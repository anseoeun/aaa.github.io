<template>
  <div 
    v-if="isOpen"
    :width="popWidth"
    :dim="isDim"
    :showClose="showClose"
    :dimClose="dimClose"
    class="layerpopup">
      <div class="dim" v-if="isDim"></div>
      <div class="pop-wrap" :style="'width:'+popWidth+'px'">
          <div class="popup">
              <VBtn class="close" @click="onClose"><i class="ico ico-close"></i></VBtn>
              <div class="pop-header">
                  <slot name="header" />
              </div>
              <div class="pop-body">
                   <slot name="body" />
              </div>
          </div>
      </div>
  </div>
</template>

<script>
export default {
  name: 'VPopup',
  head() {
    return {
      bodyAttrs: {
        style: this.isOpen ? 'overflow:hidden' : ''
      }
    }
  },
  props: {
    isOpen:{
      type:Boolean,
      default:false
    },
    popWidth:{
      type:Number,
      default:300
    },
    isDim:{
      type:Boolean,
      default:true
    },
    showClose:{
      type:Boolean,
      default:true
    },
    dimClose:{
      type:Boolean,
      default:true
    },
  },
  data() {
    return {

    }
  },

  methods: {
    onClose() {
      this.$emit('close')
    },
    onCloseDim(dimClose) {
      if(this.dimClose) this.$emit('close')
    },
  }
}
</script>