<template>
    <div class="cont-box">
        <h2 class="title-type1">주문</h2>
        <div class="data-top">
            <h3 class="title-type2">주문 관리</h3>
            <div class="btns">
                <VBtn type="nlink" to="/" class="btn-type2 st4">옵션 관리</VBtn>
                <VBtn type="nlink" to="/" class="btn-type2 st3">통계</VBtn>
            </div>
        </div>
        <div class="data-search">
            <div class="left">
                <VSelect v-model="year" :data="yearList" />
                <VSelect v-model="month" :data="monthList" />
                <VSelect v-model="cate" :data="cateList" />
                <VBtn type="submit" class="btn-type5 st1">조회</VBtn>
            </div>
            <div class="right">
                <div class="total">
                    <span class="label">합계</span>
                    <span class="price"><b>2,107,500</b>원</span>
                </div>
            </div>
        </div>
        <!-- table -->
        <div class="data-type1">
        <table>
            <colgroup>
                <col style='width:60px' />
                <col style='width:100px' />
                <col style='width:120px' />
                <col style='width:auto' />
                <col style='width:130px' />
                <col style='width:100px' />
                <col style='width:150px' />
            </colgroup>
            <thead>
                <tr>
                    <th>
                        <VCheckbox :checked.sync="all" @change="allCheck" />
                    </th>
                    <th>주문번호</th>
                    <th>주문일자</th>
                    <th>주문상품</th>
                    <th>결제금액</th>
                    <th>주문자</th>
                    <th>주문상태</th>
                </tr>
            </thead>
            <tbody>
                <tr v-for="(item, index) in dataList" :key="index">
                    <td>
                        <VCheckbox :checked.sync="item.check" @change="checkChange(index)" />
                    </td>
                    <td>{{ item.orderNum }}</td>
                    <td>{{ item.date }}</td>
                    <td>{{ item.title }}</td>
                    <td>{{ item.price }}</td>
                    <td>{{ item.orderer }}</td>
                    <td>{{ item.status }}</td>
                </tr>
            </tbody>
        </table>
        </div>
        <!-- //table -->
        <VPagination />
    </div>
</template>
<script>
export default {
  data() {
    return {
        year:'2020',
        month:'03',
        cate:'01',
        yearList:[
           {value:'2020', label:'2020'} ,
           {value:'2021', label:'2021'} ,
           {value:'2022', label:'2022'}
        ],
        monthList:[
           {value:'03', label:'03'} ,
           {value:'04', label:'04'} ,
           {value:'05', label:'05'}
        ],
        cateList:[
           {value:'01', label:'전체'} ,
           {value:'02', label:'주문일자'} ,
           {value:'03', label:'주문상품'}
        ],
        dataList:[
            {check:false, orderNum:'11-11-1111', date:'2021-04-07', title:'아메리카노2, 딸기라떼1', price:'10,500', orderer:'POS', status:'결재대기'},
            {check:false, orderNum:'11-11-1111', date:'2021-04-07', title:'아메리카노2, 딸기라떼1', price:'10,500', orderer:'POS', status:'결재대기'},
            {check:false, orderNum:'11-11-1111', date:'2021-04-07', title:'아메리카노2, 딸기라떼1', price:'10,500', orderer:'POS', status:'결재대기'},
            {check:false, orderNum:'11-11-1111', date:'2021-04-07', title:'아메리카노2, 딸기라떼1', price:'10,500', orderer:'POS', status:'결재대기'},
            {check:false, orderNum:'11-11-1111', date:'2021-04-07', title:'아메리카노2, 딸기라떼1', price:'10,500', orderer:'POS', status:'결재대기'},
            {check:false, orderNum:'11-11-1111', date:'2021-04-07', title:'아메리카노2, 딸기라떼1', price:'10,500', orderer:'POS', status:'결재대기'},
            {check:false, orderNum:'11-11-1111', date:'2021-04-07', title:'아메리카노2, 딸기라떼1', price:'10,500', orderer:'POS', status:'결재대기'},
            {check:false, orderNum:'11-11-1111', date:'2021-04-07', title:'아메리카노2, 딸기라떼1', price:'10,500', orderer:'POS', status:'결재대기'},
            {check:false, orderNum:'11-11-1111', date:'2021-04-07', title:'아메리카노2, 딸기라떼1', price:'10,500', orderer:'POS', status:'결재대기'},
        ],
        all: false,
    }
  },
  mounted(){
      
      
  },
  methods:{
      allCheck(){
        this.dataList.forEach((value, index) => {
            this.all ? value.check = true : value.check = false
        });
      },
      checkChange(index){
        this.all = true
        this.dataList.forEach((value, index) => {
            if(value.check === false) {
                this.all = false
            }
        });
      }
  }
}
</script>
