<template>
    <div>
        <div class="cont-box">
            <h2 class="title-type1">상품</h2>
            <div class="data-top line">
                <h3 class="title-type2">내 상품</h3>
                <div class="btns">
                    <VBtn class="btn-type2 st4">옵션 관리</VBtn>
                    <VBtn class="btn-type2 st3">통계</VBtn>
                </div>
            </div>
    
            <div class="option-manager">
                <div class="btn-box">
                    <a href="javascript:void(0);" class="btn-type2 st1">적용</a>
                    <a href="javascript:void(0);" class="btn-type2 st6">취소</a>
                </div>
                <div class="option-set">
                    <VBtn class="option add" @click="addOption">
                        <i class="ico i-plus-circle"></i>
                    </VBtn>
                    <div v-for="(item, index) in optList" :key="index" class="option" :style="`z-index:${100-index}`">
                        <div class="opt-name">{{ item.name }}</div>
                        <div class="opt-text">
                            {{ optSet(item)}}
                        </div>
                        <VBtn class="btn-type4 st7" @click="item.edit = true"><i class="ico i-pen2"></i>편집</VBtn>

                        <div v-if="item.edit" class="opt-layer">
                            <div class="left">
                                <div class="opt-tit">
                                    <VInput type="text" v-model="item.name" />
                                </div>
                                <p class="txt">기본 선택 옵션을 골라주세요.</p>
                                <ul>
                                    <li v-for="(option, idx) in item.opt" :key="idx">
                                        <VRadio v-model="item.val" :id="option" :name="`radio${index}`" />
                                        <div class="input-wrap">
                                            <VInput v-model="item.opt[idx]" type="text" />
                                            <VBtn v-if="(idx+1) === item.opt.length" @click="addOpt(item.opt)" class="plus"></VBtn>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                            <div class="right">
                                <VBtn class="btn-type4 st6" @click="changeData(item, index);item.edit = false"><i class="ico i-check-white"></i>완료</VBtn>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    data() {
    return {
        newItem:[
            {edit:false, name:'', val:'null', opt:['']}
        ],
        optList:[
            {edit:false, name:'온도', val:'ICED', opt:[ 'ICED', 'HOT' ]},
            {edit:false, name:'얼음', val:'보통', opt:[ '많이','보통','적게' ]},
        ],     
        addVisible:false,
        popVisible:false,
    }
    },
    mounted(){

    },
    methods:{
        optSet(item){
            let opt = item.opt.filter(
                (element, i) => element !== ''
            );
          return opt.map(v => v === item.val ? v+'(기본)' : v).join(', ') 
        },
        addData(newdata){
            if(newdata.name === '') return
            this.optList.push(bewdata)
        },
        changeData(data, index){
            if(data.name === '') {
                this.optList.splice(index, 1);
                return
            }
            this.optList.splice(index, 1, data);
        },        
        addOption(data){
            this.optList.push({edit:true, name:'', val:'null', opt:['']})
            this.addVisible = true
        },
        addOpt(data){
            if(data.name === '') return
            data.push('')
        }
    }  
}
</script>
