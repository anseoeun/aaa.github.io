<template>
    <div>
        <div class="cont-box">
            <h2 class="title-type1">상품</h2>
            <div class="data-top line">
                <h3 class="title-type2">내 상품</h3>
                <div class="btns">
                    <VBtn class="btn-type2 st4">옵션 관리</VBtn>
                    <VBtn class="btn-type2 st3">통계</VBtn>
                </div>
            </div>
            <div class="data-info-top">
                <div class="left">
                    <VBtn v-for="(item, index) in menuList" :key="index" 
                    class="btn-type3 st5" 
                    :class="{st6: menu === item.value}" 
                    @click="checkMenu(index)">{{ item.label }}</VBtn>
                </div>
                <div class="right">
                    <VBtn class="btn-type4 st7" @click="popVisible=true"><i class="ico i-setting"></i>편집</VBtn>
                    <VBtn class="btn-type4 st7"><i class="ico i-pen"></i>수정</VBtn>
                    <VBtn class="btn-type4 st7"><i class="ico i-add"></i>추가</VBtn>
                </div>
            </div>
            <!-- table -->
            <div v-if="menu === 'menu1'" class="data-type1">
            <table>
                <colgroup>
                    <col style='width:100px' />
                    <col style='width:auto' />
                    <col style='width:170px' />
                    <col style='width:200px' />
                </colgroup>
                <thead>
                    <tr>
                        <th>NO</th>
                        <th>상품명</th>
                        <th>가격(원)</th>
                        <th>수량(개)</th>
                    </tr>
                </thead>
                <tbody>
                    <tr v-for="(item, index) in dataList2" :key="index">
                        <td>{{ index + 1 }}</td>
                        <td class="align-l"><VBtn type="nlink" to="/">{{ item.title }}</VBtn></td>
                        <td>{{ item.price }}</td>
                        <td>{{ item.num }}</td>
                    </tr>
                </tbody>
            </table>
            </div>
            <!-- //table -->
            <!-- table -->
            <div v-else class="data-type1">
            <table>
                <colgroup>
                    <col style='width:60px' />
                    <col style='width:80px' />
                    <col style='width:auto' />
                    <col style='width:170px' />
                    <col style='width:200px' />
                </colgroup>
                <thead>
                    <tr>
                        <th>
                            <VCheckbox :checked.sync="all.dataList2" @change="allCheck('dataList1')" />
                        </th>
                        <th>NO</th>
                        <th>상품명</th>
                        <th>가격(원)</th>
                        <th>수량(개)</th>
                    </tr>
                </thead>
                <tbody>
                    <tr v-for="(item, index) in dataList2" :key="index">
                        <td>
                            <VCheckbox :checked.sync="item.check" @change="checkChange('dataList1', index)" />
                        </td>
                        <td>{{ index + 1 }}</td>
                        <td class="align-l"><VBtn type="nlink" to="/">{{ item.title }}</VBtn></td>
                        <td>{{ item.price }}</td>
                        <td>{{ item.num }}</td>
                    </tr>
                </tbody>
            </table>
            </div>
            <!-- //table -->
            <VPagination />
        </div>

        <v-popup
            :is-open="popVisible"
            @close="popVisible = false">
            <template slot="header">
            <p class="pop-tit">카테고리 편집</p>	
            </template>
            <template slot="body">
                <VBtn @click="add">새카테고리</VBtn>
                <draggable 
                :list="list"
                tag="ul"
                ghost-class="ghost"
                class="cate-list"
                @start="dragging = true"
                @end="dragging = false" 
                >
                    <li v-for="(element, idx) in list" :key="idx" class="list-group-item">
                        <div class="cate">
                            <i class="line"></i>
                            <VInput v-if="element.modify" />
                            <span v-else class="txt">{{ element.name }}</span>
                            <VBtn v-if="element.modify" @click="element.modify = false">완료</VBtn>
                            <VBtn v-else @click="element.modify = true"><i class="ico i-pen"></i></VBtn>
                            <VBtn @click="removeAt(idx)"><i class="ico i-del"></i></VBtn>
                        </div>
                    </li>
                </draggable>
            </template>
        </v-popup>
    </div>
</template>

<script>
import draggable from 'vuedraggable'
export default {
    components:{
        draggable
    },
    data() {
    return {
        menu: 'menu1',
        menuList:[
            {label:'전체', value:'menu1'},
            {label:'시즌메뉴', value:'menu2'},
            {label:'이벤트', value:'menu3'},
            {label:'커피', value:'menu4'},
            {label:'라떼', value:'menu5'},
            {label:'음료', value:'menu6'},
            {label:'디저트', value:'menu7'} 
        ],
        dataList1:[
            {check:false, orderNum:'11-11-1111', date:'2021-04-07', title:'아메리카노2, 딸기라떼1', price:'10,500', orderer:'POS', status:'결재대기'},
            {check:false, orderNum:'11-11-1111', date:'2021-04-07', title:'아메리카노2, 딸기라떼1', price:'10,500', orderer:'POS', status:'결재대기'},
            {check:false, orderNum:'11-11-1111', date:'2021-04-07', title:'아메리카노2, 딸기라떼1', price:'10,500', orderer:'POS', status:'결재대기'},
            {check:false, orderNum:'11-11-1111', date:'2021-04-07', title:'아메리카노2, 딸기라떼1', price:'10,500', orderer:'POS', status:'결재대기'},
            {check:false, orderNum:'11-11-1111', date:'2021-04-07', title:'아메리카노2, 딸기라떼1', price:'10,500', orderer:'POS', status:'결재대기'},
            {check:false, orderNum:'11-11-1111', date:'2021-04-07', title:'아메리카노2, 딸기라떼1', price:'10,500', orderer:'POS', status:'결재대기'},
            {check:false, orderNum:'11-11-1111', date:'2021-04-07', title:'아메리카노2, 딸기라떼1', price:'10,500', orderer:'POS', status:'결재대기'},
            {check:false, orderNum:'11-11-1111', date:'2021-04-07', title:'아메리카노2, 딸기라떼1', price:'10,500', orderer:'POS', status:'결재대기'},
            {check:false, orderNum:'11-11-1111', date:'2021-04-07', title:'아메리카노2, 딸기라떼1', price:'10,500', orderer:'POS', status:'결재대기'},
        ],
        dataList2:[
            {check:false, title:'아메리카노2, 딸기라떼1', price:'10,500', num:'999'},
            {check:false, title:'아메리카노2, 딸기라떼1', price:'10,500', num:'999'},
            {check:false, title:'아메리카노2, 딸기라떼1', price:'10,500', num:'999'},
            {check:false, title:'아메리카노2, 딸기라떼1', price:'10,500', num:'999'},
            {check:false, title:'아메리카노2, 딸기라떼1', price:'10,500', num:'999'},
            {check:false, title:'아메리카노2, 딸기라떼1', price:'10,500', num:'999'},
            {check:false, title:'아메리카노2, 딸기라떼1', price:'10,500', num:'999'},
            {check:false, title:'아메리카노2, 딸기라떼1', price:'10,500', num:'999'},
            {check:false, title:'아메리카노2, 딸기라떼1', price:'10,500', num:'999'},
        ],
        all: {
            dataList1: false,
            dataList2: false,
        },          
        popVisible:false,
        list:[
            {name:'전체', id:1, modify:false},
            {name:'시즌메뉴', id:2, modify:false},
            {name:'이벤트', id:3, modify:false},
            {name:'라떼', id:4, modify:false},
            {name:'음료', id:5, modify:false},
        ],
        listNum: 5,
    }
    },
    mounted(){
        import('~/assets/js/jquery-ui.js').then(m => {
        
        });    
    },
    methods:{
        allCheck(data){
            this[data].forEach((value, index) => {
                this.all[data] ? value.check = true : value.check = false
            });
        },
        checkChange(data, index){
            this.all[data] = true
            this[data].forEach((value, index) => {
                if(value.check === false) {
                    this.all[data] = false
                }
            });
        },

        add() {
            this.list.push({ name: "New" + this.listNum, id: this.listNum++, modify:false });
        },   
        removeAt(idx){
            this.list.splice(idx, 1);
        },
        checkMenu(index){
          this.menu = this.menuList[index].value
        }
    }  
}
</script>
