<template>
  <div class="samplePage">
    <v-checkbox :one-check="true" :checked.sync="allCheck" @change="allCheckChange"
      >전체체크</v-checkbox
    >      
      <v-checkbox v-model="checkboxDataVal" :data="checkboxListData" @change="checkChange" />

      <v-checkbox v-model="checkboxDataVal2" :data="checkboxListData2" all-chk-name="전체체크" />
  </div>
</template>

<script>
import { VCheckbox} from '~/components/element'
export default {
  name: 'UiComponent',
  components: {
    VCheckbox,
  },
  data() {
    return {
        allCheck: false,
      checkboxDataVal: [],
      checkboxListData: [
        { value: 'check1', label: '체크박스1', text:'텍스트1' },
        { value: 'check2', label: '체크박스2', text:'텍스트2' },
        { value: 'check3', label: '체크박스3', text:'텍스트3' },
        { value: 'check4', label: '체크박스4', text:'텍스트4' },
      ],
      checkboxDataVal2: [],
      checkboxListData2: [
        { value: 'check1', label: '체크박스1', text:'텍스트1' },
        { value: 'check2', label: '체크박스2', text:'텍스트2' },
        { value: 'check3', label: '체크박스3', text:'텍스트3' },
        { value: 'check4', label: '체크박스4', text:'텍스트4' },
      ],
    }
  },

  mounted() {

  },
  methods: {
    allCheckChange() {
    if(this.allCheck){
        let val = []
        this.checkboxListData.forEach((value, index) => {
            val.push(value.value)
        })
        this.allCheck = true
        this.checkboxDataVal = val
      }else{
       this.allCheck = false
       this.checkboxDataVal = ['']
      }
    },
    checkChange() {
       if(this.checkboxListData.length !== this.checkboxDataVal.length) {
           this.allCheck = false
       }else{
           this.allCheck = true
       }
    }
  },
}
</script>

