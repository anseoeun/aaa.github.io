<template>
  <div :class="`checkbox ${checkType}`">
    <el-checkbox v-if="oneCheck" v-model="isChecked" :disabled="disabled" :custom-style="customStyle" @change="onChange">
      <slot></slot>
    </el-checkbox>

    <el-checkbox-group v-else v-model="selected" :disabled="disabled" :custom-style="customStyle">
      <el-checkbox v-if="allChkName !== ''" label="all" :disabled="disabled" :custom-style="customStyle" @change="allChange" class="all-check">
        {{ allChkName }}
      </el-checkbox>
      <el-checkbox
        v-for="(item, index) in data"
        :key="index"
        :label="item[valueKey]"
        :disabled="item.disabled || item.fixed"
        :custom-style="item.customStyle"
        @change="onChange($event, item[valueKey])"
      >
        <slot v-if="customLabel" :item="item"></slot>
        <span v-else>{{ item[labelKey] }}</span>
      </el-checkbox>
    </el-checkbox-group>
  </div>
</template>


<script>
export default {
  props: {
    value: {
      type: Array,
      default: () => []
    },
    // eslint-disable-next-line
    checked: [String, Boolean],
    allChkName: {
      type: String,
      default: ''
    },
    trueValue: {
      type: String,
      default: null
    },
    valueKey: {
      type: String,
      default: 'value'
    },
    labelKey: {
      type: String,
      default: 'label'
    },
    disabled: {
      type: Boolean,
      default: false
    },
    customLabel: {
      type: Boolean,
      default: false
    },
    checkType: {
      type: String,
      default: ''
    },
    data: {
      type: Array,
      default: () => []
    },
    oneCheck: {
      type: Boolean,
      default: false
    },
    customStyle: {
      type: Boolean,
      default: false
    },
    allChkName:{
      type: String,
      default: ''
    }    
  },
  data() {
    return {
      selected: [],
      isChecked: null,
      checkAll: null
    }
  },
  watch: {
    value(newValue, oldValue) {
      const diffList = newValue.filter((val, index) => val !== oldValue[index])
      if (diffList.length) {
        this.selected = [...newValue]
      }
    },
    checked(newValue, oldValue) {
      if (newValue !== oldValue) {
        this.isChecked =
          typeof this.checked === 'boolean' ? newValue : newValue !== '' && newValue !== undefined && newValue !== null
      }
    }
  },
  created() {
    if (this.oneCheck) {
      const checked =
        typeof this.checked === 'boolean'
          ? this.checked
          : this.checked !== '' && this.checked !== undefined && this.checked !== null
      if (this.isChecked !== checked) {
        this.isChecked = checked
        this.onChange()
      }
    } else {
      this.selected = [...this.value]
      if (this.selected.length) {
        this.onChange()
      }
    }
  },

  methods: {
    onChange(chk, val) {
      if (this.oneCheck) {
        const value = typeof this.checked === 'boolean' ? this.isChecked : this.isChecked ? this.trueValue : ''
        this.$emit('update:checked', value)
        this.$emit('change', value)
      } else {
        this.$emit('input', this.selected)
        this.$emit('change', this.selected)
      }
      if (chk === true) this.$emit('checked', val)
      else if (chk === false) this.$emit('unchecked', val)

      if(this.allChkName){
        let total = this.selected.includes('all') ? this.data.length + 1 : this.data.length
        console.log(this.selected.length, total);
        if(this.selected.length === total){
          this.allChange(true)
        }else{
          if(this.selected.includes('all')){
            this.selected = this.selected.shift()
          }
        }
      }       
    },
    allChange(val) {
      let allChk = val ? ['all'] : []

      if (val)
        this.data.forEach((element) => {
          allChk.push(element.value)
        })
      this.selected = allChk
      this.$emit('input', this.selected)
      this.$emit('change', this.selected)
    }
  }
}
</script>

