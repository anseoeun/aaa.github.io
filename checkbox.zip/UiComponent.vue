<template>
  <div class="samplePage">
    <h2>버튼</h2>
    <v-btn class="btn lg blue r" type="nlink" to="./TabPage1"
      >넉스트 a태그 버튼</v-btn
    >
    <v-btn
      class="btn lg gray r"
      type="link"
      href="https://kr.vuejs.org/v2/guide/class-and-style.html"
      >a태그 버튼(외부링크)</v-btn
    >
    <v-btn class="btn md white r" type="button">button 버튼</v-btn>
    <v-btn class="btn md blue line r" type="button">button 버튼</v-btn>
    <v-btn class="btn md gray line r" type="button">button 버튼</v-btn>
    <v-btn class="btn" type="submit">submit 버튼</v-btn>
    <v-btn class="btn-more" type="nlink">더보기</v-btn>
    <v-btn type="icon" icon-class="icon-info"></v-btn>


    <h2>탭</h2>
    <v-tab class="tab-default" :data="tabList" :contents="true">
      <template slot="contents">
        <div style="border: 1px solid #000" data-id="tab1">tab1</div>
        <div style="border: 1px solid #000" data-id="tab2">tab2</div>
        <div style="border: 1px solid #000" data-id="tab3">tab3</div>
      </template>
    </v-tab>
    <br />

    <v-tab class="tab-default line" :data="tabList" :contents="true">
      <template slot="contents">
        <div style="border: 1px solid #000" data-id="tab1">tab1</div>
        <div style="border: 1px solid #000" data-id="tab2">tab2</div>
        <div style="border: 1px solid #000" data-id="tab3">tab3</div>
      </template>
    </v-tab>

    <br />
    <v-tab class="tab-sub" :data="tabList" :contents="true">
      <template slot="contents">
        <div data-id="tab1"><tab-page1 /></div>
        <div data-id="tab2"><tab-page2 /></div>
      </template>
    </v-tab>

    <h2>팝업</h2>
    <v-btn class="btn md blue" type="button" @click="popVisible = true"
      >팝업오픈 (센터일경우 class="center 추가")</v-btn
    >
    <v-btn class="btn md blue" type="button" @click="popVisible2 = true"
      >팝업오픈2</v-btn
    >
    <v-btn class="btn md blue" type="button" @click="popVisible3 = true"
      >팝업오픈 (전체)</v-btn
    >
    <test-pop :visible="popVisible2" @close="popVisible2 = false"></test-pop>
    <v-popup
      :footer="['confirm']"
      :visible="popVisible"
      :width="'1000px'"
      @confirm="popVisible = false"
      @close="
        $emit('close')
        popVisible = false
      "
    >
      <template slot="header">
        <div class="title">취득세 안내</div>
      </template>
      <template slot="body">
        <p class="contents-head">* 취득세는 자동차 등록시 부과되는 지방세로 차량 공급가격의 4~7% 입니다.</p>
        <div class="table-area">
          <table>
            <colgroup>
              <col width="113px" />
              <col width="113px" />
              <col width="338px" />
              <col width="113px" />
              <col width="113px" />
              <col width="113px" />
            </colgroup>
            <thead>
              <tr>
                <th rowspan="2">세목</th>
                <th rowspan="2">과세기준액</th>
                <th rowspan="2">경차 세율</th>
                <th colspan="2">비영업용 세율</th>
                <th rowspan="2">영업용 세율</th>
              </tr>
              <tr>
                <th>승용</th>
                <th>승합/화물</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>취득세</td>
                <td>판매가 - 부가세</td>
                <td class="left">
                  <ul class="bullet-list">
                    <li>50만원 한도 내 면제 (2021년 말까지)</li>
                    <li>4% (2022년
                      이후)</li>
                  </ul>
                </td>
                <td>7%</td>
                <td>5%</td>
                <td>4%</td>
              </tr>
            </tbody>
          </table>
          <small>(1포인트 = 1원)</small>
        </div>
      </template>
    </v-popup>

    <v-popup
      :footer="['confirm']"
      :visible="popVisible3"
      :full-popup="true"
      class="full-popup"
      @confirm="popVisible3 = false"
      @close="popVisible3 = false"
    >
      <template slot="header">
          <v-pageheader
            page-title="AX 사전계약"
            page-infotext="온라인에서 진행하는 ooooooo의 사전 계약을 시작합니다."
          />
      </template>
      <template slot="body">
        팝업 내용 <br />
      </template>
    </v-popup>

    <h2>폼</h2>
    <v-checkbox :one-check="true" :checked.sync="checkboxDataVal"
      >단독체크박스</v-checkbox
    >
    <h3>리스트형</h3>
    <v-checkbox v-model="checkboxDataListVal" :data="checkboxListData" />
    <!-- <v-checkbox v-model="checkboxDataListVal" :data="checkboxListData" all-chk-name="전체체크" /> -->
    <h3>커스텀 리스트형</h3>
    <v-checkbox v-model="checkboxDataListVal" :custom-label="true" :data="checkboxListData">
      <template slot-scope="props">{{ props.item.label }} {{ props.item.text }}</template>
    </v-checkbox>

    <h3>기본</h3>
    <v-radio v-model="radioCheck" :data="optsList1" />
    <h3>기본 커스텀</h3>
    <v-radio v-model="radioCheck" :custom-label="true" :data="optsList1">
      <template slot-scope="props">{{ props.item.label }} {{ props.item.color }}</template>
    </v-radio>

    <h3>다른 네임을 value로 사용</h3>
      <v-radio
        v-model="optsList2Checked"
        :data="optsList2"
        :custom-label="true"
        value-key="id"
        label-key="label"
      >
      <template slot-scope="props">{{ props.item.label }} {{ props.item.color }}</template>
    </v-radio>

    <h3>커스텀</h3>
    <v-radio v-model="deliveryAdress" :one-check="true" label="1">커스텀 라디오1</v-radio>
    <v-radio v-model="deliveryAdress" :one-check="true" label="2">커스텀 라디오2</v-radio>
    <div>{{ deliveryAdress }}</div>

    <h3>버튼형</h3>
    <v-radio v-model="radioCheck" class="radio-button" type="button" :data="optsList1" />
    <h3>버튼형 커스텀</h3>
    <v-radio v-model="radioCheck" class="radio-button" type="button" :custom-label="true" :data="optsList1">
        <template slot-scope="props">{{ props.item.label }} {{ props.item.color }}</template>
    </v-radio>

    <el-form ref="askForm" :model="askForm" :rules="rules" label-position="top">
      <div class="form-grid-list" prop="type">
        <ul>
          <li>

          <el-form-item prop="check">
            <v-checkbox v-model="askForm.check" :data="checkboxListData" />
          </el-form-item>

          </li>
          <li>
            <div class="form-group">
              <el-form-item label="" prop="bigOPtionValue">
                <v-select
                  v-model="askForm.bigOPtionValue"
                  :data="askForm.bigOPtion"
                  placeholder="Select"
                />
              </el-form-item>
            </div>
          </li>
          <li>
            <div class="form-group">
              <el-form-item label="" required prop="titleName">
                <v-input v-model="askForm.titleName" />
              </el-form-item>
            </div>
          </li>
        </ul>
      </div>
    </el-form>


    <h2>셀렉트</h2>
    <v-select
      v-model="selectListVal"
      :data="selectList"
      placeholder="통신사 선택"
    />
    <h2>달력</h2>
    <div class="label-input">
      <span class="offscreen">날자</span>
      <v-date-picker v-model="dateVal" class="datepicker" />
    </div>
    <div class="inbl-wrap">
      <div class="date-wrap">
        <div class="label-input">
          <span class="offscreen">시작일</span>
          <v-date-picker v-model="startDate" class="datepicker" />
        </div>
        <span class="dash"></span>
        <div class="label-input">
          <span class="offscreen">종료일</span>
          <v-date-picker v-model="endDate" class="datepicker" />
        </div>
      </div>
        <v-select
          v-model="selectCalVal"
          :data="selectCalList"
          class="no-st"
          @change="calChange"
        />
    </div>


    <h2>파일첨부</h2>
    <div class="file-upload">
      <div class="file-input">
        <input ref="fileInput" type="file" class="offscreen" @change="changeFile" />
        <v-input v-model="fileVal" class="file-value" />
        <v-btn v-if="fileVal !== ''" class="btn-file-delete" type="button" @click="fileDelete"><span>파일삭제</span></v-btn>
      </div>
      <v-btn class="file-btn btn-more" type="button" @click="fileOpen">파일찾기</v-btn>
    </div>

    <h2>페이징</h2>
    <!-- <v-pagination-el :total="100" /> -->
    <v-pagination :total="100" />
    <v-page-more :total="30" :page="10" />

    <h2>툴팁</h2>
    <v-tooltip content="Top center" placement="top-start">
      <v-btn>툴팁툴팁</v-btn>
    </v-tooltip>

    <v-popover trigger="hover" placement="bottom-start">
      <!--
        placement="bottom-start"
        placement="top-start"
        placement="bottom"
        placement="right"
       -->
      <p>
        M포인트는 M계열 카드로 어디서든 쓰면 쓸수록 더 쌓아주는 포인트로 다양한 영역에서 사용할 수 있습니다.
      </p>
      <v-btn slot="reference"><i class="icon-help"></i></v-btn>
    </v-popover>

    <h2>슬라이딩 리스트</h2>
      <el-collapse :v-model="1">
        <el-collapse-item name="1">
          <template slot="title">
            <div>
              타이틀타이틀
            </div>
          </template>
          <div>내용내용</div>
          <div>내용내용</div>
        </el-collapse-item>
        <el-collapse-item name="2">
            <template slot="title">
              <div>
                타이틀타이틀
              </div>
            </template>
            <div>내용내용</div>
            <div>내용내용</div>
        </el-collapse-item>
      </el-collapse>

      <h2>슬라이더</h2>
        <v-slider
          :min="100000"
          :max="12600000"
          :step="100000"
          :marks="{
            100000: '100,000',
            12600000: '12,600,000'
          }"
        />

        <v-slider
          :min="3"
          :max="100"
          :step="1"
          :marks="{
            3: '3',
            36: '36',
            60: '60'
          }"
        />

    <h2>별점</h2>
    <v-rate :value.sync="rateval"
    @change="aaa"
      >
      <!-- :colors="colors" -->
    </v-rate>
    <div>{{ rateval }}</div>


    <h2>이미지</h2>
    <v-img :src="require('~/assets/images/temp/temp-payment-car-model.png')" alt="AX 자가용 5인승 가솔린 1.6 2WD IVT Smart"></v-img>

    <h2>프로그래스바</h2>
    <v-progress-bar
        type="percent"
        total-width="400"
        current-per="50"
        height="10"
      />

  </div>
</template>

<script>
import { VCheckbox, VTab, VBtn, VSelect, VRadio, VInput,  VPageMore, VPagination, VPageheader, VPopup, VTooltip, VSlider, VPopover, VImg, VDatePicker, VRate} from '~/components/element'
import VProgressBar from '~/components/element/VProgressBar'
import VCarousel from '~/components/element/VCarousel'
// import  from '~/components/element/VDatepicker'
import TabPage1 from './TabPage1'
import TabPage2 from './TabPage2'
import TestPop from './TestPop'
export default {
  name: 'UiComponent',
  components: {
    VCheckbox,
    VTab,
    VBtn,
    VSelect,
    VRadio,
    VInput,
    VPopup,
    VCarousel,
    VPageheader,
    TabPage1,
    TabPage2,
    VPageMore,
    VPopover,
    VPagination,
    VTooltip,
    VSlider,
    TestPop,
    VImg,
    VDatePicker,
    VProgressBar,
    VRate
  },
  data() {
    return {
      isActive: true,
      // 탭
      tabList: [
        { value: 'tab1', label: '탭1' },
        { value: 'tab2', label: '탭2' },
        { value: 'tab3', label: '탭3' },
      ],
      // 팝업
      popVisible: false,
      popVisible2: false,
      popVisible3: false,
      // 체크박스
      checkboxDataVal: false,
      checkboxDataListVal: ['check1', 'check2', 'check3'],
      checkboxListData: [
        { value: 'check1', label: '체크박스1', text:'텍스트1' },
        { value: 'check2', label: '체크박스2', text:'텍스트2' },
        { value: 'check3', label: '체크박스3', text:'텍스트3' },
        { value: 'check4', label: '체크박스4', text:'텍스트4' },
      ],
      // 라디오
      deliveryAdress:null,
      radioCheck: '',
      optsList1: [
        { value: 'check1', label: '라디오1', color:'쉬머' },
        { value: 'check2', label: '라디오2', color:'아머' },
      ],
      optsList2Checked: '',
      optsList2: [
        {
          id: 'id1',
          label: '기본',
        },
        {
          id: 'id2',
          label: '라디오1',
        },
        {
          id: 'id3',
          label: '라디오2',
        },
      ],
      // 인풋
      inputVal: null,
      // textarea
      textareaVal: null,
      // 셀렉트
      selectListVal: '',
      selectList: [
        { value: '', label: 'Select' },
        { value: 'select1', label: 'SKT' },
        { value: 'select2', label: 'KT' },
        { value: 'select3', label: 'LGU+' },
        { value: 'select4', label: '알뜰폰 SKT' },
        { value: 'select5', label: '알뜰폰 KT' },
        { value: 'select6', label: '알뜰폰 LGU+' },
      ],
      askForm: {
        check: [],
        textCount: 0,
        bigOPtionValue: '',
        bigOPtion: [
          {
            value: '',
            label: '대분류 선택'
          },
          {
            value: 'Option1',
            label: '차량구매'
          },
          {
            value: 'Option2',
            label: '블루멤버스'
          },
          {
            value: 'Option3',
            label: '임직원 구매 제도'
          }
        ],
        smallOPtionValue: 'Option1',
        smallOPtion: [
          {
            value: 'Option1',
            label: '소분류 선택'
          },
          {
            value: 'Option2',
            label: '소분류 선택'
          },
          {
            value: 'Option3',
            label: '소분류 선택'
          },
          {
            value: 'Option4',
            label: '소분류 선택'
          },
          {
            value: 'Option5',
            label: '소분류 선택'
          }
        ],
        titleName: '',
        checked: ['check1'],
        optsList: [{ value: 'check1', label: 'SMS 알림 받기' }]
      },
      //별점
      rateval:2,
      iconShow:true,
      fileVal:'',
      //달력
      dateVal:'',
      startDate:'',
      endDate:'',
      selectCalVal:'',
      selectCalList:[
        { value: '', label: '선택' },
        { value: 'week', label: '1주일' },
        { value: 'month', label: '1개월' },
      ],
    }
  },
  computed: {
    rules() {
      return {
        check: [
          { type: 'array', required: true, message: '체크해주세요', trigger: 'change' }
        ],
        bigOPtionValue: [{ required: true, message: '대분류를 선택해 주세요.', trigger: 'change' }],
        smallOPtionValue: [{ required: true, message: '소분류를 선택해 주세요.', trigger: 'change' }],
        titleName: [
          {
            required: true,
            message: '제목을 입력하세요.',
            trigger: ['blur', 'change']
          }
        ],
      }
    },
  },
  watch: {
  },
  mounted() {
    // console.dir(this)
    this.today()
    // this.lastWeek()
  },
  updated() {
    if (this.popVisible) {
      this.setCaption()
    }
  },
  methods: {
    resetId() {
      if (this.inputVal) {
        this.inputVal = ''
      }
    },
    iconChange(){
      this.iconShow = false
    },
    changeFile(e) {
      var files = e.target.files || e.dataTransfer.files
      this.fileVal = files[0].name
    },
    fileDelete(){
      this.$refs.fileInput.value = ''
      this.fileVal = ''
    },
    fileOpen(){
      this.$refs.fileInput.click()
    },
    //달력
    getDateStr(myDate){
      let year = myDate.getFullYear()
      let month = (myDate.getMonth() + 1)
      let day = myDate.getDate()

      month = (month < 10) ? '0' + String(month) : month
      day = (day < 10) ? '0' + String(day) : day

      return  year + '.' + month + '.' + day
    },
    today() {
      let d = new Date()
      return this.getDateStr(d)
    },
    lastWeek() {
      let d = new Date()
      let dayOfMonth = d.getDate()
      d.setDate(dayOfMonth - 7)
      return this.getDateStr(d)
    },
    lastMonth() {
      let d = new Date()
      let monthOfYear = d.getMonth()
      d.setMonth(monthOfYear - 1)
      return this.getDateStr(d)
    },
    calChange(value){
      if(value == 'week'){
        this.startDate = this.today()
        this.endDate = this.lastWeek()
      }else if(value == 'month'){
        this.startDate = this.today()
        this.endDate = this.lastMonth()
      }
    },
    aaa(val){
      console.log(val)
      console.log(this.rateval)
      console.log('aaaaa')
    }
  },
}
</script>

