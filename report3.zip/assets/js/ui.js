
let pageType

$(function(){
	gnbH();
	gnbMenu();
	tabMenu();
	tableHeadersize();

	niceSelect();
	topBtn();
	newOpenClip();
});

$(window).resize(function(){
		tableHeadersize();
});
$(window).scroll(function(){
	topBtn();
});

function topBtn(){
	let top = $(window).scrollTop()
	if(top <= 0 ){
		$('.top-btn').fadeOut()
	}else{
		$('.top-btn').fadeIn()
	}
}

function niceSelect(){
	if($('select').not('.noline').length <= 0) return;
	$('select').not('.noline').niceSelect();
	$('.nice-select').not('.noline').each(function(){
		let datanum = $(this).attr('data-num')
		let w = $(this).width()
		$('ul.selectList[data-num='+datanum+']').css('width', w);
	});
}

function gnbH(){
	$('.gnb-menu-wrap').removeAttr('style');
	let wrapperH = $('.wrapper').height();
	$('.gnb-menu-wrap').height(wrapperH < $(window).height() ? $(window).height() : wrapperH);
}

function gnbMenu(){
	$('.gnb-menu-wrap .close').on('click', function(){
		$('.wrapper, .gnb-menu-wrap').removeClass('expand');
		$('.wrapper, .gnb-menu-wrap').addClass('contract');
	});
	$('.gnb-menu-wrap .menu').on('click', function(){
		$('.wrapper, .gnb-menu-wrap').addClass('expand');
		$('.wrapper, .gnb-menu-wrap').removeClass('contract');
	});
	$('.gnb-menu > ul > li a').on('click', function(){
		if($(this).next('ul').is(':hidden')){
			$(this).parent().addClass('on')
			$(this).next('ul').slideDown();
		}else{
			$(this).parent().removeClass('on')
			$(this).next('ul').slideUp();
			$(this).next('ul').find('ul').hide();
			$(this).next('ul').find('li').removeClass('on')
		}
	});
}

function tabMenu(){
	var tab = '[data-evt*="tab"]';
	//tabType1
   $(document).on('click',  tab+' a', function(e){
	e.preventDefault();
	var $this = $(this),
		id = $this.attr('href').split('#')[1];

	var $siblings = $this.parents('li').siblings('').find('a');
		$siblings.each(function(){
			var id = $(this).attr('href').split('#')[1];
			$(this).parents('li').removeClass('on');
			$('[data-id='+id+']').hide();
		});

	   $this.parents('li').addClass('on');
	   $('[data-id='+id+']').show();

	   gnbH();

	   return false;
   });
}

function tableHeadersize(){
	$('.data-list-type1 .list-header > .row').removeAttr('style');
	$('.data-list-type1 .list-header > .row').each(function(){
		let h = $(this).height();
		$(this).height(h);
	});
}

function popOpen(popup){
	var $popup = $(popup);

	$('body').css('overflow','hidden');
	$popup.show();

	$popup.find('.dim').on('click', function(){
		$popup.hide();
		$popup.removeClass('on');
		$('body').css('overflow','');
	});
}

function popClose(popup){
	var $popup = $(popup);
	$popup.hide();
	$popup.removeClass('on');
	$('body').css('overflow','');
}


//chart
function barChart(opt){
	var datasets = opt.data.map(function(chartData, i){
		return {
			// label: chartData.label,
			type:chartData.type,
			yAxisID:chartData.yAxisID,
			xAxisID:chartData.xAxisID,
			backgroundColor:chartData.bgColor,
			fill: false,
			data: chartData.data,
			label:chartData.label,
			borderWidth:0
		}
	});

	var tooltipsSetting={
		callbacks: {
			labelColor: function(tooltipItem, chart) {
					let color = tooltipItem.datasetIndex == 0 ? {
						borderColor:'rgba(0, 0, 0, 0)',
						backgroundColor: 'rgb(34, 58, 157, 1)'
					} : {
						borderColor:'rgba(0, 0, 0, 0)',
						backgroundColor: 'rgb(33, 179, 179, 1)'
					}
					return color;
			},
			labelTextColor: function(tooltipItem, chart) {
					return '#000';
			}
		},
		mode: 'index',
		intersect: false,
		xPadding:20,
		yPadding:20,
		titleMarginBottom:15,
		bodySpacing:5,
		backgroundColor:'#fff',
		borderColor: 'rgba(78,100,192,1)',
		borderWidth: 1,
		shadowOffsetX: 0,
		shadowOffsetY: 0,
		shadowBlur: 15,
		shadowColor: 'rgba(0, 0, 0, 0.3)',
		titleFontColor:'#212121',
		titleFontSize:16,
		bodyFontColor:'#212121',
		bodyFontSize:14,
	}

	var barChart = new Chart(document.getElementById(opt.id),{
		type: 'bar',
		data: {
			labels:opt.label,
			datasets: datasets
		},
		options: {
			responsive: true,
			maintainAspectRatio: false,
			legend: {
				display:false,
				align:'end',
				position:'top',
				labels:{fontSize:11,boxWidth:20},
			},
			title: {display: false},
			elements: {
				line: {
					tension: 0
				}
			},
			layout:{
				padding: {
					top: 40,
					bottom:40
				}
			},
			scales: {
				xAxes: [{
					gridLines: {
						display: false,
						// lineWidth: 0,
						// zeroLineWidth: 0,
						//drawBorder: false,
					},
					ticks: {
						fontColor: '#757575',
						fontSize: 12,
						fontStyle :'500',
						tickMarkLength:10,
					},
					categoryPercentage: 0.07,
					barPercentage: 1.2,
					maxBarThickness: 10,
					minBarLength:10,
					barThickness: 10,
					stacked:opt.xStacked ? opt.xStacked : false,
				}],
				yAxes: [{
					zeroLine:false,
					gridLines: {
						display: true,
						color:"#9e9e9e",
						lineWidth: 1,
						borderDash: [1, 2],
						// zeroLineWidth: 0,
						zeroLineColor: "#9e9e9e",
						drawTicks: true,
						tickMarkLength:0,
					},
					ticks: {
						display:false,
						beginAtZero:true,  //Y축의 값이 0부터 시작
						fontColor: '#646464',
						fontSize: 12,
						fontStyle :'500',
						padding: 10,
						max:opt.yMax ? opt.yMax : 100,
						stepSize: opt.yStepSize ? opt.yStepSize : 20,
						userCallback: function(value, index, values) {
							return value + (opt.unit != undefined ? opt.unit : '')
						},
					},
					stacked:opt.yStacked ? opt.yStacked : false,
				}],
			},
			tooltips: opt.tooltips ? opt.tooltips : tooltipsSetting
		}
	});
}

function circleChart(opt){
	var circleChart = new Chart(document.getElementById(opt.id),{
		type: 'doughnut',
		data: {
			datasets: [{
				data: opt.data,
				backgroundColor: [
					'#4e64c0',
					'#fff',
				],
				hoverOffset: 4,
				spacing:0,
				pointRadius: 1,
			}],
		},
		options: {
			responsive: true,
			maintainAspectRatio: false,
			legend: {
				display:false,
			},
			cutoutPercentage: 88,
			tooltips: false
		}
	});
}

function newOpenClip(){
	$('.btn-newopen').on('click', function(){
		let url = $(this).parents('.path').find('.link-txt').text();
		clip(url)
	});
}

function clip(url){
	// var url = '';
	var textarea = document.createElement("textarea");
	document.body.appendChild(textarea);
	// url = window.document.location.href;
	textarea.value = url;
	textarea.select();
	document.execCommand("copy");
	document.body.removeChild(textarea);
	alert("URL이 복사되었습니다.")
}