<template>
  <div class="popup-list-index">
    <header>
      <h1>{{ headingTitle }}</h1>
    </header>
    <main>
      <div v-for="(pops, index) in alist" :key="index" class="popup-list-category-box">
        <h2>{{ index + 1 + '. ' + pops.title }}</h2>
        <ul class="popup-view-list">
          <li v-for="(pop, sidx) in pops.sub" :key="sidx">
            <div v-if="pop.popup" class="popup-true-li">
              <template v-if="pop.type === 'obj'">
                <button
                  :id="pop.id"
                  class="btn md blue"
                  type="button"
                  @click="pop.popupVisible[Object.keys(pop.popupVisible)[0]] = true"
                >
                  {{
                    index +
                      1 +
                      '-' +
                      (sidx + 1) +
                      '. ' +
                      pops.title +
                      ' - ' +
                      pop.menu +
                      ' (' +
                      pop.id +
                      ') / ' +
                      pop.link
                  }}
                </button>
                <component :is="pop.id" :visible.sync="pop.popupVisible"></component>
              </template>
              <template v-else>
                <button
                  :id="pop.id"
                  class="btn md blue"
                  type="button"
                  @click="pop[Object.keys(pop)[Object.keys(pop).length - 1]] = true"
                >
                  {{
                    index +
                      1 +
                      '-' +
                      (sidx + 1) +
                      '. ' +
                      pops.title +
                      ' - ' +
                      pop.menu +
                      ' (' +
                      pop.id +
                      ') / ' +
                      pop.link
                  }}
                </button>
                <component
                  :is="pop.id"
                  :[setname(pop)]="pop[Object.keys(pop)[Object.keys(pop).length - 1]]"
                  @close="pop[Object.keys(pop)[Object.keys(pop).length - 1]] = false"
                ></component>
              </template>
            </div>
          </li>
        </ul>
      </div>
    </main>
  </div>
</template>

<script>
import applist from '~/assets/publishing/shop-menu-app.js'
export default {
  layout:'sub',
  components: {
    //탐색
    'MS-CTT_070': () => import('~/pages/pre-contract/popup/'),
    // 'MS-DIS_053': () => import('~/components/page/vehicles/popup/DeliverySelect'),


    // //결제
    // 'MS-PAY_001': () => import('~/components/page/payment/popup/'),


  },
  data() {
    return {
      headingTitle: 'POPUP LIST (팝업 모음)',
      alist: applist
    }
  },
  mounted() {},
  methods: {
    setname(val) {
      return Object.keys(val)[Object.keys(val).length - 1]
    }
  }
}
</script>

<style lang="scss">
.popup-list-index {
  > header > h1 {
    padding: 20px;
  }
  .popup-list-category-box {
    padding: 0 20px;
    h2 {
      padding: 10px 0;
    }
    .popup-view-list {
      > li {
        .popup-true-li {
          padding: 20px;
          border-bottom: 1px solid #ddd;
          > button {
            display: block;
            width: 100%;
            text-align: left;
          }
        }
      }
    }
  }
}
</style>
