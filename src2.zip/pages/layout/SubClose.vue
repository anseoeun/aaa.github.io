<template>
  <div class="content-wrap">
    <div class="content">
      <h1>Close button style sample page</h1>
      <v-pagination :total="100"></v-pagination>
    </div>
  </div>
</template>

<script>
export default {
  layout: 'full',
  data() {
    return {
      pageTitle: 'Title',
    }
  },
}
</script>
