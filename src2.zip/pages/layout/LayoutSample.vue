<template>
  <div class="content-wrap">
    <div class="content">
      <h1>Main Sample Page</h1>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      pageTitle: 'Casper',
    }
  },
}
</script>
