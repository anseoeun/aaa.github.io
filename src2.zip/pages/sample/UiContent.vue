<template>
  <div class="content samplePage">

    <v-btn type="nlink" to="./UiText" class="btn md white r">UiText (텍스트)</v-btn>
    <br /><br />
    <v-btn type="nlink" to="./UiHeaderText" class="btn md white r">UiHeaderText (헤더 텍스트)</v-btn>
    <br /><br />
    <v-btn type="nlink" to="./UiList" class="btn md white r">UiList (리스트형)</v-btn>
    <br /><br />
    <v-btn type="nlink" to="./UiGridlist" class="btn md white r">UiGridlist (그리드 리스트)</v-btn>
    <br /><br />
    <v-btn type="nlink" to="./UiGridlistForm" class="btn md white r">UiGridlistForm (그리드 리스트 폼)</v-btn>
    <br /><br />
    <v-btn type="nlink" to="./UiContbox" class="btn md white r">UiContbox (타이틀 컨텐츠매칭 박스형컨텐츠)</v-btn>
    <br /><br />
    <v-btn type="nlink" to="./UiEtc" class="btn md white r">UiEtc (기타)</v-btn>
    <br /><br />
    <v-btn type="nlink" to="./UiBtm" class="btn md white r">UiBtm (하단 버튼, 레이어)</v-btn>
    <br /><br />
    <v-btn type="nlink" to="./UiSlider" class="btn md white r">UiSlider (슬라이더)</v-btn>
    <br /><br />
    <v-btn type="nlink" to="./UiIcon" class="btn md white r">UiIcon (아이콘)</v-btn>
    <br /><br />
    <v-btn type="nlink" to="./UiToggle" class="btn md white r">UiToggle (토글리스트)</v-btn>
    <br /><br />


  </div>
</template>

<script>
import { VBtn} from '~/components/element'
export default {
  layout: 'sub',
  components: {
    VBtn,
  },
  data() {
    return {

    }
  },
}
</script>
