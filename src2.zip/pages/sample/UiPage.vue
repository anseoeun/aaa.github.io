<template>
  <div class="content samplePage">
    <h2>페이지</h2>
      <v-pagination :total="100"></v-pagination>

    <h2>더보기</h2>
      <v-page-more></v-page-more>
  </div>
</template>

<script>
export default {
  layout: 'sub',
}
</script>