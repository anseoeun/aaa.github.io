<template>
  <div class="content samplePage">
    <h2>케이스1</h2>
        <!-- 폼리스트 -->
        <div class="matching-box border-line">
          <div class="box-wrap">
            <div class="box-tit">주계약자 정보</div>
            <div class="box-desc">
              <!-- 폼리스트 -->
              <el-form ref="form" :rules="rules">
                <div class="form-grid-list line">
                  <ul>
                    <li>
                      <div class="form-label">성명</div>
                      <div class="form-group">
                        <div class="label-input">
                          <label class="offscreen">성명</label>
                          <v-input v-model="userName" :disabled="true" />
                        </div>
                      </div>
                    </li>
                    <li>
                      <div class="form-label">주민등록번호</div>
                      <div class="form-group">
                        <el-form-item prop="socialNmber2">
                          <div class="label-input">
                            <label class="offscreen">주민등록 앞자리</label>
                            <v-input v-model="socialNmber1" maxlength="6" :disabled="true" />
                          </div>
                          <div class="label-input">
                            <label class="offscreen">주민등록 뒷자리</label>
                            <v-input v-model="socialNmber2" type="number" maxlength="7" placeholder="7자리" />
                          </div>
                          <span class="result"><i class="icon-check"></i> <i class="icon-x"></i></span>
                        </el-form-item>
                      </div>
                    </li>
                    <li>
                      <div class="form-label">휴대전화</div>
                      <div class="form-group">
                        <el-form-item prop="phoneNumber">
                          <div class="label-input">
                            <label class="offscreen">휴대전화</label>
                            <v-input v-model="phoneNumber" type="number" placeholder="-없이 입력하세요." />
                          </div>
                        </el-form-item>
                      </div>
                    </li>
                    <li>
                      <div class="form-label">이메일</div>
                      <div class="form-group">
                        <el-form-item prop="email" class="email-wrap">
                          <div class="label-input">
                            <label class="offscreen">이메일 주소</label>
                            <v-input v-model="emailAddress" type="text" placeholder="이메일 주소" />
                          </div>
                          <span class="at">@</span>
                          <div class="label-input">
                            <label class="offscreen">이메일 제공자</label>
                            <v-input
                              v-model="emailProvider"
                              type="text"
                              :disabled="mailSelected == '' ? false : true"
                              :value="mailSelected == '직접입력' ? '' : mailSelected"

                            />
                          </div>
                          <div class="select">
                            <v-select v-model="mailSelected" :data="mailList" placeholder="선택" />
                          </div>
                          </el-form-item>
                      </div>
                    </li>
                  </ul>
                </div>
              </el-form>
              <!-- // 폼리스트 -->
            </div>
          </div>
        </div>
        <!-- // 폼리스트 -->

    <br /><br />
  </div>
</template>

<script>
export default {
  layout:'sub',
  components: {},
  data() {
    return {
      contractorForm: {
        userName: '김현대',
        socialNmber1: '910320',
        socialNmber2: '',
        phoneNumber: '',
        emailAddress: '',
        emailProvider: '',
        mailSelected: '',
      },
    }
  },
}
</script>
