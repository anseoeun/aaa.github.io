<template>
  <div class="content samplePage">
    <h2>탭 스크롤형 (scroll-tab)</h2>
      <v-tab v-scrolltab class="tab-sub scroll-tab" :data="tabList" :contents="true">
        <template slot="contents">
          <div style="border: 1px solid #000" data-id="tab1">tab1</div>
          <div style="border: 1px solid #000" data-id="tab2">tab2</div>
          <div style="border: 1px solid #000" data-id="tab3">tab3</div>
        </template>
      </v-tab>
    <br />

    <h2>탭 라인(tab-line), 초기 컨텐츠숨김형</h2>
    <v-tab class="tab-line" :data="tabList2" :contents="true" :init="true">
      <template slot="contents">
        <div style="border: 1px solid #000" data-id="tab1">tab1</div>
        <div style="border: 1px solid #000" data-id="tab2">tab2</div>
      </template>
    </v-tab>
    <br />

    <h2>탭 기본(tab-default)</h2>
      <v-tab class="tab-default" :data="tabList" :contents="true" value="tab2">
        <template slot="contents">
          <div style="border: 1px solid #000" data-id="tab1">tab1</div>
          <div style="border: 1px solid #000" data-id="tab2">tab2</div>
          <div style="border: 1px solid #000" data-id="tab3">tab3</div>
        </template>
      </v-tab>
    <br />

    <h2>탭 기본 html형 (tab-default)</h2>
      <v-tab class="tab-default" :data="tabList" :contents="true" :custom-label="true">
        <template slot="label" slot-scope="props">
          {{ props.item.label }}
          <span v-html="props.item.html"></span>
        </template>
        <template slot="contents">
          <div style="border: 1px solid #000" data-id="tab1">tab1</div>
          <div style="border: 1px solid #000" data-id="tab2">tab2</div>
          <div style="border: 1px solid #000" data-id="tab3">tab3</div>
        </template>
      </v-tab>
    <br />

    <h2>탭 서브형 (tab-sub)</h2>
      <v-tab class="tab-sub" :data="tabList" :contents="true">
        <template slot="contents">
          <div style="border: 1px solid #000" data-id="tab1">tab1</div>
          <div style="border: 1px solid #000" data-id="tab2">tab2</div>
          <div style="border: 1px solid #000" data-id="tab3">tab3</div>
        </template>
      </v-tab>
  </div>
</template>

<script>
export default {
  layout: 'sub',
  components: {

  },
  data() {
    return {
      tabList: [
        { value: 'tab1', label: '탭탭탭1', html:'내용내용 <br/> 내용내용' },
        { value: 'tab2', label: '탭탭탭탭탭탭탭2', html:'내용내용2 <br/> 내용내용' },
        { value: 'tab3', label: '탭탭탭탭탭탭탭3', html:'내용내용3 <br/> 내용내용'},
      ],
      tabList2: [
        { value: 'tab1', label: '신용카드'},
        { value: 'tab2', label: '무통장입금'},
      ],
    }
  },
}
</script>
