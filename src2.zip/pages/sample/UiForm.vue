<template>
  <div class="content samplePage">
    <h2>Input</h2>
    <v-input v-model="inputVal" />

    <h2>Textarea</h2>
    <v-input v-model="textareaVal" type="textarea" :rows="5" placeholder="상담내용을 입력하여 주세요(최대 2,000자)" />

    <h2>Select</h2>
    <v-select
      v-model="selectListVal"
      :data="selectList"
    />
    <v-select
      v-model="selectListVal"
      :data="selectList"
      class="w-auto"
    />
  </div>
</template>

<script>
import { VInput, VSelect } from '~/components/element'
export default {
  layout: 'sub',
  components: {
    VInput,
    VSelect,
  },
  data() {
    return {
      // 인풋
      inputVal: null,
      // textarea
      textareaVal: null,
      // 셀렉트
      selectListVal: '',
      selectList: [
        { value: '', label: 'Select' },
        { value: 'select1', label: 'SKT' },
        { value: 'select2', label: 'KT' },
        { value: 'select3', label: 'LGU+' },
        { value: 'select4', label: '알뜰폰 SKT' },
        { value: 'select5', label: '알뜰폰 KT' },
        { value: 'select6', label: '알뜰폰 LGU+ 알뜰폰 LGU+' },
      ],
    }
  },
  methods: {

  },
}
</script>
