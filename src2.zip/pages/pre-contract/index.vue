<template>
  <div class="content-wrap">
    <div class="content precontract precontract-wrap">
      <div v-if="mainIndex" class="precontract-visual">
        <contract-visual @click="changeIndex"></contract-visual>
      </div>
      <div v-else class="precontract-contents">
        <v-pageheader
          page-title="캐스퍼 사전계약"
        >
          <div class="term">사전계약기간 : {{ precontractTerm }}</div>
        </v-pageheader>
        <div class="precontract-option">
          <div class="car-visual">
              <v-img :src="carImg" alt="자동차 이미지"></v-img>
              <p class="caption">* 홈페이지 상에 사용된 이미지는 실제 적용 사양과 상이할 수 있습니다.</p>
          </div>
          <apply-form></apply-form>
        </div>
      </div>
      <popup :visible.sync="popupVisible" @visibleSync="popupSync" />
    </div>
    <div v-if="!mainIndex" class="fixed-btm-area">
      <div v-btmlayer class="btm-layer">
        <div class="tog-btn">
          <v-btn class="btn"><span class="offscreen">열기</span></v-btn>
        </div>
        <div class="layer-content">
          <div class="precontract-account hide">
            <div class="info-box">
              <div class="car-name">AX 자가용 5인승 가솔린 1.6 2WD IVT Smart </div>
              <div class="car-name t-gray">선택한 차량이 없습니다.</div>
              <div class="info-grid-list">
                <ul>
                  <li>
                    <div class="info-title">사양급</div>
                    <div class="info-group">디자인플러스</div>
                  </li>
                  <li>
                    <div class="info-title">선택품목</div>
                    <div class="info-group">빌트인캠(보조배터리 포함), 썬루프, 컴포트, 현대스마트센스</div>
                  </li>
                  <li>
                    <div class="info-title">외장색상</div>
                    <div class="info-group">쉬머링실버</div>
                  </li>
                  <li>
                    <div class="info-title">내장색상</div>
                    <div class="info-group">스톤그레이</div>
                  </li>
                </ul>
              </div>
            </div>
            <div class="account-box">
              <div class="account">
                계약금 <b>100,000</b> <span class="unit">원</span>
              </div>
              <p class="bullet-star">마이페이지에서 계약 취소 가능하며, 취소시 계약금은 환불됩니다.</p>
            </div>
          </div>
        </div>
      </div>
      <div class="fixed-btn">
        <v-btn type="nlink" to="/" class="btn blue">사전계약하기</v-btn>
      </div>
    </div>
  </div>
</template>

<script>
import ApplyForm from '~/components/page/pre-contract/ApplyForm'
import ContractVisual from '~/components/page/pre-contract/ContractVisual'
import Popup from '~/pages/pre-contract/popup/'

export default {
  head() {
    return {
      title: '사전계약 > 소개',
    }
  },
  layout:'sub',
  components: {
    ContractVisual,
    ApplyForm,
    Popup
  },
  data(){
    return{
      pageTitle: '사전계약',
      precontractTerm: '2021.01.31 ~ 2021.03.30',
      mainIndex: true,
      carImg: require('~/assets/images/temp/temp-precontact-car-visual.png'),
      popupVisible: {
        precontrctPop: false,
      }
    }
  },
  mounted() {

  },
  methods: {
    changeIndex(value) {
      this.mainIndex = value
      this.popupVisible.precontrctPop = true
    },
    popupSync(e) {
      this.popupVisible = e
    }
  }
}
</script>
