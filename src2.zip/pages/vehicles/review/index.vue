<template>
  <div class="content-wrap">
    <div class="content vehicles vehicles-review">
      <div class="vehicles-review-wrap">
          <!-- total-satisfy -->
        <div class="total-satisfy">
          <div class="rate-satisfy">
            <p class="txt"><b>총 만족도</b> ( {{ satisfy.personNum }}명 )</p>
            <div class="grade-wrap">
              <div class="grade-gage"><div class="bar" :style="`width:${satisfy.gage}%`"></div></div>
              <div class="grade">{{ satisfy.grade }}</div>
            </div>
            <v-btn class="btn-more" @click="popupVisible.satisfaction = true">자세히 보기</v-btn>
          </div>
          <div class="detail-satisfy">
            <ul>
              <li v-for="(item, index) in satisfy.detail" :key="index">
                <span class="flag">{{ item.label }}</span>
                <p class="txt">{{ item.review }}</p>
                <div class="per"><b>{{ item.per }}</b>%</div>
              </li>
            </ul>
          </div>
          <!-- // total-satisfy -->
          <div class="btn-wrap full">
            <v-btn class="btn md blue" type="button">구매후기 작성</v-btn>
          </div>
        </div>
        <div class="search-class border-line">
          <div class="select-wrap">
            <v-select
              v-model="enginVal"
              :data="enginList"
            />
            <v-select
              v-model="trimVal"
              :data="trimList"
            />
          </div>
          <div class="btn-wrap full">
            <v-btn class="btn md gray">초기화</v-btn>
            <v-btn type="submit" class="btn md blue">검색</v-btn>
          </div>
        </div>
        <!-- list-board -->
        <div class="buying-review-list">
          <div class="top-noti-info">
            <div class="left">
              <v-select
                v-model="alignVal"
                :data="alignList"
                class="select-radius"
              />
            </div>
            <div class="right inbl-wrap">
              <v-checkbox :one-check="true"
                :checked.sync="photoReviewVal"
                class="sm-size"
                >포토후기</v-checkbox>
            </div>
          </div>
          <template v-if="buyReviewList.length > 0">
            <ul>
              <li v-for="(item, index) in buyReviewList" :key="index">
                <div class="review-box">
                  <div class="desc">
                    <div class="title-wrap">
                      <div class="title">{{ item.title }}</div>
                      <v-rate v-model="item.grade" class="grade-check xs-size view"></v-rate>
                      <div class="date">
                      {{ item.contractDate }} {{ item.user }}
                      </div>
                    </div>
                    <div class="img"><v-img :src="item.carImg.src" :alt="item.carImg.alt"></v-img></div>
                    <v-btn class="btn-tog" @click="item.detailOpen = !item.detailOpen">
                      <i class="icon-toggle-arr black sm-size" :class="{'on':item.detailOpen}"></i>
                    </v-btn>
                  </div>
                  <div v-if="item.detailOpen" class="detail">
                    <ul class="review-list">
                      <li v-for="(list, idx) in item.reviews" :key="idx">
                        <span class="flag">{{ list.label }}</span> <span class="txt">{{ list.review }}</span>
                      </li>
                    </ul>
                    <!-- 사진 -->
                    <div class="upload-view-list-wrap">
                      <v-btn v-for="(photo, i) in item.fileList" :key="i" class="photo" @click="popupVisible.photoDetail = true">
                        <v-img :src="photo.src" :alt="photo.alt"></v-img>
                      </v-btn>
                    </div>
                    <div class="review" :class="{on: item.reviewOpen}">
                      <v-btn type="link" href="javascript:void(0);" @click="item.reviewOpen = true">
                        <div class="review-text">{{ item.review }}</div>
                        <span v-if="!item.reviewOpen" class="btn-more">더보기</span>
                      </v-btn>
                      <v-btn v-if="item.reviewOpen" class="btn-review-close" @click="item.reviewOpen = false">닫기 -</v-btn>
                    </div>
                    <div class="etc-menus">
                      <div class="menu">
                        <div class="btn">
                          <v-btn class="btn-more">구매 정보 상세보기</v-btn>
                        </div>
                        <div class="btn">
                          <v-btn class="btn-more">동일사양 견적내기</v-btn>
                        </div>
                      </div>
                      <div class="menu">
                        <span class="good"> <p class="txt">도움이 되었어요</p>
                           <span class="up"><i class="icon-up"></i><span class="num">75</span></span>
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </li>
            </ul>
          </template>
          <template v-else>
            <div class="list-null">
              <i class="icon-doc-none"></i>
              <p>구매 내역이 없습니다.</p>
            </div>
          </template>
        </div>
        <div v-if="buyReviewList.length <= 0" class="btn-box t-right">
          <v-btn class="btn md white r" type="nlink">구매후기 보러가기</v-btn>
        </div>
        <!-- 안내사항 -->
        <div class="match-box">
          <div class="title">아래 사항에 해당하는 경우 통보없이 게시글이 삭제될 수 있습니다.</div>
          <div class="desc">
            <ul class="bullet-list">
              <li>차량과 무관한 내용</li>
              <li>명예훼손성, 모욕성 게시글</li>
              <li>그 외 욕설, 비방글 등 본 게시판 목적에 부적절한 게시글</li>
            </ul>
          </div>
        </div>
        <!-- // 안내사항 -->
      </div>
      <!-- <photo-detail :visible="popupVisible.photoDetail" @close="popupVisible.photoDetail = false" /> -->
    </div>
    <!-- 포토상세 -->
    <photo-detail :visible="popupVisible.photoDetail" @close="popupVisible.photoDetail = false" />
  </div>
</template>

<script>
import { VBtn } from '~/components/element'
import PhotoDetail from '~/components/page/review/Detail'
// import Satisfaction from '~/components/page/review/Satisfaction'
export default {
  head() {
    return {
      title: '탐색 > 구매후기',
    }
  },
  components: {
    VBtn,
    PhotoDetail,
    // Satisfaction
  },
  layout: 'sub',
  data() {
    return {
      pageTitle: '구매후기',
      satisfy: {
        personNum: '12',
        grade: 4.6,
        gage: 90,
        detail: [
            {label: '구매과정', review: '생각보다 쉬워요', per:'92'},
            {label: '가성비', review: '예정된 날짜에 받았어요', per:'90'},
            {label: '디자인', review: '화면처럼 맘에 들어요', per:'95'},
            {label: '승차감', review: '굿이에요', per:'85'},
        ]
      },
      photoReviewVal: false,
      enginVal: 'enginselect0',
      enginList: [
        { value: 'enginselect0', label: '엔진전체' },
        { value: 'enginselect1', label: '엔진선택1' },
        { value: 'enginselect2', label: '엔진선택2' },
        { value: 'enginselect3', label: '엔진선택3' },
      ],
      trimVal: 'trimselect0',
      trimList: [
        { value: 'trimselect0', label: '트림전체' },
        { value: 'trimselect1', label: '트림선택1' },
        { value: 'trimselect2', label: '트림선택2' },
        { value: 'trimselect3', label: '트림선택3' },
      ],
      alignVal: 'alignselect0',
      alignList: [
        { value: 'alignselect1', label: '최신순' },
        { value: 'alignselect2', label: '평점높은순' },
        { value: 'alignselect3', label: '평점낮은순' },
      ],
      isView: false,
      listSelected:'',
      buyReviewList: [
        {
          carImg: {
            src: require('~/assets/images/temp/temp-review-car.png'),
            alt: '쏘나타 센슈어스(가솔린 1.6T) Premium (자가용 스마트스트림 가솔린 1.6 터보)',
          },
          title:'쏘나타 센슈어스(가솔린 1.6T) Premium (자가용 스마트스트림 가솔린 1.6 터보)',
          grade: 3,
          gage: 70,
          review: '후기내용 최대 2줄 까지 표시가 됩니다.후기내용 최대 2줄 까지 표시가 됩니다.후기내용 최대 2줄 까후기내용 최대 2줄 까지 표시가 됩니다.후기내용 최대 2줄 까지 표시가 됩니다.후기내용 최대 2줄 까지 표시가 됩니다.후기내용 최대 2줄 까지 표시가 됩니다.후기내용 최대 2줄 까후기내용 최대 2줄 까지 표시가 됩니다.후기내용 최대 2줄 까지 표시가 됩니다후기내용 최대 2줄 까지 표시가 됩니다.후기내용 최대 2줄 까지 표시가 됩니다.후기내용 최대 2줄 까후기내용 최대 2줄 까지 표시가 됩니다.후기내용 최대 2줄 까지 표시가 됩니다후기내용 최대 2줄 까지 표시가 됩니다.후기내용 최대 2줄 까지 표시가 됩니다.후기내용 최대 2줄 까후기내용 최대 2줄 까지 표시가 됩니다.후기내용 최대 2줄 까지 표시가 됩니다',
          contractDate: '2021.10.30',
          user: '(30대,남성)',
          detailOpen: false,
          reviewOpen: false,
          reviews: [
            {label: '구매과정', review: '생각보다 쉬워요'},
            {label: '가성비', review: '예정된 날짜에 받았어요'},
            {label: '디자인', review: '화면처럼 맘에 들어요'},
            {label: '승차감', review: '굿이에요'},
          ],
          // 사진 슬라이드
          fileList: [
            {
              src: require('~/assets/images/temp/temp-review-car.png'),
              alt: 'AX 센슈어스(가솔린 1.6T) Premium (자가용 스마트스트림 가솔린 1.6 터보',
            },
            {
              src: require('~/assets/images/temp/temp-review-car.png'),
              alt: 'AX 센슈어스(가솔린 1.6T) Premium (자가용 스마트스트림 가솔린 1.6 터보',
            },
            {
              src: require('~/assets/images/temp/temp-review-car.png'),
              alt: 'AX 센슈어스(가솔린 1.6T) Premium (자가용 스마트스트림 가솔린 1.6 터보',
            },
            {
              src: require('~/assets/images/temp/temp-review-car.png'),
              alt: 'AX 센슈어스(가솔린 1.6T) Premium (자가용 스마트스트림 가솔린 1.6 터보',
            },
            {
              src: require('~/assets/images/temp/temp-review-car.png'),
              alt: 'AX 센슈어스(가솔린 1.6T) Premium (자가용 스마트스트림 가솔린 1.6 터보',
            },
            {
              src: require('~/assets/images/temp/temp-review-car.png'),
              alt: 'AX 센슈어스(가솔린 1.6T) Premium (자가용 스마트스트림 가솔린 1.6 터보',
            }
          ],
        },
        {
          carImg: {
            src: require('~/assets/images/temp/temp-review-car.png'),
            alt: '쏘나타 센슈어스(가솔린 1.6T) Premium (자가용 스마트스트림 가솔린 1.6 터보)',
          },
          title:'쏘나타 센슈어스(가솔린 1.6T) Premium (자가용 스마트스트림 가솔린 1.6 터보)',
          grade: 1,
          gage: 85,
          review: '후기내용 최대 2줄 까지 표시가 됩니다.후기내용 최대 2줄 까지 표시가 됩니다.후기내용 최대 2줄 까후기내용 최대 2줄 까지 표시가 됩니다.후기내용 최대 2줄 까지 표시가 됩니다.후기내용 최대 2줄 까지 표시가 됩니다.후기내용 최대 2줄 까지 표시가 됩니다.후기내용 최대 2줄 까후기내용 최대 2줄 까지 표시가 됩니다.후기내용 최대 2줄 까지 표시가 됩니다후기내용 최대 2줄 까지 표시가 됩니다.후기내용 최대 2줄 까지 표시가 됩니다.후기내용 최대 2줄 까후기내용 최대 2줄 까지 표시가 됩니다.후기내용 최대 2줄 까지 표시가 됩니다후기내용 최대 2줄 까지 표시가 됩니다.후기내용 최대 2줄 까지 표시가 됩니다.후기내용 최대 2줄 까후기내용 최대 2줄 까지 표시가 됩니다.후기내용 최대 2줄 까지 표시가 됩니다',
          contractDate: '2021.10.30',
          user: '(30대,남성)',
          reviewOpen: false,
          reviews: [
            {label: '구매과정', review: '생각보다 쉬워요'},
            {label: '가성비', review: '예정된 날짜에 받았어요'},
            {label: '디자인', review: '화면처럼 맘에 들어요'},
            {label: '승차감', review: '굿이에요'},
          ],
          // 사진 슬라이드
          fileList: [
            {
              src: require('~/assets/images/temp/temp-review-car.png'),
              alt: 'AX 센슈어스(가솔린 1.6T) Premium (자가용 스마트스트림 가솔린 1.6 터보',
            },
            {
              src: require('~/assets/images/temp/temp-review-car.png'),
              alt: 'AX 센슈어스(가솔린 1.6T) Premium (자가용 스마트스트림 가솔린 1.6 터보',
            },
            {
              src: require('~/assets/images/temp/temp-review-car.png'),
              alt: 'AX 센슈어스(가솔린 1.6T) Premium (자가용 스마트스트림 가솔린 1.6 터보',
            },
            {
              src: require('~/assets/images/temp/temp-review-car.png'),
              alt: 'AX 센슈어스(가솔린 1.6T) Premium (자가용 스마트스트림 가솔린 1.6 터보',
            },
            {
              src: require('~/assets/images/temp/temp-review-car.png'),
              alt: 'AX 센슈어스(가솔린 1.6T) Premium (자가용 스마트스트림 가솔린 1.6 터보',
            },
          ],
        },
      ],
      popupVisible: {
        photoDetail: false,
        satisfaction: false,
      }
    }
  },
  methods:{

  }
}
</script>
