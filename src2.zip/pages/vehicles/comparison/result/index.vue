<template>
  <div class="comparision-model-result">
    <!-- 성능 제원 -->
    <perfomance-detail />
    <!-- 경제성/환경 -->
    <economic-detail />
    <!-- 충돌/안전 -->
    <safety-detail />
    <!-- 기본품목 -->
    <spec-detail />
    <!-- 구입비용 -->
    <price-detail />
  </div>
</template>

<script>
import PerfomanceDetail from '~/components/page/vehicles/comparison/PerfomanceDetail'
import EconomicDetail from '~/components/page/vehicles/comparison/EconomicDetail'
import SafetyDetail from '~/components/page/vehicles/comparison/SafetyDetail'
import SpecDetail from '~/components/page/vehicles/comparison/SpecDetail'
import PriceDetail from '~/components/page/vehicles/comparison/PriceDetail'
export default {
  components: {
    PerfomanceDetail,
    EconomicDetail,
    SafetyDetail,
    SpecDetail,
    PriceDetail,
  },
  data() {
    return {

    }
  },
  methods: {}
}
</script>
