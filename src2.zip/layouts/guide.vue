<template>
  <Nuxt />
</template>

<script>
export default {
  head() {
    return {
      title: 'AX APP PUBLISHING',
    }
  },
}
</script>

<style lang="scss">
@import '~/assets/style/guide/guide.scss';
</style>
