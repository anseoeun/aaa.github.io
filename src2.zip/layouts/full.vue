<template>
  <article class="wrap">
    <header-full />
    <main class="container">
      <Nuxt />
    </main>
  </article>
</template>

<script>
import HeaderFull from '~/components/layout/HeaderFull'
export default {
  head() {
    return {
      meta: [
        {
          hid: 'keywords',
          name: 'keywords',
          content: ''
        },
        {
          hid: 'description',
          name: 'description',
          content: ''
        },
        {
          hid: 'author',
          name: 'author',
          content: ''
        },
        {
          property: 'og:type',
          content: ''
        },
        {
          property: 'og:title',
          content: ''
        },
        {
          property: 'og:description',
          content: ''
        },
        {
          property: 'og:image',
          content: ''
        },
        {
          property: 'og:url',
          content: ''
        },
      ],
    }
  },
  components: {
    HeaderFull,
  },
}
</script>

<style lang="scss">
@import '~/assets/style/shop.scss';
</style>
