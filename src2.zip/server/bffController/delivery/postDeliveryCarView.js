const asyncHandler = require('../../utils/asyncHandler')
const Https = require('../../utils/https')

// API-E-상품서비스-048 (즉시출고차 차량상세 조회)
async function getDeliveryCarView(req, $httpsEvent) {
  try {
    const response = await $httpsEvent.get('/recommendation/similar-car-detail', { params: { ...req.body } })
    return response
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}


// API-E-상품서비스-048 (즉시출고차 차량상세 조회)
async function getDiscountProductMainView(req, $httpsEvent, $httpsPur, $httpsDelAll, $httpsCommon, $httpsPurchase) {
  try {
    const {
      saleModelCode,
      optionMixCode,
      exteriorColorCode,
      interiorColorCode,
      deliveryCenterCode,
      deliveryLocalAreaCode,
      productionCarNumber,
      contractCarTypeCode
    } = req.body
    const params = {
      saleModelCode,
      optionMixCode,
      exteriorColorCode,
      interiorColorCode,
      deliveryCenterCode,
      productionCarNumber,
      deliveryLocalAreaCode,
      contractCarTypeCode
    }

    const response = (await $httpsEvent.get('/recommendation/similar-car-detail', { params }))
    console.log('/recommendation/similar-car-detail')
    console.log(params)
    console.log(response.data)
    const resParam = {
      ...(response.data.data.discountCarInfo)
    }

    const [response2, response3, response4, response5, response6, response7, response8, response9] = await Promise.all([
      getRelCenterList(resParam.deliveryCenterCode, $httpsPur),
      getCarTrimSpeInfo(resParam.saleModelCode, $httpsEvent),

      getAreaConsignmentList(resParam, req, $httpsDelAll),
      getEstimationInfoName(resParam, $httpsEvent),
      getDisCarRecInfoList(resParam, req, $httpsEvent),
      getBranchOffView('J01', $httpsPur),
      getContractPossible(resParam, $httpsPurchase),
      getAgencyView($httpsCommon)
    ])
    
    response.data.data.relCenterList = response2.data // ok
    response.data.data.carTrimSpeInfo = response3.data // ok

    response.data.data.areaConsignmentList = response4.data // ?
    response.data.data.estimationInfoName = response5.data // ok
    response.data.data.disCarRecInfoList = response6.data // ok

    response.data.data.branchOffView = response7.data // ?
    response.data.data.contractPossible = response8.data // ?
    response.data.data.tempData = {
      test1: { ...response2.data },
      test2: { ...response7.data },
      test3: { ...response9.data.data }
    }
    return response
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}
// 생산차량, 출고차량
// 할인차량도 같이 나온다

// API-E-상품서비스-008_작업중 (할인, 전시차량 재고 정보 조회)
async function getDiscountProductStockCount(req, $httpsEvent) {
  try {
    const {
      saleModelCode,
      optionMixCode,
      exteriorColorCode,
      interiorColorCode,
      deliveryCenterCode,
      deliveryLocalAreaCode,
      productionCarNumber,
      contractCarTypeCode
    } = req.body
    const params = {
      saleModelCode,
      optionMixCode,
      exteriorColorCode,
      interiorColorCode,
      deliveryCenterCode,
      productionCarNumber,
      deliveryLocalAreaCode,
      contractCarTypeCode
    }

    const res = (await $httpsEvent.get('/recommendation/similar-car-detail', { params }))
    // console.log(res.data.discountCarInfo && res.data.discountCarInfo.carProductionNumber ? res.data.discountCarInfo.carProductionNumber : '-')
    req.body.carProductionNumber = res.data.discountCarInfo && res.data.discountCarInfo.carProductionNumber ? res.data.discountCarInfo.carProductionNumber : productionCarNumber
    const {
      criterionYearMonth,
      carProductionNumber
    } = req.body
    const response = await $httpsEvent.get('/discount-car/inventory', { params: {
      criterionYearMonth,
      carProductionNumber
    } })
    // const response = await $httpsEvent.get('/discount-car/inventory', { params: { ...req.body } })

    return response
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}

// API-E-상품서비스-010 (전시차량 차량상세 정보 조회)
async function getExhibitionProductMainView(req, $httpsEvent, $httpsPur, $httpsDelAll, $httpsCommon, $httpsPurchase) {
  try {
    const _req = { ...req }
    _req.body = {
      carProductNumber: req.body.productionCarNumber && req.body.productionCarNumber.length == 0 ? null : req.body.productionCarNumber,
      criterionYearMonth: req.body.criterionYearMonth,
      loginId: req.body.loginId
    }

    const response = await $httpsEvent.get('/recommendation/similar-car-detail', { params: { ...req.body } })
    const resParam = {
      ...response.data.data.discountCarInfo
    }

    const [response2, response3, response4, response5, response6, response7, response8, response9] = await Promise.all([
      getRelCenterList(resParam.deliveryCenterCode, $httpsPur),
      getCarTrimSpeInfo(resParam.saleModelCode, $httpsEvent),

      getAreaConsignmentList(resParam, req, $httpsDelAll),
      getEstimationInfoName(resParam, $httpsEvent),
      getDisCarRecInfoList(resParam, req, $httpsEvent),
      getBranchOffView(resParam.agencyCode, $httpsPur),
      getAgencyView($httpsCommon),
      getContractPossible(resParam, $httpsPurchase)
    ])

    const discountCarInfo = (response.data.data.discountCarInfo)
    let resp = {
      data: {
        data: {
          discountCarInfo: {
            ...discountCarInfo
          },
          discountPriceInfo: {
            ...discountCarInfo ? discountCarInfo.discountPriceInfo : {}
          },
          relCenterList: {
            data: {
              deliveryCenterName:
                response7.data && response7.data.data.agency
                  ? response7.data.data.agency.agencyName + ' ' + response7.data.data.agency.agencyTypeName
                  : '',
              deliveryCenterTel:
                response7.data && response7.data.data.agency ? response7.data.data.agency.agencyTel : '',
              deliveryCenterAddress:
                response7.data && response7.data.data.agency
                  ? response7.data.data.agency.agencyAddress1 + response7.data.data.agency.agencyAddress2
                  : '',
              deliveryCenterOpTime:
                '평일 ' +
                response8.data.data[0].chrrName1.substr(0, 2) +
                ':' +
                response8.data.data[0].chrrName1.substr(2, 3) +
                ' ~ ' +
                response8.data.data[0].chrrName2.substr(0, 2) +
                ':' +
                response8.data.data[0].chrrName2.substr(2, 3),
              lat:
                response7.data && response7.data.data && response7.data.data.agency
                  ? response7.data.data.agency.lattitude
                  : 33,
              lon:
                response7.data && response7.data.data && response7.data.data.agency
                  ? response7.data.data.agency.longitude
                  : 125
            }
          },
          carTrimSpeInfo: {
            ...response3.data
          },
          areaConsignmentList: {
            ...response4.data
          },
          estimationInfoName: {
            ...response5.data
          },
          disCarRecInfoList: {
            ...response6.data
          },
          contractPossible: {
            ...response9.data
          },
          tempData: {
            test1: { ...response2.data },
            test2: { ...response7.data },
            test3: { ...response8.data }
          }
        }
      }
    }

    console.log(resp)
    return resp
  } catch (err) {
    console.error(err)
    return {
      message: err.message,
      config: err.config
    }
  }
}

// API-H-상품서비스-079 (차량 트림 제원 정보 조회)
async function getCarTrimSpeInfo(saleModelCode, $httpsEvent) {
  try {
    const response = await $httpsEvent.get('/car/trim-variousfactor/' + saleModelCode)
    return response
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}

// API-H-제휴서비스-005 (탁송료 및 출고센터 조회)
async function getAreaConsignmentList(list, req, $httpsDelAll) {
  try {
    const _list = list
    _list.query = {
      saleModelCode: list.saleModelCode ? list.saleModelCode : '',
      deliveryAreaCode: req.body.deliveryAreaCode ? req.body.deliveryAreaCode : '',
      deliveryLocalAreaCode: req.body.deliveryLocalAreaCode ? req.body.deliveryLocalAreaCode : '',
      optionCode: list.optionMixCode ? list.optionMixCode : '',
      deliveryCenterCode: list.deliveryCenterCode ? list.deliveryCenterCode : ''
    }
    const response = await $httpsDelAll.get('/consignment-price', { params: { ..._list.query } })

    return response
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}

// API-H-상품서비스-059 (견적정보에 대한 코드명칭을 조회하는 API)
async function getEstimationInfoName(req, $httpsEvent) {
  try {
    const _req = { ...req }
    _req.query = {
      carCode: req.carCode ? req.carCode : '',
      saleModelCode: req.saleModelCode ? req.saleModelCode : '',
      optionMixCode: req.optionMixCode ? req.optionMixCode : '',
      exteriorColorCode: req.exteriorColorCode ? req.exteriorColorCode : '',
      interiorColorCode: req.interiorColorCode ? req.interiorColorCode : '',
      tuixMixCode: req.tuixMixCode ? req.tuixMixCode : '',
      saleTypeCode: req.saleTypeCode ? req.saleTypeCode : '',
      realityInteriorColorCode: req.realityInteriorColorCode ? req.realityInteriorColorCode : ''
    }
    // console.log(_req.query)

    const response = await $httpsEvent.get('/estimation-info-name', { params: { ..._req.query } })
    return response
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}

// API-H-고객지원서비스-015 (출고센터 상세조회)
async function getRelCenterList(dvcCd, $httpsPur) {
  try {
    const response = await $httpsPur.get('/delivery-center/' + dvcCd)
    // console.log(response)
    return response
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}

// API-H-고객지원서비스-010 (영업점 안내정보 상세조회)
async function getBranchOffView(agencyCode, $httpsPur) {
  try {
    const response = await $httpsPur.get('/agency/' + agencyCode)

    return response
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}

// 공통코드 조회(영업점시간)
async function getAgencyView($httpsCommon) {
  try {
    const response = await $httpsCommon.get('/common-code/E/T034')
    return response
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}

// API-H-상품서비스-081 (즉시 출고가능한 유사사양 차량 정보 조회)
async function getDisCarRecInfoList(param, req, $httpsEvent) {
  try {
    const _req = { ...param }
    _req.query = {
      saleModelCode: param.saleModelCode ? param.saleModelCode : '',
      exteriorColorCode: param.exteriorColorCode ? param.exteriorColorCode : '',
      interiorColorCode: param.interiorColorCode ? param.interiorColorCode : '',
      optionMixCode: param.optionMixCode ? param.optionMixCode : '',
      deliveryLocalAreaCode: param.deliveryLocalAreaCode ? param.deliveryLocalAreaCode : '',
    }
    // console.log('query>>>>>>>>>>>>>>>>>>>>>>')
    // console.log(_req.query)

    const response = await $httpsEvent.get('/recommendation/similar-car', { params: { ..._req.query } })
    // console.log(response)
    return response
  } catch (err) {
    console.log(err)
    return {
      message: err.message,
      config: err.config
    }
  }
}

//API-E-구매서비스-001 (계약가능 정보 조회)
async function getContractPossible(param, $httpsPurchase) {
  try {
    const _req = {
      siteTypeCode: 'E', //임직몰
      saleModelCode: param.saleModelCode,
      optionMixCode: param.optionMixCode,
      productionCarNumber: param.carProductionNumber
    }

    const response = await $httpsPurchase.get('/contract/possible/info', { params: { ..._req } })
    return response
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}

module.exports = asyncHandler(async (req, res, next) => {
  const $httpsEvent = Https({ service: 'product', version: 'v1', req })
  const $httpsPur = Https({ service: 'purchase-guide^customer-support', version: 'v1', req })
  const $httpsDelAll = Https({ service: 'delivery^alliance', version: 'v1', req })
  const $httpsCommon = Https({ service: 'common', version: 'v1', req })
  const $httpsPurchase = Https({ service: 'purchase', version: 'v1', req })

  const [
    // response0,
    response1,
    response2,
    response4,
  ] = await Promise.all([
    // getDeliveryCarView(req, $httpsEvent),
    getDiscountProductMainView(req, $httpsEvent, $httpsPur, $httpsDelAll, $httpsCommon, $httpsPurchase),
    getDiscountProductStockCount(req, $httpsEvent),
    getExhibitionProductMainView(req, $httpsEvent, $httpsPur, $httpsDelAll, $httpsCommon, $httpsPurchase),
  ])

  const responses = {
    screenId: '나중에바꿀ID',
    // dev: response0.data,
    api_e_product_007: response1.data,
    api_e_product_008: response2.data,
    api_e_product_010: response4.data,
  }

  res.json(responses)
})
