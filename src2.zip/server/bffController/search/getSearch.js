const asyncHandler = require('../../utils/asyncHandler')
const Https = require('../../utils/https')

// EP_IF_통합검색_003
module.exports = asyncHandler(async (req, res, next) => {
  const $https = Https({ service: 'search', req })
  const response = await $https.get('/sf-1/search/search.jsp', {
    params: { ...req.query }
  })

  res.json(response.data)
})
