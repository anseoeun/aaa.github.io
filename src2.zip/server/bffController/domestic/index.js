const { Router } = require('express')
const router = Router()
const asyncHandler = require('../../utils/asyncHandler')
const Https = require('../../utils/https')

// EP_IF_국내판매_054(가상계좌번호생성) EIS
const generateVbankNum = asyncHandler(async (req, res, next) => {
  const $https = Https({ service: 'domestic', req })
  const response = await $https.post('/sale/Eco?actionName=ListCommWork&cmd=R004', req.body)
  const { rspStatus, data } = response.data
  res.json({
    data: data.ds_List,
    rspStatus: {
      rspCode: rspStatus.rspCode ? (rspStatus.rspCode === '0' ? '0000' : rspStatus.rspCode) : '1000',
      rspMessage: rspStatus.rspMessage || 'I/F Server Error',
      uri: req.path
    }
  })
})

// EP_IF_국내판매_084(면세반출신고조회)
const reportHistory = asyncHandler(async (req, res, next) => {
  const $https = Https({ service: 'domestic', req })
  const response = await $https.post('/sale/Eco?actionName=TrmMkoWork&cmd=R003', req.body)
  const { rspStatus, data } = response.data
  res.json({
    data: data.ds_List,
    rspStatus: {
      rspCode: rspStatus.rspCode ? (rspStatus.rspCode === '0' ? '0000' : rspStatus.rspCode) : '1000',
      rspMessage: rspStatus.rspMessage || 'I/F Server Error',
      uri: req.path
    }
  })
})

// EP_IF_국내판매(선택형서비스 팝업 호출을 위한 보안 파라미터 조회) http://10.17.141.34/redmine/issues/557
const getChoiceServiceToken = asyncHandler(async (req, res, next) => {
  const $https = Https({ service: 'domestic', req })
  const response = await $https.post('/sale/Eco?actionName=C1101001Work&cmd=C015', req.body)
  const { rspStatus, data } = response.data
  res.json({
    data: data.ds_List,
    rspStatus: {
      rspCode: rspStatus.rspCode ? (rspStatus.rspCode === '0' ? '0000' : rspStatus.rspCode) : '1000',
      rspMessage: rspStatus.rspMessage || 'I/F Server Error',
      uri: req.path
    }
  })
})

// EP_IF_국내판매_080(출고배송모니터링)
const getShipmentMonitoring = asyncHandler(async (req, res, next) => {
  const $https = Https({ service: 'domestic', req })
  let response = await $https.post('/sale/Eco?actionName=ListIvWork&cmd=R001', req.body)
  let { rspStatus, data } = response.data
  //response = JSON.parse(`{"data":{"ds_List":[{"PATH_ADR":"서울특별시","REAI_ACQ_DTM":"20201111134955","PWTI_BD_MGMT_NO":"","PWTI_ZIP":"06184 ","REAI_PWTI_NM":"심천","TMZ_NM":"","BR_PWTI_NM":"안동현","SALE_CNTT_NO":"A3720NX000002","BR_PWTI_HP_TN":"01053940318","PWTI_WARA_ADR":"서울특별시 강남구 삼성로76길 28 (대치동) 오토개러지","DVC_CD":"Z06","HP_TN":"01091733334","CSPT_MONT_CTMS":"","DVC_NM":"신갈출고","CSPT_MONT_CMPL_CTMS":"","DLV_CNSG_ORG_TN":"","STA_YMD":"20201110","ARV_PARR_YMD":"20201110","ACQ_TYPE_NM":"배달탁송","DLV_CNSG_ORG_NO":"L","DLV_CNSG_ORG_NM":"심천","CSPT_MONT_CMPL_YMD":"","DLV_RDR_NM":"천종환","ARV_CMPL_YMD":"20201111","PWTI_HP_TN":"","PWTI_NM":"심천","ARV_CMPL_CTMS":"134955","PWTI_DTL_ADR":"오토개러지(010-5810-5205)","LOC_ST":"","REAI_PWTI_TN":"01053940318","PRDN_CAR_NO":"GW  003349","STA_CTMS":"1613  ","CSPT_MONT_YMD":"","ARV_PARR_CTMS":"1800  ","WHOT_WNT_APL_DATE":""}]},"rspStatus":{"rspCode":"0","uri":"actionName=ListIvWork&cmd=R001","rspMessage":"ó"}} `)
 // data = response.data

  res.json({
    data: data.ds_List,
    rspStatus: {
      rspCode: rspStatus.rspCode ? (rspStatus.rspCode === '0' ? '0000' : rspStatus.rspCode) : '1000',
      rspMessage: rspStatus.rspMessage || 'I/F Server Error',
      uri: req.path
    }
  })
})

// EP_IF_국내판매_075(차량별 하이패스 장착 여부)
const postHighpassEnable = asyncHandler(async (req, res, next) => {
  const $https = Https({ service: 'domestic', req })
  const response = await $https.post('/sale/Eco?actionName=ListCommWork&cmd=R005', req.body)
  const { rspStatus, data } = response.data
  res.json({
    data: data.ds_List,
    rspStatus: {
      rspCode: rspStatus.rspCode ? (rspStatus.rspCode === '0' ? '0000' : rspStatus.rspCode) : '1000',
      rspMessage: rspStatus.rspMessage || 'I/F Server Error',
      uri: req.path
    }
  })
})

// EP_IF_국내판매_054 - 가상계좌번호 생성
const postCreateGuja = asyncHandler(async (req, res, next) => {
  const $https = Https({ service: 'domestic', req })
  const response = await $https.post('/sale/Eco?actionName=ListCommWork&cmd=R004', req.body)
  const { rspStatus, data } = response.data

  let resData = null
  if (Object.keys(data).length > 0) resData = data.ds_List

  res.json({
    data: resData,
    rspStatus: {
      rspCode: rspStatus.rspCode ? (rspStatus.rspCode === '0' ? '0000' : rspStatus.rspCode) : '1000',
      rspMessage: rspStatus.rspMessage || 'I/F Server Error',
      uri: req.path
    }
  })
})

router.post('/getShipmentMonitoring', getShipmentMonitoring)
router.post('/getChoiceServiceToken', getChoiceServiceToken)
// EP_IF_국내판매_070(임직원정보조회)
const postMemberInfo = require('./postMemberInfo')

router.post('/generateVbankNum', generateVbankNum)
router.post('/reportHistory', reportHistory)
router.post('/memberInfo', postMemberInfo)
router.post('/highpassEnable', postHighpassEnable)

// EP_IF_국내판매_054 - 가상계좌번호 생성
router.post('/createGuja', postCreateGuja)

module.exports = router
