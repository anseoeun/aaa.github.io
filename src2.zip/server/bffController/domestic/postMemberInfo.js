const asyncHandler = require('../../utils/asyncHandler')
const Https = require('../../utils/https')

// EP_IF_국내판매_070 (임직원정보조회)
module.exports = asyncHandler(async (req, res, next) => {
  const $https = Https({ service: 'domestic', req })
  const response = await $https.post('/sale/Eco?actionName=ListCnttWork&cmd=R004', req.body)
  const { rspStatus, data } = response.data
  res.json({
    data: data.ds_List,
    rspStatus: {
      rspCode: rspStatus.rspCode ? (rspStatus.rspCode === '0' ? '0000' : rspStatus.rspCode) : '1000',
      rspMessage: rspStatus.rspMessage || 'I/F Server Error',
      uri: req.path
    }
  })
})
