const asyncHandler = require('../../utils/asyncHandler')
const Https = require('../../utils/https')

// API-E-구매서비스-012_작업중 (명의자 정보 조회)
async function getContractNaminfo(req, $httpsMsaPurchase) {
  try {
    const { contractNumber, electronicSignatureTypeCode } = req.body
    const params = { contractNumber, electronicSignatureTypeCode }

    const response = await $httpsMsaPurchase.get('/contract/nam/info', {
      params
    })

    return response.data
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}

// API-E-구매서비스-009 계약정보 조회
async function getContractInfo(req, $httpsMsaPurchase) {
  try {
    const { contractNumber } = req.body

    const response = await $httpsMsaPurchase.get('/contract/contract-info/' + contractNumber)

    return response.data
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}

// API-E-상품서비스-029 (계약금 조회)
async function getContractDownPayment(req, $httpsMsaPurchase, $httpsMsaProduct) {
  const { contractNumber } = req.body

  try {
    // API-E-구매서비스-009 계약정보 조회
    const responseContractInfo = await $httpsMsaPurchase.get('/contract/contract-info/' + contractNumber)

    let {
      newCarReservationCarYn,
      carAbbreviation,
      saleModelCode,
      optionMixCode,
      exteriorColorCode,
      interiorColorCode,
      carCode
    } = responseContractInfo.data.data

    if (carCode !== null) {
      carAbbreviation = carCode.substring(0, 2)
    }
    const params = {
      newCarReservationCarYn: newCarReservationCarYn === null ? '' : newCarReservationCarYn,
      carAbbreviation: carAbbreviation === null ? '' : carAbbreviation,
      saleModelCode: saleModelCode === null ? '' : saleModelCode,
      optionMixCode: optionMixCode === null ? '' : optionMixCode,
      exteriorColorCode: exteriorColorCode === null ? '' : exteriorColorCode,
      interiorColorCode: interiorColorCode === null ? '' : interiorColorCode
    }
    console.log('newCarReservationCarYn: ', newCarReservationCarYn)
    console.log('carAbbreviation: ', carAbbreviation)
    console.log('saleModelCode: ', saleModelCode)
    console.log('optionMixCode: ', optionMixCode)
    console.log('exteriorColorCode: ', exteriorColorCode)
    console.log('interiorColorCode: ', interiorColorCode)
    console.log('carCode: ', carCode)

    const response = await $httpsMsaProduct.get('/contract/down-payment/info', {
      params
    })

    return response.data
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}

module.exports = asyncHandler(async (req, res, next) => {
  const $httpsMsaProduct = Https({ service: 'product', version: 'v1', req })
  const $httpsMsaPurchase = Https({ service: 'purchase', version: 'v1', req })

  const [response1, response2, response3] = await Promise.all([
    getContractNaminfo(req, $httpsMsaPurchase),
    getContractInfo(req, $httpsMsaPurchase),
    getContractDownPayment(req, $httpsMsaPurchase, $httpsMsaProduct)
  ])

  const response = {
    screenId: 'UI_M_계약_S3_T6210A',
    api_e_purchase_012: response1,
    api_e_purchase_009: response2,
    api_e_product_029: response3
  }

  res.json(response)
})
