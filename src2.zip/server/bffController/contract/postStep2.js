const asyncHandler = require('../../utils/asyncHandler')
const Https = require('../../utils/https')

// API-H-상품서비스-059 (견적정보에 대한 코드명칭을 조회하는 API)
async function getEstimationInfoName(req, $httpsMsaProduct) {
  try {
    const _req = req
    _req.query = {
      carCode: req.body.carCode,
      saleModelCode: req.body.saleModelCode,
      optionMixCode: req.body.optionMixCode,
      exteriorColorCode: req.body.exteriorColorCode,
      interiorColorCode: req.body.interiorColorCode,
      tuixMixCode: req.body.tuixMixCode,
      saleTypeCode: req.body.saleTypeCode
    }

    const response = await $httpsMsaProduct.get('/estimation-info-name', {
      params: { ..._req.query }
    })

    return response.data
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}

// API-E-구매서비스-009 (계약정보조회)
async function getContractInfo(req, $httpsMsaPurchase) {
  try {
    const response = await $httpsMsaPurchase.get('/contract/contract-info/' + req.body.contractNumber)

    return response.data
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}
// API-E-구매서비스-010 (계약한도시간 정보 조회) - 기능 미구현
async function getContractlimittimeInfo(req, $httpsMsaPurchase) {
  try {
    const response = await $httpsMsaPurchase.get('/contract/limit-time/info', {
      params: { ...req.query }
    })

    return response.data
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}
// API-E-구매서비스-028 판촉차량 정보 조회
async function getContractPromotioncarInfo(req, $httpsMsaPurchase) {
  try {
    const response = await $httpsMsaPurchase.get('/contract/promotion-car/info/' + req.body.contractNumber)

    return response.data
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}
// API-E-구매서비스-030 (동의 정보 조회)
async function getContractAgreementInfo(req, $httpsMsaPurchase) {
  try {
    const _req = req
    _req.query = {
      contractNumber: req.body.contractNumber
    }

    const response = await $httpsMsaPurchase.get('/contract/agreement-info', {
      params: { ..._req.query }
    })

    return response.data
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}
// API-E-구매서비스-040 (계약리스트 정보조회)
async function getContractContracts(req, $httpsMsaPurchase) {
  try {
    const _req = req
    _req.query = {
      customerManagemontNumber: req.body.customerManagemontNumber,
      usedCarTradeInYn: req.body.usedCarTradeInYn
    }

    const response = await $httpsMsaPurchase.get('/contract/contracts', {
      params: { ..._req.query }
    })

    return response.data
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}
// API-E-구매서비스-043 (조건차 정보 조회) - 기능 미구현
async function getContractCoditioncarInfo(req, $httpsMsaPurchase) {
  try {
    const _req = req
    _req.query = {
      contractNumber: req.body.contractNumber
    }

    const response = await $httpsMsaPurchase.get('/contract/condition-car/info', {
      params: { ..._req.query }
    })

    return response.data
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}
// // EP_IF_블루멤버스(CM)_004 (블루멤버스가입여부확인) - 인터페이스 테스트 필요, 블루멤버스 uri 정보 필요, AES256CBC암호화 필요
// async function getBluemembersSubscriptionInfo(req, $httpsIntfBluemembers) {
//   try {
//     const _req = req

//     const encryptedData = {
//       sendCode: req.body.sendCode,
//       customerNo: req.body.customerNo,
//       name: req.body.name,
//       cellNo: req.body.cellNo,
//       ci: req.body.ci
//     }.encryption() // AES256CBC암호화 로직 적용 필요

//     _req.body = {
//       data: encryptedData
//     }

//     const response = await $httpsIntfBluemembers.get('/cm/action.do', {
//       params: { ..._req.body }
//     })

//     return response.data // 데이터 테스트 후 결과 parsing 필요
//   } catch (err) {
//     return {
//       message: err.message,
//       config: err.config
//     }
//   }
// }
// // EP_IF_블루멤버스_001 (특화서비스 상품목록) - 명세서 없음
// async function getSpecificServiceGoods(req, $httpsIntfBluemembers) {
//   try {
//     const response = await $httpsIntfBluemembers.get('/cm/action.do', {
//       params: { ...req.query }
//     })

//     return response.data // 데이터 테스트 후 결과 parsing 필요
//   } catch (err) {
//     return {
//       message: err.message,
//       config: err.config
//     }
//   }
// }
// // EP_IF_국내판매_075 (차량별 하이패스 장착여부조회) - uri 정보 필요, test 필요, 테스트 데이터 필요
// async function getHighpassUsedInfoPerCar(req, $httpsIntfDomesticSales) {
//   try {
//     const response = await $httpsIntfDomesticSales.post('')

//     return response.data // 데이터 테스트 후 결과 parsing 필요
//   } catch (err) {
//     return {
//       message: err.message,
//       config: err.config
//     }
//   }
// }

module.exports = asyncHandler(async (req, res, next) => {
  const $httpsMsaProduct = Https({ service: 'product', version: 'v1', req })
  const $httpsMsaPurchase = Https({ service: 'purchase', version: 'v1', req })
  // const $httpsIntfBluemembers = Https({ service: 'blueMembers', req })
  // const $httpsIntfDomesticSales = Https({ service: 'domestic', req })

  const [
    response1,
    response3,
    response4,
    response5,
    response6,
    response7,
    response8
    // ,response9
    // ,response10
    // ,response11
  ] = await Promise.all([
    getEstimationInfoName(req, $httpsMsaProduct),
    getContractInfo(req, $httpsMsaPurchase),
    getContractlimittimeInfo(req, $httpsMsaPurchase),
    getContractPromotioncarInfo(req, $httpsMsaPurchase),
    getContractAgreementInfo(req, $httpsMsaPurchase),
    getContractContracts(req, $httpsMsaPurchase),
    getContractCoditioncarInfo(req, $httpsMsaPurchase)
    // ,getBluemembersSubscriptionInfo(req, $httpsIntfBluemembers)
    // ,getSpecificServiceGoods(req, $httpsIntfBluemembers)
    // ,getHighpassUsedInfoPerCar(req, $httpsIntfDomesticSales)
  ])

  const response = {
    screenId: 'UI_M_계약_S2_C5100A',
    api_h_product_059: response1,
    api_e_purchase_009: response3,
    api_e_purchase_010: response4,
    api_e_purchase_028: response5,
    api_e_purchase_030: response6,
    api_e_purchase_040: response7,
    api_e_purchase_043: response8
    // ep_if_bluemembers_cm_004: response9,
    // ep_if_bluemembers_001: response10,
    // ep_if_domesticSales_075: response11
  }

  res.json(response)
})
