const asyncHandler = require('../../utils/asyncHandler')
const Https = require('../../utils/https')


// API-H-공통서비스-005 (이용약관조회)
async function getTerms(req, $httpsMsaCommon) {
  try {
    const response = await $httpsMsaCommon.get('/terms/' + req.body.termsClassCd)

    return response.data
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}
// API-H-공통서비스-004 (공통코드조회)
async function getCommoncode(req, $httpsMsaCommon) {
  try {
    const response = await $httpsMsaCommon.get('/common-code/' + req.body.systemTypeCode + '/' + req.body.codeTypeCode)

    return response.data
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}
// API-H-상품서비스-059 (견적정보에 대한 코드명칭을 조회하는 API)
async function getEstimationInfoName(req, $httpsMsaProduct) {
  try {
    const _req = req
    _req.query = {
      carCode: req.body.carCode,
      saleModelCode: req.body.saleModelCode,
      optionMixCode: req.body.optionMixCode,
      exteriorColorCode: req.body.exteriorColorCode,
      interiorColorCode: req.body.interiorColorCode,
      tuixMixCode: req.body.tuixMixCode,
      saleTypeCode: req.body.saleTypeCode
    }

    const response = await $httpsMsaProduct.get('/estimation-info-name', {
      params: { ..._req.query }
    })

    return response.data
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}
// API-E-구매서비스-007 (차량 옵션정보 조회) - 기능 미구현
async function getContractCarOptioninfo(req, $httpsMsaPurchase) {
  try {
    const response = await $httpsMsaPurchase.get('/contract/car/option-info')

    return response.data
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}
// API-E-구매서비스-009 계약정보 조회
async function getContractContractinfo(req, $httpsMsaPurchase) {
  try {
    const response = await $httpsMsaPurchase.get('/contract/contract-info/' + req.body.contractNumber)

    return response.data
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}
// API-E-구매서비스-010_작업중 (계약한도시간 정보 조회) - 기능 미구현
async function getContractLimittimeInfo(req, $httpsMsaPurchase) {
  try {
    const response = await $httpsMsaPurchase.get('/contract/limit-time/info')

    return response.data
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}
// API-E-구매서비스-012 (명의자 정보 조회) - 기능 미구현
async function getContractNomineeInfo(req, $httpsMsaPurchase) {
  try {
    const _req = req
    _req.query = {
      contractNumber: req.body.contractNumber,
      electronicSignatureTypeCode: req.body.electronicSignatureTypeCode
    }

    const response = await $httpsMsaPurchase.get('/contract/nominee/info', {
      params: { ..._req.query }
    })

    return response.data
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}
// API-E-구매서비스-013 제1블루핸즈 정보 조회 => 보증 관련 정보로 변경됨.
// async function getContractFirstbluehandsInfo(req, $httpsMsaPurchase) {
//   try {
//     const _req = req
//     _req.query = {
//       contractNumber: req.body.contractNumber
//     }

//     const response = await $httpsMsaPurchase.get(
//       '/contract/first-bluehands/info',
//       {
//         params: { ..._req.query }
//       }
//     )

//     return response.data
//   } catch (err) {
//     return {
//       message: err.message,
//       config: err.config
//     }
//   }
// }
// API-E-구매서비스-014 ((면세) 장애등급 정보 조회) - 기능 미구현
async function getContractTaxfreeInfo(req, $httpsMsaPurchase) {
  try {
    const response = await $httpsMsaPurchase.get('/contract/tax-free/info')

    return response.data
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}
// API-E-구매서비스-015 블루핸즈 리스트 조회
async function getContractBluehands(req, $httpsMsaPurchase) {
  try {
    const _req = req
    _req.query = {
      pageNo: req.body.pageNo,
      pageSize: req.body.pageSize,
      searchKeyword: req.body.searchKeyword,
      sidoCode: req.body.sidoCode,
      sigunguCode: req.body.sigunguCode,
      asnCodes: req.body.asnCodes
    }

    const response = await $httpsMsaPurchase.get('/contract/bluehands', {
      params: { ..._req.query }
    })

    return response.data
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}
// API-E-구매서비스-018 블루핸즈 시/도 리스트 조회
async function getContractBluehandsSido(req, $httpsMsaPurchase) {
  try {
    const response = await $httpsMsaPurchase.get('/contract/blue-hands/si-do')

    return response.data
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}
// API-E-구매서비스-019 블루핸즈 시/군/구 리스트 조회
async function getContractBluehandsSigungu(req, $httpsMsaPurchase) {
  try {
    const response = await $httpsMsaPurchase.get('/contract/blue-hands/si-gun-gu')

    return response.data
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}
// API-E-구매서비스-028 판촉차량 정보 조회
async function getContractPromotioncarInfo(req, $httpsMsaPurchase) {
  try {
    const response = await $httpsMsaPurchase.get('/contract/promotion-car/info/' + req.body.contractNumber)

    return response.data
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}

module.exports = asyncHandler(async (req, res, next) => {
  const $httpsMsaCommon = Https({ service: 'common', version: 'v1', req })
  const $httpsMsaProduct = Https({ service: 'product', version: 'v1', req })
  const $httpsMsaPurchase = Https({ service: 'purchase', version: 'v1', req })

  const [
    response1,
    response2,
    response3,
    response4,
    response5,
    response6,
    response7,
    // response8,
    response9,
    response10,
    response11,
    response12,
    response13
  ] = await Promise.all([
    getTerms(req, $httpsMsaCommon),
    getCommoncode(req, $httpsMsaCommon),
    getEstimationInfoName(req, $httpsMsaProduct),
    getContractCarOptioninfo(req, $httpsMsaPurchase),
    getContractContractinfo(req, $httpsMsaPurchase),
    getContractLimittimeInfo(req, $httpsMsaPurchase),
    getContractNomineeInfo(req, $httpsMsaPurchase),
    // getContractFirstbluehandsInfo(req, $httpsMsaPurchase),
    getContractTaxfreeInfo(req, $httpsMsaPurchase),
    getContractBluehands(req, $httpsMsaPurchase),
    getContractBluehandsSido(req, $httpsMsaPurchase),
    getContractBluehandsSigungu(req, $httpsMsaPurchase),
    getContractPromotioncarInfo(req, $httpsMsaPurchase)
  ])

  const response = {
    screenId: 'UI_M_계약_신청완료_C2100A11',
    api_h_common_005: response1,
    api_h_common_004: response2,
    api_h_product_059: response3,
    api_e_purchase_007: response4,
    api_e_purchase_009: response5,
    api_e_purchase_010: response6,
    api_e_purchase_012: response7,
    // api_e_purchase_013: response8,
    api_e_purchase_014: response9,
    api_e_purchase_015: response10,
    api_e_purchase_018: response11,
    api_e_purchase_019: response12,
    api_e_purchase_028: response13
  }

  res.json(response)
})
