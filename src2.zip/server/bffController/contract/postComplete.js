const asyncHandler = require('../../utils/asyncHandler')
const Https = require('../../utils/https')

// API-H-상품서비스-059 (견적정보에 대한 코드명칭을 조회하는 API)
async function getEstimationInfoName(req, $httpsMsaProduct) {
  try {
    const _req = req
    _req.query = {
      carCode: req.body.carCode,
      saleModelCode: req.body.saleModelCode,
      optionMixCode: req.body.optionMixCode,
      exteriorColorCode: req.body.exteriorColorCode,
      interiorColorCode: req.body.interiorColorCode,
      tuixMixCode: req.body.tuixMixCode,
      saleTypeCode: req.body.saleTypeCode
    }

    const response = await $httpsMsaProduct.get('/estimation-info-name', {
      params: { ..._req.query }
    })

    return response.data
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}

// API-E-구매서비스-009 계약정보 조회
async function getContractContractinfo(req, $httpsMsaPurchase) {
  try {
    const response = await $httpsMsaPurchase.get('/contract/contract-info/' + req.body.contractNumber)

    return response.data
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}

module.exports = asyncHandler(async (req, res, next) => {
  const $httpsMsaProduct = Https({ service: 'product', version: 'v1', req })
  const $httpsMsaPurchase = Https({ service: 'purchase', version: 'v1', req })

  const [response1, response2] = await Promise.all([
    getEstimationInfoName(req, $httpsMsaProduct),
    getContractContractinfo(req, $httpsMsaPurchase)
  ])

  const response = {
    screenId: 'UI_M_계약_신청완료_C2100A',
    api_h_puroduct_059: response1,
    api_e_purchase_009: response2
  }

  res.json(response)
})
