const { Router } = require('express')
const router = Router()

const postBefore = require('./postBefore')
const postStep1 = require('./postStep1')
const postStep2 = require('./postStep2')
const postStep3 = require('./postStep3')
const postStep4 = require('./postStep4')
const postComplete = require('./postComplete')

// API-H-BFF-002(계약직전팝업 조회)
router.post('/before', postBefore)

// API-H-BFF-003(계약 Step1 화면)
router.post('/step1', postStep1)

// API-H-BFF-004(계약 Step2 화면)
router.post('/step2', postStep2)

// API-H-BFF-010_작업중(계약 Step3 화면)
router.post('/step3', postStep3)

// API-H-BFF-005(계약 Step4 화면)
router.post('/step4', postStep4)

// API-H-BFF-006(계약완료 화면)
router.post('/complete', postComplete)

module.exports = router
