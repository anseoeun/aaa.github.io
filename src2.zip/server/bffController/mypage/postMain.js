const asyncHandler = require('../../utils/asyncHandler')
const Https = require('../../utils/https')

// API-H-공통서비스-007 (GNB 메뉴 전체 조회)
async function getGnbMenusData(req, $httpsMsaCommon) {
  try {
    const _req = req
    _req.query = {
      gnbType: 'P',
      siteType: 'E',
      imageSectionCode: ''
    }

    const response = await $httpsMsaCommon.get('/gnb/menus/P', {
      params: { ..._req.query }
    })

    return response.data
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}

// API-E-구매서비스-076 (나의 계약 진행 정보 조회)
async function getContractMyContractInfo(req, $httpsMsaPurchase) {
  try {
    const response = await $httpsMsaPurchase.get('/contract/my-contract/info')

    return response.data
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}
// API-E-견적서비스-001 (나의 견적 내역 TOP5 견적번호 정보 조회)
async function getMyestimationsTop5(req, $httpsMsaEstimation) {
  try {
    const response = await $httpsMsaEstimation.get('/my-estimations/top5')

    return response.data
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}
// API-E-이벤트서비스-016 (나의 판촉차 응모결과 정보 조회)
async function getPromotioncarEntryResult(req, $httpsMsaEvent) {
  try {
    const response = await $httpsMsaEvent.get('/promotion-car/entry/result')

    return response.data
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}
// API-E-고객지원서비스-003 (나의 1:1문의내역 정보 조회)
async function getInquiryInfo(req, $httpsMsaCustomersupport) {
  try {
    const response = await $httpsMsaCustomersupport.get('/inquiry/info')

    return response.data
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}
// EP_IF_국내판매_070/ 임직원정보조회
async function getEmployeeInfo(req, $httpsIntfDomesticSales) {
  try {
    const response = await $httpsIntfDomesticSales.post('/sale/Eco?actionName=ListCnttWork&cmd=R004', req.body)

    return response.data
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}
// EP_IF_오픈시승_012/ 시승예약내역
async function postBookingList(req, $httpsIntfDrive) {
  try {
    const response = await $httpsIntfDrive.post('/v10/rest/bookingList.do', req.body)

    return response.data
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}

module.exports = asyncHandler(async (req, res, next) => {
  const $httpsMsaCommon = Https({ service: 'common', version: 'v1', req })
  const $httpsMsaEstimation = Https({ service: 'estimation', version: 'v1', req })
  const $httpsMsaEvent = Https({ service: 'event', version: 'v1', req })
  const $httpsMsaPurchase = Https({ service: 'purchase', version: 'v1', req })
  const $httpsMsaCustomersupport = Https({ service: 'customer-support', version: 'v1', req })
  const $httpsIntfDomesticSales = Https({ service: 'domestic', req })
  const $httpsIntfDrive = Https({ service: 'drive', req })

  const [response1, response2, response3, response4, response5, response6, response7] = await Promise.all([
    getGnbMenusData(req, $httpsMsaCommon),
    getContractMyContractInfo(req, $httpsMsaPurchase),
    getMyestimationsTop5(req, $httpsMsaEstimation),
    getPromotioncarEntryResult(req, $httpsMsaEvent),
    getInquiryInfo(req, $httpsMsaCustomersupport),
    getEmployeeInfo(req, $httpsIntfDomesticSales),
    postBookingList(req, $httpsIntfDrive)
  ])

  const response = {
    screenId: 'UI_M_마이_메인_C1110',
    gnb_menus_data: response1,
    api_e_purchase_076: response2,
    api_e_estimation_001: response3,
    api_e_event_016: response4,
    api_e_customer_support_003: response5,
    ep_if_domestic_sales_070: response6,
    ep_if_drive_012: response7
  }

  res.json(response)
})
