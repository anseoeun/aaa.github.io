const asyncHandler = require('../../utils/asyncHandler')
const Https = require('../../utils/https')

// Juso.go.kr
module.exports = asyncHandler(async (req, res, next) => {
  const $https = Https({ service: 'juso', req })
  const response = await $https.get('/addrlink/addrCoordApiJsonp.do', {
    params: {
      confmKey: 'TESTJUSOGOKR',
      admCd: 1, // 행정구역코드
      rnMgtSn: 10, // 도로명코드
      udrtYn: '', // 지하여부
      buldMnnm: 0, // 건물본번
      buldSlno: 0, // 건물부번
      resultType: 'json',
      ...req.query
    }
  })

  const {
    results: {
      common: { errorCode, errorMessage, currentPage, countPerPage, totalCount },
      juso
    }
  } = JSON.parse(response.data.replace(/^\(/, '').replace(/\)$/, ''))

  res.json({
    data: {
      list: juso,
      total: totalCount,
      pageNum: currentPage,
      pageSize: countPerPage
    },
    rspStatus: {
      rspCode: errorCode === '0' ? '0000' : errorCode,
      rspMessage: errorMessage,
      uri: req.path
    }
  })
})
