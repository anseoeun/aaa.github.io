const asyncHandler = require('../../utils/asyncHandler')
const Https = require('../../utils/https')

// Juso.go.kr
module.exports = asyncHandler(async (req, res, next) => {
  const $https = Https({ service: 'juso', req })
  const response = await $https.get('/addrlink/addrLinkApiJsonp.do', {
    params: {
      confmKey: 'TESTJUSOGOKR',
      currentPage: 1,
      countPerPage: 10,
      keyword: '',
      resultType: 'json',
      ...req.query
    }
  })

  const {
    results: {
      common: { errorCode, errorMessage, currentPage, countPerPage, totalCount },
      juso
    }
  } = JSON.parse(response.data.replace(/^\(/, '').replace(/\)$/, ''))

  res.json({
    data: {
      list: juso,
      total: totalCount,
      pageNum: currentPage,
      pageSize: countPerPage
    },
    rspStatus: {
      rspCode: errorCode === '0' ? '0000' : errorCode,
      rspMessage: errorMessage,
      uri: req.path
    }
  })
})
