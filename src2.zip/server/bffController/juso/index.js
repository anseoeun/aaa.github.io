const { Router } = require('express')
const router = Router()
const asyncHandler = require('../../utils/asyncHandler')
const Https = require('../../utils/https')

//EP_IF_주소_001 주소검색
const searchAddr = asyncHandler(async (req, res, next) => {
  const $https = Https({ service: 'juso', req })
  const response = await $https.get('/addrlink/addrLinkApi.do', {
    params: { ...req.query, confmKey: 'U01TX0FVVEgyMDE3MDgxODE2NTExMTIzODcy', resultType: 'json' }
    // params: { ...req.query, confmKey: 'TESTJUSOGOKR', currentPage: 1, countPerPage: 10, resultType: 'json' }
    
  })
  const { results } = response.data
  res.json({
    // data: results.juso,
    data: results,
    rspStatus: {
      rspCode: results.common.errorCode || '1000',
      rspMessage: results.common.errorMessage || 'I/F Server Error',
      uri: req.path
    }
  })
})

//EP_IF_주소_002 좌표검색
// const searchCoord = asyncHandler(async (req, res, next) => {
//   const response = await $https.get('/addrlink/addrCoordApiJsonp.do', {
//     params: { ...req.query, confmKey: 'U01TX0FVVEgyMDE3MDgxODE2NTExMTIzODcy', resultType: 'json' }
//   })
//   const { results } = JSON.parse(response.data.substring(1, response.data.length-1))
//   res.json({
//     data: results && results.juso,
//     rspStatus: {
//       rspCode: (results && results.common.errorCode) || '1000',
//       rspMessage: (results && results.common.errorMessage) || 'I/F Server Error',
//       uri: req.path
//     }
//   })
// })

router.get('/searchAddr', searchAddr)
// router.get('/searchCoord', searchCoord)

module.exports = router
