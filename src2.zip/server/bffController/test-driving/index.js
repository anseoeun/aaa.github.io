const { Router } = require('express')
const router = Router()
const postCarList = require('./postCarList')
const postCarInfoDetail = require('./postCarInfoDetail')
const postCenterList = require('./postCenterList')
const postCarFuelList = require('./postCarFuelList')
const postAreaList = require('./postAreaList')
const postBookingSchedule = require('./postBookingSchedule')
const postBookingList = require('./postBookingList')
const postBookingreg = require('./postBookingreg')
const postBookingCancel = require('./postBookingCancel')
const postOrgmLoc = require('./postOrgmLoc')
const postOrgDetail = require('./postOrgDetail')
const postDrivingYn = require('./postDrivingYn')

// EP_IF_오픈시승_001_시승차종리스트
router.post('/carList', postCarList)

// EP_IF_오픈시승_002_시승차종상세정보
router.post('/carInfoDetail', postCarInfoDetail)

// EP_IF_오픈시승_003_찾아가는시승가능지역
router.post('/areaList', postAreaList)

// EP_IF_오픈시승_004_시승거점(시도)
router.post('/centerList', postCenterList)

// EP_IF_오픈시승_005_시승거점(위도/경도)
router.post('/orgmLoc', postOrgmLoc)

// EP_IF_오픈시승_006_시승거점 상세정보
router.post('/orgDetail', postOrgDetail)

// EP_IF_오픈시승_007_차량별시승거점
router.post('/carFuelList', postCarFuelList)

// EP_IF_오픈시승_008_시승가능여부 (찾아가는 시승 서비스)
router.post('/drivingYn', postDrivingYn)

// EP_IF_오픈시승_009_시승예약스케줄
router.post('/bookingSchedule', postBookingSchedule)

// EP_IF_오픈시승_011_시승예약등록
router.post('/bookingreg', postBookingreg)

// EP_IF_오픈시승_012_시승예약내역
router.post('/bookingList', postBookingList)

// EP_IF_오픈시승_013_시승예약취소
router.post('/bookingCancel', postBookingCancel)

module.exports = router
