const asyncHandler = require('../../utils/asyncHandler')
const Https = require('../../utils/https')

// EP_IF_오픈시승_005_시승거점(위도/경도)
module.exports = asyncHandler(async (req, res, next) => {
  const $https = Https({ service: 'drive', req })
  const response = await $https.post('/v10/rest/getorgmloc.do', req.body)
  const { infoResponse, DisplayResponse } = response.data
  res.json({
    data: DisplayResponse,
    rspStatus: {
      rspCode: infoResponse.rsp_CD ? (infoResponse.rsp_CD === '200' ? '0000' : infoResponse.rsp_CD) : '1000',
      rspMessage: infoResponse.rsp_MESSAGE || 'I/F Server Error',
      uri: req.path
    }
  })
})
