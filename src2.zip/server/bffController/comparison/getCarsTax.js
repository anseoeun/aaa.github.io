const asyncHandler = require('../../utils/asyncHandler')
const Https = require('../../utils/https')

// EP_IF_카젠시_009(취득세 공채 정보)
module.exports = asyncHandler(async (req, res, next) => {
  const $https = Https({ service: 'cargency', req })
  // console.log('tax req', req.query)
  const response = await $https.get('/hdcarsvc.aspx?pagecode=cmp9', {
    params: { ...req.query }
  })
  const { rspCode, rspMessage, dataList } = response.data
  // console.log('tax data', response.data)
  res.json({
    data: dataList,
    rspStatus: {
      rspCode: rspCode || '1000',
      rspMessage: rspMessage || 'I/F Server Error',
      uri: req.path
    }
  })
})
