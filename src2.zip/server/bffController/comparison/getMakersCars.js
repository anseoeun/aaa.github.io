const asyncHandler = require('../../utils/asyncHandler')
const Https = require('../../utils/https')

// EP_IF_카젠시_002(제조사별 모델리스트 조회)
module.exports = asyncHandler(async (req, res, next) => {
  const $https = Https({ service: 'cargency', req })
  const response = await $https.get('/hdcarsvc.aspx?pagecode=cmp2', {
    params: { ...req.query }
  })
  const { rspCode, rspMessage, dataList } = response.data
  res.json({
    data: dataList,
    rspStatus: {
      rspCode: rspCode || '1000',
      rspMessage: rspMessage || 'I/F Server Error',
      uri: req.path
    }
  })
})
