const asyncHandler = require('../../utils/asyncHandler')
const Https = require('../../utils/https')

// EP_IF_카젠시_003(자주비교되는 차량리스트)
module.exports = asyncHandler(async (req, res, next) => {
  const $https = Https({ service: 'cargency', req })
  const response = await $https.get('/hdcarsvc.aspx?pagecode=cmp3', {
    params: { ...req.query }
  })
  const { rspCode, rspMessage, compList } = response.data
  res.json({
    data: compList,
    rspStatus: {
      rspCode: rspCode || '1000',
      rspMessage: rspMessage || 'I/F Server Error',
      uri: req.path
    }
  })
})
