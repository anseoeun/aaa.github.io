const { Router } = require('express')
const router = Router()

const getMain = require('./getMain')
const getNotice = require('./getNotice')
const getFile = require('./getFile')
// const postUserLogin = require('./userLogin')
// const postRepayment = require('./postRepayment')
// const postAdditionalPayment = require('./postAdditionalPayment')

// 메인화면을 위한 자료취득하기
router.get('/', getMain.getMain)
router.get('/getContractDetail', getMain.getContractDetail) // 계약상세

// url : '/api/bff/main/getMainCarsInfo'
router.get('/getMainCarsInfo', getMain.getMainCarsInfo) // 메인-하단 > 차량라인업 + 할인차베스트

router.get('/getPurposeCars', getMain.getPurposeCars) // 사용안함

// 메인 > 로그인
// router.post('/user_login', postUserLogin)

// API-E-고객지원서비스-007 (공지사항 리스트)
// API-E-고객지원서비스-008 (공지사항 정보 상세조회)
router.get('/getNotice', getNotice.getNotice)

//-- (공지사항 첨부파일) 바이너리 파일 다운로드 --
router.get('/file/download/:fileGroupSn/:fileSn', getNotice.getFileDownload)

//-- 바이너리 파일 다운로드 --
router.get('/file/download/:fileGroupSn/:fileSn', getFile.getFileDownload)


// // API-H-BFF-009(추가결제 화면)
// router.post('/additional-payment', postAdditionalPayment)

module.exports = router
