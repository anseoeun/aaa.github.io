const asyncHandler = require('../../utils/asyncHandler')
const Https = require('../../utils/https')

// -- 헤더값을 복사합니다 --
// function copyHeader( res, remoteRes, itemName ) {
//   res.set( itemName, remoteRes.headers[itemName])
// }
//--------------------------------------------------------------------------
const getNotice =  async (req, res, next) => {
  const $https = Https({ service: 'customer-support', version: 'v1', req })
  //
  // console.log('[login.js] req.body:' + JSON.stringify(req.body,null,2))
  // req.body.userid
  // req.body.password
  const myConfig = {
    url: '/notices', method:'get',
    params: { 
      'pageNo': 1, 
      'pageSize': 10 
    },
    data: { } 
  }

  try {
    const response = await $https.request( myConfig)
    if(!response || !response.data ||  !response.data.data || 
      !response.data.data.list || (response.data.data.list.length < 1))
    {
      return { }
    } 
    // ----- 공지사항 목록에 상세 내역까지 존재합니다 -------
    return response.data
    //
  } catch (err) {
    console.log('[call_api] -outer error-')
    return { }
  }
}
//--------------------------------
//--- 바이너리 모드로 파일을 다운로드 받습니다
const getFileDownload =  async (req, res, next) => {
  const $https = Https({ service: 'common', version: 'v1', req })
  //
  const myConfig = {
    url: req.path, 
    method:'get',
    responseType: 'arraybuffer',
    headers: { 'user-agent': req.headers['user-agent'] } // 브라우저의 userAGent 정보를 강제로 설정해서 보냅니다
  }
  try {
    const recv_res = await $https.request( myConfig)
    //-- 헤더복사 --
    for(const key1 in recv_res.headers ){
      res.set( key1, recv_res.headers[key1])
    }

    if( !recv_res.headers['content-length'] || '0' === recv_res.headers['content-length'] || !recv_res.data){
      console.log('[getFileDownload] send 404 .......')

      return null
    }
    console.log('getNotice.js ---- getFileDownload------')
    return recv_res.data
    //
  } catch (err) {
    console.log('[call_api] -outer error-')
    return { }
  }
}
//------------------------------------------------------------
module.exports = {
  getNotice: asyncHandler(async (req, res, next) => {
    const response = await getNotice(req, res, next) 
    res.json( response )

  }),
  getFileDownload: asyncHandler(async (req, res, next) => {
    const res_data = await getFileDownload(req, res, next) 
    /*
       바이너리 데이터를 전송합니다
    */
    if( res_data){
      res.send( res_data )
    } else {
      
      res.status(404).end() // 404 시스템 메시지 보이기

    }
    

  })
}
