const asyncHandler = require('../../utils/asyncHandler')
const Https = require('../../utils/https')

// const { Router } = require('express')
// const router = Router()
// const asyncHandler = require('../../utils/asyncHandler')
// const Https = require('../../utils/https')
const $https = Https('domestic', '')
const { setLoginResultToSession } = require('../../utils/session')
const { changeObjToCamel } = require('../../utils/utils')
/*

      , employeeInfo : { // 2-임직원 회원정보
        httpsId: ['domestic',''], url: '/sale/Eco',
        params: { actionName: 'ListCnttWork',  cmd: 'R004' },
        data: {// --- FIXME : 실 데이터로 수정해야합니다.
          'EENO': '5715236', 'EENM': '', 'BIR_YYMMDD': ''
        }
      }
*/
/*-----------------------------------------------------------
// 함수명 : 로그인 - 임직원 회원정보
   호출위치 : 메인화면 > 로그인화면 : 로그인 시도시
   사용인자 : 클라이언트에서 보내는 아이디와 비밀번호를 사용합니다

   작업내용 : 국내판매의 '070'(임직원정보조회) 인터페이스를 호출합니다

   서버단의 로그인 API 완료시, 반영작업이 필요합니다.
   현재 API 작업중임(2019.11.15)
-----------------------------------------------------------*/
const loginApi = async (req, res, next) => {
  //

  console.log('[login.js] req.body:' + JSON.stringify(req.body, null, 2))
  // req.body.userid
  // req.body.password
  const myConfig = {
    url: '/sale/Eco',
    method: 'post',
    params: { actionName: 'ListCnttWork', cmd: 'R004' },
    data: {
      EENO: req.body.userid,
      EENM: '',
      BIR_YYMMDD: ''
    }
    // body: {
    //   'EENO': req.body.userid,
    //   'EENM': '',
    //   'BIR_YYMMDD': ''
    // }
  }

  console.log('[login.js] myConfig:' + JSON.stringify(myConfig, null, 2))
  // console.log('[login.js] baseURL:' + $https.baseURL)

  try {
    const response = await $https.request(myConfig)
    console.log('[login.js]after request :' + JSON.stringify(response.data, null, 2))
    // console.log('[login.js]  session :' + JSON.stringify(req.session,null,2))

    // req.session.login = {
    //   userid : '',
    //   username: ''
    // }
    // console.log('[login.js]  session :' + JSON.stringify(req.session,null,2))
    let retValue = {}
    if (
      !response ||
      !response.data ||
      !response.data.data ||
      !response.data.data.ds_List ||
      response.data.data.ds_List.length < 1
    ) {
      retValue = { isLogin: false }

      setLoginResultToSession(req, retValue)

      return retValue
    }
    //
    const empUser = changeObjToCamel(response.data.data.ds_List[0])

    retValue = {
      isLogin: true,
      empUser: empUser,
      userid: response.data.data.ds_List[0].EENO,
      username: response.data.data.ds_List[0].EE_NM,
      birthymd: response.data.data.ds_List[0].BIR_YMD
    }

    setLoginResultToSession(req, retValue)

    return retValue

    //
  } catch (err) {
    console.log('[call_api] -outer error-')
    const retValue = {
      isLogin: false,
      message: err.message,
      config: err.config
    }

    setLoginResultToSession(req, retValue)

    return retValue
  }
}

// const loginApi2 = (req, res, next) => { res.json( {data:{'EEEE':'RRRR'}}) }

//--------------------------------
module.exports = asyncHandler(async (req, res, next) => {
  const response = await loginApi(req, res, next)
  res.json(response)
})

// module.exports = asyncHandler(async (req, res, next) => {
//   //
//   console.log('[login.js] start')
//   console.log('[login.js] req.body:' + JSON.stringify(req.body,null,2))
//   // console.log('[login.js] req.data:' + req.data)
//   // console.log('[login.js] req.params:' + JSON.stringify(req.params,null,2))

//   const response = { login:true }

//   res.json( response )

// })

// //EP_IF_주소_002 좌표검색
// // const searchCoord = asyncHandler(async (req, res, next) => {
// //   const response = await $https.get('/addrlink/addrCoordApiJsonp.do', {
// //     params: { ...req.query, confmKey: 'TESTJUSOGOKR', resultType: 'json' }
// //   })
// //   const { results } = JSON.parse(response.data.substring(1, response.data.length-1))
// //   res.json({
// //     data: results && results.juso,
// //     rspStatus: {
// //       rspCode: (results && results.common.errorCode) || '1000',
// //       rspMessage: (results && results.common.errorMessage) || 'I/F Server Error',
// //       uri: req.path
// //     }
// //   })
// // })

// router.get('/searchAddr', searchAddr)
// // router.get('/searchCoord', searchCoord)

// module.exports = router
