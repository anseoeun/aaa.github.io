const { Router } = require('express')
const router = Router()

const noticeList = require('./notice')
const noticeView = require('./noticeView')

// API-H-BFF-001(공지사항 리스트)
router.post('/noticeList', noticeList)

// API-H-BFF-002(공지사항 상세보기)
router.post('/noticeView', noticeView)

module.exports = router
