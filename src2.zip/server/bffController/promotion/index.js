const { Router } = require('express')
const router = Router()

const postAttCatMulti = require('./postAttCatMulti')
const postDiscountList = require('./postDiscountList')
const postNoticeMulti = require('./postNoticeMulti')
const postPromotionEventList = require('./postPromotionEventList')
const postAttNoticeMulti = require('./postAttNoticeMulti')
const postPromotionEventView = require('./postPromotionEventView')
const postAttCarModelList = require('./postAttCarModelList')
const postPromotionCarView = require('./postPromotionCarView')
const postAttEntryUpdate = require('./postAttEntryUpdate')
const postPromotionCarList = require('./postPromotionCarList')
const postDiscountProductList = require('./postDiscountProductList')
const postDiscountProductMainView = require('./postDiscountProductMainView')

// API-P-BFF-001(관심등록 / 해제)
router.post('/postAttCatMulti', postAttCatMulti)

// API-P-BFF-003(할인차리스트)
router.post('/postDiscountList', postDiscountList)

// API-P-BFF-005(다음달 이벤트 알림 받기 정보 등록/해제)
router.post('/postNoticeMulti', postNoticeMulti)

// API-P-BFF-006(판촉차 이벤트 조회)
router.post('/postPromotionEventList', postPromotionEventList)

// API-P-BFF-007(관심이벤트 등록/해제)
router.post('/postAttNoticeMulti', postAttNoticeMulti)

// API-P-BFF-008(판촉차 이벤트 상세 조회)
router.post('/postPromotionEventView', postPromotionEventView)

// API-P-BFF-009 (할인차 차종구분별 모델 리스트 조회)
router.post('/postAttCarModelList', postAttCarModelList)

// API-P-BFF-010(판촉차 차량 상세 조회)
router.post('/postPromotionCarView', postPromotionCarView)

// API-P-BFF-011(판촉차 응모하기)
router.post('/postAttEntryUpdate', postAttEntryUpdate)

// API-P-BFF-012(판촉차 검색 정보 조회)
router.post('/postPromotionCarList', postPromotionCarList)

// API-P-BFF-013(판촉차 검색 정보 조회)
router.post('/postDiscountProductList', postDiscountProductList)

// API-P-BFF-014(할인차 상세 조회)
router.post('/postDiscountProductMainView', postDiscountProductMainView)

module.exports = router
