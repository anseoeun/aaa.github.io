const asyncHandler = require('../../utils/asyncHandler')
const Https = require('../../utils/https')

// API-H-고객정보서비스-003 (관심차량 등록)
// API-E-고객정보서비스-002 (이벤트 관심 고객수 조회)
async function postCarInterest(req, $httpsCustInfo) {
  try {
    const _req = { ...req }
    let querySum = ''
    for (let list in _req.body) {
      querySum = querySum + list + '=' + encodeURI(_req.body[list]) + '&'
    }

    const response = await $httpsCustInfo.post('/event/interest?', querySum)

    const response1 = await $httpsCustInfo.get('/event/interest/count', { params: { ..._req.body } })

    return { api_h_custserver_002: response, api_e_event_002: response1 }
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}

module.exports = asyncHandler(async (req, res, next) => {
  const $httpsCustInfo = Https({ service: 'customer-info', version: 'v1', req })
  const [response] = await Promise.all([postCarInterest(req, $httpsCustInfo)])

  const responses = {
    screenId: '나중에바꿀ID',
    api_h_custserver_002: response.api_h_custserver_002.data,
    api_e_event_002: response.api_e_event_002.data
  }
  res.json(responses)
})
