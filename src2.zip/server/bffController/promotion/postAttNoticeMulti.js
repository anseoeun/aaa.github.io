const asyncHandler = require('../../utils/asyncHandler')
const Https = require('../../utils/https')

// API-E-고객정보서비스-003 (관심이벤트 등록/해제)
async function postAttNoticeMulti(req, $httpsEvent, $httpsCustInfo) {
  try {
    const _req = req
    let querySum = ''
    for (let list in _req.body) {
      querySum = querySum + list + '=' + encodeURI(_req.body[list]) + '&'
    }

    const response = await $httpsCustInfo.post('/event/interest?', querySum)

    const response1 = await $httpsEvent.get('/promotion-car', { params: { ..._req.body } })
    console.log(_req.body)

    return { api_e_custserver_001: response, api_e_event_001: response1 }
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}

module.exports = asyncHandler(async (req, res, next) => {
  const $httpsEvent = Https({ service: 'event', version: 'v1', req })
  const $httpsCustInfo = Https({ service: 'customer-info', version: 'v1', req })

  const [response1] = await Promise.all([postAttNoticeMulti(req, $httpsEvent, $httpsCustInfo)])

  const responses = {
    screenId: '나중에바꿀ID',
    api_e_custserver_001: response1.api_e_custserver_001.data,
    api_e_event_001: response1.api_e_event_001.data
  }

  res.json(responses)
})
