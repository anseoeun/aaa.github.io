const asyncHandler = require('../../utils/asyncHandler')
const Https = require('../../utils/https')

// API-E-고객지원서비스-001 (다음달 이벤트 알림 받기 정보 등록/해제)
async function postNoticeMulti(req, $https) {
  try {
    const response = await $https.post('/event/notification?', req.body)
    return response
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}

module.exports = asyncHandler(async (req, res, next) => {
  const $https = Https({ service: 'customer-support', version: 'v1', req })
  const [response1] = await Promise.all([postNoticeMulti(req, $https)])

  const responses = {
    screenId: '나중에바꿀ID',
    api_e_custserver_001: response1.data
  }

  res.json(responses)
})
