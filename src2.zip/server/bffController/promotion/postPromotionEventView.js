const asyncHandler = require('../../utils/asyncHandler')
const Https = require('../../utils/https')

// API-E-이벤트서비스-002 (판촉차 이벤트 상세조회)
async function getAttEventView(req, $httpsEvent) {
  try {
    const response = await $httpsEvent.get(`/promotion-car/${req.body.salePromotionEventNumber}`)
    return response
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}

// API-E-고객정보서비스-002 (이벤트 관심 고객수 조회)
async function getEventAttCount(req, $httpsCust) {
  try {
    const response = await $httpsCust.get('/event/interest/count', { params: { ...req.body } })

    return response
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}

// API-E-고객정보서비스-001 (관심이벤트 조회)
async function getEventAtt(req, $httpsCust) {
  try {
    const response = await $httpsCust.get('/event/interest', { params: { ...req.body } })

    return response
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}

module.exports = asyncHandler(async (req, res, next) => {
  const $httpsEvent = Https({ service: 'event', version: 'v1', req })
  const $httpsCust = Https({ service: 'customer-info', version: 'v1', req })

  const [response1, response2, response3] = await Promise.all([
    getAttEventView(req, $httpsEvent),
    getEventAttCount(req, $httpsCust),
    getEventAtt(req, $httpsCust)
  ])
  const responses = {
    screenId: '나중에바꿀ID',
    api_e_event_002: response1.data,
    api_e_custinfo_002: response2.data,
    api_e_custinfo_001: response3.data
  }

  res.json(responses)
})
