const asyncHandler = require('../../utils/asyncHandler')
const Https = require('../../utils/https')

// API-E-상품서비스-007 (할인재고차량 차량상세 조회)
async function getDiscountProductMainView(req, $httpsEvent, $httpsPur, $httpsDelAll, $httpsCommon, $httpsPurchase) {
  try {
    const response = await $httpsEvent.get('/discount-car/info', { params: { ...req.body } })
    const resParam = {
      ...response.data.data.discountCarInfo
    }
    const [response2, response3, response4, response5, response6, response7, response8, response9] = await Promise.all([
      getRelCenterList(response.data.data.discountCarInfo.deliveryCenterCode, $httpsPur),
      getCarTrimSpeInfo(response.data.data.discountCarInfo.saleModelCode, $httpsEvent),
      getAreaConsignmentList(resParam, req, $httpsDelAll),
      getEstimationInfoName(resParam, $httpsEvent),
      getDisCarRecInfoList(resParam, req, $httpsEvent),
      getBranchOffView('J01', $httpsPur),
      getContractPossible(resParam, $httpsPurchase),
      getAgencyView($httpsCommon)
    ])

    response.data.data.relCenterList = response2.data

    response.data.data.carTrimSpeInfo = response3.data
    response.data.data.areaConsignmentList = response4.data
    response.data.data.estimationInfoName = response5.data
    response.data.data.disCarRecInfoList = response6.data
    response.data.data.branchOffView = response7.data
    response.data.data.contractPossible = response8.data
    response.data.data.tempData = {
      test1: { ...response2.data },
      test2: { ...response7.data },
      test3: { ...response9.data.data }
    }
    return response
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}

// API-E-상품서비스-008_작업중 (할인, 전시차량 재고 정보 조회)
async function getDiscountProductStockCount(req, $httpsEvent) {
  try {
    const response = await $httpsEvent.get('/discount-car/inventory', { params: { ...req.body } })

    return response
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}

// API-E-상품서비스-010 (전시차량 차량상세 정보 조회)
async function getExhibitionProductMainView(req, $httpsEvent, $httpsPur, $httpsDelAll, $httpsCommon, $httpsPurchase) {
  try {
    const _req = { ...req }
    _req.body = {
      carProductNumber: req.body.carProductionNumber,
      criterionYearMonth: req.body.criterionYearMonth,
      loginId: req.body.loginId
    }
    const response = await $httpsEvent.get('/display-car/info', { params: { ..._req.body } })
    const resParam = {
      ...response.data.data.discountCarInfo
    }

    const [response2, response3, response4, response5, response6, response7, response8, response9] = await Promise.all([
      getRelCenterList(response.data.data.discountCarInfo.deliveryCentercode, $httpsPur),
      getCarTrimSpeInfo(response.data.data.discountCarInfo.saleModelCode, $httpsEvent),
      getAreaConsignmentList(resParam, req, $httpsDelAll),
      getEstimationInfoName(resParam, $httpsEvent),
      getDisCarRecInfoList(resParam, req, $httpsEvent),
      getBranchOffView(resParam.agencyCode, $httpsPur),
      getAgencyView($httpsCommon),
      getContractPossible(resParam, $httpsPurchase)
    ])

    let resp = {
      data: {
        data: {
          discountCarInfo: {
            ...response.data.data.discountCarInfo
          },
          discountPriceInfo: {
            ...response.data.data.discountPriceInfo
          },
          relCenterList: {
            data: {
              deliveryCenterName:
                response7.data && response7.data.data.agency
                  ? response7.data.data.agency.agencyName + ' ' + response7.data.data.agency.agencyTypeName
                  : '',
              deliveryCenterTel:
                response7.data && response7.data.data.agency ? response7.data.data.agency.agencyTel : '',
              deliveryCenterAddress:
                response7.data && response7.data.data.agency
                  ? response7.data.data.agency.agencyAddress1 + response7.data.data.agency.agencyAddress2
                  : '',
              deliveryCenterOpTime:
                '평일 ' +
                response8.data.data[0].chrrName1.substr(0, 2) +
                ':' +
                response8.data.data[0].chrrName1.substr(2, 3) +
                ' ~ ' +
                response8.data.data[0].chrrName2.substr(0, 2) +
                ':' +
                response8.data.data[0].chrrName2.substr(2, 3),
              lat:
                response7.data && response7.data.data && response7.data.data.agency
                  ? response7.data.data.agency.lattitude
                  : 33,
              lon:
                response7.data && response7.data.data && response7.data.data.agency
                  ? response7.data.data.agency.longitude
                  : 125
            }
          },
          carTrimSpeInfo: {
            ...response3.data
          },
          areaConsignmentList: {
            ...response4.data
          },
          estimationInfoName: {
            ...response5.data
          },
          disCarRecInfoList: {
            ...response6.data
          },
          contractPossible: {
            ...response9.data
          },
          tempData: {
            test1: { ...response2.data },
            test2: { ...response7.data },
            test3: { ...response8.data }
          }
        }
      }
    }

    return resp
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}

// API-E-상품서비스-037_작업중 (할인차 바로구매 실시간 베스트 조회 이력 등록)
async function postDiscountBuynowRealtimebestReg(req, $httpsEvent) {
  try {
    const response = await $httpsEvent.post('/discount-car/search-history', req.body)

    return response
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}

// API-E-상품서비스-039_작업중 (할인차 차량확인 사용자 수 조회)
async function getDiscountCatCount(req, $httpsEvent) {
  try {
    let _req = { ...req }
    _req.body.dayCount = 2
    const response = await $httpsEvent.get('/discount-car/customer/count', { params: { ..._req.body } })

    return response
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}

// API-H-상품서비스-079 (차량 트림 제원 정보 조회)
async function getCarTrimSpeInfo(saleModelCode, $httpsEvent) {
  try {
    const response = await $httpsEvent.get('/car/trim-variousfactor/' + saleModelCode)
    return response
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}

// API-H-제휴서비스-005 (탁송료 및 출고센터 조회)
async function getAreaConsignmentList(list, req, $httpsDelAll) {
  try {
    const _list = { ...list }
    _list.query = {
      saleModelCode: list.saleModelCode ? list.saleModelCode : '',
      deliveryAreaCode: req.body.deliveryAreaCode ? req.body.deliveryAreaCode : '',
      deliveryLocalAreaCode: req.body.deliveryLocalAreaCode ? req.body.deliveryLocalAreaCode : '',
      optionCode: list.optionMixCode ? list.optionMixCode : '',
      deliveryCenterCode: list.deliveryCenterCode ? list.deliveryCenterCode : ''
    }
    const response = await $httpsDelAll.get('/consignment-price', { params: { ..._list.query } })

    return response
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}

// API-H-상품서비스-059 (견적정보에 대한 코드명칭을 조회하는 API)
async function getEstimationInfoName(req, $httpsEvent) {
  try {
    const _req = { ...req }
    _req.query = {
      carCode: req.carCode ? req.carCode : '',
      saleModelCode: req.saleModelCode ? req.saleModelCode : '',
      optionMixCode: req.optionMixCode ? req.optionMixCode : '',
      exteriorColorCode: req.exteriorColorCode ? req.exteriorColorCode : '',
      interiorColorCode: req.interiorColorCode ? req.interiorColorCode : '',
      tuixMixCode: req.tuixMixCode ? req.tuixMixCode : '',
      saleTypeCode: req.saleTypeCode ? req.saleTypeCode : '',
      realityInteriorColorCode: req.realityInteriorColorCode ? req.realityInteriorColorCode : ''
    }

    const response = await $httpsEvent.get('/estimation-info-name', { params: { ..._req.query } })
    return response
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}

// API-H-고객지원서비스-015 (출고센터 상세조회)
async function getRelCenterList(dvcCd, $httpsPur) {
  try {
    const response = await $httpsPur.get('/delivery-center/' + dvcCd)
    return response
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}

// API-H-고객지원서비스-010 (영업점 안내정보 상세조회)
async function getBranchOffView(agencyCode, $httpsPur) {
  try {
    const response = await $httpsPur.get('/agency/' + agencyCode)

    return response
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}

// 공통코드 조회(영업점시간)
async function getAgencyView($httpsCommon) {
  try {
    const response = await $httpsCommon.get('/common-code/E/T034')
    return response
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}

// API-E-상품서비스-012 (할인차 유사사양 추천리스트 정보 조회)
async function getDisCarRecInfoList(param, req, $httpsEvent) {
  try {
    const _req = { ...param }
    _req.query = {
      carCode: param.carCode ? param.carCode : '',
      carProductionNumber: req.body.carProductionNumber
    }

    const response = await $httpsEvent.get('/discount-car/similar-car', { params: { ..._req.query } })
    return response
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}

//API-E-구매서비스-001 (계약가능 정보 조회)
async function getContractPossible(param, $httpsPurchase) {
  try {
    const _req = {
      siteTypeCode: 'E', //임직몰
      saleModelCode: param.saleModelCode,
      optionMixCode: param.optionMixCode,
      productionCarNumber: param.carProductionNumber
    }

    const response = await $httpsPurchase.get('/contract/possible/info', { params: { ..._req } })

    return response
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}

module.exports = asyncHandler(async (req, res, next) => {
  const $httpsEvent = Https({ service: 'product', version: 'v1', req })
  const $httpsPur = Https({ service: 'purchase-guide^customer-support', version: 'v1', req })
  const $httpsDelAll = Https({ service: 'delivery^alliance', version: 'v1', req })
  const $httpsCommon = Https({ service: 'common', version: 'v1', req })
  const $httpsPurchase = Https({ service: 'purchase', version: 'v1', req })

  const [
    response1,
    response2,
    response3,
    response4,
    // response5,
    response6
  ] = await Promise.all([
    getDiscountProductMainView(req, $httpsEvent, $httpsPur, $httpsDelAll, $httpsCommon, $httpsPurchase),
    getDiscountProductStockCount(req, $httpsEvent),
    postDiscountBuynowRealtimebestReg(req, $httpsEvent),
    getExhibitionProductMainView(req, $httpsEvent, $httpsPur, $httpsDelAll, $httpsCommon, $httpsPurchase),
    getDiscountCatCount(req, $httpsEvent)
  ])

  const responses = {
    screenId: '나중에바꿀ID',
    api_e_product_007: response1.data,
    api_e_product_008: response2.data,
    api_e_product_037: response3.data,
    api_e_product_010: response4.data,
    api_e_product_039: response6.data
  }

  res.json(responses)
})
