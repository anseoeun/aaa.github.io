const asyncHandler = require('../../utils/asyncHandler')
const Https = require('../../utils/https')
const FormData = require('form-data')

// API-E-공통서비스-004 (파일 업로드)
// API-E-고객지원서비스-006 (1:1문의 등록)
async function getPaymentamountInfo(req, $httpsCommon, $httpsCustomer) {
  try {
    const _req = req
    let response = {
      data: ''
    }

    if (_req.file) {
      const form = new FormData()
      form.append('file', _req.file.buffer, {
        filename: _req.file.originalname,
        originalname: _req.file.originalname,
        encoding: _req.file.encoding,
        mimetype: _req.file.mimetype,
        size: _req.file.size
      })
      form.append('customerNumber', _req.body.customerNumber)
      form.append('privateYn', _req.body.privateYn)
      form.append('fileBizTypeCode', _req.body.fileBizTypeCode)

      response = await $httpsCommon.post('/file/upload/files', form , {'headers':{'Content-Type':`multipart/form-data; boundary=${form._boundary}`}})

      if (response && response.rspStatus && response.rspStatus.rspCode !== '0000') {
        return { api_e_comm_004: response }
      }
    }

    let strGroupSn = response && response.data && response.data.data ? response.data.data.fileGroupSn : 0
    _req.body.inquiryParam = JSON.parse(_req.body.inquiryParam)
    _req.body.inquiryParam.fileGroupSeq = strGroupSn
    console.log('call :>> ', _req.body)
    if($httpsCustomer.defaults.headers.post){
      $httpsCustomer.defaults.headers.post['Content-Type'] = 'application/json'
    }
    const respons2 = await $httpsCustomer.post('/inquiry', _req.body.inquiryParam)
    
    console.log('respons2 :>> ', respons2)
    return { api_e_comm_004: response.data, api_e_cust_006: respons2.data }
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}

module.exports = asyncHandler(async (req, res, next) => {
  const $httpsCommon = Https({ service: 'common', version: 'v1', req })
  const $httpsCustomer = Https({ service: 'customer-support', version: 'v1', req })

  const [response1] = await Promise.all([getPaymentamountInfo(req, $httpsCommon, $httpsCustomer)])

  const response = {
    screenId: '나중에 만들 id',
    api_e_popup_003: response1
  }
  // console.log(response)
  res.json(response)
})
