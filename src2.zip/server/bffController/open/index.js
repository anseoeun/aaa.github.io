const { Router } = require('express')
const router = Router()
const asyncHandler = require('../../utils/asyncHandler')
const Https = require('../../utils/https')

// 오픈시승-012(시승예약내역) EIS
const getBookingList = asyncHandler(async (req, res, next) => {
  const $https = Https({ service: 'drive', req })
  const response = await $https.post('/v10/rest/bookingList.do', req.body)
  const { infoResponse, DisplayResponse } = response.data
  res.json({
    data: DisplayResponse,
    rspStatus: {
      rspCode: infoResponse.rsp_CD ? (infoResponse.rsp_CD === '200' ? '0000' : infoResponse.rsp_CD) : '1000',
      rspMessage: infoResponse.rsp_MESSAGE || 'I/F Server Error',
      uri: req.path
    }
  })
})

// 오픈시승-013(시승예약취소) EIS
const cancelBooking = async (req, res, next) => {
  const $https = Https({
    service: 'drive',
    req,
    headers: {
      'Content-Type': 'application/json'
    }
  })
  try {
    const response = await $https.post('/v10/rest/bookingList.do', req.body)
    const { infoResponse, DisplayResponse } = response.data
    res.json({
      data: DisplayResponse,
      rspStatus: {
        rspCode: infoResponse.rsp_CD ? (infoResponse.rsp_CD === '200' ? '0000' : infoResponse.rsp_CD) : '1000',
        rspMessage: infoResponse.rsp_MESSAGE || 'I/F Server Error',
        uri: req.path
      }
    })
  } catch (e) {
    console.log(e)
  }
}

router.post('/bookingList', getBookingList)
router.post('/bookingCancel', cancelBooking)

module.exports = router
