const Https = require('../../utils/https')

/************ 의존성 ************/
/*
1) API-E-결제서비스-011 (임직원 할인 리스트 조회)

=> API-E-결제서비스-013 (판매조건 변동사항 체크 정보 조회)
   (employeeLossCode 직원차량손실코드, customerTypeCode 고객유형코드)

=> API-H-결제서비스-009 (블루멤버스 적립예정 포인트 조회)
   (customerTypeCode 고객유형코드)

2) API-E-구매-009 계약정보
=> API-H-상품서비스-059 (견적정보에 대한 코드명칭을 조회하는 API)
   (carCode, saleModelCode, optionMixCode, exteriorColorCode, interiorColorCode, tuixMixCode)
*/

async function getDataSet1(req, $httpsMsaPayment) {
  const { saleContractNo } = req.body
  const result = {
    api_e_payment_011: null,
    api_e_payment_013: null
  }
  try {
    //API-E-결제서비스-011 (임직원 할인 리스트 조회)
    const response = await $httpsMsaPayment.get('/discount/member', {
      params: {
        eeno: req.body.eeno,
        eenm: req.body.eenm,
        birthDate: req.body.birthDate
      }
    })
    result.api_e_payment_011 = response && response.data
  } catch (err) {
    result.api_e_payment_011 = {
      message: err.message,
      config: err.config
    }
    return result
  }

  try {
    //API-E-결제서비스-013 (판매조건 변동사항 체크 정보 조회)
    const response = await $httpsMsaPayment.get('/sale-condition/check', {
      params: {
        saleContractNo
      }
    })
    result.api_e_payment_013 = response && response.data
  } catch (err) {
    result.api_e_payment_013 = {
      message: err.message,
      config: err.config
    }
  }

  return result
}

async function getDataSet2(req, $httpsMsaPurchase, $httpsMsaProduct, $httpsMsaSaleCondition, $httpsMsaEstimation) {
  const { contractNumber } = req.body
  let params = {
    contractNumber
  }

  const result = {
    api_e_purchase_009: null,
    api_h_product_059: null,
    api_h_payment_016: null,
    api_h_estimate_018: null
  }
  try {
    //API-E-구매서비스-009 (계약정보 조회)
    const response = await $httpsMsaPurchase.get('/contract/contract-info/' + contractNumber)
    result.api_e_purchase_009 = response && response.data
    // eslint-disable-next-line no-unexpected-multiline
    const {
      carCode,
      saleModelCode,
      optionMixCode,
      exteriorColorCode,
      interiorColorCode,
      realityInteriorColorCode,
      tuixMixCode,
      productionCarNumber,
      salePromotionEventNumber,
      estimationNumber
    } = response.data.data
    params = {
      ...params,
      carCode: carCode || '',
      optionMixCode: optionMixCode || '',
      salePromotionEventNo: salePromotionEventNumber || '',
      exteriorColorCode: exteriorColorCode || '',
      interiorColorCode: interiorColorCode || '',
      realityInteriorColorCode: realityInteriorColorCode || '',
      tuixMixCode: tuixMixCode || '',
      saleModelCode: saleModelCode || '',
      carProductionNo: productionCarNumber || '',
      estimationNumber: estimationNumber,
      saleTypeCode: 'XX'
    }
  } catch (err) {
    result.api_e_purchase_009 = {
      message: err.message,
      config: err.config
    }
    return result
  }

  // API-H-결제서비스-009 (블루멤버스 적립예정 포인트 조회)
  try {
    const response = await $httpsMsaSaleCondition.get('/point/save-blue-point', {
      params: {
        carCode: params.carCode,
        customerTypeCode: '05'
      }
    })
    result.api_h_payment_009 = response && response.data
  } catch (err) {
    result.api_h_payment_009 = {
      message: err.message,
      config: err.config
    }
  }

  try {
    //API-H-상품서비스-059 (견적정보에 대한 코드명칭을 조회하는 API)
    const response = await $httpsMsaProduct.get('/estimation-info-name', {
      params
    })
    result.api_h_product_059 = response && response.data
  } catch (err) {
    result.api_h_product_059 = {
      message: err.message,
      config: err.config
    }
  }

  try {
    if (params.carProductionNo) {
      // API-H-결제서비스-016 (생산월 차량할인 정보 조회)
      // eslint-disable-next-line no-const-assign
      const response = await $httpsMsaSaleCondition.get('/discount/car/production-month', {
        params
      })
      result.api_h_payment_016 = response && response.data
    } else {
      // eslint-disable-next-line no-const-assign
      result.api_h_payment_016 = {
        message: '차량생산번호가 없습니다.',
        config: null
      }
    }
  } catch (err) {
    result.api_h_payment_016 = {
      message: err.message,
      config: err.config
    }
  }

  try {
    // API-H-결제서비스-002 (차량 할인 리스트 조회)
    const response = await $httpsMsaSaleCondition.get('/discount/car', {
      params: {
        saleModelCode: params.saleModelCode
      }
    })
    result.api_h_payment_002 = response && response.data
  } catch (err) {
    result.api_h_payment_002 = {
      message: err.message,
      config: err.config
    }
  }

  try {
    // API-H-결제서비스-004 (타겟 할인 리스트 조회)
    const response = await $httpsMsaSaleCondition.get('/discount/target', {
      params: {
        saleModelCode: params.saleModelCode,
        carOptionCode: params.optionMixCode
      }
    })

    result.api_h_payment_004 = response && response.data
  } catch (err) {
    result.api_h_payment_004 = {
      message: err.message,
      config: err.config
    }
  }

  try {
    // API-H-결제서비스-011 (금융프로모션 상품리스트 조회)
    const response = await $httpsMsaSaleCondition.get('/payment/promotion/' + params.saleModelCode)

    result.api_h_payment_011 = response && response.data
  } catch (err) {
    result.api_h_payment_011 = {
      message: err.message,
      config: err.config
    }
  }

  try {
    // API-H-결제서비스-003 (금리 할인 리스트 조회)
    const response = await $httpsMsaSaleCondition.get('/discount/interest/' + params.saleModelCode, params)

    result.api_h_payment_003 = response && response.data
  } catch (err) {
    result.api_h_payment_003 = {
      message: err.message,
      config: err.config
    }
  }

  if (params.estimationNumber) {
    try {
      // API-H-견적서비스-018 (견적 결제 및 할인정보 상세조회)
      const response = await $httpsMsaEstimation.get('/info/payment-discount/' + params.estimationNumber)

      result.api_h_estimate_018 = response && response.data
    } catch (err) {
      result.api_h_estimate_018 = {
        message: err.message,
        config: err.config
      }
    }
  } else {
    result.api_h_estimate_018 = {
      message: '견적 번호가 없습니다.',
      config: null
    }
  }

  return result
}

// E-구매서비스012(명의자 정보 조회), E-결제서비스-032(블루멤버스 가용포인트 조회)
async function getContractNaminfo(req, $httpsMsaPurchase, $httpsMsaPayment) {
  const result = {
    api_e_purchase_012: null,
    api_e_payment_032: null
  }
  let params = {}

  try {
    // API-E-구매서비스-012 (명의자 정보 조회)
    const response = await $httpsMsaPurchase.get('/contract/nam/info', {
      params: {
        contractNumber: req.body.contractNumber,
        electronicSignatureTypeCode: 'A'
      }
    })

    response.data.data.relationPersonList.filter((obj) => {
      if (obj.relationPersonTypeCode === '01') {
        params = {
          customerNumber: obj.customerManagemontNumber
        }
      }
    })

    result.api_e_purchase_012 = response && response.data
  } catch (err) {
    result.api_e_purchase_012 = {
      message: err.message,
      config: err.config
    }
  }

  if (params.customerNumber) {
    try {
      // API-E-결제서비스-032 (블루멤버스 가용포인트 조회)
      const response = await $httpsMsaPayment.get('/point/available-blue-point', {
        params: {
          customerNumber: params.customerNumber
        }
      })

      result.api_e_payment_032 = response && response.data
    } catch (err) {
      result.api_e_payment_032 = {
        message: err.message,
        config: err.config
      }
    }
  } else {
    result.api_e_payment_032 = {
      message: '주계약자 정보가 없습니다.',
      config: null
    }
  }
  return result
}

// API-E-구매서비스-072 (인수정보 조회)
async function getAcquisitionInfo(req, $httpsMsaPurchase) {
  try {
    const response = await $httpsMsaPurchase.get('/acquisition/info', {
      params: {
        contractNumber: req.body.contractNumber
      }
    })

    return response.data
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}
// API-E-결제서비스-002 (선지급 정보 조회)
async function getAdvancepayment(req, $httpsMsaPayment) {
  try {
    const response = await $httpsMsaPayment.get('/advance-payment', {
      params: {
        saleContractNo: req.body.saleContractNo
      }
    })
    return response.data
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}
// API-E-결제서비스-003 (차량대금 결제정보 조회)
async function getPaymentamountInfo(req, $httpsMsaPayment) {
  try {
    const response = await $httpsMsaPayment.get('/payment-amount/info', {
      params: {
        saleContractNo: req.body.saleContractNo
      }
    })
    return response.data
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}

// API-E-결제서비스-038 (결제기한 정보 조회)
async function getTimeLimitInfo(req, $httpsMsaPayment) {
  try {
    const response = await $httpsMsaPayment.get('/time-limit/info', {
      params: {
        saleContractNo: req.body.saleContractNo
      }
    })
    return response.data
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}

module.exports = async (req, res, next) => {
  const $httpsMsaProduct = Https({
    service: 'product',
    version: 'v1',
    req
  })
  const $httpsMsaPayment = Https({
    service: 'payment',
    version: 'v1',
    req
  })
  const $httpsMsaPurchase = Https({
    service: 'purchase',
    version: 'v1',
    req
  })
  const $httpsMsaSaleCondition = Https({
    service: 'sale-condition',
    version: 'v1',
    req
  })
  const $httpsMsaEstimation = Https({
    service: 'estimation',
    version: 'v1',
    req
  })

  const [
    { api_e_payment_011, api_e_payment_013 },
    {
      api_e_purchase_009,
      api_h_product_059,
      api_h_payment_016,
      api_h_payment_002,
      api_h_payment_004,
      api_h_payment_009,
      api_h_payment_011,
      api_h_payment_003,
      api_h_estimate_018
    },
    api_e_purchase_072,
    api_e_payment_002,
    api_e_payment_003,
    { api_e_purchase_012, api_e_payment_032 },
    api_e_payment_038
  ] = await Promise.all([
    getDataSet1(req, $httpsMsaPayment, $httpsMsaSaleCondition),
    getDataSet2(req, $httpsMsaPurchase, $httpsMsaProduct, $httpsMsaSaleCondition, $httpsMsaEstimation),
    getAcquisitionInfo(req, $httpsMsaPurchase),
    getAdvancepayment(req, $httpsMsaPayment),
    getPaymentamountInfo(req, $httpsMsaPayment),
    getContractNaminfo(req, $httpsMsaPurchase, $httpsMsaPayment),
    getTimeLimitInfo(req, $httpsMsaPayment)
  ])

  const response = {
    screenId: 'UI_M_결제_1100A',
    api_e_payment_011,
    api_e_payment_013,
    api_e_purchase_009,
    api_h_product_059,
    api_h_payment_016,
    api_h_payment_002,
    api_h_payment_004,
    api_h_payment_009,
    api_h_estimate_018,
    api_e_purchase_072,
    api_e_payment_002,
    api_e_payment_003,
    api_h_payment_011,
    api_e_purchase_012,
    api_e_payment_032,
    api_e_payment_038,
    api_h_payment_003
  }

  console.log('response: ', response)
  res.json(response)
}
