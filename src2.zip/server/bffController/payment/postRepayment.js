const asyncHandler = require('../../utils/asyncHandler')
const Https = require('../../utils/https')

// API-E-결제서비스-003 (차량대금 결제정보 조회)
async function getPaymentamountInfo(req, $httpsMsaPayment) {
  try {
    const response = await $httpsMsaPayment.get('/payment-amount/info', {
      params: {
        saleContractNo: req.body.saleContractNo
      }
    })

    return response.data
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}
// API-E-결제서비스-039 (다시 결제 대상 조회)
async function getAgainRequestTarget(req, $httpsMsaPayment) {
  try {
    const response = await $httpsMsaPayment.get('/again/request/target', {
      params: {
        saleModelCode: req.body.saleModelCode,
        contractNumber: req.body.contractNumber,
        saleContractNo: req.body.contractNumber,
        customerManagementNumber: req.body.customerManagementNumber
      }
    })
    return response.data
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}
// API-E-구매서비스-012 (명의자 정보 조회)
async function getContractNaminfo(req, $httpsMsaPurchase) {
  try {
    const response = await $httpsMsaPurchase.get('/contract/nam/info', {
      params: {
        contractNumber: req.body.contractNumber,
        electronicSignatureTypeCode: 'A'
      }
    })
    return response.data
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}

// API-H-결제서비스-002 (차량 할인 리스트 조회)
async function getDiscountCar(req, $httpsMsaSaleCondition) {
  try {
    const response = await $httpsMsaSaleCondition.get('/discount/car', {
      params: {
        saleModelCode: req.body.saleModelCode
      }
    })
    return response.data
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}

module.exports = asyncHandler(async (req, res, next) => {
  const $httpsMsaPayment = Https({
    service: 'payment',
    version: 'v1',
    req
  })
  const $httpsMsaPurchase = Https({
    service: 'purchase',
    version: 'v1',
    req
  })
  const $httpsMsaSaleCondition = Https({
    service: 'sale-condition',
    version: 'v1',
    req
  })

  const [api_e_payment_003, api_e_payment_039, api_e_purchase_012, api_h_payment_002] = await Promise.all([
    getPaymentamountInfo(req, $httpsMsaPayment),
    getAgainRequestTarget(req, $httpsMsaPayment),
    getContractNaminfo(req, $httpsMsaPurchase),
    getDiscountCar(req, $httpsMsaSaleCondition)
  ])

  const response = {
    screenId: 'UI_M_2110A',
    api_e_payment_003,
    api_e_payment_039,
    api_e_purchase_012,
    api_h_payment_002
  }

  console.log('response: ', response)
  res.json(response)
})