const { Router } = require('express')
const router = Router()

// API-H-BFF-007(결제하기 화면)
router.post('/', require('./postPayment'))

// API-H-BFF-008(다시결제/결제변경 화면)
router.post('/repayment', require('./postRepayment'))

// API-H-BFF-009(추가결제 화면)
router.post('/addpayment', require('./postAddPayment'))

// API-H-BFF-010(결제완료 화면)
router.post('/complete', require('./postCompletePayment'))

module.exports = router
