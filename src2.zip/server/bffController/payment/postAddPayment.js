const asyncHandler = require('../../utils/asyncHandler')
const Https = require('../../utils/https')

// API-E-결제서비스-040 (추가 결제 대상 조회)
async function getAddRequestTarget(req, $httpsMsaPayment) {
  try {
    const response = await $httpsMsaPayment.get('/add/request/target', {
      params: {
        saleContractNo: req.body.saleContractNo
      }
    })
    return response.data
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}
// API-E-구매서비스-012 (명의자 정보 조회)
async function getContractNaminfo(req, $httpsMsaPurchase) {
  try {
    const response = await $httpsMsaPurchase.get('/contract/nam/info', {
      params: {
        contractNumber: req.body.contractNumber,
        electronicSignatureTypeCode: 'A'
      }
    })
    return response.data
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}

module.exports = asyncHandler(async (req, res, next) => {
  const $httpsMsaPayment = Https({ service: 'payment', version: 'v1', req })
  const $httpsMsaPurchase = Https({ service: 'purchase', version: 'v1', req })

  const [api_e_payment_040, api_e_purchase_012] = await Promise.all([
    getAddRequestTarget(req, $httpsMsaPayment),
    getContractNaminfo(req, $httpsMsaPurchase)
  ])
  const response = {
    screenId: 'UI_M_결제_2300A',
    api_e_payment_040,
    api_e_purchase_012
  }

  console.log('response: ', response)
  res.json(response)
})
