const asyncHandler = require('../../utils/asyncHandler')
const Https = require('../../utils/https')

// API-E-결제서비스-002 (선지급 정보 조회)
async function getAdvancepayment(req, $httpsMsaPayment) {
  try {
    const response = await $httpsMsaPayment.get('/advance-payment', {
      params: { saleContractNo: req.body.saleContractNo }
    })
    return response.data
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}

// API-E-결제서비스-003 (차량대금 결제정보 조회)
async function getPaymentamountInfo(req, $httpsMsaPayment) {
  try {
    const response = await $httpsMsaPayment.get('/payment-amount/info', {
      params: { saleContractNo: req.body.saleContractNo }
    })
    return response.data
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}

// API-E-결제서비스-006	결제진행요청완료조회
async function getPaymentRequest(req, $httpsMsaPayment) {
  try {
    const response = await $httpsMsaPayment.get('/request', {
      params: { saleContractNo: req.body.saleContractNo }
    })
    return response.data
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}

// API-E-결제서비스-015	증빙서류조회
async function getPaymentDocumentaryEvidence(req, $httpsMsaPayment) {
  try {
    const response = await $httpsMsaPayment.get('/documentary-evidence', {
      params: { contractNumber: req.body.contractNumber }
    })
    return response.data
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}

// API-E-구매서비스-072 (인수정보 조회)
async function getAcquisitionInfo(req, $httpsMsaPurchase) {
  try {
    const response = await $httpsMsaPurchase.get('/acquisition/info', {
      params: { contractNumber: req.body.contractNumber }
    })
    return response.data
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}

// API-E-구매서비스-009 계약정보 조회 => API-H-고객지원서비스-015 (출고센터 상세조회) 또는 전시차량의 경우 API-H-고객지원서비스-030 (전시차량 전시지점 조회)
async function getDeliveryCenter(req, $httpsMsaPurchase, $httpsMsaPurchaseGuide, $httpsMsaCS) {
  const { saleContractNo } = req.body
  try {
    // API-E-구매서비스-009 계약정보 조회
    const api_e_purchase_009 = await $httpsMsaPurchase.get(`/contract/contract-info/${saleContractNo}`)

    // API-H-고객지원서비스-015 (출고센터 상세조회) 또는 전시차량의 경우 API-H-고객지원서비스-030 (전시차량 전시지점 조회)
    let { deliveryCenterCode } = api_e_purchase_009.data ? api_e_purchase_009.data.data : {}
    let api_h_purchaseGuide_015
    if (deliveryCenterCode) {
      api_h_purchaseGuide_015 = await $httpsMsaPurchaseGuide.get(`/delivery-center/${deliveryCenterCode}`)
    }

    const result = {
      api_e_purchase_009: api_e_purchase_009.data,
      api_h_purchaseGuide_015: api_h_purchaseGuide_015.data
    }

    return result
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}

module.exports = asyncHandler(async (req, res, next) => {
  const $httpsMsaPayment = Https({ service: 'payment', version: 'v1', req })
  const $httpsMsaPurchase = Https({ service: 'purchase', version: 'v1', req })
  const $httpsMsaPurchaseGuide = Https({ service: 'purchase-guide', version: 'v1', req })
  const $httpsMsaCS = Https({ service: 'customer-support', version: 'v1', req })

  const [
    api_e_payment_002,
    api_e_payment_003,
    api_e_payment_006,
    api_e_payment_015,
    api_e_purchase_072,
    api_e_purchase_result
  ] = await Promise.all([
    getAdvancepayment(req, $httpsMsaPayment),
    getPaymentamountInfo(req, $httpsMsaPayment),
    getPaymentRequest(req, $httpsMsaPayment),
    getPaymentDocumentaryEvidence(req, $httpsMsaPayment),
    getAcquisitionInfo(req, $httpsMsaPurchase),
    getDeliveryCenter(req, $httpsMsaPurchase, $httpsMsaPurchaseGuide, $httpsMsaCS)
  ])

  const response = {
    screenId: 'UI_M_결제_C3210A',
    api_e_payment_002,
    api_e_payment_003,
    api_e_payment_006,
    api_e_payment_015,
    api_e_purchase_072,
    api_e_purchase_result
  }

  console.log('response: ', response)
  res.json(response)
})
