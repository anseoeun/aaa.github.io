const { Router } = require('express')
const router = Router()

const getCarTax = require('./getCarTax')
const getCarArea = require('./getCarArea')

// EP_IF_카젠시_009 지역별 취득세공채정보
router.get('/carTax', getCarTax)
router.get('/carArea', getCarArea)

module.exports = router
