const asyncHandler = require('../../utils/asyncHandler')
const Https = require('../../utils/https')

// API-H-공통서비스-007 (GNB 메뉴 전체 조회)
async function getGnbMenus(req, $httpsCommon) {
  const { gnbType, siteType, imageSectionCode } = req.query
  try {
    const response = await $httpsCommon.get(`/gnb/menus/${gnbType}`, {
      params: { siteType, imageSectionCode }
    })
    return response.data
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}
// API-H-공통서비스-008 (세션전체속성조회)
async function getUserInfo(req, $httpsSession) {
  const { sessionId } = req.query
  try {
    const response = await $httpsSession.get('/attributes', {
      params: { sessionId: `employee-${sessionId}` }
    })
    return response.data
  } catch (err) {
    return {
      message: req,
      config: err.config
    }
  }
}
// API-E-공통서비스-015 (MY알림 건수 조회)
async function getNoticeCount($httpsCommon) {
  try {
    const response = await $httpsCommon.get('/notification/count')
    return response.data
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}

module.exports = asyncHandler(async (req, res, next) => {
  const $httpsCommon = Https({ service: 'common', version: 'v1', req })
  const $httpsSession = Https({ service: 'session', version: 'v1', req })

  const [response1, response2, response3] = await Promise.all([
    getGnbMenus(req, $httpsCommon),
    getUserInfo(req, $httpsSession),
    getNoticeCount($httpsCommon)
  ])

  const response = {
    gnbMenus: response1.data,
    userInfo: response2.data,
    noticeCount: response3.data
  }

  res.json(response)
})
