const asyncHandler = require('../../utils/asyncHandler')
const Https = require('../../utils/https')


// API-H-상품서비스-062 (차량상세 Key Visual 정보 조회)
async function getKeyVisual(req, $httpsProduct) {
  const { carEngName, siteTypeCode } = req.query
  try {
    const response = await $httpsProduct.get(`/car/key-visual/${carEngName}`, {
      params: { siteTypeCode }
    })
    return response.data
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}
// API-H-고객정보서비스-004 (관심차량 등록 카운트)
async function getInterestCount(req, query, $httpsCustomer) {
  const { customerNumber, carCode } = query
  try {
    const response = await $httpsCustomer.get('/car/interest/count', {
      params: { customerNumber, carCode }
    })
    return response.data
  } catch (err) {
    return {
      message: req,
      config: err.config
    }
  }
}

module.exports = asyncHandler(async (req, res, next) => {
  const $httpsProduct = Https({ service: 'product', version: 'v1', req })
  const $httpsCustomer = Https({ service: 'customer-info', version: 'v1', req })

  const response1 = await getKeyVisual(req, $httpsProduct)
  const carCode = response1.data.carCode || ''
  const { customerNumber } = req.query
  const response2 = await getInterestCount(req, { customerNumber, carCode }, $httpsCustomer)

  const response = {
    keyVisual: response1.data,
    interestCount: response2.data
  }

  res.json(response)
})
