const asyncHandler = require('../../utils/asyncHandler')
const Https = require('../../utils/https')

// API-H-구매가이드서비스-003 (영업점 전시차량 조회)
module.exports = asyncHandler(async (req, res, next) => {
  const $https = Https({ service: 'purchase-guide', version: 'v1', req })
  const response = await $https.get(req.path, { params: { ...req.query } })
  if (response.data == null || response.data.data == null) {
    console.log(response.data)
    const dummyResponse = {
      data: [
        {
          agencyTypeName: '지점',
          agencyCode: 'E55',
          agencyName: '일 산',
          carCode: 'IG02',
          carName: '그랜저',
          saleModelCode: 'IGJS4TFT3',
          carDetail: '그랜저IG 자가용 가솔린 2.4 EXCLUSIVE SPECIAL A/T 19MY',
          exteriorColorCode: 'WC9',
          exteriorColorName: '화이트크림',
          interiorColorName: '브라운투톤',
          carTimName: 'EXCLUSIVE SPECIAL',
          carEnginName: '가솔린 2.4',
          filePath: null
        },
        {
          agencyTypeName: '지점',
          agencyCode: 'E55',
          agencyName: '일 산',
          carCode: 'DN01',
          carName: '쏘나타',
          saleModelCode: 'DNJS4SBT1',
          carDetail: 'DN8 자가용 가솔린 2.0 CVVL 프리미엄 오토 런칭',
          exteriorColorCode: 'Y2E',
          exteriorColorName: '플레임레드',
          interiorColorName: '블랙모노톤',
          carTimName: '프리미엄',
          carEnginName: '가솔린 2.0 CVVL',
          filePath: null
        }
      ],
      rspStatus: {
        rspCode: '0000',
        rspMessage: '성공',
        uri: 'http://localhost:8095/v1/purchase-guide/agency/display-cars?agencyCode=E55'
      }
    }
    return res.json(dummyResponse)
  }
  res.json(response.data)
})
