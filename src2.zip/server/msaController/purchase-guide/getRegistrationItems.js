const asyncHandler = require('../../utils/asyncHandler')
const Https = require('../../utils/https')

// API-H-구매가이드서비스-008 (등록비 기초정보 조회)
module.exports = asyncHandler(async (req, res, next) => {
  const $https = Https({ service: 'purchase-guide', version: 'v1', req })
  const response = await $https.get(req.path, { params: { ...req.query } })
  if (response.data == null || response.data.data == null) {
    console.log(response.data)
    const dummyResponse = {
      data: {
        registerCondition: [
          {
            conditionCode: '7',
            conditionName: '5.18 민주부상자 1급 (면세)'
          },
          {
            conditionCode: '8',
            conditionName: '고엽제등급판정자 고도~경도(면세)'
          },
          {
            conditionCode: '2',
            conditionName: '국가유공상이자 1~7급 (면세)'
          },
          {
            conditionCode: '1',
            conditionName: '일반장애 1급~3급(시각징애 3급 포함)(면세)'
          },
          {
            conditionCode: '9',
            conditionName: '일반장애 4급~6급 (과세)'
          }
        ],
        registerArea: [
          {
            govBondAreaCode: '1',
            govBondAreaName: '강원',
            registerSubArea: [
              {
                govBondSubAreaCode: '1-1',
                govBondSubAreaName: '강릉시'
              },
              {
                govBondSubAreaCode: '1-10',
                govBondSubAreaName: '인제군'
              },
              {
                govBondSubAreaCode: '1-11',
                govBondSubAreaName: '정선군'
              },
              {
                govBondSubAreaCode: '1-12',
                govBondSubAreaName: '철원군'
              },
              {
                govBondSubAreaCode: '1-13',
                govBondSubAreaName: '춘천시'
              },
              {
                govBondSubAreaCode: '1-14',
                govBondSubAreaName: '태백시'
              },
              {
                govBondSubAreaCode: '1-15',
                govBondSubAreaName: '평창군'
              },
              {
                govBondSubAreaCode: '1-16',
                govBondSubAreaName: '홍천군'
              },
              {
                govBondSubAreaCode: '1-17',
                govBondSubAreaName: '화천군'
              },
              {
                govBondSubAreaCode: '1-18',
                govBondSubAreaName: '횡성군'
              },
              {
                govBondSubAreaCode: '1-2',
                govBondSubAreaName: '고성군'
              },
              {
                govBondSubAreaCode: '1-3',
                govBondSubAreaName: '동해시'
              },
              {
                govBondSubAreaCode: '1-4',
                govBondSubAreaName: '삼척시'
              },
              {
                govBondSubAreaCode: '1-5',
                govBondSubAreaName: '속초시'
              },
              {
                govBondSubAreaCode: '1-6',
                govBondSubAreaName: '양구군'
              },
              {
                govBondSubAreaCode: '1-7',
                govBondSubAreaName: '양양군'
              },
              {
                govBondSubAreaCode: '1-8',
                govBondSubAreaName: '영월군'
              },
              {
                govBondSubAreaCode: '1-9',
                govBondSubAreaName: '원주시'
              }
            ]
          },
          {
            govBondAreaCode: '2',
            govBondAreaName: '경기',
            registerSubAreaString: '',
            registerSubArea: [
              {
                govBondSubAreaCode: '2-1',
                govBondSubAreaName: '가평군'
              },
              {
                govBondSubAreaCode: '2-10',
                govBondSubAreaName: '동두천시'
              },
              {
                govBondSubAreaCode: '2-11',
                govBondSubAreaName: '부천시'
              },
              {
                govBondSubAreaCode: '2-12',
                govBondSubAreaName: '성남시'
              },
              {
                govBondSubAreaCode: '2-13',
                govBondSubAreaName: '수원시'
              },
              {
                govBondSubAreaCode: '2-14',
                govBondSubAreaName: '시흥시'
              },
              {
                govBondSubAreaCode: '2-15',
                govBondSubAreaName: '안산시'
              },
              {
                govBondSubAreaCode: '2-16',
                govBondSubAreaName: '안성시'
              },
              {
                govBondSubAreaCode: '2-17',
                govBondSubAreaName: '안양시'
              },
              {
                govBondSubAreaCode: '2-18',
                govBondSubAreaName: '양주시'
              },
              {
                govBondSubAreaCode: '2-19',
                govBondSubAreaName: '양평군'
              },
              {
                govBondSubAreaCode: '2-2',
                govBondSubAreaName: '고양시'
              },
              {
                govBondSubAreaCode: '2-20',
                govBondSubAreaName: '여주시'
              },
              {
                govBondSubAreaCode: '2-21',
                govBondSubAreaName: '연천군'
              },
              {
                govBondSubAreaCode: '2-22',
                govBondSubAreaName: '오산시'
              },
              {
                govBondSubAreaCode: '2-23',
                govBondSubAreaName: '용인시'
              },
              {
                govBondSubAreaCode: '2-24',
                govBondSubAreaName: '의왕시'
              },
              {
                govBondSubAreaCode: '2-25',
                govBondSubAreaName: '의정부시'
              },
              {
                govBondSubAreaCode: '2-26',
                govBondSubAreaName: '이천시'
              },
              {
                govBondSubAreaCode: '2-27',
                govBondSubAreaName: '파주시'
              },
              {
                govBondSubAreaCode: '2-28',
                govBondSubAreaName: '평택시'
              },
              {
                govBondSubAreaCode: '2-29',
                govBondSubAreaName: '포천시'
              },
              {
                govBondSubAreaCode: '2-3',
                govBondSubAreaName: '과천시'
              },
              {
                govBondSubAreaCode: '2-30',
                govBondSubAreaName: '하남시'
              },
              {
                govBondSubAreaCode: '2-31',
                govBondSubAreaName: '화성시'
              },
              {
                govBondSubAreaCode: '2-4',
                govBondSubAreaName: '광명시'
              },
              {
                govBondSubAreaCode: '2-5',
                govBondSubAreaName: '광주시'
              },
              {
                govBondSubAreaCode: '2-6',
                govBondSubAreaName: '구리시'
              },
              {
                govBondSubAreaCode: '2-7',
                govBondSubAreaName: '군포시'
              },
              {
                govBondSubAreaCode: '2-8',
                govBondSubAreaName: '김포시'
              },
              {
                govBondSubAreaCode: '2-9',
                govBondSubAreaName: '남양주시'
              }
            ]
          },
          {
            govBondAreaCode: '3',
            govBondAreaName: '경남',
            registerSubAreaString: '',
            registerSubArea: [
              {
                govBondSubAreaCode: '3-1',
                govBondSubAreaName: '거제시'
              },
              {
                govBondSubAreaCode: '3-10',
                govBondSubAreaName: '의령군'
              },
              {
                govBondSubAreaCode: '3-11',
                govBondSubAreaName: '진주시'
              },
              {
                govBondSubAreaCode: '3-12',
                govBondSubAreaName: '창녕군'
              },
              {
                govBondSubAreaCode: '3-13',
                govBondSubAreaName: '통영시'
              },
              {
                govBondSubAreaCode: '3-14',
                govBondSubAreaName: '하동군'
              },
              {
                govBondSubAreaCode: '3-15',
                govBondSubAreaName: '함안군'
              },
              {
                govBondSubAreaCode: '3-16',
                govBondSubAreaName: '함양군'
              },
              {
                govBondSubAreaCode: '3-17',
                govBondSubAreaName: '합천군'
              },
              {
                govBondSubAreaCode: '3-2',
                govBondSubAreaName: '거창군'
              },
              {
                govBondSubAreaCode: '3-3',
                govBondSubAreaName: '고성군'
              },
              {
                govBondSubAreaCode: '3-4',
                govBondSubAreaName: '김해시'
              },
              {
                govBondSubAreaCode: '3-5',
                govBondSubAreaName: '남해군'
              },
              {
                govBondSubAreaCode: '3-6',
                govBondSubAreaName: '밀양시'
              },
              {
                govBondSubAreaCode: '3-7',
                govBondSubAreaName: '사천시'
              },
              {
                govBondSubAreaCode: '3-8',
                govBondSubAreaName: '산청군'
              },
              {
                govBondSubAreaCode: '3-9',
                govBondSubAreaName: '양산시'
              }
            ]
          },
          {
            govBondAreaCode: '5',
            govBondAreaName: '경북',
            registerSubAreaString: '',
            registerSubArea: [
              {
                govBondSubAreaCode: '5-1',
                govBondSubAreaName: '경산시'
              },
              {
                govBondSubAreaCode: '5-10',
                govBondSubAreaName: '성주군'
              },
              {
                govBondSubAreaCode: '5-11',
                govBondSubAreaName: '안동시'
              },
              {
                govBondSubAreaCode: '5-12',
                govBondSubAreaName: '영덕군'
              },
              {
                govBondSubAreaCode: '5-13',
                govBondSubAreaName: '영양군'
              },
              {
                govBondSubAreaCode: '5-14',
                govBondSubAreaName: '영주시'
              },
              {
                govBondSubAreaCode: '5-15',
                govBondSubAreaName: '영천시'
              },
              {
                govBondSubAreaCode: '5-16',
                govBondSubAreaName: '예천군'
              },
              {
                govBondSubAreaCode: '5-17',
                govBondSubAreaName: '울릉군'
              },
              {
                govBondSubAreaCode: '5-18',
                govBondSubAreaName: '울진군'
              },
              {
                govBondSubAreaCode: '5-19',
                govBondSubAreaName: '의성군'
              },
              {
                govBondSubAreaCode: '5-2',
                govBondSubAreaName: '경주시'
              },
              {
                govBondSubAreaCode: '5-20',
                govBondSubAreaName: '청도군'
              },
              {
                govBondSubAreaCode: '5-21',
                govBondSubAreaName: '청송군'
              },
              {
                govBondSubAreaCode: '5-22',
                govBondSubAreaName: '칠곡군'
              },
              {
                govBondSubAreaCode: '5-23',
                govBondSubAreaName: '포항시'
              },
              {
                govBondSubAreaCode: '5-3',
                govBondSubAreaName: '고령군'
              },
              {
                govBondSubAreaCode: '5-4',
                govBondSubAreaName: '구미시'
              },
              {
                govBondSubAreaCode: '5-5',
                govBondSubAreaName: '군위군'
              },
              {
                govBondSubAreaCode: '5-6',
                govBondSubAreaName: '김천시'
              },
              {
                govBondSubAreaCode: '5-7',
                govBondSubAreaName: '문경시'
              },
              {
                govBondSubAreaCode: '5-8',
                govBondSubAreaName: '봉화군'
              },
              {
                govBondSubAreaCode: '5-9',
                govBondSubAreaName: '상주시'
              }
            ]
          },
          {
            govBondAreaCode: '14',
            govBondAreaName: '전남',
            registerSubAreaString: '',
            registerSubArea: [
              {
                govBondSubAreaCode: '14-1',
                govBondSubAreaName: '강진군'
              },
              {
                govBondSubAreaCode: '14-10',
                govBondSubAreaName: '보성군'
              },
              {
                govBondSubAreaCode: '14-11',
                govBondSubAreaName: '순천시'
              },
              {
                govBondSubAreaCode: '14-12',
                govBondSubAreaName: '신안군'
              },
              {
                govBondSubAreaCode: '14-13',
                govBondSubAreaName: '여수시'
              },
              {
                govBondSubAreaCode: '14-14',
                govBondSubAreaName: '영광군'
              },
              {
                govBondSubAreaCode: '14-15',
                govBondSubAreaName: '영암군'
              },
              {
                govBondSubAreaCode: '14-16',
                govBondSubAreaName: '완도군'
              },
              {
                govBondSubAreaCode: '14-17',
                govBondSubAreaName: '장성군'
              },
              {
                govBondSubAreaCode: '14-18',
                govBondSubAreaName: '장흥군'
              },
              {
                govBondSubAreaCode: '14-19',
                govBondSubAreaName: '진도군'
              },
              {
                govBondSubAreaCode: '14-2',
                govBondSubAreaName: '고흥군'
              },
              {
                govBondSubAreaCode: '14-20',
                govBondSubAreaName: '함평군'
              },
              {
                govBondSubAreaCode: '14-21',
                govBondSubAreaName: '해남군'
              },
              {
                govBondSubAreaCode: '14-22',
                govBondSubAreaName: '화순군'
              },
              {
                govBondSubAreaCode: '14-3',
                govBondSubAreaName: '곡성군'
              },
              {
                govBondSubAreaCode: '14-4',
                govBondSubAreaName: '광양시'
              },
              {
                govBondSubAreaCode: '14-5',
                govBondSubAreaName: '구례군'
              },
              {
                govBondSubAreaCode: '14-6',
                govBondSubAreaName: '나주시'
              },
              {
                govBondSubAreaCode: '14-7',
                govBondSubAreaName: '담양군'
              },
              {
                govBondSubAreaCode: '14-8',
                govBondSubAreaName: '목포시'
              },
              {
                govBondSubAreaCode: '14-9',
                govBondSubAreaName: '무안군'
              }
            ]
          },
          {
            govBondAreaCode: '15',
            govBondAreaName: '전북',
            registerSubAreaString: '',
            registerSubArea: [
              {
                govBondSubAreaCode: '15-1',
                govBondSubAreaName: '고창군'
              },
              {
                govBondSubAreaCode: '15-10',
                govBondSubAreaName: '임실군'
              },
              {
                govBondSubAreaCode: '15-11',
                govBondSubAreaName: '장수군'
              },
              {
                govBondSubAreaCode: '15-12',
                govBondSubAreaName: '전주시'
              },
              {
                govBondSubAreaCode: '15-13',
                govBondSubAreaName: '정읍시'
              },
              {
                govBondSubAreaCode: '15-14',
                govBondSubAreaName: '진안군'
              },
              {
                govBondSubAreaCode: '15-2',
                govBondSubAreaName: '군산시'
              },
              {
                govBondSubAreaCode: '15-3',
                govBondSubAreaName: '김제시'
              },
              {
                govBondSubAreaCode: '15-4',
                govBondSubAreaName: '남원시'
              },
              {
                govBondSubAreaCode: '15-5',
                govBondSubAreaName: '무주군'
              },
              {
                govBondSubAreaCode: '15-6',
                govBondSubAreaName: '부안군'
              },
              {
                govBondSubAreaCode: '15-7',
                govBondSubAreaName: '순창군'
              },
              {
                govBondSubAreaCode: '15-8',
                govBondSubAreaName: '완주군'
              },
              {
                govBondSubAreaCode: '15-9',
                govBondSubAreaName: '익산시'
              }
            ]
          },
          {
            govBondAreaCode: '17',
            govBondAreaName: '충남',
            registerSubAreaString: '',
            registerSubArea: [
              {
                govBondSubAreaCode: '17-1',
                govBondSubAreaName: '계룡시'
              },
              {
                govBondSubAreaCode: '17-10',
                govBondSubAreaName: '아산시'
              },
              {
                govBondSubAreaCode: '17-11',
                govBondSubAreaName: '예산군'
              },
              {
                govBondSubAreaCode: '17-12',
                govBondSubAreaName: '천안시'
              },
              {
                govBondSubAreaCode: '17-13',
                govBondSubAreaName: '청양군'
              },
              {
                govBondSubAreaCode: '17-14',
                govBondSubAreaName: '태안군'
              },
              {
                govBondSubAreaCode: '17-15',
                govBondSubAreaName: '홍성군'
              },
              {
                govBondSubAreaCode: '17-2',
                govBondSubAreaName: '공주시'
              },
              {
                govBondSubAreaCode: '17-3',
                govBondSubAreaName: '금산군'
              },
              {
                govBondSubAreaCode: '17-4',
                govBondSubAreaName: '논산시'
              },
              {
                govBondSubAreaCode: '17-5',
                govBondSubAreaName: '당진시'
              },
              {
                govBondSubAreaCode: '17-6',
                govBondSubAreaName: '보령시'
              },
              {
                govBondSubAreaCode: '17-7',
                govBondSubAreaName: '부여군'
              },
              {
                govBondSubAreaCode: '17-8',
                govBondSubAreaName: '서산시'
              },
              {
                govBondSubAreaCode: '17-9',
                govBondSubAreaName: '서천군'
              }
            ]
          },
          {
            govBondAreaCode: '18',
            govBondAreaName: '충북',
            registerSubAreaString: '',
            registerSubArea: [
              {
                govBondSubAreaCode: '18-1',
                govBondSubAreaName: '괴산군'
              },
              {
                govBondSubAreaCode: '18-10',
                govBondSubAreaName: '청주시'
              },
              {
                govBondSubAreaCode: '18-11',
                govBondSubAreaName: '충주시'
              },
              {
                govBondSubAreaCode: '18-2',
                govBondSubAreaName: '단양군'
              },
              {
                govBondSubAreaCode: '18-3',
                govBondSubAreaName: '보은군'
              },
              {
                govBondSubAreaCode: '18-4',
                govBondSubAreaName: '영동군'
              },
              {
                govBondSubAreaCode: '18-5',
                govBondSubAreaName: '옥천군'
              },
              {
                govBondSubAreaCode: '18-6',
                govBondSubAreaName: '음성군'
              },
              {
                govBondSubAreaCode: '18-7',
                govBondSubAreaName: '제천시'
              },
              {
                govBondSubAreaCode: '18-8',
                govBondSubAreaName: '증평군'
              },
              {
                govBondSubAreaCode: '18-9',
                govBondSubAreaName: '진천군'
              }
            ]
          }
        ],
        certificateStamp: '2600',
        carNumberPayment: '25000',
        agencyFee: '55000'
      },
      rspStatus: {
        rspCode: '0000',
        rspMessage: '성공',
        uri: 'http://127.0.0.1:8095/v1/purchase-guide/registration/items'
      }
    }
    return res.json(dummyResponse)
  }
  res.json(response.data)
})
