const { Router } = require('express')
const reqApiHandler = require('../reqApiHandler')
const reqGetGuideApi = reqApiHandler({ method: 'GET', service: 'purchase-guide', version: 'v1' })
const getAgencyDisplayCars = require('./getAgencyDisplayCars')
const getDisplayCarAgencies = require('./getDisplayCarAgencies')
const getRegistrationItems = require('./getRegistrationItems')
const getRegistrationFees = require('./getRegistrationFees')
const router = Router()

// API-H-구매가이드서비스-001 (영업점 조회)
router.get('/agencies', reqGetGuideApi)
// API-H-구매가이드서비스-003 (영업점 전시차량 조회)
// - 002번을 먼저 놓을경우 002로 분류 되어 003으로 분기를 타지 않음
router.get('/agency/display-cars', getAgencyDisplayCars)
// API-H-구매가이드서비스-002 (영업점 안내정보 상세조회) / API-H-고객지원서비스-010 (영업점 안내정보 상세조회)
router.get('/agency/:agencyCode', reqGetGuideApi)
// API-H-구매가이드서비스-004 (트림별 전시차량 보유 영업점 조회)
router.get('/display-car/agencies', getDisplayCarAgencies)
// API-H-구매가이드서비스-005 (카마스터 리스트 조회)
router.get('/car-masters', reqGetGuideApi)
// API-H-구매가이드서비스-006 (출고센터 조회)
router.get('/delivery-center', reqGetGuideApi)
// API-H-구매가이드서비스-007 (출고센터 상세조회)
// _ TODO : check! 네이밍룰에 따르면 위의 것이랑 동일하게 되어 Detail추가
router.get('/delivery-center/:deliveryCentercode', reqGetGuideApi)
// API-H-구매가이드서비스-008 (등록비 기초정보 조회) _ TODO :API미완성 쿼리에러 반환
router.get('/registration/items', getRegistrationItems)
// API-H-구매가이드서비스-009 (등록,취득세 및 공채금액 조회) _ TODO :API 연동규격서와 응답값이 동일하지 않음
router.get('/registration/fees', getRegistrationFees)
// API-H-고객지원서비스-018 (지역별 썬팅지정 장착점 리스트 조회)
router.get('/mount-centers', reqGetGuideApi)
// API-H-구매가이드서비스-011 (썬팅지정 장착점 상세조회) _ TODO :API미완성 404
router.get('/mount-center/:mountCode', reqGetGuideApi)
// API-H-구매가이드서비스-012 (장착점 주소 조회)
router.get('/area-code', reqGetGuideApi)

module.exports = router
