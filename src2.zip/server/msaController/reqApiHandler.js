const Https = require('../utils/https')

module.exports = (options = {}) => {
  return async (req, res, next) => {
    const { method, service, version, url, query, sessionId } = options
    const ver = version || 'v1'
    const path = req ? (method === 'GET' ? req.path : req.url) : url
    const data = req ? (method === 'GET' ? req.query : req.body) : query
    const $https = Https({ service, version: ver, req, sessionId })

    try {
      const response =
        method === 'GET' ? await $https.get(path, { params: { ...data } }) : await $https.post(path, data)
      if (res) {
        res.json(response.data)
      } else {
        return [response.data, null]
      }
    } catch (e) {
      console.log(e)
      if (next) {
        next()
      } else {
        return [null, e]
      }
    }
  }
}
