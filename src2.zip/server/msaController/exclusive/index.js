const { Router } = require('express')
const router = Router()
const reqApiHandler = require('../reqApiHandler')
const reqGetExclusiveApi = reqApiHandler({ method: 'GET', service: 'exclusive', version: 'v1' })
const reqPostExclusiveApi = reqApiHandler({ method: 'POST', service: 'exclusive', version: 'v1' })

// API-E-전담컨설턴트-127 (전담처리정보 제출서류삭제)
router.post('/mypage/document', reqPostExclusiveApi)

// API-E-전담컨설턴트-130 등록대행업체(행정사) 목록 조회(조회전용)
router.get('/setting/registration-firms-list', reqGetExclusiveApi)

// API-E-전담컨설턴트-034 (등록대행정보 조회)
router.get('/work/regist-agency/:contractNumber', reqGetExclusiveApi)

module.exports = router
