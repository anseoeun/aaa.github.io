const asyncHandler = require('../../utils/asyncHandler')
const Https = require('../../utils/https')
const FormData = require('form-data')

// API-E-공통서비스-005 (추가 파일 업로드)
module.exports = asyncHandler(async (req, res, next) => {
  const $https = Https({ service: 'common', version: 'v1', req })
  const form = new FormData()
  form.append('file', req.file.buffer, {
    filename: req.file.originalname,
    originalname: req.file.originalname,
    encoding: req.file.encoding,
    mimetype: req.file.mimetype,
    size: req.file.size
  })
  form.append('customerNumber', req.body.customerNumber)
  form.append('privateYn', req.body.privateYn)
  form.append('fileGroupSn', req.body.fileGroupSn)

  const response = await $https.post(req.url, form , {'headers':{'Content-Type':`multipart/form-data; boundary=${form._boundary}`}})
  res.json(response.data)
})
