const { Router } = require('express')
const reqApiHandler = require('../reqApiHandler')
const reqGetDeliveryApi = reqApiHandler({ method: 'GET', service: 'delivery', version: 'v1' })
const reqGetDeliveryAllianceApi = reqApiHandler({ method: 'GET', service: 'delivery^alliance', version: 'v1' })
const router = Router()

// API-H-차량배송서비스-001 (즉시 출고가능한 유사사양 차량 정보 조회)
router.get('/car/similar-car', reqGetDeliveryApi)
// API-H-차량배송서비스-002 (지역/출고예정일별 탁송료 정보 조회)
router.get('/consignment-fee', reqGetDeliveryApi)
// API-H-제휴서비스-003 (출고센터별 TP탁송료 조회)
router.get('/tp-consignment-fee', reqGetDeliveryApi)
// API-H-제휴서비스-005 (탁송료 및 출고센터 조회)
router.get('/consignment-price', reqGetDeliveryAllianceApi)

module.exports = router
