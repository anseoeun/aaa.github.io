const { Router } = require('express')
const router = Router()

// 공통
router.use('/common', require('./common'))
// 상품
router.use('/product', require('./product'))
// 개인화
router.use('/personalization', require('./personalization'))
// 견적
router.use('/estimation', require('./estimation'))
// 판매조건금융
router.use('/sale-condition', require('./sale-condition'))
// 구매
router.use('/purchase', require('./purchase'))
// 구매 가이드
router.use('/purchase-guide', require('./purchase-guide'))
// 고객지원
router.use('/customer-support/', require('./customer-support/'))
// 고객정보
router.use('/customer-info', require('./customer-info'))
// 차량배송
router.use('/delivery', require('./delivery'))
// 결제
router.use('/payment', require('./payment'))
// 이벤트
router.use('/event', require('./event'))
// 전담
router.use('/exclusive', require('./exclusive'))

module.exports = router
