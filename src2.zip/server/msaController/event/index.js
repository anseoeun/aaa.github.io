const { Router } = require('express')
const reqApiHandler = require('../reqApiHandler')
const reqGetEventApi = reqApiHandler({ method: 'GET', service: 'event', version: 'v1' })
const reqPostEventApi = reqApiHandler({ method: 'POST', service: 'event', version: 'v1' })
const router = Router()

// API-E-이벤트서비스-018 (나의 판촉차 신청내역 정보 조회)
router.get('/promotion-car/entries', reqGetEventApi)
// API-E-이벤트서비스-019 (나의 판촉차 신청 정보 상세조회)
router.get('/promotion-car/entry/:promotionSeq', reqGetEventApi)
// API-E-이벤트서비스-020 (판촉차 통합 검색 정보 조회)
router.get('/promotion-car/search/cars', reqGetEventApi)
// API-E-이벤트서비스-021 (판촉차 신청 취소)
router.post('/promotion-car/cancellation', reqPostEventApi)

module.exports = router
