const { Router } = require('express')
const reqApiHandler = require('../reqApiHandler')
const reqGetPersonalApi = reqApiHandler({ method: 'GET', service: 'personalization', version: 'v1' })
const router = Router()


// API-H-개인화추천서비스-001 (엔진 추천 정보 조회)
router.get('/recommendation/engin', reqGetPersonalApi)
// API-H-개인화추천서비스-002 (트림 추천 정보 조회)
router.get('/recommendation/trim', reqGetPersonalApi)
// API-H-개인화추천서비스-003 (연령별 외장색상 추천 정보 조회)
router.get('/recommendation/exterior-color', reqGetPersonalApi)
// API-H-개인화추천서비스-004 (옵션 추천 리스트 조회)
router.get('/recommendation/option', reqGetPersonalApi)
// API-H-개인화추천서비스-005 (메인_나를 위한 추천 차량 리스트 조회)
router.get('/recommendation/my-car', reqGetPersonalApi)
// API-H-개인화추천서비스-006 (내차만들기 추천결과 차량 리스트 조회)
router.get('/recommendation/estimation-cars', reqGetPersonalApi)
// API-H-개인화추천서비스-007 (연령대별 판매 TOP3 차량 리스트)
router.get('/recommendation/top3-cars', reqGetPersonalApi)
// API-H-개인화추천서비스-008 (개인화 상세 내역 정보 조회)
router.get('/recommendation/customer/case', reqGetPersonalApi)

module.exports = router
