const axios = require('axios')
const config = require('../../../nuxt.config.js')
const { env } = config
const baseUrl = env.API_GATEWAY_PATH
const exclusiveUrl = env.EXCLUSIVE_PATH
const cookieparser = require('cookieparser')
const ip = require('ip')

// MSA API Gateway base uri
const gateWayBaseUri = (service = '', version) => {
  const ver = version ? `/${version}` : ''
  let serviceName = service
  /**
   * MSA Service 조정으로 인해 병합된 service이름 변경조치
   * 기본 uri 규칙
   * { serviceName(변경된이름) }{ version }{ service(원래이름) }
   */
  if (service === 'session') {
    serviceName = 'common'
  } else if (service === 'purchase-guide') {
    serviceName = 'customer-support'
  } else if (service === 'personalization') {
    serviceName = 'customer-info'
  } else if (service === 'delivery') {
    serviceName = 'alliance'
  } else if (service === 'sale-condition') {
    serviceName = 'payment'
  } else if (service.indexOf('^') !== -1) {
    serviceName = service.split('^')[1]
    service = service.split('^')[0]
  } 
  
  return service === 'exclusive'
    ? `${exclusiveUrl}${ver}/${service}`
    : `${baseUrl}/${serviceName}${ver}/${service}`
}

// 인터페이스 URL
const eisUrl = {
  // 카젠시
  cargency: `${baseUrl}/cg-eis/cargency/carsvc`,
  // 블루링크
  bluelink: `${baseUrl}/eis/bluelink/tmsif/PtlWs`,
  // 블루멤버스
  blueMembers: `${baseUrl}/aw-eis/AXWAY/bluemembers`,
  // 오픈시승
  drive: `${baseUrl}/aw-eis/AXWAY/HDRIVE`,
  // 통합검색
  search: `${baseUrl}/eis/wisenut`,
  // juso.go.kr
  juso: `${baseUrl}/eis/juso`,
  // 국내판매
  domestic: `${baseUrl}/hds-eis/domestic-sales`,
  // 카카오페이
  kakaopay: `${baseUrl}/eis/kakaopay/api/v1`
}

// axios 버퍼
const $axiosDict = {}
const Https = (options = {}) => {
  const { service, version, req, sessionId, customHeaders = {}, url } = options
  // console.log(baseUrl)

  // API Version
  const ver = version && version !== '' ? `/${version}` : ''
  // Base URL
  const baseURL = eisUrl[service]
    ? `${eisUrl[service]}${ver}` // 인터페이스 (EIS)
    : gateWayBaseUri(service, version) // MSA API
  // IP Address
  const ipAddress = req ? req.headers['x-forwarded-for'] || req.connection.remoteAddress : ip.address()
  // Session ID
  let jsessionid = ''
  let pageUrl = ''
  if (req) {
    // SessionID
    if (req.headers.sessionid) {
      jsessionid = req.headers.sessionid || ''
    }
    if (jsessionid === '' && req.headers.cookie) {
      const parsed = cookieparser.parse(req.headers.cookie)
      jsessionid = parsed.sessionId || ''
    }
    // page URL
    if (req.headers.url) {
      pageUrl = req.headers.url || ''
    }
    if (pageUrl === '' && req.headers.cookie) {
      const parsed = cookieparser.parse(req.headers.cookie)
      pageUrl = parsed.url || ''
    }
  } else {
    jsessionid = sessionId || ''
    pageUrl = url || ''
  }

  // Http request Header
  const headers = {
    'api-Key': '54afb4e2-123d-44c2-a24d-43fa7dbfb761',
    'x-b3-sampled': 1,
    'ep-ip': ipAddress,
    'ep-channel': 'employee',
    'ep-jsessionid': jsessionid,
    'ep-menu-id': pageUrl,
    ...customHeaders
  }

  if(!$axiosDict[service]) {
    $axiosDict[service] = axios.create({ baseURL, headers })
  } else {
    $axiosDict[service].defaults.headers = headers
  }
  return $axiosDict[service]
}

module.exports = Https
