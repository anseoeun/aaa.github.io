/*  입력 문자열을 캐멀 문자열로 만듭니다
    - 일단 소문자로 전환후에 언더바 이후의 문자를 대문자로 변환합니다.
    리턴값: 캐멀 형식의 문자열
 */
const changeToCamel = (str) => {
  return str.toLowerCase().replace(/_([a-z])/g, function(g) {
    return g[1].toUpperCase()
  })
}
// 객체의 프로퍼티명을 캐멀형으로 수정합니다
exports.changeObjToCamel = (obj) => {
  const newObj = {}
  for (const key in obj) {
    const val = obj[key]
    newObj[changeToCamel(key)] = val
  }
  return newObj
}
