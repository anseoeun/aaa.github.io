const express = require('express')
const bodyParser = require('body-parser')
const logger = require('morgan')
const path = require('path')
const app = express()
const msaController = require('./msaController')
const bffController = require('./bffController')

app.use(bodyParser.json())
app.use(logger('short'))
const publicPath = path.resolve(__dirname, 'log')
app.use(express.static(publicPath))


// Import API
app.use(msaController)
app.use(bffController)

export default {
  path: '/api',
  handler: app
}
