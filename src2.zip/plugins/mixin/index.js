import Vue from 'vue'
import DefaultMixin from './default-mixin.js'

Vue.mixin(DefaultMixin)
