import $ from 'jquery'

export default {
  data() {
    return {
    }
  },
  updated() {
  },
  mounted() {
    if(this.pageTitle) {
      this.setSubject()
    }
    if(this.headerBtns) {
      this.setHomebutton()
      this.setListbutton()
    }
  },
  methods: {
    //page title
    setSubject() {
      this.$nuxt.$emit('subject', this.pageTitle)
    },

    //header buttons
    setHomebutton() {
      this.$nuxt.$emit('home', this.headerBtns.home)
    },
    setListbutton() {
      this.$nuxt.$emit('list', this.headerBtns.list)
    },

    //interaction
    setGoTop() {
      $('body, html').stop().animate({ 'scrollTop' : '0' }, 200)
    },
  },
}
