// import createPersistedState from 'vuex-persistedstate'

// export default ({ store }) => {
//   window.onNuxtReady(() => {
//     createPersistedState({
//       // key: 'yourkey',
//       // paths: [...]
//       // ...
//     })(store)
//   })
// }

// https://codesandbox.io/s/80k4m2598
// 클라이언트에서 지속되는 애플리케이션 상태
