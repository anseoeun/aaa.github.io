import Vue from 'vue'
import Element from 'element-ui'
import locale from 'element-ui/lib/locale/lang/ko'
import * as components from '../components/element'

export default ({ env }) => {
  Vue.use(Element, { locale })
  Object.entries(components).forEach(([name, component]) => {
    Vue.component(name, component)
  })
  Vue.mixin({
    computed: {
      BASE_PATH: () => env.BASE_PATH,
      CONT_PATH: () => env.CONT_PATH,
      CARD_EVENT_LINK_HOST: () => env.CARD_EVENT_LINK_HOST
    }
  })
}
