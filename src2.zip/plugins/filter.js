import Vue from 'vue'
import he from 'he'

const filters = {
  capitalize: (value) => {
    if (!value) return ''
    value = value.toString()
    return value.charAt(0).toUpperCase() + value.slice(1)
  },
  // 내용: 숫자 문자열에 천단위로 컴마를 추가합니다
  amount: (value) => {
    if (!value) return ''
    value = value.toString()
    return value.replace(/\B(?=(\d{3})+(?!\d))/g, ',')
  },

  amountPrice: (value) => {
    if (!value || value === '0'  || value === 0) return '-'
    const num = parseInt(value)
    const val = parseInt(num / 10000)
    return val.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',')
  },

  numberWithCommas: (value) => {
    return value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',')
  },

  currency: (num) => {
    return (+num || 0).toString().replace(/^-?\d+/g, (m) => m.replace(/(?=(?!\b)(\d{3})+$)/g, ','))
  },

  currencyTenThousand: (num) => {
    num = num / 10000
    return (+num || 0).toString().replace(/^-?\d+/g, (m) => m.replace(/(?=(?!\b)(\d{3})+$)/g, ','))
  },

  krYYYYMMDDHHMI: (value) => {
    if (value !== null && value !== undefined) {
      const year = value.substring(0, 4)
      const month = value.substring(4, 6)
      const day = value.substring(6, 8)
      const hour = value.substring(8, 10)
      const minute = value.substring(10, 12)
      return `${year}년 ${month}월 ${day}일 ${hour}시 ${minute}분`
    } else {
      return null
    }
  },

  phone: (num) => {
    return num.replace(/(^02.{0}|^01.{1}|[0-9]{3})([0-9]+)([0-9]{4})/, '$1-$2-$3')
  },

  unescape: (htmlEntity) => {
    return he.unescape(htmlEntity)
  }
}

Object.keys(filters).forEach((key) => {
  Vue.filter(key, filters[key])
})

export default (app, inject) => {
  inject('filter', filters)
}
