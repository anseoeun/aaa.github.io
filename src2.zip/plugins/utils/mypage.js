import moment from 'moment'
/**
 * 구매프로세스대분류코드	E	T030
 */
export const PROCESS_CATEGORY_CODE = {
  A10: 'STEP1_CONSTRACT', //계약
  A20: 'STEP2_VEHICLE_PREPARATION', //차량준비
  A30: 'STEP3_PAYMENT', //결제
  A40: 'STEP4_ON_DELIVERY', //탁송
  A50: 'STEP5_TAKEOVER_COMPLETED', //인수완료
  A60: 'STEP6_TAX_EXEMPTION' //면세신고
}

export const MYPAGE_CASE = {
  // A10 -------------------
  CONT_APPLIED: {
    ocsc: ['0043', '0044', '0045'],
    mypage_step: '계약신청',
    getHeader: function(cd) {
      let o = {}
      o.title = `${moment().format('MM/DD')} 계약신청`
      o.desc_blue = `${moment(cd.contractStartDate, 'YYYYMMDD').format('YYYY년 MM월 DD일(dddd)')} 오전 09:00시 예상출고일 확정 후`
      o.desc = '계약 작성 하시기 바랍니다'
      return o
    },
    getStep: function({ contractDetail: cd, carExemInfo: car }) {
        this.blnCarAssigned = !(cd.assignmentDate === null && cd.assignmentRequestDate !== null)
        this.rightTopText = (!this.blnCarAssigned)? car.exemplificationDateText : ''
        return [
        {
            label: '예상출고일',
            //                              배정차량              배정요청차량
            content: (this.blnCarAssigned)? '즉시 출고 가능' : car.exemplificationDateText  ,
            detailBadge1: true,
            isPrimary1: `${car.notSettledYn === 'Y' ? true : false}`, // false : 그레이, true: 블루
            badgeName1: `${car.notSettledYn === 'Y' ? '확정' : '미확정'}`, // 미확정, 확정, 변경
            detailBadge2: false, // badgeName2:''
            detailPopover: true,
            detailPopoverKey: 'ANTICIPATION'
        },
        {
            label: '예상 확정 시간',
            content: `${moment(cd.contractStartDate, 'YYYYMMDD').format(
            'YYYY년 MM월 DD일(ddd)'
            )} 09:00 예상 출고일 안내 예정`,
            detailPopover: false
        }
        ]
    },
    rightTopText : '',   //YYYY년 MM월 N째주 출고 예정
    blnCarAssigned : false //배정차량 여부   (true :배정차량 , false:배정요청차량)
  },
  CONT_APPLIED_COMFIRMED: {
    ocsc: ['0046', '0047'],
    mypage_step: '계약신청[확정]',
    getHeader: function(cd) {
      let o = {}
      o.title = `${moment().format('MM/DD')} 계약신청`
      o.desc_blue = ''
      o.desc = `계약작성을 시작할 수 있습니다. 계약작성 시작 후, 3시간 내에 계약완료 바랍니다.`
      return o
    },
    getStep: function({ contractDetail: cd, carExemInfo: car }) {
        this.blnCarAssigned = !(cd.assignmentDate === null && cd.assignmentRequestDate !== null)
        this.rightTopText = (!this.blnCarAssigned)? car.exemplificationDateText : ''
        //                              배정차량              배정요청차량
        const cont = (this.blnCarAssigned)? '즉시 출고 가능' : car.exemplificationDateText
        return [
            {
                label: '예상 출고일',
                content: cont,
                detailBadge1: true,
                isPrimary1: `${car.notSettledYn === 'Y' ? true : false}`, // false : 그레이, true: 블루
                badgeName1: `${car.notSettledYn === 'Y' ? '확정' : '미확정'}`, // 미확정, 확정, 변경
                detailBadge2: false, // badgeName2:''
                detailPopover: false
            },
            {
                label: '계약 가능 시간',
                content: `${moment(cd.contractStartDate, 'YYYYMMDDHHmm').format('YYYY년 MM월 DD일(ddd) HH:mm')} ~
                ${moment( cd.contractCompletionLimitDate, 'YYYYMMDDHHmm' ).format('YYYY년 MM월 DD일(ddd) HH:mm')} 까지`,
                detailPopover: false
            }
        ]
    },
    rightTopText : ''  , //YYYY년 MM월 N째주 출고 예정
    blnCarAssigned : false //배정차량 여부   (true :배정차량 , false:배정요청차량)
  },
  CONT_APPLIED_CHANGED: {
    ocsc: ['0947', '0941'],
    mypage_step: '계약신청[변경]',
    getHeader: function(cd) {
      let o = {}
      o.title = `${moment().format('MM/DD')} 계약신청`
      o.desc_blue = ''
      o.desc = `계약작성을 시작할 수 있습니다. 계약작성 시작 후, 72시간 내에 계약완료 바랍니다.`
      return o
    },
    getStep: function({ contractDetail: cd, carExemInfo: car }) {
        this.rightTopText = car.exemplificationDateText
        return [
            {
                label: '예상 출고일',
                content: `${car.exemplificationDateText}`,
                detailBadge1: true,
                isPrimary1: true, // false : 그레이, true: 블루
                badgeName1: '변경',
                detailBadge2: false, // badgeName2:''
                detailPopover: false
            },
            {
                label: '계약 가능 시간',
                content: `${moment(cd.contractStartDate, 'YYYYMMDDHHmm').format('YYYY년 MM월 DD일(ddd) HH:mm')}
                ~ ${moment(cd.contractCompletionLimitDate, 'YYYYMMDDHHmm').format('YYYY년 MM월 DD일(ddd) HH:mm')} 까지`,
                detailPopover: false
            }
        ]
    },
    rightTopText : ''   //( 항상표시 ) YYYY년 MM월 N째주 출고 예정
  },
  CONT_CANCEL_SOLDOUT: { // 계약신청취소[품절]
    ocsc: ['0946'],
    mypage_step: '계약신청 취소',
    getHeader: function(cd) {
      let o = {}
      o.title = `${moment(cd.cancelDate, 'YYYYMMDD').format('MM/DD')} 계약신청 취소`
      o.desc_blue = ''
      o.desc = `안타깝게도 품절로 인해 선택할 차량을 계약 할 수 없습니다. 다른 차량을 선택해주세요.`
      return o
    },
    getStep: function({ contractDetail: cd, carExemInfo: car }) {
      return [
        {
          label: '취소 사유',
          content: `품절, 출고 불가`,
          detailBadge1: false,
          isPrimary1: false, // false : 그레이, true: 블루
          badgeName1: '',
          detailBadge2: false, // badgeName2:''
          detailPopover: false
        },
        {
          label: '취소 시간',
          content: `${moment(cd.cancelDate, 'YYYYMMDDHHmm').format('YYYY년 MM월 DD일(ddd) HH:mm')}`,
          detailPopover: false
        }
      ]
    }
  },
  CONT_CANCEL_CUSTOMER: {  //계약신청취소[고객]
    // 이 케이스는 계약으로서의 의미를 상실했으므로, 리스트에서 링크 제거함 (2019.10. 김경선 수석님)
    // 0016 - 여기에추가 (임의) 20.02.15 계약취소도 리스트에서 표시시킴
    ocsc: ['0049','0016'],
    mypage_step: '계약취소',
    getHeader: function(cd) {
      let o = {}
      o.title = `${moment(cd.cancelDate, 'YYYYMMDDHHmm').format('MM/DD')} 계약신청 취소`
      o.desc_blue = ''
      o.desc = ``
      return o
    },
    getStep: function({ contractDetail: cd, carExemInfo: car }) {
      return [
        {
          label: '취소 시간',
          content: `${moment(cd.cancelDate, 'YYYYMMDDHHmm').format('YYYY년 MM월 DD일(ddd) HH:mm')}`,
          detailBadge1: false,
          isPrimary1: false, // false : 그레이, true: 블루
          badgeName1: '',
          detailBadge2: false, // badgeName2:''
          detailPopover: false
        }
      ]
    }
  },
  CONT_CANCEL_EXPIRATION: { //계약신청취소[기간만료]
    ocsc: ['0015', '0089'],  // 0015: 계약기간만료(계약금있음)  /   0089 : 계약기한만료(계약금없음)
    mypage_step: '계약 취소',
    getHeader: function(cd) {
      let o = {}
      o.title = `${moment(cd.cancelDate, 'YYYYMMDDHHmm').format('MM/DD')} 계약 취소`
      o.desc_blue = ''
      o.desc = `계약작성 기간 만료로 계약이 취소 되었습니다. 새로운 계약을 진행해 주세요.`
      return o
    },
    getStep: function({ contractDetail: cd, carExemInfo: car }) {
      return [
        {
          label: '취소 사유',
          content: `계약 기간 만료`,
          detailBadge1: false,
          isPrimary1: false, // false : 그레이, true: 블루
          badgeName1: '',
          detailBadge2: false, // badgeName2:''
          detailPopover: false
        },
        {
          label: '취소 시간',
          content: `${moment(cd.cancelDate, 'YYYYMMDDHHmm').format('YYYY년 MM월 DD일(ddd) HH:mm')}`,
          detailPopover: false
        }
      ]
    }
  },
  CONT_CANCEL_REFUND_WAIT: {
    //CASE 3.4. 계약:계약 취소(환불대기)
    ocsc: ['0035', '0036', '0099'], // 0099 결제기간만료로 batch에서 취소된 케이스
    mypage_step: '계약취소[환불대기]',
    getHeader: function(cd) {
      let o = {}
      o.title = `${moment(cd.cancelDate, 'YYYYMMDDHHmm').format('MM/DD')} 계약신청 취소`
      o.desc_blue = ''
      o.desc = `계약이 취소 되었습니다. 결제금액을 환불 받을 계좌 정보를 입력해주세요.`
      return o
    },
    getStep: function({ contractDetail: cd, carExemInfo: car }) {
      let a =  [
        // {
        //   label: '체크리스트',
        //   content: '',
        //   detailBadge1: true,
        //   isPrimary1: false, // false : 그레이, true: 블루
        //   badgeName1: `환불 계좌 입력`,
        //   detailPopover: false
        // },
        {
          label: '취소 시간',
          content: `${moment(cd.cancelDate, 'YYYYMMDDHHmm').format('YYYY년 MM월 DD일(ddd) HH:mm')}`,
          detailPopover: false
        }
      ]
      //if(cd.paymentTypeCode !== '30'  )        a.shift()   //체크리스트 삭제
      return a
    }
  },
  /**
   * 신차사전계약 판매개시일 이전 상태
   */
  CONT_IN_PROGRESS_WAIT: {
    /**
     * 0010 : 계약금미입금 , 0020 : 계약금입금
     */
    ocsc: ['0010','0020'],
    mypage_step: '계약진행[대기중]',
    getHeader: function(cd) {
      let o = {}
      o.title = `계약진행[대기중]`
      o.desc_blue = ''
      o.desc = `신차사전계약을 완료한 대상자에게 선착순으로 판매개시일을 안내할 예정입니다. 이후 계약 진행하시기 바랍니다.`
      return o
    },
    getStep: function({ contractDetail: cd, carExemInfo: car, contractPossibleStartDate }) {
      // 판매개시일 이전 : INACTIVE
      // 판매개시일 이후 :   ACTIVE
      this.showBtnContCreateAndUpdate = moment().isSameOrAfter( moment(contractPossibleStartDate, 'YYYY-MM-DD hh:mm:ss'))
      return [
        {
          label: '판매개시일',
          content: `추후 문자 발송 안내(판매개시일부터 계약 작성 바랍니다.)`,
          detailBadge1: false,
          isPrimary1: false, // false : 그레이, true: 블루
          badgeName1: '',
          detailBadge2: false, // badgeName2:''
          detailPopover: false
        }
      ]
    },
    showBtnContCreateAndUpdate: false // [계약내역 작성/수정]
  },
  CONT_IN_PROGRESS_CREATING: {
    ocsc: [
      '0030', // 신차사전계약 - 판매개시일 기간 (시작)~
      '0040',
      '0041',
      '0042',
      '0050',
      '0051',
      '0052',
      '0053',
      '0070',
      '0071',
      '0060',
      '0061',
      '0072',
      '0073',
      '0081','0082','0083','0084'   // <-- 2019.12.21 전자서명 보내지 않은 상태
    ],
    mypage_step: '계약진행 [작성중]',
    getHeader: function(cd) {
      let o = {}
      o.title = `계약진행`
      o.desc_blue = ''
      o.desc = `${moment(cd.contractCompletionLimitDate, 'YYYYMMDDHHmm').format('YYYY년 MM월 DD일(ddd) HH:mm')} 시까지 계약을 완료하시기 바랍니다. 미완료 시 계약은 자동 취소됩니다` //2019 10 11 10 34 40
      return o
    },
    getStep: function({ contractDetail: cd, carExemInfo: car }) {
      return [
        {
          label: '계약 완료 기한',
          content: MYPAGE_CASE.convertLimitPeriodText(cd.contractCompletionLimitDate),
          detailBadge1: false,
          isPrimary1: false, // false : 그레이, true: 블루
          badgeName1: '',
          detailBadge2: false, // badgeName2:''
          detailPopover: false
        }
      ]
    }
  },
  CONT_COMPLETE_UNPAID: {  //계약진행 [계약작성 완료] (미입금)    ---> 계약금이 미입금된 상태
    ocsc: ['0087'],
    mypage_step: '계약진행 [계약작성 완료]',
    getHeader: function(cd) {
      let o = {}
      o.title = `계약진행`
      o.desc_blue = ''
      o.desc = `${moment(cd.contractCompletionLimitDate, 'YYYYMMDDHHmm').format(
        'YYYY년 MM월 DD일(ddd) HH:mm'
      )} 시까지 계약을 완료하시기 바랍니다. 미완료 시 계약은 자동 취소됩니다`
      return o
    },
    getStep: function({ contractDetail: cd, carExemInfo: car }) {
      this.activeReadOnly = (cd.contractStateDetailCode === '4')
      return [
        {
          label: '체크리스트',
          content: '',
          detailBadge1: true,
          isPrimary1: false, // false : 그레이, true: 블루
          badgeName1: `계약금 결제`, // 미확정, 확정, 변경
          detailBadge2: true,
          isPrimary2: false,
          badgeName2: `전자서명`,
          detailPopover: false
        },
        {
          label: '계약 완료 기한',
          content: MYPAGE_CASE.convertLimitPeriodText(cd.contractCompletionLimitDate),
          detailPopover: false
        }
      ]
    },
    activeReadOnly : true //계약내역 보기 (계약변경으로 변경이 완료되지 않은 경우는 비활성화)
  },
  CONT_COMPLETE_UNSIGNED: { //계약진행 [계약작성 완료] (미서명)
    ocsc: ['0085', '0086'],
    mypage_step: '계약진행 [계약작성 완료]',
    getHeader: function(cd) {
      let o = {}
      o.title = `계약진행`
      o.desc_blue = ''
      o.desc = `${moment(cd.contractCompletionLimitDate, 'YYYYMMDDHHmm').format(
        'YYYY년 MM월 DD일(ddd) HH:mm'
      )} 시까지 계약을 완료하시기 바랍니다. 미완료 시 계약은 자동 취소됩니다`
      return o
    },
    getStep: function({ contractDetail: cd, carExemInfo: car }) {
      this.activeReadOnly = (cd.contractStateDetailCode === '4')
      // 배정차량
      const isAssigned = !(cd.assignmentDate === null && cd.assignmentRequestDate !== null)
      return [
        {
          label: '체크리스트',
          content: '',
          detailBadge1: !isAssigned,
          isPrimary1: true, // false : 그레이, true: 블루
          badgeName1: `계약금 결제`, // 미확정, 확정, 변경

          detailBadge2: true, // badgeName2:''
          isPrimary2: false,
          badgeName2: '전자서명',

          detailPopover: false
        },
        {
          label: '계약 완료 기한',
          content: MYPAGE_CASE.convertLimitPeriodText(cd.contractCompletionLimitDate),
          detailPopover: false
        }
      ]
    },
    activeReadOnly : true //계약내역 보기 (계약변경으로 변경이 완료되지 않은 경우는 비활성화)
  },
  // A20 -------------------
  CAR_PREP_PRDN_WAIT: {
    //차량배정요청일+14 < SYSDATE
    ocsc: ['0098','0078'],
    mypage_step: '차량생산대기',
    getHeader: function(cd) {
      let o = {}
      o.title = `차량생산대기`
      o.desc_blue = ''
      o.desc = `계약 완료 후, 차량준비를 시작합니다.`
      return o
    },
    getStep: function({ contractDetail: cd, carExemInfo: car }) {
      this.activeReadOnly = (cd.contractStateDetailCode === '4')
      return [
        {
          label: '계약완료일',
          content: `${moment(cd.contractDate, 'YYYYMMDDHHmm').format('YYYY년 MM월 DD일(ddd) HH:mm')}`,
          detailBadge1: false,
          isPrimary1: true, // false : 그레이, true: 블루
          badgeName1: '변경',
          detailBadge2: false, // badgeName2:''
          detailPopover: false
        },
        {
          label: '예상출고일',
          content: `${car.exemplificationDateText}`,
          detailPopover: true,
          detailPopoverKey: 'DUEDATE'
        }
      ]
    },
    activeReadOnly : true //계약내역 보기 (계약변경으로 변경이 완료되지 않은 경우는 비활성화)
  },
  CAR_PREP_ING: {
    //차량배정요청일+14 >= SYSDATE
    ocsc: ['0098','0078'],
    mypage_step: '차량생산중',
    getHeader: function(cd) {
      let o = {}
      o.title = `차량생산중`
      o.desc_blue = ''
      o.desc = `예상 출고일은 차량생산완료 시 확정됩니다.`
      return o
    },
    getStep: function({ contractDetail: cd, carExemInfo: car }) {
      this.activeReadOnly = (cd.contractStateDetailCode === '4')
      return [
        {
          label: '계약완료일',
          content: `${moment(cd.contractDate, 'YYYYMMDDHHmm').format('YYYY년 MM월 DD일(ddd) HH:mm')}`,
          detailBadge1: false,
          isPrimary1: true, // false : 그레이, true: 블루
          badgeName1: '변경',
          detailBadge2: false, // badgeName2:''
          detailPopover: false
        },
        {
          label: '예상출고일',
          content: `${car.exemplificationDateText}`,
          detailPopover: true,
          detailPopoverKey: 'DUEDATE'
        }
      ]
    },
    activeReadOnly : true //계약내역 보기 (계약변경으로 변경이 완료되지 않은 경우는 비활성화)
  },
  // A30 -------------------
  PAY_WAIT: {
    ocsc: ['0093'],
    mypage_step: '결제대기',
    getHeader: function(cd) {
      let o = {}
      o.title = `결제대기`
      o.desc_blue = ''
      o.desc = `기한 내 결제수단 선택 및 결제를 완료하시기 바랍니다.`
      return o
    },
    getStep: function({ contractDetail: cd, carExemInfo: car, paymentTimeLimit }) {
      // 임직원일 경우 2년 의무보유기간 경과 전인 경우, 비활성화 처리
      const isBefore2Years = cd.dutyHoldPeriodYn === 'Y' // <-----   임직원이면서, 의무보유기간경과전 이면 Y
      if (isBefore2Years) this.activeBtnPayment = false

      //결제대기의 분기  -  CASE 7.1 과세 or 심사 없는 경우  :true     /  CASE 7.1.1 면세(ONLY 계약시 체크한 경우)  : false
      const noEvidenceReview = (cd.taxationTypeCode === '1')
      let a = [
        {
          label: '체크리스트',
          content: '',
          detailBadge1: true,
          isPrimary1: false, // false : 그레이, true: 블루
          badgeName1: `증빙심사 `,
          detailBadge2: false, // badgeName2:''
          detailPopover: false
        },
        {
          label: '결제 기한',
          content: MYPAGE_CASE.convertLimitPeriodText(paymentTimeLimit),
          detailPopover: false
        }
      ]
      if (noEvidenceReview) a.shift() //첫번째 객체를 제거
      return a
    },
    activeBtnPayment: true
  },
  PAY_WAIT_CONT_CHANGED: {
    ocsc: ['0094','0095'],  // (20.01.29) 0095  추가 -
    mypage_step: '결제대기 [계약변경]',
    getHeader: function(cd) {
      let o = {}
      o.title = `결제대기`
      o.desc_blue = ''
      o.desc = `전자서명을 완료해주세요.`
      return o
    },
    getStep: function({ contractDetail: cd, carExemInfo: car, paymentTimeLimit }) {
      return [
        {
          label: '체크리스트',
          content: '',
          detailBadge1: true,
          isPrimary1: false, // false : 그레이, true: 블루
          badgeName1: '전자서명',
          detailBadge2: false, // badgeName2:''
          detailPopover: false
        // },     // 결제기한숨김 20.02.12 (김경선)
        // {
        //   label: '결제 기한',
        //   content: MYPAGE_CASE.convertLimitPeriodText(paymentTimeLimit),
        //   detailPopover: false
        }
      ]
    }
  },
  PAY_WAIT_TRADEIN_WAIT: {
    ocsc: ['0092'],
    mypage_step: '결제대기 [trade-in 대기]',
    getHeader: function(cd) {
      let o = {}
      o.title = `결제대기`
      o.desc_blue = ''
      o.desc = `기한 내 결제수단 선택 및 결제를 완료하시기 바랍니다.`
      return o
    },
    getStep: function({ contractDetail: cd, carExemInfo: car, paymentTimeLimit }) {
      return [
        {
          label: '안내사항',
          content: `중고차 매각거래 완료 후 결제진행 바랍니다`,
          detailBadge1: false,
          isPrimary1: false, // false : 그레이, true: 블루
          badgeName1: '',
          detailBadge2: false, // badgeName2:''
          detailPopover: false
        },
        {
          label: '결제 기한',
          content: MYPAGE_CASE.convertLimitPeriodText(paymentTimeLimit),
          detailPopover: false
        }
      ]
    }
  },
  PAY_WAIT_DELIVERY: {
    /** 배달탁송전환시, 배달탁송료 추가결제          --> 기존사양
     *  면세->과세변경시, 추가되는 과세금액 추가결제  --> 추가사양 20.01.29 (w/김경선)
     * */
    ocsc: ['0097'],
    mypage_step: '결제대기',
    getHeader: function(cd) {
      let o = {}
      o.title = `결제대기`
      o.desc_blue = ''
      o.desc = `기한 내 결제수단 선택 및 결제를 완료하시기 바랍니다.`
      return o
    },
    getStep: function({ contractDetail: cd, carExemInfo: car }) {
      return [
        {
          label: '체크리스트',
          content: ``,
          detailBadge1: true,
          isPrimary1: false, // false : 그레이, true: 블루
          badgeName1: '추가금액 결제',
          detailBadge2: false, // badgeName2:''
          detailPopover: false
        }
      ]
    }
  },
  PAY_ING: {
    // CASE 7.5
    ocsc: ['0130'],
    mypage_step: '결제처리중',
    getHeader: function(cd) {
      let o = {}
      o.title = `결제처리중`
      o.desc_blue = ''
      o.desc = `결제처리중입니다. 잠시만 기다려주세요.`
      return o
    },
    getStep: function({ contractDetail: cd, carExemInfo: car, paymentUpdatedDate }) {
      return [
        {
          label: '결제정보입력일',
          content: moment(paymentUpdatedDate, 'YYYYMMDDHHmm').format('YYYY년 MM월 DD일(ddd) HH:mm'),
          detailBadge1: false,
          isPrimary1: false, // false : 그레이, true: 블루
          badgeName1: '',
          detailBadge2: false, // badgeName2:''
          detailPopover: false
        }
      ]
    }
  },
  PAY_ING_EVIDENCE_REVIEW: {
    // CASE 7.6
    ocsc: ['0120'],
    mypage_step: '결제처리중 (증빙심사)',
    getHeader: function(cd) {
      let o = {}
      o.title = `결제처리중`
      o.desc_blue = ''
      o.desc = `결제처리중입니다. 잠시만 기다려주세요.`
      return o
    },
    getStep: function({ contractDetail: cd, carExemInfo: car, paymentUpdatedDate }) {
      return [
        {
          label: '체크리스트',
          content: ``,
          detailBadge1: true,
          isPrimary1: false, // false : 그레이, true: 블루
          badgeName1: '증빙심사',
          detailBadge2: false, // badgeName2:''
          detailPopover: false
        },
        {
          label: '결제정보입력일',
          content: moment(paymentUpdatedDate, 'YYYYMMDDHHmm').format('YYYY년 MM월 DD일(ddd) HH:mm'),
          detailPopover: false
        }
      ]
    }
  },
  PAY_ING_JUDGED_FAILED: {
    // CASE 7.7
    ocsc: ['9121'],
    mypage_step: '결제처리중 [심사실패] ',
    getHeader: function(cd) {
      let o = {}
      o.title = `결제처리중`
      o.desc_blue = ''
      o.desc = `결제처리중입니다. 잠시만 기다려주세요.`
      return o
    },
    getStep: function({ contractDetail: cd, carExemInfo: car, reasonOfReject = [] }) {
      let a = [
        {
          label: '체크리스트',
          content: ``,
          detailBadge1: true,
          isPrimary1: false, // false : 그레이, true: 블루
          badgeName1: '증빙심사',
          detailBadge2: false, // badgeName2:''
          detailPopover: false
        }
      ]
      // 실패사유 리스트
      reasonOfReject.forEach((text, idx) => {
        const o = {
          label: `실패사유 #${idx + 1}`,
          content: text,
          detailPopover: false
        }
        a.push(o)
      })
      return a
    }
  },
  PAY_ING_TAX_EXEMPT_FAILED: {
    ocsc: ['9122'],
    mypage_step: '결제처리중 [면세심사실패] ',
    getHeader: function(cd) {
      let o = {}
      o.title = `결제처리중`
      o.desc_blue = ''
      o.desc = `결제처리중입니다. 잠시만 기다려주세요.`
      return o
    },
    getStep: function({ contractDetail: cd, carExemInfo: car, reasonOfReject = [] }) {
      let a = [
        {
          label: '체크리스트',
          content: ``,
          detailBadge1: true,
          isPrimary1: false, // false : 그레이, true: 블루
          badgeName1: '증빙심사',
          detailBadge2: false, // badgeName2:''
          detailPopover: false
        }
      ]
      // 실패사유 리스트
      reasonOfReject.forEach((text, idx) => {
        const o = {
          label: `실패사유 #${idx + 1}`,
          content: text,
          detailPopover: false
        }
        a.push(o)
      })
      return a
    }
  },
  PAY_FAIL: {
    ocsc: ['9131'],
    mypage_step: '결제실패',
    getHeader: function(cd) {
      let o = {}
      o.title = `결제실패`
      o.desc_blue = ''
      o.desc = `결제 실패 사유를 확인 후, 다시 결제해주세요.`
      return o
    },
    getStep: function({ contractDetail: cd, carExemInfo: car, reasonOfReject = [] }) {
      let a = []
      // 실패사유 리스트
      const o = {
        label: `실패사유`,
        content: reasonOfReject[0],
        detailPopover: false
      }
      a.push(o)
      return a
    }
  },
  PAY_FAIL_EVIDENCE_REVIEW: {
    ocsc: ['9109'],
    mypage_step: '결제실패 (증빙심사)',
    getHeader: function(cd) {
      let o = {}
      o.title = `결제실패`
      o.desc_blue = ''
      o.desc = `결제 실패 사유를 확인 후, 다시 결제해주세요.`
      return o
    },
    getStep: function({ contractDetail: cd, carExemInfo: car, reasonOfReject = [] }) {
      let a = [
        {
          label: '체크리스트',
          content: ``,
          detailBadge1: true,
          isPrimary1: false, // false : 그레이, true: 블루
          badgeName1: '증빙심사',
          detailBadge2: false, // badgeName2:''
          detailPopover: false
        }
      ]
      // 실패사유 리스트
      reasonOfReject.forEach((text, idx) => {
        const o = {
          label: `실패사유 #${idx + 1}`,
          content: text,
          detailPopover: false
        }
        a.push(o)
      })
      return a
    }
  },
  PAY_FAIL_JUDGED_FAILED: {
    ocsc: ['9125'],
    mypage_step: '결제실패 [심사실패]',
    getHeader: function(cd) {
      let o = {}
      o.title = `결제실패`
      o.desc_blue = ''
      o.desc = `결제 실패 사유를 확인 후, 다시 결제해주세요.`
      return o
    },
    getStep: function({ contractDetail: cd, carExemInfo: car, reasonOfReject = [] }) {
      let a = [
        {
          label: '체크리스트',
          content: ``,
          detailBadge1: true,
          isPrimary1: false, // false : 그레이, true: 블루
          badgeName1: '증빙심사',
          detailBadge2: false, // badgeName2:''
          detailPopover: false
        }
      ]
      // 실패사유 리스트
      reasonOfReject.forEach((text, idx) => {
        const o = {
          label: `실패사유 #${idx + 1}`,
          content: text,
          detailPopover: false
        }
        a.push(o)
      })
      return a
    }
  },
  PAY_FAIL_EXEMPT_FAILED: {
    ocsc: ['9126'],
    mypage_step: '결제실패 [면세심사실패] ',
    getHeader: function(cd) {
      let o = {}
      o.title = `결제실패`
      o.desc_blue = ''
      o.desc = `결제 실패 사유를 확인 후, 다시 결제해주세요.`
      return o
    },
    getStep: function({ contractDetail: cd, carExemInfo: car, reasonOfReject = [] }) {
      let a = [
        {
          label: '체크리스트',
          content: ``,
          detailBadge1: true,
          isPrimary1: false, // false : 그레이, true: 블루
          badgeName1: '증빙심사',
          detailBadge2: false, // badgeName2:''
          detailPopover: false
        }
      ]
      // 실패사유 리스트
      reasonOfReject.forEach((text, idx) => {
        const o = {
          label: `실패사유 #${idx + 1}`,
          content: text,
          detailPopover: false
        }
        a.push(o)
      })
      return a
    }
  },
  PAY_OK_JUDGED_FAILED: {
    ocsc: ['9123'],
    mypage_step: '결제승인 [심사실패] ',
    getHeader: function(cd) {
      let o = {}
      o.title = `심사실패`
      o.desc_blue = ''
      o.desc = `심사 실패 사유를 확인 후, 다시 제출해주세요.`
      return o
    },
    getStep: function({ contractDetail: cd, carExemInfo: car, reasonOfReject = [] }) {
      let a = [
        {
          label: '체크리스트',
          content: ``,
          detailBadge1: true,
          isPrimary1: false, // false : 그레이, true: 블루
          badgeName1: '증빙심사',
          detailBadge2: false, // badgeName2:''
          detailPopover: false
        }
      ]
      // 실패사유 리스트
      reasonOfReject.forEach((text, idx) => {
        const o = {
          label: `실패사유`, //단수
          content: text,
          detailPopover: false
        }
        a.push(o)
      })
      return a
    }
  },
  PAY_OK_EXEMPT_FAILED: {
    ocsc: ['9124'],
    mypage_step: '결제승인 [면세심사실패] ',
    getHeader: function(cd) {
      let o = {}
      o.title = `면세심사 실패`
      o.desc_blue = ''
      o.desc = `면세 실패 사유를 확인 후, 다시 제출해주세요.`
      return o
    },
    getStep: function({ contractDetail: cd, carExemInfo: car, reasonOfReject = [] , taxPossibleYn = 'N' }) {
      this.activeBtnChangeTax = (taxPossibleYn==='Y')
      let a = [
        {
          label: '체크리스트',
          content: ``,
          detailBadge1: true,
          isPrimary1: false, // false : 그레이, true: 블루
          badgeName1: '증빙심사',
          detailBadge2: false, // badgeName2:''
          detailPopover: false
        }
      ]
      // 실패사유 리스트
      reasonOfReject.forEach((text, idx) => {
        const o = {
          label: `실패사유 #${idx + 1}`,
          content: text,
          detailPopover: false
        }
        a.push(o)
      })
      return a
    },
    activeBtnChangeTax : false  // 면세 > 과세로 변경하기 Btn 표시여부
  },
  PAY_OK_EVIDENCE_REVIEW: {
    //8.7
    ocsc: ['9108'],
    mypage_step: '결제승인 (증빙심사)',
    getHeader: function(cd) {
      let o = {}
      o.title = `결제승인`
      o.desc_blue = ''
      o.desc = `` // 기획서 없음.
      return o
    },
    getStep: function({ contractDetail: cd, carExemInfo: car, paymentUpdatedDate }) {
      return [
        {
          label: '체크리스트',
          content: ``,
          detailBadge1: true,
          isPrimary1: false, // false : 그레이, true: 블루
          badgeName1: '증빙심사',
          detailBadge2: false, // badgeName2:''
          detailPopover: false
        },
        {
          label: '결제정보입력일',
          content: moment(paymentUpdatedDate, 'YYYYMMDDHHmm').format('YYYY년 MM월 DD일(ddd) HH:mm'),
          detailPopover: false
        }
      ]
    }
  },
  PAY_COMPLETED: {
    //미노출 - 결제승인은 증빙심사 중이거나 특정 심사 실패시에만 노출됨.   ->>>  2019.12.09 노출되는 것으로 수정  (강주원/김경선)
    ocsc : [ '0200' ] ,
    mypage_step: '결제완료',
    getHeader: function(cd) {
      let o = {}
      o.title = `결제완료`
      o.desc_blue = ''
      o.desc = `차량준비중입니다.`
      return o
    },
    getStep: function({ contractDetail: cd, carExemInfo: car, paymentDate }) {
      return [
        {
          label: '결제완료일시',
          content: moment(paymentDate, 'YYYYMMDDHHmm').format('YYYY년 MM월 DD일(ddd) HH:mm'),
          detailBadge1: false,
          isPrimary1: false, // false : 그레이, true: 블루
          badgeName1: '',
          detailBadge2: false, // badgeName2:''
          detailPopover: false
        }
      ]
    }
  },
  // A40 ------------------- 배달탁송 (인수유형코드:배달탁송 acquisitionTypeCode == 02)
  DLV_READY: {
    ocsc: ['0400'],
    mypage_step: '배달탁송준비',
    getHeader: function(cd) {
      let o = {}
      o.title = `배달탁송 준비`
      o.desc_blue = ''
      o.desc = `배달탁송완료 및 자동차제작증 발급 전까지 선택형 서비스를 구매하실 수 있습니다`
      return o
    },
    getStep: function({ contractDetail: cd, carExemInfo: car }) {
      return [
        {
          label: '배달탁송지',
          content: `${cd.acceqtorInfo.acceptorZipCode} ${cd.acceqtorInfo.acceptorCenterAddress} ${cd.acceqtorInfo.acceptorCenterAddressDetail}`,
          detailBadge1: false,
          isPrimary1: false, // false : 그레이, true: 블루
          badgeName1: '',
          detailBadge2: false, // badgeName2:''
          detailPopover: false
        },
        {
          label: '도착예상일',
          content: `추후 안내 ${
            cd.tuixOptionCode !== ''
              ? '(H Genuine Accessories 계약 차량의 경우, 일반 차량에 비해 커스터마이징/H Genuine Accessories 장착 소요시간이 더 발생합니다.)'
              : ''
          }`,
          detailPopover: false
        }
      ]
    }
  },
  DLV_ON: {
    ocsc: ['0410'],
    mypage_step: '배달탁송중',
    getHeader: function(cd) {
      let o = {}
      o.title = `배달탁송중`
      o.desc_blue = ''
      o.desc = `차량을 받아보셨다면 차량인수 확정처리를 해주세요!`
      return o
    },
    getStep: function({ contractDetail: cd, carExemInfo: car }) {
      return [
        {
          label: '체크리스트',
          content: ``,
          detailBadge1: true,
          isPrimary1: false, // false : 그레이, true: 블루
          badgeName1: '차량인수 확정',
          detailBadge2: false, // badgeName2:''
          detailPopover: false
        },
        {
          label: '도착예상일',
          content: `${moment(cd.carArrivalPrearrangementDate, 'YYYYMMDDhhmmss').format('YYYY년 MM월 DD일 HH')} 시경 도착 예정`,
          detailPopover: false
        }
      ]
    }
  },
  DLV_ACQ_COMPLETED: {
    // CASE 10.1. 인수완료 [제작증 미발급]
    ocsc: ['0610'],  //0610 차량 인수 완료(배달탁송)
    mypage_step: '차량 인수 완료',
    getHeader: function(cd) {
      let o = {}
      o.title = `${moment(cd.customerUndertakingDecisionDate , 'YYYYMMDDhhmmss').format('MM/DD')} 차량 인수 완료`
      o.desc_blue = ''
      o.desc = `고객님의 차량이 배달탁송완료되었습니다. 차량인수확정 및 전자서명 완료후 자동차제작증을 발급받으세요!`
      return o
    },
    getStep: function({ contractDetail: cd, carExemInfo: car }) {
      this.isCertificationRequestValidDate  = MYPAGE_CASE.isNotOver( cd.carMakeCertificateRequestDate , 14, true)
      this.isReviewValidDate                = MYPAGE_CASE.isNotOver( cd.carMakeCertificateRequestDate , 30, true)
      return [
        {
          label: '체크리스트',
          content: ``,
          detailBadge1: true,
          isPrimary1: false, // false : 그레이, true: 블루
          badgeName1: '제작증 발급',
          detailBadge2: false, // badgeName2:''
          detailPopover: false
        },
        {
          label: '차량인수일',
          content: moment(cd.customerUndertakingDecisionDate , 'YYYYMMDDhhmmss').format('YYYY년 MM월 DD일(ddd) HH:mm'),
          detailPopover: false
        }
      ]
    },
    isCertificationRequestValidDate : true ,
    isReviewValidDate : true  //구매후기 작성가능일 여부
  },
  DLV_PUR_COMPLETED: {
    // CASE 10.2. 배달탁송완료 : 차량구매완료       ----- 면세 미신고 대상자 ONLY (taxationTypeCode===1)
    ocsc: ['0710'],
    mypage_step: '차량 구매 완료',
    getHeader: function(cd) {
      let o = {}
      o.title = `${moment(cd.carMakeCertificateRequestDate, 'YYYYMMDDhhmmss').format('MM/DD')} 차량 구매 완료` // 차량구매완료일자는 제작증발급일로 출력 (2019.11.01 - 안성경)
      o.desc_blue = ''
      o.desc = `자동차제작증 발급이 완료되었습니다. 차량등록 절차를 확인하세요!`
      return o
    },
    getStep: function({ contractDetail: cd, carExemInfo: car }) {
      this.isCertificationRequestValidDate  = MYPAGE_CASE.isNotOver( cd.carMakeCertificateRequestDate , 14, true)
      this.isReviewValidDate                = MYPAGE_CASE.isNotOver( cd.carMakeCertificateRequestDate , 30, true)
      const a = [
        {
          label: '제작증 발급일',
          content: moment(cd.carMakeCertificateRequestDate, 'YYYYMMDDhhmmss').format('YYYY년 MM월 DD일(ddd) HH:mm'),
          detailBadge1: false,
          isPrimary1: false, // false : 그레이, true: 블루
          badgeName1: '',
          detailBadge2: false, // badgeName2:''
          detailPopover: false
        },
        {
          label: '차량등록 기한일',
          content: moment(cd.carRegistrationPeriod, 'YYYYMMDDhhmmss').format('YYYY년 MM월 DD일(ddd) HH:mm'),
          detailPopover: true,
          detailPopoverKey: 'TICKET'
        }
      ]
      // 차량등록 기한일 다음날 부터는 출력안함
      if (moment().isAfter(moment(cd.carRegistrationPeriod, 'YYYYMMDDhhmmss'))) return a.splice(1, 1) // 차량등록기한일 제외
      return a
    },
    isCertificationRequestValidDate : true ,
    isReviewValidDate : true  //구매후기 작성가능일 여부
  },
  DLV_PUR_COMPLETED_TAXFREE_NOT_REPORTED: {
    //(taxationTypeCode===2)   CASE 10.3.배달탁송완료 : 차량 구매 완료
    ocsc: ['0800', '0810'],
    mypage_step: '차량 구매 완료 ',
    getHeader: function(cd) {
      let o = {}
      o.title = `${moment(cd.carMakeCertificateRequestDate, 'YYYYMMDD').format('MM/DD')} 차량 구매 완료` // 차량구매완료일자는 제작증발급일로 출력 (2019.11.01 - 안성경)
      o.desc_blue = ''
      o.desc = `기한일 내 차량등록을 진행 후, 면세신고 접수 및 완료 하시기 바랍니다.`
      return o
    },
    getStep: function({ contractDetail: cd, carExemInfo: car }) {
      this.isCertificationRequestValidDate = moment().isSameOrBefore( moment(cd.carMakeCertificateRequestDate, 'YYYYMMDD').add(14, 'days'))
      const a = [
        {
          label: '체크리스트',
          content: '',
          detailBadge1: true,
          isPrimary1: false, // false : 그레이, true: 블루
          badgeName1: '면세신고',
          detailBadge2: false, // badgeName2:''
          detailPopover: false
        },
        {
          label: '차량등록 기한일',
          content: (cd.carRegistrationPeriod)? moment(cd.carRegistrationPeriod, 'YYYYMMDD').format('YYYY년 MM월 DD일(ddd) 까지') : 'No Date',
          detailPopover: true,
          detailPopoverKey: 'TICKET'
        },
        {
          label: '면세신고 기한일',
          content: (cd.taxFreeStatementPeriod)? moment(cd.taxFreeStatementPeriod, 'YYYYMMDD').format('YYYY년 MM월 DD일(ddd) 까지') : 'No Date',
          detailPopover: true,
          detailPopoverKey: 'REPORT'
        }
      ]
      return a
    },
    isCertificationRequestValidDate: true // [차량 등록방법/절차 보기]
  },
  DLV_PUR_COMPLETED_TAXFREE: {
    //(taxationTypeCode===2) CASE 10.4. 배달탁송완료 : 차량 구매 완료 (면세신고 완료)
    ocsc: ['0710'],
    mypage_step: '차량 구매 완료',
    getHeader: function(cd) {
      let o = {}
      o.title = `${moment(cd.carMakeCertificateRequestDate, 'YYYYMMDD').format('MM/DD')} 차량 구매 완료` // 차량구매완료일자는 제작증발급일로 출력 (2019.11.01 - 안성경)
      o.desc_blue = ''
      o.desc = ''
      return o
    },
    getStep: function({ contractDetail: cd, carExemInfo: car }) {
      this.isCertificationRequestValidDate = moment().isSameOrBefore( moment(cd.carMakeCertificateRequestDate, 'YYYYMMDD').add(14, 'days'))
      return [
        {
          label: '제작증 발급일',
          content: moment(cd.carMakeCertificateRequestDate, 'YYYYMMDDhhmmss').format('YYYY년 MM월 DD일(ddd) HH:mm'),
          detailBadge1: false,
          isPrimary1: false, // false : 그레이, true: 블루
          badgeName1: '면세신고',
          detailBadge2: false, // badgeName2:''
          detailPopover: false
        }
      ]
    },
    isCertificationRequestValidDate : true
  },
  // A50 -------------------  인수유형코드:본인출고, 대리인 acquisitionTypeCode == 00 || 01
  DIRECT_VISIT_READY: {
    // CASE. 11.2.
    ocsc: ['0320'],
    mypage_step: '방문예약 대기',
    getHeader: function(cd) {
      let o = {}
      o.title = '방문예약 대기'
      o.desc_blue = ''
      o.desc = '방문일자를 예약해주세요!'
      return o
    },
    getStep: function({ contractDetail: cd, carExemInfo: car }) {
      return [
        {
          label: '방문 예약일',
          content: '금일 기준 1~2일 내 방문 예약 날짜와 시간을 선택해주세요',
          detailPopover: true,
          detailPopoverKey: 'VISIT'
        }
      ]
    }
  },
  DIRECT_RSV_COMPLETED: {
    // CASE 11.3.
    ocsc: ['0330'],
    mypage_step: '방문예약 완료',
    getHeader: function(cd) {
      let o = {}
      o.title = `${moment(cd.deliveryPrearrangedDate, 'YYYYMMDD').format('MM/DD')} 방문예약 완료`
      o.desc_blue = ''
      o.desc = '예약한 방문일자에 반드시 방문수령 바랍니다'
      return o
    },
    getStep: function({ contractDetail: cd, carExemInfo: car }) {
      return [
        {
          label: '방문예약일',
          content: `${moment(cd.deliveryPrearrangedDate,'YYYYMMDD').format('YYYY년 MM월 DD일(ddd)')}  ${cd.visitPrearrangementTime}`, //2019년 05월 05일(금) 09:00~09:30
          detailPopover: true,
          detailPopoverKey: 'NOSHOW'
        }
      ]
    }
  },
  DIRECT_ACQ_WAIT: {
    // CASE. 11.4. 직접인수 : 차량 인수 대기중  (지점)
    ocsc: ['0580'],
    mypage_step: '차량 인수 대기중 ',
    getHeader: function(cd) {
      let o = {}
      o.title = `차량 인수 대기중`
      o.desc_blue = ''
      o.desc = '차량보관장소(지점)로 연락 후 직접인수 확정처리를 진행해주세요!'
      return o
    },
    getStep: function({ contractDetail: cd, carExemInfo: car }) {
      return [
        {
          label: '체크리스트',
          content: ``,
          detailBadge1: true,
          isPrimary1: false, // false : 그레이, true: 블루
          badgeName1: '차량 인수 확정',
          detailBadge2: false, // badgeName2:''
          detailPopover: false
        },
        {
          label: '방문예약일',
          content: '지점으로 별도 연락 및 방문일정을 정하신 후, 차량 인수 확정처리 바랍니다.',
          detailPopover: true,
          detailPopoverKey: 'CANT_CHANGE_DLV'
        }
      ]
    }
  },
  DIRECT_ACQ_FAIL: {
    // CASE 11.5. 직접인수: 차량 인수 실패
    ocsc: ['9600'],
    mypage_step: '차량 인수실패',
    getHeader: function(cd) {
      let o = {}
      o.title = `${moment(cd.deliveryPrearrangedDate, 'YYYYMMDD').format('MM/DD')} 차량 인수실패`
      o.desc_blue = ''
      o.desc = '예약한 방문일자에 반드시 방문수령 바랍니다'
      return o
    },
    getStep: function({ contractDetail: cd, carExemInfo: car }) {
      return [
        {
          label: '방문예약일',
          content: '접수하신 방문 예약일에 방문하지 않은 고객은 배달탁송으로 차량을 인도합니다.',
          detailPopover: true,
          detailPopoverKey: 'CHANGE_DLV'
        }
      ]
    }
  },
  DIRECT_ACQ_COMPLETED: {
    //CASE 12.1 직접인수완료 : 차량 인수 완료
    ocsc: ['0600'],
    mypage_step: '차량인수 완료',
    getHeader: function(cd) {
      let o = {}
      o.title = `${moment(cd.customerUndertakingDecisionDate, 'YYYYMMDDHHmmss').format('MM/DD')} 차량인수 완료`
      o.desc_blue = ''
      o.desc = '고객님의 차량이 직접인수완료되었습니다. 차량인수확정 및 전자서명 완료후 자동차제작증을 발급받으세요!'
      return o
    },
    getStep: function({ contractDetail: cd, carExemInfo: car }) {
      this.isCertificationRequestValidDate  = MYPAGE_CASE.isNotOver( cd.carMakeCertificateRequestDate , 14, true)
      this.isReviewValidDate                = MYPAGE_CASE.isNotOver( cd.carMakeCertificateRequestDate , 30, true)
      return [
        {
          label: '체크리스트',
          content: ``,
          detailBadge1: true,
          isPrimary1: false, // false : 그레이, true: 블루
          badgeName1: '제작증 발급',
          detailBadge2: false, // badgeName2:''
          detailPopover: false
        },
        {
          label: '차량인수일',
          content: moment(cd.customerUndertakingDecisionDate, 'YYYYMMDDHHmmss').format('YYYY년 MM월 DD일(ddd) HH:mm'),
          detailPopover: false
        }
      ]
    },
    isCertificationRequestValidDate : true ,
    isReviewValidDate : true  //구매후기 작성가능일 여부
  },
  DIRECT_PUR_COMPLETED: {
    ocsc: ['0710'],
    mypage_step: '직접인수완료 : 차량 구매 완료',
    getHeader: function(cd) {
      let o = {}
      o.title = `${moment(cd.customerUndertakingDecisionDate, 'YYYYMMDDHHmmss').format('MM/DD')} 차량인수 완료`
      o.desc_blue = ''
      o.desc = '고객님의 차량이 직접인수완료되었습니다. 자동차제작증을 발급받으세요.'
      return o
    },
    getStep: function({ contractDetail: cd, carExemInfo: car }) {
      this.isCertificationRequestValidDate  = MYPAGE_CASE.isNotOver( cd.carMakeCertificateRequestDate , 14, true)
      this.isReviewValidDate                = MYPAGE_CASE.isNotOver( cd.carMakeCertificateRequestDate , 30, true)
      return [
        {
          label: '체크리스트',
          content: ``,
          detailBadge1: true,
          isPrimary1: false, // false : 그레이, true: 블루
          badgeName1: '제작증 발급',
          detailBadge2: false, // badgeName2:''
          detailPopover: false
        },
        {
          label: '차량인수일',
          content: moment(cd.customerUndertakingDecisionDate, 'YYYYMMDDHHmmss').format('YYYY년 MM월 DD일(ddd) HH:mm'),
          detailPopover: false
        }
      ]
    },
    isCertificationRequestValidDate: true , // [차량 등록방법/절차 보기]
    isReviewValidDate : true  // [구매후기 작성]
  },
  /**  (20.02.17 추가)
   * 등록환입 판촉차 (a.k.a 부활차량):  이미차량제작증까지 발급했던 차량이므로, 등록절차없이 차양 구매 완료됨.
   * 자동차 제작증 발급은 불가능하고 "말소사실 증명서" 만 발급이 가능함.
   */
  DIRECT_PUR_COMPLETED_RESOLD: {
    ocsc: ['0720'],
    mypage_step: '직접인수완료 : 차량 구매 완료',
    getHeader: function(cd) {
      let o = {}
      o.title = `${moment(cd.customerUndertakingDecisionDate, 'YYYYMMDDHHmmss').format('MM/DD')} 차량인수 완료`
      o.desc_blue = ''
      o.desc = '고객님의 차량이 직접인수완료되었습니다.'
      return o
    },
    getStep: function({ contractDetail: cd, carExemInfo: car }) {
      return [
        {
          label: '차량인수일',
          content: moment(cd.customerUndertakingDecisionDate, 'YYYYMMDDHHmmss').format('YYYY년 MM월 DD일(ddd) HH:mm'),
          detailPopover: false
        }
      ]
    }
  },
  DIRECT_PUR_COMPLETED_TAXFREE_NOT_REPORTED: {
    // 면세미신고   (taxationTypeCode===2) CASE 12.3. 직접인수완료 : 차량 구매 완료 (미신고)
    ocsc: ['0800', '0810'],
    mypage_step: '차량 구매 완료 ',
    getHeader: function(cd) {
      let o = {}
      o.title = `${moment(cd.carMakeCertificateRequestDate, 'YYYYMMDD').format('MM/DD')} 차량 구매 완료` // 차량구매완료일자는 제작증발급일로 출력 (2019.11.01 - 안성경)
      o.desc_blue = ''
      o.desc = `기한일 내 차량등록을 진행 후, 면세신고 접수 및 완료 하시기 바랍니다.`
      return o
    },
    getStep: function({ contractDetail: cd, carExemInfo: car }) {
      this.isCertificationRequestValidDate = moment().isSameOrBefore(
        moment(cd.carMakeCertificateRequestDate, 'YYYYMMDD').add(14, 'days')
      )
      const a = [
        {
          label: '체크리스트',
          content: '',
          detailBadge1: true,
          isPrimary1: false, // false : 그레이, true: 블루
          badgeName1: '면세신고',
          detailBadge2: false, // badgeName2:''
          detailPopover: false
        },
        {
          label: '차량등록 기한일',
          content: moment(cd.carRegistrationPeriod, 'YYYYMMDDhhmmss').format('YYYY년 MM월 DD일(ddd) 까지'),
          detailPopover: true,
          detailPopoverKey: 'TICKET'
        },
        {
          label: '면세신고 기한일',
          content: moment(cd.taxFreeStatementPeriod, 'YYYYMMDDhhmmss').format('YYYY년 MM월 DD일(ddd) 까지'),
          detailPopover: true,
          detailPopoverKey: 'REPORT'
        }
      ]
      return a
    },
    isCertificationRequestValidDate: true // [차량 등록방법/절차 보기]
  },
  DIRECT_PUR_COMPLETED_TAXFREE: {
    //  (taxationTypeCode===2) CASE 12.4.직접인수완료 : 차량 구매 완료  (신고함)
    ocsc: ['0710'],
    mypage_step: '차량 구매 완료 ',
    getHeader: function(cd) {
      let o = {}
      o.title = `${moment(cd.carMakeCertificateRequestDate, 'YYYYMMDD').format('MM/DD')} 차량 구매 완료` // 차량구매완료일자는 제작증발급일로 출력 (2019.11.01 - 안성경)
      o.desc_blue = ''
      o.desc = ``
      return o
    },
    getStep: function({ contractDetail: cd, carExemInfo: car }) {
      this.isCertificationRequestValidDate = moment().isSameOrBefore( moment(cd.carMakeCertificateRequestDate, 'YYYYMMDD').add(14, 'days'))
      return [
        {
          label: '제작증 발급일',
          content: moment(cd.carMakeCertificateRequestDate, 'YYYYMMDDhhmmss').format('YYYY년 MM월 DD일(ddd) HH:mm'),
          detailBadge1: false,
          isPrimary1: false, // false : 그레이, true: 블루
          badgeName1: '',
          detailBadge2: false, // badgeName2:''
          detailPopover: false
        },
        {
          label: '차량등록 기한일',
          content: moment(cd.carRegistrationPeriod, 'YYYYMMDD').format('YYYY년 MM월 DD일(ddd) 까지'),
          detailPopover: true,
          detailPopoverKey: 'TICKET'
        }
      ]
    },
    isCertificationRequestValidDate  : true
  },
  getCase: function(cd) {
    let p_code = cd.onlineContractStateCode

    // ---TEST----
    // p_code = '0320'
    // cd.assignmentRequestDate = '20191205090909'
    // ---TEST----

    let caseArr = []
    let key = ''

    for (let val of Object.keys(this)) {
      if (typeof this[val].ocsc !== 'undefined') {
        const tmpArr = this[val].ocsc.filter((code) => p_code === code)
        if (tmpArr.length > 0) {
          tmpArr.forEach((el) => {
            caseArr.push(el)
          })
          key = val
        }
      }
    }
    // 차량생산대기 OR 차량생산중
    if (['0098','0078'].includes(p_code)) {
      key = 'CAR_PREP_PRDN_WAIT'  //차량준비: 차량생산대기   ( 출고예정일에 값이 없으면 "생산대기")
      if (cd.deliveryPrearrangedDate) {
        var now = moment()
        const whotParrDtmDate = moment(cd.deliveryPrearrangedDate, 'YYYYMMDD')
        if (whotParrDtmDate.isSameOrBefore(now.add(15, 'days'))) key = 'CAR_PREP_ING' //차량준비 : 차량생산중  ( 출고예정일 < 현재일자 + 15일    이면 "차량생산중")
      }
    } else if (p_code === '0710') {
      // 차량구매완료
      if (cd.acceqtorInfo.acquisitionTypeCode === '02') {
        // 인수유형코드 : 배달탁송
        if (cd.taxationTypeCode === '1') key = 'DLV_PUR_COMPLETED'
        // 과세
        else if (cd.taxationTypeCode === '2') key = 'DLV_PUR_COMPLETED_TAXFREE' // 면세
      } else {
        // cd.acceqtorInfo.acquisitionTypeCode === '00'||'01' 인수유형코드 : 대리인, 본인  ... others
        if (cd.taxationTypeCode === '1') key = 'DIRECT_PUR_COMPLETED'
        else if (cd.taxationTypeCode === '2') key = 'DIRECT_PUR_COMPLETED_TAXFREE'
      }
    } else if (['0800', '0810'].includes(p_code)) {
      if (cd.acceqtorInfo.cquisitionTypeCode === '02') key = 'DLV_PUR_COMPLETED_TAXFREE_NOT_REPORTED'
      // 인수유형코드 : 배달탁송
      else key = 'DIRECT_PUR_COMPLETED_TAXFREE_NOT_REPORTED'
    }
    if(!key){
        console.log('[ERROR] --- mypage.js getCode has no key!!!   onlineContractStateCode: ' , p_code)
        console.log('[ERROR] CONTRACTDETAIL(009) CONNECTION FAILURE!! CHECK THE SERVER!!!' )
    }

    //key = 'CONT_COMPLETE_UNSIGNED'  // 카카오톡 전자서명 재전송
    //key = 'PAY_FAIL_JUDGED_FAILED'  // 실패이유

    let o = this[key]
    if(o) o.alias = key
    return o
  },
  convertLimitPeriodText: ( limitDateText ) => {
    const limitDate = moment(limitDateText, 'YYYYMMDDHHmm') // 2019 11 07 / 20 37
    // if(!limitDate.isValid()){
    //   return ''
    // }
    const duration = moment.duration(limitDate.diff(new moment()))
    const HH = Math.floor(duration.asHours())
    const mm = moment.utc(duration.asMilliseconds()).format('mm')
    return `${limitDate.format('YYYY년 MM월 DD일(ddd) HH:mm')} 까지  |  ${HH}시간 ${mm}분 남음`
  },
  isNotOver : (fromDate, addDays , isNotOver ) => {
    if(fromDate){
      const fromDay = moment(fromDate, 'YYYYMMDD')
      if(fromDay.isValid()) isNotOver = moment().isSameOrBefore(fromDay.add(addDays, 'days'))
    }
    return isNotOver
  }
}

export const CAR_TYPE_INFO = [
  {
    typeCode: '10', typeName: '즉시출고차량',
    typeDesc: [
      '즉시 출고 차량은 고객님이 원하시는 차량의 재고가 확인되어 정상적으로 결제 및 출고가 가능한 상품입니다.'
    ]
  },
  {
    typeCode: '20', typeName: '할인재고차량',
    typeDesc: [
        '할인이 가능한 상품입니다. 일부 차량의 경우 상품보관 장소로 직접 방문인수 하셔야 하오니 인수 방법을 반드시 확인 하시기 바랍니다.'
    ]
  },
  {
    typeCode: '30', typeName: '전시차량',
    dlvDisable: true,  //배달탁송가능여부
    typeDesc: [
      '보유거점에 사전예약후 차량보관장소에서 직접방문 인수하셔야 합니다.'
    ]
  },
  {
    typeCode: '40', typeName: '판촉차 (즉시출고)',
    dlvDisable: true,  //배달탁송가능여부
    typeDesc: [
      '판촉차는 정해진 계약 기간 내 계약 완료 하셔야 합니다. 계약기간 확인 후 기간 내 계약 완료 바랍니다.',
      '또한 상품보관장소로 직접 방문 인수 하셔야 하오니 차량 인수지를 반드시 확인하시기 바랍니다.'
    ]
  },
  {
    typeCode: '50', typeName: '생산주문차량',
    typeDesc: [
      '생산 주문 차량은 고객님이 원하시는 차량의 재고가 소진되어 주문 생산하는 상품입니다.',
      '생산 완료 시까지 일정 기간이 소요되며, 생산 완료 이후 결제를 진행 하시기 바랍니다.'
    ]
  },
  {
    typeCode: '60', typeName: '신차 사전 계약 차량',
    typeDesc: [
      '생산 주문 차량은 고객님이 원하시는 차량의 재고가 소진되어 주문 생산하는 상품입니다.',
      '생산 완료 시까지 일정 기간이 소요되며, 생산 완료 이후 결제를 진행 하시기 바랍니다.'
    ]
  },
  {
    typeCode: '99', typeName: '특별 주문 차량',
    typeDesc: [
      '특별 주문 차량은 환불/취소가 불가능한 상품입니다. 반드시 확인 후 구매 하시기 바랍니다.'
    ]
  }
]