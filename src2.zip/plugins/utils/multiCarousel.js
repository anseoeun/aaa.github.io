// 변수 i 는 항상 carousel index를 의미
/* 
 * Multi Carousel Types
 basic, gallery, thumb(gallery carousel sibling. 스크립트로 생성됨)
*/
class MultiCarousel {
  constructor(video) {
    this.video = video
    this.carousels = []
    this.isPcSize = {now: window.innerWidth > 768, before: null}
    this.isChangedBreakPoint = true
    this.isDesignTypeB = document.querySelector('.carModelInfoTypeB')   
    
    this.createCarouselUtilsBeforeInit().then(() => {
      const carousels = document.querySelectorAll('.carousel-multi')
      for(let i = 0; i < carousels.length; i++) {
        const carousel = carousels[i],
              datasetJs = carousel.dataset.js,
              slides = carousel.querySelectorAll('.list-slide')[0].children,
              slidesNotClone = Array.prototype.reduce.call(slides, (acc, crr) => { 
                const isClone = crr.getAttribute('class').includes('clone')
                if(!isClone) acc.push(crr)
                return acc
              }, [])
        this.carousels.push(
          {
            index: i,
            el: carousel,
            slidingArea: carousel.querySelectorAll('.area-sliding')[0],
            slides: slidesNotClone,
            lastSlideIndex: slides.length - 1,
            type: datasetJs ? datasetJs : 'basic',
            indicators: null,
            isGallery: null,  
            arrows: null, 
            activeIndex: 0, 
            slidesPerView:1,
            slideWidth: 0
          }
        )
        this.initCarousel(this.carousels[i])
      }
    })
  }
  async drawExteriorMobileCarousel() {
    if(!this.isDesignTypeB) return false
    const exteriorContAreas = document.querySelectorAll(`[data-js='carouselInMobile']`)

    for(let i = 0; i < exteriorContAreas.length; i++){
      const exteriorContArea = exteriorContAreas[i],
            exteriorArea = exteriorContArea.parentElement,
            mobCarouselArea = exteriorArea.querySelector('.mob-carousel')
      // 기본 html삽입
      mobCarouselArea.innerHTML = `      
        <div class="carousel-multi">
          <div class="viewport">
            <div class="area-sliding">
              <ul class="list-slide">
              </ul>
            </div>
          </div>
        </div>
      `
      const mobCarouselList= mobCarouselArea.querySelector('.list-slide')
      const images = exteriorArea.querySelectorAll('.exterior-popup .m-img'),
            titles = exteriorArea.querySelectorAll('.exterior-popup .descript strong'),
            textArea = exteriorArea.querySelectorAll('.exterior-popup .descript')
      let listsHTML = ''
      // pc용 마크업 내 텍스트 값 캐러셀 아이템 마크업에 각각 삽입 후 적용
      for(let j = 0; j < images.length; j++){
        const active = j === 0 ? ' is-active' : '',
              desc = textArea[j].querySelector('p') ,
              titleHTML = titles[j].innerHTML ? `<strong><span> ${titles[j].innerHTML} </span></strong>` : '',
              descHTML = (desc && desc.innerHTML) ? `<p>${desc.innerHTML}</p>` : ''
              
        listsHTML += ` 
          <li class="slide${active}">
            <img src="${images[j].attributes.src.value}" alt="${images[j].alt}" class="m-img">
            <div class="option-title">
              ${ titleHTML }
              ${ descHTML }
            </div>
          </li>
        `
      }
      mobCarouselList.innerHTML = listsHTML
    }
  }
  async createCarouselUtilsBeforeInit() {
    this.drawExteriorMobileCarousel().then(() => {
      const carousels = document.querySelectorAll('.carousel-multi')
      for(let i = 0; i < carousels.length; i++) {
        const carousel = carousels[i]
        /*  쇼룸 페이지 업데이트&신규 작업이 잦아,
            관련 작업 최소화를 위해 캐러셀 기능 관련 마크업은 스크립트로 삽입 */
        // 2. arrows 
        this.createArrows(carousel)
        // 2. indicator or thumbnail 
        const carouselData = carousel.dataset.js || ''
        carouselData.includes('gallery')
        ? this.createThumbCarousel(carousel)
        : this.createIndicators(carousel)
      }
    })
  }
  createCarouselWrap(carousel) {
    // gallery carousel 영역 표시를 위해, 기존 carousel은 제거하고 div로 감싼 carousel을 삽입한다.
    // 작업 편의를 위해 나머지 carousel도 동일하게 적용
    if(this.isDesignTypeB) return false    
    const carouselWrap = document.createElement('div'),
          carouselHTML = carousel.outerHTML

    carouselWrap.classList.add('wrap-carousel')
    carousel.parentNode.insertBefore(carouselWrap, carousel)
    carouselWrap.innerHTML = carouselHTML
    carousel.parentNode.removeChild(carousel)
    this.el = carouselWrap
  }
  createArrows(carousel) {
    const buttonClassName = this.isDesignTypeB
      ? 'arrow '
      : 'el-carousel__arrow el-carousel__arrow--'
    const utilCarousel = document.createElement('div')
    const buttonInnerHtml = (direction) => {
      const span = `<span class="sr-only">${direction === 'left' ? '이전' : '다음'} 슬라이드 이동</span>`
      return this.isDesignTypeB 
              ? span              
              :`<i class="el-icon-arrow-${direction}">${span}</i>`
    }
    const utilCarouselClassName = this.isDesignTypeB
      ? 'utils-carousel-typeB'
      : 'utils-carousel'
    utilCarousel.classList.add(utilCarouselClassName)
    carousel.appendChild(utilCarousel)
    utilCarousel.innerHTML = `
      <div class="wrap-utils">
        <div class="area-arrow">
          <button class="${buttonClassName}left" data-btn="prev">
            ${buttonInnerHtml('left')}
          </button>
          <button class="${buttonClassName}right" data-btn="next">
            ${buttonInnerHtml('right')}
          </button>
        </div>
      </div>
    `
  }
  createIndicators(carousel) {
    // indicators ol 태그 생성 및 삽입
    const indicatorParent = this.isDesignTypeB
            ? carousel.querySelectorAll('.wrap-utils')[0]
            : carousel,
          indicatorListWrap = document.createElement('ol')
    indicatorListWrap.classList.add('area-indicator')
    indicatorListWrap.setAttribute('role', 'tablist')
    indicatorParent.appendChild(indicatorListWrap)    
    // indicators li 생성 및 삽입
    const slides = carousel.querySelectorAll('.list-slide')[0].children
    let indicatorsHTML = ''
    for (let j = 0; j < slides.length; j++) {
      const buttonInnerHTML = slides[j].dataset.title
        ? `<span class="button-text">${slides[j].dataset.title}</span>`
        : `<span class="sr-only">슬라이드 ${j + 1}. 이미지 보기</span></button>`
      indicatorsHTML += `
        <li role="presentation" class="indicator"><button role="tab" class="btn-indicator" aria-selected="false">${buttonInnerHTML}</button></li>
      `
    }
    indicatorListWrap.innerHTML = indicatorsHTML
  }
  createThumbCarousel(carousel) {
    // gallery carousel 응용하여 thumb slide 마크업으로 재구성
    const slides = carousel.querySelectorAll('.list-slide')[0].children
    let thumbSlidesHTML = ''
    for (let j = 0; j < slides.length; j++) {
      thumbSlidesHTML += `
        <li role="presentation" class="slide">        
          <button role="tab" class="btn-thumb" aria-selected="false">
            ${slides[j].innerHTML + `<span class='sr-only'>슬라이드 ${j + 1}. 이미지 크게 보기</span>`}
          </button>
        </li>
      `
      // gallery slide에는 aria role panel 삽입
      slides[j].setAttribute('role', 'tabpanel')
    }
    // carousel 영역에 thumb carousel 추가 삽입
    const thumbCarousel = document.createElement('div'),
          arrowArea = carousel.querySelectorAll('.area-arrow')[0]
    thumbCarousel.classList.add('carousel-multi')
    thumbCarousel.setAttribute('data-js', 'thumb')
    thumbCarousel.innerHTML += `
      <div class="viewport">
        <div class="area-sliding">
          <ol role="tablist" class="list-slide">
            ${thumbSlidesHTML}
          </ol>
        </div>
      </div>
      ${arrowArea.outerHTML}    
    `
    carousel.parentNode.appendChild(thumbCarousel)
  }
  initCarousel(carousel) {
    carousel.isGallery = carousel.type.includes('gallery')
    // gallery carousel는 indicator로 thumb 지정
    const indicatorArea = carousel.el.querySelectorAll('.area-indicator'),
          arrowArea = carousel.el.querySelectorAll('.area-arrow')
    carousel.indicators = carousel.isGallery
      ? carousel.el.parentNode.querySelectorAll(`[data-js*='thumb'] .slide`)
      : indicatorArea.length > 0 
        ? indicatorArea[indicatorArea.length - 1].querySelectorAll('.indicator')
        : null
    carousel.arrows = arrowArea[arrowArea.length - 1].querySelectorAll('button')
    // 이미지 로딩 후 셋팅
    this.checkImageLoad(carousel)
    // transition
    this.setTransition(carousel)
    // click arrow button 
    this.clickArrow(carousel)
    // click indicators or slides
    this.clickIndicatorSlide(carousel)
    // focus btn
    this.focusButtonInSlide(carousel)
    // swiper carousel
    this.swipeCarousel(carousel)
    // create clones
    // carousel.type.includes('centeredSlide') && this.createClones(carousel)
    // active thumb slide
    this.setActive(carousel)
  }
  checkImageLoad(carousel) {
    // 이미지 로딩이 느린 경우 높이값이 0으로 들어오는 경우 있어 체크

    // 슬라이드에 이미지 없는 경우도 있어 체크
    let imgSample = null
    for(const slide of carousel.slides) {
      const img = slide.querySelector('img')
      if(img) {
        imgSample = img
        break
      }
    }

    const checkImageHeight = setInterval(() => {
      if(imgSample.complete || !imgSample){
        clearInterval(checkImageHeight)    
        // setting carousel
        this.carouselSettingHandler(carousel)
      }
    }, 150)
  }
  carouselSettingHandler(carousel) {
    /*** 아래 함수들은 실행 순서 지켜져야 함 ***/
    // pc, mobile 전환된 경우에만 실행
    if(this.isPcSize.now !== this.isPcSize.before){
      // step 1. slides per view
      this.setSlidesPerView(carousel)
      // step 2. thumbnail area 남는 공간에 default slides 삽입
      this.createDefaultSlide(carousel)
      // step 999. mo > pc : centeredSlide sliding area transform 초기화
      if(carousel.type.includes('centeredSlide') && this.isPcSize.now) {
        carousel.slidingArea.style.cssText = ''
        for(const slide of carousel.slides) {
          slide.style.cssText = ''
        }
      }
    }
    const isExteriorPopup = carousel.el.parentNode.getAttribute('class').includes('exterior')
    // 우측 텍스트 영역 때문에 가로 사이즈 불러오는 이슈가 있어 예외 처리
    if(!isExteriorPopup) {
      // step 3. slides width
      this.setSlideWidth(carousel)
      // step 4. sliding area 사이즈 지정
      this.setWidthSlidingArea(carousel)
    }
    // step 5. slides number 체크 하여 slides per view보다 적으면 arrow 숨김처리
    this.checkSlidesNumHideArrow(carousel)
    // step 999. indicator top position
    this.setTopPosUtils(carousel)
  }
  setTransition(carousel) {
    carousel.slidingArea.style.transition = 'transform 0.5s ease'
  }
  setActive(carousel) {
    const targetsArray = [carousel.slides, carousel.indicators],
          classNames = {
            active: 'is-active',
            prev: 'prev',
            prevBefore: 'prev-before',
            next: 'next',
            nextAfter: 'next-after'
          },
          nextIndex = carousel.activeIndex
    for(const targets of targetsArray){
      if(!targets) continue
      const activeElement = findElementHasClass(targets, classNames.active),
            targetButton = targets[0].querySelector('button'),
            isAriaSelected = targetButton ? targetButton.attributes['aria-selected'] : null,
            isSlide = targets[0].getAttribute('class').includes('slide')

      // active, active 전 후 슬라이드 클래스명 재설정
      for(const key in classNames){
        const element = findElementHasClass(targets, classNames[key]),
              prevOrNext = key === 'prev' || key === 'next'
        let nextIndexByElement = nextIndex
        // CENTERED SLIDE - prev/next 관련 설정들은 슬라이드 길이에 따라 next Index 설정
        if(isSlide && key !== 'active') {
          let params = []
          switch (key) {
            case 'prev':
              params = [-1, 'prev']
              break
            case 'prevBefore':
              params = [-2, 'prev']
              break
            case 'next':
              params = [1, 'next']
              break
            case 'nextAfter':
              params = [2, 'next']
              break
          }
          // prev, next 엘리먼트가 슬라이드 인덱스 범위 벗어났을때 설정
          const slideNextIndex = nextIndex + params[0]
          nextIndexByElement = params[1] === 'prev'
             ? slideNextIndex < 0 ? carousel.lastSlideIndex + slideNextIndex + 1 : slideNextIndex 
             : slideNextIndex > carousel.lastSlideIndex ? slideNextIndex - carousel.lastSlideIndex - 1 : slideNextIndex
        }
        // 기존 클래스명, tabindex 제거
        if(element) {
          element.classList.remove(classNames[key])
          prevOrNext && element.removeAttribute('tabindex')
        }
        // 새로 클래스명, tabindex 추가
        targets[nextIndexByElement].classList.add(classNames[key])        
        isSlide && prevOrNext && targets[nextIndexByElement].setAttribute('tabindex', 0)
        // 인디게이터 컬러 설정
        if(isSlide && carousel.indicators) {
          const indicatorColorData = targets[nextIndex].dataset.indicator,
                indicatorWrap = carousel.indicators[0].parentNode.parentNode.parentNode
          indicatorColorData && indicatorColorData.includes('black')
          ? indicatorWrap.classList.add('black')
          : indicatorWrap.getAttribute('class').includes('black') 
            && indicatorWrap.classList.remove('black')
        }
      }
      // aria 재설정
      activeElement && isAriaSelected && activeElement.querySelector('button').setAttribute('aria-selected', 'false')
      isAriaSelected && targets[nextIndex].querySelector('button').setAttribute('aria-selected', 'true')
    }
  }
  setSlidesPerView(carousel) {
    /*  slides Per View 
       (thumb carousel은 pc에서 slide 6개, 모바일에서 4개. 나머지는 1개) */
    const isThumbCarousel = carousel.type.includes('thumb')
    carousel.slidesPerView = isThumbCarousel ? (this.isPcSize.now ? 6 : 4) : 1
  }
  createDefaultSlide(carousel) {
    const slideDivideRemainder = carousel.slides.length % carousel.slidesPerView,
          defaultSlideNum = slideDivideRemainder ? carousel.slidesPerView - (slideDivideRemainder) : 0
    let defaultArea = carousel.el.querySelectorAll('.area-default')[0]

    // default slide가 필요 없는 경우
    if (defaultSlideNum === 0) return false

    // 최초 진입 시, default slide number & default area 셋팅
    if(!defaultArea) {
      defaultArea = document.createElement('div')
      defaultArea.classList.add('area-default')
    } 

    // default area, default slides 삽입
    const slidingArea = carousel.el.querySelectorAll('.area-sliding')[0]
    let defaultSlidesHTML = ''
    for (let j = 0; j < defaultSlideNum; j++) {
      defaultSlidesHTML += `<div class="slide-default"></div>`
    }
    defaultArea.innerHTML = defaultSlidesHTML
    slidingArea.appendChild(defaultArea)
  }
  createClones(carousel) {
    const slides = carousel.slides,
          listSlide = carousel.el.querySelectorAll('.list-slide')[0],
          cloneFirstSlide = slides[0].cloneNode(true),
          cloneLastSlide = slides[carousel.lastSlideIndex].cloneNode(true) 
    cloneFirstSlide.classList.add('clone')
    cloneLastSlide.classList.add('clone')
    listSlide.insertBefore(cloneLastSlide, slides[0])
    listSlide.appendChild(cloneFirstSlide)
  }  
  setSlideWidth(carousel) {
    const defaultSlideArea = carousel.el.querySelectorAll('.area-default')[0],
          defaultSlides = defaultSlideArea 
            ? defaultSlideArea.children
            : [],
          allSlides = [...defaultSlides, ...carousel.slides],
          slideWidth = carousel.el.offsetWidth / carousel.slidesPerView
    // ie에서 가로값 17px 오차 있어 분기처리 (스크롤 너비로 추정) ---- 현재는 사라진 이슈이나 추후 확인될 수 있어 주석
    // const agent = navigator.userAgent.toLowerCase(),
    //       isIE = (navigator.appName == 'Netscape' && navigator.userAgent.search('Trident') != -1) || (agent.indexOf('msie') != -1),
    //       isSectionFull = carousel.el.getAttribute('class').includes('section-full')
    // carousel.slideWidth = (isIE && isSectionFull && window.innerWidth > 1280) 
    //   ? slideWidth + 17
    //   : slideWidth
    carousel.slideWidth = slideWidth
    if(!(carousel.type.includes('centeredSlide') && this.isPcSize.now)) {
      for (const slide of allSlides) {
        slide.style.cssText = `width: ${carousel.slideWidth}px`
      }
    }
  }
  setWidthSlidingArea(carousel) {
    if(carousel.type.includes('centeredSlide') && this.isPcSize.now) return false
    const slides = carousel.slides,
          defaultSlideArea = carousel.el.querySelectorAll('.area-default')[0],
          defaultSlides = defaultSlideArea 
            ? defaultSlideArea.children
            : [],
          slidesLength = slides.length + defaultSlides.length,
          slidingAreaWidth = carousel.slideWidth * slidesLength
    carousel.slidingArea.style.width = `${slidingAreaWidth}px`
  }
  sliding(carousel) {
    if(carousel.type.includes('centeredSlide') && this.isPcSize.now) return false
      // active slide 위치 찾아 view port 사이즈만큼 슬라이딩
    const slidingX = carousel.slideWidth * carousel.slidesPerView,
          nextActiveSlideBundle = Math.ceil((carousel.activeIndex + 1) / carousel.slidesPerView) - 1
    carousel.slidingArea.style.transform = `translateX(-${ slidingX * nextActiveSlideBundle }px)`
  }
  slidingHandler(carousel, nextIndex) {
    // 영상 자막 활성화된 경우 비활성화
    const activeSlide = carousel.slides[carousel.activeIndex],
          subTitleContents = activeSlide.querySelector('.subtitle-con')
    if(subTitleContents && subTitleContents.getAttribute('class').includes('active')) {
      subTitleContents.classList.remove('active')
    }
    // 영상 재생중인 경우 비활성화
    const activeVideo = activeSlide.querySelector('.video-wrap.active video')
    activeVideo && this.video.disableVideo()

    // active index 변경
    carousel.activeIndex = nextIndex
    // next active index 해당 슬라이드 active data 적용 (for css)
    this.setActive(carousel)
    // sliding
    this.sliding(carousel)
  }
  checkSlidesNumHideArrow(carousel) {
    // slide 갯수가 slides per view보다 적거나 같은 경우 arrow 비노출
    const arrowArea = carousel.arrows[0].parentNode,
          isSlidesLessThanPerView = carousel.slides.length <= carousel.slidesPerView
    arrowArea.style.cssText = isSlidesLessThanPerView ? 'display: none;' : ''
  }
  setTopPosUtils(carousel) {
    if(this.isDesignTypeB) return false //design type b는 css로 위치 잡음
    const util = carousel.el.querySelectorAll('.area-indicator')[0],
          arrows = carousel.el.querySelectorAll('.area-arrow')[0].querySelectorAll('.el-carousel__arrow'),
          imageHeight = carousel.slides[0].querySelector('img').offsetHeight
    if (util) {
      const utilStyle = this.isPcSize.now 
        ? `top: ${imageHeight - util.offsetHeight}px;`
        : 'position: static;'
      util.style.cssText = utilStyle
    }
    if (arrows) {
      for (const arrow of arrows) {
        const arrowTopPos = (imageHeight - arrow.offsetHeight) / 2
        arrow.style.top = `${arrowTopPos}px`
      }
    }
  }
  returnNextIndex(carousel, prevOrNext) {
    // active slide index, button type, slides per view 체크하여 next active index값 설정
    const lastIdx = carousel.lastSlideIndex,
          slidesPerView = carousel.slidesPerView,
          activeSlideView = Math.ceil((carousel.activeIndex + 1) / slidesPerView) - 1,
          lastSlideView = Math.ceil((lastIdx + 1) / slidesPerView) - 1

    let nextIndex
    if (prevOrNext == 'next') {
      nextIndex = activeSlideView == lastSlideView
        ? 0 // check last slide
        : (activeSlideView + 1) * slidesPerView
    } else if (prevOrNext == 'prev') {
      nextIndex = activeSlideView == 0
        ? lastSlideView * slidesPerView // check first slide
        : (activeSlideView - 1) * slidesPerView
    }
    return nextIndex
  }
  clickArrow(carousel) {
    for (const arrow of carousel.arrows) {
      arrow.addEventListener('click', () => {
        const prevOrNext = arrow.dataset.btn
        this.slidingHandler(carousel, this.returnNextIndex(carousel, prevOrNext))
      })
    }
  }
  clickIndicatorSlide(carousel) {
    for (let j = 0; j < carousel.slides.length; j++) {
      if(carousel.indicators) {
        carousel.indicators[j].querySelector('button').addEventListener('click', () => {
          this.slidingHandler(carousel, j)
        })
      }
      if(carousel.type === 'centeredSlide') {
        const slide = carousel.slides[j]
          slide.addEventListener('click', () => {
            const slideClassName = slide.getAttribute('class')
            if(slideClassName.includes('prev') || slideClassName.includes('next')) {
              this.slidingHandler(carousel, j)
            }
          })
      }
    }
  }
  clickSlides(carousel) {
    for (let j = 0; j < carousel.slides.length; j++) {
      const slide = carousel.slides[j]
      slide.addEventListener('click', () => {
        this.slidingHandler(carousel, j)
      })
    }
  }
  focusButtonInSlide(carousel) {
    for(let i = 0; i < carousel.slides.length; i++) {
      const buttonInSlide = carousel.slides[i].querySelectorAll('a, button')[0]
      if(!buttonInSlide) continue
      buttonInSlide.addEventListener('focus', () => {
        this.slidingHandler(carousel, i)
      })
    }
  }
  swipeCarousel(carousel) {
    const touchArea = carousel.el.parentNode ? carousel.el.parentNode : carousel.el    
    let touchMoveX, touchMoveY
    touchArea.addEventListener('touchstart', (e) => {
      touchMoveX =  e.touches[0].clientX
      touchMoveY = e.touches[0].clientY
    }, false)
    touchArea.addEventListener('touchend', (e) => {
      const isPopupInCarouselActive = carousel.el.querySelector('.popup-body.active')
      if(!isPopupInCarouselActive) {
        const changedTouch = e.changedTouches[0],
              moveDistanceX = Math.abs(touchMoveX - changedTouch.clientX),
              moveDistanceY = Math.abs(touchMoveY - changedTouch.clientY)
        if ( moveDistanceX > 15 && moveDistanceX > moveDistanceY) {
          const prevOrNext = touchMoveX - changedTouch.clientX > 0 ? 'next' : 'prev'
          this.slidingHandler(carousel, this.returnNextIndex(carousel, prevOrNext))
        }
      }
    }, false)
  }
  windowResizeHandler() {
    this.isPcSize.before = this.isPcSize.now
    this.isPcSize.now = window.innerWidth > 768
    for (const carousel of this.carousels) {
      // resize 할땐 transition 제거
      carousel.slidingArea.style.transition = 'none'
      this.carouselSettingHandler(carousel)
      this.sliding(carousel)
      this.setTransition(carousel)
    }
  }
}
function findElementHasClass(elements, className) {
  let result
  Array.from(elements).find((element) => {
    if (element.getAttribute('class').split(' ').includes(className)) result = element
  })
  return result
}
export default MultiCarousel