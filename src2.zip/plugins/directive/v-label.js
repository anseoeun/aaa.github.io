const autoLabel = {
  bind: (el, binding, vnode) => {
    let value = binding.value
    let label = el.querySelector('label')
    let input = el.querySelector('input, textarea')
    let inputDid = input.dataset.id
    let pageName = vnode.context.$route.name
    let init = {
      labelfor(val) {
        label.setAttribute('for', val)
        input.setAttribute('id', val)
      }
    }
    value ? init.labelfor(value) : init.labelfor(pageName + inputDid)
  }
}

export default autoLabel
