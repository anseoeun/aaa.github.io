import Vue from 'vue'
import label from './v-label.js'
import caption from './v-caption.js'
import btmlayer from './v-btmlayer.js'
import scrolltab from './v-scrolltab.js'

Vue.directive('label', label)
Vue.directive('caption', caption)
Vue.directive('btmlayer', btmlayer)
Vue.directive('scrolltab', scrolltab)