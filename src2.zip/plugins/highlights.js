import Vue from 'vue'
import VueHighlightJS from 'vue-highlight.js'

import javascript from 'highlight.js/lib/languages/javascript'
import html from 'highlight.js/lib/languages/htmlbars'
import vue from 'vue-highlight.js/lib/languages/vue'

/*
 * Import Highlight.js theme
 * Find more: https://highlightjs.org/static/demo/
 */
import 'highlight.js/styles/default.css'

export default () => {
  Vue.use(VueHighlightJS, {
    languages: {
      javascript,
      html,
      vue
    }
  })
}
