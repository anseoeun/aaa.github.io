import Vue from 'vue'
import VueMq from 'vue-mq'

/**
 * 뷰포트 너비 감지
 * https://www.npmjs.com/package/vue-mq
 */

export default () => {
  Vue.use(VueMq, {
    breakpoints: {
      mobile: 768,
      tablet: 1025,
      desktop: Infinity
    },
    defaultBreakpoint: 'desktop'
  })

  Vue.mixin({
    computed: {
      $isMobile() {
        return this.$mq === 'mobile'
      },
      $isTablet() {
        return this.$mq === 'tablet'
      },
      $isDesktop() {
        return this.$mq === 'desktop'
      }
    }
  })
}
