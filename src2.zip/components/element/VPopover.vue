<template>
  <el-popover
    :value="value"
    :placement="placement"
    :title="title"
    :width="width"
    :trigger="trigger"
    :content="content"
    :offset="offset"
    :transition="transition"
    :popper-class="popoverType"
    :disabled="disabled"
    :visible-arrow="visibleArrow"
    :popper-options="popperOptions"
    :open-delay="openDelay"
    @show="$emit('input', true)"
    @hide="$emit('input', false)"
  >
    <slot v-if="content === null"></slot>
    <template slot="reference">
      <slot name="reference"></slot>
    </template>
  </el-popover>
</template>

<script>
export default {
  props: {
    value: {
      type: Boolean,
      default: false
    },
    placement: {
      type: String,
      default: 'bottom-start'
    },
    title: {
      type: String,
      default: ''
    },
    width: {
      type: String,
      default: '250'
    },
    trigger: {
      type: String,
      default: 'click'
    },
    content: {
      type: String,
      default: null
    },
    popoverType: {
      type: String,
      default: ''
    },
    disabled: {
      type: Boolean,
      default: false
    },
    offset: {
      type: Number,
      default: 0
    },
    transition: {
      type: String,
      default: 'el-fade-in-linear'
    },
    visibleArrow: {
      type: Boolean,
      default: true
    },
    popperOptions: {
      type: Object,
      default: () => ({ boundariesElement: 'body', gpuAcceleration: false })
    },
    openDelay: {
      type: Number,
      default: null
    }
  },

  data() {
    return {}
  },

  mounted() {
    // console.log(this.$slots.reference)
  },

  methods: {}
}
</script>
