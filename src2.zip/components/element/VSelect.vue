<template>
  <el-select
    :value="selected"
    :class="[`${selectType}`, {'no-selected' : selected === ''}]"
    :placeholder="placeholder"
    :disabled="disabled"
    :popper-append-to-body="popperAppendToBody"
    :style="[{width:width+'px'}]"
    @input="onInput"
    @change="onChange"
  >
    <el-option
      v-for="item in list"
      :key="item.value"
      :label="item[labelKey]"
      :value="item[valueKey]"
      :disabled="item.disabled"
    >
      <slot :item="item"></slot>
    </el-option>
  </el-select>
</template>

<script>
export default {
  props: {
    version: {
      type: Number,
      default: 1
    },

    value: {
      type: String,
      default: ''
    },
    valueKey: {
      type: String,
      default: 'value'
    },
    labelKey: {
      type: String,
      default: 'label'
    },
    placeholder: {
      type: String,
      default: ''
    },
    data: {
      type: Array,
      default: () => []
    },
    disabled: {
      type: Boolean,
      default: false
    },
    firstSelect: {
      type: Boolean,
      default: false
    },
    selectType: {
      type: String,
      default: ''
    },
    popperAppendToBody :{
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      selected: '',
      width:'',
    }
  },

  computed: {
    list() {
      return this.data.length ? this.data.map((obj) => ({ ...obj })) : [{ [this.valueKey]: '', [this.labelKey]: '' }]
    }
  },

  watch: {
    value(newValue, oldValue) {
      if (this.version >= 2) {
        return
      }

      if (newValue !== oldValue) {
        this.selected = newValue
        this.$emit('change', newValue)
      }
    },

    data(newList, oldList) {
      let isDiff = newList.length !== oldList.length
      if (!isDiff) {
        newList.forEach(({ value, label }, index) => {
          if (oldList[index].value !== value || oldList[index].label) {
            isDiff = true
          }
        })
      }

      if (isDiff) {
        if (!newList.length) {
          this.selected = ''
          this.$emit('input', '')
        } else {
          this.selected = this.value === '' && this.firstSelect ? newList[0][this.valueKey] : this.value
          this.$emit('input', this.selected)
        }
      }
    }
  },

  created() {
    this.selected = this.value === '' && this.firstSelect ? this.list[0][this.valueKey] : this.value
    if (this.selected !== '') {
      this.$emit('change', this.selected)
    }
  },
  mounted() {
    if(this.$el.className.includes('select-radius')){
     this.valueCheck(this.value)
    }
  },
  methods: {
    onInput(value) {
      if (this.version >= 2) {
        this.selected = value
      }

      this.$emit('input', value)
    },
    onChange(value) {
      if(this.$el.className.includes('select-radius')) this.valueCheck(value)
      this.$emit('change', value)
    },
    valueCheck(value){
      let val = value
      this.list.forEach(({ value, label }, index) => {
        if(value == val){
          // this.width = label.length * 15 + 30
         }
      })
    }
  }
}
</script>
