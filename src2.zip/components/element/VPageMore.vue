<template>
  <div class="page-more">
    <a href="javascript:void(0);" class="more" role="button" @click="handleClick">
      더보기 +
    </a>
  </div>
</template>

<script>
export default {
  name: 'VPageMore',
  methods: {
    handleClick(e) {
      this.$emit('click', e)
    }
  }
}
</script>
