﻿<template>
  <div :class="['tab-wrap', tabType]">
    <div class="tab-menu">
      <!-- Prepend -->
      <div v-if="$slots.prepend" class="prepend">
        <slot name="prepend"></slot>
      </div>

      <ul ref="tabbtn">
        <li
          v-for="(item, index) in list"
          :ref="`tabbtn${index}`"
          :key="index"
          :class="{ active: item[valueKey] === selected }"
        >
          <a
            v-if="item[linkKey] && typeof item[linkKey] === 'string'"
            :href="item[linkKey]"
            :target="item.target ? item.target : '_self'"
            :class="{ active: item[valueKey] === selected }"
          >
            <span v-if="!customLabel">{{ item[labelKey] }}</span>
            <slot v-else name="label" :item="item"></slot>
          </a>

          <button
            v-if="item[linkKey] && typeof item[linkKey] !== 'string'"
            type="button"
            :class="{ active: $route.name === item[linkKey].name }"
            @click.prevent="onTabLink(item, index)"
          >
            <span
              v-if="tabType === 'radio-transition'"
              class="radio-simbol"
            ></span>
            <span v-if="!customLabel">{{ item[labelKey] }}</span>
            <slot v-else name="label" :item="item"></slot>
          </button>

          <button
            v-if="!item[linkKey]"
            type="button"
            :class="{ active: item[valueKey] === selected }"
            @click="onTabClick(item, index, 'click')"
            @mouseenter="onTabHover(item, index, 'hover')"
          >
            <span
              v-if="tabType === 'radio-transition'"
              class="radio-simbol"
            ></span>
            <span v-if="!customLabel">{{ item[labelKey] }}</span>
            <slot v-else name="label" :item="item"></slot>
          </button>
        </li>
      </ul>

      <!-- Append -->
      <div v-if="$slots.append" class="append">
        <slot name="append"></slot>
      </div>
    </div>

    <!-- Tab Contents -->
    <div v-if="contents" class="tab-contents">
      <slot name="contents" :list="list"></slot>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    isResponsive: {
      type: Boolean,
      default: false,
    },
    breakPoints: {
      type: Array,
      default: () => ['mobile', 'tablet'],
    },
    isCustomEvent: {
      type: Boolean,
      default: false,
    },
    customEvent: {
      type: Function,
      default: () => {},
    },
    value: {
      type: [String, Object, Number],
      default: null,
    },
    data: {
      type: Array,
      default: () => [],
    },
    customLabel: {
      type: Boolean,
      default: false,
    },
    valueKey: {
      type: String,
      default: 'value',
    },
    labelKey: {
      type: String,
      default: 'label',
    },
    linkKey: {
      type: String,
      default: 'link',
    },
    contents: {
      type: Boolean,
      default: false,
    },
    tabType: {
      type: String,
      default: '',
    },
    trigger: {
      type: String,
      default: 'click',
    },
    cols: {
      type: Number,
      default: null,
    },
    init: {
       type: Boolean,
      default: false,
    },
  },

  data() {
    return {
      selected: '',
      selectedItem: { label: '전체' },
      isMenuOpen: false,
    }
  },

  computed: {
    isLinkType() {
      return (item) => item[this.linkKey]
    },
    isSelect() {
      return (item) => item[this.valueKey] === this.selected
    },

    // getWidthStyle() {
    //   if (this.cols) {
    //     return `width: ${100 / this.cols}%`
    //   } else {
    //     return this.tabType.startsWith('sp')
    //       ? ''
    //       : `width: ${100 / this.list.length}%`
    //   }
    // },

    list() {
      return this.data.map((item, index) => {
        return typeof item === 'string'
          ? {
              value: String(index),
              label: item,
            }
          : { ...item }
      })
    },
  },

  watch: {
    value(newValue, oldValue) {
      console.log('watch')
      const type = typeof newValue
      const isDiff =
        type === 'object'
          ? newValue[this.valueKey] !== oldValue[this.valueKey]
          : newValue !== oldValue
      if (isDiff) {
          const value =
            this.value !== null
              ? typeof this.value === 'object'
                ? this.value[this.valueKey]
                : this.value
              : this.value
          let itemIndex =
            value !== null
              ? this.list.findIndex((item) => item[this.valueKey] === value)
              : 0
          itemIndex = itemIndex || 0
          setTimeout(() => {
            this.onTabActive(this.list[itemIndex], itemIndex)
          }, 0)
      }
    },
  },

  created() {
    if(this.init) return
    let itemIndex =
      this.value !== null
        ? this.list.findIndex((item) => item[this.valueKey] === this.value)
        : 0
    itemIndex = itemIndex || 0

    this.setSelectedTab(this.list[itemIndex], 0)
  },

  mounted() {
    if(this.init) return
    const value =
      this.value !== null
        ? typeof this.value === 'object'
          ? this.value[this.valueKey]
          : this.value
        : this.value
    let itemIndex =
      value !== null
        ? this.list.findIndex((item) => item[this.valueKey] === value)
        : 0
    itemIndex = itemIndex || 0
    setTimeout(() => {
      this.onTabActive(this.list[itemIndex], itemIndex)
    }, 0)
    /*
    if (this.$slots.contents) {
      this.setContents()
    }
    */
  },

  methods: {
    mob_onClick(event) {
      // let index
      let eTarget = event.target
      if (eTarget.tagName === 'SPAN') {
        eTarget = event.target.parentNode
      }

      const index = eTarget.getAttribute('data-num')
      if (index) {
        this.mob_setContents(index)
        this.isCustomEvent &&
          this.$emit('customEvent', { idx: index, ev: event })
        this.isMenuOpen = false
      }
    },

    mob_setContents(index) {
      const item = this.list[index]
      const prevState = this.selected
      const currState = [].concat(item.value)[0]

      if (prevState !== currState) {
        this.selected = currState
        this.selectedItem = item
        this.setContents()
      }
    },

    setContents() {
      this.$slots.contents.forEach((node) => {
        if (node.data && node.elm && node.elm.classList) {
          node.elm.classList.remove('show')
          if (node.data.attrs['data-id'] === this.selected) {
            node.elm.classList.add('show')
          }
        }
      })
    },

    setSelectedTab(item, index) {
      this.selected = item[this.valueKey]
      this.selectedItem = item
      const isNLink =
        item[this.linkKey] && typeof item[this.linkKey] !== 'string'

      if (this.$slots.contents) {
        this.setContents()
      }
      if (isNLink && this.$route.name !== item[this.linkKey].name) {
        this.$router.push({ ...item[this.linkKey] })
      }
    },

    onTabClick(item, index, evtType) {
      if (!this.trigger.includes('click')) {
        return
      }
      this.onTabActive(item, index, evtType)
    },

    onTabHover(item, index, evtType) {
      if (!this.trigger.includes('hover')) {
        return
      }
      this.onTabActive(item, index, evtType)
    },

    onTabActive(item, index, evtType) {
      this.setSelectedTab(item)
      const valueData =
        typeof this.data[0] === 'string' ? this.data[index] : this.list[index]
      this.$emit('input', valueData, index, evtType)
      this.$emit('change', valueData, index, evtType)
      this.$refs.tabbtn.scrollLeft = this.$refs['tabbtn'+index][0].offsetLeft - this.$refs.tabbtn.offsetLeft
    },

    onTabLink(item) {
      if (this.trigger !== 'click') {
        return
      }
      this.selected = item[this.valueKey]
      this.$router.push({ ...item[this.linkKey] })
    },
  },
}
</script>
