export default {
  props: {
    tag: {
      type: String,
      default: ''
    },
    template: {
      type: String,
      default: ''
    }
  },

  data() {
    return {
      currentTag: 'div',
      _element: null
    }
  },

  watch: {
    template(newValue) {
      this._element.innerHTML = newValue
    }
  },

  created() {
    this.currentTag = this.tag || this.currentTag
  },

  render(createElement) {
    return createElement(this.currentTag, {
      class: 'viewer'
    })
  },

  // After first time render.
  mounted() {
    this._element = this.$el

    // if (this.value) {
    this._element.innerHTML = this.template
    this.$emit('load')
    // }
  }
}
