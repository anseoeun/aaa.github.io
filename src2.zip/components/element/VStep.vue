<template>
  <div class="step" :class="`${stepType}`">
    <ul>
      <li
        v-for="(item, index) in data"
        :key="index"
        :class="{ active: stepHere == index + 1 }"
        :style="{ width: 100 / data.length + '%' }"
      >
        <span>{{ item }}</span>
      </li>
    </ul>
  </div>
</template>

<script>
export default {
  props: {
    stepHere: {
      type: String,
      default: '1'
    },
    stepType: {
      type: String,
      default: ''
    },
    data: {
      type: Array,
      default: () => []
    }
  }
}
</script>
