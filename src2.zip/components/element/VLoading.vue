<template lang="html">
  <div v-if="loading" class="loading-page">
    <div class="contents">
      <div class="image">
        <img src="/static/images/pages/payment/Loading_Car.gif" alt />
      </div>
      <div class="text" style="overflow:hidden;">
        <p class="title">{{ message }}</p>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data: () => ({
    loading: false,
    message: '잠시만 기다려 주세요.'
  }),
  methods: {
    start(msg = this.message) {
      this.message = msg
      this.loading = true
    },
    finish() {
      this.message = '잠시만 기다려 주세요.'
      this.loading = false
    }
  }
}
</script>
