<template>
  <div class="pagination">
    <v-btn i-name="btn-prevall" class="btn-prevall">
      <span class="ir">처음</span>
    </v-btn>
    <v-btn i-name="btn-prev" class="btn-prev">
      <span class="ir">이전</span>
    </v-btn>

    <div class="page-index text-b1">
      <n-link to="" class="on ">
        <span>1</span>
      </n-link>
      <n-link to="">
        <span>2</span>
      </n-link>
      <n-link to="">
        <span>3</span>
      </n-link>
      <n-link to="">
        <span>4</span>
      </n-link>
      <n-link to="">
        <span>5</span>
      </n-link>
      <template v-if="$mq === 'desktop'">
        <n-link to="">
          <span>6</span>
        </n-link>
        <n-link to="">
          <span>7</span>
        </n-link>
        <n-link to="">
          <span>8</span>
        </n-link>
        <n-link to="">
          <span>9</span>
        </n-link>
        <n-link to="">
          <span>10</span>
        </n-link>
      </template>
    </div>

    <v-btn i-name="btn-next" :class="'ative'" class="btn-next">
      <span class="ir">다음</span>
    </v-btn>
    <v-btn i-name="btn-nextall" :class="'ative'" class="btn-nextall">
      <span class="ir">마지막</span>
    </v-btn>
  </div>
</template>

<script>
import { VBtn } from '~/components/element'
export default {
  components: {
    VBtn
  }
}
</script>
