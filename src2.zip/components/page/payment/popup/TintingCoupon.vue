<template>
  <v-popup
    :visible="popVisible.tintingCoupon"
    @confirm="popVisible.tintingCoupon = false"
    @close="popVisible.tintingCoupon = false"
  >
    <template slot="header">
      <div class="title">썬팅 무료 시공</div>
      <p class="header-description">지정 장착점을 통하여 프리미엄 썬팅 서비스를 제공 받으실 수 있습니다.</p>
    </template>
    <template slot="body">
      <ul class="body-contents">
        <li>
          <p class="contents-head">예약안내</p>
          <ul class="body-description-list">
            <li>가까운 지정 장착점을 확인하시고 미리 연락하신 후 썬팅 시공을 받으시면 됩니다. (필요정보: 차대번호)</li>
            <li>* 썬팅 시공권 출력은 불필요하며 장착점을 방문하여 차대번호를 확인해 주시면 됩니다.</li>
          </ul>
        </li>
        <li>
          <p class="contents-head">공식 시공필름 안내</p>
          <ul class="body-description-list">
            <li>디텍, 존슨, 레이노, 틴트어카, 썬가드, SKC, 3M, 솔라가드, 루마 중 선택 가능</li>
            <li>
              필름 상세 안내 (<a
                href="http://www.tbsunting.com/new_user.film_intro.jsp"
                target="_blank"
                title="새창 열림"
                >http://www.tbsunting.com/new_user.film_intro.jsp</a
              >)
            </li>
          </ul>
        </li>
      </ul>
      <div class="notice">
        <ul class="bullet-list">
          <li>시공점마다 보유하고 있는 필름브랜드가 일부 상이할 수 있습니다.</li>
          <li>본 썬팅쿠폰 시공가능 범위는 창유리 측/후면 입니다.</li>
        </ul>
        <p class="bullet-star">가시광선 투과율 허용 기준 : 운전석 좌우 옆면 창유리 40% 이상 (도로교통법 제 49조)</p>
      </div>
    </template>
    <template slot="footer">
      <div class="btn-group round">
        <v-btn class="btn" b-size="btn-md">확인</v-btn>
      </div>
    </template>
  </v-popup>
</template>

<script>
import { VPopup } from '~/components/element'
export default {
  components: {
    VPopup
  },
  props: {
    popVisible: {
      type: Object,
      defualt: {},
      required: true
    }
  }
}
</script>
