<template>
  <v-popup :visible="popVisible.installmentIncrease" @close="popVisible.installmentIncrease = false">
    <template slot="header">
      <div class="title">카드한도 상향 신청</div>
      <p class="header-description">
        간편하게 한도를 조회할 수 있는 URL을 보내드립니다.<br />휴대폰 번호를 입력해 주세요.
      </p>
    </template>
    <template slot="body">
      <el-form ref="form" :model="phoneForm" :rules="rules">
        <el-form-item prop="phoneNumber">
          <div class="form-grid">
            <div v-label class="label-input">
              <label class="form-title">휴대폰 번호</label>
              <v-input
                v-model="phoneForm.phoneNumber"
                class="form-group"
                type="number"
                maxlength="12"
                placeholder="'-'없이 숫자만 입력"
              />
            </div>
          </div>
        </el-form-item>
      </el-form>
    </template>
    <template slot="footer">
      <div class="btn-group">
        <v-btn class="btn btn-md" b-size="btn-md">전송하기</v-btn>
      </div>
    </template>
  </v-popup>
</template>

<script>
import { VPopup, VBtn, VInput } from '~/components/element'
export default {
  components: {
    VPopup,
    VBtn,
    VInput
  },
  props: {
    popVisible: {
      type: Object,
      default: () => {
        return {}
      },
      required: true
    }
  },
  data() {
    return {
      phoneForm: {
        phoneNumber: ''
      }
    }
  },
  computed: {
    rules() {
      return {
        phoneNumber: [
          {
            required: true,
            message: '* 휴대폰번호를 입력해 주세요',
            trigger: 'blur'
          }
        ]
      }
    }
  }
}
</script>
