<template>
  <div class="gray-bg">
    <v-popup
      :width="'1000px'"
      :visible="popVisible.recommendOption"
      :append-to-body="false"
      @close="popVisible.recommendOption = false"
    >
      <template slot="header">
        <div class="title">BEST 옵션 조합</div>
        <p class="header-description">인기있는 옵션조합으로 옵션을 빠르고 간편하게 선택해 보세요.</p>
      </template>
      <template slot="body">
        <ul class="recommend-option-list">
          <li>
            <div class="ranking">1위</div>
            <div class="option-type">
              <ul>
                <li>
                  <span>선루프</span>
                  <em>600,000 원</em>
                </li>
                <li>
                  <span>스타일 패키지Ⅰ</span>
                  <em>1,000,000 원</em>
                </li>
                <li>
                  <span>터보패키지Ⅰ</span>
                  <em>1,000,000 원</em>
                </li>
              </ul>
              <div class="total">총 <strong>2,300,000</strong>원</div>
            </div>
            <v-btn class="btn md blue line r" type="button">선택 적용하기</v-btn>
          </li>
          <li>
            <div class="ranking">2위</div>
            <div class="option-type">
              <div class="total">총 <strong>0</strong>원</div>
            </div>
            <v-btn class="btn md blue line r" type="button">선택 적용하기</v-btn>
          </li>
          <li>
            <div class="ranking">3위</div>
            <div class="option-type">
              <ul>
                <li>
                  <span>선루프</span>
                  <em>600,000 원</em>
                </li>
                <li>
                  <span>스타일 패키지Ⅰ</span>
                  <em>1,000,000 원</em>
                </li>
                <li>
                  <span>하이패스</span>
                  <em>1,000,000 원</em>
                </li>
                <li>
                  <span>시트 패키지</span>
                  <em>2,300,000 원</em>
                </li>
              </ul>
              <div class="total">총 <strong>2,300,000</strong>원</div>
            </div>
            <v-btn class="btn md blue line r" type="button">선택 적용하기</v-btn>
          </li>
        </ul>
      </template>
    </v-popup>
  </div>
</template>

<script>
import { VBtn } from '~/components/element'
export default {
  components: {
    VBtn
  },

  props: {
    popVisible: {
      type: Object,
      defualt: {},
      required: true
    }
  }
}
</script>
