<template>
  <div class="matching-box border-line">
    <div class="box-wrap">
      <div class="box-tit main-title">판촉차 상세 설명</div>
      <div class="box-desc">
        <div class="match-box">
          <div class="title">판촉차 구매 유의 사항</div>
          <div class="desc">
            <ol class="num">
              <li>1. 판촉차의 상태는 개인에 따라 다르게 느껴질 수 있는 부분이므로 고객님께서 출고센터로 직접 방문하셔서 차량 상태 확인 후 인수하셔야 합니다.</li>
              <li>2. 차량 상태가 고객님께서 생각하신 것과 다른 경우 차량 인수를 거부할 수 있으며, 인수 거부시 고객센터 (080-500-6000) 으로 전화 주시면 취소 처리 해드리겠습니다.</li>
            </ol>
          </div>
        </div>
        <div class="match-box">
          <div class="title">차량 상세 정보</div>
          <div class="desc info-grid-list">
            <ul>
              <li>
                <strong class="info-title">할인사유</strong>
                <div class="info-group">등록 환입 | 엔진,변속기,ECM 교환</div>
              </li>
              <li>
                <strong class="info-title">주행거리</strong>
                <div class="info-group">500 km</div>
              </li>
              <li>
                <strong class="info-title">차량상태</strong>
                <div class="info-group">
                  <ul class="desc-list">
                    <li>본네트 교환</li>
                    <li>앞펜더 : 우 교환</li>
                    <li>실내/시트 오염</li>
                  </ul>
                </div>
              </li>
            </ul>
          </div>
        </div>
        <div class="match-box">
          <div class="title">차량 실사진</div>
          <div class="desc">
            <div v-if="viewSlider" class="slider-list">
              <v-carousel :options="options" :data="slideList" :btmarrow="true">
                <template slot-scope="props">
                  <div class="car-img">
                    <v-img :src="props.item.carImg.src" :alt="props.item.carImg.alt"></v-img>
                  </div>
                </template>
              </v-carousel>
            </div>
            <div v-else class="no-slider">
              <p>이미지 준비 중입니다</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  components: {},
  data() {
    return {
      carImg: {
        src: require('~/assets/images/temp/temp-payment-car-model.png'),
        alt: 'AX 스마트스트림 가솔린 1.1 터보 프리미엄 밀레니얼 A/T'
      },
      viewSlider: true,
      options: {
        perPage: 1,
        perMove: 1,
        arrows: false
        // fixedWidth: '90%', //너비고정시
      },
      slideList: [
        {
          carImg: {
            src: require('~/assets/images/temp/temp-payment-car-model.png'),
            alt: '베뉴 자가용 LPG 1.6<br />Modern A/T'
          }
        },
        {
          carImg: {
            src: require('~/assets/images/temp/temp-payment-car-model.png'),
            alt: '베뉴 자가용 LPG 1.6<br />Modern A/T'
          }
        },
        {
          carImg: {
            src: require('~/assets/images/temp/temp-payment-car-model.png'),
            alt: '베뉴 자가용 LPG 1.6<br />Modern A/T'
          }
        }
      ],
    }
  }
}
</script>
