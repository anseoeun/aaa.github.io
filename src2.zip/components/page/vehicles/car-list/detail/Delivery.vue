<template>
  <div class="matching-box border-line">
    <div class="box-wrap">
      <div class="box-tit main-title">배달 탁송 및 인수 절차 안내</div>
      <div class="box-desc">
        <div class="match-box">
          <div class="title">배달탁송 안내</div>
          <div class="desc">결제 안료 후 탁송 기간은 일반적으로 3~5일 (주말, 공휴일 제외) 소요되나 상황에 따라 달라질 수 있습니다. H Genuine Accessories, N Performance 파츠 추가 차량은 장착 기간으로 인해 추가 시일이 소요될 수 있습니다.</div>
        </div>
        <div class="match-box">
          <div class="title">차량 인수 안내</div>
          <div class="desc">
            <ul>
              <li>
                <strong class="t-black">- 인수 현장에서 -</strong>
                <ol class="num">
                  <li>1. 신분증을 보여주고 차량을 인수합니다.</li>
                  <li>2. 차량의 내/외관을 확인합니다.</li>
                  <li>3. 주행거리,인수날짜,지급품,연료량이 인수증에 기재된 정보와 동일한지 확인합니다.</li>
                  <li>4. 이상이 없다면 차량 인수증에 서명하고 차량을 인수합니다.</li>
                </ol>
              </li>
              <li>
                <strong class="t-black">- CASPER 사이트에서 -</strong>
                <ol class="num">
                  <li>5. 마이페이지에서 인수확정 버튼을 클릭하시면 영수증 제작증이 발급됩니다. (개인 사업자 및 법인의 경우 세금 계산서가 발급 됩니다.)</li>
                </ol>
              </li>
            </ul>
          </div>
        </div>
        <div class="match-box">
          <div class="title">유의사항</div>
          <div class="desc">
            <p class="bullet text-main">인수 확정 후에는 단순 변심에 의한 반품 요청 시 왕복 탁송료를 부과하셔야 합니다.</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  components: {},
  data() {
    return {}
  }
}
</script>
