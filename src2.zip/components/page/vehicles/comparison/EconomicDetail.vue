<template>
  <section class="info-detail border-line" :class="{ open: isOptionsShow }">
    <v-btn class="summary-info" :class="{ active: isOptionsShow }" @click="isOptionsShow = !isOptionsShow">
      <h1 class="title">경제성/환경</h1>
      <i class="icon-toggle-arr off-gray" :class="{'on':isOptionsShow}"></i>
    </v-btn>
    <div v-show="isOptionsShow" class="detail-info">
      <div class="comparison-wrap">
        <div v-for="(item, index) in dataLabel" :key="index" class="item-box">
          <template v-for="idx in 2">
            <div v-if="idx <= dataList.length" :key="idx" class="item">
              <strong class="title">{{ item }}
                <!-- 보험료 -->
                <span v-if="Object.keys(dataList[idx - 1])[index] == 'insurance'" class="icon">
                  <v-btn type="icon" icon-class="icon-info"></v-btn>
                </span>
              </strong>
              <template v-if="['combinedFuel', 'cityFuel', 'highFuel', 'fuelEconomyClass', 'selfInsuranceClass', 'carbonDioxide', 'support'].includes(Object.keys(dataList[idx - 1])[index])">
                <div class="text dot">
                  {{ dataList[idx - 1][Object.keys(dataList[idx - 1])[index]] | comma }}
                  <span class="right margin">
                    <span v-if="getNumber(dataList[0][Object.keys(dataList[idx - 1])[index]]) !== getNumber(dataList[idx - 1][Object.keys(dataList[idx - 1])[index]])">
                      <span v-if="getNumber(dataList[0][Object.keys(dataList[idx - 1])[index]]) > getNumber(dataList[idx - 1][Object.keys(dataList[idx - 1])[index]])" class="down">
                        {{ getNumber(dataList[0][Object.keys(dataList[idx - 1])[index]]) - getNumber(dataList[idx - 1][Object.keys(dataList[idx - 1])[index]]) | comma }}
                        <span v-if="Object.keys(dataList[idx - 1])[index] === 'combinedFuel'" class="unit">km/ℓ</span>
                        <span v-if="Object.keys(dataList[idx - 1])[index] === 'cityFuel'" class="unit">km/ℓ</span>
                        <span v-if="Object.keys(dataList[idx - 1])[index] === 'highFuel'" class="unit">km/ℓ</span>
                        <span v-if="Object.keys(dataList[idx - 1])[index] === 'fuelEconomyClass'" class="unit">등급</span>
                        <span v-if="Object.keys(dataList[idx - 1])[index] === 'carbonDioxide'" class="unit">g/km</span>
                        <span v-if="Object.keys(dataList[idx - 1])[index] === 'support'" class="unit">원</span>
                      </span>
                      <span v-if="getNumber(dataList[0][Object.keys(dataList[idx - 1])[index]]) < getNumber(dataList[idx - 1][Object.keys(dataList[idx - 1])[index]])" class="up">
                        {{ getNumber(dataList[idx - 1][Object.keys(dataList[idx - 1])[index]]) - getNumber(dataList[0][Object.keys(dataList[idx - 1])[index]]) | comma }}
                        <span v-if="Object.keys(dataList[idx - 1])[index] === 'combinedFuel'" class="unit">km/ℓ</span>
                        <span v-if="Object.keys(dataList[idx - 1])[index] === 'cityFuel'" class="unit">km/ℓ</span>
                        <span v-if="Object.keys(dataList[idx - 1])[index] === 'highFuel'" class="unit">km/ℓ</span>
                        <span v-if="Object.keys(dataList[idx - 1])[index] === 'fuelEconomyClass'" class="unit">등급</span>
                        <span v-if="Object.keys(dataList[idx - 1])[index] === 'carbonDioxide'" class="unit">g/km</span>
                        <span v-if="Object.keys(dataList[idx - 1])[index] === 'support'" class="unit">원</span>
                      </span>
                    </span>
                    &nbsp;
                  </span>
                </div>
              </template>
              <template v-else>
                <div class="text dot">{{ dataList[idx - 1][Object.keys(dataList[idx - 1])[index]] | comma }}</div>
              </template>
            </div>
            <div v-else :key="idx"></div>
          </template>

        </div>
      </div>
    </div>
  </section>
</template>

<script>
export default {
  components: {},
  filters:{
    comma(val){
      return String(val).replace(/\B(?=(\d{3})+(?!\d))/g, ',')
    }
  },
  data() {
    return {
      isOptionsShow: false,
      dataLabel: ['복합연비', '시내연비', '고속연비', '연비등급', '자체 보험등급', '이산화탄소 배출량', '자동차세', '보험료', '유류비', '유지 비용'],
      dataList: [
        {
          combinedFuel: '15km/ℓ',
          cityFuel: '15km/ℓ',
          highFuel: '13km/ℓ',
          fuelEconomyClass: '1등급',
          selfInsuranceClass: '15',
          carbonDioxide: '151g/km',
          tax: '87924원',
          insurance: '287924원',
          oil: '1425842원',
          support:'2669986원'
        },
        {
          combinedFuel: '12km/ℓ',
          cityFuel: '12km/ℓ',
          highFuel: '12km/ℓ',
          fuelEconomyClass: '2등급',
          selfInsuranceClass: '14',
          carbonDioxide: '151g/km',
          tax: '87924',
          insurance: '281000원',
          oil: '1425842원',
          support:'3969245원'
        }
      ]
    }
  },
  methods: {
    getNumber(value){
      return parseFloat(value.replace(/[^0-9]/g,''))
    },
  }
}
</script>
