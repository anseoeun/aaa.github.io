<template>
  <section class="info-detail border-line" :class="{ open: isOptionsShow }">
    <v-btn class="summary-info" :class="{ active: isOptionsShow }" @click="isOptionsShow = !isOptionsShow">
      <h1 class="title">기본품목 <v-btn type="icon" icon-class="icon-info" @click="popVisible = true"></v-btn></h1>
      <i class="icon-toggle-arr off-gray" :class="{'on':isOptionsShow}"></i>
    </v-btn>
    <div v-show="isOptionsShow" class="detail-info">
      <div class="comparison-wrap v-type">
          <div v-for="(item, index) in dataListLabel" :key="index" class="item-box">
             <template v-for="idx in 2">
              <div v-if="idx <= dataList.length" :key="idx" class="item">
                <strong class="title">{{ item }}</strong>
                <template v-if="typeof dataList[idx - 1][Object.keys(dataList[idx - 1])[index]] === 'string'">
                   <div class="text">{{ dataList[idx - 1][Object.keys(dataList[idx - 1])[index]] }}</div>
                </template>
                <template v-else>
                   <div class="normal-list">
                    <ul>
                      <li v-for="(list, i) in dataList[idx - 1][Object.keys(dataList[idx - 1])[index]]" :key="i" v-html="list"></li>
                    </ul>
                  </div>
                </template>
              </div>
              <div v-else :key="idx"></div>
            </template>

          </div>
      </div>
    </div>

    <!-- 팝업 : 기본품목 안내 -->
    <default-option-info :visible="popVisible" @close="popVisible = false"></default-option-info>
  </section>
</template>

<script>
import DefaultOptionInfo from '~/components/page/vehicles/comparison/popup/DefaultOptionInfo'
export default {
  components: {
    DefaultOptionInfo
  },
  data() {
    return {
      isOptionsShow: false,
      popVisible: false,
      dataListLabel: ['파워트레인', '지능형 안전기술', '외관', '내장', '안전', '편의', '멀티미디어' ],
      dataList: [
        {
          powerTrain: [
            '카파개선 1.0 엔진',
            '4단 자동변속기',
            '풋파킹 브레이크',
          ],
          intelligentSkill: [
           '6 에어백<br />(운전석, 동승석, 사이드, 커튼)',
           'VSM+(차세대 ESC 외 안전제어 기능 TVBB/SLS/FBC추가)',
           '경사로 밀림 방지장치(HAC)',
          ],
          exterior: [
            '16인치 알로이 휠 & 타이어',
            '아웃사이드 미러(열선, 전동 조절, LED 방향지시등)'
          ],
          inside: '4.2인치 컬러 LCD 클러스터',
          safety: '전방 차량 출발 알림',
          convenience: '폴딩타입 도어 리모컨키',
          multimedia: '일반 오디오 시스템',
        },
        {
          powerTrain: [
            '스마트 스트림 가솔린 1.6 엔진',
            '디스크 브레이크',
          ],
          intelligentSkill: [
           '6 에어백<br />(운전석, 동승석, 사이드, 커튼)',
           '앞좌석 사이드',
          ],
          exterior: [
            '16인치 알로이 휠 & 타이어',
            '아웃사이드 미러(열선, 전동 조절, LED 방향지시등)'
          ],
          inside: '4.2인치 컬러 LCD 클러스터',
          safety: '전방 차량 출발 알림',
          convenience: '폴딩타입 도어 리모컨키',
          multimedia: '일반 오디오 시스템',
        },
        {
          powerTrain: [
            '전/후륜 디스크 브레이크(전륜 벤틸레이티드)',
            'Ce 260(터보 직분사 가솔린)엔진',
            '랙 구동형 전자식 파워스티어링(R-EPS)',
          ],
          exterior: [
            '16인치 알로이 휠 & 타이어',
            '아웃사이드 미러(열선, 전동 조절, LED 방향지시등)'
          ],
          inside: '4.2인치 컬러 LCD 클러스터',
          safety: '전방 차량 출발 알림',
          convenience: '폴딩타입 도어 리모컨키',
          multimedia: '일반 오디오 시스템',
        }
      ]
    }
  },
  methods: {}
}
</script>
