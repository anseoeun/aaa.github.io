<template>
  <v-popup
    :visible="visible"
    :footer="['close']"
    @close="
      $emit('close')
      popVisible = false
    "
    @confirm="
      $emit('close')
      popVisible = false
    "
  >
    <template slot="header">
      <div class="title">신차안전도 평가 안내</div>
    </template>
    <template slot="body">
      <ul class="body-contents">
        <li class="bullet">
          본 신차안전도 평가결과는 국토해양부 주관 안전도 평가 후 발표된 자료입니다.(교통안전공단 자세한 내용 www.kncap.org 참조)
        </li>
        <li class="bullet">
          안전도 종합등급 안전평가에서 실시하고 있는 정면충돌, 측면충돌, 보행자 등 22개 항목의 평가 결과를 종합하여 평가
          대상 차량의 안전도를 등급(1~5등급)과 점수(100점 만점)로 소비자들에게 제공합니다.
        </li>
        <li class="bullet">1등급일수록 가장 안전한 차량입니다.</li>
        <li class="bullet">
          매년 자동차 판매수가 많거나 판매가 급증 추세인 차 그리고 과거 평가를 하지 않은 모델 중에서 평가를 실시하며,
          평가에 사용된 차량의 에어백 등의 안전장비는 실제 구입하시는 차량과 다를 수 있으므로 확인 하시 길 바랍니다.
        </li>
      </ul>
    </template>
  </v-popup>
</template>

<script>
import { VPopup } from '~/components/element'
export default {
  components: {
    VPopup
  },
  props: {
    visible: {
      type: Boolean,
      default: false
    }
  }
}
</script>