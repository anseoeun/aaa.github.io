<template>
  <section class="info-detail border-line" :class="{ open: isOptionsShow }">
    <v-btn class="summary-info" :class="{ active: isOptionsShow }" @click="isOptionsShow = !isOptionsShow">
      <h1 class="title">충돌/안전</h1>
      <i class="icon-toggle-arr off-gray" :class="{'on':isOptionsShow}"></i>
    </v-btn>
    <div v-show="isOptionsShow" class="detail-info">
      <div class="comparison-wrap">
          <div v-for="(item, index) in dataListLabel" :key="index" class="item-box">
             <template v-for="idx in 2">
              <div v-if="idx <= dataList.length" :key="idx" class="item">
                <strong class="title">{{ item }}
                  <!-- 종합등급(충돌안전) -->
                  <span v-if="Object.keys(dataList[idx - 1])[index] == 'overallGrade'" class="icon">
                    <v-btn type="icon" icon-class="icon-info"></v-btn>
                  </span>
                </strong>
                  <div class="text dot">
                    {{ dataList[idx - 1][Object.keys(dataList[idx - 1])[index]] }}
                    <div v-if="Object.keys(dataList[idx - 1])[index] === 'displacement' && parseInt(dataList[0].displacement) !== parseInt(dataList[idx - 1].displacement)" class="right margin">
                      <span v-if="parseInt(dataList[0].displacement) > parseInt(dataList[idx - 1].displacement)" class="down">
                        {{ dataList[0].displacement - dataList[idx - 1].displacement }} cc
                      </span>
                      <span v-if="parseInt(dataList[0].displacement) < parseInt(dataList[idx - 1].displacement)" class="up">
                        {{ dataList[idx - 1].displacement - dataList[0].displacement }} cc
                      </span>
                    </div>
                  </div>
              </div>
              <div v-else :key="idx"></div>
            </template>
          </div>
      </div>
      <div class="newcar-safety-evaluation border-line">
        <div class="img"><v-img :src="require('~/assets/images/mycar/img-kncap.png')"></v-img></div>
        <div class="desc">
          <p class="title">신차 안전도 평가</p>
          <p class="text">
            국토 교통부는 매년 국내에 많이 판매되는 국산차 및 외산차 10개 차종을 대상으로 안전도 평가를 실시 합니다. 자동차 충돌시험 등을 통해 차의 안전성을 평가하여, 소비자에게 결과를 제공하고 제작사로 하여금 보다 안전한 자동차를 제작하도록 유도하기 위해 1999년 부터 시행해 왔습니다. 최근의 자동차 안전도 평가는 충돌 안전, 보행자 안전, 사고예방 안전등 3개 분야로 나누어 각 차종의 안전도를 평가합니다.
          </p>
          <div class="link"><v-btn type="link" href="http://www.kncap.org/" target="_blank">www.kncap.org</v-btn></div>
        </div>
      </div>
    </div>
  </section>
</template>

<script>
export default {
  components: {},
  data() {
    return {
      isOptionsShow: false,
      dataListLabel: ['종합등급(충돌안전)', '평가연도', '점수', '출동안전', '보행자 안전', '사고예방 안전', '가산점' ],
      dataList: [
        {
          overallGrade: '1등급',
          evaluationYear: '2015년',
          grade: '91.9점',
          exhibition: '91.9점',
          pedestrianSafety: '91.9점',
          accidentPreventionSafety: '91.9점',
          additionalPoints: '91.9점',
        },
        {
          overallGrade: '1등급',
          evaluationYear: '2015년',
          grade: '91.9점',
          exhibition: '91.9점',
          pedestrianSafety: '91.9점',
          accidentPreventionSafety: '91.9점',
          additionalPoints: '91.9점',
        },
        {
          overallGrade: '1등급',
          evaluationYear: '2015년',
          grade: '91.9점',
          exhibition: '91.9점',
          pedestrianSafety: '91.9점',
          accidentPreventionSafety: '91.9점',
          additionalPoints: '91.9점',
        },
      ]
    }
  },
  methods: {}
}
</script>
