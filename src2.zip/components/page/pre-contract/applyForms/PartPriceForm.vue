<template>
  <div class="partprice-form-wrap">
     <div class="apply-box border-line">
      <div class="con-box">
        <div class="agreement">
          <v-checkbox :one-check="true" :checked.sync="oneChecked">
            온라인계약 확인 동의(필수)
          </v-checkbox>
          <div class="agreement-info" :class="{'t-black': oneChecked}">
              공동인증서 소지자 또는 본인 명의의 카카오톡 계정이 있는 스마트폰 소비자에 한해 온라인 계약이 가능합니다.
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
   data() {
    return {
      oneChecked: false
    }
  }
}
</script>
