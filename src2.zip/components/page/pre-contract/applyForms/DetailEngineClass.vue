<template>
  <div class="detail-form">
    <div v-if="showDetail == ''" class="not-selected">
      <h5>모델 상세 선택</h5>
      <p>엔진을 선택해주세요.</p>
    </div>
    <div v-else class="checkbox-group">
      <div v-for="(boxs, index) in boxList" :key="index" class="box">
        <label aria-checked="true" roll="checkbox">
          <input type="checkbox" name="detail-group" class="hidden-checkbox" aria-checked="true" />
          <span>
            디젤 2.2<br />
            {{ boxs.name }}
          </span>
        </label>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    showDetail: {
      type: String,
      default: ''
    }
  },
  data() {
    return {
      boxList: [
        {
          name: '4WD 7인승 오토',
          value: '00'
        },
        {
          name: '4WD 8인승 오토',
          value: '01'
        },
        {
          name: '2WD 7인승 오토',
          value: '02'
        },
        {
          name: '2WD 8인승 오토',
          value: '03'
        }
      ]
    }
  }
}
</script>
