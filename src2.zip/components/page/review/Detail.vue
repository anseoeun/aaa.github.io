<template>
  <v-popup
    :visible="visible"
    @close="
      $emit('close')
    "
  >
    <template slot="header">
      <div class="title">상세보기</div>
    </template>
    <template slot="body">
      <div class="pop-review-detail">
        <div class="detail-img">
          <v-img :src="reviewPhoto.src" :alt="reviewPhoto.alt"></v-img>
        </div>
        <!-- 사진 -->
        <div class="upload-view-list-wrap">
          <v-carousel
            :options="photoOptions"
            :data="fileList"
            class="upload-view-list sm-size"
          >
            <!-- :btmarrow="true" -->
            <template slot-scope="props">
              <div class="item">
                <v-btn class="img" @click="changePhoto(props.item.src)">
                  <v-img :src="props.item.src" :alt="props.item.alt"></v-img>
                </v-btn>
              </div>
            </template>
          </v-carousel>
        </div>
      </div>
    </template>
  </v-popup>
</template>

<script>
import { VImg, VCarousel} from '~/components/element'
export default {
  components: {
    VImg,
    // VRate,
    VCarousel
  },
  props: {
    visible: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      photoOptions: {
        perPage: 3,
        perMove: 2,
        autoWidth: true,
        autoplay: true,
        type: 'loop',
      },
      reviewPhoto: {
        src: require('~/assets/images/temp/temp-car-option2.png'),
        alt: '구매후기사진'
      },
      detailinfo: {
        title: '캐스퍼 센슈어스 (가솔린1.6T) Primium ( 자가용 스마트 스트림 가솔린 1.6 터보)',
        contractDate: '2021.10.20',
        user: '(30, 남성)'
      },
      grade: 3,
      satisfaction: [
        {
          cate: '구매과정',
          text: '생각보다 쉬워요.'
        },
        {
          cate: '가성비',
          text: '가격대비 최고예요.'
        },
        {
          cate: '디자인',
          text: '화면처럼 맘에들어요.'
        },
        {
          cate: '승차감',
          text: '무척 좋아요.'
        }
      ],
      fileList: [
        {
          src: require('~/assets/images/temp/temp-car-option2.png'),
          alt: '구매후기사진'
        },
        {
          src: require('~/assets/images/temp/temp-car-option.png'),
          alt: '구매후기사진'
        },
        {
          src: require('~/assets/images/temp/temp-car-option2.png'),
          alt: '구매후기사진'
        },
        {
          src: require('~/assets/images/temp/temp-car-option.png'),
          alt: '구매후기사진'
        },
        {
          src: require('~/assets/images/temp/temp-car-option2.png'),
          alt: '구매후기사진'
        },
        {
          src: require('~/assets/images/temp/temp-car-option.png'),
          alt: '구매후기사진'
        }
      ],
    }
  },
  methods: {
    changePhoto(src) {
      this.reviewPhoto.src = src
    }
  }
}
</script>
