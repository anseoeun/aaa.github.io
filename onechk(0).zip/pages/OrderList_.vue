<template>
    <div>
        <div class="order-board">
            <div class="order-list">
                <!-- <VueSlickCarousel  ref="slick" :arrows="true" :dots="false" :vertical="true" :slidesToShow="slidesToShow"  :infinite="false" @reInit="reInit">
                    <button v-for="num in orderPage" :key="num">{{ num }}</button>
                </VueSlickCarousel> -->
                <div class="slider">
                    <button v-for="num in orderPage" :key="num">{{ num }}</button>
                </div>
                <button class="add" @click="addPage">add</button>
    {{ orderPage }}
                <div class="order-layer">
                    주문내역
                </div>
            </div>
            <div class="store-status">

            </div>
        </div>

        <v-popup
            :is-open="popVisible"
            @close="popVisible = false">
            <template slot="header">
            <p class="pop-tit">상품 옵션 선택</p>
            </template>
            <template slot="body">
                {{ inpNum }}
                <VInpNum v-model="inpNum" :max="12" />
            </template>
        </v-popup>
    </div>
</template>

<script>
import VueSlickCarousel from 'vue-slick-carousel'
import $ from 'jquery'
import 'vue-slick-carousel/dist/vue-slick-carousel.css'

import '~/assets/style/slick.css'
export default {
  components: { VueSlickCarousel },
    data() {
        return {
            popVisible : false,
            inpNum: 1,
            orderPage:3,
            slidesToShow : 1
        }
    },
    mounted(){
        // setTimeout(()=>{
        //     this.popVisible = true
        // },100)
        // this.slidesToShow = this.orderPage <= 5 ? this.orderPage : 5
        const _this = this
        import('~/assets/js/slick.js').then(m => {
            $('.slider').slick({
                slidesToShow: 1,
                slidesToScroll: 1,
                vertical:true,
            });
            $('.add').click(function(){
                console.log(_this.orderPage)
                _this.orderPage += 1;
                // $('.slider').slick('destroy')
                $('.slider').slick('slickAdd','<div><div><button style="width: 100%; display: inline-block;">' + 4 + '</button></div></div>');
            });
        });
//    this.$nextTick(function() {

//  });
    },
    methods:{
        addPage(){
            // this.orderPage += 1;
            // $('.slider').slick('unslick')
            //  this.$refs.slick.ne/zxt();
            //  this.$refs.slick.reInit();
            // this.$refs.slick.reSlick();
            // this.slidesToShow =  this.orderPage <= 10 ? this.orderPage : 10
        },
        reInit() {
            // Helpful if you have to deal with v-for to update dynamic lists
            this.$nextTick(() => {
                // this.$refs.slick.reSlick();
            });
        },
         next() {
            this.$refs.slick.next();
        },

        prev() {
            this.$refs.slick.prev();
        },
        handleAfterChange(event, slick, currentSlide) {
            console.log('handleAfterChange', event, slick, currentSlide);
        },
    }
}
</script>
