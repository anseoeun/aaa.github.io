<template>
    <div>
        <div class="cont-box">
            <h2 class="title-type1">상품</h2>
            <div class="data-top line">
                <h3 class="title-type2">내 상품</h3>
                <div class="btns">
                    <VBtn class="btn-type2 st4">옵션 관리</VBtn>
                    <VBtn class="btn-type2 st3">통계</VBtn>
                </div>
            </div>
            <div class="title-type3-wrap">
                <h3 class="title-type3">상품 등록</h3>
            </div>
            
            <!-- table -->
            <div class="data-type2">
            <table>
                <colgroup>
                    <col style='width:230px' />
                    <col style='width:auto' />
                </colgroup>
                <tbody>
                    <tr>
                        <th>상품 이름</th>
                        <td>
                            <VInput type="text" placeholder="상품 이름을 입력하세요." style="width:578px" />
                        </td>
                    </tr>
                    <tr>
                        <th>상품 사진</th>
                        <td>
                            <VUpload v-model="imgSrc" />
                        </td>
                    </tr>
                    <tr>
                        <th>상품 가격</th>
                        <td>
                            <VInput type="text" style="width:112px;" /> 원
                        </td>
                    </tr>
                    <tr>
                        <th>상품 수량</th>
                        <td>
                            <VInput type="text" style="width:112px;" /> 개
                        </td>
                    </tr>
                    <tr>
                        <th>상품 설명</th>
                        <td>
                            <div class="textarea">
                                <VInput v-model="explanation" type="textarea" style="width:100%;height:170px" maxlength="500" placeholder="상품설명을 입력하세요"></VInput>
                                <span class="byte">{{ explanation.length }} / 500</span>
                            </div>
                        </td>
                    </tr>
                </tbody>
            </table>
            </div>
            <!-- //table -->
            <div class="btn-box align-r">
                <VBtn type="nlink" class="btn-type2 st5">뒤로가기</VBtn>
                <VBtn class="btn-type2 st6">취소</VBtn>
                <VBtn type="submit" class="btn-type2 st1">등록</VBtn>
            </div>
        </div>

        <v-popup
            :is-open="popVisible"
            @close="popVisible = false">
            <template slot="header">
            <p class="pop-tit noline">옵션선택</p>	
            </template>
            <template slot="body">
				<div class="apply-box"><button class="btn-type4 st7"><i class="ico i-chk-circle"></i>적용</button></div>
                <div class="option-box">
                    <ul>
                        <li>
                            <label class="inp-chk type2">
                                <input type="checkbox" checked="">
                                <span class="ic"></span>
                                <span class="t">온도</span>
                            </label>
                            <ul>
                                <li>ICED (기본)</li>
                                <li>HOT</li>
                            </ul>
                        </li>
                        <li>
                            <label class="inp-chk">
                                <input type="checkbox" checked="">
                                <span class="ic"></span>
                                <span class="t">온도</span>
                            </label>
                            <ul>
                                <li>ICED (기본)</li>
                                <li>HOT</li>
                            </ul>
                        </li>
                    </ul>
                </div>
            </template>
        </v-popup>
    </div>
</template>

<script>
export default {
    data() {
    return {
        fileVal: '',
        imgSrc: '',
        explanation:'',
        popVisible:false,
    }
    },
    mounted(){
        this.$nextTick(function() {
            setTimeout(()=>{
                this.popVisible=true
            },100)
        });
    },

}
</script>
