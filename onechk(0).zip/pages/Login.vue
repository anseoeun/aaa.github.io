<template>
  <!-- login-box -->
  <div class="login-box">
      <h2><img src="~assets/images/logo-login.png" alt=""></h2>
      <ul>
          <li>
              <VInput type="text" v-model="id" />
          </li>
          <li><VInput type="password" v-model="password" /></li>
      </ul>
      <div class="id-save">
          <VCheckbox v-model="save">아이디 저장</VCheckbox>
      </div>
      <div class="login-btn">
          <VBtn class="btn-type1 st1 full">로그인</VBtn>
      </div>
      <div class="login-menu">
          <VBtn type="nlink" to="/">아이디 찾기</VBtn>
          <VBtn type="nlink" to="/">비밀번호 찾기</VBtn>
          <div class="right">
              <VBtn type="nlink" to="/" class="btn-type2 st2">회원가입</VBtn>
          </div>
      </div>
  </div>
  <!-- // login-box -->
</template>
<script>
export default {
  data() {
    return {
        id:'',
        password:'',
        save:false
    }
  }
}
</script>
