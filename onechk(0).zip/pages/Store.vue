<template>
    <div class="cont-box">
        <h2 class="title-type1">가게</h2>
        <div class="data-top">
            <h3 class="title-type2">내 가게</h3>
            <div class="btns">
                <VBtn class="btn-type2 st4">옵션 관리</VBtn>
                <VBtn class="btn-type2 st3">통계</VBtn>
            </div>
        </div>
        <!-- table -->
        <div class="data-type2">
            <table>
                <colgroup>
                    <col style='width:230px' />
                    <col style='width:auto' />
                </colgroup>
                <tbody>
                        <tr>
                            <th>가게 명</th>
                            <td>
                                <VInput v-if="modifyMode" type="text" style="width:578px" :value="store" />
                                <template v-else>{{ store }}</template>
                            </td>
                        </tr>
                        <tr>
                            <th>식별코드</th>
                            <td>
                                <VInput v-if="modifyMode" type="text" style="width:578px" :value="code" />
                                <template v-else>{{ code }}</template>
                            </td>
                        </tr>
                        <tr>
                            <th>전화번호</th>
                            <td>
                                <VInput v-if="modifyMode" type="text" style="width:578px" :value="tel" />
                                <template v-else>{{ tel }}</template>
                            </td>
                        </tr>
                        <tr>
                            <th>업종</th>
                            <td>
                                <div v-if="modifyMode" class="inp-search">
                                    <VInput type="text" style="width:578px" :value="sectors" placeholder="업종을 검색하세요." />
                                    <VBtn class="btn-search"><i class="ico i-search"></i></VBtn>
                                </div>
                                <template v-else>{{ sectors }}</template>
                            </td>
                        </tr>
                        <tr>
                            <th>아이콘</th>
                            <td>
                                <template v-if="modifyMode" >
                                    <VUpload v-model="imgSrc" />
                                </template>
                                <template v-else>
                                    <img :src="imgSrc" alt="">
                                </template>
                            </td>
                        </tr>
                        <tr>
                            <th>주소</th>
                            <td>
                                <template v-if="modifyMode">
                                    <div class="inp-addr">
                                        <div class="row">
                                            <VInput type="text" :value="address[0]" />
                                            <VBtn class="btn-type6 st6">주소찾기</VBtn>
                                        </div>
                                        <div class="row">
                                            <VInput type="text" :value="address[1]" />
                                        </div>
                                    </div>
                                </template>
                                <template v-else>{{ address[0] }} {{ address[1] }}</template>
                            </td>
                        </tr>
                        <tr>
                            <th>세부위치</th>
                            <td>
                                <div class="detail-map">
                                    <img src="~/assets/images/temp/temp_map.jpg" alt="">
                                    <template v-if="modifyMode"><p class="txt">가게의 정확한 출입구 위치를 마커를 옮겨서 설정해주세요</p></template>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <th>건물 설명</th>
                            <td>
                                <div v-if="modifyMode" class="textarea">
                                    <VInput v-model="explanation" type="textarea" style="width:100%;height:170px" maxlength="500" placeholder="상품 설명을 입력하세요."></VInput>
                                    <span class="byte">{{ explanation.length }} / 500</span>
                                </div>
                                <div v-else class="textarea">{{ explanation }} </div>
                            </td>
                        </tr>
                        <tr>
                            <th>가게 실내도 (선택)</th>
                            <td>
                                <VBtn class="btn-type2 st1" style="width:145px">실내도 관리</VBtn>
                            </td>
                        </tr>
                        <tr>
                            <th>사업자등록증</th>
                            <td>
                                <template v-if="modifyMode">
                                    <VBtn class="btn-type2 st1" style="width:145px">변경</VBtn>
                                    &nbsp;&nbsp;
                                </template>
                                 마지막 업로드 일자: {{ uploadeDate }}
                            </td>
                        </tr>
                </tbody>
            </table>
            </div>
            <!-- //table -->
            <div class="btn-box align-r">
                <VBtn type="nlink" to="/" class="btn-type2 st5">뒤로가기</VBtn>
                <VBtn v-if="!modifyMode" class="btn-type2 st6" @click="modifyMode = true">정보편집</VBtn>
                <VBtn v-else class="btn-type2 st6" @click="modifyMode = false">수정완료</VBtn>
            </div>
    </div>
</template>
<script>
export default {
  data() {
    return {
        modifyMode:false,
        store:'교촌치킨 금정점',
        code:'123456789',
        tel:'031-123-4567',
        sectors:'',
        imgSrc:require('~/assets/images/temp/temp_logo.png'),
        address:[
            '서울시 송파구 올림픽로 300', '102호'
        ],
        explanation:'다른 치킨 브랜드와 달리 간장치킨이 간판 메뉴이자, \n이 브랜드를 전국적으로 성공시킨 효자 메뉴다. \n 1978년 창업한 대구통닭이 간장치킨의 원조이고, 거기서 \n일하던 직원이 나와 차린 것이 교촌치킨이라는 설이 지역\n에서는 많이 알려져 있다. 양념치킨이 주로 아이들에게 \n인기가 있는 반면 간장치킨은 연령에 상관없이 성인들에게도 인기가 있다. ',
        uploadeDate:' 2021-04-06',
    }
  },
  mounted(){

  },
  methods:{
        changeFile(e, type) {
        const file = this.$refs.imgFile
        const list = this.imgList
        // const overNum = 7
        const overSize = 10000
        const overTxt = '용량초과 이미지가 있습니다. 파일당 10MB미만의 jpg, gif, png파일만 첨부하실 수 있습니다.'
        let files = e.target.files || e.dataTransfer.files
        if (files.length === 0) return
        this.fileVal = files[0].name
        this.addPhotoFile(file, (src, size) => {
            if (parseInt(this.formatSizeUnits(size)) > overSize) {
                alert(overTxt)
            } else {
                this.imgSrc = src
            }
        })
        },
        fileDelete(index, type) {
            this.imgSrc = ''
        },
        fileOpen(type) {
            this.$refs.imgFile.click()
        },
        addPhotoFile(obj, callback) {
            let src, size
            if (obj.files && obj.files[0]) {
                let reader = new FileReader()
                reader.readAsDataURL(obj.files[0])
                reader.onload = function (e) {
                size = obj.files[0].size
                src = e.target.result
                callback && callback(src, size)
                }
            }
        },
        formatSizeUnits(bytes) {
            if (bytes >= 1000000000) {
                bytes = (bytes / 1000000000).toFixed(2) + ' GB'
            } else if (bytes >= 1000000) {
                bytes = (bytes / 1000000).toFixed(2) + ' MB'
            } else if (bytes >= 1000) {
                bytes = (bytes / 1000).toFixed(2) + ' KB'
            } else if (bytes > 1) {
                bytes = bytes + ' bytes'
            } else if (bytes == 1) {
                bytes = bytes + ' byte'
            } else {
                bytes = '0 byte'
            }
            return bytes
        },
    }
}
</script>
