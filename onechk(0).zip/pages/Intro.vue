<template>
<div class="visual-main-intro">
    <div class="text">
        <span class="label-txt">원체크 사장님 광장</span>
        <p class="tit">
            <b>서비스 홍보</b>하는 <b>컨텐츠</b> <br>
            들어가는 부분
        </p>
        <p class="txt">원체크 사장님 광장, 해당 부분은 임시 문구 입니다. </p>
    </div>
</div>
</template>
<script>

export default {
  data() {
    return {

    }
  },
  mounted(){
      
      
  },
  methods:{

  }
}
</script>
