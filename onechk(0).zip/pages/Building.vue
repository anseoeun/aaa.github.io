<template>
    <div class="cont-box">
        <h2 class="title-type1">건물</h2>
        <div class="data-top">
            <h3 class="title-type2">내 건물</h3>
            <div class="btns">
                <VBtn class="btn-type2 st4">옵션 관리</VBtn>
                <VBtn class="btn-type2 st3">통계</VBtn>
            </div>
        </div>
        <!-- table -->
        <div class="data-type2">
            <table>
                <colgroup>
                    <col style='width:230px' />
                    <col style='width:auto' />
                </colgroup>
                <tbody>
                        <tr>
                            <th>건물명</th>
                            <td>
                                <VInput v-if="modifyMode" type="text" style="width:578px" :value="building" />
                                <template v-else>{{ building }}</template>
                            </td>
                        </tr>
                        <tr>
                            <th>건물 사진</th>
                            <td>    
                                <template v-if="modifyMode" >
                                    <VUpload v-model="imgSrc" />
                                </template>
                                <template v-else>
                                    <img :src="imgSrc" alt="">
                                </template>
                            </td>
                        </tr>
                        <tr>
                            <th>건물 주소</th>
                            <td>
                                <div v-if="modifyMode" class="inp-addr">
                                    <VInput type="text" :value="address" />
                                    <VBtn class="btn-type6 st6">주소찾기</VBtn>
                                </div>
                                <template v-else>{{ address }}</template>
                            </td>
                        </tr>
                        <tr>
                            <th>건물 설명</th>
                            <td>
                                <div v-if="modifyMode" class="textarea">
                                    <VInput v-model="explanation" type="textarea" style="width:100%;height:170px" maxlength="500" placeholder="상품 설명을 입력하세요."></VInput>
                                    <span class="byte">{{ explanation.length }} / 500</span>
                                </div>
                                <div v-else class="textarea">{{ explanation }} </div>
                            </td>
                        </tr>
                        <tr>
                            <th>건물 실내도 (선택)</th>
                            <td>
                                <VBtn class="btn-type2 st1" style="width:145px">실내도 관리</VBtn>
                            </td>
                        </tr>
                </tbody>
            </table>
            </div>
            <!-- //table -->
            <div class="btn-box align-r">
                <!-- <VBtn type="nlink" to="/" class="btn-type2 st5">뒤로가기</VBtn> -->
                <VBtn v-if="!modifyMode" class="btn-type2 st6" @click="modifyMode = true">정보편집</VBtn>
                <VBtn v-else class="btn-type2 st6" @click="modifyMode = false">수정완료</VBtn>
            </div>
    </div>
</template>
<script>
export default {
  data() {
    return {
        modifyMode:false,
        imgSrc:require('~/assets/images/temp/temp_photo.jpg'),
        building:'롯데 월드 타워',
        address:'서울시 송파구 올림픽로 300',
        explanation:'롯데월드타워(영어: Lotte World Tower[1][2][3])는 대한민국 \n서울특별시 송파구 신천동 롯데월드몰 단지 내에 위치한 \n마천루이다.[4][5][6] 지상 123층, 높이 555m의 마천루로 \n2010년에 착공을 시작하여 2015년 12월 22일 123층까지 \n상량 완료했으며, 2016년 3월경 첨탑공사가 완료됨으로써',
    }
  },
}
</script>
