<template>
    <div>
        <div class="order-board">
            <div class="order-list">
                <div class="order-numbering">
                    <VBtn class="prev" @click="pagePrev">이전</VBtn>
                    <VBtn class="add" @click="addPage">add</VBtn>
                    <div class="paging">
                        <div class="scroll" :style="`top:${pageScrollTop}px`">
                            <VBtn v-for="num in orderPage" :key="num">{{ num }}</VBtn>
                        </div>
                    </div>
                    <VBtn class="next" @click="pageNext">다음</VBtn>
                </div>

                <div class="order-layer">
                    주문내역
                </div>
                <div class="new-table">

                </div>
            </div>
            <div class="store-status">
                <div class="table-status">
                    <div class="status-manu">
                        <VBtn>편집</VBtn>
                        <div class="status-txt">2020-04-09(금) 11:58:53</div>
                        <div class="btn-layer">
                            <VBtn>이동/합석</VBtn>
                            <ul>
                                <li><VBtn>테이블 이동</VBtn></li>
                                <li><VBtn>테이블 합석</VBtn></li>
                            </ul>
                        </div>
                    </div>
                    <div class="table-view">
                        <template v-for="table in tableList">
                            <div class="box" :id="table.id" :style="`top:${table.top}px;left:${table.left}px`" @dragStart="dragStart" @drag="drag"></div>
                        </template>
                    </div>
                </div>
            </div>
        </div>

        <v-popup
            :is-open="popVisible"
            @close="popVisible = false">
            <template slot="header">
            <p class="pop-tit">상품 옵션 선택</p>
            </template>
            <template slot="body">
                {{ inpNum }}
                <VInpNum v-model="inpNum" :max="12" />
            </template>
        </v-popup>
    </div>
</template>

<script>
import VueSlickCarousel from 'vue-slick-carousel'
import $ from 'jquery'
import 'vue-slick-carousel/dist/vue-slick-carousel.css'
import '~/assets/style/slick.css'
export default {
  components: { VueSlickCarousel },
  filters:{
    comma(val){
      return String(val).replace(/\B(?=(\d{3})+(?!\d))/g, ',')
    }
  },
    data() {
        return {
            popVisible : false,
            inpNum: 1,
            orderPage:3,
            pageScrollTop : 0,
            pageH:39,
            tableList:[
                {id:'TABLE01', menu:'아메1, 딸기2, 카페라떼1', price:'15500', top:0, left:0, right:145, bottom:124},
                {id:'TABLE02', menu:'', price:'', top:150, left:0, right:145, bottom:274},
                {id:'TABLE03', menu:'', price:'', top:300, left:0, right:145, bottom:424},
                {id:'TABLE04', menu:'아메1, 딸기2, 카페라떼1', price:'15500', top:450, left:0, right:145, bottom:574},
                {id:'TABLE05', menu:'', price:'', top:600, left:0, right:145, bottom:724},
                {id:'TABLE06', menu:'', price:'', top:0, left:150, right:295, bottom:124},
                {id:'TABLE07', menu:'아메1, 딸기2, 카페라떼1', price:'15500', top:0, left:300, right:445, bottom:124},
                {id:'TABLE08', menu:'', price:'', top:0, left:450, right:595, bottom:124},
                // {id:'TABLE09', menu:'아메1, 딸기2, 카페라떼1', price:'15500'},
                // {id:'TABLE010', menu:'아메1, 딸기2, 카페라떼1', price:'15500'},
                // {id:'TABLE011', menu:'', price:''},
                // {id:'TABLE012', menu:'아메1, 딸기2, 카페라떼1', price:'15500'},
                // {id:'TABLE013', menu:'', price:''},
                // {id:'TABLE014', menu:'', price:''},
            ]
        }
    },
    mounted(){
        // import('~/assets/js/jquery-ui.js').then(m => {
        //     let _this = this;
        //     $( ".table-view .box" ).draggable({
        //         containment: "parent",
        //         // revert: true,
        //         // cancel: ".no-draggable",
        //         drag: function( event, ui ) {
        //             _this.tableList.forEach((value) => {
        //                 let topleft = ui.position.top > value.top &&  ui.position.top < value.bottom && ui.position.left > value.left && ui.position.left < value.right
        //                 let topright = ui.position.top > value.top &&  ui.position.top < value.bottom && ui.position.left + 145 < value.right && ui.position.left + 145 > value.left
        //                 let btmleft = ui.position.bottom < value.bottom &&  ui.position.bottom > value.top && ui.position.left > value.left && ui.position.left < value.right
        //                 let btmright = ui.position.bottom < value.bottom &&  ui.position.bottom > value.top && ui.position.left + 145 < value.right && ui.position.left + 145 > value.left
        //                 let poscheck =[topleft, topright, btmleft, btmright]
        //                 // console.log(topleft,topright,btmleft, btmright)
        //                 console.log(ui.position.top, value.top)
        //                 console.log(ui.position.top, value.bottom)
        //                 console.log(ui.position.left, value.left)
        //                 console.log(ui.position.left, value.right)
        //                 if(topleft){
        //                     console.log('message')
        //                 }
        //             })
        //         }
        //     });
        //     $( ".table-view .box.no-draggable" ).draggable({
        //         // containment: "parent",
        //         revert: true,
        //         // cancel: ".no-draggable",
        //         // drop: function( event, ui ) {
        //         //     console.log(ui)
        //         // }
        //     });
        //     $( ".table-view .box").droppable({
        //         accept: ".table-view .box",
        //         classes: {
        //             "ui-droppable-active": "ui-state-active",
        //             "ui-droppable-hover": "ui-state-hover"
        //         },
        //         drop: function( event, ui ) {
        //             console.log(ui.draggable)
        //         }
        //     });
        // });

    },
    methods:{
        addPage(){
            this.orderPage += 1;
        },
        pagePrev() {
            if(this.orderPage > 6 && this.pageScrollTop < 0) this.pageScrollTop += 50
        },
        pageNext() {
            console.log((this.orderPage-6) * this.pageH)
            if(this.orderPage > 6 && this.pageScrollTop > -((this.orderPage-6) * this.pageH)) this.pageScrollTop -= this.pageH
        },
        dragStart(e){
            console.log(e)
        },
        drag(e){
            console.log(e.offsetY, e.target.offsetTop)
            e.target.style.top = e.clientY - e.offsetY -124 + 'px'
            e.target.style.left = e.clientX - e.offsetX - 145 + 'px'
            // console.log('message')
            console.log(e.target);
        }
    }
}
</script>
