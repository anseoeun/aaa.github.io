<template>
<div class="cont-box">
    <h2 class="title-type1">회원가입</h2>
    <!-- table -->
    <div class="data-type2">
        <table>
            <colgroup>
                <col style='width:230px' />
                <col style='width:auto' />
            </colgroup>
            <tbody>
                <tr>
                    <th>아이디</th>
                    <td><VInput v-model="id" type="text" style="width:578px" /></td>
                </tr>
                <tr>
                    <th>비밀번호 </th>
                    <td><VInput v-model="password" type="password" style="width:578px" /></td>
                </tr>
                <tr>
                    <th>성/이름 </th>
                    <td>
                        <VInput v-model="firstName" type="text" style="width:240px" />
                        &nbsp;
                        <VInput v-model="lastName" type="text" style="width:330px" />
                    </td>
                </tr>
                <tr>
                    <th>이메일</th>
                    <td>
                        <VInput v-model="emailAddr" type="text" style="width:255px;" />
                        <span class="at">@</span>
                        <VInput v-model="emailProvider" type="text" style="width:295px" />
                    </td>
                </tr>
                <tr>
                    <th>전화번호</th>
                    <td>
                        <VSelect v-model="tel1" :data="telList" style="width:95px" />
                        <span class="dash">-</span>
                        <VInput v-model="tel2" type="text" style="width:95px" />
                        <span class="dash">-</span>
                        <VInput v-model="tel3" type="text" style="width:95px" />
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
    <!-- //table -->
    <div class="btn-box">
        <VBtn class="btn-type1 st3">취소</VBtn>
        <VBtn class="btn-type1 st1">가입완료</VBtn>
    </div>
</div>
</template>
<script>
export default {
  data() {
    return {
        id:'',
        password:'',
        firstName:'',
        lastName:'',
        emailAddr:'',
        emailProvider:'',
        tel1:'010',
        tel2:'',
        tel3:'',
        telList:[
           {value:'010', label:'010'} ,
           {value:'011', label:'011'} ,
           {value:'012', label:'012'}
        ]
    }
  }
}
</script>
