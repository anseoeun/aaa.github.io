<template>
<!-- wrapper -->
<div class="wrapper">
	<!-- <div class="header">
        <div class="inner-wrap">
            <h1 class="logo"><img src="~assets/images/logo.png" alt=""></h1>
            <div class="right">
                <ul class="gnb">
                    <li><a href="javascript:void(0);">건물</a></li>
                    <li><a href="javascript:void(0);">가게</a></li>
                    <li><a href="javascript:void(0);">상품</a></li>
                    <li><a href="javascript:void(0);">주문</a></li>
                </ul>
                <div class="login-menu">
                    <a href="javascript:void(0);">LOGIN</a>
                    <a href="javascript:void(0);">SIGN UP</a>
                </div>
                <div class="mypagen-menu">
                    <a href="javascript:void(0);">MY page</a>
                </div>
            </div>
        </div>
    </div> -->
    <Nuxt />
    <!-- <div class="footer">
        <div class="inner-wrap">
            <ul class="footer-menu">
                <li><a href="javascript:void(0);">회사소개</a></li>
                <li><a href="javascript:void(0);">개인정보취급방침</a></li>
                <li><a href="javascript:void(0);">이용약관</a></li>
                <li><a href="javascript:void(0);">서비스이용약관</a></li>
            </ul>
            <div class="address">
                <span class="name">원체크사장님광장</span>
                <span class="addr">주소. 주소부분입니다. 1600 (가전리 307)</span>
                <span class="tel">Tel. 02-123-4567</span>
            </div>
            <div class="copyright">
                COPYRIGHT ⓒ  <b>2021 ONE CHECK.</b> ALL RIGHTS RESERVED.
            </div>
        </div>
    </div> -->
</div>
<!-- // wrapper -->
</template>
