<template>
  <div class="pagination">
      <VBtn class="prev"></VBtn>
      <span class="page">
          <VBtn class="on"><span>1</span></VBtn>
          <VBtn><span>2</span></VBtn>
          <VBtn><span>3</span></VBtn>
          <VBtn><span>4</span></VBtn>
          <VBtn><span>5</span></VBtn>
      </span>
      <VBtn class="next" disabled="true"></VBtn>
  </div>    
</template>
