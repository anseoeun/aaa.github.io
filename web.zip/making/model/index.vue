<template>
  <div class="making-container">
      <div class="car-visual">
        <div class="visual" style="background-image:url('/_nuxt/src/assets/images/mycar/bg-casper-body.jpg')"></div>
        <div class="visual-menu">
          <v-btn type="button" class="btn-out"></v-btn>
          <v-btn type="button" class="btn-in"></v-btn>
          <span class="btn-spred">
            <v-btn type="button" :class="[`${spredBtn}`, {on : spredBtnIs}]" @click="spredBtnIs = !spredBtnIs"></v-btn>
              <span v-show="spredBtnIs" class="spred">
                <v-btn v-if="spredBtn !== 'btn-day'" type="button" class="btn-day" @click="spredBtn = 'btn-day'"></v-btn>
                <v-btn v-if="spredBtn !== 'btn-night'" type="button" class="btn-night" @click="spredBtn = 'btn-night'"></v-btn>
                <v-btn v-if="spredBtn !== 'btn-outdoor'" type="button" class="btn-outdoor" @click="spredBtn = 'btn-outdoor'"></v-btn>
                <v-btn v-if="spredBtn !== 'btn-city'" type="button" class="btn-city" @click="spredBtn = 'btn-city'"></v-btn>
              </span>
          </span>
        </div>
      </div>
      <div ref="caropt" class="car-option" :class="{expend : isExpend}" @scroll="scroll">
        <div ref="caroptin" class="inner">
          <div class="recommend">
            <p class="txt">
              잠깐! 선택이 어려우신가요? <br />
              나만의 캐스퍼를 추천해 드립니다.
            </p>
            <span class="img"></span>
            <!-- <v-img :src="carImg.src" :alt="carImg.alt"></v-img> -->
          </div>
          <!-- 바디타입 -->
          <div class="option-box">
            <div class="box-header">
              <b class="tit">바디타입</b>
            </div>
            <div class="box-body">
                <v-radio v-model="bodyTypeVal" class="radio-blue-round-button btn-num2" type="button" :data="bodyType" />
            </div>
          </div>
          <!-- 트림 -->
          <div class="option-box">
            <div class="box-header">
              <b class="tit">트림</b>
              <div class="right">
                <v-btn type="button" class="more">트림 비교 보기</v-btn>
              </div>
            </div>
            <div class="box-body">
              <v-radio v-model="trimListVal" class="radio-blue-round-button t-bewteen" type="button" :custom-label="true" :data="trimList">
                  <template slot-scope="props"><span class="left">{{ props.item.label }}</span> <span class="right">{{ props.item.price }}원</span></template>
              </v-radio>
            </div>
          </div>
          <!-- 외장색상 -->
          <div class="option-box">
            <div class="box-header">
              <b class="tit">외장색상</b>
              <div class="right">
                <v-btn type="button" class="more">인기 색상 보기</v-btn>
              </div>
            </div>
            <div class="box-body">
              <v-radio v-model="outColorVal" :custom-label="true" :data="outColorList" class="out-color-List">
                  <template slot-scope="props">
                    <v-popover trigger="hover" :placement="props.item.index % 5 == 0 || props.item.index % 6 == 0 ? 'top-end' : 'top-start'" style-type="popover-round">
                      <p>
                        {{ props.item.exp }}
                      </p>
                      <i v-if="props.item.type === 'shiny'" slot="reference" class="out-color shiny" :style="`background-color:${props.item.color}`"></i>
                      <i v-if="props.item.type === 'matte'" slot="reference" class="out-color matte" :style="`background-color:${props.item.color}`"></i>
                    </v-popover>
                  </template>
              </v-radio>
              <div class="optprice">
                <div class="left">
                  <span class="name">소울 트로닉 오렌지 펄</span>
                </div>
                <div class="right"><span class="price">+ 0 원</span></div>
              </div>
            </div>
          </div>
          <!-- 내장색상 -->
          <div class="option-box">
            <div class="box-header">
              <b class="tit">내장색상</b>
              <div class="right">
              </div>
            </div>
            <div class="box-body">
              <v-radio v-model="inColorVal" :custom-label="true" :data="inColorList" class="in-color-List">
                <template slot-scope="props">
                  <v-popover trigger="hover" :placement="props.item.index % 2 == 0 ? 'top-end' : 'top-start'" style-type="popover-round">
                    <p>
                      {{ props.item.exp }}
                    </p>
                    <!-- <i slot="reference" class="in-color" :style="`background-image:${props.item.img}`"></i> -->
                    <i slot="reference" class="in-color" :style="`background-image:url(${props.item.img})`"></i>
                  </v-popover>
                </template>
              </v-radio>
              <div class="optprice">
                <div class="left">
                  <span class="name">블랙(NNB) + 칼라 포인트</span>
                </div>
                <div class="right"><span class="price">+ 300,000 원</span></div>
              </div>
            </div>
          </div>
          <div class="etc-option">

            <!-- 옵션 -->
            <div class="option-box">
              <v-btn class="btn-option-open" @click="optExpend('option1')"></v-btn>
              <v-btn class="btn-option-close" @click="optContract('option1')"></v-btn>
              <div class="box-header">
                <b class="tit">옵션</b>
                <div class="right">
                  <v-btn type="button" class="more">추천 옵션 보기</v-btn>
                </div>
              </div>
              <div class="box-body">
                <div class="car-option-list">
                  <ul>
                    <li v-for="(item, index) in optionList" :key="index">
                      <a href="javascript:void(0)" role="button" type="button" class="opt-bx" :class="{on : optionListVal === item.value}" @click="optionListVal = item.value">
                        <div class="tit">
                            <span>{{ item.tit }}</span>
                        </div>
                        <div class="img">
                          <v-btn class="btn-icon">
                            <v-popover trigger="click" placement="top-end">
                              <p>
                                {{ item.exp }}
                              </p>
                              <i slot="reference" class="icon-info"></i>
                            </v-popover>
                          </v-btn>
                          <v-img :src="item.img" :alt="item.tit"></v-img>
                        </div>
                        <div class="price">
                          + {{ item.price }} 원
                        </div>
                      </a>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
            <!-- H Genuine Accessories -->
            <div class="option-box">
              <v-btn class="btn-option-open" @click="optExpend('option2')"></v-btn>
              <v-btn class="btn-option-close" @click="optContract('option2')"></v-btn>
              <div class="box-header">
                <b class="tit">H Genuine<br />Accessories</b>
                <div class="right">
                  <v-btn type="button" class="more">추천 옵션 보기</v-btn>
                </div>
              </div>
              <div class="box-body">
                <div class="car-option-list">
                  <ul>
                    <li v-for="(item, index) in optionList" :key="index">
                      <a href="javascript:void(0)" role="button" type="button" class="opt-bx" :class="{on : optionListVal === item.value}" @click="optionListVal = item.value">
                        <div class="tit">
                            <span>{{ item.tit }}</span>
                        </div>
                        <div class="img">
                          <v-btn class="btn-icon">
                            <v-popover trigger="click" placement="top-end">
                              <p>
                                {{ item.exp }}
                              </p>
                              <i slot="reference" class="icon-info"></i>
                            </v-popover>
                          </v-btn>
                          <v-img :src="item.img" :alt="item.tit"></v-img>
                        </div>
                        <div class="price">
                          + {{ item.price }} 원
                        </div>
                      </a>
                    </li>
                  </ul>
                </div>
              </div>
            </div>

          </div>

          <div class="fixed-price-wrap">
            <a href="javascript:void(0);" class="fixed-price" :style="fixSubStyle">
              <div class="left">총 차량 가격</div>
              <div class="right">
                <span class="account">
                  <b>13,890,000</b> 원
                </span>
                <i class="icon-summary-view"></i>
              </div>
            </a>
          </div>
          <div class="total-price" style="height:50px;background:pink">
            총금액
          </div>
        </div>
      </div>

  </div>
</template>

<script>
export default {
  head() {
    return {
      title: '탐색 > 내 차 만들기',
      bodyAttrs: {
        style:'overflow-y:hidden'
      }
    }
  },
  name: 'Casper',
  layout: 'casper',
  components: {

  },
  data() {
    return {
      isExpend: false,
      carImg: {
        src: require('~/assets/images/temp/temp-payment-car-model.png'),
        alt: 'AX 스마트스트림 가솔린 1.1 터보 프리미엄 밀레니얼 A/T',
      },
      bodyTypeVal: '',
      bodyType: [
        { value: 'suv', label: 'SUV' },
        { value: 'suvban', label: 'SUV 밴' },
      ],
      trimListVal: '',
      trimList: [
        { value: 'trim1', label: '스마트', price:'12,100,000' },
        { value: 'trim2', label: '모던', price:'13,600,000' },
        { value: 'trim3', label: '인스퍼레이션', price:'15,700,000' },
      ],
      outColorVal: '',
      outColorList: [
        {index:1, value: 'color1', type: 'shiny', exp:'회색', price: '0', color: '#e2e2e2'},
        {index:2, value: 'color2', type: 'shiny', exp: '그레이', price: '50,000', color: '#848484'},
        {index:3, value: 'color3', type: 'shiny', exp: '블랙', price: '10,000', color: '#000000'},
        {index:4, value: 'color4', type: 'shiny', exp: '하늘색', price: '0', color: '#9ceafc'},
        {index:5, value: 'color5', type: 'shiny', exp: '소울 트로닉 오렌지 펄', price: '30,000', color: '#ec6333'},
        {index:6, value: 'color6', type: 'shiny', exp: '블루', price: '10,000', color: '#0707ff'},
        {index:7, value: 'color7', type: 'matte', exp: '그레이 그레이', price: '40,000', color: '#a3a3a3'},
        {index:8, value: 'color8', type: 'matte', exp: '톰보이 카키 매트', price: '70,000', color: '#667866'},
      ],
      inColorVal: '',
      inColorList: [
        {index:1, value: 'color1', exp:'회색회색회색회색', price: '0', img: require('~/assets/images/temp/temp-payment-car-model1.png')},
        {index:2, value: 'color2', exp: '블랙 모노', price: '50,000', img: require('~/assets/images/temp/temp-payment-car-model2.png')},
        {index:3, value: 'color3', exp: '톰보이 카키 매트', price: '10,000', img: require('~/assets/images/temp/temp-payment-car-model3.png')},
      ],
     scrollSize:'',
     scrollIs: false,
     scrollBottom: false,
     fixSubStyle :'',
     optionListVal: '',
     optionList: [
       {value: 'option1', tit:'현대 스마트 센스 I', img:require('~/assets/images/temp/temp-car-option.png'), exp:'설명 설명 설명', price:'1,350,000'},
       {value: 'option2', tit:'네비게이션 패키지', img:require('~/assets/images/temp/temp-car-option.png'), exp:'설명 설명 설명', price:'1,350,000'},
       {value: 'option3', tit:'에센셜 플러스', img:require('~/assets/images/temp/temp-car-option.png'), exp:'설명 설명 설명', price:'1,350,000'},
       {value: 'option4', tit:'현대 스마트 센스 I', img:require('~/assets/images/temp/temp-car-option.png'), exp:'설명 설명 설명', price:'1,350,000'},
       {value: 'option5', tit:'네비게이션 패키지', img:require('~/assets/images/temp/temp-car-option.png'), exp:'설명 설명 설명', price:'1,350,000'},
       {value: 'option6', tit:'에센셜 플러스', img:require('~/assets/images/temp/temp-car-option.png'), exp:'설명 설명 설명', price:'1,350,000'},
     ],

     //spredBtn
     spredBtnIs: false,
     spredBtn: 'btn-day'
    }
  },
  computed: {
    // scrollIs() {
    //   return this.scrollCheck()
    // },
    // fixSubStyle(){
    //   return this.setStyle()
    // }
  },
  mounted(){
    this.scrollSize = this.$refs.caropt.offsetWidth - this.$refs.caropt.clientWidth
    this.scrollCheck()
    this.setStyle()
  },
  methods: {
    setStyle(){
      if(this.scrollIs && this.scrollBottom){
        this.fixSubStyle = ''
      }else if(this.scrollIs && this.scrollBottom == false) {
        this.fixSubStyle = 'position:fixed;bottom:0;right:'+this.scrollSize+';width:'+(this.$refs.caropt.clientWidth - this.scrollSize)+'px;'
      }else{
        this.fixSubStyle = 'position:fixed;bottom:0;right:0;width:'+this.$refs.caropt.offsetWidth+'px;'
      }
    },
    scrollCheck() {
      console.log(this.$refs.caropt.offsetWidth)
      console.log(this.$refs.caropt.clientWidth)
      if(this.$refs.caropt.offsetWidth == this.$refs.caropt.clientWidth) this.scrollIs = false
      else this.scrollIs = true
    },
    scroll(){
      // console.log( this.$refs.caropt.scrollTop + this.$refs.caropt.clientHeight);
      // console.log(this.$refs.caroptin.clientHeight - 100);
      if(this.$refs.caropt.scrollTop + this.$refs.caropt.clientHeight >= (this.$refs.caroptin.clientHeight - 60)) {
        this.scrollBottom = true
          this.setStyle()
      }else{
        this.scrollBottom = false
          this.setStyle()
      }
    },
    optExpend() {
      this.isExpend = true
    },
    optContract() {
      this.isExpend = false
    }
  }

}
</script>
<style >

.popover-round{background:red}
[styleType="popover-round"]{background:red}
</style>