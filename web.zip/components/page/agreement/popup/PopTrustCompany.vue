<template>
  <div>

    <!-- 블루핸즈 가맹점 외 2개 업체 -->
    <v-popup
      :visible="popVisible.companyBluehands"
      :width="'776px'"
      :footer="['confirm']"
      @close="
        $emit('close')
      "
      @confirm="
        $emit('close')
      "
    >

      <template slot="header">
        <div class="title">개인정보 위탁업무별 수탁업체 안내</div>
      </template>
      <template slot="body">
        <div class="table-area nohead">
          <table class="noline">
            <colgroup>
              <col width="105px" />
              <col width="auto" />
            </colgroup>
            <tbody>
              <tr>
                <th class="bold">위탁 업무</th>
                <td class="left">보증수리, 긴급출동, 차량관리서비스 및 제작결함 시정 대행, 특장차량 특장부분에 대한 보증수리</td>
              </tr>
              <tr>
                <th class="bold">수탁 업체</th>
                <td class="left">블루핸즈 가맹점, 현대하이카손해사정(주), 열쇠콜</td>
              </tr>
            </tbody>
          </table>
        </div>
      </template>
    </v-popup>

    <!-- 오복사 외 85개 업체 -->
    <v-popup
      :visible="popVisible.companyOboksa"
      :width="'776px'"
      :footer="['confirm']"
      @close="
        $emit('close')
      "
      @confirm="
        $emit('close')
      "
    >

      <template slot="header">
        <div class="title">개인정보 위탁업무별 수탁업체 안내</div>
      </template>
      <template slot="body">
        <div class="table-area nohead">
          <table class="noline">
            <colgroup>
              <col width="105px" />
              <col width="auto" />
            </colgroup>
            <tbody>
              <tr>
                <th class="bold">위탁 업무</th>
                <td class="left">차량 등록대행(업체)</td>
              </tr>
              <tr>
                <th class="bold">수탁 업체</th>
                <td class="left">오복사, 전국행정사협회, 일우사, 광진 오복사, 동대문 태광사, 삼오사, 충일오복사, 대현씨에스, 오복사(삼형제), 오복충일사, 당진오복사, 명진행정사사무소, 행정사이정호사무소, 아산삼오사행정사, 고려자동차등록대행사, 여수오복사, 종합자동차등록대행, 소망등록대행, 행정사 최광택사무소, 삼우사, 무실번호 판제작소, 등록나라, 충일사, 우성사, 대하사, 경기사, 부천오복사, 신우상사, JK행정사, 차용지행정서사, 군산채권사, 전북번호판제작소, 성일사, 오복사우림채권, 정읍번호판 제작소, 제일자동차번호판제작소, 동인종합카센타&amp;익산동인번호판, 삼보, 구미등록, 삼보행정사, 현우사, 우리사, 경성사, 서천일행정사, 평화사, 성북오복사, 신라상운(도봉오복사 / 노원충일사 / 강북오복사 / 동대문오복사), 우진사, 월드행정사, 부경사, 충일카프라자, 카인스톨, 행정사 최승식 사무소, 행정사 박회순 사무소, 엘지상사, 세계 철거전문공사(솔로몬 행정사), 행정사배정록사무소, 정국진행정사, 제일사, 화성사, 최용구행정사무소(금강 행정사사무소), 국민사무소, 미래사무소, 대광사, ㈜다진, 대한상사, 대성, 미진사, 삼정오복, 한뫼, 천리마, 현대한길로, ㈜제이엘, 대명사, 하나사, 한빛종보, 군포은화사, 시화상사, 광명대행사, 은화, 미래사, 조은사, 용인중앙행정사사무소, 한영순, 경기태극사, 운광사</td>
              </tr>
            </tbody>
          </table>
        </div>
      </template>
    </v-popup>

    <!-- 현대글로비스(주) 외 16개 업체 -->
    <v-popup
      :visible="popVisible.companyGlovis"
      :width="'776px'"
      :footer="['confirm']"
      @close="
        $emit('close')
      "
      @confirm="
        $emit('close')
      "
    >

      <template slot="header">
        <div class="title">개인정보 위탁업무별 수탁업체 안내</div>
      </template>
      <template slot="body">
        <div class="table-area nohead">
          <table class="noline">
            <colgroup>
              <col width="105px" />
              <col width="auto" />
            </colgroup>
            <tbody>
              <tr>
                <th class="bold">위탁 업무</th>
                <td class="left">계약차량의 고객인도</td>
              </tr>
              <tr>
                <th class="bold">수탁 업체</th>
                <td class="left">현대글로비스㈜, ㈜광장물류, ㈜아름물류, ㈜용성물류, 대통, 무진물류㈜, 상원물류㈜, ㈜선명물류, ㈜심천, 유수물류㈜, ㈜진용물류, 주성네트웍스㈜, 세마물류, ㈜현대로지스, 부기물류㈜, (유)현대로지스틱스, 에이치엠물류㈜</td>
              </tr>
            </tbody>
          </table>
        </div>
      </template>
    </v-popup>

    <!-- (주)한국갤럽조사연구소 외 15개 업체 -->
    <v-popup
      :visible="popVisible.companyGallup"
      :width="'776px'"
      :footer="['confirm']"
      @close="
        $emit('close')
      "
      @confirm="
        $emit('close')
      "
    >

      <template slot="header">
        <div class="title">개인정보 위탁업무별 수탁업체 안내</div>
      </template>
      <template slot="body">
        <div class="table-area nohead">
          <table class="noline">
            <colgroup>
              <col width="105px" />
              <col width="auto" />
            </colgroup>
            <tbody>
              <tr>
                <th class="bold">위탁 업무</th>
                <td class="left">구매차량 만족도 및 신차에 대한 소비자의견 조사</td>
              </tr>
              <tr>
                <th class="bold">수탁 업체</th>
                <td class="left">㈜한국갤럽조사연구소, 닐슨컴퍼니코리아(유), ㈜입소스코리아, 나이스알엘씨㈜, ㈜한국리서치, ㈜칸타코리아, 지에프 케이커스텀리서치코리아(유), ㈜마크로밀엠브레인, ㈜밀워드브라운미디어리서치, ㈜마케팅인사이트, ㈜서울마케팅리서치, 에이콘마케팅 앤드리서치컨설턴츠홍콩리미티드한국영업소, ㈜엠브레인, 시노베이트 코리아, 포커스컴퍼니㈜, ㈜리서치랩</td>
              </tr>
            </tbody>
          </table>
        </div>
      </template>
    </v-popup>

    <!-- NICE신용평가정보(주) 외 5개 업체 -->
    <v-popup
      :visible="popVisible.companyNice"
      :width="'776px'"
      :footer="['confirm']"
      @close="
        $emit('close')
      "
      @confirm="
        $emit('close')
      "
    >

      <template slot="header">
        <div class="title">개인정보 위탁업무별 수탁업체 안내</div>
      </template>
      <template slot="body">
        <div class="table-area nohead">
          <table class="noline">
            <colgroup>
              <col width="105px" />
              <col width="auto" />
            </colgroup>
            <tbody>
              <tr>
                <th class="bold">위탁 업무</th>
                <td class="left">차량구입대금 추심&middot;신용정보조회, 시장분석 및 본인확인 등</td>
              </tr>
              <tr>
                <th class="bold">수탁 업체</th>
                <td class="left">NICE신용평가정보㈜, 솔로몬신용정보㈜, 서울신용평가정보㈜, 미래신용정보㈜, 고려신용정보㈜, 세일신용정보㈜</td>
              </tr>
            </tbody>
          </table>
        </div>
      </template>
    </v-popup>

    <!-- (주)골든민커뮤니케이션 외 11개 업체 -->
    <v-popup
      :visible="popVisible.companyGolden"
      :width="'776px'"
      :footer="['confirm']"
      @close="
        $emit('close')
      "
      @confirm="
        $emit('close')
      "
    >

      <template slot="header">
        <div class="title">개인정보 위탁업무별 수탁업체 안내</div>
      </template>
      <template slot="body">
        <div class="table-area nohead">
          <table class="noline">
            <colgroup>
              <col width="105px" />
              <col width="auto" />
            </colgroup>
            <tbody>
              <tr>
                <th class="bold">위탁 업무</th>
                <td class="left">고객초청행사, TM, 우편물 및 경품 배송 업무 대행</td>
              </tr>
              <tr>
                <th class="bold">수탁 업체</th>
                <td class="left">㈜골든민커뮤니케이션, 3A빌링㈜, ㈜빌 포스트, 조우니(블루링크/모젠), 이노션, 무한상상, 클립서비스㈜, ㈜플레이스엠, ㈜한진, 모그커뮤니케이션즈, 미디어블링, 올포원</td>
              </tr>
            </tbody>
          </table>
        </div>
      </template>
    </v-popup>

    <!-- 효성ITX(주) 외 1개 업체 -->
    <v-popup
      :visible="popVisible.companyHyosung"
      :width="'776px'"
      :footer="['confirm']"
      @close="
        $emit('close')
      "
      @confirm="
        $emit('close')
      "
    >

      <template slot="header">
        <div class="title">개인정보 위탁업무별 수탁업체 안내</div>
      </template>
      <template slot="body">
        <div class="table-area nohead">
          <table class="noline">
            <colgroup>
              <col width="105px" />
              <col width="auto" />
            </colgroup>
            <tbody>
              <tr>
                <th class="bold">위탁 업무</th>
                <td class="left">텔레매틱스 서비스 및 가입안내</td>
              </tr>
              <tr>
                <th class="bold">수탁 업체</th>
                <td class="left">효성ITX㈜, ㈜KT</td>
              </tr>
            </tbody>
          </table>
        </div>
      </template>
    </v-popup>

    <!-- 글라스코팅(동부) 외 114개 업체 -->
    <v-popup
      :visible="popVisible.companyGlass"
      :width="'776px'"
      :footer="['confirm']"
      @close="
        $emit('close')
      "
      @confirm="
        $emit('close')
      "
    >

      <template slot="header">
        <div class="title">개인정보 위탁업무별 수탁업체 안내</div>
      </template>
      <template slot="body">
        <div class="table-area nohead">
          <table class="noline">
            <colgroup>
              <col width="105px" />
              <col width="auto" />
            </colgroup>
            <tbody>
              <tr>
                <th class="bold">위탁 업무</th>
                <td class="left">오디오, 차량시트, 차량 유리 등 상담 및 정비서비스</td>
              </tr>
              <tr>
                <th class="bold">수탁 업체</th>
                <td class="left">글라스코팅(동부), 현대자동차유리(동부), 동부유리, 대교시트(동부), 동부서비스렌터카, 수지상사(동부), 현대유통(동부), 대화유리(북부), 현대북부시트(북부), 창동북부점현대자동차㈜(북부), 현대커밍마스타(북부), 장산(북부), 현대성우광택(남부), 대화유리(남부), ㈜블루핸즈 현대시트(남부), 동부시트사(남부), 현대유통(남부), 용진서비스(남부), 한스팀(남부), 대방서비스(남부), 현대광택(고양), 대화유리㈜(고양), 현대차유리(고양), 현대서울시트(고양), 고양스팀세차, 휠 프로(고양), ㈜오토핸즈 마이렌터카(고양), 시케이서비스(고양), 현대코팅광택(인천), 현대차유리(인천), 한국타이어 동암대리점(인천), 세원광택(인천), 태인모터스(인천), 신현대캐리어(인천), 현대수원시트(수원), 유영자동차유리상사(수원), (주)고속상사(수원), 현대특수자동차(수원), 오토비스코리아(수원), 현대시트(시화), 유영자동차유리(시화), 타이어마트 시화점, 백송모터스(시화), 현대차유리(강릉), 파이카솔루션(강릉), 한국타이어T스테이션 강릉MBC점, 현대깔끔이세차장(강릉), 비상(강릉), 현대스팀세차(청주), 대우자동차유리(청주), 주식회사 충청특판(타이어프로 봉명점)(청주), 진성(청주), GH모터스(대전), 금강자동차유리(대전), 한국타이어고속총판㈜(대전), 현대긴급렉카(대전), 현대이동세차(대전), 에이치에스(H.S)렌탈서비스(대전), 현대차유리(전주), 대륙시트(전주), 타이어테크 동산점(전주), 대성광택(전주), 전주센터렌탈서비스(전주), 희망스팀세차(전주), 현대유리시트사(군산), 서강차유리(군산), 이레(군산), 유진자동차유리(광주), 현대광택(광주), 파란 H&amp;N(광주), 대화차유리(순천), 쎈택(순천), 대원종합부품카써비스운송(순천), 동인전기광택(대구), 삼오자동차유리(대구), 현대대경시트(대구), 충북타이어상사(대구), 엠디(MD)오토 대구노원점, 엘림렌탈서비스(대구), 현대차유리(포항), 태원특수렉카(포항), ㈜기분좋은타이어(포항), 로하스렌터카(포항), 광쟁이(포항), 현대유리(부산), 대진종합상사(부산), KJH 모터스(부산), 현대스팀세차(부산), A.B.S 밍광택(사상), 해광자동차유리(사상), 현대타이어(사상), 현대렌트써비스(사상), 나이스스팀세차(사상), 상신차유리시트(서부산), 삼천리주차장(서부산), 현대스팀세차(서부산), 현대시트유리상사(울산), 현대스팀세차(울산), 조이본드(울산), 현대출장광택(울산), 올레렌터카(울산), 타이어마스타 울산총판, 부림시트(창원), 현창(창원), 현대창원렌트서비스(창원), 모터플러스 창원점, 현대카광택(제주), 현대차유리(제주), 재상렌트카(제주), 베바스토코리아홀딩스, 인알파코리아㈜, ㈜현대웰슨, ㈜세븐TMC, 롯데렌탈㈜, SK렌터카</td>
              </tr>
            </tbody>
          </table>
        </div>
      </template>
    </v-popup>

  </div>
</template>

<script>
import { VPopup } from '~/components/element'
export default {
  components: {
    VPopup
  },
  props: {
    popVisible: {
      type: Object,
      defualt: {},
      required: true
    }
  },

  // 2021.03.17 (ver1.1)
  updated() {
    this.setCaption()
  },
}
</script>