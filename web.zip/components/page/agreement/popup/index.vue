<template>
  <div class="">
    <!-- 개인정보 위탁업무별 수탁업체 안내  -->
    <pop-trust-company :pop-visible="visible" />

  </div>
</template>

<script>
import PopTrustCompany from '~/components/page/agreement/popup/PopTrustCompany'

export default {
  components: {
    PopTrustCompany,

  },
  props: {
    visible: {
      type: Object,
      defualt: {},
      required: true
    }
  },
  data() {
    return {}
  },
  methods: {
    parentsSync(e) {
      this.visible = e
      this.$emit('visibleSync', this.visible)
    }
  }
}
</script>
