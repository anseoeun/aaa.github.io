<template>
  <div class="summary-wrap">
    <div class="summary-box">
      <b class="tit">트림</b>
      <div class="summary-txt">
        <span class="txt">
          캐스퍼 가솔린 1.0 터보 Smart 2WD 오토
        </span>
        <span class="price">
          <b>10,790,000</b>원
        </span>
      </div>
    </div>
    <div class="summary-box">
      <b class="tit">외장색상</b>
      <div class="summary-txt">
        <span class="txt">
          이그나이트 플레임(팬텀블랙)
        </span>
        <span class="price">
          +<b>0</b>원
        </span>
      </div>
    </div>
    <div class="summary-box">
      <b class="tit">내장색상</b>
      <div class="summary-txt">
        <span class="txt">
          블랙-그레이 투톤 칼라패키지
        </span>
        <span class="price">
          +<b>100,000</b>원
        </span>
      </div>
    </div>
    <div class="summary-box">
      <b class="tit">옵션</b>
      <ul class="summary-list">
        <li>
          <span class="txt">
            빌트인 캠(보조배터리 미포함)
          </span>
          <span class="price">
            +<b>900,000</b>원
          </span>
        </li>
        <li>
          <span class="txt">
            빌트인 캠(보조배터리 미포함)
          </span>
          <span class="price">
            +<b>900,000</b>원
          </span>
        </li>
        <li>
          <span class="txt">
            빌트인 캠(보조배터리 미포함)
          </span>
          <span class="price">
            +<b>900,000</b>원
          </span>
        </li>
        <li>
          <span class="txt">
            빌트인 캠(보조배터리 미포함)
          </span>
          <span class="price">
            +<b>900,000</b>원
          </span>
        </li>
        <li>
          <span class="txt">
            빌트인 캠(보조배터리 미포함)
          </span>
          <span class="price">
            +<b>900,000</b>원
          </span>
        </li>
        <li>
          <span class="txt">
            빌트인 캠(보조배터리 미포함)
          </span>
          <span class="price">
            +<b>900,000</b>원
          </span>
        </li>
      </ul>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {

    }
  },
}
</script>
