<template>
  <div class="">
    <!-- 지인할인추천안내  -->
    <friend-recommend :pop-visible="visible" />

    <!-- 트림비교 항목보기  -->
    <detail :pop-visible="visible"
      @packagePop="visible.packageGuide = true"
     />

    <!-- 사양안내팝업(패키지)  -->
    <package-guide :pop-visible="visible" />

    <!-- 사양안내팝업(일반)  -->
    <spec-guide :pop-visible="visible" />

    <!-- 트림비교  -->
    <compare-select :pop-visible="visible" />

    <!-- 색상에따른트림변경안내  -->
    <trim-change-info :pop-visible="visible" />

    <!-- 색상에따른옵션추가안내  -->
    <option-change-info :pop-visible="visible" />

    <!-- 파츠추가안내  -->
    <parts-add-info :pop-visible="visible" />

    <!-- 파츠삭제안내  -->
    <parts-dell-info :pop-visible="visible" />

    <!-- 색상추천정보 -->
    <recommend-color :pop-visible="visible" />

    <!-- 옵션추천정보 -->
    <recommend-option :pop-visible="visible" />

    <!-- 차량조합추천 -->
    <recommend-combination :pop-visible="visible" />
  </div>
</template>

<script>
import FriendRecommend from '~/components/page/vehicles/popup/FriendRecommend'
import PackageGuide from '~/components/page/vehicles/popup/PackageGuide'
import Detail from '~/components/page/vehicles/making/popup/Detail'
import SpecGuide from '~/components/page/vehicles/popup/SpecGuide'
import CompareSelect from '~/components/page/vehicles/comparison/popup/CompareSelect'
import TrimChangeInfo from '~/components/page/vehicles/making/popup/TrimChangeInfo'
import OptionChangeInfo from '~/components/page/vehicles/making/popup/OptionChangeInfo'
import PartsAddInfo from '~/components/page/vehicles/making/popup/PartsAddInfo'
import PartsDellInfo from '~/components/page/vehicles/making/popup/PartsDellInfo'
import RecommendColor from '~/components/page/vehicles/making/popup/RecommendColor'
import RecommendOption from '~/components/page/vehicles/making/popup/RecommendOption'
import RecommendCombination from '~/components/page/vehicles/making/popup/RecommendCombination'

export default {
  components: {
    FriendRecommend,
    PackageGuide,
    Detail,
    SpecGuide,
    CompareSelect,
    TrimChangeInfo,
    OptionChangeInfo,
    PartsAddInfo,
    PartsDellInfo,
    RecommendColor,
    RecommendOption,
    RecommendCombination
  },
  props: {
    visible: {
      type: Object,
      defualt: {},
      required: true
    }
  },
  data() {
    return {}
  },
}
</script>
