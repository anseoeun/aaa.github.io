<template>
  <v-popup
    :width="'1000px'"
    :visible="popVisible.recommendCombination"
    @close="popVisible.recommendCombination = false"
  >
    <template slot="header">
      <div class="title">사회 초년생이 선택한 캐스퍼</div>
      <p class="header-description">20대가 가장 많이 선택한 캐스퍼 TOP3입니다.</p>
    </template>
    <template slot="body">
      <div class="recommend-combi-wrap">
        <ul>
          <li v-for="(item, index) in recommendList" :key="index">
            <div class="trim-info">
              <div class="trim-name">{{ item.trimName }}</div>
              <div class="car-price">
                <v-img :src="item.imgSrc" :alt="item.carAlt"></v-img>
                <p>
                  <strong>{{ item.carPrice }}</strong> 원
                </p>
              </div>
            </div>

            <!-- open -->
            <div v-if="show" class="combi-list-open">
              <ul>
                <li v-for="(option, idx) in item.optionList" :key="idx">
                  <div class="option-title">{{ option.optionTitle }}</div>
                  <ul class="option-info">
                    <li v-for="(list, sidx) in option.infoList" :key="sidx">
                      <span class="option-name">{{ list.optionName }}</span>
                      <em class="option-price">{{ list.optionPrice }} 원</em>
                    </li>
                  </ul>
                </li>
              </ul>
              <div class="total">
                <span>총가격</span>
                <em
                  ><strong>{{ item.carPrice }}</strong> 원</em
                >
              </div>
            </div>
            <!-- // open -->

            <!-- default -->
            <div v-else class="combi-list">
              <ul>
                <li v-for="(data, idx) in item.optionListsmall" :key="idx">
                  <div class="option-title">{{ data.optionTitle }}</div>
                  <div class="option-name">{{ data.optionName }}</div>
                </li>
              </ul>
            </div>
            <!-- // default -->

            <v-btn class="btn md blue line r" type="button">선택하기</v-btn>
          </li>
        </ul>

        <!-- open시 class active 추가 -->
        <v-btn class="btn btn-bottom-line" :class="{ active: show }" @click="show = !show">TOP3 요약 보기</v-btn>
      </div>
    </template>
  </v-popup>
</template>

<script>
import { VBtn } from '~/components/element'
export default {
  components: {
    VBtn
  },
  props: {
    popVisible: {
      type: Object,
      defualt: {},
      required: true
    }
  },
  data() {
    return {
      show: false,
      recommendList: [
        {
          trimName: '가솔린1.0 스마트',
          imgSrc: require('~/assets/images/temp/temp-payment-car-model.png'),
          imgAlt: '',
          carPrice: '12,890,000',
          optionListsmall: [
            { optionTitle: '외장', optionName: '러브 유얼셀프 그린 펄' },
            { optionTitle: '내장', optionName: '블랙 모노' },
            { optionTitle: '옵션', optionName: '시트패키지 II 외 3개' }
          ],
          optionList: [
            {
              optionTitle: '트림',
              infoList: [{ optionName: '가솔린1.0 모던', optionPrice: '11,200,000' }]
            },
            {
              optionTitle: '외장',
              infoList: [{ optionName: '러브 유얼셀프 그린 펄', optionPrice: '+ 0' }]
            },
            {
              optionTitle: '내장',
              infoList: [{ optionName: '블랙 모노', optionPrice: '+ 0' }]
            },
            {
              optionTitle: '옵션',
              infoList: [
                { optionName: '시트패키지 II', optionPrice: '+ 1,000,000' },
                { optionName: '17인치 알로이휠&타이어 II', optionPrice: '+ 800,000' },
                { optionName: '베이직 플럿', optionPrice: '+ 400,000' },
                { optionName: '네비게이션 패키지', optionPrice: '+ 200,000' }
              ]
            }
          ]
        },
        {
          trimName: '가솔린1.0 터보 모던',
          imgSrc: require('~/assets/images/temp/temp-payment-car-model.png'),
          imgAlt: '',
          carPrice: '13,700,000',
          optionListsmall: [
            { optionTitle: '외장', optionName: '톰보이 카키' },
            { optionTitle: '내장', optionName: '블랙(NNB) + 칼라 포인트' },
            { optionTitle: '옵션', optionName: '시트패키지 II 외 4개' }
          ],
          optionList: [
            {
              optionTitle: '트림',
              infoList: [{ optionName: '가솔린1.0 모던', optionPrice: '11,200,000' }]
            },
            {
              optionTitle: '외장',
              infoList: [{ optionName: '톰보이 카키', optionPrice: '+ 0' }]
            },
            {
              optionTitle: '내장',
              infoList: [{ optionName: '블랙(NNB) + 칼라 포인트', optionPrice: '+ 0' }]
            },
            {
              optionTitle: '옵션',
              infoList: [
                { optionName: '시트패키지 II', optionPrice: '+ 1,000,000' },
                { optionName: '17인치 알로이휠&타이어 II', optionPrice: '+ 800,000' },
                { optionName: '베이직 플럿', optionPrice: '+ 400,000' },
                { optionName: '네비게이션 패키지', optionPrice: '+ 200,000' },
                { optionName: '하이패스', optionPrice: '+ 100,000' }
              ]
            }
          ]
        },
        {
          trimName: '가솔린1.0 인스퍼레이션 밴',
          imgSrc: require('~/assets/images/temp/temp-payment-car-model.png'),
          imgAlt: '',
          carPrice: '15,600,000',
          optionListsmall: [
            { optionTitle: '외장', optionName: '보헤미안 블루 펄' },
            { optionTitle: '내장', optionName: '다크 그레이(YGN) + 칼라 포인트' },
            { optionTitle: '옵션', optionName: '시트패키지 II 외 2개' }
          ],
          optionList: [
            {
              optionTitle: '트림',
              infoList: [{ optionName: '가솔린1.0 모던', optionPrice: '11,200,000' }]
            },
            {
              optionTitle: '외장',
              infoList: [{ optionName: '보헤미안 블루 펄', optionPrice: '+ 0' }]
            },
            {
              optionTitle: '내장',
              infoList: [{ optionName: '다크 그레이(YGN) + 칼라 포인트', optionPrice: '+ 0' }]
            },
            {
              optionTitle: '옵션',
              infoList: [
                { optionName: '스타일 패키지 I', optionPrice: '+ 1,000,000' },
                { optionName: '시트패키지 II', optionPrice: '+ 1,000,000' },
                { optionName: '17인치 알로이휠&타이어 II', optionPrice: '+ 800,000' }
              ]
            }
          ]
        }
      ]
    }
  }
}
</script>
