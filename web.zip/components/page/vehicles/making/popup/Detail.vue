<template>
  <v-popup
    :visible="popVisible.detail"
    :width="'1200px'"
    @close="popVisible.detail = false"
  >

    <template slot="header">
      <div class="title">인스퍼레이션</div>
    </template>
    <template slot="body">
      <div class="specification-wrap package">
        <!-- 품목 -->
        <div class="section">
          <div class="basic">
            <strong class="title">기본품목</strong>
            <ul class="tog-list">
              <li v-for="(item, index) in basicList" :key="index" :class="{on: basicListShow == index}">
                <v-btn class="list-tit" @click="setActive('basicListShow', index)">
                  <b>{{ item.name }}</b>
                  <i :class="['icon-tog-arr gray-off', { on: basicListShow == index }]"></i>
                </v-btn>
                <div v-if="basicListShow == index" class="conts">
                  <ul>
                    <li v-for="(opt, idx) in item.option" :key="idx">
                      <!--  2021.04.14(ver1.1)  class="btn-on"변경, span으로 변경, @click="$emit('bagicPop')"제거 -->
                      <span v-if="opt.selected" class="btn-on">{{ opt.name }}</span>
                      <template v-else>
                        <v-btn>{{ opt.name }}</v-btn>
                      </template>
                    </li>
                  </ul>
                </div>
              </li>
            </ul>
          </div>
          <!-- selection -->
          <div class="selection">
            <strong class="title">선택품목</strong>
            <ul class="tog-list">
              <li v-for="(item, index) in selectionList" :key="index" :class="{on: selectionListShow == index}">
                <v-btn class="list-tit" @click="setActive('selectionListShow', index)">
                  <b>{{ item.name }}</b>
                  <i :class="['icon-tog-arr gray-off', { on: selectionListShow == index }]"></i>
                </v-btn>
                <div v-if="selectionListShow == index" class="conts">
                  <ul>
                    <!--  2021.04.14(ver1.1)  class="btn-on"변경, span으로 변경, @click="$emit('bagicPop')"제거 -->
                    <li v-for="(opt, idx) in item.option" :key="idx">
                      <span v-if="opt.selected" class="btn-on">{{ opt.name }}</span>
                      <template v-else><v-btn>{{ opt.name }}</v-btn></template>
                      <div class="right">
                        <span class="price">{{ opt.price }} 원</span>
                      </div>
                    </li>
                  </ul>
                </div>
              </li>
            </ul>
          </div>
          <!-- // selection -->
        </div>
        <!-- 품목상세 -->
        <div class="section">
            <strong class="title">카파개선 1.0 엔진</strong>
            <ul class="opt-tab">
              <li>
                <v-btn class="tab">고속도로 주행 보조</v-btn>
              </li>
              <li class="on">
                <v-btn class="tab">내비게이션 기반 스마트 크루즈 컨트롤(안전구간, 곡선로)</v-btn>
              </li>
              <li>
                <v-btn class="tab">원격 스마트 주차 보조</v-btn>
              </li>
              <li>
                <v-btn class="tab">스마트 크루즈 컨트롤(정차 및 재출발 기능 포함)</v-btn>
              </li>
            </ul>
            <!-- 사진 -->
            <div class="pooto-view-list-wrap">
              <v-carousel-new
                :data="photoList"
                :navigation="true"
                :pagination="true"
                :items-to-show="1"
                :items-to-slide="1"
                class="pooto-view-list"
              >
                <template slot-scope="props">
                  <div class="item">
                    <div class="img">
                      <v-img :src="props.item.src" :alt="props.item.alt"></v-img>
                    </div>
                  </div>
                </template>
              </v-carousel-new>
            </div>
            <!-- // 사진 -->
            <div class="opt-desc">
              <div class="opt-exp">
                차세대 파워트레인 엔진으로 차량의 운전조건에 따라 스마트하게 제어하며 최고 수준의 연비와 성능을 구현합니다. 통합 열관리 시스템, 마찰 저감 엔진 무빙 시스템을 통해 연소 효율과 연비를 개선하여 배기가스 배출을 낮추고 최적의 드라이빙을 선사합니다.
              </div>
              <p class="bullet-star">
                홈페이지의 사진과 설명은 참고용이며 실제 차량에 탑재되는 기능과 설명은 상이할수 있습니다.
              </p>
            </div>
            <div class="menu">
              <div class="price"><b>1,200,000</b> <span class="unit">원</span></div>
              <div class="right">
                <v-btn class="btn md white r" type="button">추가하기</v-btn>
              </div>
            </div>
        </div>
      </div>
    </template>
  </v-popup>
</template>

<script>
import { VPopup, VCarouselNew } from '~/components/element'
export default {
  components: {
    VPopup,
    VCarouselNew
  },
  props: {
    popVisible: {
      type: Object,
      defualt: {},
      required: true
    }
  },
  data() {
    return {
      basicListShow: -1,
      selectionListShow: -1,
      basicList: [
        {name: '파워트레인/성능', option: [
          { name: '카파개선 1.0 엔진', selected: true, },
          { name: '4단 자동변속기' },
          { name: '풋파킹 브레이크' }
        ]},
        {name: '안전', option: [
          { name: '카파개선 1.0 엔진', selected: true, },
          { name: '4단 자동변속기' },
          { name: '풋파킹 브레이크' }
        ]},
        {name: '외관', option: [
          { name: '카파개선 1.0 엔진', selected: true, },
          { name: '4단 자동변속기' },
          { name: '풋파킹 브레이크' }
        ]},
        {name: '시트', option: [
          { name: '카파개선 1.0 엔진', selected: true, },
          { name: '4단 자동변속기' },
          { name: '풋파킹 브레이크' }
        ]},
        {name: '편의', option: [
          { name: '카파개선 1.0 엔진', selected: true, },
          { name: '4단 자동변속기' },
          { name: '풋파킹 브레이크' }
        ]},
        {name: '멀티미디어', option: [
          { name: '카파개선 1.0 엔진', selected: true, },
          { name: '4단 자동변속기' },
          { name: '풋파킹 브레이크' }
        ]}
      ],
      selectionList: [
        {name: '옵션', option: [
          { name: '17인치 알로이휠&타이어', selected: true, price:'800,000'},
          { name: '4단 자동변속기', price:'200,000' },
          { name: '풋파킹 브레이크', price:'900,000' }
        ]},
        {name: '옵션2', option: [
          { name: '17인치 알로이휠&타이어', selected: true, price:'800,000'},
          { name: '4단 자동변속기', price:'200,000' },
          { name: '풋파킹 브레이크', price:'900,000' }
        ]}
      ],
      photoList: [
        {
          src: require('~/assets/images/temp/temp-car-option2.png'),
          alt: '구매후기사진'
        },
        {
          src: require('~/assets/images/temp/temp-car-option.png'),
          alt: '구매후기사진'
        },
        {
          src: require('~/assets/images/temp/temp-car-option2.png'),
          alt: '구매후기사진'
        }
      ],
    }
  },
  methods: {
    //하나만열리는 타입
    setActive(show, index){
      if(this[show] == index){
        this[show] = -1
      }else{
        this[show] = index
      }
    },
  }
}
</script>