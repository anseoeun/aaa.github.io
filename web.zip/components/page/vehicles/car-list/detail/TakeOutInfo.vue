<template>
  <div class="matching-box">
    <div class="box-wrap">
      <div class="box-tit">직접 인수 <br />방법 안내</div>
      <div class="box-desc">
        <div class="matching-list line-type">
          <ul>
            <li>
              <div class="tit"><b>직접 인수 방법</b></div>
              <div class="txt auto">
                <ul class="list">
                  <li>전시차량은 온라인 구매 후 전시지점에 직접 방문 인수하셔야 합니다.</li>
                  <li>차량 보관 장소에 전화로 사전 방문 예약 후 신분증을 지참하여 방문해 주세요.</li>
                </ul>
              </div>
            </li>
            <li>
              <div class="tit"><b>차량보관장소</b></div>
              <div class="txt auto">
                <ul class="cell-list">
                  <li>
                    <div class="cell-tit">지점명</div>
                    <div class="cell-txt">강남 논현 지점</div>
                  </li>
                  <li>
                    <div class="cell-tit">주소</div>
                    <div class="cell-txt">서울특별시 서초구 강남대로 565 1, 4층 현대자동차</div>
                  </li>
                  <li>
                    <div class="cell-tit">전화</div>
                    <div class="cell-txt">02-542-1114</div>
                  </li>
                  <li>
                    <div class="cell-tit">근무시간</div>
                    <div class="cell-txt">평일 09:00 ~ 22:00
                        <br />
                        <br />
                        <p class="bullet-star">방문예약(통화) 후 방문해주세요</p>
                    </div>
                  </li>
                </ul>
              </div>
            </li>
          </ul>
        </div>
      </div>
    </div>
    <!-- 지도 -->
    <div class="map-area">
      지도영역
    </div>
  </div>
</template>

<script>
export default {
  components: {},
  data() {
    return {}
  }
}
</script>
