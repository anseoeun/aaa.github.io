<template>
  <div class="matching-box">
    <div class="box-wrap">
      <!-- 2021.04.14(ver1.1) 상세설명으로텍스트수정 -->
      <div class="box-tit">상세설명</div>
      <div class="box-desc">
        <div class="matching-list line-type">
          <ul>
            <li>
              <div class="tit"><b>유의사항</b></div>
              <div class="txt auto">
                <div class="list-wrap">
                  <p>판촉차 구매전 확인해 주세요!</p>
                  <ul class="list">
                    <li>
                      1. 판촉차의 상태는 개인에 따라 다르게 느껴질 수있는 부분이므로 고객님께서 출고센터로
                      직접방문하셔서 차량의 상태 확인 후 인수하셔야 합니다.
                    </li>
                    <li>
                      2. 차량 상태가 고객님께서 생각하신 것과 다른 경우 차량 인수를 거부할 수 있으며, 인수 거부 시
                      고객센터(080-500-6000)으로 전화 주시면 취소 처리 해드리겠습니다.
                    </li>
                  </ul>
                </div>
              </div>
            </li>
            <li>
              <div class="tit"><b>할인사유</b></div>
              <div class="txt auto">등록환입 | 엔진,변속기,ECM 교환</div>
            </li>
            <li>
              <div class="tit"><b>주행거리</b></div>
              <div class="txt auto">500 km</div>
            </li>
            <li>
              <div class="tit"><b>차량상태</b></div>
              <div class="txt auto">
                <ul class="list">
                  <li>본네트 교환</li>
                  <li>앞펜더 : 우 교환</li>
                  <li>실내/시트 오염</li>
                </ul>
              </div>
            </li>
            <li>
              <div class="tit"><b>차량 실사진</b></div>
              <div class="txt auto">
                클릭시 원본 사이즈로 확인하실 수 있습니다.
                <div class="car-detail-img">
                  <div class="img">
                    <v-img :src="carImg.src" :alt="carImg.alt"></v-img>
                    <p class="no-img">이미지 준비 중 입니다.</p>
                  </div>
                  <v-pagination :total="100" />
                </div>
              </div>
            </li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import VPagination from '~/components/element/VPagination'
export default {
  components: {
    VPagination
  },
  data() {
    return {
      carImg: {
        src: require('~/assets/images/temp/temp-payment-car-model.png'),
        alt: 'AX 스마트스트림 가솔린 1.1 터보 프리미엄 밀레니얼 A/T'
      }
    }
  }
}
</script>
