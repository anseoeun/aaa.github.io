<template>
  <div class="similar-recommend-list recommend-car-list">
    <div class="slide-list">
     <p class="title">이런 차량은 어떠세요?</p>
      <v-carousel-new
        :data="slideList"
        :pagination="true"
        :navigation="true"
        :items-to-show="5"
        :items-to-slide="5"
        :touch-drag="false"
        :infinite-scroll="false"
      >
        <template slot-scope="props">
          <nuxt-link to="/" role="button">
            <v-img :src="props.item.carImg.src" :alt="props.item.carImg.alt"></v-img>
            <ul class="flag-list">
              <li>8월 생산 할인차</li>
            </ul>
            <!--
              삭제됨
              <strong class="name">{{ props.item.name }}</strong>
             -->
            <ul class="detail">
              <li class="fullname" v-html="props.item.fullName"></li>
              <li class="out-color">{{ props.item.outColor }}</li>
              <li class="in-color">{{ props.item.inColor }}</li>
              <li class="option">
                <span v-if="props.item.option.length <= 0">옵션없음</span>
                <span v-else>옵션 {{ props.item.option.length }}개
                  <v-popover trigger="hover" placement="bottom-center" width="170">
                    <p v-for="(opt, index) in props.item.option" :key="index" class="t-black">{{ opt }}</p>
                    <v-btn slot="reference"><i class="icon-opt-tog"></i></v-btn>
                  </v-popover>
                </span>
              </li>
            </ul>
            <ul class="price">
              <li class="total-price"><strong>{{ props.item.totalPirce }}</strong> 원</li>
            </ul>
          </nuxt-link>
        </template>
      </v-carousel-new>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      // 슬라이드
      slideList: [
        {
          carImg: {
            src: require('~/assets/images/temp/temp-payment-car-model.png'),
            alt: '베뉴 자가용 LPG 1.6<br />Modern A/T',
          },
          name: '베뉴',
          fullName: '베뉴 자가용 LPG 1.6<br />Modern A/T',
          outColor: '미드나잇블랙',
          inColor: '블랙모노톤(블랙시트)',
          optionType: '동일옵션',
          option: [
            '옵션명 옵션명 옵션명',
            '옵션명 옵션명 옵션명',
            '옵션명 옵션명 옵션명',
            '옵션명 옵션명',
          ],
          optionClass: '',
          totalPirce: '23,220,000',
        },
        {
          carImg: {
            src: require('~/assets/images/temp/temp-payment-car-model.png'),
            alt: '베뉴 자가용 LPG 1.6<br />Modern A/T',
          },
          name: '그랜저',
          fullName: '그랜저 자가용 LPG 1.6<br />Modern A/T',
          outColor: '미드나잇블랙',
          inColor: '블랙모노톤(블랙시트)',
          optionType: '추가옵션',
          option: [
            '옵션명 옵션명 옵션명',
            '옵션명 옵션명 옵션명',
            '옵션명 옵션명 옵션명',
            '옵션명 옵션명',
          ],
          optionClass: '',
          totalPirce: '23,220,000',
        },
        {
          carImg: {
            src: require('~/assets/images/temp/temp-payment-car-model.png'),
            alt: '베뉴 자가용 LPG 1.6<br />Modern A/T',
          },
          name: '그랜저',
          fullName: '그랜저 자가용 LPG 1.6<br />Modern A/T',
          outColor: '미드나잇블랙',
          inColor: '블랙모노톤(블랙시트)',
          optionType: '제외옵션',
          option: [
            '옵션명 옵션명 옵션명',
            '옵션명 옵션명 옵션명',
            '옵션명 옵션명 옵션명',
            '옵션명 옵션명',
          ],
          optionClass: 'cancle',
          totalPirce: '23,220,000',
        },
        {
          carImg: {
            src: require('~/assets/images/temp/temp-payment-car-model.png'),
            alt: '베뉴 자가용 LPG 1.6<br />Modern A/T',
          },
          name: '베뉴',
          fullName: '베뉴 자가용 LPG 1.6<br />Modern A/T',
          outColor: '미드나잇블랙',
          inColor: '블랙모노톤(블랙시트)',
          optionType: '동일옵션',
          option: [],
          optionClass: '',
          totalPirce: '23,220,000',
        },
        {
          carImg: {
            src: require('~/assets/images/temp/temp-payment-car-model.png'),
            alt: '베뉴 자가용 LPG 1.6<br />Modern A/T',
          },
          name: '그랜저',
          fullName: '그랜저 자가용 LPG 1.6<br />Modern A/T',
          outColor: '미드나잇블랙',
          inColor: '블랙모노톤(블랙시트)',
          optionType: '추가옵션',
          option: [
            '옵션명 옵션명 옵션명',
            '옵션명 옵션명 옵션명',
            '옵션명 옵션명',
          ],
          optionClass: '',
          totalPirce: '23,220,000',
        },
        {
          carImg: {
            src: require('~/assets/images/temp/temp-payment-car-model.png'),
            alt: '베뉴 자가용 LPG 1.6<br />Modern A/T',
          },
          name: '그랜저',
          fullName: '그랜저 자가용 LPG 1.6<br />Modern A/T',
          outColor: '미드나잇블랙',
          inColor: '블랙모노톤(블랙시트)',
          optionType: '제외옵션',
          option: [
            '옵션명 옵션명 옵션명',
            '옵션명 옵션명 옵션명',
            '옵션명 옵션명 옵션명',
            '옵션명 옵션명',
          ],
          optionClass: 'cancle',
          totalPirce: '23,220,000',
        },
        {
          carImg: {
            src: require('~/assets/images/temp/temp-payment-car-model.png'),
            alt: '베뉴 자가용 LPG 1.6<br />Modern A/T',
          },
          name: '베뉴',
          fullName: '베뉴 자가용 LPG 1.6<br />Modern A/T',
          outColor: '미드나잇블랙',
          inColor: '블랙모노톤(블랙시트)',
          optionType: '동일옵션',
          option: [ ],
          optionClass: '',
          totalPirce: '23,220,000',
        },
        {
          carImg: {
            src: require('~/assets/images/temp/temp-payment-car-model.png'),
            alt: '베뉴 자가용 LPG 1.6<br />Modern A/T',
          },
          name: '그랜저',
          fullName: '그랜저 자가용 LPG 1.6<br />Modern A/T',
          outColor: '미드나잇블랙',
          inColor: '블랙모노톤(블랙시트)',
          optionType: '추가옵션',
          option: [
            '옵션명 옵션명 옵션명',
            '옵션명 옵션명 옵션명',
            '옵션명 옵션명 옵션명',
            '옵션명 옵션명',
          ],
          optionClass: '',
          totalPirce: '23,220,000',
        },
        {
          carImg: {
            src: require('~/assets/images/temp/temp-payment-car-model.png'),
            alt: '베뉴 자가용 LPG 1.6<br />Modern A/T',
          },
          name: '그랜저',
          fullName: '그랜저 자가용 LPG 1.6<br />Modern A/T',
          outColor: '미드나잇블랙',
          inColor: '블랙모노톤(블랙시트)',
          optionType: '제외옵션',
          option: [
            '옵션명 옵션명 옵션명',
            '옵션명 옵션명 옵션명',
            '옵션명 옵션명 옵션명',
            '옵션명 옵션명',
          ],
          optionClass: 'cancle',
          totalPirce: '23,220,000',
        },
      ],
    }
  },
}
</script>
