<template>
  <div class="matching-box">
    <div class="box-wrap">
      <div class="box-tit">상세 스펙</div>
      <div class="box-desc">
        <div class="info-grid-list">
          <ul>
            <li>
              <strong class="info-title">모델</strong>
              <div class="info-group">
                <p>AX 스마트스트림 가솔린 1.1 터보 프리미엄 밀레니얼 A/T</p>
                <span class="price">33,000,000 원</span>
              </div>
            </li>
            <li>
              <strong class="info-title">
                외장 색상 <br />
                내장 색상
              </strong>
              <div class="info-group">
                <ul class="color-list">
                  <li>
                    <div class="color">
                      <div class="color-sample" :style="`background-image:url(${outColor.src})`"></div>
                      <div class="color-txt">{{ outColor.txt }}</div>
                      <span class="price">0 원</span>
                    </div>
                  </li>
                  <li>
                    <div class="color">
                      <div class="color-sample" :style="`background-image:url(${inColor.src})`"></div>
                      <div class="color-txt">{{ inColor.txt }}</div>
                      <span class="price">0 원</span>
                    </div>
                  </li>
                </ul>
              </div>
            </li>
            <li>
              <strong class="info-title">옵션</strong>
              <div class="info-group">
                <ul class="desc-list">
                  <li v-for="(option, index) in optionData" :key="index">
                    <em>{{ option.name }}</em>
                    <span class="price">{{ option.price }} 원</span>
                  </li>
                </ul>
              </div>
            </li>
            <li>
              <strong class="info-title"
                ><v-img :src="require('~/assets/images/temp/logo-hgenuine.png')"></v-img
              ></strong>
              <div class="info-group">
                <ul class="desc-list">
                  <li v-for="(discountRate, index) in etcOptData" :key="index">
                    <em>{{ discountRate.discountName }}</em>
                    <span class="price">{{ discountRate.discountPrice }} 원</span>
                  </li>
                </ul>
              </div>
            </li>
            <li>
              <strong class="info-title"
                ><v-img :src="require('~/assets/images/temp/logo-performance.png')"></v-img
              ></strong>
              <div class="info-group">
                s
                <ul class="desc-list">
                  <li v-for="(discountRate, index) in etcOptData" :key="index">
                    <em>{{ discountRate.discountName }}</em>
                    <span class="price">{{ discountRate.discountPrice }} 원</span>
                  </li>
                </ul>
              </div>
            </li>
          </ul>
          <ul>
            <li>
              <strong class="info-title">성능</strong>
              <div class="info-group">
                <ul class="car-opt-list">
                  <li v-for="(item, index) in performanceList" :key="index">
                    <b>{{ item.tit }}</b>
                    <div>{{ item.value }}</div>
                  </li>
                </ul>
              </div>
            </li>
            <li>
              <strong class="info-title">연비</strong>
              <div class="info-group">
                <ul class="car-opt-list">
                  <li v-for="(item, index) in efficiencyList" :key="index">
                    <b>{{ item.tit }}</b>
                    <div>{{ item.value }}</div>
                  </li>
                </ul>
              </div>
            </li>
            <li>
              <strong class="info-title">제원</strong>
              <div class="info-group">
                <ul class="car-opt-list">
                  <li v-for="(item, index) in specificationList" :key="index">
                    <b>{{ item.tit }}</b>
                    <div>{{ item.value }}</div>
                  </li>
                </ul>
              </div>
            </li>
            <li>
              <strong class="info-title">기본 포함 품목</strong>
              <div class="info-group">
                <ul class="car-opt-list sm-mg">
                  <li v-for="(item, index) in baseList" :key="index">
                    <div>{{ item }}</div>
                  </li>
                </ul>
              </div>
            </li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  components: {},
  data() {
    return {
      inColor: {txt:'메테오 블루', src: require('~/assets/images/temp/temp-color-4.png')},
      outColor: {txt:'쉬머링 실버', src: require('~/assets/images/temp/temp-color-1.png')},
      optList: [
        { opt: '현대스마트센스' },
        { opt: '펫 패키지Ⅰ(강아지얼굴,소형)-모노민트' },
        { opt: '펫 패키지Ⅲ(소형)-모노옐로우' },
        { opt: '[N퍼포먼스 파츠] 인테리어 패키지' }
      ],
      optionData: [
        { name: '현대스마트센스', price: '1,000,000' },
        { name: '펫 패키지Ⅰ(강아지얼굴,소형)-모노', price: '100,000' },
        { name: '펫 패키지Ⅲ(소형)-모노옐로우', price: '100,000' },
        { name: '펫 패키지Ⅲ(소형)-모노옐로우', price: '100,000' }
      ],
      etcOptData: [
        { discountName: '7단 DCT', discountPrice: '100,000' },
        { discountName: '2WD 험로주행모드(머드/샌드/스노', discountPrice: '100,000' },
        { discountName: 'ISG 시스템', discountPrice: '100,000' },
        { discountName: '통합 주행모드', discountPrice: '100,000' },
        { discountName: '전/후륜 디스크 브레이크', discountPrice: '100,000' },
        { discountName: '스마트스트림 가솔린 1.6 터보 엔진', discountPrice: '100,000' },
        { discountName: '전방 충돌방지 보조 외 4개', discountPrice: '100,000' },
        { discountName: '6 에어백 시스템(앞좌석 어드밴스드', discountPrice: '100,000' }
      ],
      performanceList: [
        { tit: '엔진', value: '4,650 mm' },
        { tit: '엔진', value: '4,650 mm' },
        { tit: '엔진', value: '4,650 mm' },
        { tit: '엔진', value: '4,650 mm' },
        { tit: '엔진', value: '4,650 mm' },
        { tit: '엔진', value: '4,650 mm' },
        { tit: '엔진', value: '4,650 mm' },
        { tit: '엔진', value: '4,650 mm' }
      ],
      efficiencyList: [
        { tit: '연비등급', value: '4,650 mm' },
        { tit: '연비등급', value: '4,650 mm' },
        { tit: '연비등급', value: '4,650 mm' },
        { tit: '연비등급', value: '4,650 mm' },
        { tit: '연비등급', value: '4,650 mm' }
      ],
      specificationList: [
        { tit: '전장', value: '4,650 mm' },
        { tit: '전장', value: '4,650 mm' },
        { tit: '전장', value: '4,650 mm' },
        { tit: '전장', value: '4,650 mm' },
        { tit: '전장', value: '4,650 mm' },
        { tit: '전장', value: '4,650 mm' }
      ],
      baseList: ['기본 포함 품목', '기본 포함 품목', '기본 포함 품목', '기본 포함 품목', '기본 포함 품목']
    }
  }
}
</script>
