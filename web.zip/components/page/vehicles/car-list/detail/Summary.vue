<template>
  <section class="purchase-tool">
    <ul class="flag-list">
      <li v-for="(flag, index) in flagData" :key="index">{{ flag.flagName }}</li>
    </ul>
    <h1>AX 스마트스트림 가솔린 1.1 터보 프리미엄 밀레니얼 A/T</h1>

    <div class="info-grid-list">
      <ul class="left-type">
        <li>
          <strong class="info-title">외장색상</strong>
          <div class="info-group">
            <span class="text">폴라화이트</span>
          </div>
        </li>
        <li>
          <strong class="info-title">내장색상</strong>
          <div class="info-group">
            <span class="text">베이지</span>
          </div>
        </li>
        <li>
          <strong class="info-title">옵션</strong>
          <div class="info-group">
            <span class="text">
              선루프, 컴포트패키지, 내비게이션, 휠 패키지 에시드 옐로우 휠캡
            </span>
          </div>
        </li>
        <li>
          <strong class="info-title">출고센터</strong>
          <div class="info-group">
            <span class="text">
              울산출고센터
            </span>
          </div>
        </li>
        <li>
          <strong class="info-title">주행거리</strong>
          <div class="info-group">
            <span class="text">500km</span>
          </div>
        </li>
        <li>
          <strong class="info-title">생산일</strong>
          <div class="info-group">
            <span class="text">2021.08.01</span>
          </div>
        </li>
        <li>
          <strong class="info-title">주행거리</strong>
          <div class="info-group">
            <span class="text">
              <ul class="list">
                <li>울산출고센터</li>
                <li>역삼지점
                  <v-btn class="btn-more" @click="$emit('viewMap')">지도보기</v-btn>
                </li>
              </ul>
            </span>
          </div>
        </li>
      </ul>
      <ul class="noti-text">
        <li>※ 판촉차 상세 설명을 꼭 확인해 주세요</li>
        <li>※ 전시지점을 확인해 주세요(직접인수)</li>
      </ul>
      <ul>
        <li>
          <strong class="info-title">차량금액</strong>
          <div class="info-group">
            <span class="price">33,300,000 원</span>
          </div>
        </li>
        <li>
          <div class="info-title full">
            <strong>할인금액</strong>
            <v-btn
              class="btn btn-detail"
              type="icon"
              :icon-class="['icon-open-arrow', { active: isOptionsShow }]"
              @click="isOptionsShow = !isOptionsShow"
              ><span class="offscreen">상세보기</span></v-btn
            >
            <span class="price t-blue">(-) 1,000,000 원</span>
          </div>
          <div class="info-group full">
            <ul v-show="isOptionsShow" class="desc-list">
              <li v-for="(point, index) in pointData" :key="index">
                <em>{{ point.pointName }}</em>
                <span class="price">(-) {{ point.pointPrice }} 원</span>
              </li>
            </ul>
          </div>
        </li>
        <li>
          <strong class="info-title">판매금액</strong>
          <div class="info-group">
            <span class="price total"><b>33,300,000</b> 원</span>
          </div>
        </li>
        <li>
          <strong class="info-title">탁송료
             <span class="t-gray">서울시 기준</span>
             <v-btn class="btn-more" @click="deliverySelectPop = true">변경</v-btn>
          </strong>
          <div class="info-group">
            <span class="price">270,000 원</span>
            <v-popover trigger="hover" placement="bottom-end">
              <p>탁송료는 차량이 생산된공장에서 차량이 위치한 출고센터까지의 탁송료와 차량이위치했던 출고센터에서의 고객님이 요청하신 지역까지의 탁송료가 부과됩니다.</p>
              <v-btn slot="reference"><i class="icon-help"></i></v-btn>
            </v-popover>
          </div>
        </li>
      </ul>
      <div class="etc-text t-right">
        직접인수
        <v-popover trigger="hover" placement="bottom-end">
          <p>전시차량은 온라인 구매 후 전시 지점에 직접 방문 인수하셔야 합니다.</p>
          <v-btn slot="reference"><i class="icon-help"></i></v-btn>
        </v-popover>
      </div>
    </div>
    <div class="btn-wrap">
      <v-btn class="btn md blue r">견적내기</v-btn>
    </div>
    <delivery-select :visible="deliverySelectPop" @close="deliverySelectPop = false" />
  </section>
</template>

<script>
import DeliverySelect from '~/components/page/vehicles/popup/DeliverySelect'
export default {
  components: {
    DeliverySelect
  },
  data() {
    return {
      deliverySelectPop: false,
      isOptionsShow: false,
      isDetailShow: false,
      flagData: [{ flagName: '판촉차' }],
      pointData: [
        { pointName: '기본할인', pointPrice: '1,000,000' },
        { pointName: '기획전할인', pointPrice: '300,000' }
      ]
    }
  }
}
</script>
