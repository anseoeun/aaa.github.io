<template>
  <div class="vehicles-list">
    <ul>
      <li v-for="(vehicles, index) in vehiclesData" :key="index">
        <nuxt-link to="/" role="button">
          <div class="vehicles-img"><v-img :src="vehicles.carImg.src" :alt="vehicles.carImg.alt"></v-img></div>
          <ul class="flag-list">
            <li v-for="(flag, idx) in vehicles.flagData" :key="idx">{{ flag.title }}</li>
          </ul>
          <div class="detail">
            <div class="vehicles-name">
              <strong class="name">{{ vehicles.name }}</strong>
              <div class="fullname">
                <span>{{ vehicles.engine }}</span>
                <strong>{{ vehicles.title }}</strong>
              </div>
            </div>
            <ul class="option-box">
              <li class="out-color">{{ vehicles.outColor }}</li>
              <li class="in-color">{{ vehicles.inColor }}</li>
              <li v-if="vehicles.option" class="option">
                <span>옵션 {{ vehicles.optionNum }}</span>
                <div class="option-list">
                  <i class="icon-plus"></i>
                  <div class="cont">
                    <p v-for="(optionType, idex) in vehicles.optionList" :key="idex">{{ optionType.optionName }}</p>
                  </div>
                </div>
              </li>
              <li v-else class="option">옵션없음</li>
            </ul>
          </div>
          <!-- 2021.03.29 (ver1.1) sold-out 추가 -->
          <div v-if="vehicles.soldout" class="sold-out">SOLD OUT</div>

          <!-- 2021.03.29 (ver1.1) v-else 추가 -->
          <ul v-else class="price-info">
            <li v-if="isNan(vehicles.price)" class="price">
              <span class="text">차량금액</span> {{ vehicles.price }} 원
            </li>
            <li v-if="isNan(vehicles.discount)" class="discount">
              <span>할인 {{ vehicles.discount }} 원</span>
            </li>
            <li class="total-price">
              <strong>{{ vehicles.totalPirce }}</strong> 원
            </li>
          </ul>

          <!-- 2021.03.29 (ver1.1) v-if 추가 -->
          <ul v-if="!vehicles.soldout" class="take-over">
            <li>{{ vehicles.takeOverPlace }}</li>
            <li v-if="vehicles.takeOverType" class="price">탁송료 {{ vehicles.takeOverPrice }} 원</li>
            <li v-else class="last">
              직접인수
              <v-popover trigger="hover" placement="bottom-start">
                <p>전시차량은 온라인 구매 후 전시지점에<br />직접 방문 인수하셔야 합니다.</p>
                <v-btn slot="reference"><i class="icon-help"></i></v-btn>
              </v-popover>
            </li>
          </ul>
        </nuxt-link>
      </li>
    </ul>
  </div>
</template>

<script>
export default {
  data() {
    return {
      isOptionsShow: false,
      vehiclesData: [
        {
          carImg: {
            src: require('~/assets/images/temp/temp-payment-car-model.png'),
            alt: '베뉴 가솔린 1.6 FLUX 2WD IVT'
          },
          flagData: [{ title: '8월 생산 할인차' }, { title: '장애인' }],
          name: '베뉴',
          engine: '가솔린 1.6 FLUX 2WD IVT',
          title: 'FLUX',
          outColor: '미드나잇블랙',
          inColor: '블랙모노톤(블랙시트)',
          option: false,
          // 2021.03.29 (ver1.1) sold-out 추가
          soldout: false,
          price: '33,000,000',
          discount: '1,000,000',
          totalPirce: '32,000,000',
          takeOverPlace: '울산출고센터',
          takeOverType: true,
          takeOverPrice: '134,000'
        },
        {
          carImg: {
            src: require('~/assets/images/temp/temp-precontact-car-visual2.png'),
            alt: '그랜드 스타렉스 Smart 자가용 웨건 12인승'
          },
          flagData: [],
          name: '그랜드 스타렉스 Smart',
          engine: '그랜드 스타렉스 Smart 자가용 웨건 12인승',
          title: 'LPi 오토 Smart',
          outColor: '미드나잇블랙',
          inColor: '블랙모노톤(블랙시트)',
          option: true,
          optionNum: '2개',
          optionList: [
            { optionName: '옵션명옵션명이 길경우 길게 길게' },
            { optionName: '옵션명명이 들어갑니다 1줄초과시 말줄임' }
          ],
          // 2021.03.29 (ver1.1) sold-out 추가
          soldout: true
          // price: '33,000,000',
          // discount: '1,000,000',
          // totalPirce: '32,000,000',
          // takeOverPlace: '서초지점',
          // takeOverType: false,
        },
        {
          carImg: {
            src: require('~/assets/images/temp/temp-precontact-car-visual2.png'),
            alt: '아반떼 Hybrid 자가용 하이브리드'
          },
          flagData: [{ title: '전시차' }, { title: '렌터카' }],
          name: '아반떼',
          engine: 'Hybrid 자가용 하이브리드',
          title: 'Inspiration DCT Inspiration DCT ',
          outColor: '미드나잇블랙',
          inColor: '블랙모노톤(블랙시트)',
          option: true,
          optionNum: '1개',
          optionList: [{ optionName: '옵션명' }],
          // 2021.03.29 (ver1.1) sold-out 추가
          soldout: false,
          totalPirce: '12,000,000',
          takeOverPlace: '서초지점',
          takeOverType: true,
          takeOverPrice: '134,000'
        },
        {
          carImg: {
            src: require('~/assets/images/temp/temp-payment-car-model.png'),
            alt: '베뉴 가솔린 1.6 FLUX 2WD IVT'
          },
          flagData: [{ title: '8월 생산 할인차' }, { title: '장애인' }],
          name: '베뉴',
          engine: '가솔린 1.6 FLUX 2WD IVT',
          title: 'FLUX',
          outColor: '미드나잇블랙',
          inColor: '블랙모노톤(블랙시트)',
          option: false,
          // 2021.03.29 (ver1.1) sold-out 추가
          soldout: false,
          price: '33,000,000',
          discount: '1,000,000',
          totalPirce: '32,000,000',
          takeOverPlace: '울산출고센터',
          takeOverType: true,
          takeOverPrice: '134,000'
        },
        {
          carImg: {
            src: require('~/assets/images/temp/temp-precontact-car-visual2.png'),
            alt: '베뉴 자가용 LPG 1.6<br />Modern A/T'
          },
          flagData: [],
          name: '그랜드 스타렉스 Smart',
          engine: '자가용 웨건 12인승',
          title: 'LPi 오토 Smart',
          outColor: '미드나잇블랙',
          inColor: '블랙모노톤(블랙시트)',
          option: true,
          optionNum: '5개',
          optionList: [
            { optionName: '옵션명옵션명이 길경우 길게 길게' },
            { optionName: '옵션명명이 들어갑니다 1줄초과시 말줄임' },
            { optionName: '옵션명3' },
            { optionName: '옵션명4' },
            { optionName: '옵션명5' }
          ],
          // 2021.03.29 (ver1.1) sold-out 추가
          soldout: false,
          price: '33,000,000',
          discount: '1,000,000',
          totalPirce: '32,000,000',
          takeOverPlace: '서초지점',
          takeOverType: false
        },
        {
          carImg: {
            src: require('~/assets/images/temp/temp-precontact-car-visual.png'),
            alt: '베뉴 자가용 LPG 1.6<br />Modern A/T'
          },
          flagData: [{ title: '판촉차' }],
          name: '그랜드 스타렉스 Smart',
          engine: '자가용 웨건 12인승',
          title: 'LPi 오토 Smart',
          outColor: '미드나잇블랙',
          inColor: '블랙모노톤(블랙시트)',
          option: false,
          // 2021.03.29 (ver1.1) sold-out 추가
          soldout: false,
          totalPirce: '12,000,000',
          takeOverPlace: '제주연북로지점',
          takeOverType: false
        },
        {
          carImg: {
            src: require('~/assets/images/temp/temp-precontact-car-visual2.png'),
            alt: '베뉴 자가용 LPG 1.6<br />Modern A/T'
          },
          flagData: [{ title: '전시차' }, { title: '렌터카' }],
          name: '아반떼',
          engine: 'Hybrid 자가용 하이브리드',
          title: 'Inspiration DCT',
          outColor: '미드나잇블랙',
          inColor: '블랙모노톤(블랙시트)',
          option: true,
          optionNum: '1개',
          optionList: [{ optionName: '옵션명' }],
          // 2021.03.29 (ver1.1) sold-out 추가
          soldout: false,
          totalPirce: '12,000,000',
          takeOverPlace: '서초지점',
          takeOverType: true,
          takeOverPrice: '134,000'
        },
        {
          carImg: {
            src: require('~/assets/images/temp/temp-precontact-car-visual.png'),
            alt: '베뉴 자가용 LPG 1.6<br />Modern A/T'
          },
          flagData: [{ title: '판촉차' }],
          name: '그랜드 스타렉스 Smart',
          engine: '자가용 웨건 12인승',
          title: 'LPi 오토 Smart',
          outColor: '미드나잇블랙',
          inColor: '블랙모노톤(블랙시트)',
          option: false,
          // 2021.03.29 (ver1.1) sold-out 추가
          soldout: false,
          totalPirce: '12,000,000',
          takeOverPlace: '제주연북로지점',
          takeOverType: true,
          takeOverPrice: '134,000'
        }
      ]
    }
  },
  methods: {
    isNan(val) {
      return val != undefined && val != null && val != '' ? true : false
    }
  }
}
</script>
