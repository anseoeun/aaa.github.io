<template>
  <section class="information-detail" :class="{ open: isOptionsShow }">
    <div class="summary-info" :class="{ active: isOptionsShow }">
      <h1 class="title">기본품목 <v-btn type="icon" icon-class="icon-info" @click="popVisible = true"></v-btn></h1>
      <v-btn
        class="btn-detail"
        type="icon"
        :icon-class="['icon-open', { active: isOptionsShow }]"
        @click="isOptionsShow = !isOptionsShow"
        ><span class="offscreen">상세보기</span></v-btn
      >
    </div>
    <div v-show="isOptionsShow" class="detail-info">
      <div class="comparison-wrap v-type">
          <div v-for="(item, index) in dataListLabel" :key="index" class="item-box">
            <strong class="title">{{ item }}</strong>
            <ul class="item-list">
               <template v-for="idx in 4">
                <li v-if="idx <= dataList.length" :key="idx">
                  <template v-if="typeof dataList[idx - 1][Object.keys(dataList[idx - 1])[index]] === 'string'">
                    {{ dataList[idx - 1][Object.keys(dataList[idx - 1])[index]] }}
                  </template>
                  <template v-else>
                     <div class="full-box normal-list">
                      <ul>
                        <li v-for="(list, i) in dataList[idx - 1][Object.keys(dataList[idx - 1])[index]]" :key="i">{{ list }}</li>
                      </ul>
                    </div>
                  </template>
                </li>
                <li v-else :key="idx"></li>
              </template>
            </ul>
          </div>
      </div>
      <div class="newcar-safety-evaluation">
        <div class="img"><v-img :src="require('~/assets/images/mycar/img-kncap.png')"></v-img></div>
        <div class="desc">
          <p class="title">신차 안전도 평가</p>
          <p class="text">
            국토 교통부는 매년 국내에 많이 판매되는 국산차 및 외산차 10개 차종을 대상으로 안전도 평가를 실시 합니다. 자동차 충돌시험 등을 통해 차의 안전성을 평가하여, 소비자에게 결과를 제공하고 제작사로 하여금 보다 안전한 자동차를 제작하도록 유도하기 위해 1999년 부터 시행해 왔습니다. 최근의 자동차 안전도 평가는 충돌 안전, 보행자 안전, 사고예방 안전등 3개 분야로 나누어 각 차종의 안전도를 평가합니다.
          </p>
          <div class="link"><v-btn type="link" href="http://www.kncap.org/" target="_blank">www.kncap.org</v-btn></div>
        </div>
      </div>
    </div>

    <!-- 팝업 : 기본품목 안내 -->
    <default-option-info :visible="popVisible" @close="popVisible = false"></default-option-info>
  </section>
</template>

<script>
import DefaultOptionInfo from '~/components/page/vehicles/comparison/popup/DefaultOptionInfo'
export default {
  components: {
    DefaultOptionInfo
  },
  data() {
    return {
      isOptionsShow: false,
      popVisible: false,
      dataListLabel: ['파워트레인', '외관', '내장', '안전', '편의', '멀티미디어' ],
      dataList: [
        {
          powerTrain: [
            '전/후륜 디스크 브레이크(전륜 벤틸레이티드)',
            'Ce 260(터보 직분사 가솔린)엔진',
            '랙 구동형 전자식 파워스티어링(R-EPS)',
          ],
          exterior: [
            '16인치 알로이 휠 & 타이어',
            '아웃사이드 미러(열선, 전동 조절, LED 방향지시등)'
          ],
          inside: '4.2인치 컬러 LCD 클러스터',
          safety: '전방 차량 출발 알림',
          convenience: '폴딩타입 도어 리모컨키',
          multimedia: '일반 오디오 시스템',
        },
        {
          powerTrain: [
            '전/후륜 디스크 브레이크(전륜 벤틸레이티드)',
            'Ce 260(터보 직분사 가솔린)엔진',
            '랙 구동형 전자식 파워스티어링(R-EPS)',
          ],
          exterior: [
            '16인치 알로이 휠 & 타이어',
            '아웃사이드 미러(열선, 전동 조절, LED 방향지시등)'
          ],
          inside: '4.2인치 컬러 LCD 클러스터',
          safety: '전방 차량 출발 알림',
          convenience: '폴딩타입 도어 리모컨키',
          multimedia: '일반 오디오 시스템',
        },
        {
          powerTrain: [
            '전/후륜 디스크 브레이크(전륜 벤틸레이티드)',
            'Ce 260(터보 직분사 가솔린)엔진',
            '랙 구동형 전자식 파워스티어링(R-EPS)',
          ],
          exterior: [
            '16인치 알로이 휠 & 타이어',
            '아웃사이드 미러(열선, 전동 조절, LED 방향지시등)'
          ],
          inside: '4.2인치 컬러 LCD 클러스터',
          safety: '전방 차량 출발 알림',
          convenience: '폴딩타입 도어 리모컨키',
          multimedia: '일반 오디오 시스템',
        }
      ]
    }
  },
  methods: {}
}
</script>
