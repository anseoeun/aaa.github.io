<template>
  <v-popup
    :visible="visible"
    :footer="['close']"
    :width="'550px'"
    @close="
      $emit('close')
      popVisible = false
    "
    @confirm="
      $emit('close')
      popVisible = false
    "
  >
    <template slot="header">
      <div class="title">보험료 산출 안내</div>
    </template>
    <template slot="body">
      <ul class="body-contents">
        <li class="bullet">(유의사항)보험료 산출은 가입자의 운전경력 및 손해율 그리고 가입시기, 가입하실 보험사에 따라 달라질 수 있음을 알려드립니다.</li>
        <li class="bullet">각 모델의 차량가격으로 보험료를 산출하지만, 업데이트 시점에 따라 가격이 정확하지 않을 수 있습니다.</li>
        <li class="bullet">보험료 산출은 다음과 같은 조건에서 산출하였습니다.</li>
      </ul>
    </template>
  </v-popup>
</template>

<script>
import { VPopup } from '~/components/element'
export default {
  components: {
    VPopup
  },
  props: {
    visible: {
      type: Boolean,
      default: false
    }
  },
}
</script>