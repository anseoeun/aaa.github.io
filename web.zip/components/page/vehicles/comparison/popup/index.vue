<template>
  <div class="">
    <!-- 색상에따른트림변경안내  -->
    <compare-select :pop-visible="visible" />
  </div>
</template>

<script>
import CompareSelect from '~/components/page/vehicles/comparison/popup/CompareSelect'

export default {
  components: {
    CompareSelect,
  },
  props: {
    visible: {
      type: Object,
      defualt: {},
      required: true
    }
  },
  data() {
    return {}
  },
  methods: {
    parentsSync(e) {
      this.visible = e
      this.$emit('visibleSync', this.visible)
    }
  }
}
</script>
