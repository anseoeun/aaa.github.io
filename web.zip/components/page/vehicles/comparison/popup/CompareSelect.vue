<template>
  <v-popup
    :width="'1200px'"
    :visible="popVisible.compareSelect"
    class="trim-compare"
    @close="popVisible.compareSelect = false"
  >
    <template slot="body">
      <!-- trim-option -->
      <div ref="wrapper" class="trim-option" :class="{fix:wrapperFixed}" @scroll="scroll">
        <!-- option-header -->
        <div class="option-header">
          <div ref="fixHeader" class="option-box">
            <div class="title">
              <b>트림 구분</b>
              <p class="txt">
                스크롤 하시면 트림별 특징을 <br />
                비교하며 보실 수 있습니다.
              </p>
            </div>
            <div class="desc">
              <ul>
                <li v-for="(item, index) in dataLabel" :key="index">
                  <b class="tit">{{ item.name }}</b>
                  <p class="price"><b>{{ item. price }}</b><span class="unit">원</span></p>
                  <div class="btn-wrap">
                    <v-btn class="btn md blue r" type="button">선택 적용하기</v-btn>
                  </div>
                </li>
              </ul>
            </div>
          </div>
        </div>
        <!-- // option-header -->
        <!-- option-body -->
        <div class="option-body">
          <div v-for="(label, index) in dataOptListLabel" :key="index" class="option-box">
            <div class="title">
              <b>{{ label }}</b>
            </div>
            <div class="desc">
              <ul>
                <li v-for="(item, idx) in dataOptList" :key="idx">
                  <div v-for="(opt, i) in item[Object.keys(dataOptList[idx])[index]]" :key="i" class="box">
                    <b class="tit">{{ opt.tit }}</b>
                    <p v-if="opt.name !== ''" class="name">{{ opt.name }}</p>
                    <p class="sub">
                      <i v-if="opt.noOpt" class="icon"></i>
                      <span v-if="opt.sub !== ''" class="sub-txt">({{ opt.sub }})</span>
                    </p>
                  </div>
                </li>
              </ul>
            </div>
          </div>
        </div>
        <!-- // option-body -->
      </div>
      <!-- // trim-option -->
    </template>
  </v-popup>
</template>

<script>
// import { VBtn } from '~/components/element'
export default {
  components: {
    // VBtn,
  },

  props: {
    popVisible: {
      type: Object,
      defualt: {},
      required: true
    }
  },
  data() {
    return {
      dataLabel :[
        {
          name: '스마트',
          price: '12,890,000',
        },
        {
          name: '모던',
          price: '13,700,000',
        },
        {
          name: '인스퍼레이션',
          price: '15,200,000',
        },
      ],
      dataOptListLabel: ['파워트레인', '안전','외관', '시트', '편의', '멀티미디어' ],
      dataOptList: [
        {
          powrerTrain: [
            {tit:'엔진', name:'카파개선 1.0 엔진', sub:'카파개선 1.0 터보 엔진 선택가능'}
          ],
          safty: [
            {tit:'현대 스마트센스', name:'', sub:'', noOpt: true},
            {tit:'에어백', name:'6에어백', sub:''}
          ],
          exterior: [
            {tit:'휠&타이어', name:'15인치 스타일드 스틸휠', sub:''},
          ],
          seat: [
            {tit:'시트', name:'직물시트', sub:''},
            {tit:'열선시트', name:'', sub:'', noOpt: true},
            {tit:'통풍시트', name:'', sub:'', noOpt: true},
            {tit:'폴딩시트', name:'뒷좌석 5:5 분할 폴딩 시트', sub:''},
          ],
          convenience: [
            {tit:'헤드램프', name:'', sub:'프로젝션 헤드램프 선택가능', noOpt: true},
            {tit:'하이패스', name:'', sub:'', noOpt: true},
            {tit:'에어컨', name:'매뉴얼 에어컨', sub:''},
            {tit:'버튼시동 & 스마트키', name:'', sub:'시스템 선택가능', noOpt: true},
            {tit:'선루프', name:'', sub:'선택가능'},
          ],
          multimedia: [
            {tit:'내비게이션', name:'', sub:'8인치 와이드 내비게이션 선택가능', noOpt: true},
            {tit:'후방카메라', name:'', sub:'후방카메라 선택가능', noOpt: true},
          ],
        },
        {
          powrerTrain: [
            {tit:'엔진', name:'카파개선 1.0 엔진', sub:'카파개선 1.0 터보 엔진 선택가능'}
          ],
          safty: [
            {tit:'현대 스마트센스', name:'', sub:'현대 스마트센스I 선택가능', noOpt: true},
            {tit:'에어백', name:'6에어백', sub:''}
          ],
          exterior: [
            {tit:'휠&타이어', name:'15인치 스타일드 스틸휠', sub:'17인치 알로이휠 선택가능'},
          ],
          seat: [
            {tit:'시트', name:'인조가죽 시트', sub:''},
            {tit:'열선시트', name:'앞좌석 열선 시트', sub:''},
            {tit:'통풍시트', name:'운전석 통풍 시트', sub:''  },
            {tit:'폴딩시트', name:'뒷좌석 5:5 분할 폴딩 시트', sub:''},
          ],
          convenience: [
            {tit:'헤드램프', name:'', sub:'프로젝션 헤드램프 선택가능', noOpt: true},
            {tit:'하이패스', name:'', sub:'하이패스 시스템 선택가능', noOpt: true},
            {tit:'에어컨', name:'매뉴얼 에어컨', sub:'풀오토 에어컨 선택가능'},
            {tit:'버튼시동 & 스마트키', name:'', sub:'시스템 선택가능', noOpt: true},
            {tit:'선루프', name:'', sub:'선택가능'},
          ],
          multimedia: [
            {tit:'내비게이션', name:'', sub:'8인치 와이드 내비게이션 선택가능', noOpt: true},
            {tit:'후방카메라', name:'', sub:'후방카메라 선택가능', noOpt: true},
          ],
        },
        {
          powrerTrain: [
            {tit:'엔진', name:'카파개선 1.0 엔진', sub:'카파개선 1.0 터보 엔진 선택가능'}
          ],
          safty: [
            {tit:'현대 스마트센스', name:'현대 스마트센스I', sub:''},
            {tit:'에어백', name:'6에어백', sub:''}
          ],
          exterior: [
            {tit:'휠&타이어', name:'17인치 알로이휠', sub:''},
          ],
          seat: [
            {tit:'시트', name:'인조가죽 시트', sub:''},
            {tit:'열선시트', name:'앞좌석 열선 시트', sub:''},
            {tit:'통풍시트', name:'운전석 통풍 시트', sub:''},
            {tit:'폴딩시트', name:'운전석/동승석 풀 폴딩  ', sub:''},
          ],
          convenience: [
            {tit:'헤드램프', name:'프로젝션 헤드램프', sub:''},
            {tit:'하이패스', name:'하이패스 시스템', sub:''},
            {tit:'에어컨', name:'매뉴얼 에어컨', sub:''},
            {tit:'버튼시동 & 스마트키', name:'버튼시동 & 스마트키 시스템', sub:''},
            {tit:'선루프', name:'', sub:'선택가능'},
          ],
          multimedia: [
            {tit:'내비게이션', name:'8인치 와이드 내비게이션', sub:''},
            {tit:'후방카메라', name:'후방카메라', sub:''},
          ],
        }
      ],
      wrapperFixed: false
    }
  },
  methods: {
    scroll() {
      let scrollTop = Math.ceil(this.$refs.wrapper.scrollTop)
      if (scrollTop > 0) {
        this.wrapperFixed = true
        this.$refs.fixHeader.style.width = this.$refs.wrapper.clientWidth + 'px'
      } else {
        this.wrapperFixed = false
        this.$refs.fixHeader.style.width = this.$refs.wrapper.offsetWidth + 'px'
      }
    },
  },
}
</script>
