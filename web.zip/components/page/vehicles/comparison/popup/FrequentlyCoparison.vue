<template>
  <v-popup
    :visible="visible"
    :footer="['close']"
    :width="'550px'"
    @close="
      $emit('close')
      popVisible = false
    "
    @confirm="
      $emit('close')
      popVisible = false
    "
  >
    <template slot="header">
      <div class="title">자주비교되는 차량</div>
    </template>
    <template slot="body">
        TBD
    </template>
  </v-popup>
</template>

<script>
import { VPopup } from '~/components/element'
export default {
  components: {
    VPopup
  },
  props: {
    visible: {
      type: Boolean,
      default: false
    }
  },
}
</script>