<template>
  <section class="information-detail" :class="{ open: isOptionsShow }">
    <div class="summary-info" :class="{ active: isOptionsShow }">
      <h1 class="title">구입비용</h1>
      <v-btn
        class="btn-detail"
        type="icon"
        :icon-class="['icon-open', { active: isOptionsShow }]"
        @click="isOptionsShow = !isOptionsShow"
        ><span class="offscreen">상세보기</span></v-btn
      >
    </div>
    <div v-show="isOptionsShow" class="detail-info">
      <div class="comparison-wrap v-type">
          <div v-for="(item, index) in registDataLabel" :key="index" class="item-box no-line">
            <strong class="title">{{ item }}</strong>
            <ul class="item-list">
               <template v-for="idx in 4">
                <li v-if="idx <= registList.length" :key="idx">
                  <template v-if="Object.keys(registList[idx - 1])[index] === 'condition'">
                    <div>
                      <v-select
                        v-model="registList[idx - 1].condition.conditionVal"
                        :data="registList[idx - 1].condition.list"
                        :disabled="idx - 1 != 0 ? true : false"
                        style="width:150px;"
                        placeholder="등록조건선택"
                      />
                    </div>
                    <div class="mg">
                      <v-checkbox
                        :one-check="true"
                        :checked.sync="registList[idx - 1].condition.multichildVal"
                        :disabled="idx - 1 != 0 ? true : false"
                        >다자녀 감면</v-checkbox>
                    </div>
                  </template>
                  <template v-else-if="Object.keys(registList[idx - 1])[index] === 'area'">
                    <div>
                      <v-select
                        v-model="registList[idx - 1].area.areaVal"
                        :data="registList[idx - 1].area.areaList"
                        :disabled="idx - 1 != 0 ? true : false"
                        style="width:135px;"
                        placeholder="등록지역선택"
                      />
                    </div>
                    <div class="mg">
                      <v-select
                        v-model="registList[idx - 1].area.area2Val"
                        :data="registList[idx - 1].area.area2List"
                        :disabled="idx - 1 != 0 ? true : false"
                        style="width:135px;"
                        placeholder="등록지역상세선택"
                      />
                    </div>
                  </template>
                  <template v-else>{{
                  registList[idx - 1][Object.keys(registList[idx - 1])[index]]
                }}</template>
                </li>
                <li v-else :key="idx"></li>
              </template>
            </ul>
          </div>
          <div class="line"></div>
          <div v-for="(item, index) in subsidyDataLabel" :key="index" class="item-box no-line">
            <strong class="title">{{ item }}</strong>
            <ul class="item-list">
               <template v-for="idx in 4">
                <li v-if="idx <= subsidyList.length" :key="idx">
                  <template v-if="Object.keys(subsidyList[idx - 1])[index] === 'subsidyPrice'">
                    <div>
                      {{ subsidyList[idx - 1].subsidyPrice.price | comma }} 원
                    </div>
                    <div class="mg">
                      <v-checkbox
                        :one-check="true"
                        :checked.sync="subsidyList[idx - 1].subsidyPrice.subsidy"
                        >국고 보조금</v-checkbox
                      >
                    </div>
                  </template>
                  <template v-else>{{ subsidyList[idx - 1][Object.keys(subsidyList[idx - 1])[index]] | comma }} 원</template>
                </li>
                <li v-else :key="idx"></li>
              </template>
            </ul>
          </div>
      </div>
   </div>

    <!-- 취득세 안내  -->
    <info-acquirement :pop-visible="popVisible" />
    <!-- 공채 안내 -->
    <info-fund :pop-visible="popVisible" />
  </section>
</template>

<script>
import InfoAcquirement from '~/components/page/payment/popup/InfoAcquirement'
import InfoFund from '~/components/page/payment/popup/InfoFund'
export default {
  components: {
    InfoAcquirement,
    InfoFund
  },
  filters: {
    comma(val) {
      return String(val).replace(/\B(?=(\d{3})+(?!\d))/g, ',')
    }
  },
  data() {
    return {
      isOptionsShow: false,
      registDataLabel: ['등록비', '등록조건', '취득세', '등록지역', '공채금액(할인)'],
      subsidyDataLabel: ['친환경차 보조금', '승용 및 초소형 전기차', '지자체별 친환경차 보조금'],
      registList :[
        {
          registPrice:'2669986',
          condition : {
            conditionVal: '3',
            list: [
              { value: '1', label: '일반인' },
              { value: '2', label: '장애 1-3급' },
              { value: '3', label: '시각장애 4급' }
            ],
            multichildVal: false,
          },
          tax: '2,500,000',
          area: {
            areaVal: '2',
            areaList: [
              { value: '1', label: '서울' },
              { value: '2', label: '경기' },
              { value: '3', label: '대구' }
            ],
            area2Val: '2',
            area2List: [
              { value: '1', label: '경기 안양시' },
              { value: '2', label: '경기 광명시' },
              { value: '3', label: '인천' }
            ],
          },
          sale: '47,924'
        },
        {
          registPrice:'2669986',
          condition : {
            conditionVal: '3',
            list: [
              { value: '1', label: '일반인' },
              { value: '2', label: '장애 1-3급' },
              { value: '3', label: '시각장애 4급' }
            ],
            multichildVal: false,
          },
          tax: '2,500,000',
          area: {
            areaVal: '2',
            areaList: [
              { value: '1', label: '서울' },
              { value: '2', label: '경기' },
              { value: '3', label: '대구' }
            ],
            area2Val: '2',
            area2List: [
              { value: '1', label: '경기 안양시' },
              { value: '2', label: '경기 광명시' },
              { value: '3', label: '인천' }
            ],
          },
          sale: '47,924'
        },
        {
          registPrice:'2669986',
          condition : {
            conditionVal: '3',
            list: [
              { value: '1', label: '일반인' },
              { value: '2', label: '장애 1-3급' },
              { value: '3', label: '시각장애 4급' }
            ],
            multichildVal: false,
          },
          tax: '2,500,000',
          area: {
            areaVal: '2',
            areaList: [
              { value: '1', label: '서울' },
              { value: '2', label: '경기' },
              { value: '3', label: '대구' }
            ],
            area2Val: '2',
            area2List: [
              { value: '1', label: '경기 안양시' },
              { value: '2', label: '경기 광명시' },
              { value: '3', label: '인천' }
            ],
          },
          sale: '47,924'
        }
      ],
      subsidyList: [
        {
          subsidyPrice: {
            price: '0',
            subsidy:'',
          },
          carSubsidyPrice:'0',
          areaSubsidyPrice: '0',
        },
        {
          subsidyPrice: {
            price: '0',
            subsidy:'',
          },
          carSubsidyPrice:'0',
          areaSubsidyPrice: '0',
        },
        {
          subsidyPrice: {
            price: '0',
            subsidy:'',
          },
          carSubsidyPrice:'0',
          areaSubsidyPrice: '0',
        },
      ],
      popVisible: {
        infoAcquirement: false,
        infoFund: false
      }
    }
  },
  mounted(){

  },
  methods: {}
}
</script>
