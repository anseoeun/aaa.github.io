<template>
  <section class="information-detail" :class="{ open: isOptionsShow }">
    <div class="summary-info" :class="{ active: isOptionsShow }">
      <h1 class="title">충돌/안전</h1>
      <v-btn
        class="btn-detail"
        type="icon"
        :icon-class="['icon-open', { active: isOptionsShow }]"
        @click="isOptionsShow = !isOptionsShow"
        ><span class="offscreen">상세보기</span></v-btn
      >
    </div>
    <div v-show="isOptionsShow" class="detail-info">
      <div class="comparison-wrap v-type">
          <div v-for="(item, index) in dataListLabel" :key="index" class="item-box">
            <strong class="title">{{ item }}</strong>
            <ul class="item-list">
               <template v-for="idx in 4">
                <li v-if="idx <= dataList.length" :key="idx">
                  {{ dataList[idx - 1][Object.keys(dataList[idx - 1])[index]] }}
                    <div v-if="Object.keys(dataList[idx - 1])[index] === 'displacement' && parseInt(dataList[0].displacement) !== parseInt(dataList[idx - 1].displacement)" class="right margin">
                      <span v-if="parseInt(dataList[0].displacement) > parseInt(dataList[idx - 1].displacement)" class="down">{{ dataList[0].displacement - dataList[idx - 1].displacement }} cc</span>
                      <span v-if="parseInt(dataList[0].displacement) < parseInt(dataList[idx - 1].displacement)" class="up">{{ dataList[idx - 1].displacement - dataList[0].displacement }} cc</span>
                    </div>
                </li>
                <li v-else :key="idx"></li>
              </template>
            </ul>
          </div>
      </div>
    </div>
  </section>
</template>

<script>
export default {
  components: {},
  data() {
    return {
      isOptionsShow: false,
      dataListLabel: ['종합등급(충돌안전)', '평가연도', '점수', '출동안전', '보행자 안전', '사고예방 안전(2016년 이전 : 주행안)', '가산점(2016년 이전 : 사고 예방안전)' ],
      dataList: [
        {
          overallGrade: '1등급',
          evaluationYear: '2015년',
          grade: '91.9점',
          exhibition: '91.9점',
          pedestrianSafety: '91.9점',
          accidentPreventionSafety: '91.9점',
          additionalPoints: '91.9점',
        },
        {
          overallGrade: '1등급',
          evaluationYear: '2015년',
          grade: '91.9점',
          exhibition: '91.9점',
          pedestrianSafety: '91.9점',
          accidentPreventionSafety: '91.9점',
          additionalPoints: '91.9점',
        },
        {
          overallGrade: '1등급',
          evaluationYear: '2015년',
          grade: '91.9점',
          exhibition: '91.9점',
          pedestrianSafety: '91.9점',
          accidentPreventionSafety: '91.9점',
          additionalPoints: '91.9점',
        },
      ]
    }
  },
  methods: {}
}
</script>
