<template>
  <section class="information-detail" :class="{ open: isOptionsShow }">
    <div class="summary-info" :class="{ active: isOptionsShow }">
      <h1 class="title">경제성/환경</h1>
      <v-btn
        class="btn-detail"
        type="icon"
        :icon-class="['icon-open', { active: isOptionsShow }]"
        @click="isOptionsShow = !isOptionsShow"
        ><span class="offscreen">상세보기</span></v-btn
      >
    </div>
    <div v-show="isOptionsShow" class="detail-info">
      <div class="comparison-wrap v-type">
        <div v-for="(item, index) in dataLabel" :key="index" class="item-box">
          <strong class="title">{{ item }}</strong>
          <ul class="item-list">
            <template v-for="idx in 4">
              <li v-if="idx <= dataList.length" :key="idx">
                <template v-if="Object.keys(dataList[idx - 1])[index] === 'support'">
                  {{ dataList[idx - 1][Object.keys(dataList[idx - 1])[index]].price | comma }} 원
                  <span class="right margin">
                    <span v-if="parseInt(dataList[0][Object.keys(dataList[idx - 1])[index]].price) !== parseInt(dataList[idx - 1][Object.keys(dataList[idx - 1])[index]].price)">
                      <span v-if="parseInt(dataList[0][Object.keys(dataList[idx - 1])[index]].price) > parseInt(dataList[idx - 1][Object.keys(dataList[idx - 1])[index]].price)" class="down">{{ dataList[0][Object.keys(dataList[idx - 1])[index]].price - dataList[idx - 1][Object.keys(dataList[idx - 1])[index]].price | comma }} 원</span>
                      <span v-if="parseInt(dataList[0][Object.keys(dataList[idx - 1])[index]].price) < parseInt(dataList[idx - 1][Object.keys(dataList[idx - 1])[index]].price)" class="up">{{ dataList[idx - 1][Object.keys(dataList[idx - 1])[index]].price - dataList[0][Object.keys(dataList[idx - 1])[index]].price | comma }} 원</span>
                    </span>
                    &nbsp;
                  </span>
                </template>
                <template v-else-if="Object.keys(dataList[idx - 1])[index] === 'supportCondition'">
                    <ul class="item-detail">
                      <li>
                        <em>운행기간</em>
                        <span class="item">
                          <v-select
                            v-model="dataList[idx - 1][Object.keys(dataList[idx - 1])[index]].termVal"
                            :data="dataList[idx - 1][Object.keys(dataList[idx - 1])[index]].term"
                            style="width:150px;"
                            placeholder="운행기간선택"
                          />
                        </span>
                      </li>
                      <li>
                        <em>운행거리</em>
                        <span class="item">
                            <v-select
                              v-model="dataList[idx - 1][Object.keys(dataList[idx - 1])[index]].distenceVal"
                              :data="dataList[idx - 1][Object.keys(dataList[idx - 1])[index]].distence"
                              style="width:150px;"
                              placeholder="운행거리선택"
                            />
                        </span>
                      </li>
                      <li><em>자동차세</em> <span class="item">+ {{ dataList[idx - 1][Object.keys(dataList[idx - 1])[index]].tax }} 원</span></li>
                      <li><em>보험료</em> <span class="item">+ {{ dataList[idx - 1][Object.keys(dataList[idx - 1])[index]].insurance }} 원</span></li>
                      <li><em>유류비</em> <span class="item">+ {{ dataList[idx - 1][Object.keys(dataList[idx - 1])[index]].oil }} 원</span></li>
                    </ul>
                </template>
                  <template v-else>{{
                  dataList[idx - 1][Object.keys(dataList[idx - 1])[index]]
                }}</template>
              </li>
              <li v-else :key="idx"></li>
            </template>
          </ul>
        </div>
      </div>
    </div>
  </section>
</template>

<script>
export default {
  components: {},
  filters:{
    comma(val){
      return String(val).replace(/\B(?=(\d{3})+(?!\d))/g, ',')
    }
  },
  data() {
    return {
      isOptionsShow: false,
      dataLabel: ['복합연비', '시내연비', '고속연비', '연비등급', '자체 보험등급', '이산화탄소 배출량', '유지 비용', '운행조건별 유지 비용'],
      dataList: [
        {
          combinedFuel: '12.6 km/ℓ',
          cityFuel: '12.6 km/ℓ',
          highFuel: '12.6 km/ℓ',
          fuelEconomyClass: '2등급',
          selfInsuranceClass: '14',
          carbonDioxide: '151 g/km',
          support:{
              price: '2669986',
          },
          supportCondition:{
            termVal: '3',
            term: [
              { value: '1', label: '1년' },
              { value: '2', label: '2년' },
              { value: '3', label: '3년' }
            ],
            distenceVal: '2',
            distence: [
              { value: '1', label: '1만 km / 1년' },
              { value: '2', label: '2만 km / 1년' },
              { value: '3', label: '3만 km / 1년' }
            ],
            tax: '87,924',
            insurance: '287,924',
            oil: '1,425,842'
          }
        },
        {
          combinedFuel: '12.6 km/ℓ',
          cityFuel: '12.6 km/ℓ',
          highFuel: '12.6 km/ℓ',
          fuelEconomyClass: '2등급',
          selfInsuranceClass: '14',
          carbonDioxide: '151 g/km',
          support:{
              price: ' 3969245',
          },
          supportCondition:{
              termVal: '3',
              term: [
                { value: '1', label: '1년' },
                { value: '2', label: '2년' },
                { value: '3', label: '3년' }
              ],
              distenceVal: '2',
              distence: [
                { value: '1', label: '1만 km / 1년' },
                { value: '2', label: '2만 km / 1년' },
                { value: '3', label: '3만 km / 1년' }
              ],
              tax: '87,924',
              insurance: '287,924',
              oil: '1,425,842'
          }
        },
        {
          combinedFuel: '12.6 km/ℓ',
          cityFuel: '12.6 km/ℓ',
          highFuel: '12.6 km/ℓ',
          fuelEconomyClass: '2등급',
          selfInsuranceClass: '14',
          carbonDioxide: '151 g/km',
          support:{
              price: '1429986',
          },
          supportCondition: {
              termVal: '3',
              term: [
                { value: '1', label: '1년' },
                { value: '2', label: '2년' },
                { value: '3', label: '3년' }
              ],
              distenceVal: '2',
              distence: [
                { value: '1', label: '1만 km / 1년' },
                { value: '2', label: '2만 km / 1년' },
                { value: '3', label: '3만 km / 1년' }
              ],
              tax: '87,924',
              insurance: '287,924',
              oil: '1,425,842'
          }
        }
      ]
    }
  },
  methods: {}
}
</script>
