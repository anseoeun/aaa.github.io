<template>
  <section class="information-detail" :class="{ open: isOptionsShow }">
    <div class="summary-info" :class="{ active: isOptionsShow }">
      <h1 class="title">성능/제원</h1>
      <v-btn
        class="btn-detail"
        type="icon"
        :icon-class="['icon-open', { active: isOptionsShow }]"
        @click="isOptionsShow = !isOptionsShow"
        ><span class="offscreen">상세보기</span></v-btn
      >
    </div>
    <div v-show="isOptionsShow" class="detail-info">
      <div class="comparison-wrap v-type">
          <div v-for="(item, index) in dataListLabel" :key="index" class="item-box">
            <strong class="title">{{ item }}</strong>
            <ul class="item-list">
               <template v-for="idx in 4">
                <li v-if="idx <= dataList.length" :key="idx">
                  {{ dataList[idx - 1][Object.keys(dataList[idx - 1])[index]] }}
                    <div v-if="Object.keys(dataList[idx - 1])[index] === 'displacement' && parseInt(dataList[0].displacement) !== parseInt(dataList[idx - 1].displacement)" class="right margin">
                      <span v-if="parseInt(dataList[0].displacement) > parseInt(dataList[idx - 1].displacement)" class="down">{{ dataList[0].displacement - dataList[idx - 1].displacement }} cc</span>
                      <span v-if="parseInt(dataList[0].displacement) < parseInt(dataList[idx - 1].displacement)" class="up">{{ dataList[idx - 1].displacement - dataList[0].displacement }} cc</span>
                    </div>
                </li>
                <li v-else :key="idx"></li>
              </template>
            </ul>
          </div>
      </div>
    </div>
  </section>
</template>

<script>
export default {
  components: {},
  data() {
    return {
      isOptionsShow: false,
      dataListLabel: ['엔진', '연료	', '변속기', '최고출력', '최고토크', '배기량', '구동방식', '연료탱크', '배터리 종류', '배터리 충전 용량', '1회 충전 주행거리', '충전시간(급속)', '충전시간(완속)', '전장', '전폭', '전고', '축간 거리', '윤거 전', '윤거 후', '타이어', '공차 중량'],
      dataList: [
        {
          engin: '스마트스트림 G1.6 엔진',
          fuel: '가솔린',
          transmission: '6단 수동변속기',
          output: '123 ps / 6300 rpm',
          torque: '15.7 kg·m / 4500 rpm',
          displacement: '1598',
          drivingMethod: '2WD / FWD(전륜구동)',
          fuelTank:'47 ℓ',
          batteryType: '-',
          batteryChargingCapacity: '-',
          mileage :'-',
          dhargingTimeQuick :'-',
          dhargingTimeSlow :'-',
          fullLength :'4,650 mm',
          fullWidth :'1,825 mm',
          fullHeight :'1,420 mm',
          axisDistance :'2,720 mm',
          beforeRolling :'1,593 mm',
          afterRolling :'1,604 mm',
          tire :'195/65R15',
          toleranceWeight :'1,185 kg'
        },
        {
          engin: '스마트스트림 G1.6 엔진',
          fuel: '가솔린',
          transmission: '6단 수동변속기',
          output: '123 ps / 6300 rpm',
          torque: '15.7 kg·m / 4500 rpm',
          displacement: '1400',
          drivingMethod: '2WD / FWD(전륜구동)',
          fuelTank:'47 ℓ',
          batteryType: '-',
          batteryChargingCapacity: '-',
          mileage :'-',
          dhargingTimeQuick :'-',
          dhargingTimeSlow :'-',
          fullLength :'4,650 mm',
          fullWidth :'1,825 mm',
          fullHeight :'1,420 mm',
          axisDistance :'2,720 mm',
          beforeRolling :'1,593 mm',
          afterRolling :'1,604 mm',
          tire :'195/65R15',
          toleranceWeight :'1,185 kg'
        },
        {
          engin: '스마트스트림 G1.6 엔진',
          fuel: '가솔린',
          transmission: '6단 수동변속기',
          output: '123 ps / 6300 rpm',
          torque: '15.7 kg·m / 4500 rpm',
          displacement: '1700',
          drivingMethod: '2WD / FWD(전륜구동)',
          fuelTank:'47 ℓ',
          batteryType: '-',
          batteryChargingCapacity: '-',
          mileage :'-',
          dhargingTimeQuick :'-',
          dhargingTimeSlow :'-',
          fullLength :'4,650 mm',
          fullWidth :'1,825 mm',
          fullHeight :'1,420 mm',
          axisDistance :'2,720 mm',
          beforeRolling :'1,593 mm',
          afterRolling :'1,604 mm',
          tire :'195/65R15',
          toleranceWeight :'1,185 kg'
        },
      ]
    }
  },
  methods: {}
}
</script>
