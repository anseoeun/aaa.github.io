<template>
  <div class="">
    <!-- 시승신청약관레이어들  -->
    <agreement-use :pop-visible="visible" />
    <!-- 드라이빙 라운지 -->
    <driving-lounge :pop-visible="visible" />
    <!-- 위치수정레이어 -->
    <address-pop :pop-visible="visible" />
    <!-- 시승체크포인트레이어 -->
    <check-point :pop-visible="visible" />
  </div>
</template>

<script>
import AgreementUse from '~/components/page/vehicles/test-driving/popup/AgreementUse'
import DrivingLounge from '~/components/page/vehicles/test-driving/popup/DrivingLounge'
import AddressPop from '~/components/page/vehicles/test-driving/popup/Address'
import CheckPoint from '~/components/page/vehicles/test-driving/popup/CheckPoint'

export default {
  components: {
    AgreementUse,
    DrivingLounge,
    AddressPop,
    CheckPoint
  },
  props: {
    visible: {
      type: Object,
      defualt: {},
      required: true
    }
  },
  data() {
    return {}
  },
  methods: {
    parentsSync(e) {
      this.visible = e
      this.$emit('visibleSync', this.visible)
    }
  }
}
</script>
