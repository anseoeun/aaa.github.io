<template>
  <div>

    <!-- (필수)시승차이용및서비스이용에따른주요고지사항 -->
    <v-popup
      :width="'1000px'"
      :visible="popVisible.testDrive"
      :footer="['confirm']"
      @confirm="popVisible.testDrive = false"
      @close="popVisible.testDrive = false"
    >
      <template slot="header">
        <div class="title">(필수) 시승차 이용 및 서비스 이용에 따른 주요 고지사항</div>
      </template>
      <template slot="body">
        <div class="terms-area">
          <strong>1. 유의사항</strong>
          <ol>
            <li>① 고객님의 시승차 운전이 불가하다고 판단 시 귀사 직원의 판단에 따라 즉시 시승이 중단/취소될 수 있으며 향후 시승 이용이 제한될 수 있습니다.<br />(음주, 심신미약, 운전미숙, 과속 및 난폭운전, 기상악화 등 안전상 위험하다고 판단되는 경우)</li>
            <li>② 시승서비스 이용을 위해서는 시승 전 반드시 운전면허증을 제시해야 합니다.</li>
            <li>③ 시승차는 보험 적용 기준에 따라 만 21세 이상만 운형 가능합니다.</li>
            <li>④ 찾아가는 시승서비스의 경우 시승 구간은 시승 희망지 주변이며, 그 외의 경우 시승 구간은 드리이빙라운지 주변입니다. 시승 후에는 출발지로 돌아와 반드시 차량을 반납해야 합니다.</li>
            <li>⑤ 다음 시승 신청 고객님들을 위해 시승 신청시간을 준수해 주시기 바랍니다. 신청 변동사항이 있을 경우 드라이빙라운지 혹은 담당 카마스터에게 사전 연락을 부탁드립니다. 고객님과 연락이 두절되는 경우 시승 신청이 자동 취소될 수 있습니다. 시승시간은 차량준비 및 이동시간을 포함하여 총 1시간 30분 또는 2시간입니다. (시간대별 상이)<br />*long-time 시승 (총3시간)을 원하시는 경우 방문 희망 드라이빙라운지로 유선 연락 주시길 바랍니다.</li>
            <li>⑥ 시승 고객님의 안전한 운행을 위해 동승 시승, 찾아가는 시승을 희망하시는 경우 카마스터가 동승합니다.</li>
            <li>⑦계약 이력 또는 담당 카마스터가 있는 고객님이 동승 시승을 희망하시는 경우 담당 카마스터담당 와 동승 시승 가능 여부 확인 후 예약이 확정됩니다. 계약 이력이 있는 고객님은 담당 카마스터가 동승이 불가능한 경우, 찾아가는 시승서비스 이용이 제한됩니다.</li>
            <li>⑧ 시승서비스는 고객님께서 차량을 구매하기 전 관심 차종을 경험할 수 있는 기회를 드리고자 제공되는 서비스입니다. 따라서 개인적 용도로 시승차를 이용하려는 경우 시승이 제한될 수 있습니다.  많은 고객님께서 시승서비스를 제공하기 위해 고객님 한 분당 연간 6회까지 시승 신청이 가능합니다.</li>
          </ol>

          <strong>2. 보험사항</strong>
          <p>상기차량은 대인배상(1,2), 대물배상, 자기신체, 자기 차량, 무보험 등의 보험에 가입되어 있으나, 보험 가액을 초과하는 부분 및 보험 미적용 부분 (운전자 연령 한정 운전 특약 위반, 차량 사고 시 자차 부담금 최대 10만원 고객 부담)등에 대해서는 본인이 스스로 책임을 지는 동시에 귀사에 발생한 모든 손해를 배상할 것을 약속합니다.</p>

          <strong>3. 금지사항</strong>
          <p>본인은 귀사가 제공한 상기 차량을 상업적으로 이용하는 등 비정상적으로 운행하거나, 본인 외 제 3자에게 운행, 양도, 대여, 담보의 목적으로 제공하는 등의 행위를 일절 하지 않을 것을 약속합니다. 또한 주행보조 기능(AEB자동 긴급 제동 시스템, FCA 전방 충돌 방지 보조 등) 작동을 위하여 위험한 운전을 시도하지 않으며, 항상 안전하게 운전할 것을 약속합니다.</p>

          <strong>4. 책임사항</strong>
          <ol>
            <li>① 본인은 위 보험 사항 및 금지사항, 유의사항을 위반하여 발생한 모든 민.형사상 책임을 부담합니다.</li>
            <li>② 본인은 약정된 차량 반납 일시까지 상기 차량을 지정된 반납 장소에 반납하지 않거나 차량 반납시 차량 상태가 변동된 경우, 이로 인해 발생한 모든 손해에 대한 배상 책임을 부담합니다.</li>
            <li>③ 본인은 교통법규 미준수로 인한 벌금, 과태료 및 시승 운행 시 발생한 도로교통비 등을 부담합니다.</li>
          </ol>

          <strong>위치정보 수집장치 부착 사실 고지</strong>
          <p>시승차량에 장착된 블루링크 단말을 통해 시승서비스 이용 시간 동안 시승차량 및 고객님의 위치정보가 수집됨을 알려드립니다.</p>
        </div>
      </template>
    </v-popup>

    <!-- (필수) 개인정보 수집 및 이용안내 -->
    <v-popup
      :width="'550px'"
      :visible="popVisible.privacyInfo"
      :footer="['confirm']"
      @confirm="popVisible.privacyInfo = false"
      @close="popVisible.privacyInfo = false"
    >
      <template slot="header">
        <div class="title">(필수) 개인정보 수집 및 이용안내</div>
      </template>
      <template slot="body">
        <p class="contents-head">개인정보 수집 및 이용 목적</p>
        <ul class="bullet-list">
          <li>시승서비스 제공, 시승차량 사고 발생 시 보험처리 등</li>
          <li>사고 대응, 시승차량 도난 방지 및 운행 관리, 고객 불만</li>
          <li>민원사항 처리, 분쟁 발생 시 대응, 소비자 의견 조사, 고객 관리 서비스 제공</li>
        </ul>

        <p class="contents-head">개인정보의 수집 항목</p>
        <ul class="bullet-list">
          <li>고객성명, 휴대전화번호, 생년월일, 성별, 시승정보(시승차종, 차량번호, 시승일시), 시승차량 이동 내역 및 실시간 위치정보</li>
        </ul>

        <p class="contents-head">개인정보의 보유 및 이용기간</p>
        <ul class="bullet-list">
          <li>시승일 기준 2년</li>
        </ul>

        <div class="notice"><div class="bullet-star">고객님은 위의 개인정보 수집 이용에 대한 동의를 거부하실 수 있습니다.<br />그러나, 동의 거부 시 시승서비스 이용이 불가합니다.</div></div>
      </template>
    </v-popup>

    <!-- (필수)개인정보처리위탁안내 -->
    <v-popup
      :width="'550px'"
      :visible="popVisible.privacyTrust"
      :footer="['confirm']"
      @confirm="popVisible.privacyTrust = false"
      @close="popVisible.privacyTrust = false"
    >
      <template slot="header">
        <div class="title">(필수) 개인정보 처리 위탁 안내</div>
      </template>
      <template slot="body">
        <ul class="bullet-list">
          <li>현대자동차(주)는 전산시스템 운영 및 유지보수 등 서비스 제공을 위하여 필요한 경우 외부 전문업체에 개인정보 처리업무를 위탁하여 운영하고 있습니다.</li>
          <li>개인정보 처리업무와 관련한 자세한 내용과 변경사항은 당사 홈페이지 (www.hyundai.com)에 게시된 '개인정보 처리방침'에서 확인하실 수 있습니다.</li>
        </ul>
      </template>
    </v-popup>

    <!-- (선택)차량구입관련상담및각종정보제공안내 -->
    <v-popup
      :width="'550px'"
      :visible="popVisible.carBuy"
      :footer="['nonAgree', 'confirm']"
      @close="popVisible.carBuy = false"
    >
      <template slot="header">
        <div class="title">(선택) 차량구입 관련 상담 및 각종 정보제공 안내</div>
      </template>
      <template slot="body">
        <p class="contents-head">정보 수집 목적</p>
        <ul class="bullet-list">
          <li>차량구입 안내 및 제품/서비스/이벤트 관련 정보 전송 등</li>
          <li>마케팅 &middot; 홍보 목적 활용</li>
        </ul>

        <p class="contents-head">정보 수집 항목</p>
        <ul class="bullet-list">
          <li>고객성명, 휴대전화번호, 생년월일, 성별</li>
        </ul>

        <p class="contents-head">정보 수집 목적</p>
        <ul class="bullet-list">
          <li>시승일 기준 2년간</li>
        </ul>

        <div class="notice"><div class="bullet-star">고객님은 위의 마케팅 활용 및 광고성 정보 전송에 대한 동의를 거부하실 수 있습니다. 동의를 거부하시더라도 시승서비스 이용에는 제한이 없으나, 차량구입 정보 등의 안내 &middot; 제공이 제한됩니다.</div></div>
      </template>
    </v-popup>

  </div>
</template>
<script>
import { VPopup } from '~/components/element'
export default {
  components: {
    VPopup,
  },
  props: {
    popVisible: {
      type: Object,
      defualt: {},
      required: true
    }
  },
}
</script>
