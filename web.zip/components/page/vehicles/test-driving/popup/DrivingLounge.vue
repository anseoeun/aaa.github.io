<template>
  <v-popup
    :width="'776px'"
    :visible="popVisible.drivingLounge"
    @close="popVisible.drivingLounge = false"
  >
    <template slot="header">
      <div class="title">드라이빙 라운지 안내</div>
    </template>
    <template slot="body">
      <div class="driving-lounge-guide">
        <div class="contents-head">{{ text.seongNae.title }}</div>
        <p class="text-main t-left">{{ text.seongNae.address }}</p>
        <p class="text-main t-left">{{ text.seongNae.number }}</p>
        <div class="map-area" style="height:380px; background:#f9f9f9;">지도영역</div>
        <div class="contents-head">찾아오시는 길</div>
        <ul class="lounge-direction">
          <li>
            <span>지하철</span>
            <em>{{ text.seongNae.subwayDesc }}</em>
          </li>
          <li>
            <span>버스</span>
            <em>{{ text.seongNae.busDesc1 }}<br />{{ text.seongNae.busDesc2 }}</em>
          </li>
          <li>
            <span>자가용</span>
            <em>{{ text.seongNae.carDesc }}</em>
          </li>
          <li>
            <span>주차장</span>
            <em>{{ text.seongNae.parkingDesc }}</em>
          </li>
        </ul>
      </div>
    </template>
  </v-popup>
</template>
<script>
import { VPopup } from '~/components/element'
export default {
  components: {
    VPopup,
  },
  props: {
    popVisible: {
      type: Object,
      defualt: {},
      required: true
    }
  },
  data(){
    return {
      text: {
        seongNae: {
          title: '성내시승센터',
          address: '서울특별시 강동구 천호대로 1096',
          number: '02-459-8330',
          subwayDesc: '지하철 5호선 강동역 3번출구로 나오시면 현대자동차 모터프자라 內 3층 성내시승센터가 있습니다.',
          busDesc1: '30-3, 555-2, 112, 113, 571, 21, 64-1',
          busDesc2: '(지하철 강동역 정류장에서 내려 길동4거리 방향으로 오시면 현대자동차 모터프자라 內 3층 성내시승센터가 있습니다.)',
          carDesc: '천호사거리에서 길동사거리 (지하철 5호선)를 지나 20m 지점 오른쪽에 있습니다.',
          parkingDesc: '천호사거리에서 길동사거리 (지하철 5호선)를 지나 20m 지점 오른쪽에 있습니다.',
        },
      }
    }
  }
}
</script>
