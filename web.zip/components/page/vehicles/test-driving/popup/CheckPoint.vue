<template>
  <v-popup
    :width="'776px'"
    :visible="popVisible.checkPoint"
    @close="popVisible.checkPoint = false"
  >
    <template slot="header">
      <div class="title">시승 체크포인트</div>
    </template>
    <template slot="body">
      <v-tab class="tab-default" :data="tabList" :contents="true">
        <template slot="contents">
          <div data-id="tab1">
            <div class="checkpoint-body">
              <ul class="body-contents">
                <li>
                  <strong class="contents-head">시승 전 확인해주세요!</strong>
                  <p class="text-main t-left">시승 거점 이용 전 아래의 사항을 확인하시면 더욱 편안한 시승을 즐길수 있습니다.</p>
                </li>
                <li>
                  <strong class="contents-head">1. 시승 거점 방문시 운전면허증 지참해주세요.</strong>
                  <p class="text-main t-left">보험 적용 기준에 따라 만 21세 이상 시승 가능</p>
                </li>
                <li>
                  <strong class="contents-head">2. 여유 있는 시승 체험을 위해 최대 2시간동안 이용하실 수 있습니다.</strong>
                  <p class="text-main t-left">차량 준비 및 이동 시간을 포함하여 1시간 반 ~ 2시간 동안 서비스 제공</p>
                </li>
                <li>
                  <strong class="contents-head">3. 시승 차종 옵션 및 상품 정보 사진 확인해주세요.</strong>
                  <p class="text-main t-left">홈페이지에서 차량 제원 및 신사양 확인 가능, 가격표 다운로드 가능</p>
                  <div class="bth-group">
                    <v-btn class="btn-more">카탈로그 다운로드</v-btn>
                    <v-btn class="btn-more">가격표 다운로드</v-btn>
                  </div>
                </li>
                <li>
                  <strong class="contents-head">4. 내 차 처럼 안전한 운행과 교통법규를 지켜주세요.</strong>
                  <p class="text-main t-left">혹시 모를 사고시 자기 부담금은 최대 10만원 까지만! 시승 시 교통법규 준수는 필수!</p>
                </li>
              </ul>
              <p class="bullet-star">과속, 위험 운전 및 기타 운행이 불가능하다고 판단될 경우 고객님의 안전을 위해 시승이 제한될 수 있습니다.</p>
            </div>
          </div>
          <div data-id="tab2">
            <div class="checkpoint-body">
              <ul class="body-contents">
                <li>
                  <strong class="contents-head">시승 준비가 되셨다면 아래의 사항을 확인해주세요.</strong>
                </li>
                <li>
                  <strong class="contents-head">1. 운전석 시트 및 미러 조절</strong>
                  <p class="text-main t-left">편안한 운전을 위해 전, 후방 시야가 잘 확보되는지 확인해주세요.</p>
                </li>
                <li>
                  <strong class="contents-head">2. 시승 차 주행 센서 사전 체크</strong>
                  <p class="text-main t-left">주행 시 경보음이 울리거나 핸들에 진동이 오더라도 놀라지 마세요. 안정을 위한 소리입니다.(ON/OFF 기능)</p>
                </li>
                <li>
                  <strong class="contents-head">3. 신기술 버튼 조작법 숙지</strong>
                  <p class="text-main t-left">출발 전 동승 카마스터에게 체험하고 싶은 기능들을 알려주시면 좋습니다.<br />(차선 이탈경보 시스템, 스마트 크루즈 컨트롤, 자동주차 기능 등)</p>
                </li>
                <li>
                  <strong class="contents-head">4. ISG 활성화 여부 확인</strong>
                  <p class="text-main t-left">신호를 기다리는데 엔진이 일시적으로 멈췄나요?<br />엔진의 공회전을 줄이기 위해 장착된 ISG 기능입니다. (IDLE STOP GO)<br />* 디젤 및 하이브리드 차량 적용</p>
                </li>
                <li>
                  <strong class="contents-head">5. 썬루프 오픈 후 체험</strong>
                  <p class="text-main t-left">썬루프를 열어서 시원한 개방감을 느껴보세요. 아이들이 정말 좋아한답니다.</p>
                </li>
                <li>
                  <strong class="contents-head">6. 뒷자석 공간성 확인</strong>
                  <p class="text-main t-left">가족들과 함께 탈 차량이라면, 여유 있는 뒷자석 공간을 체크해보세요.</p>
                </li>
                <li>
                  <strong class="contents-head">7. 적제공간 체크</strong>
                  <p class="text-main t-left">트렁크를 한 번 열어서 넉넉한 적재공간을 확인해 보세요.<br />뒷자석 폴딩 시 적재공간이 더 넉넉해집니다.</p>
                </li>
              </ul>
            </div>
          </div>
        </template>
      </v-tab>
    </template>
  </v-popup>
</template>
<script>
import { VPopup, VTab } from '~/components/element'
export default {
  components: {
    VPopup,
    VTab
  },
  props: {
    popVisible: {
      type: Object,
      defualt: {},
      required: true
    }
  },
  data(){
    return {
      tabList: [
        { value: 'tab1', label: '시승 전 체크포인트' },
        { value: 'tab2', label: '시승 시 체크포인트' }
      ],
    }
  }
}
</script>
