<template>
  <v-popup
    :visible="popVisible.specGuide"
    :width="'777px'"
    @close="popVisible.specGuide = false"
  >

    <template slot="header">
      <div class="title">사양명</div>
    </template>
    <template slot="body">
      <div class="specification-wrap">
        <!-- 품목상세 -->
        <div class="section">
            <div class="pooto-view-list-wrap">
              <v-carousel-new
                :data="photoList"
                :navigation="true"
                :pagination="true"
                :items-to-show="1"
                :items-to-slide="1"
                class="pooto-view-list"
              >
                <template slot-scope="props">
                  <div class="item">
                    <div class="img">
                      <v-img :src="props.item.src" :alt="props.item.alt"></v-img>
                    </div>
                  </div>
                </template>
              </v-carousel-new>
            </div>
            <div class="opt-desc">
              <div class="opt-exp">
                차세대 파워트레인 엔진으로 차량의 운전조건에 따라 스마트하게 제어하며 최고 수준의 연비와 성능을 구현합니다. 통합 열관리 시스템, 마찰 저감 엔진 무빙 시스템을 통해 연소 효율과 연비를 개선하여 배기가스 배출을 낮추고 최적의 드라이빙을 선사합니다.
              </div>
              <p class="bullet-star">
                홈페이지의 사진과 설명은 참고용이며 실제 차량에 탑재되는 기능과 설명은 상이할수 있습니다.
              </p>
            </div>
            <div class="menu">
              <div class="price"><b>1,200,000</b> <span class="unit">원</span></div>
              <div class="right">
                <v-btn class="btn md white r" type="button">추가하기</v-btn>
              </div>
            </div>
        </div>
      </div>
    </template>
  </v-popup>
</template>

<script>
import { VPopup } from '~/components/element'
export default {
  components: {
    VPopup
  },
  props: {
    popVisible: {
      type: Object,
      defualt: {},
      required: true
    }
  },
  data() {
    return {
      photoList: [
        {
          src: require('~/assets/images/temp/temp-car-option2.png'),
          alt: '구매후기사진'
        },
        {
          src: require('~/assets/images/temp/temp-car-option.png'),
          alt: '구매후기사진'
        },
        {
          src: require('~/assets/images/temp/temp-car-option2.png'),
          alt: '구매후기사진'
        }
      ],
    }
  },
}
</script>