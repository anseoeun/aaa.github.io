<template>
  <v-popup
    :visible="visible"
    :width="'776px'"
    :footer="['change']"
    @close="$emit('close') "
    @change="$emit('close')">
    <template slot="header">
      <div class="title">나의 탁송지역 변경</div>
    </template>
    <template slot="body">
      <div class="body-contents">
        <div class="info-grid-list">
          <ul>
            <li>
              <div class="info-title">
                <strong>현재 탁송지역</strong>
              </div>
              <div class="info-group">
                <p>서울시</p>
              </div>
            </li>
            <li class="bond">
              <div class="info-title ct">
                <strong>변경할 탁송지역</strong>
              </div>
              <div class="info-group">
                <v-select v-model="locationSelectValue" :data="locationSelect" placeholder="시/도">
                </v-select>
                <v-select v-model="locationSelectValue" :data="locationSelect" placeholder="시/군/구">
                </v-select>
              </div>
            </li>
          </ul>
        </div>
        <div class="notice">
          <ul class="bullet-list">
            <li>나의 탁송지역 기준으로 예상 탁송료가 책정됩니다.</li>
            <li>탁송지역 변경 시 예상 탁송료가 변경될 수 있습니다.</li>
          </ul>
        </div>
      </div>
    </template>
  </v-popup>
</template>

<script>
import { VPopup } from '~/components/element'
export default {
  components: {
    VPopup,
  },
  props: {
    visible: {
      type: Boolean,
      default: false
    },
    data: {
      type: Object,
      default: () => {},
    },
  },
  data() {
    return {
      locationSelect: [
        {
          name: '1',
          value: '서울시'
        },
        {
          name: '2',
          value: '경기도'
        },
        {
          name: '3',
          value: '인천광역시'
        }
      ],
      locationSelectValue: '',
    }
  },
}
</script>