<template>
  <div>
    <div class="event-list">
      <ul>
        <li v-for="(item, index) in evtList" :key="index">
          <div class="img">
            <div class="dim"></div>
            <div class="flag">종료</div>
            <v-img :src="item.src" :alt="item.title"></v-img>
          </div>
          <p class="tit">{{ item.title }}</p>
          <p class="date">{{ item.date }}</p>
        </li>
      </ul>
      <v-pagination :total="100" />
    </div>
  </div>
</template>

<script>
import { VPagination } from '~/components/element'
export default {
  components: {
    VPagination
  },
  data() {
    return {
      topBreadcrumb: [
        { linkName: '모델', link: '/' },
        { linkName: '모델비교', link: '/' }
      ],
      tabList: [
        { value: 'tab1', label: '진행중인 이벤트' },
        { value: 'tab2', label: '지난 이벤트' }
      ],

      evtList: [
        {
          src: require('~/assets/images/temp/temp-event.jpg'),
          title: '9월 제휴 카드 구매 혜택',
          date: '2012.01.02 ~ 2021.01.31'
        },
        {
          src: require('~/assets/images/temp/temp-event.jpg'),
          title: '9월 제휴 카드 구매 혜택',
          date: '2012.01.02 ~ 2021.01.31'
        }
      ]
    }
  }
}
</script>
