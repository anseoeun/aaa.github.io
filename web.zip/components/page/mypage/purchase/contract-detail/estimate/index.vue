<template>
  <div class="matching-box estimate">
    <!-- 계약 기본정보 -->
    <div class="box-wrap">
      <div class="box-tit">
        계약 기본정보
        <v-btn type="nlink" to="/" class="btn-more">변경하기</v-btn>
      </div>
      <div class="box-desc full">
        <div v-if="contractInfo" class="info-grid-list">
          <ul>
            <li v-for="(item, index) in contractorList" :key="index">
              <div class="info-title full">
                <strong class="bold">{{ item.relationCode }}</strong>
                <div v-if="item.sign" class="last">
                  <span class="state">전자서명 완료</span>
                  <span class="sub-text">{{ item.signDate }}</span>
                </div>
                <div v-else class="last sub-text">전자서명 미완료</div>
              </div>
              <div class="info-group full">
                <ul class="desc-list">
                  <li>
                    <em>이름</em>
                    <span>{{ item.relationPersonName }}</span>
                  </li>
                  <li>
                    <em>주민등록번호</em>
                    <span>{{ item.inhabitantsIdentificationNumber }}</span>
                    <!-- asis -->
                    <!-- <span>
                      {{ item.inhabitantsIdentificationNumber.substring(0, 6) }}
                      -
                      {{ item.inhabitantsIdentificationNumber.substring(6, 7) }}******
                    </span> -->
                  </li>
                  <li>
                    <em>연락처</em>
                    <span
                      >{{ item.mobilePhoneNumber1 }}-{{ item.mobilePhoneNumber2 }}-{{ item.mobilePhoneNumber3 }}</span
                    >
                  </li>
                  <li>
                    <em>이메일</em>
                    <span>{{ item.emailAddress }}</span>
                  </li>
                  <li>
                    <em>주소</em>
                    <span>({{ item.zipCode }}) {{ item.addressContents }} {{ item.detailAddressContents }}</span>
                  </li>
                </ul>
                <div v-if="item.signBtn" class="btn-wrap">
                  <ul>
                    <li><v-btn class="btn white md r">카카오톡으로 전자서명</v-btn></li>
                    <li><v-btn class="btn white md r">공동인증서로 전자서명</v-btn></li>
                    <li><v-btn class="btn gray line md r">네이버로 전자서명</v-btn></li>
                  </ul>
                </div>
              </div>
            </li>
            <li>
              <strong class="info-title">면세 정보</strong>
              <div class="info-group">
                <ul class="desc-list">
                  <li>{{ taxFreeDisabilityName }}</li>
                  <li>서류 증빙 시 면세 적용</li>
                </ul>
                <ul class="bullet-star-list full">
                  <li>
                    서류 심사 및 승인은 서류제출(파일 업로드 또는 스크래핑-PC 공인인증으로 자동 업로드) 후 진행합니다.
                  </li>
                  <li>서류 심사 및 승인이 완료되어야 차량대금 결제가 가능합니다.</li>
                  <li>
                    면세 혜택은 공동명의자가 있을 경우 주계약자와 공동명의자의 주소가 동일해야 가능하며, 증빙서류를
                    제출해야 합니다.
                  </li>
                  <li>
                    PC 공인인증으로 자동 업로드가 가능한 대상자는 일반장애 1급~3급 (시각장애 3급 포함) 입니다.<br />그
                    외 대상자는 직접 파일을 업로드 해 주시기 바랍니다.
                  </li>
                </ul>
              </div>
            </li>
            <li>
              <strong class="info-title">보증제도</strong>
              <div class="info-group">{{ guarantyRepairTypeName }}</div>
            </li>
            <li>
              <strong class="info-title full bold">추천 카마스터</strong>
              <div class="info-group full">
                <ul class="desc-list">
                  <li>
                    <em>이름</em>
                    <span>홍길동</span>
                  </li>
                  <li>
                    <em>연락처</em>
                    <span>010-1234-5678</span>
                  </li>
                </ul>
              </div>
            </li>
          </ul>
        </div>
        <p v-else>등록한 정보는 계약서 작성완료 이후 확인하실 수 있습니다.</p>
      </div>
    </div>

    <!-- 서비스 가입 및 신청 정보 -->
    <div class="box-wrap">
      <div class="box-tit full">서비스 가입 및 신청 정보</div>
      <div class="box-desc full">
        <div v-if="serviceInfo" class="info-grid-list">
          <ul>
            <li>
              <strong class="info-title full bold">블루멤버스</strong>
              <div class="info-group full">
                <!-- 멤버십 카드 -->
                <ul v-if="serviceCard === 'members'" class="desc-list">
                  <li>
                    <em>선택한 카드</em>
                    <span>멤버십 카드</span>
                  </li>
                  <li v-if="membersChange">
                    <em>카드 수령지</em>
                    <div>
                      <p>(06719) 서울특별시 서초구 남부순환로 2415 (서초동) 123</p>
                      <v-btn type="nlink" to="/" class="btn-more">수령지 변경</v-btn>
                      <p class="bullet-star">
                        블루멤버스 제휴신용카드 신청자의 경우 현대카드㈜에서 별도 연락 후, HYUNDAI BLUE members Credit
                        카드,<br />HYUNDAI BLUE members Platinum 카드, HYUNDAI BLUE members Platinum Plus 카드 중 1개를
                        신청하실 수 있습니다.
                      </p>
                      <v-btn
                        type="link"
                        href="https://www.hyundaicard.com/ncb/cb/NCBCB0101_01.hc"
                        target="_blank"
                        title="새창열림"
                        class="btn white md r"
                        >현대카드 블루멤버스 전용카드 혜택 알아보기 ></v-btn
                      >
                    </div>
                  </li>
                  <!-- 멤버십 카드 : 카드수령지 변경 -->
                  <li v-else class="form-grid-list">
                    <em class="form-label">카드 수령지</em>
                    <div class="form-group">
                      <el-form ref="cardForm" :model="cardForm" :rules="rules">
                        <el-form-item prop="address" class="form-address full">
                          <div class="label-input inbl-wrap">
                            <label class="offscreen">우편번호</label>
                            <v-input v-model="cardForm.address" type="text" disabled="disabled" />
                            <v-btn class="btn-more">우편번호</v-btn>
                          </div>
                          <div class="label-input">
                            <label class="offscreen">기본주소</label>
                            <v-input v-model="cardForm.address2" type="text" />
                          </div>
                          <div class="label-input">
                            <label class="offscreen">상세주소</label>
                            <v-input v-model="cardForm.address3" type="text" />
                          </div>
                        </el-form-item>
                      </el-form>
                      <div class="btn-wrap">
                        <v-btn class="btn">변경취소</v-btn>
                        <v-btn class="btn">변경완료</v-btn>
                      </div>
                      <p class="bullet-star">
                        블루멤버스 제휴신용카드 신청자의 경우 현대카드㈜에서 별도 연락 후, HYUNDAI BLUE members Credit
                        카드,<br />HYUNDAI BLUE members Platinum 카드, HYUNDAI BLUE members Platinum Plus 카드 중 1개를
                        신청하실 수 있습니다.
                      </p>
                      <v-btn
                        type="link"
                        href="https://www.hyundaicard.com/ncb/cb/NCBCB0101_01.hc"
                        target="_blank"
                        title="새창열림"
                        class="btn white md r"
                        >현대카드 블루멤버스 전용카드 혜택 알아보기 ></v-btn
                      >
                    </div>
                  </li>
                </ul>
                <!-- PLCC 카드 -->
                <ul v-if="serviceCard === 'plcc'" class="desc-list">
                  <li>
                    <em>선택한 카드</em>
                    <div>
                      PLCC 카드
                      <p class="bullet-star full">
                        신차 구매부터 유지ㆍ관리ㆍ재구매까지, 전용카드만의 차별화된 혜택을 만나보세요.
                      </p>
                    </div>
                  </li>
                </ul>
                <!-- 모바일 카드 -->
                <ul v-if="serviceCard === 'mobile'" class="desc-list">
                  <li>
                    <em>선택한 카드</em>
                    <div>
                      모바일 카드
                      <p class="bullet-star full">
                        스마트폰 사용 고객이라면 카드 신청 없이 모바일에서 더욱 간편하게 블루멤버십 혜택을 누릴 수
                        있습니다.
                      </p>
                    </div>
                  </li>
                </ul>
              </div>
            </li>
            <li>
              <strong class="info-title">하이패스</strong>
              <div class="info-group">
                <p>{{ dispHipass }}</p>
                <ul class="bullet-star-list full">
                  <li>하이패스는 주행 중인 차 안에서 고속도로 통행료를 지불하는 시스템입니다.</li>
                  <li>장애인/국가유공자는 감면혜택 적용된 별도 단말기를 사용할 수 있습니다.</li>
                </ul>
              </div>
            </li>
            <li>
              <strong class="info-title">PLCC 카드</strong>
              <div class="info-group">
                <p>신청</p>
                <p class="bullet-star full">
                  신차 구매부터 유지ㆍ관리ㆍ재구매까지, 전용카드만의 차별화된 혜택을 만나보세요.
                </p>
              </div>
            </li>
            <li>
              <strong class="info-title">중고차 가격보장<br />서비스</strong>
              <div class="info-group">
                <p>신청</p>
                <p class="bullet-star full">
                  신차 구매부터 유지ㆍ관리ㆍ재구매까지, 전용카드만의 차별화된 혜택을 만나보세요.
                </p>
              </div>
            </li>
            <li>
              <strong class="info-title">어드밴티지<br />프로그램</strong>
              <div class="info-group">
                <p>신청안함</p>
                <p class="bullet-star full">
                  신차 구매부터 유지ㆍ관리ㆍ재구매까지, 전용카드만의 차별화된 혜택을 만나보세요.
                </p>
              </div>
            </li>
          </ul>
        </div>
        <p v-else>서비스 가입 및 신청 정보는 계약서 작성완료 이후 확인하실 수 있습니다.</p>
      </div>
    </div>

    <!-- 계약금 결제정보 -->
    <div class="box-wrap">
      <div class="box-tit full">계약금 결제정보</div>
      <div class="box-desc full">
        <div v-if="contractPaymentInfo" class="info-grid-list">
          <ul>
            <li>
              <strong class="info-title">결제수단</strong>
              <div class="info-group">
                <!-- 무통장입금 -->
                <ul v-if="paymentType" class="desc-list">
                  <li>무통장입금<v-btn type="nlink" to="/" class="btn-more">결제수단 변경하기</v-btn></li>
                  <li>
                    <em>결제자</em>
                    <span>{{ paymentName }}</span>
                  </li>
                  <li>
                    <em>입금계좌정보</em>
                    <span>{{ virtualAccount }}</span
                    ><span class="bank-company">{{ bankName }} {{ paymentStatusName }}</span>
                  </li>
                  <li>
                    <em>결제기한</em>
                    <span>{{ paymentLimitDate }} 까지</span><span class="state">입금대기</span>
                  </li>
                </ul>
                <!-- 카드결제 -->
                <ul v-else class="desc-list">
                  <li>신용카드</li>
                  <li>
                    <em>결제자</em>
                    <span>{{ paymentName }}</span>
                  </li>
                  <li>
                    <em>카드정보</em>
                    <span>{{ cardName }} / {{ installment }}</span>
                  </li>
                  <li>
                    <em>결제일</em>
                    <span>{{ paymentLimitDate }}</span>
                  </li>
                </ul>
              </div>
            </li>
            <li>
              <strong class="info-title">계약금</strong>
              <div class="info-group">{{ paymentAmount }} 원</div>
            </li>
          </ul>
        </div>
        <p v-else>계약금 결제 내역이 없습니다.</p>
      </div>
    </div>

    <!-- 할인정보 -->
    <div class="box-wrap">
      <div class="box-tit full">할인정보<v-btn type="nlink" to="/" class="btn-more">변경하기</v-btn></div>
      <div class="box-desc full">
        <div v-if="saleInfo" class="info-grid-list">
          <ul>
            <li>
              <strong class="info-title">직원 혜택</strong>
              <div class="info-group">
                <ul class="desc-list">
                  <li>
                    <em>근속연수 할인 26%</em>
                    <span class="price">(-) 100,000 원</span>
                  </li>
                  <li>
                    <em>무이자할부</em>
                    <span class="price">(-) 100,000 원</span>
                  </li>
                </ul>
              </div>
            </li>
            <li>
              <strong class="info-title">차량할인</strong>
              <div class="info-group">
                <ul class="desc-list">
                  <li>
                    <em>차량기본할인</em>
                    <span class="price">(-) 100,000 원</span>
                  </li>
                  <li>
                    <em>금리할인상품명</em>
                    <span class="price">(-) 100,000 원</span>
                  </li>
                  <li>
                    <em>생산월할인</em>
                    <span class="price">(-) 100,000 원</span>
                  </li>
                  <li>
                    <em>특별재고할인</em>
                    <span class="price">(-) 100,000 원</span>
                  </li>
                  <li>
                    <em>전시할인</em>
                    <span class="price">(-) 100,000 원</span>
                  </li>
                  <li>
                    <em>판촉할인</em>
                    <span class="price">(-) 100,000 원</span>
                  </li>
                </ul>
              </div>
            </li>
            <li>
              <strong class="info-title">특별조건할인</strong>
              <div class="info-group">
                <ul class="desc-list">
                  <li>
                    <em>특별조건할인조건명1</em>
                    <span class="price">(-) 100,000 원</span>
                  </li>
                  <li>
                    <em>특별조건할인조건명2</em>
                    <span class="price">(-) 100,000 원</span>
                  </li>
                </ul>
              </div>
            </li>
            <li>
              <strong class="info-title">온라인쿠폰</strong>
              <div class="info-group">
                <ul class="desc-list">
                  <li>
                    <em>쿠폰명</em>
                    <span class="price">(-) 100,000 원</span>
                  </li>
                  <li>
                    <em>쿠폰명</em>
                    <span class="price">(-) 100,000 원</span>
                  </li>
                </ul>
              </div>
            </li>
            <li>
              <strong class="info-title">지인추천할인</strong>
              <div class="info-group">
                <ul class="desc-list">
                  <li>
                    <em>XTS0135792HO</em>
                    <span class="price">(-) 100,000 원</span>
                  </li>
                </ul>
              </div>
            </li>
          </ul>
        </div>
        <p v-else>선택한 할인정보가 없습니다.</p>
      </div>
    </div>

    <!-- 자주하는 질문 -->
    <div class="box-wrap">
      <div class="box-tit full">자주하는 질문<v-btn type="nlink" to="/" class="btn-more">1:1 문의하기</v-btn></div>
      <div class="box-desc full">
        <div class="toggle-list">
          <v-list-group v-model="subSelected" :accordion="true">
            <v-list-item v-for="(item, index) in faqList" :key="index" :data-id="String(index + 1)">
              <template slot="label">
                <span class="list-category">{{ item.category }}</span>
                <span class="list-content"><span v-html="item.title"></span></span>
              </template>
              <div v-html="item.content"></div>
            </v-list-item>
          </v-list-group>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    // 계약 상세정보
    contractDetail: {
      type: Object,
      default: () => {}
    },
    // 계약금 결제정보
    paymentInfo: {
      type: Object,
      default: () => {}
    }
  },
  data() {
    return {
      // 계약기본정보
      contractInfo: true,
      contractorList: [
        {
          relationCode: '주계약자',
          sign: true,
          signDate: '2021.02.01 15:50',
          signBtn: false,
          relationPersonName: '김현대',
          inhabitantsIdentificationNumber: '210121-1******',
          mobilePhoneNumber1: '010',
          mobilePhoneNumber2: '1234',
          mobilePhoneNumber3: '5678',
          emailAddress: 'izzzz@naver.com',
          zipCode: '06719',
          addressContents: '서울특별시 서초구',
          detailAddressContents: '남부순환로 2415 (서초동) 123'
        },
        {
          relationCode: '공동명의자',
          sign: false,
          signBtn: true,
          relationPersonName: '이현대',
          inhabitantsIdentificationNumber: '210121-1******',
          mobilePhoneNumber1: '010',
          mobilePhoneNumber2: '1234',
          mobilePhoneNumber3: '5678',
          emailAddress: 'izzzz@naver.com',
          zipCode: '06719',
          addressContents: '서울특별시 서초구',
          detailAddressContents: '남부순환로 2415 (서초동) 123'
        }
      ],
      guarantyRepairTypeName: '기본형 (3년/6만㎞)',

      // 서비스 가입 및 신청 정보
      serviceInfo: true,
      serviceCard: 'members',
      membersChange: true,
      dispHipass: '자동등록 신청',
      taxFreeDisabilityName: '일반장애 1~3급',

      // 계약금 결제정보
      contractPaymentInfo: true,
      paymentType: true,
      paymentName: '김현대',
      virtualAccount: '900252282042',
      bankName: '신한은행',
      paymentStatusName: '',
      cardName: '현대카드',
      installment: '일시불',
      paymentLimitDate: '2021.02.01 12:30:39',
      paymentAmount: '100,000',

      saleInfo: true,

      subSelected: [],
      faqList: [
        {
          seq: 1,
          category: `[차량구매]`,
          title: `차량 계약 후 해지시 계약금은 환불 받을 수 있습니까?`,
          content: `<div class="faq-cont">즉시출고차, 할인차, 전시차, 판촉차, 생산주문 차량의 경우 차량 대금 결제 전, 마이페이지에서 계약 해약 시 계약금 환불이 가능합니다. 하지만 특별주문 차량의 경우 계약 해지시 계약금 환불이 불가합니다. 계약금을 현금으로 납부하셨다면 계약 해지시 입력하신 환불계좌로 계약금이 환불되며, 계약금을 카드로 납부하셨다면 7일 이내 카드 결제가 취소 됩니다.</div>`
        },
        {
          seq: 2,
          category: `[차량구매]`,
          title: `차량 구입시 신용카드는 여러개의 카드로 결제가 가능한가요?`,
          content: `<div class="faq-cont">즉시출고차, 할인차, 전시차, 판촉차, 생산주문 차량의 경우 차량 대금 결제 전, 마이페이지에서 계약 해약 시 계약금 환불이 가능합니다. 하지만 특별주문 차량의 경우 계약 해지시 계약금 환불이 불가합니다. 계약금을 현금으로 납부하셨다면 계약 해지시 입력하신 환불계좌로 계약금이 환불되며, 계약금을 카드로 납부하셨다면 7일 이내 카드 결제가 취소 됩니다.</div>`
        },
        {
          seq: 3,
          category: `[차량구매]`,
          title: `장애인 면세 공동명의로 차량 구입하려고 하는데 장애인을 외1인으로 해도 되나요?`,
          content: `<div class="faq-cont">즉시출고차, 할인차, 전시차, 판촉차, 생산주문 차량의 경우 차량 대금 결제 전, 마이페이지에서 계약 해약 시 계약금 환불이 가능합니다. 하지만 특별주문 차량의 경우 계약 해지시 계약금 환불이 불가합니다. 계약금을 현금으로 납부하셨다면 계약 해지시 입력하신 환불계좌로 계약금이 환불되며, 계약금을 카드로 납부하셨다면 7일 이내 카드 결제가 취소 됩니다.</div>`
        }
      ],
      cardForm: {
        address: '',
        address2: '',
        address3: ''
      }
    }
  },
  computed: {
    rules() {
      return {
        address: [
          {
            required: true,
            message: '* 주소를 입력해 주세요.',
            trigger: 'blur'
          }
        ]
      }
    }
  }
}
</script>
