<template>
  <div class="matching-box take-over">
    <!-- 인수정보 -->
    <div class="box-wrap">
      <div class="box-tit">
        인수자 정보
        <v-btn type="nlink" to="/" class="btn-more">변경하기</v-btn>
      </div>
      <div class="box-desc full">
        <div class="info-grid-list">
          <ul>
            <li>
              <strong class="info-title">인수자</strong>
              <div class="info-group">{{ acceptorName }}</div>
              <!-- asis -->
              <!-- <span>{{ acquisitionInfo.acceptorName || '-' }}</span> -->
            </li>
            <li>
              <strong class="info-title">인수자 연락처</strong>
              <div class="info-group">{{ acceptorTelephonNumber }}</div>
              <!-- asis -->
              <!-- <span>{{ acquisitionInfo.acceptorTelephonNumber || '-' }}</span> -->
            </li>
            <li>
              <strong class="info-title">인수자 주소</strong>
              <div class="info-group">
                <ul class="desc-list">
                  <li>
                    {{ acceptorCenterAddress }}<span class="state">{{ acceptorState }}</span>
                  </li>
                  <li>({{ acceptorZipCode }}) {{ acceptorCenterAddressDetail }}</li>
                </ul>
              </div>
              <!-- asis -->
              <!-- <span>{{ acquisitionInfo.acceptorZipCode && `(${acquisitionInfo.acceptorZipCode})` }} {{ acquisitionInfo.acceptorCenterAddress || '-' }} {{ acquisitionInfo.acceptorCenterAddressDetail }}</span> -->
            </li>
            <li>
              <strong class="info-title">기타 요청 사항</strong>
              <div class="info-group">{{ etcContent }}</div>
              <!-- asis -->
              <!-- <span>{{ acquisitionInfo.etcContent || '-' }}</span> -->
            </li>
          </ul>
        </div>
      </div>
    </div>

    <!-- 배달탁송 내역 -->
    <div class="box-wrap">
      <div class="box-tit">
        배달탁송 내역
      </div>
      <div class="box-desc full">
        <!-- 배송시작, 완료 -->
        <div class="info-grid-list">
          <ul>
            <li>
              <strong class="info-title">탁송사</strong>
              <div class="info-group">{{ deliveryCompany }}</div>
              <!-- asis -->
              <!-- <span>{{ shipmentMonitoring.DLV_CNSG_ORG_NM || '-' }}</span> -->
            </li>
            <li class="t-blue">
              <strong class="info-title">도착예정일</strong>
              <div class="info-group">{{ deliveryDate }}</div>
              <!-- asis -->
              <!-- <strong>{{ shipmentMonitoring.ARV_PARR_YMD }} {{ shipmentMonitoring.ARV_PARR_CTMS }}</strong> -->
            </li>
            <li class="t-blue">
              <strong class="info-title">도착일</strong>
              <div class="info-group">{{ deliveryCompleteDate }}</div>
            </li>
          </ul>
          <div class="map-view">
            <div style="height:480px;background:#f9f9f9">지도영역</div>
          </div>
          <p class="bullet-star">배달탁송 상태는 교통 및 날씨 상황에 따라 변경될 수 있습니다.</p>
          <div class="table-area">
            <table class="noline">
              <colgroup>
                <col width="140px" />
                <col width="415px" />
                <col width="" />
              </colgroup>
              <thead>
                <tr>
                  <th scope="col">일시</th>
                  <th scope="col">현재 위치</th>
                  <th scope="col">배달탁송 상태</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>{{ deliveryStateDate }}</td>
                  <td>{{ deliveryCurrentLocation }}</td>
                  <td>{{ deliveryStatus }}</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        <!-- 정보없음 -->
        <div class="table-area">
          <table class="noline">
            <colgroup>
              <col width="140px" />
              <col width="415px" />
              <col width="" />
            </colgroup>
            <thead>
              <tr>
                <th scope="col">일시</th>
                <th scope="col">현재 위치</th>
                <th scope="col">배달탁송 상태</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td colspan="3">
                  배달탁송 정보가 없습니다.
                </td>
              </tr>
            </tbody>
          </table>
        </div>

        <!-- 데이터미전송 -->
        <div class="table-area">
          <table class="noline">
            <colgroup>
              <col width="140px" />
              <col width="415px" />
              <col width="" />
            </colgroup>
            <thead>
              <tr>
                <th scope="col">일시</th>
                <th scope="col">현재 위치</th>
                <th scope="col">배달탁송 상태</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>안내 예정</td>
                <td>현재 위치를 확인 중입니다.</td>
                <td>배달탁송 시작</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>

    <!-- 차량보관장소 -->
    <div class="box-wrap">
      <div class="box-tit">
        차량보관장소
      </div>
      <div class="box-desc full">
        <div class="info-grid-list">
          <ul>
            <li>
              <strong class="info-title">지점명</strong>
              <div class="info-group">{{ agencyName }}</div>
              <!-- asis -->
              <!-- <td>{{ displayCarAgency.agencyName || '-' }}</td> -->
            </li>
            <li>
              <strong class="info-title">대표전화번호</strong>
              <div class="info-group">{{ agencyTel }}</div>
              <!-- asis -->
              <!-- <td>{{ displayCarAgency.agencyTel || '-' }}</td> -->
            </li>
            <li>
              <strong class="info-title">지점 주소</strong>
              <div class="info-group">{{ agencyAddress }}</div>
              <!-- asis -->
              <!-- <td>{{ displayCarAgency.agencyAddress || '-' }}</td> -->
              <v-btn class="last btn-more">지도 인쇄하기</v-btn>
            </li>
          </ul>
        </div>
        <div class="map-view">
          <div style="height:480px;background:#f9f9f9">지도영역</div>
        </div>
        <p class="bullet-star">반드시 방문 전 대표전화로 연락 후, 방문해 주시기 바랍니다.</p>
      </div>
    </div>

    <!-- 선택형 서비스 구매 내역 -->
    <div class="box-wrap">
      <div class="box-tit">
        선택형 서비스 구매 내역
      </div>
      <div class="box-desc full">
        <div class="table-area">
          <table class="noline">
            <colgroup>
              <col width="120px" />
              <col width="158px" />
              <col />
              <col width="156px" />
              <col width="120px" />
            </colgroup>
            <thead>
              <tr>
                <th>서비스 유형</th>
                <th>서비스명</th>
                <th>서비스 내용</th>
                <th>차감 포인트</th>
                <th>결제상태</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>{{ productType }}</td>
                <td>{{ productName }}</td>
                <td>{{ productDesc }}</td>
                <td class="t-right">{{ salePrice }} P</td>
                <td>{{ orderStatusName }}</td>
              </tr>
              <tr>
                <td colspan="5">
                  선택형 서비스 구매 내역이 없습니다.
                </td>
              </tr>
            </tbody>
            <!-- asis -->
            <!-- <tbody v-if="!serviceMultipleChoiceData || serviceMultipleChoiceData.length == 0">
              <tr>
                <td colspan="5">
                  선택형 서비스 구매 내역이 없습니다.
                </td>
              </tr>
            </tbody>
            <tbody v-else>
              <template v-for="(service, idx) in serviceMultipleChoiceData">
                <tr :key="`row1-${idx}`">
                  <td>서비스 유형명</td>
                  <td>{{ service.productName }}</td>
                  <td>{{ service.productDesc }}</td>
                  <td class="t-right">{{ service.salePrice | currency }} P</td>
                  <td>{{ service.orderStatusName }}</td>
                </tr>
              </template>
            </tbody> -->
          </table>
        </div>
        <p class="bullet-star">
          선택형 서비스는 결제완료 이후 자동차제작증 발급 전까지만 블루멤버스 포인트로 구입/변경/취소가 가능합니다.
        </p>
      </div>
    </div>

    <!-- 면세신고내역 -->
    <div class="box-wrap">
      <div class="box-tit">
        면세신고 내역
      </div>
      <div class="box-desc full">
        <div class="table-area">
          <table class="noline">
            <colgroup>
              <col width="259px" />
              <col />
              <col width="258px" />
            </colgroup>
            <thead>
              <tr>
                <th>자동차 제작증 발급일</th>
                <th>진행 상태</th>
                <th>신고 결과</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>{{ tacCertifiDate }}</td>
                <td>{{ needPapersStatusName }}</td>
                <td>{{ taxFreeApprovalYn }}</td>
              </tr>
              <tr>
                <td colspan="3">면세신고 정보가 없습니다.</td>
              </tr>

              <!-- asis -->
              <!-- <tr v-if="contractDetail.carMakeCertificateIssueYn == 'Y'">
                <td>{{ tacCertifiDate }}</td>
                <td>{{ contractDetail.needPapersStatusName }}</td>
                <td>{{ contractDetail.taxFreeApprovalYn == 'Y' ? '완료' : '미완료' }}</td>
              </tr>
              <tr v-else>
                <td colspan="3">면세신고 정보가 없습니다.</td>
              </tr> -->
            </tbody>
          </table>
        </div>
        <p class="bullet-star">
          면세신고 작성 및 접수는 차량등록 이후부터 가능합니다. 차량등록 및 증빙서류 승인 과정을 포함하여 면세 신고 기한
          내 면세 신고를 완료해 주시기 바랍니다.
        </p>
      </div>
    </div>

    <!-- 자주하는 질문 -->
    <div class="box-wrap">
      <div class="box-tit full">자주하는 질문<v-btn type="nlink" to="/" class="btn-more">1:1 문의하기</v-btn></div>
      <div class="box-desc full">
        <div class="toggle-list">
          <v-list-group v-model="subSelected" :accordion="true">
            <v-list-item v-for="(item, index) in faqList" :key="index" :data-id="String(index + 1)">
              <template slot="label">
                <span class="list-category">{{ item.category }}</span>
                <span class="list-content"><span v-html="item.title"></span></span>
              </template>
              <div v-html="item.content"></div>
            </v-list-item>
          </v-list-group>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    // 계약상세정보
    contractDetail: {
      type: Object,
      default: () => {
        return {}
      }
    },
    onlineContractState: {
      type: String,
      default: ''
    },
    onlineContractStateCode: {
      type: String,
      default: ''
    },
    serviceMultipleChoiceData: {
      type: Array,
      default: () => {
        return []
      }
    }
  },
  data() {
    return {
      paymentHistory: true,

      // 인수정보
      acceptorName: '박창석 (주계약자)',
      acceptorTelephonNumber: '010-1234-5678',

      acceptorState: '차량 검수 패기지 신청',
      acceptorCenterAddress: '[블루핸즈] (주)강남정비센타',
      acceptorZipCode: '06719',
      acceptorCenterAddressDetail: '서울특별시 서초구 남부순환로 2415 (서초동) 123',
      etcContent: '도착 30분 전 전화 주세요.',

      // 배달탁송내역
      deliveryCompany: '현대글로비스',
      deliveryDate: '2021년 2월 5일 12시경 도착예정입니다.',
      deliveryStateDate: '2021.02.01 12:30',
      deliveryCurrentLocation: '광주공장',
      deliveryStatus: '배달탁송 시작',
      deliveryCompleteDate: '2021년 2월 5일 12시경 도착하였습니다.',

      // 차량보관장소
      agencyName: '현대자동차 강남대로지점',
      agencyTel: '02-3461-1990',
      agencyAddress: '서울특별시 강남구 강남대로 292',

      // 선택형 서비스 구매 내역
      productType: '서비스 유형명',
      productName: '서비스명',
      productDesc: '1년 또는 2만 km 선 도래',
      salePrice: '30,000',
      orderStatusName: '구매대기',

      // 면세신고 내역
      tacCertifiDate: '2021.03.02',
      needPapersStatusName: '심사승인',
      taxFreeApprovalYn: '미완료',
      takeoverHistory: true,

      subSelected: [],
      faqList: [
        {
          seq: 1,
          category: `[인수]`,
          title: `인수 단계에서 자주하는 질문`,
          content: `<div class="faq-cont">인수 단계에서 자주하는 질문결제 단계에서 자주하는 질문결제 단계에서 자주하는 질문결제 단계에서 자주하는 질문</div>`
        },
        {
          seq: 2,
          category: `[인수]`,
          title: `인수 단계에서 자주하는 질문`,
          content: `<div class="faq-cont">인수 단계에서 자주하는 질문</div>`
        },
        {
          seq: 3,
          category: `[인수]`,
          title: `인수 단계에서 자주하는 질문`,
          content: `<div class="faq-cont">인수 단계에서 자주하는 질문결제 단계에서 자주하는 질문결제 단계에서 자주하는 질문결제 단계에서 자주하는 질문결제 단계에서 자주하는 질문결제 단계에서 자주하는 질문</div>`
        }
      ]
    }
  },
  computed: {
  },
  updated() {
    if (this.visible) {
      this.setCaption()
    }
  },
}
</script>
