<template>
  <div class="matching-box">
    <!-- 결제금액 -->
    <div class="box-wrap">
      <div class="box-tit">
        결제금액
      </div>
      <div class="box-desc full">
        <div class="info-grid-list">
          <ul>
            <li>
              <strong class="info-title">차량금액</strong>
              <div class="info-group">
                <ul class="desc-list">
                  <li>
                    <em>총 차량가격</em>
                    <span class="price">{{ carAmount }} 원</span>
                  </li>
                  <li>
                    <em>{{ detailCarName }}</em>
                    <span class="price">{{ detailNormalCarPrice }} 원</span>
                  </li>
                  <li>
                    <em>{{ exteriorColorName }}</em>
                    <span class="price">{{ exteriorColorNormalCarPrice }} 원</span>
                  </li>
                  <li>
                    <em>{{ interiorColorName }}</em>
                    <span class="price">{{ interiorColorNormalCarPrice }} 원</span>
                  </li>
                  <li v-for="(option, index) in optionData" :key="index" :class="option.class">
                    <em>{{ option.optionName }}</em>
                    <span class="price">{{ option.optionPrice }} 원</span>
                  </li>
                </ul>
              </div>
            </li>
            <li>
              <strong class="info-title"></strong>
              <div class="info-group">
                <ul class="desc-list">
                  <li>
                    <em>선지급금액(계약금)</em>
                    <span class="price">(-) 100,000 원</span>
                  </li>
                  <li>
                    <em>세액 감면 혜택</em>
                    <span class="price">(-) 400,000 원</span>
                  </li>
                  <li>
                    <em>할인금액</em>
                    <span class="price">(-) 1,000,000 원</span>
                  </li>
                  <li>
                    <em>탁송료</em>
                    <span class="price">300,000 원</span>
                  </li>
                  <li>
                    <em>단기의무보험료</em>
                    <span class="price">2,300 원</span>
                  </li>
                  <li>
                    <em>할부인지대</em>
                    <span class="price">3,000원</span>
                  </li>
                </ul>
              </div>
            </li>
            <li class="total-price">
              <strong class="info-title">총 결제금액</strong>
              <div class="info-group">
                <div class="last">
                  <span class="t-blue">할인 {{ discountRate }}%</span>
                  <strong class="price bold">{{ totalPaymentAmount }}</strong> 원
                </div>
                <div class="bluemembers">
                  <em>블루멤버스 적립포인트</em>
                  <span>{{ blueMembersPrearrangementPoint }} P</span>
                </div>
              </div>
            </li>
          </ul>
        </div>
      </div>
    </div>

    <!-- 결제내역 -->
    <div class="box-wrap">
      <div class="box-tit">
        결제내역
      </div>
      <div class="box-desc full">
        <div v-if="paymentHistory" class="info-grid-list payment-info">
          <ul>
            <li>
              <div class="info-title full">
                <span class="date">2021.01.04</span>
                <span class="type">계약금 결제</span>
                <span>100,000 원</span>
                <v-btn type="icon" class="btn" :icon-class="['icon-tog-arr', { on: isAct(0) }]" @click="setAct(0)"
                  ><span class="offscreen">상세보기</span></v-btn
                >
              </div>
              <div v-if="isAct(0)" class="info-group full">
                <ul class="desc-list">
                  <li>
                    <em>신용카드</em>
                    <span class="number"
                      >9042-****-****-**** <span class="card-company">신한카드</span> <span>일시불</span></span
                    >
                    <span class="current">승인완료</span>
                    <span class="price">1,000,000 원</span>
                  </li>
                </ul>
              </div>
            </li>
            <li>
              <div class="info-title full">
                <span class="date">2021.01.04</span>
                <span class="type">차량대금 결제</span>
                <span>21,800,000 원</span>
                <v-btn type="icon" class="btn" :icon-class="['icon-tog-arr', { on: isAct(1) }]" @click="setAct(1)"
                  ><span class="offscreen">상세보기</span></v-btn
                >
              </div>
              <div v-if="isAct(1)" class="info-group full">
                <ul class="desc-list">
                  <li class="point">
                    <em>포인트</em>
                    <ul>
                      <li>
                        <strong class="type">블루멤버스 포인트</strong>
                        <ul>
                          <li>
                            박창석<span class="current complete">사용완료</span><span class="price">1,000,000 원</span>
                          </li>
                          <li>
                            이숙영<span class="current complete">사용완료</span><span class="price">1,000,000 원</span>
                          </li>
                        </ul>
                      </li>
                      <li>
                        <strong class="type">M포인트</strong>
                        <ul>
                          <li>
                            박창석<span class="current complete">사용완료</span><span class="price">1,000,000 원</span>
                          </li>
                          <li>
                            김호중<span class="current complete">사용완료</span><span class="price">1,000,000 원</span>
                          </li>
                          <li>
                            이희준<span class="current complete">사용완료</span><span class="price">1,000,000 원</span>
                          </li>
                        </ul>
                      </li>
                    </ul>
                  </li>
                  <li class="cash">
                    <em>현금</em>
                    <ul>
                      <li>
                        <strong class="type full">무통장입금</strong>
                        <v-btn class="btn-more">결제수단 변경하기</v-btn>
                        <ul class="full">
                          <li>
                            <span class="number">9042-****-****-**** <span class="card-company">신한카드</span></span>
                            <span>홍길동_현대자동차</span>
                            <span class="current">입금대기중</span>
                            <span class="price">3,000,000 원</span>
                          </li>
                        </ul>
                      </li>
                    </ul>
                  </li>
                  <li class="credit-card">
                    <em>신용카드</em>
                    <ul>
                      <li>
                        <span class="number">9042-****-****-**** <span class="card-company">신한카드</span></span>
                        <span>일시불</span>
                        <span class="current">승인요청중</span>
                        <span class="price">1,000,000 원</span>
                      </li>
                      <li>
                        <span class="number">9042-****-****-**** <span class="card-company">현대카드</span></span>
                        <ul class="">
                          <li>
                            <span>일시불 /<br />캐시백 0.5%</span>
                            <span class="current">승인요청중</span>
                            <span class="price">1,000,000 원</span>
                          </li>
                          <li>
                            <span>세이브-오토</span>
                            <span class="current complete">승인완료</span>
                            <span class="price">1,000,000 원</span>
                          </li>
                        </ul>
                      </li>
                    </ul>
                  </li>
                </ul>
              </div>
            </li>
          </ul>
        </div>
        <p v-else>결제 내역이 없습니다.</p>
      </div>
    </div>

    <!-- 할부내역 -->
    <div class="box-wrap">
      <div class="box-tit">
        할부내역
      </div>
      <div class="box-desc full">
        <div class="info-grid-list">
          <ul>
            <li>
              <strong class="info-title">할부 상한계획</strong>
              <div class="info-group">
                <v-btn type="nlink" to="/" class="btn-more">조회하기</v-btn>
              </div>
            </li>
            <li>
              <strong class="info-title">할부정보</strong>
              <div class="info-group">
                <ul class="desc-list">
                  <li>
                    <em>할부상품</em>
                    <span class="last">{{ installmentName }}</span>
                    <!-- asis -->
                    <!-- <span>{{ item.installmentName }}</span> -->
                  </li>
                  <li>
                    <em>할부원금</em>
                    <div class="last">
                      <ul>
                        <li><span class="price">{{ installmentAmount }} 원</span></li>
                        <li><em>실 납입 할부금</em><span class="price">{{ totalPrice }} 원</span></li>
                      </ul>
                    </div>
                    <!-- asis -->
                    <!-- <span>{{ item.installmentAmount | currency }} 원</span> -->
                  </li>
                  <li>
                    <em>할부기간</em>
                    <span class="last">{{ installmentMonthCount }} 개월</span>
                    <!-- asis -->
                    <!-- <span>{{ item.installmentMonthCount }} 개월</span> -->
                  </li>
                </ul>
              </div>
            </li>
            <li class="total-price">
              <strong class="info-title">월 납입금</strong>
              <div class="info-group">
                <div class="last">
                  <span class="t-blue">금리 3.5%</span>
                  월 <strong class="price bold">87,000</strong> 원
                </div>
              </div>
            </li>
          </ul>
        </div>
      </div>
    </div>

    <!-- 자주하는 질문 -->
    <div class="box-wrap">
      <div class="box-tit full">자주하는 질문<v-btn type="nlink" to="/" class="btn-more">1:1 문의하기</v-btn></div>
      <div class="box-desc full">
        <div class="toggle-list">
          <v-list-group v-model="subSelected" :accordion="true">
            <v-list-item v-for="(item, index) in faqList" :key="index" :data-id="String(index + 1)">
              <template slot="label">
                <span class="list-category">{{ item.category }}</span>
                <span class="list-content"><span v-html="item.title"></span></span>
              </template>
              <div v-html="item.content"></div>
            </v-list-item>
          </v-list-group>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  props: {
  },
  data() {
    return {
      paymentHistory: true,
      listSelected: [false, false],

      // 결제금액
      carAmount: '20,000,000',
      detailCarName: '차량모델',
      detailNormalCarPrice: '18,500,000',
      exteriorColorName: '외장색상명',
      exteriorColorNormalCarPrice: '0',
      interiorColorName: '내장색상명',
      interiorColorNormalCarPrice: '0',
      optionData: [
        { optionName: '옵션1', optionPrice: '100,000' },
        { optionName: '옵션2', optionPrice: '50,000' },
      ],
      discountRate: '17.5',
      totalPaymentAmount: '12,827,100',
      blueMembersPrearrangementPoint: '41,719',

      // 할부정보
      installmentName: '표준형',
      installmentAmount: '1,000,000',
      totalPrice: '18,500,000',
      installmentMonthCount: '36',

      subSelected: [],
      faqList: [
        {
          seq: 1,
          category: `[결제]`,
          title: `결제 단계에서 자주하는 질문`,
          content: `<div class="faq-cont">결제 단계에서 자주하는 질문결제 단계에서 자주하는 질문결제 단계에서 자주하는 질문결제 단계에서 자주하는 질문</div>`
        },
        {
          seq: 2,
          category: `[결제]`,
          title: `결제 단계에서 자주하는 질문`,
          content: `<div class="faq-cont">결제 단계에서 자주하는 질문</div>`
        },
        {
          seq: 3,
          category: `[결제]`,
          title: `결제 단계에서 자주하는 질문`,
          content: `<div class="faq-cont">결제 단계에서 자주하는 질문결제 단계에서 자주하는 질문결제 단계에서 자주하는 질문결제 단계에서 자주하는 질문결제 단계에서 자주하는 질문결제 단계에서 자주하는 질문</div>`
        }
      ]
    }
  },
  methods: {
    setAct(index) {
      if (this.listSelected[index] === false) {
        this.$set(this.listSelected, index, true)
      } else {
        this.$set(this.listSelected, index, false)
      }
    },
    isAct(index) {
      return this.listSelected[index] === true
    }
  }
}
</script>
