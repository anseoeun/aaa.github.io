<template>
  <v-popup
    :visible="visible"
    :width="'776px'"
    @close="
      $emit('close')
      popVisible = false
    "
  >

    <template slot="header">
      <div class="title">선택형 서비스 구매하기</div>
    </template>
    <template slot="body">
      <p class="contents-head">블루멤버스 포인트 안내</p>
      <ul class="plan-info">
        <li>
          <p class="title">차량 구매회차(이번 구매 포함)</p>
          <p class="description"><span>7</span>회</p>
        </li>
        <li>
          <p class="title">보유 포인트(실시간)</p>
          <p class="description"><span>10,000</span> P</p>
        </li>
        <li>
          <p class="title">이번 적립 포인트</p>
          <p class="description t-blue"><span>150,000</span> P</p>
        </li>
      </ul>
      <div class="body-contents bbnone">
        <div class="form-grid-list select-service">
          <div class="title"><span class="bold">선택형 서비스 신청</span><v-btn class="btn-more">조회하기</v-btn></div>
          <ul class="half">
            <li>
              <strong class="form-label">서비스 유형</strong>
              <div class="form-group">
                <v-select
                  v-model="selectServiceType"
                  :data="selectServiceTypeList"
                  placeholder="선택"
                />
              </div>
            </li>
            <li>
              <strong class="form-label">서비스명</strong>
              <div class="form-group">
                <v-select
                  v-model="selectServiceName"
                  :data="selectServiceNameList"
                  placeholder="선택"
                />
              </div>
            </li>
          </ul>
          <p class="bullet-star">선택형 서비스는 이번 적립 포인트로만 구매 가능합니다.</p>
        </div>


        <div class="table-area">
          <div class="table-top">
            <strong class="title">서비스 내역</strong>
            <v-btn class="btn-more">신청하기</v-btn>
          </div>
          <table class="noline-in">
            <colgroup>
              <col width="113px" />
              <col width="113px" />
              <col width="113px" />
              <col width="113px" />
              <col />
            </colgroup>
            <thead>
              <tr>
                <th scope="col">선택</th>
                <th scope="col">서비스 유형</th>
                <th scope="col">서비스명</th>
                <th scope="col">차감포인트</th>
                <th scope="col">서비스 내용</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="(item, idx) in serviceList" :key="idx">
                <td><v-checkbox :one-check="true" :checked.sync="item.isAgree"></v-checkbox></td>
                <td>{{ item.serviceType }}</td>
                <td>{{ item.serviceName }}</td>
                <td class="right">{{ item.point }} P</td>
                <td>{{ item.content }}</td>
              </tr>
            </tbody>
          </table>
        </div>

        <div class="table-area">
          <div class="table-top">
            <strong class="title">서비스 구매 신청 내역</strong>
          </div>
          <table class="noline-in">
            <colgroup>
              <col width="113px" />
              <col width="225px" />
              <col width="113px" />
              <col width="113px" />
              <col />
            </colgroup>
            <thead>
              <tr>
                <th scope="col">서비스 유형</th>
                <th scope="col">서비스명</th>
                <th scope="col">차감포인트</th>
                <th scope="col">결제상태</th>
                <th scope="col"></th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="(item, index) in serviceApplicationList" :key="index">
                <td>{{ item.serviceType }}</td>
                <td>{{ item.serviceName }}</td>
                <td class="right">{{ item.point }} P</td>
                <td>{{ item.state }}</td>
                <td>
                  <v-btn class="btn-more">취소하기</v-btn>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </template>
    <template slot="footer">
      <div class="btn-group">
        <v-btn class="btn btn-gray" b-size="btn-md" b-color="btn-gray">취소</v-btn>
        <v-btn class="btn" b-size="btn-md">신청완료</v-btn>
      </div>
    </template>
  </v-popup>
</template>

<script>
import { VPopup } from '~/components/element'
export default {
  components: {
    VPopup,
  },
  props: {
    visible: {
      type: Boolean,
      default: false
    },
  },
  data() {
    return {
      selectServiceType: '',
      selectServiceTypeList: [
        { value: 'service1', label: '서비스1' },
        { value: 'service2', label: '서비스2' },
      ],
      selectServiceName: '',
      selectServiceNameList: [
        { value: 'servicename1', label: '서비스명1' },
        { value: 'servicename2', label: '서비스명2' },
      ],
      serviceList: [
        {
          isAgree: false,
          serviceType: '서비스 유형명',
          serviceName: '서비스 유형명',
          point: '00,000',
          content: '서비스내용서비스내용'
        },
        {
          isAgree: false,
          serviceType: '서비스 유형명',
          serviceName: '서비스 유형명',
          point: '00,000',
          content: '서비스내용서비스내용'
        },
      ],
      serviceApplicationList: [
        {
          serviceType: '서비스 유형명',
          serviceName: '서비스유형명 서비스유형명',
          point: '00,000',
          state: '결제대기'
        }
      ]
    }
  },
  updated() {
    if (this.visible) {
      this.setCaption()
    }
  },
}
</script>