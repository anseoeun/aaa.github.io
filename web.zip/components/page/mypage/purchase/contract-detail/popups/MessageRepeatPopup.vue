<template>
  <v-popup
    :visible="visible"
    :width="'550px'"
    :footer="['confirm']"
    @close="
      $emit('close')
      popVisible = false
    "
    @confirm="
      $emit('close')
      popVisible = false
    "
  >

    <template slot="header">
      <div class="title">전자서명 메시지 재전송</div>
      <p class="header-description">전자서명을 아직 하지 않은 명의자를 확인해 주세요.<br />[전송] 버튼을 클릭하시면 해당 명의자의 휴대전화로 메시지가 전송됩니다.</p>
    </template>
    <template slot="body">
      <div class="table-area">
        <table class="noline">
          <colgroup>
            <col width="113px" />
            <col width="auto" />
            <col width="113px" />
          </colgroup>
          <tbody>
            <tr>
              <th class="bold">박창석</th>
              <td class="left"><strong>전자서명 완료</strong></td>
              <td class="right"></td>
            </tr>
            <tr>
              <th class="bold">김효중</th>
              <td class="left"><strong>전자서명 완료</strong></td>
              <td class="right"></td>
            </tr>
            <tr>
              <th class="bold">이숙영</th>
              <td class="left">전자서명 미완료</td>
              <td class="right"><v-btn class="btn-more" type="nlink">전송하기</v-btn></td>
            </tr>
            <tr>
              <th class="bold">이희준</th>
              <td class="left">전자서명 미완료</td>
              <td class="right"><v-btn class="btn-more" type="nlink">전송하기</v-btn></td>
            </tr>
          </tbody>
        </table>
      </div>
    </template>
  </v-popup>
</template>

<script>
import { VPopup } from '~/components/element'
export default {
  components: {
    VPopup
  },
  props: {
    visible: {
      type: Boolean,
      default: false
    },
  },
  updated() {
    if (this.visible) {
      this.setCaption()
    }
  },
}
</script>