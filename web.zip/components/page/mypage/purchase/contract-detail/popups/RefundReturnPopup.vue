<template>
  <v-popup
    :visible="visible"
    :width="'776px'"
    @close="
      $emit('close')
      popVisible = false
    "
  >
    <template slot="header">
      <div class="title">반품 및 환불 문의</div>

      <!-- 2021.04.05 (ver1.1) 텍스트 수정 -->
      <p class="header-description">차량인수 확정 후 단순변심으로 인한 환불 시 왕복탁송료가 부과됩니다.</p>
    </template>
    <template slot="body">
      <div class="inquire-form">
        <ul class="bullet-list">
          <li>문의를 등록하시면 주계약자의 연락처로 연락을 드립니다.</li>
          <li>문의하신 내용은 마이페이지&gt;1:1 문의내역에서 확인하실 수 있습니다.</li>
        </ul>
        <el-form ref="askForm" :model="askForm" :rules="rules" label-position="top" class="body-contents bktop">
          <div class="form-grid-list">
            <ul>
              <li>
                <div class="form-label">반품 및 환불 사유</div>
                <div class="form-group">
                  <el-form-item prop="bigOPtionValue">
                    <v-select v-model="askForm.bigOPtionValue" :data="askForm.bigOPtion" />
                  </el-form-item>
                </div>
              </li>
              <li class="label-input">
                <div class="form-label">
                  <label>문의 내용</label>
                  <div class="txt-count">
                    ( <span class="txt-blue">{{ askForm.textCount }}</span
                    >자/2000자 )
                  </div>
                </div>
                <div class="form-group">
                  <el-form-item label="" prop="counsel" required>
                    <v-input
                      v-model="askForm.counsel"
                      type="textarea"
                      :rows="13"
                      placeholder="문의내용을 입력하여 주세요 (최대 2,000자)"
                      maxlength="2000"
                      @input="checkText"
                    />
                  </el-form-item>
                </div>
              </li>
              <li class="label-input file-attach">
                <div class="form-label"><label>파일첨부</label></div>
                <div class="form-group">
                  <div class="file-upload-wrap">
                    <div class="file-upload">
                      <div class="file-input">
                        <input ref="fileInput" type="file" class="offscreen" @change="changeFile" />
                        <v-input v-model="fileVal" class="file-value" />
                        <v-btn class="btn-file-delete" type="button" @click="fileDelete"><span>파일삭제</span></v-btn>
                      </div>
                      <v-btn class="file-btn btn-more" type="button" @click="fileOpen">파일찾기</v-btn>
                    </div>
                    <ul class="bullet-list">
                      <!-- 2021.04.05 (ver1.1) 텍스트 수정 -->
                      <li>jpg, gif, png, pdf 파일만 첨부 가능합니다.</li>
                      <li>첨부파일은 최대 3MB를 초과할 수 없으며, 1개 등록하실 수 있습니다.</li>
                      <li>문의 내용과 무관한 파일이거나 불법적인 내용은 통보없이 삭제될 수 있습니다.</li>
                    </ul>
                  </div>
                </div>
              </li>
            </ul>
          </div>
        </el-form>
      </div>
    </template>
    <template slot="footer">
      <div class="btn-group">
        <v-btn class="btn btn-gray" b-size="btn-md" b-color="btn-gray">취소</v-btn>
        <v-btn class="btn" b-size="btn-md">등록</v-btn>
      </div>
    </template>
  </v-popup>
</template>

<script>
import { VPopup } from '~/components/element'
export default {
  components: {
    VPopup
  },
  props: {
    visible: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      askForm: {
        textCount: 0,
        bigOPtionValue: '',
        bigOPtion: [
          {
            value: '',
            label: '사유를 선택해 주세요.'
          },
          {
            value: 'Option1',
            label: '사유1'
          },
          {
            value: 'Option2',
            label: '사유2'
          }
        ]
      },
      fileVal: ''
    }
  },
  computed: {
    rules() {
      return {
        bigOPtionValue: [{ required: true, message: '* 반품 및 환불 사유를 선택해 주세요.', trigger: 'change' }],
        counsel: [
          {
            required: true,
            message: '* 문의내용을 입력해 주세요.',
            trigger: ['blur', 'change']
          }
        ]
      }
    }
  },
  updated() {
    this.setLabel((idg) => {
      //console.dir(idg) // 자동 생성된 ID 배열
    })
  },
  methods: {
    changeFile(e) {
      var files = e.target.files || e.dataTransfer.files
      this.fileVal = files[0].name
    },
    fileDelete() {
      this.$refs.fileInput.value = ''
      this.fileVal = ''
    },
    fileOpen() {
      this.$refs.fileInput.click()
    },
    checkText() {
      this.askForm.textCount = this.askForm.counsel.length
    }
  }
}
</script>
