<template>
  <v-popup
    :visible="visible"
    :width="'776px'"
    @close="
      $emit('close')
      popVisible = false
    "
  >

    <template slot="header">
      <div class="title">계약금 결제</div>
    </template>
    <template slot="body">
      <p class="contents-head">계약금 결제수단 변경</p>
      <div class="body-contents bktop">
        <el-form ref="form" :rules="rules">
          <div class="form-grid-list payment">
            <ul>
              <li>
                <strong class="form-label">결제자</strong>
                <div class="form-group">
                  <v-select
                    v-model="ownerNm"
                    :data="ownerNmList"
                    placeholder="선택"
                  />
                </div>
              </li>
              <li>
                <strong class="form-label">결제수단</strong>
                <div class="form-group">
                  <ul class="desc-list">
                    <li><v-btn class="btn black md r">신용카드</v-btn></li>
                    <li>
                      <div class="inbl-wrap card-number">
                        <el-form-item prop="cardNumber">
                          <div class="label-input">
                            <label class="offscreen">첫번째 카드번호</label>
                            <v-input v-model="cardNumber[0]" type="number" maxlength="4" />
                          </div>
                          <div class="label-input">
                            <label class="offscreen">두 번째 카드번호</label>
                            <v-input v-model="cardNumber[1]" type="number" maxlength="4" />
                          </div>
                          <div class="label-input">
                            <label class="offscreen">세번째 카드번호</label>
                            <v-input v-model="cardNumber[2]" type="number" maxlength="4" />
                          </div>
                          <div class="label-input">
                            <label class="offscreen">네번째 카드번호</label>
                            <v-input v-model="cardNumber[3]" type="number" maxlength="4" />
                          </div>
                          <span class="result">
                            <i class="icon-check"></i>
                            <i class="icon-x"></i>
                          </span>
                        </el-form-item>
                      </div>
                    </li>
                    <li>
                      <div class="inbl-wrap card-limit">
                        <el-form-item prop="datelimit">
                          <div class="label-input">
                            <label class="offscreen">년도 유효기간</label>
                            <v-input v-model="datelimit[1]" type="number" maxlength="2" placeholder="MM" />
                          </div>
                          <div class="label-input">
                            <label class="offscreen">월 유효기간</label>
                            <v-input v-model="datelimit[2]" type="number" maxlength="2" placeholder="YY" />
                          </div>
                          <span class="result">
                            <i class="icon-check"></i>
                            <i class="icon-x"></i>
                          </span>
                        </el-form-item>
                      </div>
                    </li>
                  </ul>
                </div>
              </li>
            </ul>
          </div>
        </el-form>
      </div>
    </template>
    <template slot="footer">
      <div class="btn-group">
        <v-btn class="btn btn-lg" b-size="btn-lg">확인</v-btn>
        <v-btn class="btn btn-lg" b-size="btn-lg">계약금 결제</v-btn>
      </div>
    </template>
  </v-popup>
</template>

<script>
import { VPopup } from '~/components/element'
export default {
  components: {
    VPopup
  },
  props: {
    visible: {
      type: Boolean,
      default: false
    },
  },
  data() {
    return {
      ownerNm: '',
      ownerNmList: [
        { value: 'owner1', label: '김현대' },
        { value: 'owner2', label: '이현대' },
      ],
      cardNumber:['', '', '', ''],
      datelimit:['', ''],
    }
  },
  computed: {
    rules() {
      return {
        cardNumber: [
          {
            required: true,
            message: '* 카드번호를 입력해 주세요.',
            trigger: 'blur',
          },
        ],
        datelimit: [
          {
            required: true,
            message: '* 유효기간을 입력해 주세요.',
            trigger: 'blur',
          },
        ],
      }
    },
  },

  // 2021.03.17 (ver1.1)
  updated() {
    this.setLabel((idg) => {
    // console.dir(idg) // 자동 생성된 ID 배열, 예) 첫번째 입력폼 ID : idg[0]
    })
  },

}
</script>