<template>
  <v-popup
    :visible="visible"
    :width="'776px'"
    :footer="['cancel', 'confirm']"
    @close="
      $emit('close')
      popVisible = false
    "
  >
    <template slot="header">
      <div class="title">주소 입력</div>
      <p class="header-description">자동차제작증 발급을 위해 아래 주소를 확인해 주세요.</p>
    </template>
    <template slot="body">
      <el-form ref="addressForm" :model="addressForm" :rules="rules">
        <el-form-item prop="address" class="form-address">
          <div class="label-input inbl-wrap">
            <label class="offscreen">우편번호</label>
            <v-input v-model="addressForm.address" type="text" disabled="disabled" />
            <v-btn class="btn-more">우편번호</v-btn>
          </div>
          <div class="label-input">
            <label class="offscreen">기본주소</label>
            <v-input v-model="addressForm.address2" type="text" />
          </div>
          <div class="label-input">
            <label class="offscreen">상세주소</label>
            <v-input v-model="addressForm.address3" type="text" />
          </div>
        </el-form-item>
      </el-form>

      <!-- 2021.03.24 (ver1.1) -->
      <p class="bullet-star">
        주민등록상 주소를 입력해 주세요. 주민등록상 주소와 상이할 경우 차량 등록이 불가할 수 있습니다.
      </p>
    </template>
  </v-popup>
</template>

<script>
import { VPopup } from '~/components/element'
export default {
  components: {
    VPopup
  },
  props: {
    visible: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      addressForm: {
        address: '22262',
        address2: '서울특별시 강남구 테헤란로20길 9',
        address3: '동궁빌딩 6층'
      }
    }
  },
  computed: {
    rules() {
      return {
        address: [
          {
            required: true,
            message: '* 상세 주소를 입력해 주세요.',
            trigger: 'blur'
          }
        ]
      }
    }
  },
  updated() {
    if (this.visible) {
      this.setLabel((idg) => {
        // console.dir(idg) // 자동 생성된 ID 배열, 예) 첫번째 입력폼 ID : idg[0]
      })
    }
  }
}
</script>
