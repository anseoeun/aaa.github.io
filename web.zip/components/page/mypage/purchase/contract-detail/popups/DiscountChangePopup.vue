<template>
  <v-popup
    :visible="visible"
    :width="'1000px'"
    @close="
      $emit('close')
      popVisible = false
    "
  >

    <template slot="header">
      <div class="title">할인정보 조회 및 변경</div>
    </template>
    <template slot="body">
      <div class="contract">
        <div class="payment-info">
          <!-- 계약5단계 할인정보 영역에서 선택한 정보 화면 출력(PS-CTT_049) -->
          <sale-point></sale-point>
        </div>
      </div>
    </template>
    <template slot="footer">
      <div class="btn-group">
        <v-btn class="btn btn-lg" b-size="btn-lg">확인</v-btn>
        <v-btn class="btn btn-lg" b-size="btn-lg">할인정보 변경</v-btn>
      </div>
    </template>
  </v-popup>
</template>

<script>
import { VPopup } from '~/components/element'
import SalePoint from '~/components/page/contract/SalePoint'
export default {
  components: {
    VPopup,
    SalePoint,
  },
  props: {
    visible: {
      type: Boolean,
      default: false
    },
  },
}
</script>