<template>
  <v-popup
    :visible="visible"
    :width="'1000px'"
    @close="
      $emit('close')
      popVisible = false
    "
  >

    <template slot="header">
      <div class="title">계약 기본정보 조회 및 변경</div>
    </template>
    <template slot="body">
      <!-- 계약2단계 계약기본정보 조회 및 입력 화면 출력(PS-CTT_025) -->
      <div class="content contract">
        <page-step2></page-step2>
      </div>
    </template>
    <template slot="footer">
      <div class="btn-group">
        <v-btn class="btn btn-lg" b-size="btn-lg">확인</v-btn>
        <v-btn class="btn btn-lg" b-size="btn-lg">기본정보 변경</v-btn>
      </div>
    </template>
  </v-popup>
</template>

<script>
import { VPopup } from '~/components/element'
import PageStep2 from '~/components/page/contract/PageStep2'
export default {
  components: {
    VPopup,
    PageStep2
  },
  props: {
    visible: {
      type: Boolean,
      default: false
    },
  },
}
</script>