<template>
  <v-popup
    :visible="visible"
    :width="'550px'"
    @close="
      $emit('close')
      popVisible = false
    "
  >
    <template slot="header">
      <div class="title">FAX 번호 입력</div>
    </template>
    <template slot="body">
      <el-form ref="form" :model="faxForm" :rules="rules">
        <el-form-item prop="faxNumber">
          <div class="form-grid">
            <div class="label-input">
              <label class="form-title">FAX번호</label>
              <v-input v-model="faxForm.faxNumber" class="form-group" type="number" />
            </div>
          </div>
        </el-form-item>
      </el-form>
    </template>
    <template slot="footer">
      <v-btn class="btn" b-size="btn-md">전송하기</v-btn>
    </template>
  </v-popup>
</template>

<script>
import { VPopup } from '~/components/element'
export default {
  components: {
    VPopup
  },
  props: {
    visible: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      faxForm: {
        faxNumber: ''
      }
    }
  },
  computed: {
    rules() {
      return {
        faxNumber: [
          {
            required: true,
            message: '* FAX 번호를 입력해 주세요.',
            trigger: 'blur'
          }
        ]
      }
    }
  },
  updated() {
    if (this.visible) {
      this.setLabel((idg) => {
        // console.dir(idg) // 자동 생성된 ID 배열, 예) 첫번째 입력폼 ID : idg[0]
      })
    }
  }
}
</script>
