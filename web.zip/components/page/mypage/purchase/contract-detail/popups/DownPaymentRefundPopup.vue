<template>
  <v-popup
    :visible="visible"
    :width="'550px'"
    @close="
      $emit('close')
      popVisible = false
    "
  >
    <template slot="header">
      <div class="title">환불계좌 입력</div>
      <p class="header-description">현금으로 결제한 금액을 환불받을 계좌정보를 입력해 주세요.<br />주계약자 또는 공동명의자 본인 명의의 계좌만 등록 가능합니다.</p>
    </template>
    <template slot="body">
      <div class="body-contents bktop">
        <el-form ref="accountForm" :model="accountForm" :rules="rules">
          <div class="form-grid-list">
            <ul>
              <li>
                <strong class="form-label">예금주</strong>
                <div class="form-group">
                  <v-select
                    v-model="depositor"
                    :data="depositorList"
                    placeholder="선택"
                  />
                </div>
              </li>
              <li>
                <strong class="form-label">입금은행</strong>
                <div class="form-group">
                  <el-form-item prop="bank">
                    <v-select
                      v-model="accountForm.bank"
                      :data="bankList"
                      placeholder="선택"
                    />
                  </el-form-item>
                </div>
              </li>
              <li class="label-input">
                <strong class="form-label"><label>계좌번호</label></strong>
                <div class="form-group">
                  <el-form-item prop="account">
                    <v-input
                      v-model="accountForm.account"
                      placeholder="'-'없이 숫자만 입력해 주세요"
                    ></v-input>
                  </el-form-item>
                </div>
              </li>
            </ul>
          </div>
          <ul class="bullet-star-list">
            <li>문의를 등록하시면 주계약자의 연락처로 연락을 드립니다.</li>
            <li>문의하신 내용은 마이페이지&gt;1:1 문의내역에서 확인하실 수 있습니다.</li>
          </ul>
        </el-form>
      </div>


    </template>
    <template slot="footer">
      <div class="btn-group">
        <v-btn class="btn btn-gray" b-size="btn-md" b-color="btn-gray">취소</v-btn>
        <v-btn class="btn" b-size="btn-md">등록</v-btn>
      </div>
    </template>
  </v-popup>
</template>

<script>
import { VBtn, VPopup } from '~/components/element'
export default {
  components: {
    VBtn,
    VPopup
  },
  props: {
    visible: {
      type: Boolean,
      default: false
    },
  },
  data() {
    return {
      depositor: '',
      depositorList: [
        { value: 'depositor1', label: '김현대' },
        { value: 'depositor2', label: '이현대' },
      ],
      bankList: [
        { value: 'bank1', label: '신한은행' },
        { value: 'bank2', label: '우리은행' },
      ],
      accountForm: {
        bank: '',
        account: '',
      },
    }
  },
  computed: {
    rules() {
      return {
        bank: [
          {
            required: true,
            message: '* 입금은행을 선택해 주세요.',
            trigger: 'change'
          }
        ],
        account: [
          {
            required: true,
            message: '* 계좌번호를 입력해 주세요.',
            trigger: 'blur',
          },
        ],
      }
    },
  },

  // 2021.03.17 (ver1.1)
  updated() {
    this.setLabel((idg) => {
    // console.dir(idg) // 자동 생성된 ID 배열, 예) 첫번째 입력폼 ID : idg[0]
    })
  },
}
</script>
