<template>
  <v-popup
    :visible="visible"
    :width="'776px'"
    @close="
      $emit('close')
      popVisible = false
    "
    @confirm="
      $emit('close')
      popVisible = false
    "
  >

    <template slot="header">
      <div class="title">나만의 캐스퍼</div>
    </template>
    <template slot="body">
      <div class="pop-casper">
        <div class="car-img"><v-img :src="require('~/assets/images/temp/temp-precontact-car-visual.png')" alt="자동차 이미지"></v-img></div>
        <div class="table-area nohead">
          <table class="noline">
            <colgroup>
              <col width="200px" />
              <col width="auto" />
            </colgroup>
            <tbody>
              <tr>
                <th class="bold">모델명</th>
                <td class="left">AX 자가용 5인승 가솔린 1.6 2WD IVT Smart</td>
              </tr>
              <tr>
                <th class="bold">색상</th>
                <td class="left">
                  <ul class="color-list">
                    <li>
                      <span>외장색상</span>
                      <div class="color">
                        <div class="color-sample" :style="`background-image:url(${outColor.src})`"></div>
                        <div class="color-txt">{{ outColor.txt }}</div>
                      </div>
                    </li>
                    <li>
                      <span>내장색상</span>
                      <div class="color">
                        <div class="color-sample" :style="`background-image:url(${inColor.src})`"></div>
                        <div class="color-txt">{{ inColor.txt }}</div>
                      </div>
                    </li>
                  </ul>
                </td>
              </tr>
              <tr>
                <th class="bold">선택품목</th>
                <td class="left">
                  <ul class="table-list">
                    <li>인조가죽 시트</li>
                    <li>인포테인먼트 내비 1</li>
                    <li>익스테리어 디자인 1</li>
                  </ul>
                </td>
              </tr>
              <tr>
                <th class="bold">기본품목</th>
                <td class="left">
                  <ul class="table-list">
                    <li>ISG 시스템</li>
                    <li>통합주행모드</li>
                    <li>스마트스트림 디젤 2.2 엔진</li>
                    <li>스마트스트림 습식 8단 DCT</li>
                    <li>전자식 변속 버튼</li>
                    <li>전동식 파워 스티어릴(R-MDPS)</li>
                  </ul>
                </td>
              </tr>
              <tr>
                <th class="bold">H Genuine Accessories</th>
                <td class="left">
                  <ul class="table-list">
                    <li>1열 방오 시트 커버 + 2열 방오 커버</li>
                    <li>ISOPIX 카시트</li>
                    <li>하네스 ISOPIX 안전벨트 테더</li>
                  </ul>
                </td>
              </tr>
              <tr>
                <th class="bold">N Performance</th>
                <td class="left">인테리어 패키지</td>
              </tr>
            </tbody>
            <tfoot>
              <tr>
                <th class="left bold">차량가격</th>
                <td><span>14,000,000</span>원</td>
              </tr>
            </tfoot>
          </table>
          <div class="notice">
            <ul class="bullet-star-list">
              <li>모델, 색상, 옵션 등 차량 정보를 변경할 수 있습니다. [차량정보 변경] 버튼을 클릭하고 나만의 캐스퍼 만들기로 이동하여 다른 사양으로 변경해 보세요</li>
              <li>차량정보 변경은 결제 전까지 언제든 가능합니다. 단, 변경하시는 품목에 따라 차량 가격이 달라질 수 있습니다.</li>
            </ul>
          </div>
        </div>
      </div>
    </template>
    <template slot="footer">
      <div class="btn-group">
        <v-btn class="btn btn-lg" b-size="btn-lg">확인</v-btn>
        <v-btn class="btn btn-lg" b-size="btn-lg">차량정보 변경</v-btn>
      </div>
    </template>
  </v-popup>
</template>

<script>
import { VPopup } from '~/components/element'
export default {
  components: {
    VPopup
  },
  props: {
    visible: {
      type: Boolean,
      default: false
    },
  },
  data(){
    return{
      inColor: { txt: '메테오 블루',  src: require('~/assets/images/temp/temp-color-4.png'), price: '0' },
      outColor: { txt: '쉬머링 실버',  src: require('~/assets/images/temp/temp-color-1.png'), price: '100,000' },
    }
  },
  updated() {
    if (this.visible) {
      this.setCaption()
    }
  },
}
</script>