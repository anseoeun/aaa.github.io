<template>
  <div>
    <v-popup
      :visible="visible"
      :width="'776px'"
      @close="
        $emit('close')
        popVisible = false
      "
    >
      <template slot="header">
        <div class="title">차량인수 확정처리</div>

        <!-- 2021.04.05 (ver1.1) 텍스트 수정 -->
        <p class="header-description">차량을 정상적으로 인수하신 경우, 차량인수 확정을 진행해 주세요.</p>
      </template>
      <template slot="body">
        <p class="contents-head">점검 사항</p>
        <div class="check-list">
          <div class="table-area">
            <table class="noline-in">
              <colgroup>
                <col width="226px" />
                <col width="113px" />
                <col width="226px" />
                <col width="auto" />
              </colgroup>
              <thead>
                <tr>
                  <th scope="col">구분</th>
                  <th scope="col">항목</th>
                  <th scope="col">체크포인트</th>
                  <th scope="col">확인 여부</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <th rowspan="2" scope="row">차량정보</th>
                  <td class="left">차대번호</td>
                  <td class="left">{{ vehicleIdentificationNumber }}</td>
                  <td><v-checkbox :one-check="true" :checked.sync="isAgree.first"></v-checkbox></td>
                </tr>
                <tr>
                  <td class="left">임시번호</td>
                  <td class="left">{{ temporaryCarNumber }}</td>
                  <td><v-checkbox :one-check="true" :checked.sync="isAgree.second"></v-checkbox></td>
                </tr>
                <tr style="border-top: 1px solid #eee">
                  <th rowspan="4" scope="row">차량상태 및 기능 지급품 이상 유무</th>
                  <td class="left">서류 및 지급품</td>
                  <td class="left">임시운행증, 브랜드 KIT</td>
                  <td><v-checkbox :one-check="true" :checked.sync="isAgree.third"></v-checkbox></td>
                </tr>
                <tr>
                  <td class="left">외관</td>
                  <td class="left">긁힘, 요철, 조립상태, 오염 등</td>
                  <td><v-checkbox :one-check="true" :checked.sync="isAgree.fourth"></v-checkbox></td>
                </tr>
                <tr>
                  <td class="left">실내</td>
                  <td class="left">오염</td>
                  <td><v-checkbox :one-check="true" :checked.sync="isAgree.fifth"></v-checkbox></td>
                </tr>
                <tr>
                  <td class="left">기능</td>
                  <td class="left">전조등, 램프, 에어컨, 히터, 와이퍼</td>
                  <td><v-checkbox :one-check="true" :checked.sync="isAgree.sixth"></v-checkbox></td>
                </tr>
              </tbody>
            </table>
          </div>
          <div class="check-message">
            <v-checkbox :one-check="true" :checked.sync="isAgree.all" @change="onChangeIsAgreeAll"
              >위 점검 사항을 확인하고, 이상 없이 차량을 인수받았음을 동의합니다.</v-checkbox
            >
            <div v-if="showAgreeAlert" class="notice">
              <ul class="bullet-list">
                <li>모든 항목을 확인하고 체크해 주세요.</li>
                <li>차량 이상 또는 서류 및 지급품 누락 시, 고객센터(080-600-6000)로 문의해 주세요.</li>
              </ul>
            </div>
          </div>
        </div>

        <!-- 2021.04.05 (ver1.1) 텍스트 추가 -->
        <div class="notice">
          <ul class="bullet-list">
            <li>차량인수 확정 후, 자동차제작증 발급 및 차량 등록이 가능합니다.</li>
            <li>차량 이상 또는 서류 및 지급품 누락 시, 고객센터(080-600-6000)로 문의해 주세요.</li>
          </ul>
        </div>
      </template>
      <template slot="footer">
        <div class="btn-group">
          <v-btn class="btn btn-gray btn-lg" b-size="btn-lg" b-color="btn-gray">취소</v-btn>
          <v-btn class="btn btn-lg" b-size="btn-lg">차량인수 확정</v-btn>
        </div>
        <!-- asis -->
        <!-- <div class="btn-group center">
            <v-btn b-size="btn-md" b-color="btn-gray" @click="popShow.takeOverConfirmPop = false">취소</v-btn>
            <v-btn b-size="btn-md" b-color="btn" @click="confirm">차량인수 확정</v-btn>
          </div> -->
      </template>
    </v-popup>
  </div>
</template>

<script>
import { VPopup, VCheckbox, VBtn } from '~/components/element'
export default {
  components: {
    VPopup,
    VCheckbox,
    VBtn
  },
  props: {
    visible: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      confirmToastShow: false,
      isAgree: {
        all: false,
        first: false,
        second: false,
        third: false,
        fourth: false,
        fifth: false,
        sixth: false
      },
      showAgreeAlert: false,

      vehicleIdentificationNumber: '23차 2338',
      temporaryCarNumber: '232338'
      // vehicleIdentificationNumber: null,
      // temporaryCarNumber: null
    }
  },
  // 2021.03.17 (ver1.1)
  updated() {
    if (this.visible) {
      this.setCaption()
    }
  },
  methods: {
    confirm() {
      if (
        this.contractNumber &&
        this.isAgree.first &&
        this.isAgree.second &&
        this.isAgree.third &&
        this.isAgree.fourth &&
        this.isAgree.fifth &&
        this.isAgree.sixth
      ) {
        this.showAgreeAlert = false
        this.confirmTakeOverCarDecision({ contractNumber: this.contractNumber })
      } else {
        this.showAgreeAlert = true
      }
    },
    onChangeIsAgreeAll(val) {
      if (val) {
        this.isAgree = {
          all: true,
          first: true,
          second: true,
          third: true,
          fourth: true,
          fifth: true,
          sixth: true
        }
      }
    },
    onClose() {
      this.isAgree = {
        all: false,
        first: false,
        second: false,
        third: false,
        fourth: false,
        fifth: false,
        sixth: false
      }
      this.popShow.takeOverConfirmPop = false
      this.$emit('update:popShow', this.popShow)
    }
  }
}
</script>
