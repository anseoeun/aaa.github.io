<template>
  <v-popup
    :visible="visible"
    :width="'776px'"
    :footer="['confirm']"
    @close="
      $emit('close')
    "
    @confirm="
      $emit('close')
    "
  >

    <template slot="header">
      <div class="title">전자서명 메시지 발송</div>
    </template>
    <template slot="body">
      <div class="contents-head">전자서명 인증 방식을 선택해 메시지를 발송해 주세요.</div>
      <ul class="contractor-list">
        <li v-for="(item, index) in contractorData" :key="index">
          <strong>{{ item.title }}</strong>
          <span>{{ item.name }}</span>
          <div v-if="item.completeYN === 'Y'">
            <span>전자서명 완료<em>({{ item.date }})</em></span>
          </div>
          <div v-if="item.completeYN === 'N'">
            <span>미완료</span>
            <v-btn class="btn md white r" type="button">카카오톡</v-btn>
            <v-btn class="btn md white r" type="button">공동인증서</v-btn>
          </div>
        </li>
      </ul>
    </template>
  </v-popup>
</template>

<script>
import { VPopup } from '~/components/element'
export default {
  components: {
    VPopup
  },
  props: {
    visible: {
      type: Boolean,
      default: false
    },
  },
  data () {
    return {
      contractorData: [
        {
          title: '면세 구입자(신고인)',
          name: '홍길동',
          completeYN: 'Y',
          date: '2021.01.28 11:10'
        },
        {
          title: '공동등록자1',
          name: '김현대',
          completeYN: 'N',
        },
        {
          title: '공동등록자2',
          name: '박창석',
          completeYN: 'N',
        },
        {
          title: '공동등록자3',
          name: '이숙영',
          completeYN: 'Y',
          date: '2021.01.28 11:10'
        },

      ]
    }
  }
}
</script>