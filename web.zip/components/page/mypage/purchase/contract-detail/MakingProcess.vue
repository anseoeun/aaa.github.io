<template>
  <div class="making-process">
    <div class="title">자동차 제조공정 안내</div>
    <div class="step-summary">
      고객님의 {{ carName }}는 <strong class="t-blue">{{ productFactoryName }}</strong>에서 {{ productStatus }}중입니다.
      <v-btn type="link" href="/" target="_blank" title="새창열림" class="btn-more">{{ productFactoryName }} 둘러보기</v-btn>
    </div>
    <div class="detail">
      <div class="video-list">
        <ul>
          <li v-for="(item, index) in videoList" :key="item.engTitle">
            <button class="btn" :class="{ active: item.isActive }" @click.prevent.stop="handleActiveItem(index, item.startTime)">
              {{ `0${index + 1}. ${item.title}` }}<span>{{ item.engTitle }}</span>
            </button>
          </li>
        </ul>
      </div>
      <div class="video-wrap">
        <div class="iframe-frame">
          <iframe
            id="player" ref="player" type="text/html" width="950" height="480"
            src="https://www.youtube.com/embed/pUFk9wpqMv4?enablejsapi=1"
            frameborder="0">
          </iframe>
        </div>
        <div class="explane">
          <strong class="bold">{{ videoList[videoCurrIdx].title }} 단계에서 진행하는 공정은?</strong>
          <p>{{ videoList[videoCurrIdx].content }}</p>
        </div>
      </div>

    </div>
  </div>
</template>

<script>
// import { mapState } from 'vuex'

export default {
  props: {
    contractNumber: {
      type: String,
      default: ''
    }
  },

  data() {
    return {
      carName: 'AX',
      productFactoryName: '광주공장',
      productStatus: '생산대기중',
      videoCurrIdx: 0,
      videoList: [
        {
          title: '프레스',
          engTitle: 'Stamping',
          startTime : 2,
          content:
            '상하운동을 하는 프레스 기계에서 금형 장착 후 철판을 변형시켜 차량 총 중량의 50% 이상을 차지하는 프레임, 파니 패널 등 생산',
          isActive: true
        },
        {
          title: '자체 조립',
          engTitle: 'Welding',
          startTime : 31,
          content:
            '패널들을 조립, 용접하여 차의 모양을 만드는 공정으로 높은 정밀도가 요구되며 최초로 차체 스타일 형성 및 튼튼한 조립으로 안전성을 확보.',
          isActive: false
        },
        {
          title: '도장',
          engTitle: 'Paint',
          startTime : 56,
          content:
            '부식으로부터 소재 보호, 색상으로 외관 향상, 다른 차량과 구별하는 기능을 하며 세계 각지의 다양한 기후와 환경에 대한 내구성 개선 공정',
          isActive: false
        },
        {
          title: '의장',
          engTitle: 'Assembly',
          startTime : 85,
          content:
            '차체에 내장, 편의사양 등 실내외 부품 장착 후 엔진, 트랜스미션, 차축 등 기계부품 조립 및 전장부품과 배선, 배관 작업으로 차량 완성',
          isActive: false
        },
        {
          title: '검수',
          engTitle: 'Inspection',
          startTime : 113,
          content:
            '완성된 차량의 휠 얼라인먼트 조정과 브레이크 및 배기가스 테스트 등 기능 검사 실시. 하자 발견 시 수정 작업을 하여 출고 전 품질 관리',
          isActive: false
        }
      ]
    }
  },

  computed: {
    // ...mapState({
    //   manufacturingProcessState: (state) => state.myPageModules.manufacturingProcessState
    // })
  },

  watch: {
    manufacturingProcessState(res) {
      const { rspStatus, data } = res
      if (rspStatus.rspMessage === '성공' && data) {
        for (const property in data) {
          this[property] = data[property]
        }
      }
    }
  },

  beforeMount() {
    // this.$store.dispatch('myPageModules/GET_MANUFACTURING_PROCESS_STATE', { contractNumber: this.contractNumber })
  },

  methods: {
    handleActiveItem(vIndex, sec) {
      this.$refs.player.contentWindow.postMessage(
        '{"event":"command","func":"seekTo","args":[' + sec + ', true]}',
        '*'
      )

      this.videoList.map((item, idx) => vIndex === idx ? item.isActive = true : item.isActive = false)
      this.videoCurrIdx = vIndex
    }
  }
}
</script>
