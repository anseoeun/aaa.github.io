<template>
  <section class="information-detail">
    <div class="summary-info" :class="{ active: isOptionsShow }">
      <h1 class="title full">블루멤버스 적립예정 포인트</h1>
      <v-btn class="btn-detail" type="icon" :icon-class="['icon-open', { 'on': isOptionsShow} ]" @click="isOptionsShow = !isOptionsShow"><span class="offscreen">상세보기</span></v-btn>
    </div>
    <div v-show="isOptionsShow" class="detail-info">
      <div class="comparison-wrap">
        <div class="item-box">
          <strong class="title">적립예정포인트</strong>
          <ul class="item-list">
            <li v-for="(item, index) in carInfoData" :key="index">
              <div class="total-price">(-) {{ item.blueMembersPoint }} 원</div>
            </li>
            <li v-if="carInfoData[2] === undefined"></li>
            <li v-if="carInfoData[3] === undefined"></li>
          </ul>
        </div>
      </div>
      <p class="bullet-star">계약시 할인/포인트 내역이 변경될 수 있습니다.</p>
    </div>
  </section>
</template>

<script>
import { mapGetters } from 'vuex'
export default {
  components: {
  },
  data() {
    return {
      isOptionsShow: true,
    }
  },
  computed: {
    ...mapGetters({
      selectedData: 'mypageModules/selectedData',
    }),
    carInfoData() {
      return this.selectedData
    }
  },
}
</script>