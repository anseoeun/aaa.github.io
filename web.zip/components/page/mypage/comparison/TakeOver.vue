<template>
  <section class="information-detail">
    <div class="summary-info" :class="{ active: isOptionsShow }">
      <h1 class="title">인수정보</h1>
      <v-btn class="btn-detail" type="icon" :icon-class="['icon-open', { active: isOptionsShow} ]" @click="isOptionsShow = !isOptionsShow"><span class="offscreen">상세보기</span></v-btn>
    </div>
    <div v-show="isOptionsShow" class="detail-info">
      <div class="comparison-wrap">
        <div class="item-box">
          <strong class="title">탁송정보</strong>
          <ul class="item-list">
            <li v-for="(item, index) in carInfoData" :key="index">
              <div class="total-price">+ {{ item.takeOverFee }} 원</div>
              <div class="item-detail">
                <em>{{ item.takeOverType }}</em>
                <span> {{ item.takeOverArea }}</span>
              </div>
            </li>
            <li v-if="carInfoData[2] === undefined"></li>
            <li v-if="carInfoData[3] === undefined"></li>
          </ul>
        </div>
        <div class="item-box">
          <div class="title">
            <strong>출고예정일</strong>
            <v-popover trigger="hover" placement="bottom-start">
              <p>현 시점 계약완료 기준으로 재고 및<br />생산계획 기반 산출된 예상출고일이며,<br />당사 사정에 의하여 변경될 수 있으니<br />단순 참고만 하시기 바랍니다.</p>
              <v-btn slot="reference"><i class="icon-help"></i></v-btn>
            </v-popover>
          </div>
          <ul class="item-list">
            <li v-for="(item, index) in carInfoData" :key="index">
              <ul>
                <li>{{ item.releaseDate }}</li>
              </ul>
            </li>
            <li v-if="carInfoData[2] === undefined"></li>
            <li v-if="carInfoData[3] === undefined"></li>
          </ul>
        </div>
      </div>
    </div>
  </section>
</template>

<script>
import { mapGetters } from 'vuex'
export default {
  components: {
  },
  data() {
    return {
      isOptionsShow: true,
    }
  },
  computed: {
    ...mapGetters({
      selectedData: 'mypageModules/selectedData',
    }),
    carInfoData() {
      return this.selectedData
    }
  },
}
</script>