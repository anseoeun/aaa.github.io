<template>
  <section class="information-detail">
    <div class="summary-info" :class="{ active: isOptionsShow }">
      <h1 class="title">결제방법</h1>
      <v-btn class="btn-detail" type="icon" :icon-class="['icon-open', { 'on': isOptionsShow} ]" @click="isOptionsShow = !isOptionsShow"><span class="offscreen">상세보기</span></v-btn>
    </div>
    <div v-show="isOptionsShow" class="detail-info">
      <div class="comparison-wrap">
        <div class="item-box">
          <strong class="title">출고 전 납입 총액</strong>
          <ul class="item-list">
            <li v-for="(item, index) in carInfoData" :key="index">
              <div class="total-price">{{ item.beforeReleasePrice }} 원</div>
            </li>
            <li v-if="carInfoData[2] === undefined"></li>
            <li v-if="carInfoData[3] === undefined"></li>
          </ul>
        </div>
        <div class="item-box">
          <strong class="title">결제수단</strong>
          <ul class="item-list">
            <li v-for="(item, index) in carInfoData" :key="index">
              <div class="item-detail">{{ item.paymentMethod.type }}</div>
              <div class="product-wrap">
                <div v-for="(list, idx) in item.paymentMethod.list" :key="idx" class="item-detail">
                  <strong class="sub-title">{{ list.name }}</strong>
                  <ul>
                    <li v-for="(opt, i) in list.option" :key="i">
                      <em>{{ opt.name }}</em>
                      <span v-if="opt.price != undefined" class="price">{{ opt.price }}원</span>
                      <span v-if="opt.productName != undefined" class="price">{{ opt.productName }}</span>
                      <span v-if="opt.rate != undefined" class="price">{{ opt.rate }}%</span>
                    </li>
                  </ul>
                </div>
              </div>
            </li>
            <li v-if="carInfoData[2] === undefined"></li>
            <li v-if="carInfoData[3] === undefined"></li>
          </ul>
        </div>
      </div>
      <p class="bullet-star">계약시 할인/포인트 내역이 변경될 수 있습니다.</p>
    </div>
  </section>
</template>

<script>
import { mapGetters } from 'vuex'
export default {
  components: {
  },
  data() {
    return {
      isOptionsShow: true,
    }
  },
  computed: {
    ...mapGetters({
      selectedData: 'mypageModules/selectedData',
    }),
    carInfoData() {
      return this.selectedData
    }
  },
}
</script>