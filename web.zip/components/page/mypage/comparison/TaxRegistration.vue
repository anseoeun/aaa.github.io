<template>
  <section class="information-detail">
    <div class="summary-info" :class="{ active: isOptionsShow }">
      <h1 class="title">등록비</h1>
      <v-btn class="btn-detail" type="icon" :icon-class="['icon-open', { 'on': isOptionsShow} ]" @click="isOptionsShow = !isOptionsShow"><span class="offscreen">상세보기</span></v-btn>
    </div>
    <div v-show="isOptionsShow" class="detail-info">
      <div class="comparison-wrap">
        <div class="item-box">
          <strong class="title">총 차량 등록 비용</strong>
          <ul class="item-list">
             <li v-for="(item, index) in carInfoData" :key="index">
              <div class="total-price">{{ item.carRegistFee }} 원</div>
            </li>
            <li v-if="carInfoData[2] === undefined"></li>
            <li v-if="carInfoData[3] === undefined"></li>
          </ul>
        </div>
        <div class="item-box">
          <strong class="title">등록 비용 내역</strong>
          <ul class="item-list">
           <li v-for="(item, index) in carInfoData" :key="index">
              <ul class="item-detail">
                <li v-for="(list, idx) in item.carRegistFeeList" :key="idx">
                  <em>
                    {{ list.name }}
                    <v-btn v-if="list.name === '취득세'" class="btn-info" type="icon" icon-class="icon-info" @click="$emit('popInfoAcquirement')"><span class="offscreen">취득세안내팝업보기</span></v-btn>
                    <!-- 2021.04.13(ver1.2) 공채할인제거 -->
                    <!-- <v-btn v-if="list.name === '공채(할인)'" class="btn-info" type="icon" icon-class="icon-info" @click="$emit('popInfoFund')"><span class="offscreen">공채안내팝업보기</span></v-btn> -->
                  </em>
                  <span v-if="list.text != undefined">{{ list.text }}</span>
                  <span v-if="list.area != undefined">{{ list.area }}</span>
                  <span v-if="list.price != undefined">{{ list.price }} 원</span>
                </li>
              </ul>
            </li>
            <li v-if="carInfoData[2] === undefined"></li>
            <li v-if="carInfoData[3] === undefined"></li>
          </ul>
        </div>
      </div>
      <ul class="bullet-star-list">
        <li>등록비는 견적금액에 포함되지 않습니다.</li>
        <li>공채 할인금액은 지자체별 할인율이 매일 변동됨에 따라 실제와 다소 차이가 있을 수 있습니다.</li>
        <!-- 2021.04.13(ver1.2) 아래텍스트제거 -->
        <!-- <li>차량번호판과 등록대행수수료는 지역별로 차이가 있으므로 단순 참고만 하시기 바랍니다.</li> -->
      </ul>
    </div>
  </section>
</template>

<script>
import { mapGetters } from 'vuex'
export default {
  components: {
  },
  data() {
    return {
      isOptionsShow: true,
    }
  },
  computed: {
    ...mapGetters({
      selectedData: 'mypageModules/selectedData',
    }),
    carInfoData() {
      return this.selectedData
    }
  },
}
</script>