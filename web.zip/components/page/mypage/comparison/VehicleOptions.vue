<template>
  <section class="information-detail">
    <div class="summary-info" :class="{ active: isOptionsShow }">
      <h1 class="title">차량정보</h1>
      <v-btn class="btn-detail" type="icon" :icon-class="['icon-open', { active: isOptionsShow} ]" @click="isOptionsShow = !isOptionsShow"><span class="offscreen">상세보기</span></v-btn>
    </div>
    <div v-show="isOptionsShow" class="detail-info">
      <div class="comparison-wrap">
        <div class="item-box">
          <strong class="title">외장색상</strong>
          <ul class="item-list color-list">
            <li v-for="(item, index) in carInfoData" :key="index">
              <div v-if="parseInt(carInfoData[0].outColor.price) !== parseInt(item.outColor.price)" class="margin">
                <span v-if="parseInt(carInfoData[0].outColor.price) > parseInt(item.outColor.price)" class="down">{{ carInfoData[0].outColor.price - item.outColor.price | comma }} 원</span>
                <span v-if="parseInt(carInfoData[0].outColor.price) < parseInt(item.outColor.price)" class="up">{{ item.outColor.price - carInfoData[0].outColor.price | comma }} 원</span>
              </div>
              <div v-if="item.outColor.price !== undefined " class="total-price">+ {{ item.outColor.price }} 원</div>
              <div class="color">
                <div class="color-txt">{{ item.outColor.name }}</div>
                <div class="color-sample" :style="`background-image:url(${item.outColor.src})`"></div>
              </div>
            </li>
            <li v-if="carInfoData[2] === undefined"></li>
            <li v-if="carInfoData[3] === undefined"></li>
          </ul>
        </div>
        <div class="item-box">
          <strong class="title">내장색상</strong>
          <ul class="item-list color-list">
            <li v-for="(item, index) in carInfoData" :key="index">
             <div v-if="parseInt(carInfoData[0].inColor.price) !== parseInt(item.inColor.price)" class="left margin">
                <span v-if="parseInt(carInfoData[0].inColor.price) > parseInt(item.inColor.price)" class="down">{{ carInfoData[0].inColor.price - item.inColor.price | comma }} 원</span>
                <span v-if="parseInt(carInfoData[0].inColor.price) < parseInt(item.inColor.price)" class="up">{{ item.inColor.price - carInfoData[0].inColor.price | comma }} 원</span>
              </div>
              <div v-if="item.inColor.price !== undefined" class="total-price">+ {{ item.inColor.price }} 원</div>
              <div class="color">
                <div class="color-txt">{{ item.inColor.name }}</div>
                <div class="color-sample" :style="`background-image:url(${item.inColor.src})`"></div>
              </div>
            </li>
            <li v-if="carInfoData[2] === undefined"></li>
            <li v-if="carInfoData[3] === undefined"></li>
          </ul>
        </div>
        <div class="item-box">
          <strong class="title">선택옵션</strong>
          <ul class="item-list">
            <li v-for="(item, index) in carInfoData" :key="index">
             <div v-if="carInfoData[0].option.totalPrice !== item.option.totalPrice" class="left margin">
                <span v-if="carInfoData[0].option.totalPrice > item.option.totalPrice" class="down">{{ carInfoData[0].option.totalPrice -item.option.totalPrice | comma }} 원</span>
                <span v-if="carInfoData[0].option.totalPrice < item.option.totalPrice" class="up">{{ item.option.totalPrice - carInfoData[0].option.totalPrice | comma }} 원</span>
              </div>
              <div v-if="item.option.totalPrice !== undefined" class="total-price">+ {{ item.option.totalPrice }}원</div>
              <ul class="item-detail">
                <li v-for="(opt, idx) in item.option.opts" :key="idx">
                  <em>{{ opt.name }}</em>
                  <span class="price">+ {{ opt.price }} 원</span>
                </li>
              </ul>
            </li>
            <li v-if="carInfoData[2] === undefined"></li>
            <li v-if="carInfoData[3] === undefined"></li>
          </ul>
        </div>
      </div>
      <strong class="title">기본옵션</strong>
      <div class="comparison-wrap">
        <div class="item-box">
          <strong class="title">파워트레인</strong>
          <ul class="item-list">
            <li v-for="(item, index) in carInfoData" :key="index">
              <ul>
                <li v-for="(opt, idx) in item.powerTrain" :key="idx">{{ opt }}</li>
              </ul>
            </li>
            <li v-if="carInfoData[2] === undefined"></li>
            <li v-if="carInfoData[3] === undefined"></li>
          </ul>
        </div>
        <div class="item-box">
          <strong class="title">외관</strong>
          <ul class="item-list">
            <li v-for="(item, index) in carInfoData" :key="index">
              <ul>
                <li v-for="(opt, idx) in item.exterior" :key="idx">{{ opt }}</li>
              </ul>
            </li>
            <li v-if="carInfoData[2] === undefined"></li>
            <li v-if="carInfoData[3] === undefined"></li>
          </ul>
        </div>
      </div>
    </div>
  </section>
</template>

<script>
import { mapGetters } from 'vuex'
export default {
  components: {
  },
  filters:{
    comma(val){
      return String(val).replace(/\B(?=(\d{3})+(?!\d))/g, ',')
    }
  },
  data() {
    return {
      isOptionsShow: true,
    }
  },
  computed: {
    ...mapGetters({
      selectedData: 'mypageModules/selectedData',
    }),
    carInfoData() {
      return this.selectedData
    }
  },
}
</script>