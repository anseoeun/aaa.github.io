<template>
  <v-popup
    :visible="visible"
    :width="'550px'"
    :footer="['confirm']"
    @close="
      $emit('close')
      popVisible = false
    "
    @confirm="
      $emit('close')
      popVisible = false
    "
  >

    <template slot="header">
      <div class="title">쿠폰 사용조건 자세히 보기</div>
    </template>
    <template slot="body">

      <div class="contents-head">첫 차 구매 할인쿠폰</div>
      <div style="width: 100%; height: 400px; background-color: #f6f3f2;">[BO]입력 내용 노출</div>
    </template>
  </v-popup>
</template>

<script>
import { VPopup } from '~/components/element'
export default {
  components: {
    VPopup
  },
  props: {
    visible: {
      type: Boolean,
      default: false
    },
  },
}
</script>