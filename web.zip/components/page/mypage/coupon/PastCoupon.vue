<template>
  <div>
    <div class="top-noti-info">
      <div class="left">
        <p class="bullet">지난 쿠폰 내역은 최근 1개월까지만 보관됩니다.</p>
      </div>
    </div>
    <div class="list-board">
      <div class="list-header">
        <div class="expiration">사용/만료일</div>
        <div class="title past">쿠폰명</div>
        <div class="reason">사유</div>
      </div>
      <div class="list-body">
        <template v-if="couponList.length > 0">
          <ul>
            <li v-for="(item, index) in couponList" :key="index">
              <div class="desc">
                <div class="expiration">{{ item.date }}</div>
                <div class="title past">{{ item.title }}</div>
                <div class="reason">
                  {{ item.reason }}
                  <nuxt-link v-if="isNan(item.link)" :to="item.linkAddr" class="link">({{ item.link }})</nuxt-link>
                </div>
              </div>
            </li>
          </ul>
          <v-pagination :total="100" />
        </template>
        <template v-else>
          <div class="list-null">
            <i class="icon-coupon-none"></i>
            <p>사용 가능한 쿠폰이 없습니다.</p>
          </div>
        </template>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  components: {
  },
  data() {
    return {
      topBreadcrumb: [
        { linkName: '마이페이지', link: '/' },
        { linkName: '나의 혜택', link: '/' },
        { linkName: '쿠폰 내역', link: '/' },
      ],
      tabList: [
        { value: 'tab1', label: '보유 쿠폰' },
        { value: 'tab2', label: '지난 쿠폰 내역' },
      ],
      couponList: [
        { date:'2021.01.08', title: 'AX 출시 기념 할인쿠폰', reason: '기간만료' },
        { date:'2021.01.08', title: '온라인 첫 차 구매 할인쿠폰',reason: '기간만료' },
        { date:'2021.01.08', title: 'AX 출시 기념 할인쿠폰', reason: '사용', link: '2021020100041', linkAddr: '/', },
      ],
    }
  },
  methods:{
    isNan(val) {
      return val != undefined &&  val != null && val != '' ? true : false
    },
  },
}
</script>
