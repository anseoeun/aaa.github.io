<template>
  <div class="mypage-wrap">
    <div class="top-noti-info">
      <div class="left inbl-wrap">
        <div class="date-wrap">
          <div class="label-input">
            <span class="offscreen">시작일</span>
            <v-date-picker v-model="startDate" class="datepicker" />
          </div>
          <span class="dash"></span>
          <div class="label-input">
            <span class="offscreen">종료일</span>
            <v-date-picker v-model="endDate" class="datepicker" />
          </div>
        </div>
        <v-select v-model="selectCalVal" :data="selectCalList" class="no-st" @change="calChange" />
      </div>
      <div class="right"><v-btn class="btn white md r">조회</v-btn></div>
    </div>
    <div class="order-info">
      <template v-if="emptyList">
        <div class="list-null">
          <i class="icon-doc-none"></i>
          <p>구매 내역이 없습니다.</p>
        </div>
      </template>
      <ul v-else>
        <li v-for="sh in historyListForUI" :key="sh.contractNumber">
          <div class="contract-num">{{ sh.contractNumber }}</div>
          <div class="state">{{ sh.state }}</div>
          <div class="car-img"><v-img :src="sh.carImg.src" :alt="sh.carImg.alt"></v-img></div>
          <nuxt-link :to="sh.detail" class="btn-more">상세보기</nuxt-link>
          <div class="info-grid-list">
            <ul>
              <li>
                <strong class="info-title">모델명</strong>
                <div class="info-group">{{ sh.saleModelName }}</div>
              </li>
              <li v-if="isNan(sh.contractDate)">
                <strong class="info-title">계약완료일</strong>
                <div class="info-group">{{ sh.contractDate }}</div>
              </li>
              <li>
                <strong class="info-title">외장색상</strong>
                <div class="info-group">{{ sh.outColor }}</div>
              </li>
              <li>
                <strong class="info-title">선택품목</strong>
                <div class="info-group">{{ sh.option }}</div>
              </li>
              <li>
                <strong class="info-title">계약금액</strong>
                <div class="info-group price">{{ sh.carPrice }}원</div>
              </li>
              <li>
                <strong class="info-title">단계</strong>
                <div class="info-group step-info">
                  <ol>
                    <li v-for="(ms, idx) in mySteps" :key="idx" :class="{ active: sh.step === `${idx + 1}` }">
                      {{ `0${idx + 1}. ${ms}` }}
                    </li>
                  </ol>
                  <p class="result">{{ sh.description }}</p>
                </div>
              </li>
            </ul>
          </div>
        </li>
      </ul>
      <v-pagination :total="100" />
    </div>
  </div>
</template>

<script>
import VPagination from '~/components/element/VPagination'
export default {
  components: {
    VPagination
  },
  data() {
    return {
      startDate: '',
      endDate: '',
      selectCalVal: '',
      selectCalList: [
        { value: '', label: '선택' },
        { value: 'week', label: '1주일' },
        { value: 'month', label: '1개월' }
      ],
      mySteps: ['계약', '차량준비', '결제', '배달탁송', '배달탁송완료'],
      historyListForUI: [
        {
          contractNumber: 'A3721CN000090',
          state: '결제처리중',
          carImg: {
            src: require('~/assets/images/temp/temp-payment-car-model.png'),
            alt: 'AX 자가용 5인승 가솔린 1.6 2WD IVT Smart '
          },
          detail: '/',
          saleModelName: 'AX 자가용 5인승 가솔린 1.6 2WD IVT Smart ',
          outColor: '그레이',
          option: '스마트스트림 가솔린 1.6 엔진 외 5개',
          carPrice: '21,480,000',
          step: '3',
          description: '결제처리중 입니다. 잠시만 기다려 주세요.'
        },
        {
          contractNumber: 'A3721CN000093',
          state: '결제처리중',
          carImg: {
            src: require('~/assets/images/temp/temp-review-car.png'),
            alt: 'AX 자가용 5인승 가솔린 1.6 2WD IVT Smart '
          },
          detail: '/',
          saleModelName: 'AX 자가용 5인승 가솔린 1.6 2WD IVT Smart ',
          contractDate: '2021.02.01 15:50',
          outColor: '그레이',
          option: '스마트스트림 가솔린 1.6 엔진 외 5개',
          carPrice: '21,480,000',
          step: '3',
          description: '결제처리중 입니다. 잠시만 기다려 주세요.'
        },
        {
          contractNumber: 'A3720TM001532',
          state: '계약진행 [작성중]',
          carImg: {
            src: require('~/assets/images/temp/temp-precontact-car-visual.png'),
            alt: 'AX 자가용 5인승 가솔린 1.6 2WD IVT Smart '
          },
          detail: '/',
          saleModelName: 'AX 자가용 5인승 가솔린 1.6 2WD IVT Smart ',
          outColor: '그레이',
          option: '스마트스트림 가솔린 1.6 엔진 외 5개',
          carPrice: '21,480,000',
          step: '1',
          description: '2021년 2월 3일 10시 31분까지 계약을 완료해 주세요. 기한이 지나면 계약은 자동으로 취소됩니다.'
        }
      ],
      emptyList: false
    }
  },
  methods: {
    //달력
    getDateStr(myDate) {
      let year = myDate.getFullYear()
      let month = myDate.getMonth() + 1
      let day = myDate.getDate()

      month = month < 10 ? '0' + String(month) : month
      day = day < 10 ? '0' + String(day) : day

      return year + '.' + month + '.' + day
    },
    today() {
      let d = new Date()
      return this.getDateStr(d)
    },
    lastWeek() {
      let d = new Date()
      let dayOfMonth = d.getDate()
      d.setDate(dayOfMonth - 7)
      return this.getDateStr(d)
    },
    lastMonth() {
      let d = new Date()
      let monthOfYear = d.getMonth()
      d.setMonth(monthOfYear - 1)
      return this.getDateStr(d)
    },
    calChange(value) {
      if (value == 'week') {
        this.startDate = this.today()
        this.endDate = this.lastWeek()
      } else if (value == 'month') {
        this.startDate = this.today()
        this.endDate = this.lastMonth()
      }
    },
    isNan(val) {
      return val != undefined && val != null && val != '' ? true : false
    }
  }
}
</script>
