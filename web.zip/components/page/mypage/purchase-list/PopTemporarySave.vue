<template>
  <v-popup :visible="visible" :width="'550px'" :footer="['confirm']" @close="$emit('close')" @confirm="$emit('close')">
    <template slot="header">
      <div class="title">임시저장 안내</div>
    </template>
    <template slot="body">
      <p class="contents-head t-center">임시저장 완료!</p>

      <!-- 2021.03.24 (ver1.1) -->
      <p class="text-main t-gray">면세신고 기한 내 서류 작성 후, 접수해 주세요.</p>
    </template>
  </v-popup>
</template>

<script>
import { VPopup } from '~/components/element'
export default {
  components: {
    VPopup
  },
  props: {
    visible: {
      type: Boolean,
      default: false
    }
  }
}
</script>