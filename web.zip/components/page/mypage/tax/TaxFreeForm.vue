<template>
<div class="taxfreefrom">
    <!-- 폼영역 -->
    <div class="form-grid-list section">
      <p class="section-tit">면세 구입자(신고인) 인적사항</p>
      <ul>
        <li class="w50">
          <strong class="form-label bold">성명</strong>
          <div class="form-group label-input">
            <label class="offscreen">성명</label>
            <v-input v-model="formData.name" :disabled="true"></v-input>
          </div>
        </li>
        <li class="clear w50">
          <strong class="form-label bold">주민등록번호</strong>
          <div class="form-group label-input">
            <label class="offscreen">주민등록번호</label>
            <v-input v-model="formData.personNum" :disabled="true"></v-input>
          </div>
        </li>
        <li class="clear w50">
          <strong class="form-label bold">휴대전화번호</strong>
          <div class="form-group label-input">
            <label class="offscreen">휴대전화번호</label>
            <v-input v-model="formData.name" :disabled="true"></v-input>
          </div>
        </li>
        <li>
          <strong class="form-label bold">주소</strong>
          <div class="form-group label-input">
            <label class="offscreen">주소</label>
            <v-input v-model="formData.address" :disabled="true"></v-input>
          </div>
        </li>
      </ul>
    </div>
    <div class="form-grid-list section">
      <p class="section-tit">공동등록자 인적사항 1</p>
      <ul>
        <li class="w50">
          <strong class="form-label bold">성명</strong>
          <div class="form-group label-input">
            <label class="offscreen">성명</label>
            <v-input v-model="formData.name" :disabled="true"></v-input>
          </div>
        </li>
        <li class="w50">
          <strong class="form-label bold">주계약자와의 관계</strong>
          <div class="form-group label-input">
            <label class="offscreen">주계약자와의 관계</label>
            <v-input v-model="formData.relation" :disabled="true"></v-input>
          </div>
        </li>
        <li class="clear w50">
          <strong class="form-label bold">주민등록번호</strong>
          <div class="form-group label-input">
            <label class="offscreen">주민등록번호</label>
            <v-input v-model="formData.personNum" :disabled="true"></v-input>
          </div>
        </li>
        <li class="clear w50">
          <strong class="form-label bold">휴대전화번호</strong>
          <div class="form-group label-input">
            <label class="offscreen">휴대전화번호</label>
            <v-input v-model="formData.name" :disabled="true"></v-input>
          </div>
        </li>
        <li>
          <strong class="form-label bold">주소</strong>
          <div class="form-group label-input">
            <label class="offscreen">주소</label>
            <v-input v-model="formData.address" :disabled="true"></v-input>
          </div>
        </li>
      </ul>
    </div>
    <div class="form-grid-list section">
      <p class="section-tit">면세신고 사항</p>
      <ul>
        <li class="w50">
          <strong class="form-label bold">증서구분</strong>
          <div class="form-group">
            <v-select
              v-model="selectVal"
              :data="selectList"
              style="width:100%;"
            />
          </div>
        </li>
        <li class="w50">
          <strong class="form-label bold">장애등급</strong>
          <div class="form-group">
            <v-select
              v-model="selectVal"
              :data="selectList"
              style="width:100%;"
              aria-placeholder="선택해 주세요"
            />
          </div>
        </li>
        <li class="w50">
          <strong class="form-label bold">증빙증서</strong>
          <div class="form-group">
             <v-select
              v-model="selectVal"
              :data="selectList"
              style="width:100%;"
              aria-placeholder="선택해 주세요"
            />
          </div>
        </li>
        <li class="w50">
          <strong class="form-label bold">발급기관</strong>
          <div class="form-group label-input">
            <label class="offscreen">발급기관</label>
            <v-input v-model="formData.name" placeholder="발급기관"></v-input>
          </div>
        </li>
        <li class="w50">
          <strong class="form-label bold">장애 등록일</strong>
          <div class="form-group label-input">
            <label class="offscreen">장애 등록일</label>
            <v-date-picker v-model="dateVal" class="datepicker box-st" placeholder="선택해 주세요" />
          </div>
        </li>
        <li class="w50">
          <strong class="form-label bold">발급일</strong>
          <div class="form-group label-input">
            <label class="offscreen">발급일</label>
            <v-date-picker v-model="dateVal" class="datepicker box-st" placeholder="선택해 주세요" />
          </div>
        </li>
        <li class="w50">
          <strong class="form-label bold">직업</strong>
          <div class="form-group">
            <v-select
              v-model="selectVal"
              :data="selectList"
              style="width:100%;"
            />
          </div>
        </li>
        <li class="w50">
          <strong class="form-label bold">구입목적</strong>
          <div class="form-group">
            <v-select
              v-model="selectVal"
              :data="selectList"
              style="width:100%;"
              placeholder="선택해 주세요"
            />
          </div>
        </li>
        <li class="w50">
          <strong class="form-label bold">자동차등록번호</strong>
          <div class="form-group label-input">
            <label class="offscreen">자동차등록번호</label>
            <v-input v-model="formData.name" placeholder="예) 12가1234"></v-input>
          </div>
        </li>
        <li class="w50">
          <strong class="form-label bold">자동차 등록일</strong>
          <div class="form-group label-input">
            <label class="offscreen">자동차 등록일</label>
            <v-date-picker v-model="dateVal" class="datepicker box-st" placeholder="선택해 주세요" />
          </div>
        </li>
        <!-- 2021.03.24 (ver1.1) 보훈번호추가 -->
        <li class="w50">
          <strong class="form-label bold">보훈번호</strong>
          <div class="form-group label-input">
            <label class="offscreen">보훈번호</label>
            <v-input v-model="formData.name" placeholder="예) 12345678"></v-input>
          </div>
        </li>
      </ul>
    </div>

    <!-- 증빙항목 -->
    <div class="section">
      <p class="section-tit">증빙항목</p>
      <ul class="bullet-list">
        <li>선택한 항목에 알맞은 서류를 증빙해 주세요.</li>
        <li>확장자는 jpg, jpeg, gif, pdf만 가능합니다.(파일당 3MB 미만)</li>
        <li>첨부파일에 주민등록번호 뒷부분 7자리가 있는 경우, 해당 내역은 가리고 업로드 바랍니다.</li>
        <li>업로드한 파일이 있을 경우, 파일 삭제 후 재 업로드 하시기 바랍니다.</li>
      </ul>
      <div class="judge-file-upload">
        <ul>
          <li v-for="(item, index) in fileList" :key="index">
            <div class="seq">증빙 {{ index + 1 }}</div>
            <div class="file-label">{{ item.name }}</div>
            <div class="file-name">
              <div class="file-input label-input">
                <label class="offscreen">파일첨부</label>
                <input
                  :ref="`fileInput`"
                  type="file"
                  :class="`offscreen fileInput${index}`"
                  @change="changeFile($event, index)"
                />
              </div>
              <span v-if="item.val != ''" class="file">
                {{ item.val }}
                <v-btn class="btn-file-delete" type="button" @click="fileDelete(index)"
                  ><span class="offscreen">파일삭제</span></v-btn
                >
              </span>
              <span class="error">실패 사유 메세지를 노출해주세요</span>
            </div>
            <div class="file-btn">
              <v-btn
                class="file-btn btn-more"
                :disabled="item.val != ''"
                type="button"
                @click="fileOpen(index)"
                >파일 업로드</v-btn
              >
            </div>
            <span class="status t-black">완료</span>
          </li>
        </ul>
      </div>
    </div>
    <!-- 개별소비세 조건부 면세승용차를 구입한 자가 지켜야 할 사항 -->
    <div class="section">
      <p class="section-tit">개별소비세 조건부 면세승용차를 구입한 자가 지켜야 할 사항</p>
      <div class="rule-box">
          개별소비세법 제18조 제1항 제5호, 제2항, 제4항 및 같은법시행령 제19조의3, 제31조, 제33조의 규정에 의하여 개별소비세 조건부 면세 승용차를 구입하는 사람(법인)이 지켜야 할 사항을 다음과 같이 알려드립니다.
          <br />
          <br />
          1. 개별소비세가 면세되는 승용차를 구입하려는 사람(법인)은 면세입법취지에 부합되도록 성실하게 「승용차 개별소비세 조건부 면세 구입. 반출신고서」를 기재하여 제출하여야 하며 승용차 영업소로부터 교부받은 동 서식1부는 5년간 보관하여야 합니다. 모든 기재사항은 산처리된 후 각 항목별로 해당 정부기관에 의뢰하여 주기적으로 전신검증하니 성실하게 작성하여야 합니다.
          <br />
          <br />
          2. 면세승용차를 구입한 후에는 반드시 법정기관내에 시.구청에 자동차등록을 하여야만 개별소비세가 면세됩니다. 면세구입한 달의 다음달 20일까지 자동차영업소에 자동차등록에 관한 사항을 통보하여야 합니다.
          개별소비세법 제18조 제1항 제5호, 제2항, 제4항 및 같은법시행령 제19조의3, 제31조, 제33조의 규정에 의하여 개별소비세 조건부 면세 승용차를 구입하는 사람(법인)이 지켜야 할 사항을 다음과 같이 알려드립니다.
          <br />
          <br />
          1. 개별소비세가 면세되는 승용차를 구입하려는 사람(법인)은 면세입법취지에 부합되도록 성실하게 「승용차 개별소비세 조건부 면세 구입. 반출신고서」를 기재하여 제출하여야 하며 승용차 영업소로부터 교부받은 동 서식1부는 5년간 보관하여야 합니다. 모든 기재사항은 산처리된 후 각 항목별로 해당 정부기관에 의뢰하여 주기적으로 전신검증하니 성실하게 작성하여야 합니다.
          <br />
          <br />
          2. 면세승용차를 구입한 후에는 반드시 법정기관내에 시.구청에 자동차등록을 하여야만 개별소비세가 면세됩니다. 면세구입한 달의 다음달 20일까지 자동차영업소에 자동차등록에 관한 사항을 통보하여야 합니다.
      </div>
      <v-checkbox :one-check="true" :checked.sync="agreeVal"><span class="t-blue">개별소비세 조건부 면세승용차를 구입한 자가 지켜야 할 사항</span>을 확인하였습니다. (필수)</v-checkbox>
    </div>
</div>
</template>

<script>
export default {
  components: {
  },
  data() {
    return {
      formData: [
        {
          name: '김현대',
          personNum: '800218 - 1******',
          phone: '01029387648',
          address: '서울특별시 서초구 강남대로 331(서초동) 111',
        }
      ],
      fileList: [
        { name: '장애인 복지카드(앞면)', val: '장애인 복지카드(앞면).jpg' },
        { name: '장애인 복지카드(뒷면)', val: '장애인 복지카드(뒷면).jpg' },
        { name: '자동차 등록원부', val: '' },
        { name: '주민등록등본', val: '' }
      ],
      selectVal :'',
      selectList: [
        { value: '', label: '선택해주세요' },
        { value: 'select1', label: '선택1' },
        { value: 'select2', label: '선택2' },
        { value: 'select3', label: '선택3' }
      ],
      agreeVal: false,
      dateVal: '',
      veteransVal: ''
    }
  },
  methods: {
    changeFile(e, index) {
      var files = e.target.files || e.dataTransfer.files
      this.fileList[index].val = files[0].name
    },
    fileDelete(index) {
      this.fileList[index].val = ''
      // document.querySelector(`.fileInput${index}`).value = ''
    },
    fileOpen(index) {
      document.querySelector(`.fileInput${index}`).click()
    }
  }
}
</script>
