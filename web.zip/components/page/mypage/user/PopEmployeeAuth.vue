<template>
  <v-popup
    :visible="visible"
    :footer="['confirm']"
    :width="'550px'"
    @close="
      $emit('close')
      popVisible = false
    "
    @confirm="
      $emit('close')
      popVisible = false
    "
  >
    <template slot="header">
      <div class="title">직원 인증 안내</div>

      <!-- 2021.03.31 (ver1.1) 전체수정 -->
      <p class="header-description">
        <!-- 2021.04.08 (ver1.2) 텍스트수정 -->
        직원 인증은 현대자동차를 위해 함께 애써주시는<br />그룹사 및 협력사 직원을 위한 서비스입니다.
      </p>
    </template>
    <template slot="body">
      <ul class="bullet-list">
        <li><strong>화면 상단의 “진행상태” 에서 각 단계 요청 내역 및 진행상황을 확인하실 수 있습니다.</strong></li>
        <li><strong>각 단계에서 요청하는 서류 및 내용을 충실히 등록 및 기재해주세요.</strong></li>
        <li><strong>올려주신 서류는 일일이 확인을 거치므로 시간이 소요될 수 있습니다.</strong></li>
      </ul>
      <ul class="body-contents">
        <li>
          <p class="text-main t-left t-gray">각 서류 요청 사유는 다음과 같습니다.</p>
        </li>
        <li>
          <p class="text-main t-left t-gray">기본 서류</p>
          <ul class="bullet-list">
            <li><strong>재직증명서, 명예 사원증, 임원 우대증 중 택1</strong> : 직원 재직 여부 및 DC율 확인</li>
            <!-- 2021.04.08 (ver1.2) 텍스트수정 -->
            <li><strong>가족관계증명서</strong> : 임직원 배우자 명의로 직원DC 받은 내역 확인</li>
          </ul>
        </li>
        <li>
          <p class="text-main t-left t-gray">추가 서류</p>
          <ul class="bullet-list">
            <!-- 2021.04.08 (ver1.2) 텍스트수정 -->
            <li><strong>차량구입 대상자 확인서</strong> : 일부 회사의 경우, 해당 서류로 재직여부 추가 확인</li>
            <li><strong>4대 보험 가입자 가입내역 확인서</strong> : 일부 회사의 경우, 해당 서류로 재직여부 추가 확인</li>
            <li><strong>근속 DC 확인서</strong> : 일부 회사의 경우, 해당 서류로 근속 연수 추가 확인</li>
          </ul>
        </li>
      </ul>
    </template>
  </v-popup>
</template>

<script>
import { VPopup } from '~/components/element'
export default {
  components: {
    VPopup
  },
  props: {
    visible: {
      type: Boolean,
      default: false
    }
  }
}
</script>
