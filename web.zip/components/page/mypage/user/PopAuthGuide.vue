<template>
  <v-popup
    :visible="visible"
    :width="'550px'"
    @close="
      $emit('close')
      popVisible = false
    "
    @confirm="
      $emit('close')
      popVisible = false
    "
  >
    <template slot="header">
      <div class="title">직원할인 구매방법 안내</div>
    </template>
    <template slot="body">
      <div class="auth-guide">
        <ul>
          <li>
            <p>마이페이지에서</p>
            <p class="t-blue">직원여부 인증</p>
          </li>
          <li>
            <p>결제 시</p>
            <p class="t-blue">최종인증</p>
          </li>
        </ul>
        <p class="bullet">결제 시 재직 여부에 따라 직원 할인이 적용되지 않을 수 있습니다.</p>
      </div>
    </template>
  </v-popup>
</template>

<script>
import { VPopup } from '~/components/element'
export default {
  components: {
    VPopup
  },
  props: {
    visible: {
      type: Boolean,
      default: false
    }
  }
}
</script>
