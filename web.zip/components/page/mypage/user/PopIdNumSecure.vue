<template>
  <v-popup
    :visible="visible"
    :width="'550px'"
    @close="
      $emit('close')
      popVisible = false
    "
  >
    <template slot="header">
      <div class="title">주민번호 뒷자리 처리 안내</div>
      <p class="header-description">
        서류의 주민등록번호 뒷자리를<br />다음과 같이 보이지 않게 처리해주세요.
      </p>
    </template>
    <template slot="body">
      <div class="body-contents bbnone">
        <div class="id-secure">
          <div class="text-main">주민등록 번호</div>
          <p class="id-num">800125 -</p>
        </div>
      </div>
    </template>
  </v-popup>
</template>

<script>
import { VPopup } from '~/components/element'
export default {
  components: {
    VPopup
  },
  props: {
    visible: {
      type: Boolean,
      default: false
    }
  }
}
</script>
