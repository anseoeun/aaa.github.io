<template>
  <v-popup
    :visible="visible"
    :width="'550px'"
    :footer="['confirm']"
    @close="
      $emit('close')
      popVisible = false
    "
    @confirm="
      $emit('close')
      popVisible = false
    "
  >

    <template slot="header">
      <div class="title">탈퇴 불가 알림</div>
    </template>
    <template slot="body">
      <p class="text-main">
        진행 중인 계약 건이 있으므로 회원 탈퇴가 불가합니다.<br />계약취소 또는 계약완료 후 탈퇴하실 수 있습니다.
      </p>
    </template>
  </v-popup>
</template>

<script>
import { VPopup } from '~/components/element'
export default {
  components: {
    VPopup
  },
  props: {
    visible: {
      type: Boolean,
      default: false
    },
  },
}
</script>