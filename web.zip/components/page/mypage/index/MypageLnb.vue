<template>
  <div class="mypage-lnb">
    <ul class="main-menu">
      <li>
        <strong class="title">나의 계약</strong>
        <ul class="sub-menu">
          <li>
            <nuxt-link to="/">구매(계약/결제)내역</nuxt-link>
          </li>
          <li>
            <nuxt-link to="/">증빙서류 제출 내역</nuxt-link>
          </li>
          <li>
            <nuxt-link to="/">면세신고 내역</nuxt-link>
          </li>
        </ul>
      </li>
      <li>
        <strong class="title">나의 활동</strong>
        <ul class="sub-menu">
          <li>
            <nuxt-link to="/" class="active">견적 내역</nuxt-link>
          </li>
          <li class="active">
            <nuxt-link to="/">시승 신청 내역</nuxt-link>
          </li>
          <li>
            <nuxt-link to="/">1:1 문의 내역</nuxt-link>
          </li>
          <li>
            <nuxt-link to="/">구매후기</nuxt-link>
          </li>
        </ul>
      </li>
      <li>
        <strong class="title">나의 혜택</strong>
        <ul class="sub-menu">
          <li>
            <nuxt-link to="/">쿠폰 내역</nuxt-link>
          </li>
          <li>
            <nuxt-link to="/">임직원 인증</nuxt-link>
          </li>
        </ul>
      </li>
    </ul>
    <div class="notice-menu">
      <nuxt-link to="/">MY 알림 전체보기</nuxt-link>
    </div>
  </div>
</template>
