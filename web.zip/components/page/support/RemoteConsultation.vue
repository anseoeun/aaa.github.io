<template>
  <v-popup
    :visible="visible"
    :width="'830px'"
    @close="
      $emit('close')
      popVisible = false
    "
  >
    <template slot="header">
      <div class="title">차량구매 원격상담 서비스</div>
      <p class="header-description">
        차량구매 사이트 이용 중 직원이 고객님과 같은 PC 화면을 보면서 도움을 드리는 서비스입니다.
      </p>
    </template>
    <template slot="body">
      <div class="body-contents">
        <p class="contents-head">원격상담 이용 안내</p>
        <div class="contents-box-wrap">
          <div class="contents-box">
            <div class="contents-box-header">
              ① 차량구매 지원센터로 전화 주세요.
            </div>
            <ul class="bullet-list">
              <li>전화번호 : 02-0000-0000</li>
              <li>운영시간 : 평일 09:00~17:00</li>
            </ul>
          </div>
          <div class="contents-box">
            <div class="contents-box-header">
              ② 직원 안내 시 위 [원격상담 요청하기] 버튼 클릭하세요.
            </div>
            <p class="bullet">[원격상담 요청하기] 버튼 선택 후 직원 안내에 따라 원격상담이 진행됩니다.</p>
            <v-btn class="btn-more" type="nlink">원격상담 요청하기</v-btn>
          </div>
        </div>
      </div>
      <div class="notice">
        <div class="title">유의사항</div>
        <ul class="bullet-list">
          <li>원격상담 시 상담원이 고객님의 PC를 원격으로 접속하게 됩니다.</li>
          <li>원격상담의 모든 내용은 녹화됩니다.</li>
          <li>필요 시 상담사가 고객님의 PC 화면을 캡쳐할 수 있습니다.</li>
          <li>단순한 사이트 이용 방법 및 구매 방법에 대한 문의는 원격상담을 지원하지 않습니다.</li>
        </ul>
      </div>
    </template>
  </v-popup>
</template>

<script>
import { VPopup } from '~/components/element'
export default {
  components: {
    VPopup
  },
  props: {
    visible: {
      type: Boolean,
      default: false
    },
    data: {
      type: Object,
      default: () => {}
    }
  },
}
</script>