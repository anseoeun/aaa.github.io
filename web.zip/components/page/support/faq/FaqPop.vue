<template>
  <v-popup
    :visible="visible"
    class="faq-popup"
    :footer="['confirm']"
    @close="
      $emit('close')
    "
    @confirm="
      $emit('close')
    "
  >
    <template slot="header">
      <div class="title">자주하는 질문</div>
    </template>
    <template slot="body">
      <faq-list :faq-list="faqList" class="toggle-list" :no-page="true" />
    </template>
  </v-popup>
</template>

<script>
import { VPopup } from '~/components/element'
import FaqList from '~/components/page/support/faq/FaqList'
export default {
  components: {
    VPopup,
    FaqList
  },
  props: {
    visible: {
      type: Boolean,
      default: false
    },
  },
  data() {
    return {
      faqList: [
        {
          seq: 1,
          category: `[차량구매 > 전체]`,
          title: `장애인면세공동명의로 구입하려고 하는데 꼭 세대합가를 해야 하나요?`,
          content: `<div class="faq-cont">▶장애인 차량 구입시에는 ①개별 소비세, ②지방세, ③공채 항목시에 <span class="key">면세</span>  혜택이 있습니다.  서울시 기준으로는 심한장애인, 국가유공상이자(1~7급), 고엽제 후유증(경도~고도), 광주민주화운동 부상자(1급~14급)은 장애인 조건으로 차량 구입시 심한 장애인, 국가유공상이자(1~7급), 고엽제 후유증(경도~고도), 광주</p>
          </div>`,
        },
        {
          seq: 2,
          category: `[차량구매 > 계약]`,
          title: `장애인 면세공동명의로 구입하려고 하는데 꼭 세대합가를 해야 하나요?`,
          content: `<div class="faq-cont">▶장애인 차량 구입시에는 ①개별 소비세, ②지방세, ③공채 항목시에 <span class="key">면세</span>  혜택이 있습니다.  서울시 기준으로는 심한장애인, 국가유공상이자(1~7급), 고엽제 후유증(경도~고도), 광주민주화운동 부상자(1급~14급)은 장애인 조건으로 차량 구입시 심한 장애인, 국가유공상이자(1~7급), 고엽제 후유증(경도~고도), 광주</p>
          </div>`,
        },
      ]
    }
  }
}
</script>

