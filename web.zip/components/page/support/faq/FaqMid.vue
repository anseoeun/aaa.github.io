<template>
  <section>
    <div v-if="midList === 'default'">
      <v-tab
        v-if="faqInfo.mainTabYN === 'Y'"
        class="tab-default"
        :data="faqInfo.mainTabList"
        :contents="true"
        :cols="faqInfo.mainTabList.length"
        trigger="click hover"
        @change="onChangeMainTab1"
        @mouseenter="onChangeMainTab1"
      >
        <template slot="contents">
          <div
            v-for="(mainTabItem, mainTabIndex) in faqInfo.mainTabList"
            :key="mainTabIndex"
            :data-id="mainTabItem.value"
          >
            <!-- 소분류탭 -->
            <v-tab
              v-if="faqInfo.subTabYN === 'Y'"
              class="tab-sub"
              :data="faqInfo.subTabList"
              :contents="true"
              @change="onChangeSubTab1"
            >
              <template slot="contents">
                <div
                  v-for="(subTabItem, subTabIndex) in faqInfo.subTabList"
                  v-show="isClick"
                  :key="subTabIndex"
                  :data-id="subTabItem.value"
                >
                  <faq-list :faq-list="faqInfo.faqList" />
                </div>
              </template>
            </v-tab>
          </div>
        </template>
      </v-tab>
    </div>
    <div v-if="midList === 'result'" class="list">
      <div>
        <faq-list :faq-list="faqInfo.faqList" />
      </div>
    </div>
  </section>
</template>

<script>
import { VTab } from '~/components/element'
import FaqList from '~/components/page/support/faq/FaqList'
export default {
  components: {
    VTab,
    FaqList,
  },
  props: {
    midList: {
      type: String,
      default: 'default',
    },
    faqInfo: {
      type: Object,
      default: () => {},
    },
  },
  data() {
    return {
      tabFaqInfo: {},
      subTabList: [],
      tabFaqList: [],
      currentTab:'tab1',
      isClick: false
    }
  },
  computed: {
    resFaqInfo() {
      let newFaqList = {}
      if (this.faqInfo !== null) {
        newFaqList = Object.assign(this.faqInfo)
      }
      return newFaqList
    },
  },
  methods: {
    onChangeMainTab1(obj, index, evtType) {
      if(evtType === 'click'){
         this.isClick = true
      }else {
        this.isClick = false
      }

      if(evtType == 'click') this.$nuxt.$emit('tab-click')
      else this.$nuxt.$emit('tab-change')

      this.currentTab = obj.value
      if (obj.value === 'tab1') {
        this.resFaqInfo.subTabList = [
          { value: 'sub1', label: '전체' },
          { value: 'sub2', label: '계약' },
          { value: 'sub3', label: '결제' },
          { value: 'sub4', label: '차량 배송 및 인수' },
          { value: 'sub5', label: '보험/등록' },
          { value: 'sub6', label: '중고차/폐차' },
          { value: 'sub7', label: '세금' },
          { value: 'sub8', label: '취소' },
        ]
        this.onChangeSubTab1({ value: 'sub1', label: '전체' })
        this.$emit('update:faqInfo', this.resFaqInfo)
      } else if (obj.value === 'tab2') {
        this.resFaqInfo.subTabList = [
          { value: 'sub1', label: '전체' },
          { value: 'sub2', label: '회원 및 혜택' },
          { value: 'sub3', label: '카드/포인트' },
          { value: 'sub4', label: '제휴/서비스' },
        ]
        this.onChangeSubTab1({ value: 'sub1', label: '전체' })
        this.$emit('update:faqInfo', this.resFaqInfo)
      } else if (obj.value === 'tab3') {
        this.resFaqInfo.subTabList = [
          { value: 'sub1', label: '전체' },
          { value: 'sub2', label: '구매 규정' },
        ]
        this.onChangeSubTab1({ value: 'sub1', label: '전체' })
        this.$emit('update:faqInfo', this.resFaqInfo)
      } else if (obj.value === 'tab4') {
        this.resFaqInfo.subTabList = [
          { value: 'sub1', label: '전체' },
          { value: 'sub2', label: '회원 및 이용' },
        ]
        this.onChangeSubTab1({ value: 'sub1', label: '전체' })
        this.$emit('update:faqInfo', this.resFaqInfo)
      }
    },
    onChangeSubTab1(obj, index, evtType) {
      if(evtType === 'click'){
         this.isClick = true
      }

      if(evtType == 'click') this.$nuxt.$emit('tab-click')
      else this.$nuxt.$emit('tab-change')

      // console.log('sub - ', obj)
      if(this.currentTab === 'tab1'){
        if (obj.value === 'sub1') {
          this.resFaqInfo.faqList = [
            {
              seq: 1,
              category: `[차량구매 > 전체]`,
              title: `임시운행기간중에 차량 사고가 발생했습니다. 어떻게 해야 하나요?`,
              content: `<div class="faq-cont">▶[차량구매] 차량 계약 후 해지시 계약금은 환불 받을 수 있습니까?
              <p>즉시출고차, 할인차, 전시차, 판촉차, 생산주문 차량의 경우 차량 대금 결제 전, 마이페이지에서 계약 해약 시 계약금 환불이 가능합니다. 하지만 특별주문
              차량의 경우 계약 해지시 계약금 환불이 불가합니다. 계약금을 현금으로 납부하셨다면 계약 해지시 입력하신 환불계좌로 계약금이 환불되며, 계약금을
              카드로 납부하셨다면 7일 이내 카드 결제가 취소 됩니다.</p>
              </div>`,
            },
            {
              seq: 2,
              category: `[차량구매 > 전체]`,
              title: `임시운행기간중에 차량 사고가 발생했습니다. 어떻게 해야 하나요?`,
              content: `<div class="faq-cont">▶[차량구매] 차량 계약 후 해지시 계약금은 환불 받을 수 있습니까?
              <p>즉시출고차, 할인차, 전시차, 판촉차, 생산주문 차량의 경우 차량 대금 결제 전, 마이페이지에서 계약 해약 시 계약금 환불이 가능합니다. 하지만 특별주문
              차량의 경우 계약 해지시 계약금 환불이 불가합니다. 계약금을 현금으로 납부하셨다면 계약 해지시 입력하신 환불계좌로 계약금이 환불되며, 계약금을
              카드로 납부하셨다면 7일 이내 카드 결제가 취소 됩니다.</p>
              </div>`,
            },
          ]
          this.$emit('update:faqInfo', this.resFaqInfo)
        }else if (obj.value === 'sub2') {
          this.resFaqInfo.faqList = [
            {
              seq: 1,
              category: `[차량구매 > 계약]`,
              title: `임시운행기간중에 차량 사고가 발생했습니다. 어떻게 해야 하나요?`,
              content: `<div class="faq-cont">▶[차량구매] 차량 계약 후 해지시 계약금은 환불 받을 수 있습니까?
              <p>즉시출고차, 할인차, 전시차, 판촉차, 생산주문 차량의 경우 차량 대금 결제 전, 마이페이지에서 계약 해약 시 계약금 환불이 가능합니다. 하지만 특별주문
              차량의 경우 계약 해지시 계약금 환불이 불가합니다. 계약금을 현금으로 납부하셨다면 계약 해지시 입력하신 환불계좌로 계약금이 환불되며, 계약금을
              카드로 납부하셨다면 7일 이내 카드 결제가 취소 됩니다.</p>
              </div>`,
            },
            {
              seq: 2,
              category: `[차량구매2 > 계약]`,
              title: `임시운행기간중에 차량 사고가 발생했습니다. 어떻게 해야 하나요?`,
              content: `<div class="faq-cont">▶[차량구매] 차량 계약 후 해지시 계약금은 환불 받을 수 있습니까?
              <p>즉시출고차, 할인차, 전시차, 판촉차, 생산주문 차량의 경우 차량 대금 결제 전, 마이페이지에서 계약 해약 시 계약금 환불이 가능합니다. 하지만 특별주문
              차량의 경우 계약 해지시 계약금 환불이 불가합니다. 계약금을 현금으로 납부하셨다면 계약 해지시 입력하신 환불계좌로 계약금이 환불되며, 계약금을
              카드로 납부하셨다면 7일 이내 카드 결제가 취소 됩니다.</p>
              </div>`,
            },
          ]
          this.$emit('update:faqInfo', this.resFaqInfo)
        }else{
          this.resFaqInfo.faqList=[]
        }
      }else if(this.currentTab === 'tab2'){
         if (obj.value === 'sub1') {
          this.resFaqInfo.faqList = [
            {
              seq: 1,
              category: '[블루멤버스 > 전체]',
              title: '임시운행기간중에 차량 사고가 발생했습니다. 어떻게 해야 하나요?',
              content: `<div class="faq-cont">▶[차량구매] 차량 계약 후 해지시 계약금은 환불 받을 수 있습니까?
              <p>즉시출고차, 할인차, 전시차, 판촉차, 생산주문 차량의 경우 차량 대금 결제 전, 마이페이지에서 계약 해약 시 계약금 환불이 가능합니다. 하지만 특별주문
              차량의 경우 계약 해지시 계약금 환불이 불가합니다. 계약금을 현금으로 납부하셨다면 계약 해지시 입력하신 환불계좌로 계약금이 환불되며, 계약금을
              카드로 납부하셨다면 7일 이내 카드 결제가 취소 됩니다.</p>
              </div>`,
            },
            {
              seq: 2,
              category: '[블루멤버스 > 전체]',
              title: '임시운행기간중에 차량 사고가 발생했습니다. 어떻게 해야 하나요?',
              content: `<div class="faq-cont">▶[차량구매] 차량 계약 후 해지시 계약금은 환불 받을 수 있습니까?
              <p>즉시출고차, 할인차, 전시차, 판촉차, 생산주문 차량의 경우 차량 대금 결제 전, 마이페이지에서 계약 해약 시 계약금 환불이 가능합니다. 하지만 특별주문
              차량의 경우 계약 해지시 계약금 환불이 불가합니다. 계약금을 현금으로 납부하셨다면 계약 해지시 입력하신 환불계좌로 계약금이 환불되며, 계약금을
              카드로 납부하셨다면 7일 이내 카드 결제가 취소 됩니다.</p>
              </div>`,
            },
          ]
          this.$emit('update:faqInfo', this.resFaqInfo)
        }else{
          this.resFaqInfo.faqList=[]
        }
      }
    },
  },
}
</script>
