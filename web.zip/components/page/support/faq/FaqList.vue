<template>
  <div>
    <template v-if="faqList.length > 0">
      <v-list-group v-model="subSelected" :accordion="true">
        <v-list-item
          v-for="(item, index) in faqList"
          :key="index"
          :data-id="String(index + 1)"
        >
          <template slot="label">
            <span class="list-category">{{ item.category }}</span>
            <span class="list-content"><span v-html="item.title"></span></span>
          </template>
          <div v-html="item.content"></div>
        </v-list-item>
      </v-list-group>
      <!-- <VPagination-pub /> -->
      <v-page-more v-if="!noPage" :total="30" :page="10" />
    </template>
    <template v-else>
      <div class="list-null">
        <p>검색된 결과가 없습니다.</p>
      </div>
    </template>
  </div>
</template>

<script>
import {VListGroup , VListItem, VPageMore} from '~/components/element'
export default {
  components: {
    VListGroup,
    VListItem,
    VPageMore
  },
  props: {
    faqList: {
      type: Array,
      default: () => [],
    },
    noPage:{
      type:Boolean,
      default:false,
    },
  },
  data() {
    return {
      subSelected: ['6'],
    }
  },
}
</script>
