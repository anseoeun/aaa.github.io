<template>
  <v-popup
    :visible="visible"
    :width="'776px'"
    :footer="['cancel','confirm']"
    @close="
      $emit('close')
      popVisible = false
    "
  >
    <template slot="header">
      <div class="title">구매 차량 선택</div>
      <p class="header-description">문의하실 구매 차량을 선택해주세요.</p>
    </template>
    <template slot="body">
      <p class="contents-head">총 <span class="t-blue">15</span>대</p>
      <ul class="purchase-vehicle-list">
        <li v-for="(item, index) in vehicleList" :key="index">
          <v-img :src="item.imgSrc" :alt="item.carAlt"></v-img>
          <ul>
            <li v-for="(data, idx) in item.dataList" :key="idx">
              <span>{{ data.title }}</span>
              <em>{{ data.cont }}</em>
            </li>
          </ul>
          <v-radio v-model="carList" :one-check="true" :label="index" class="radio-button-single">선택</v-radio>
        </li>
      </ul>
      <v-page-more :total="30" :page="1" />
    </template>
  </v-popup>
</template>

<script>
import { VPopup, VPageMore } from '~/components/element'
export default {
  components: {
    VPopup,
    VPageMore
  },
  props: {
    visible: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      carList: '',
      vehicleList: [
        {
          imgSrc: require('~/assets/images/temp/temp-mypage-car-visual.png'),
          imgAlt: '',
          dataList: [
            { title: '계약일', cont: '2021.03.01' },
            { title: '계약번호', cont: '1234657980' },
            { title: '차량정보', cont: '쏘나타 센슈어스(가솔린1.6T) Premium (자가용 스마트 스트림) 가솔린 1.6 터보' }
          ]
        },
        {
          imgSrc: require('~/assets/images/temp/temp-mypage-car-visual.png'),
          imgAlt: '',
          dataList: [
            { title: '계약일', cont: '2021.03.01' },
            { title: '계약번호', cont: '1234657980' },
            { title: '차량정보', cont: '쏘나타 센슈어스(가솔린1.6T) Premium (자가용 스마트 스트림) 가솔린 1.6 터보' }
          ]
        },
        {
          imgSrc: require('~/assets/images/temp/temp-mypage-car-visual.png'),
          imgAlt: '',
          dataList: [
            { title: '계약일', cont: '2021.03.01' },
            { title: '계약번호', cont: '1234657980' },
            { title: '차량정보', cont: '쏘나타 센슈어스(가솔린1.6T) Premium (자가용 스마트 스트림) 가솔린 1.6 터보' }
          ]
        }
      ]
    }
  }
}
</script>