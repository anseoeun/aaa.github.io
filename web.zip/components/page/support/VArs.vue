<template>
  <v-popup
    :visible="visible"
    :width="'948px'"
    @close="
      $emit('close')
      popVisible = false
    "
  >
    <template slot="header">
      <div class="title">보이는 ARS 이용방법</div>
      <p class="header-description">
        ARS로 전화를 걸었을 때, 상담원 연결 없이 직접 화면을 보면서 편리하게 각종 안내 및 조회 메뉴를 이용하실 수 있는 서비스입니다.
      </p>
    </template>
    <template slot="body">
      <div class="ars-info">
        <div class="first">
          <div class="img">
            <span class="offscreen">보이는 상담접수 / 보이는 ARS 화면으로 이동</span>
          </div>
          <div class="text">
            <ul>
              <li>
                <strong><em>1</em>보이는 ARS 상담접수</strong>
                <span>080-600-6000으로 전화해<br />단축번호 1번을 누르면 상담 URL<br />을 문자메시지로 수신</span>
              </li>
              <li>
                <strong><em>2</em>보이는 ARS 화면으로 이동</strong>
                <span>통화 상태에서 상담 URL을 누르면<br />보이는 ARS 화면으로 연결</span>
              </li>
            </ul>
          </div>
        </div>
        <div class="last">
          <div class="img">
            <span class="offscreen">보이는 ARS 상담 시작</span>
          </div>
          <div class="text">
            <ul>
              <li>
                <strong><em>3</em>보이는 ARS 상담 시작</strong>
                <span>통화 상태에서 보이는 ARS 화면을<br />보며 편리하게 상담 진행</span>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </template>
  </v-popup>
</template>

<script>
import { VPopup } from '~/components/element'
export default {
  components: {
    VPopup
  },
  props: {
    visible: {
      type: Boolean,
      default: false
    },
    data: {
      type: Object,
      default: () => {}
    }
  },
}
</script>
