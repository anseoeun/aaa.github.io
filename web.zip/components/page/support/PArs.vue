<template>
  <v-popup
    :visible="visible"
    :width="'740px'"
    @close="
      $emit('close')
      popVisible = false
    "
  >
    <template slot="header">
      <div class="title">ARS 이용방법</div>
      <p class="header-description">고객센터(080-600-6000) 번호별 서비스를 안내해 드립니다. 번호를 누르면 자세한 안내를 보실 수 있습니다.</p>
    </template>
    <template slot="body">
      <div class="ars-touch">
        <div class="phone">
          <div class="customer-tell">
            <strong>고객센터 대표번호<br />080-600-6000</strong>
          </div>
          <div class="tell-number">
            <ul>
              <li>
                <el-radio v-model="cuurentInfo" label="1">
                  <em class="number">1</em>
                  <span class="text">
                    긴급출동/전기차 충전/수소전기차
                  </span>
                </el-radio>
              </li>
              <li>
                <el-radio v-model="cuurentInfo" label="2">
                  <em class="number">2</em>
                  <span class="text">정비예약</span>
                </el-radio>
              </li>
              <li>
                <el-radio v-model="cuurentInfo" label="3">
                  <em class="number">3</em>
                  <span class="text">블루멤버스</span>
                </el-radio>
              </li>
              <li>
                <em class="number">4</em>
              </li>
              <li>
                <em class="number">5</em>
              </li>
              <li>
                <em class="number">6</em>
              </li>
              <li>
                <em class="number">7</em>
              </li>
              <li>
                <em class="number">8</em>
              </li>
              <li>
                <em class="number">9</em>
              </li>
              <li>
                <em class="number">*</em>
              </li>
              <li>
                <el-radio v-model="cuurentInfo" label="0">
                  <em class="number">0</em>
                  <span class="text">상담사 연결</span>
                </el-radio>
              </li>
              <li>
                <em class="number">#</em>
              </li>
            </ul>
          </div>
        </div>
        <div class="ars-list">
          <ul>
            <li v-if="cuurentInfo === '1'" class="touchContent">
              <strong><em>1</em>긴급출동/전기차 충전/수소전기차</strong>
              <ol>
                <li><span>① 긴급출동</span></li>
                <li><span>② 전기차 충전 서비스</span></li>
                <li><span>③ 수소전기차 서비스</span></li>
              </ol>
            </li>
            <li v-if="cuurentInfo === '2'" class="touchContent">
              <strong><em>2</em>정비예약</strong>
              <ol>
                <li><span>① 정비예약 접수 및 변경, 취소</span></li>
                <li><span>② 정비예약 확인</span></li>
                <li><span>③ 서비스 점검/리콜 관련 조회</span></li>
              </ol>
            </li>
            <li v-if="cuurentInfo === '3'" class="touchContent">
              <strong><em>3</em>블루멤버스</strong>
              <ol>
                <li><span>① 비밀번호 변경</span></li>
                <li><span>② 카드 포인트 조회</span></li>
                <li><span>③ 개인 회원 상담</span></li>
                <li><span>④ 법인/리스/렌트 회원 상담</span></li>
              </ol>
            </li>
            <li v-if="cuurentInfo === '0'" class="touchContent">
              <strong><em>0</em>상담사 연결</strong>
              <ol>
                <li><span>① 차량 정비, 구입</span></li>
                <li><span>② 블루링크 센터 연결</span></li>
                <li><span>③ 디지털키</span></li>
                <li><span>④ 홈투홈 서비스</span></li>
                <li><span>⑤ 과잉수리 비용 접수</span></li>
                <li><span>⑥ 모비스 부품 관련</span></li>
              </ol>
            </li>
          </ul>
        </div>
      </div>
    </template>
  </v-popup>
</template>

<script>
import { VPopup } from '~/components/element'
export default {
  components: {
    VPopup
  },
  props: {
    visible: {
      type: Boolean,
      default: false
    },
    data: {
      type: Object,
      default: () => {}
    }
  },
  data() {
    return {
      cuurentInfo: '1',
    }
  }
}
</script>