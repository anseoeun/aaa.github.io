<template>
  <!-- 2021.03.12 (ver1.1) -->
  <!-- 2021.03.16 (ver1.2) -->
  <!-- 2021.03.23 (ver1.3) -->
  <!-- 2021.03.29 (ver1.4) -->
  <!-- 2021.03.31 (ver1.5) -->

  <!-- 2021.04.13 (ver1.6) 디자인 변경으로인한 전체적인 수정 -->
  <div class="page-step step2">
    <div class="matching-box">
      <div class="box-wrap">
        <div class="box-tit full">계약 기본정보</div>
        <div class="box-desc full">
          <!-- 직원할인 -->
          <section class="information-detail">
            <div class="summary-info">
              <h1 class="title">직원 할인 <span class="t-blue">(할인율 00%)</span></h1>
            </div>
            <div class="detail-info">
              <v-checkbox :one-check="true" :checked.sync="dicountCheck">할인 적용</v-checkbox>
            </div>
          </section>

          <!-- 명의자 정보 -->
          <section class="information-detail">
            <div class="summary-info">
              <h1 class="title">명의자 정보</h1>
              <v-btn
                class="btn-detail"
                type="icon"
                :icon-class="['icon-open', { active: isIdentyShow }]"
                @click="isIdentyShow = !isIdentyShow"
                ><span class="offscreen">상세보기</span></v-btn
              >
            </div>
            <div v-show="isIdentyShow" class="detail-info">
              <el-form ref="identifyForm" :model="ruleForm" :rules="rules">
                <!-- 명의자 1 -->
                <div class="form-grid-list">
                  <ul>
                    <li>
                      <strong class="form-label bold">명의자 1</strong>
                      <div class="form-group ct">
                        <div class="radio">
                          <el-radio v-model="ppri" label="1">주계약자로 설정</el-radio>
                        </div>
                      </div>
                    </li>
                    <li>
                      <strong class="form-label">성명</strong>
                      <div class="form-group ct">
                        <span>김현대</span>
                      </div>
                    </li>
                    <li>
                      <strong class="form-label">주민등록번호</strong>
                      <div class="form-group ct">
                        <p>800218 - 1******</p>
                      </div>
                    </li>
                    <li>
                      <strong class="form-label">주계약자와의 관계</strong>
                      <div class="form-group">
                        <div class="select inbl-wrap">
                          <v-select v-model="ruleForm.mainContractor" :data="ruleForm.mainContractorList" placeholder="선택하세요" />
                        </div>
                      </div>
                    </li>
                    <li>
                      <div class="form-label">휴대전화번호</div>
                      <div class="form-group">
                        <el-form-item prop="phoneNumber" class="inbl-wrap">
                          <div class="label-input">
                            <label class="offscreen">휴대전화</label>
                            <v-input v-model="ruleForm.phoneNumber" type="number" placeholder="-없이 입력하세요." />
                          </div>
                        </el-form-item>
                      </div>
                    </li>
                    <li>
                      <div class="form-label">이메일</div>
                      <div class="form-group">
                        <el-form-item prop="email" class="inbl-wrap">
                          <div class="label-input">
                            <label class="offscreen">이메일 주소</label>
                            <v-input v-model="ruleForm.emailAddress" type="text" placeholder="이메일 주소" />
                          </div>
                          <span class="at">@</span>
                          <div class="label-input">
                            <label class="offscreen">이메일 제공자</label>
                            <v-input
                              v-model="ruleForm.emailProvider"
                              type="text"
                              :disabled="ruleForm.mailSelected == '' ? false : true"
                              :value="ruleForm.mailSelected == '직접입력' ? '' : ruleForm.mailSelected"
                            />
                          </div>
                          <div class="select">
                            <v-select v-model="ruleForm.mailSelected" :data="ruleForm.mailList" placeholder="선택" />
                          </div>
                        </el-form-item>
                      </div>
                    </li>
                    <li>
                      <div class="form-label">주소</div>
                      <div class="form-group">
                        <el-form-item prop="address" class="form-address full">
                          <div class="label-input inbl-wrap">
                            <label class="offscreen">우편번호</label>
                            <v-input v-model="ruleForm.address" type="text" disabled="disabled" />
                            <v-btn class="btn-more" @click="popVisible.postCode = true">우편번호 </v-btn>
                            <v-checkbox :one-check="true" :checked.sync="addrCopyCheck" class="right"
                              >주계약자 주소와 동일</v-checkbox
                            >
                          </div>
                          <div class="label-input">
                            <label class="offscreen">기본주소</label>
                            <v-input v-model="ruleForm.address2" type="text" />
                          </div>
                          <div class="label-input">
                            <label class="offscreen">상세주소</label>
                            <v-input v-model="ruleForm.address3" type="text" />
                          </div>
                        </el-form-item>
                        <p class="bullet-star">
                          주민등록 상 주소로 입력해 주세요.<br />(주민등록 상 주소와 상이할 경우 차량 등록이 불가할 수
                          있습니다.)
                        </p>
                      </div>
                    </li>
                    <li class="w50">
                      <div class="form-label">사업자등록번호</div>
                      <div class="form-group">
                        <el-form-item prop="companyNumber">
                          <div class="label-input inbl-wrap">
                            <label class="offscreen">사업자등록번호</label>
                            <v-input v-model="ruleForm.companyNumber" type="text" />
                          </div>
                        </el-form-item>
                        <v-btn class="btn-more">확인</v-btn>
                      </div>
                    </li>
                    <li class="w50">
                      <div class="form-label">상호명</div>
                      <div class="form-group">
                        <el-form-item prop="companyName">
                          <div class="label-input inbl-wrap">
                            <label class="offscreen">상호명</label>
                            <v-input v-model="ruleForm.companyName" type="text" />
                          </div>
                        </el-form-item>
                      </div>
                    </li>
                    <li class="w50">
                      <div class="form-label">업태</div>
                      <div class="form-group">
                        <el-form-item prop="business">
                          <div class="label-input inbl-wrap">
                            <label class="offscreen">업태</label>
                            <v-input v-model="ruleForm.business" type="text" />
                          </div>
                        </el-form-item>
                      </div>
                    </li>
                    <li class="w50">
                      <div class="form-label">종목</div>
                      <div class="form-group">
                        <el-form-item prop="event">
                          <div class="label-input inbl-wrap">
                            <label class="offscreen">종목</label>
                            <v-input v-model="ruleForm.event" type="text" />
                          </div>
                        </el-form-item>
                      </div>
                    </li>
                  </ul>
                </div>

                <div class="btn-add">
                  <v-popover trigger="hover" placement="bottom-start">
                    <ol>
                      <li>1. 일반 공동명의는 타인 누구와도 가능합니다<br />(단, 직원의 경우 본인 이외 공동명의자 1인 추가만 가능합니다.)</li>
                      <li>2. 일반 공동명의는 최대 3인까지 추가 지정 가능하며, 계약자 본인은 명의자 중 필수로 포함되어야 합니다.</li>
                      <li>3. 취·등록세 면제 또는 감면을 위해 공동명의를 하실 경우, 면제/감면 대상자를 주계약자로 지정하셔야 합니다.</li>
                    </ol>
                    <v-btn slot="reference" class="btn md white r">명의자 추가</v-btn>
                  </v-popover>
                </div>

                <!-- 명의자 2 -->
                <div class="form-grid-list">
                  <ul>
                    <li>
                      <strong class="form-label bold">명의자 2</strong>
                      <div class="form-group ct">
                        <div class="radio">
                          <el-radio v-model="ppri" label="2">주계약자로 설정</el-radio>
                        </div>
                      </div>
                    </li>
                    <li>
                      <strong class="form-label">성명</strong>
                      <div class="form-group inbl-wrap">
                        <el-form-item prop="ownerName">
                          <div class="label-input">
                            <label class="offscreen">성명</label>
                            <v-input v-model="ruleForm.ownerName" type="text" />
                          </div>
                          <v-btn class="btn md line blue r" @click="popVisible.identifyVerification = true">본인 확인</v-btn>
                        </el-form-item>
                      </div>
                    </li>
                    <li>
                      <strong class="form-label">주민등록번호</strong>
                      <div class="form-group">
                        <el-form-item prop="security" class="inbl-wrap">
                          <div class="label-input">
                            <label class="offscreen">주민등록 앞자리</label>
                            <v-input v-model="ruleForm.security1" maxlength="6" />
                          </div>
                          <div class="label-input">
                            <label class="offscreen">주민등록 뒷자리</label>
                            <v-input v-model="ruleForm.security2" type="number" maxlength="7" />
                          </div>
                        </el-form-item>
                      </div>
                    </li>
                    <li>
                      <strong class="form-label">주계약자와의 관계</strong>
                      <div class="form-group">
                        <div class="select inbl-wrap">
                          <v-select v-model="ruleForm.mainContractor" :data="ruleForm.mainContractorList" placeholder="선택하세요" />
                        </div>
                      </div>
                    </li>
                    <li>
                      <div class="form-label">휴대전화번호</div>
                      <div class="form-group">
                        <el-form-item prop="phoneNumber" class="inbl-wrap">
                          <div class="label-input">
                            <label class="offscreen">휴대전화</label>
                            <v-input v-model="ruleForm.phoneNumber" type="number" placeholder="-없이 입력하세요." />
                          </div>
                        </el-form-item>
                      </div>
                    </li>
                    <li>
                      <div class="form-label">이메일</div>
                      <div class="form-group">
                        <el-form-item prop="email" class="inbl-wrap">
                          <div class="label-input">
                            <label class="offscreen">이메일 주소</label>
                            <v-input v-model="ruleForm.emailAddress" type="text" placeholder="이메일 주소" />
                          </div>
                          <span class="at">@</span>
                          <div class="label-input">
                            <label class="offscreen">이메일 제공자</label>
                            <v-input
                              v-model="ruleForm.emailProvider"
                              type="text"
                              :disabled="ruleForm.mailSelected == '' ? false : true"
                              :value="ruleForm.mailSelected == '직접입력' ? '' : ruleForm.mailSelected"
                            />
                          </div>
                          <div class="select">
                            <v-select v-model="ruleForm.mailSelected" :data="ruleForm.mailList" placeholder="선택" />
                          </div>
                        </el-form-item>
                      </div>
                    </li>
                    <li>
                      <div class="form-label">주소</div>
                      <div class="form-group">
                        <el-form-item prop="address" class="form-address full">
                          <div class="label-input inbl-wrap">
                            <label class="offscreen">우편번호</label>
                            <v-input v-model="ruleForm.address" type="text" disabled="disabled" />
                            <v-btn class="btn-more" @click="popVisible.postCode = true">우편번호</v-btn>
                            <v-checkbox :one-check="true" :checked.sync="addrCopyCheck" class="right"
                              >주계약자 주소와 동일</v-checkbox
                            >
                          </div>
                          <div class="label-input">
                            <label class="offscreen">기본주소</label>
                            <v-input v-model="ruleForm.address2" type="text" />
                          </div>
                          <div class="label-input">
                            <label class="offscreen">상세주소</label>
                            <v-input v-model="ruleForm.address3" type="text" />
                          </div>
                        </el-form-item>
                        <p class="bullet-star">
                          주민등록 상 주소로 입력해 주세요.<br />(주민등록 상 주소와 상이할 경우 차량 등록이 불가할 수
                          있습니다.)
                        </p>
                      </div>
                    </li>
                    <li class="w50">
                      <div class="form-label">사업자등록번호</div>
                      <div class="form-group">
                        <el-form-item prop="companyNumber">
                          <div class="label-input inbl-wrap">
                            <label class="offscreen">사업자등록번호</label>
                            <v-input v-model="ruleForm.companyNumber" type="text" />
                          </div>
                        </el-form-item>
                        <v-btn class="btn-more">확인</v-btn>
                      </div>
                    </li>
                    <li class="w50">
                      <div class="form-label">상호명</div>
                      <div class="form-group">
                        <el-form-item prop="companyName">
                          <div class="label-input inbl-wrap">
                            <label class="offscreen">상호명</label>
                            <v-input v-model="ruleForm.companyName" type="text" />
                          </div>
                        </el-form-item>
                      </div>
                    </li>
                    <li class="w50">
                      <div class="form-label">업태</div>
                      <div class="form-group">
                        <el-form-item prop="business">
                          <div class="label-input inbl-wrap">
                            <label class="offscreen">업태</label>
                            <v-input v-model="ruleForm.business" type="text" />
                          </div>
                        </el-form-item>
                      </div>
                    </li>
                    <li class="w50">
                      <div class="form-label">종목</div>
                      <div class="form-group">
                        <el-form-item prop="event">
                          <div class="label-input inbl-wrap">
                            <label class="offscreen">종목</label>
                            <v-input v-model="ruleForm.event" type="text" />
                          </div>
                        </el-form-item>
                      </div>
                    </li>
                  </ul>
                </div>
                <div class="agree-check">
                  <div prop="type">
                    <el-form-item prop="agreeCheck">
                      <v-checkbox v-model="ruleForm.agreeCheck" :data="agreeCheckData1" />
                    </el-form-item>
                    <el-form-item prop="agreeCheck">
                      <v-checkbox v-model="ruleForm.agreeCheck" :data="agreeCheckData2" />
                    </el-form-item>
                  </div>
                </div>
                <div class="btn-add">
                  <v-btn class="btn md line gray r">명의자 삭제</v-btn>
                  <v-popover trigger="hover" placement="bottom-start">
                    <ol>
                      <li>1. 일반 공동명의는 타인 누구와도 가능합니다<br />(단, 직원의 경우 본인 이외 공동명의자 1인 추가만 가능합니다.)</li>
                      <li>2. 일반 공동명의는 최대 3인까지 추가 지정 가능하며, 계약자 본인은 명의자 중 필수로 포함되어야 합니다.</li>
                      <li>3. 취·등록세 면제 또는 감면을 위해 공동명의를 하실 경우, 면제/감면 대상자를 주계약자로 지정하셔야 합니다.</li>
                    </ol>
                    <v-btn slot="reference" class="btn md white r">명의자 추가</v-btn>
                  </v-popover>
                </div>

                <!-- 명의자 3 -->
                <div class="form-grid-list">
                  <ul>
                    <li>
                      <strong class="form-label bold">명의자 3</strong>
                      <div class="form-group ct">
                        <div class="radio">
                          <el-radio v-model="ppri" label="2">주계약자로 설정</el-radio>
                        </div>
                      </div>
                    </li>
                    <li>
                      <strong class="form-label">성명</strong>
                      <div class="form-group inbl-wrap">
                        <el-form-item prop="ownerName">
                          <div class="label-input">
                            <label class="offscreen">성명</label>
                            <v-input v-model="ruleForm.ownerName" type="text" />
                          </div>
                          <v-btn class="btn md line blue r" @click="popVisible.identifyVerification = true">본인 확인</v-btn>
                        </el-form-item>
                      </div>
                    </li>
                    <li>
                      <strong class="form-label">주민등록번호</strong>
                      <div class="form-group">
                        <el-form-item prop="security" class="inbl-wrap">
                          <div class="label-input">
                            <label class="offscreen">주민등록 앞자리</label>
                            <v-input v-model="ruleForm.security1" maxlength="6" />
                          </div>
                          <div class="label-input">
                            <label class="offscreen">주민등록 뒷자리</label>
                            <v-input v-model="ruleForm.security2" type="number" maxlength="7" />
                          </div>
                        </el-form-item>
                      </div>
                    </li>
                    <li>
                      <strong class="form-label">주계약자와의 관계</strong>
                      <div class="form-group">
                        <div class="select inbl-wrap">
                          <v-select v-model="ruleForm.mainContractor" :data="ruleForm.mainContractorList" placeholder="선택하세요" />
                        </div>
                      </div>
                    </li>
                    <li>
                      <div class="form-label">휴대전화번호</div>
                      <div class="form-group">
                        <el-form-item prop="phoneNumber" class="inbl-wrap">
                          <div class="label-input">
                            <label class="offscreen">휴대전화</label>
                            <v-input v-model="ruleForm.phoneNumber" type="number" placeholder="-없이 입력하세요." />
                          </div>
                        </el-form-item>
                      </div>
                    </li>
                    <li>
                      <div class="form-label">이메일</div>
                      <div class="form-group">
                        <el-form-item prop="email" class="inbl-wrap">
                          <div class="label-input">
                            <label class="offscreen">이메일 주소</label>
                            <v-input v-model="ruleForm.emailAddress" type="text" placeholder="이메일 주소" />
                          </div>
                          <span class="at">@</span>
                          <div class="label-input">
                            <label class="offscreen">이메일 제공자</label>
                            <v-input
                              v-model="ruleForm.emailProvider"
                              type="text"
                              :disabled="ruleForm.mailSelected == '' ? false : true"
                              :value="ruleForm.mailSelected == '직접입력' ? '' : ruleForm.mailSelected"
                            />
                          </div>
                          <div class="select">
                            <v-select v-model="ruleForm.mailSelected" :data="ruleForm.mailList" placeholder="선택" />
                          </div>
                        </el-form-item>
                      </div>
                    </li>
                    <li>
                      <div class="form-label">주소</div>
                      <div class="form-group">
                        <el-form-item prop="address" class="form-address full">
                          <div class="label-input inbl-wrap">
                            <label class="offscreen">우편번호</label>
                            <v-input v-model="ruleForm.address" type="text" disabled="disabled" />
                            <v-btn class="btn-more" @click="popVisible.postCode = true">우편번호</v-btn>
                            <v-checkbox :one-check="true" :checked.sync="addrCopyCheck" class="right"
                              >주계약자 주소와 동일</v-checkbox
                            >
                          </div>
                          <div class="label-input">
                            <label class="offscreen">기본주소</label>
                            <v-input v-model="ruleForm.address2" type="text" />
                          </div>
                          <div class="label-input">
                            <label class="offscreen">상세주소</label>
                            <v-input v-model="ruleForm.address3" type="text" />
                          </div>
                        </el-form-item>
                        <p class="bullet-star">
                          주민등록 상 주소로 입력해 주세요.<br />(주민등록 상 주소와 상이할 경우 차량 등록이 불가할 수
                          있습니다.)
                        </p>
                      </div>
                    </li>
                    <li class="w50">
                      <div class="form-label">사업자등록번호</div>
                      <div class="form-group">
                        <el-form-item prop="companyNumber">
                          <div class="label-input inbl-wrap">
                            <label class="offscreen">사업자등록번호</label>
                            <v-input v-model="ruleForm.companyNumber" type="text" />
                          </div>
                        </el-form-item>
                        <v-btn class="btn-more">확인</v-btn>
                      </div>
                    </li>
                    <li class="w50">
                      <div class="form-label">상호명</div>
                      <div class="form-group">
                        <el-form-item prop="companyName">
                          <div class="label-input inbl-wrap">
                            <label class="offscreen">상호명</label>
                            <v-input v-model="ruleForm.companyName" type="text" />
                          </div>
                        </el-form-item>
                      </div>
                    </li>
                    <li class="w50">
                      <div class="form-label">업태</div>
                      <div class="form-group">
                        <el-form-item prop="business">
                          <div class="label-input inbl-wrap">
                            <label class="offscreen">업태</label>
                            <v-input v-model="ruleForm.business" type="text" />
                          </div>
                        </el-form-item>
                      </div>
                    </li>
                    <li class="w50">
                      <div class="form-label">종목</div>
                      <div class="form-group">
                        <el-form-item prop="event">
                          <div class="label-input inbl-wrap">
                            <label class="offscreen">종목</label>
                            <v-input v-model="ruleForm.event" type="text" />
                          </div>
                        </el-form-item>
                      </div>
                    </li>
                  </ul>
                </div>
                <div class="agree-check">
                  <div prop="type">
                    <el-form-item prop="agreeCheck">
                      <v-checkbox v-model="ruleForm.agreeCheck" :data="agreeCheckData1" />
                    </el-form-item>
                    <el-form-item prop="agreeCheck">
                      <v-checkbox v-model="ruleForm.agreeCheck" :data="agreeCheckData2" />
                    </el-form-item>
                  </div>
                </div>
                <div class="btn-add">
                  <v-btn class="btn md line gray r">명의자 삭제</v-btn>
                  <v-popover trigger="hover" placement="bottom-start">
                    <ol>
                      <li>1. 일반 공동명의는 타인 누구와도 가능합니다<br />(단, 직원의 경우 본인 이외 공동명의자 1인 추가만 가능합니다.)</li>
                      <li>2. 일반 공동명의는 최대 3인까지 추가 지정 가능하며, 계약자 본인은 명의자 중 필수로 포함되어야 합니다.</li>
                      <li>3. 취·등록세 면제 또는 감면을 위해 공동명의를 하실 경우, 면제/감면 대상자를 주계약자로 지정하셔야 합니다.</li>
                    </ol>
                    <v-btn slot="reference" class="btn md white r">명의자 추가</v-btn>
                  </v-popover>
                </div>

              </el-form>
            </div>
          </section>

          <identify-verification
            :visible="popVisible.identifyVerification"
            @close="popVisible.identifyVerification = false"
          ></identify-verification>
          <post-code :pop-visible="popVisible"></post-code>

          <!-- 보증제도 -->
          <section class="information-detail">
            <div class="summary-info">
              <div class="title ct">
                <h1>보증제도</h1>
                <v-btn
                  class="btn-info"
                  type="icon"
                  icon-class="icon-info"
                  @click="popVisible.flexibleWarrantyService = true"
                  ><span class="offscreen">안내팝업보기</span></v-btn
                >
              </div>
            </div>
            <div class="detail-info">
              <v-select v-model="form.guaranteeSel" :data="form.commonCodes" class="lg" />
            </div>
          </section>
          <flexible-warranty-service
            :visible="popVisible.flexibleWarrantyService"
            @close="popVisible.flexibleWarrantyService = false"
          ></flexible-warranty-service>

          <!-- 카마스터 -->
          <section class="information-detail">
            <div class="summary-info">
              <h1 class="title">추천 카마스터 <span>(선택)</span></h1>
              <v-btn
                class="btn-detail"
                type="icon"
                :icon-class="['icon-open', { active: isMasterShow }]"
                @click="isMasterShow = !isMasterShow"
                ><span class="offscreen">상세보기</span></v-btn
              >
            </div>
            <div v-show="isMasterShow" class="detail-info car-master">
              <div class="recommend-box">
                <strong>카마스터</strong>
                <div>김현대 (010-2378-5678)</div>
              </div>

              <div class="master-search">
                <div class="search-type">
                  <el-radio v-model="carMaster.carMasterSearch" label="1">이름으로 찾기</el-radio>
                  <el-radio v-model="carMaster.carMasterSearch" label="2">지점/대리점으로 찾기</el-radio>
                </div>
                <div class="master-input">
                  <div v-if="carMaster.carMasterSearch === '1'" class="label-input inbl-wrap">
                    <label class="offscreen">이름으로 찾기</label>
                    <v-input v-model="carMaster.carMasterName" placeholder="이름을 입력해주세요." />
                    <v-btn class="btn-more">검색</v-btn>
                  </div>
                  <div v-if="carMaster.carMasterSearch === '2'" class="label-input inbl-wrap">
                    <label class="offscreen">지점/대리점으로 찾기</label>
                    <v-input v-model="carMaster.carMasterAgent" placeholder="지점 또는 대리점명을 입력해 주세요." />
                    <v-btn class="btn-more">검색</v-btn>
                  </div>
                </div>
              </div>

              <div class="search-result">
                <div v-if="carMaster.carMasterSearch === '1'" class="master-filter">
                  <v-radio v-model="carMasterCheck" :custom-label="true" :data="carMasterSearchList">
                    <template slot-scope="props">{{ props.item.label }} ({{ props.item.count }})</template>
                  </v-radio>
                </div>
                <div class="location-map">
                  <p v-if="carMaster.mapRecommend === '1'" class="text">구매 상담을 도와주신 카마스터(직원)가 있나요?<br />카마스터를 추천해주세요.</p>
                  <!-- 검색결과 있을 경우 -->
                  <div v-else-if="carMaster.mapRecommend === '2'" class="map-view">
                    <div style="background:#f9f9f9" class="map-area">
                      지도영역
                    </div>
                    <div class="master-list">
                      <ul v-if="carMasterList.length > 0">
                        <li v-for="(master, index) in carMasterList" :key="index">
                          <div class="master-info">
                            <div>
                              <span class="num">{{ `${index + 1}` }}</span>
                              <strong class="name">{{ master.master }}</strong>
                            </div>
                            <span>{{ master.place }}</span>
                            <p>{{ master.email }}</p>
                            <p>{{ master.phone }}</p>
                          </div>
                          <v-btn class="btn-more">선택</v-btn>
                        </li>
                      </ul>
                    </div>
                  </div>
                  <!-- 검색결과 없을 경우 -->
                  <p v-else-if="carMaster.mapRecommend === '3'" class="no-result">검색결과가 없습니다.</p>
                </div>
              </div>
            </div>
          </section>
        </div>
      </div>
    </div>

    <div class="btn-wrap">
      <v-btn class="btn lg blue r">다음</v-btn>
    </div>

  </div>
</template>

<script>
// import VProgressBar from '~/components/element/VProgressBar'
// import ContractTool from '~/components/page/contract/ContractTool'
// import DutyCar from '~/components/page/contract/popup/DutyCar'
// 2021.03.16 (ver1.2) 팝업 추가
import IdentifyVerification from '~/components/page/contract/popup/IdentifyVerification'
// 2021.03.23 (ver1.3) 팝업 추가
import FlexibleWarrantyService from '~/components/page/contract/popup/FlexibleWarrantyService'
import PostCode from '~/components/common/PostCode'

export default {
  components: {
    // VProgressBar,
    // ContractTool,
    // DutyCar,
    IdentifyVerification,
    FlexibleWarrantyService,
    PostCode
  },
  props: {
    type: {
      type: String,
      default: ''
    }
  },
  data() {
    return {
      // 2021.03.23 (ver1.3) 추가
      dicountCheck: false,
      businessCheck: false,

      isIdentyShow: false,
      isMasterShow: false,
      checkboxBenefit: false,
      ppri: '1',
      ruleForm: {
        // 2021.03.23 (ver1.3) 추가
        ownerName: '',

        agreeCheck: [],
        security: true,
        security1: '',
        security2: '',
        phoneNumber: '',
        emailAddress: '',
        emailProvider: '',
        mailSelected: '',
        mailList: [
          {
            label: '직접 입력',
            value: ''
          },
          {
            label: 'gmail.com',
            value: 'gmail.com'
          },
          {
            label: 'naver.com',
            value: 'naver.com'
          },
          {
            label: 'daum.net',
            value: 'daum.net'
          }
        ],
        address: '',
        address2: '',
        address3: '',
        companyNumber: '',
        companyName: '',
        business: '',
        event: '',

        mainContractor: '',
        mainContractorList: [
          {
            value: 'contractor1',
            label: '조부모'
          },
          {
            value: 'contractor2',
            label: '외조부모'
          },
        ],
      },
      addrCopyCheck: false,
      agreeCheckData1: [
        { value: 'agree', label: '본인은 귀사가 상기 목적으로 본인의 개인정보를 수집·이용하는 것에 동의합니다.' }
      ],
      agreeCheckData2: [
        {
          value: 'agree',
          label:
            '본인은 귀사가 상기 목적으로 상기 보유·이용 기간 동안 본인의 고유식별정보(주민등록번호, 운전면허번호, 여권번호, 외국인등록번호)를 수집·이용하는 것에 동의합니다.'
        }
      ],
      taxExemptOption: {
        applied: false,
        selectedType: '',
        resHandicapList: [
          {
            value: '',
            label: '장애 등급 및 관련 내용 선택'
          },
          {
            value: 'Option1',
            label: 'hadicap1'
          },
          {
            value: 'Option2',
            label: 'hadicap2'
          },
          {
            value: 'Option3',
            label: 'hadicap3'
          }
        ]
      },
      form: {
        guaranteeSel: '',
        commonCodes: [
          {
            value: '',
            label: '보증제도 선택'
          },
          {
            label: '기본형 (3년/6만㎞)',
            value: '1'
          },
          {
            label: '마일리지형 (2년/8만㎞)',
            value: '2'
          },
          {
            label: '기간연장형 (4년/4만㎞)',
            value: '3'
          }
        ]
      },
      carMaster: {
        carMasterRecommend: false,
        carMasterSearch: '1',
        carMasterName: '',
        carMasterrAgent: '',
        mapRecommend: '2'
      },
      carMasterCheck: '',
      carMasterSearchList: [
        { value: 'check1', label: '전체', count: '3' },
        { value: 'check2', label: '지점', count: '1' },
        { value: 'check3', label: '대리점', count: '1' }
      ],
      carMasterList: [
        {
          // photo: {
          //   src: require('~/assets/images/temp/temp-car-master-img.jpg'),
          //   alt: '김현대',
          // },
          master: '김현대',
          place: '서초지점',
          email: 'hyundai.kim@hyundai.com',
          phone: '010-1234-5678'
        },
        {
          // photo: {
          //   src: require('~/assets/images/temp/temp-car-master-img.jpg'),
          //   alt: '김현대',
          // },
          master: '김현대',
          place: '동대문역대리점',
          email: 'hyundai.kim@hyundai.com',
          phone: '010-1234-5678'
        },
        {
          // photo: {
          //   src: require('~/assets/images/temp/temp-car-master-img.jpg'),
          //   alt: '김현대',
          // },
          master: '김현대',
          place: '서초지점',
          email: 'hyundai.kim@hyundai.com',
          phone: '010-1234-5678'
        },
        {
          // photo: {
          //   src: require('~/assets/images/temp/temp-car-master-img.jpg'),
          //   alt: '김현대',
          // },
          master: '김현대',
          place: '동대문역대리점',
          email: 'hyundai.kim@hyundai.com',
          phone: '010-1234-5678'
        },
        {
          // photo: {
          //   src: require('~/assets/images/temp/temp-car-master-img.jpg'),
          //   alt: '김현대',
          // },
          master: '김현대',
          place: '동대문역대리점',
          email: 'hyundai.kim@hyundai.com',
          phone: '010-1234-5678'
        }
      ],
      popVisible: {
        dutyCar: false,
        // 2021.03.16 (ver1.2) 팝업 추가
        identifyVerification: false,
        // 2021.03.23 (ver1.3) 팝업 추가
        flexibleWarrantyService: false,
        postCode: false
      }
    }
  },
  computed: {
    rules() {
      return {
        agreeCheck: [
          {
            required: true,
            message: '* 약관에 동의해 주세요.',
            trigger: 'change'
          }
        ],
        // 2021.03.23 (ver1.3) 삭제
        // security2: [
        //   {
        //     required: true,
        //     message: '* 주민등록번호를 입력해 주세요',
        //     trigger: 'blur',
        //   },
        // ],
        phoneNumber: [
          {
            required: true,
            message: '* 휴대전화를 입력해 주세요',
            trigger: 'blur'
          }
        ],
        email: [
          {
            required: true,
            message: '* 이메일을 입력해 주세요.',
            trigger: 'blur'
          }
        ],
        address: [
          {
            required: true,
            message: '* 주소를 입력해 주세요.',
            trigger: 'blur'
          }
        ],
        selectedType: [
          {
            required: true,
            message: '* 장애등급을 선택해 주세요.',
            trigger: 'change'
          }
        ],

        // 2021.03.23 (ver1.3) 추가 start
        ownerName: [
          {
            required: true,
            message: '* 본인확인을 완료해 주세요.',
            trigger: 'blur'
          }
        ],
        companyNumber: [
          {
            required: true,
            message: '* 사업자등록번호를 입력해 주세요.',
            trigger: 'blur'
          }
        ],
        companyName: [
          {
            required: true,
            message: '* 상호명을 입력해 주세요.',
            trigger: 'blur'
          }
        ],
        business: [
          {
            required: true,
            message: '* 업태를 입력해 주세요.',
            trigger: 'blur'
          }
        ],
        event: [
          {
            required: true,
            message: '* 종목을 입력해 주세요.',
            trigger: 'blur'
          }
        ],
        security: [
          {
            required: true,
            message: '* 주민등록번호를 입력해 주세요',
            trigger: 'blur'
          }
        ]
        // end
      }
    }
  },
  // 2021.03.23 (ver1.3) 삭제
  // mounted() {
  //   console.log(this.type)
  //   this.setLabel((idg) => {
  //     // console.dir(idg) // 자동 생성된 ID 배열
  //   })
  // },
  // 2021.03.23 (ver1.3) 추가
  updated() {
    this.setLabel((idg) => {
      // console.dir(idg) // 자동 생성된 ID 배열
    })
  }
}
</script>
