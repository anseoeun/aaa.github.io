<!-- 2021.03.31 STEP 삭제 -->
<template>
  <!-- 2021.03.29 (ver1.4) 동의와 관련된 스크립트수정및 추가 -->

  <!-- 2021.03.23 (ver1.3) step3 클래스 추가 -->
  <div class="page-step step3">
    <div class="purchase-wrap">
      <!-- 2021.03.23 (ver1.3) purchase-join 클래스 삭제 -->
      <!-- <div class="purchase-info purchase-join"> -->
      <div class="purchase-info">
        <!-- 서비스 가입 신청 -->
        <section class="purchase-application">
          <h1>서비스 가입 &middot; 신청</h1>

          <!--  블루멤버스 회원가입 신청 -->
          <section class="information-detail">
            <div class="summary-info">
              <!-- 2021.03.29 (ver1.4) 필수 텍스트 추가 -->
              <h1 class="title">블루멤버스 회원가입 신청 (필수)</h1>
              <v-btn class="btn-more">블루멤버스 회원혜택 자세히 알아보기</v-btn>
              <!-- 2021.03.29 (ver1.4) @click 수정 -->
              <v-btn
                :class="{ active: viewType !== '' }"
                class="btn white md r"
                @click="setAct(0, true), viewType === '' ? (viewType = 'plcc') : (viewType = viewType)"
                >신청하기</v-btn
              >
              <v-btn class="btn-detail" type="icon" :icon-class="['icon-open', { active: isAct(0) }]" @click="setAct(0)"
                ><span class="offscreen">상세보기</span></v-btn
              >
            </div>
            <div v-show="isAct(0)" class="detail-info">
              <p>블루멤버스 회원으로 가입하시고, 현대자동차가 제공하는 다양하고 특별한 혜택을 누리세요.</p>
              <div class="card-select">
                <strong>블루멤버스 카드 선택</strong>
                <ul class="card-list">
                  <li>
                    <v-btn :class="{ active: viewType === 'plcc' }" class="btn md r" @click="viewType = 'plcc'"
                      >PLCC 카드</v-btn
                    >
                  </li>
                  <li>
                    <v-btn
                      :class="{ active: viewType === 'membership' }"
                      class="btn md r"
                      @click="viewType = 'membership'"
                      >멤버십 카드</v-btn
                    >
                  </li>
                  <li>
                    <v-btn :class="{ active: viewType === 'mobile' }" class="btn md r" @click="viewType = 'mobile'"
                      >모바일 카드</v-btn
                    >
                  </li>
                </ul>
              </div>
              <div class="card-type">
                <!-- PLCC 카드 -->
                <div v-show="viewType === 'plcc'" class="plcc">
                  <p style="height: 100px;">기획 TBD</p>
                  <!-- <p>신차 구매부터 유지ㆍ관리ㆍ재구매까지, 전용카드만의 차별화된 혜택을 만나보세요.</p>
                  <v-btn type="link" href="/" target="_blank" title="새창열기" class="btn-more">PLCC 카드 신청하기</v-btn>
                  <div>
                    <strong class="bullet-star bold">PLCC 카드의 주요 혜택</strong>
                    <ol>
                      <li><span class="bold">하나.</span> 신차 구매 혜택은 물론, 쓸 때마다 M포인트와 블루멤버스포인트가 동시에 쌓이는 카드
                        <p>당월 이용금액별 M포인트 적립, 적립된 M포인트를 기준으로 15~30% 블루멤버스포인트 적립<br />(카드별 블루멤버스포인트 적립률 : 신용카드 15%, Platinum카드 20%, Platinum Plus 카드 30%)<br />당월 이용금액 50만원 미만 시 M포인트 적립 제외되며, 블루멤버스포인트도 미적립</p>
                      </li>
                      <li><span class="bold">둘.</span> 정비 2만원 자동차 특화 혜택! 이용 실적에 무관하게 제공되는 블루멤버스 카드 추가 혜택</li>
                    </ol>
                    <p>기획 TBD</p>
                  </div> -->
                </div>
                <!-- 멤버십 카드 -->
                <div v-show="viewType === 'membership'">
                  <p>
                    8년 8회 정기점검, 블루멤버스 포인트 서비스 등 차량 구매에서부터 폐차에 이르기까지 다양한 혜택을
                    제공해 드리는 블루멤버스 카드입니다.
                    <v-btn class="btn-more">현대카드 블루멤버스 전용카드 혜택 알아보기</v-btn>
                  </p>
                  <div class="form-grid-list">
                    <ul>
                      <li>
                        <div class="form-label">카드 수령지</div>
                        <div class="form-group">
                          <el-form ref="cardForm" :model="cardForm" :rules="rules">
                            <el-form-item prop="address" class="form-address full">
                              <div class="label-input inbl-wrap">
                                <label class="offscreen">우편번호</label>
                                <v-input v-model="cardForm.address" type="text" disabled="disabled" />

                                <!-- 2021.03.29 (ver1.4) 우편번호 팝업 연결-->
                                <v-btn class="btn-more" @click="popVisible.postCode = true">우편번호</v-btn>
                              </div>
                              <div class="label-input">
                                <label class="offscreen">기본주소</label>
                                <v-input v-model="cardForm.address2" type="text" />
                              </div>
                              <div class="label-input">
                                <label class="offscreen">상세주소</label>
                                <v-input v-model="cardForm.address3" type="text" />
                              </div>
                            </el-form-item>
                          </el-form>
                        </div>
                      </li>
                    </ul>
                  </div>
                </div>
                <!-- 모바일 카드 -->
                <div v-show="viewType === 'mobile'">
                  <p>
                    스마트폰 사용 고객이라면 카드 신청 없이 모바일에서 더욱 간편하게 블루멤버십 혜택을 누릴 수
                    있습니다.<br />계약 완료 후 고객님의 스마트폰으로 모바일 블루멤버십 이용을 위한 안내를 별도로
                    드리겠습니다.
                  </p>
                </div>
                <!-- 2021.03.29 (ver1.4) 우편번호 팝업 -->
                <post-code :pop-visible="popVisible" />
              </div>
              <!-- 약관 -->
              <div class="agree-info">
                <div class="summary-info">
                  <strong class="title">블루멤버스 회원가입 및 개인정보 활용 동의</strong>

                  <!-- 2021.03.29 (ver1.4) @click 수정 -->
                  <v-btn
                    class="btn md white r"
                    :class="{ active: blueMembersAgreeCheckActive }"
                    @click="setAct(1, true, blueMembersAgreeCheck)"
                    >전체 동의</v-btn
                  >
                  <v-btn
                    class="btn-detail"
                    type="icon"
                    :icon-class="['icon-open', { active: isAct(1) }]"
                    @click="setAct(1)"
                    ><span class="offscreen">상세보기</span></v-btn
                  >
                </div>
                <div v-show="isAct(1)" class="detail-info">
                  <!-- 2021.03.29 (ver1.4) 기획확인중 추후 수정예정 -->
                  <!-- <div class="">
                    <strong>블루멤버스 회원가입 이용약관</strong>
                    <v-checkbox :one-check="true" :checked.sync="checkboxBluemembers" @change="popOpen"
                      >약관 확인하기</v-checkbox
                    >
                  </div> -->
                  <div class="info-grid-list">
                    <!-- 2021.03.29 (ver1.4) @change 추가 -->
                    <v-checkbox :one-check="true" :checked.sync="checkboxBluemembers1" @change="actInnerCheck(1)">
                      블루멤버스 필수적 개인정보 수집ㆍ이용에 대한 동의</v-checkbox
                    >
                    <ul>
                      <li>
                        <strong class="info-title">개인정보 수집ㆍ이용 목적</strong>
                        <div class="info-group">
                          블루멤버스 서비스 제공(보증수리, 차량 점검ㆍ정비 및 유지보수 서비스, 긴급출동 서비스 및
                          제작결함 시정 서비스, 포인트 적립&#38;사용, 제휴서비스, 각종 정보제공 서비스 등), 서비스
                          제공을 위한 본인확인, 분쟁조정을 위한 기록 보존, 고지사항 전달, 서비스 만족도 조사 등
                        </div>
                      </li>
                      <li>
                        <strong class="info-title">수집하는 개인정보 항목</strong>
                        <div class="info-group">
                          성명, 생년월일(행정상), 성별, 암호화된 동일인 식별정보(CI), 신용평가기관의 본인인증값(I-PIN,
                          My-PIN, 휴대폰, 신용카드, 범용공인인증서 인증값), 내외국인 여부, 직장/자택주소, 휴대폰번호,
                          이메일주소, 구입차량정보, 생성정보(카드번호, 서비스&#38;포인트 이용정보, 수집에 동의한 정보를
                          가공한 정보 등)
                        </div>
                      </li>
                      <li>
                        <strong class="info-title">개인정보 보유 및 이용기간</strong>
                        <div class="info-group">
                          현대자동차㈜는 상법 등 관계법령의 규정에 의하여 보존할 의무가 있는 경우가 아닌 한, 원칙적으로
                          회원 탈퇴시 까지만 본인의 개인정보를 보유ㆍ이용합니다. 다만, 고객불만 및 분쟁처기, 기 적립된
                          잔여포인트, 회원 탈퇴 등에 관한 기록은 예외적으로 회원 탈퇴 후 5년간 보관합니다.
                        </div>
                      </li>
                    </ul>
                  </div>
                  <div class="info-grid-list">
                    <!-- 2021.03.29 (ver1.4) @change 추가 -->
                    <v-checkbox :one-check="true" :checked.sync="checkboxBluemembers2" @change="actInnerCheck(1)"
                      >선택적 개인정보 수집ㆍ이용 및 광고성 정보 수신에 대한 동의 (선택)</v-checkbox
                    >
                    <ul>
                      <li>
                        <strong class="info-title">개인정보 수집ㆍ이용 목적</strong>
                        <div class="info-group">
                          블루멤버스 서비스와 관계없는 광고성 정보전달 및 마케팅에 활용, 시장조사, 차량 정기점검 및 정비
                          상품ㆍ이벤트 안내 등
                        </div>
                      </li>
                      <li>
                        <strong class="info-title">수집하는 개인정보 항목</strong>
                        <div class="info-group">
                          [필수적 개인정보 수집ㆍ이용에 대한 동의]에서 수집하는 개인정보 항목과 동일
                        </div>
                      </li>
                      <li>
                        <strong class="info-title">개인정보 보유 및 이용기간</strong>
                        <div class="info-group">
                          [필수적 개인정보 수집ㆍ이용에 대한 동의]에서 수집하는 개인정보 항목과 동일
                        </div>
                      </li>
                      <li>
                        <strong class="info-title">미동의 시 불이익 사항</strong>
                        <div class="info-group">없음(멤버십 이벤트 초청 행사 등 정보 수신 불가)</div>
                      </li>
                    </ul>
                    <div class="all-check-list">
                      <!-- 2021.03.29 (ver1.4) @change 추가 -->
                      <v-checkbox
                        v-model="checkboxInfoAll"
                        :data="checkboxInfoAllList"
                        all-chk-name="정보수신방법"
                        @change="actInnerCheck(1)"
                      />
                    </div>
                  </div>
                  <!-- end -->
                </div>
              </div>
            </div>
          </section>

          <!-- 2021.03.29 (ver1.4) 팝업 추가 -->
          <terms-blueMembers
            :visible="popVisible.termsBlueMembers"
            @close="popVisible.termsBlueMembers = false"
          ></terms-blueMembers>

          <!-- PLCC 카드 신청 -->
          <section class="information-detail">
            <div class="summary-info">
              <!-- 2021.03.29 (ver1.4) 선택 텍스트 추가 -->
              <h1 class="title">PLCC 카드 신청 (선택)</h1>
              <v-btn class="btn-detail" type="icon" :icon-class="['icon-open', { active: isAct(2) }]" @click="setAct(2)"
                ><span class="offscreen">상세보기</span></v-btn
              >
            </div>
            <div v-show="isAct(2)" class="detail-info">
              <div class="plcc">
                <p style="height: 100px;">기획 TBD</p>
                <!-- <p>신차 구매부터 유지ㆍ관리ㆍ재구매까지, 전용카드만의 차별화된 혜택을 만나보세요.</p>
                <v-btn type="link" href="/" target="_blank" title="새창열기" class="btn-more">PLCC 카드 신청하기</v-btn>
                <div>
                  <strong class="bullet-star bold">PLCC 카드의 주요 혜택</strong>
                  <ol>
                    <li><span class="bold">하나.</span> 신차 구매 혜택은 물론, 쓸 때마다 M포인트와 블루멤버스포인트가 동시에 쌓이는 카드
                      <p>당월 이용금액별 M포인트 적립, 적립된 M포인트를 기준으로 15~30% 블루멤버스포인트 적립<br />(카드별 블루멤버스포인트 적립률 : 신용카드 15%, Platinum카드 20%, Platinum Plus 카드 30%)<br />당월 이용금액 50만원 미만 시 M포인트 적립 제외되며, 블루멤버스포인트도 미적립</p>
                    </li>
                    <li><span class="bold">둘.</span> 정비 2만원 자동차 특화 혜택! 이용 실적에 무관하게 제공되는 블루멤버스 카드 추가 혜택</li>
                  </ol>
                  <p>기획 TBD</p>
                </div> -->
              </div>
            </div>
          </section>

          <!-- 하이패스 자동등록 신청 -->
          <section class="information-detail">
            <div class="summary-info">
              <!-- 2021.03.29 (ver1.4) 필수 텍스트 추가 -->
              <h1 class="title">하이패스 자동등록 신청 (필수)</h1>
              <!-- 2021.03.29 (ver1.4) @click 수정 -->
              <v-btn :class="{ active: hipassAct }" class="btn white md r" @click="setAct(3, true), (hipassAct = true)"
                >신청하기</v-btn
              >
              <v-btn class="btn-detail" type="icon" :icon-class="['icon-open', { active: isAct(3) }]" @click="setAct(3)"
                ><span class="offscreen">상세보기</span></v-btn
              >
            </div>
            <div v-show="isAct(3)" class="detail-info">
              <!-- 2021.03.29 (ver1.4) 수정 start -->
              <p class="text">하이패스는 주행 중인 차 안에서 고속도록 통행료를 무선으로 지불하는 시스템입니다.</p>
              <p v-if="hipassType">장애인 및국가유공자는 감면 혜택이 적용될 별도 단말기를 사용할 수 있습니다.</p>
              <!-- end -->
              <div class="agree-info">
                <div class="summary-info">
                  <!-- 2021.03.29 (ver1.4) sm 클래스 추가 -->
                  <strong class="title sm">개인정보 수집ㆍ이용 및 제공 동의 [한국도로공사용]</strong>
                  <!-- 2021.03.29 (ver1.4) @click 수정 -->
                  <v-btn
                    class="btn md white r"
                    :class="{ active: personalInfoAgreeCheckActive }"
                    @click="setAct(4, true, personalInfoAgreeCheck)"
                    >전체 동의</v-btn
                  >
                  <v-btn
                    class="btn-detail"
                    type="icon"
                    :icon-class="['icon-open', { active: isAct(4) }]"
                    @click="setAct(4)"
                    ><span class="offscreen">상세보기</span></v-btn
                  >
                </div>
                <div v-show="isAct(4)" class="detail-info">
                  <!-- 2021.03.29 (ver1.4) 내용 추가 start -->
                  <div class="table-area">
                    <div class="table-top">
                      <!-- 2021.03.29 (ver1.4) @change 추가 -->
                      <v-checkbox
                        :one-check="true"
                        :checked.sync="checkboxHipass1"
                        @change="actInnerCheck(4, checkboxHipass1)"
                        >한국도로공사-개인정보 수집 이용에 대한 안내</v-checkbox
                      >
                    </div>
                    <table>
                      <colgroup>
                        <col width="20%" />
                        <col width="20%" />
                        <col width="20%" />
                        <col width="20%" />
                        <col width="20%" />
                      </colgroup>
                      <thead>
                        <tr>
                          <th>항목</th>
                          <th>수집 &middot; 이용하는 목적</th>
                          <th>수집 &middot; 이용하는 개인정보 항목</th>
                          <th>개인정보 보유 및 이용기간</th>
                          <th>동의를 거부할 권리 및 미동의에 따른<br />불이익 사항</th>
                        </tr>
                      </thead>
                      <tbody class="t-left">
                        <tr>
                          <td>신청자 기본정보</td>
                          <td>단말기 사후 관리</td>
                          <td>
                            성명, 휴대폰번호, 차명(차종), 차량번호
                          </td>
                          <td>단말기 해지 또는<br />명의변경 후 6개월</td>
                          <td rowspan="3">
                            개인정보 수집 &middot; 이용에 관한 동의는 거부할 수 있으며, 거부할 경우 하이패스 차량 단말기
                            등록 및 서비스 이용을 할 수 없습니다.
                          </td>
                        </tr>
                        <tr>
                          <td>하이패스 이용정보</td>
                          <td>
                            통행료 정산,<br />교통정보 제공,<br />고객응대(민원해소)<br />및 이를 위한<br />서비스 향상
                          </td>
                          <td>통행일시<br />진출입 요금소 요금<br />단말기 번호<br />하이패스 카드 번호</td>
                          <td>
                            3년(전자금융거래법 시행령 제12조)<br />※ 개인정보 보유 및 이용기간 예외<br />1. 통행료를
                            납부하지 않은 경우 납부 완료 시까지<br />2. 통행료 관련 분쟁이 발생한 경우 분쟁 완료
                            시까지<br />3. 다른 법령 또는 당사자의 합의에 따라 보유할 필요가 있는 경우
                          </td>
                        </tr>
                        <tr>
                          <td>하이패스<br />위반(에러) 정보</td>
                          <td>단말기 사후 관리(A/S)</td>
                          <td>
                            위반(에러) 발생정보 통행일시, 진출입 요금소, 에러유형, 회원 성명, 휴대폰번호, 차량번호
                          </td>
                          <td>에러(위반)에 대한 사후관리(A/S) 목적 달성 시까지</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                  <div class="table-area">
                    <div class="table-top">
                      <!-- 2021.03.29 (ver1.4) @change 추가 -->
                      <v-checkbox
                        :one-check="true"
                        :checked.sync="checkboxHipass2"
                        @change="actInnerCheck(4, checkboxHipass2)"
                        >한국도로공사-필수적 개인정보 제3자 제공 조회에 대한 동의</v-checkbox
                      >
                    </div>
                    <table>
                      <colgroup>
                        <col width="16.66%" />
                        <col width="16.66%" />
                        <col width="16.66%" />
                        <col width="16.66%" />
                        <col width="16.66%" />
                      </colgroup>
                      <thead>
                        <tr>
                          <th>항목</th>
                          <th>제공대상</th>
                          <th>수집 &middot; 이용하는 목적</th>
                          <th>수집 &middot; 이용하는 개인정보 항목</th>
                          <th>개인정보 보유 및 이용기간</th>
                          <th>동의를 거부할 권리 및 미동의에 따른<br />불이익 사항</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td>신청자 기본정보</td>
                          <td rowspan="2">
                            통행료 정산 또는 통행료 수납업무의 위ㆍ수탁 계약에 따른 연계유료도로 운영자
                          </td>
                          <td rowspan="2">
                            통행료 정산, 고객응대 및 이를 위한 서비스 향상
                          </td>
                          <td rowspan="2">통행일시<br />진출입 요금소 요금<br />단말기 번호<br />하이패스 카드 번호</td>
                          <td>단말기 해지 또는<br />명의변경 후 6개월</td>
                          <td rowspan="2">
                            개인정보 수집 &middot; 이용에 관한 동의는 거부할 수 있으며, 거부할 경우 하이패스 차량 단말기
                            등록 및 서비스 이용을 할 수 없습니다.
                          </td>
                        </tr>
                        <tr>
                          <td>하이패스 이용정보</td>
                          <td>
                            3년(전자금융거래법 시행령 제12조)<br />※ 개인정보 보유 및 이용기간 예외<br />1. 통행료를
                            납부하지 않은 경우 납부 완료 시까지<br />2. 통행료 관련 분쟁이 발생한 경우 분쟁 완료
                            시까지<br />3. 다른 법령 또는 당사자의 합의에 따라 보유할 필요가 있는 경우
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                  <!-- end -->
                </div>
              </div>
            </div>
          </section>

          <!-- 중고차 가격보장 서비스 신청 -->
          <section class="information-detail">
            <div class="summary-info">
              <!-- 2021.03.29 (ver1.4) 선택 텍스트 추가 -->
              <h1 class="title">중고차 가격보장 서비스 신청 (선택)</h1>
              <!-- 2021.03.29 (ver1.4) @click 수정 -->
              <v-btn
                :class="{ active: isUsedCarAct }"
                class="btn white md r"
                @click="setAct(5, true), (isUsedCarAct = true)"
                >신청하기</v-btn
              >
              <v-btn class="btn-detail" type="icon" :icon-class="['icon-open', { active: isAct(5) }]" @click="setAct(5)"
                ><span class="offscreen">상세보기</span></v-btn
              >
            </div>
            <div v-show="isAct(5)" class="detail-info">
              <p>기획 TBD</p>
              <!-- <p>신차 구매 차량의 잔존가치를 3년간 보유 기간에 따라 높은 보장율로 고객만족을 높이고, 당사 신차 구매 시 중고차 가격 확보를 통해 신차 구입 편의를 증대하기 위한 서비스입니다. 무료로 신청하고, 3년 이내 당사 차량 재구매 시 할인 혜택을 누리세요.</p> -->
            </div>
          </section>

          <!-- 어드밴티지 프로그램 -->
          <section class="information-detail">
            <div class="summary-info">
              <!-- 2021.03.29 (ver1.4) 선택 텍스트 추가 -->
              <h1 class="title">어드밴티지 프로그램 (선택)</h1>
              <!-- 2021.03.29 (ver1.4) @click 수정 -->
              <v-btn
                :class="{ active: isAdvantageAct }"
                class="btn white md r"
                @click="setAct(6, true), (isAdvantageAct = true)"
                >신청하기</v-btn
              >
              <v-btn class="btn-detail" type="icon" :icon-class="['icon-open', { active: isAct(6) }]" @click="setAct(6)"
                ><span class="offscreen">상세보기</span></v-btn
              >
            </div>
            <div v-show="isAct(6)" class="detail-info">
              <p>기획 TBD</p>
            </div>
          </section>

          <!-- 2021.03.29 (ver1.4) 추가 -->
          <!-- 웰컴 H-패밀리 케어 프로그램 신청 -->
          <section class="information-detail">
            <div class="summary-info">
              <h1 class="title">웰컴 H-패밀리 케어 프로그램 신청 (선택)</h1>
              <v-btn
                :class="{ active: isWelcomeCare }"
                class="btn white md r"
                @click="setAct(12, true), (isWelcomeCare = true)"
                >신청하기</v-btn
              >
              <v-btn
                class="btn-detail"
                type="icon"
                :icon-class="['icon-open', { active: isAct(12) }]"
                @click="setAct(12)"
                ><span class="offscreen">상세보기</span></v-btn
              >
            </div>
            <div v-show="isAct(12)" class="detail-info">
              <p>기획 TBD</p>
            </div>
          </section>
        </section>

        <!-- 구매동의 -->
        <section class="purchase-agree">
          <h1>구매동의</h1>

          <!-- 자동차 교환ㆍ환불 중재제도 설명에 대한 이해 및 수락여부 확인 -->
          <section class="information-detail">
            <div class="summary-info">
              <!-- 2021.03.29 (ver1.4) 필수 텍스트 추가 -->
              <h1 class="title">자동차 교환ㆍ환불 중재제도 설명에 대한 이해 및 수락여부 확인 (필수)</h1>
              <v-btn class="btn-detail" type="icon" :icon-class="['icon-open', { active: isAct(7) }]" @click="setAct(7)"
                ><span class="offscreen">상세보기</span></v-btn
              >
            </div>
            <div v-show="isAct(7)" class="detail-info">
              <!-- 2021.03.29 (ver1.4) 내용 추가 start -->
              <div class="table-area">
                <div class="table-top">
                  <strong class="title">교환&middot;환불 중재 제도 요지</strong>
                </div>
                <table>
                  <colgroup>
                    <col width="150px" />
                    <col width="auto" />
                  </colgroup>
                  <tbody>
                    <tr>
                      <th>중재의 정의</th>
                      <td>
                        “중재”는 분쟁 당사자들간의 합의로 그들의 분쟁을 중립적 사람(중재위원) 또는 중재부(중제관정부)의
                        결정(중재판정)에 의하여 해결하고 그 결정에 구속되는 분쟁해결절차를 말합니다.
                      </td>
                    </tr>
                    <tr>
                      <th>중재합의</th>
                      <td>
                        ① “중재합의＂는 당사자 간에 이미 발생했거나 발생이 예상되는 분쟁의 전부 또는 일부를 중재에
                        의하여 해결하도록 하는 당사자 간의 합의를 말합니다.<br />② 자동차 교환ㆍ환불 중재 규정(이하
                        “중재규정“이라 함)이 적용되는 중재합의는 양 당사자 모두가 자동차관리법 제47조의 4 제1항에 따라
                        중재규정을 수락했을 때 성립합니다.
                      </td>
                    </tr>
                    <tr>
                      <th>중재합의의<br />성립과 효과</th>
                      <td>
                        ① 자동차관리법 제47조의 4 제1항에 따라 제작자가 사전에 중재규정을 수락하였고, 또한 동 제작자가
                        제작한 차량의 구매자가 매매계약을 체결할 때 또는 교환ㆍ환불 중재를 신청할 때 중재규정을 수락한
                        경우, 자동차 교환ㆍ환불 중재합의가 성립된 것으로 간주됩니다.<br />② 제1항에 따라 자동차
                        교환ㆍ환불 중재합의가 성립되면 양 당사자는 동일한 내용의 교환ㆍ환불을 이유로 법원에 소송을
                        제기할 수 없습니다.<br />③ 제1항에 따라 자동차 교환ㆍ환불 중재합의가 성립되면 1985년
                        ‘외국중재판정의 승인 및 집행에 관한 뉴욕 협약’ 제2조에 규정된 승인 및 집행의 요건으로서 중재에
                        대한 서면 합의 요건을 충족하는 것으로 봅니다.
                      </td>
                    </tr>
                    <tr>
                      <th>중재판정의 효력</th>
                      <td>중재판정은 제작자와 소유자에 대하여 법원의 확정판결과 동일한 효력이 있습니다.</td>
                    </tr>
                  </tbody>
                </table>
              </div>
              <div class="table-area">
                <div class="table-top">
                  <strong class="title">중요 안내 사항</strong>
                </div>
                <table>
                  <colgroup>
                    <col width="150px" />
                    <col width="auto" />
                  </colgroup>
                  <tbody>
                    <tr>
                      <th>자동차 교환ㆍ환불 중재 규정을 수락한 사실</th>
                      <td>
                        “중재”는 분쟁 당사자들간의 합의로 그들의 분쟁을 중립적 사람(중재위원) 또는 중재부(중제관정부)의
                        결정(중재판정)에 의하여 해결하고 그 결정에 구속되는 분쟁해결절차를 말합니다.
                      </td>
                    </tr>
                    <tr>
                      <th>신차로의 교환ㆍ환불 보장</th>
                      <td>
                        현대자동차는 자동차관리법 제47조 제1항 및 자동차관리법 제47조의 7 제2항에 따른 자동차 안전ㆍ하자
                        심의위원회가 제정한 교환ㆍ환불 중재 규정(이하 “중재규정”이라 칭함)을 수락하였음을 알려드립니다.
                      </td>
                    </tr>
                    <tr>
                      <th>인도날짜</th>
                      <td>
                        ① “중재합의＂는 당사자 간에 이미 발생했거나 발생이 예상되는 분쟁의 전부 또는 일부를 중재에
                        의하여 해결하도록 하는 당사자 간의 합의를 말합니다.<br />② 자동차 교환ㆍ환불 중재 규정(이하
                        “중재규정” 이라 칭함)이 적용되는 중재합의는 양 당사자 모두가 자동차관리법 제47조의 제1항에 따라
                        중재규정을 수락했을 때 성립합니다.
                      </td>
                    </tr>
                    <tr>
                      <th>통지방법</th>
                      <td>
                        현대자동차는 자동차관리법 제47조 제1항 및 자동차관리법 제47조의 7 제2항에 따른 자동차 안전ㆍ하자
                        심의위원회가 제정한 교환ㆍ환불 중재 규정(이하 “중재규정”이라 칭함)을 수락하였음을 알려드립니다.
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
              <div class="agree-box">
                <strong class="title">하자재발통보</strong>
                <v-checkbox v-model="checkDefect" class="check-list" :custom-label="true" :data="checkDefectList">
                  <template slot-scope="props"
                    ><span>{{ props.item.label }}</span
                    ><span v-html="props.item.text"></span
                  ></template>
                </v-checkbox>
              </div>
              <div class="agree-box">
                <strong class="title"
                  >본인은 자동차 교환ㆍ환불 중재 규정에 대한 수락 시점을 다음 중에서 선택합니다.</strong
                >
                <v-radio v-model="radioDefect" :data="radioDefectList" />
                <v-checkbox :one-check="true" :checked.sync="checkDefect2"
                  >본인은 자동차 교환ㆍ환불 중재 규정에 따른 통지 및 연락을 전자우편, 문자메시지, 팩스 등을 통해
                  받겠습니다.<br />(미동의 시 직접 교부, 등기우편 등 발송 및 수취를 증명할 수 있는 우편방법
                  이용)</v-checkbox
                >
              </div>
            </div>
          </section>

          <!-- 특별주문차량 구매 동의 -->
          <section class="information-detail">
            <div class="summary-info">
              <!-- 2021.03.29 (ver1.4) 필수 텍스트 추가 -->
              <h1 class="title">특별주문차량 구매 동의 (필수)</h1>
              <!-- 2021.03.29 (ver1.4) @click 수정 -->
              <v-btn
                :class="{ active: specialOrderAgreeCheckActive }"
                class="btn white md r"
                @click="setAct(8, true, specialOrderAgreeCheck), (isSpecialAct = true)"
                >전체동의</v-btn
              >
              <v-btn class="btn-detail" type="icon" :icon-class="['icon-open', { active: isAct(8) }]" @click="setAct(8)"
                ><span class="offscreen">상세보기</span></v-btn
              >
            </div>
            <div v-show="isAct(8)" class="detail-info">
              <!-- 2021.03.29 (ver1.4) 내용 추가 start -->
              <div class="info-grid-list">
                <!-- 2021.03.29 (ver1.4) @change 추가 -->
                <v-checkbox :one-check="true" :checked.sync="checkSpecial" @change="actInnerCheck(8)"
                  >본인은 아래 표에 기재되어 있는 특별주문차량의 생산 요청을 최종 확인합니다.</v-checkbox
                >
                <ul>
                  <li>
                    <strong class="info-title">차종</strong>
                    <div class="info-group">AX 자가용 5인승 가솔린 1.6 2WD IVT Smart</div>
                  </li>
                  <li>
                    <strong class="info-title">계약일시</strong>
                    <div class="info-group">2021년 1월 19일</div>
                  </li>
                  <li>
                    <strong class="info-title">주문요청일시</strong>
                    <div class="info-group">2021년 1월 20일</div>
                  </li>
                  <li>
                    <strong class="info-title">외장칼라</strong>
                    <div class="info-group">팬텀 블랙</div>
                  </li>
                  <li>
                    <strong class="info-title">내장칼라</strong>
                    <div class="info-group">블랙 모노톤(블랙시트)</div>
                  </li>
                  <li>
                    <strong class="info-title">계약번호</strong>
                    <div class="info-group">A3721CN000022</div>
                  </li>
                  <li>
                    <strong class="info-title">옵션</strong>
                    <div class="info-group">
                      <em class="full">[선택옵션]</em>
                      <ul>
                        <li>개별 옵션- 옵션 1, 옵션 2, 옵션 3</li>
                        <li>패키지- 옵션 1, 옵션 2, 옵션 3</li>
                        <li>TUIX – 옵션 1, 옵션 2, 옵션 3</li>
                      </ul>
                    </div>
                  </li>
                </ul>
              </div>
              <!-- 2021.03.29 (ver1.4) @change 추가 -->
              <v-checkbox
                v-model="checkSpecial2"
                class="check-list"
                :data="checkSpecialList"
                @change="actInnerCheck(8)"
              />
              <!-- end -->
            </div>
          </section>

          <!-- 판촉차량 구매 동의 -->
          <section class="information-detail">
            <div class="summary-info">
              <!-- 2021.03.29 (ver1.4) 필수 텍스트 추가 -->
              <h1 class="title">판촉차량 구매 동의 (필수)</h1>
              <!-- 2021.03.29 (ver1.4) @click 수정 -->
              <v-btn
                :class="{ active: promotionAgreeCheckActive }"
                class="btn white md r"
                @click="setAct(9, true, promotionAgreeCheck), (isSaleAct = true)"
                >전체동의</v-btn
              >
              <v-btn class="btn-detail" type="icon" :icon-class="['icon-open', { active: isAct(9) }]" @click="setAct(9)"
                ><span class="offscreen">상세보기</span></v-btn
              >
            </div>
            <div v-show="isAct(9)" class="detail-info">
              <!-- 2021.03.29 (ver1.4) 내용 추가 start -->
              <div class="info-grid-list">
                <v-checkbox :one-check="true" :checked.sync="checkSale" @change="actInnerCheck(9)"
                  >본인은 아래 표에 기재되어 있는 현재 주요 문제 내역은 보증수리 불가함을 확인합니다.</v-checkbox
                >
                <ul>
                  <li>
                    <strong class="info-title">차종</strong>
                    <div class="info-group">AX 자가용 5인승 가솔린 1.6 2WD IVT Smart</div>
                  </li>
                  <li>
                    <strong class="info-title">차대번호</strong>
                    <div class="info-group">KMHGR41EDKU321360</div>
                  </li>
                  <li>
                    <strong class="info-title">생산일자</strong>
                    <div class="info-group">2021년 1월 20일</div>
                  </li>
                  <li>
                    <strong class="info-title">차량금액</strong>
                    <div class="info-group">41,610,000 원</div>
                  </li>
                  <li>
                    <strong class="info-title">판촉 할인금액</strong>
                    <div class="info-group">22,000,000 원</div>
                  </li>
                  <li>
                    <strong class="info-title">할인사유</strong>
                    <div class="info-group">등록환입 | 엔진, 변속기, ECM 교환</div>
                  </li>
                  <li>
                    <strong class="info-title">현 주요문제</strong>
                    <div class="info-group">
                      <ul>
                        <li>본네트 교환</li>
                        <li>앞펜더: 우 교환</li>
                        <li>실내/시트 오염</li>
                        <li>바닥 낙진 및 스크래치</li>
                        <li>엔진 교환 및 LH FRT BPR 긁힘</li>
                      </ul>
                    </div>
                  </li>
                </ul>
              </div>
              <v-checkbox v-model="checkSale2" class="check-list" :data="checkSaleList" @change="actInnerCheck(9)" />
              <!-- end -->
            </div>
          </section>

          <!-- 전시차량 구매 동의 -->
          <section class="information-detail">
            <div class="summary-info">
              <!-- 2021.03.29 (ver1.4) 필수 텍스트 추가 -->
              <h1 class="title">전시차량 구매 동의 (필수)</h1>
              <!-- 2021.03.29 (ver1.4) @click 수정 -->
              <v-btn
                :class="{ active: displayCarAgreeCheckActive }"
                class="btn white md r"
                @click="setAct(10, true, displayCarAgreeCheck), (isDisplayAct = true)"
                >전체동의</v-btn
              >
              <v-btn
                class="btn-detail"
                type="icon"
                :icon-class="['icon-open', { active: isAct(10) }]"
                @click="setAct(10)"
                ><span class="offscreen">상세보기</span></v-btn
              >
            </div>
            <div v-show="isAct(10)" class="detail-info">
              <!-- 2021.03.29 (ver1.4) 내용 추가 start -->
              <div class="info-grid-list">
                <v-checkbox :one-check="true" :checked.sync="checkDisplay" @change="actInnerCheck(10)"
                  >아래 명시된 차량은 [테헤란] 지점 전시 차량임을 확인합니다.</v-checkbox
                >
                <ul>
                  <li>
                    <div class="info-title">차종</div>
                    <div class="info-group">AX 자가용 5인승 가솔린 1.6 2WD IVT Smart</div>
                  </li>
                  <li>
                    <div class="info-title">차대번호</div>
                    <div class="info-group">KMHGR41EDKU321360</div>
                  </li>
                  <li>
                    <div class="info-title">생산일자</div>
                    <div class="info-group">2021년 1월 20일</div>
                  </li>
                  <li>
                    <div class="info-title">차량상태</div>
                    <div class="info-group">바닥 낙진 및 스크래치</div>
                  </li>
                </ul>
              </div>
              <v-checkbox class="check-list" :one-check="true" :checked.sync="checkDisplay2" @change="actInnerCheck(10)"
                >본인은 귀사의 전시차량의 상태 및 특이사항에 대하여 충분히 숙지하고 확인하였습니다.</v-checkbox
              >
            </div>
          </section>

          <!-- 임직원 차량의무보유기간 준수 동의 -->
          <section class="information-detail">
            <div class="summary-info">
              <!-- 2021.03.29 (ver1.4) 필수 텍스트 추가 -->
              <h1 class="title">직원 차량의무보유기간 준수 동의 (필수)</h1>
              <!-- 2021.03.29 (ver1.4) @click 수정 -->
              <v-btn
                :class="{ active: staffDutyAgreeCheckActive }"
                class="btn white md r"
                @click="setAct(11, true, staffDutyAgreeCheck), (isStaffAct = true)"
                >전체동의</v-btn
              >
              <v-btn
                class="btn-detail"
                type="icon"
                :icon-class="['icon-open', { active: isAct(11) }]"
                @click="setAct(11)"
                ><span class="offscreen">상세보기</span></v-btn
              >
            </div>
            <div v-show="isAct(11)" class="detail-info">
              <!-- 2021.03.29 (ver1.4) 내용 추가 start -->
              <div class="info-grid-list">
                <v-checkbox :one-check="true" :checked.sync="checkStaff" @change="actInnerCheck(11)"
                  >본인은 아래 표에 기재되어 있는 임직원용 차량 정보를 최종 확인합니다.</v-checkbox
                >
                <ul>
                  <li>
                    <strong class="info-title">차종</strong>
                    <div class="info-group">AX 자가용 5인승 가솔린 1.6 2WD IVT Smart</div>
                  </li>
                  <li>
                    <strong class="info-title">차량가격</strong>
                    <div class="info-group">10,000,000원</div>
                  </li>
                  <li>
                    <strong class="info-title">직원용 할인액</strong>
                    <div class="info-group">600,000원</div>
                  </li>
                </ul>
              </div>
              <v-checkbox
                v-model="checkStaff2"
                class="check-list"
                :custom-label="true"
                :data="checkStaffList"
                @change="actInnerCheck(11)"
              >
                <template slot-scope="props"
                  ><span>{{ props.item.label }}</span
                  ><span v-html="props.item.text"></span
                ></template>
              </v-checkbox>
              <!-- end -->
            </div>
          </section>
        </section>
      </div>

      <contract-tool />
    </div>
    <div class="btn-wrap">
      <v-btn class="btn lg gray r">이전</v-btn>
      <v-btn class="btn lg blue r">다음</v-btn>
    </div>
  </div>
</template>

<script>
import ContractTool from '~/components/page/contract/ContractTool'
import TermsBlueMembers from '~/components/page/contract/popup/TermsBlueMembers'
import PostCode from '~/components/common/PostCode'
export default {
  components: {
    ContractTool,
    TermsBlueMembers,
    PostCode
  },
  data() {
    return {
      viewType: '',
      hipassType: true,
      hipassAct: false,
      isUsedCarAct: false,
      isAdvantageAct: false,
      isSpecialAct: false,
      isSaleAct: false,
      isDisplayAct: false,
      isStaffAct: false,
      isTaxAct: false,
      // 2021.03.29 (ver1.4) 추가
      isWelcomeCare: false,
      cardForm: {
        address: '',
        address2: '',
        address3: ''
      },

      //
      listSelected: [false, false, false, false, false, false, false, false, false, false, false, false, false],

      // 블루멤버스
      checkboxBluemembers: false,
      checkboxBluemembers1: false,
      checkboxBluemembers2: false,
      checkboxInfoAll: [],
      checkboxInfoAllList: [
        { value: 'check1', label: '문자(SMS)' },
        { value: 'check2', label: '이메일' },
        { value: 'check3', label: '우편(DM)' },
        { value: 'check4', label: '휴대폰/전화' }
      ],

      // 하이패스
      checkboxHipass1: false,
      checkboxHipass2: false,

      // 구매동의 - 자동차 교환ㆍ환불 중재제도 설명에 대한 이해 및 수락여부 확인
      checkDefect: [],
      checkDefectList: [
        {
          value: 'defect1',
          label: '등기우편 : 서울 동작구 노량진로53 현대자동차 고객센터',
          text:
            '<br />전자우편 : 현대자동차 홈페이지<a href="http://www.hyundai.com" target="_blank" title="새창열기">(http://www.hyundai.com)</a> 또는 제네시스 홈페이지<a href="http://www/genesis.com" target="_blank" title="새창열기">(http://www/genesis.com)</a><br />하자재발통보서 접수'
        },
        {
          value: 'defect2',
          label: '대표(수신인) : 현대자동차 고객센터'
        },
        {
          value: 'defect3',
          label:
            '본인은 자동차 교환ㆍ환불 중재 제도 요지 및 중요 안내 사항을 읽고 숙지하여 충분히 이해하였음을 확인합니다.'
        }
      ],
      radioDefect: false,
      radioDefectList: [
        { value: 'rdDefect1', label: '추후 중재 신청 시 수락하겠습니다' },
        { value: 'rdDefect2', label: '지금 수락하겠습니다. (수락 시점 이후 법원에 소송제기 불가)' }
      ],
      checkDefect2: false,

      // 구매동의 - 특별주문차량
      checkSpecial: false,
      checkSpecial2: [],
      checkSpecialList: [
        { value: 'special1', label: '본인은 상기 특별주문차량의 생산 요청을 최종 확인합니다.' },
        {
          value: 'special2',
          label:
            '‘전자상거래법 시행령 제21조’에 의거 상기 본인이 주문 요청한 특별주문생산 차량은 청약철회가 제한됨을 확인합니다.'
        },
        {
          value: 'special3',
          label:
            '청약철회 제한에도 불구하고 본인은 계약을 해제할 수 있으며, ‘전자상거래법 제19조’에 의거 계약 해지 시 위약금 10만원이 발생됨을 확인합니다.'
        },
        {
          value: 'special4',
          label:
            '본인이 금번 계약으로 납부한 계약금 10만원은 계약 해지 시 환불되지 않으며, 발생한 위약금 10만원으로 대체 납부한다는 사실을 확인합니다.'
        }
      ],

      // 구매동의 - 판촉차량
      checkSale: false,
      checkSale2: [],
      checkSaleList: [
        {
          value: 'sale1',
          label:
            '본인은 귀사의 차량 판매가격에서 ￦0,000,000원을 할인(판매가격의 11.5%) 받아 기재된 현재 주요문제 내역을 귀사로부터 매수할 당시 귀사와 본인이 인정하여 상호 합의한 문제부위에 대해서는 귀사의 약관 제7조에서 정한 보증수리 책임을 청구하지 않음은 물론, 동 약관 각 조항에서 정한 귀사의 하자담보 책임과 관련한 일체 민ㆍ형사상의 항변권을 포기할 것을 동의합니다.'
        },
        {
          value: 'sale2',
          label:
            '상기 차량을 제 3자에게 양도하는 경우 문제내역 고지 및 해당 문제에 대한 보증수리가 불가함을 통지할 의무가 있으며, 이러한 의무를 해태하여 귀사가 손해를 입는 경우 일체 손해를 배상하도록 하겠습니다.'
        }
      ],

      // 구매동의 - 전시차량
      checkDisplay: false,
      checkDisplay2: false,

      // 구매동의 - 직원
      checkStaff: false,
      checkStaff2: [],
      checkStaffList: [
        {
          value: 'staff1',
          label:
            '1항) 임직원 복지 차원에서 회사가 규정한대로 근속년수 및 직원용 타겟 조건에 따른 할인을 받아 차량을 구입한 임직원은 본인(배우자 포함) 명의로 차량등록을 하여야 하며, 차량출고일로부터 2년 간 제3자에게 명의를 이전하지 않는다.',
          text:
            '*예) 2017-02-15 출고, 2019-02-15부터 명의변경/매각/재출고 가능, 보유기간 종료일이 법정휴일인 경우 해당일에 이은 첫번째 평일부터 가능'
        },
        {
          value: 'staff2',
          label:
            '2항) 임직원의 개인사정으로 인해 출고일로부터 2년 내 부득이하게 차량을 타인 명의로 이전할 필요가 생긴 경우에는 사전에 회사에 서면 신고를 한 후 승인을 득하여야 하며, 사전신고를 한 임직원의 경우에는 직원용 할인액 중 잔여보유기간에 해당하는 비율만큼의 할인액을 현금 일시불로 회사에 반환하여야 한다.',
          text: '* 반환해야 할 할인액 = 직원용 할인액 x 잔여일수/730일(2년)'
        },
        {
          value: 'staff3',
          label:
            '3항) 본인명의로 차량등록 후 사전신고 없이 타인명의로 이전을 하거나, 미등록상태에서 차량을 타인에게 전매한 경우에는 할인액 전액을 현금 일시불로 회사에 반납하여야 한다. (할인액의 반환과는 별도로 회사는 의무보유기간 지침을 위반한 임직원에 한해 징계를 할 수 있다.)'
        },
        {
          value: 'staff4',
          label:
            '4항) 제2항의 경우 사전신고일 다음날로부터 그리고 제3항의 경우 의무보유기간의 준수를 위반한 날로부터 할인액을 반환할 의무를 부담한다.'
        },
        {
          value: 'staff5',
          label:
            '5항) 별도의 약정이 없는 경우 지연손해는 위 제4항의 각 날로부터 차량매매계약 당시 계약서상의 지연손해배상규정이율에 의해 계산한다.'
        },
        { value: 'staff6', label: '6항) 기타 세부사항은 공지된 회사 임직원 차량 판매지침에 따른다.' }
      ],

      popVisible: {
        termsBlueMembers: false,
        postCode: false
      }
    }
  },
  computed: {
    rules() {
      return {
        address: [
          {
            required: true,
            message: '* 주소를 입력해 주세요.',
            trigger: 'blur'
          }
        ]
      }
    },
    blueMembersAgreeCheckActive() {
      if (
        this.checkboxBluemembers1 === true &&
        this.checkboxBluemembers2 === true &&
        this.checkboxInfoAll.includes('all')
      ) {
        return true
      } else {
        return false
      }
    },
    personalInfoAgreeCheckActive() {
      if (this.checkboxHipass1 === true && this.checkboxHipass2 === true) {
        return true
      } else {
        return false
      }
    },
    specialOrderAgreeCheckActive() {
      if (this.checkSpecial === true && this.checkSpecial2.length === this.checkSpecialList.length) {
        return true
      } else {
        return false
      }
    },
    promotionAgreeCheckActive() {
      if (this.checkSale === true && this.checkSale2.length === this.checkSaleList.length) {
        return true
      } else {
        return false
      }
    },
    displayCarAgreeCheckActive() {
      if (this.checkDisplay === true && this.checkDisplay2 === true) {
        return true
      } else {
        return false
      }
    },
    staffDutyAgreeCheckActive() {
      if (this.checkStaff === true && this.checkStaff2.length === this.checkStaffList.length) {
        return true
      } else {
        return false
      }
    }
  },
  mounted() {
    this.setLabel((idg) => {
      // console.dir(idg) // 자동 생성된 ID 배열
    })
  },
  methods: {
    setAct(index, status, fnc) {
      if (status === undefined || status === null) {
        if (this.listSelected[index] === false) {
          this.$set(this.listSelected, index, true)
        } else {
          this.$set(this.listSelected, index, false)
        }
      } else {
        this.$set(this.listSelected, index, status)
      }

      if (fnc !== undefined) fnc()
    },
    isAct(index, value) {
      if (value !== undefined) {
        this.listSelected[index] = value
      }
      return this.listSelected[index] === true
    },
    // popOpen() {
    //   if (this.checkboxBluemembers) {
    //     this.popVisible.termsBlueMembers = true
    //   }
    // }
    actInnerCheck(number) {
      if (number === 1) {
        //블루멤버스 회원가입 및 개인정보 활용 동의
        if (!this.checkboxBluemembers1 && !this.checkboxBluemembers2 && this.checkboxInfoAll.includes('all')) {
          this.isAct(1, false)
        }
      } else if (number === 4) {
        //개인정보 수집ㆍ이용 및 제공 동의 [한국도로공사용]
        if (!this.checkboxHipass1 && !this.checkboxHipass2) {
          this.isAct(4, false)
        }
      } else if (number === 8) {
        //특별주문차량 구매 동의 (필수)
        if (!this.checkSpecial && this.checkSpecial2.length === 0) {
          this.isAct(8, false)
        }
      } else if (number === 9) {
        //판촉차량 구매 동의 (필수)
        if (!this.checkSale && this.checkSale2.length === 0) {
          this.isAct(9, false)
        }
      } else if (number === 10) {
        //전시차량 구매 동의 (필수)
        if (!this.checkDisplay && !this.checkDisplay2) {
          this.isAct(10, false)
        }
      } else if (number === 11) {
        //직원 차량의무보유기간 준수 동의 (필수)
        if (!this.checkStaff && this.checkStaff2.length === 0) {
          this.isAct(11, false)
        }
      }
    },
    blueMembersAgreeCheck(type) {
      this.checkboxBluemembers1 = true
      this.checkboxBluemembers2 = true
      let val = ['all']
      this.checkboxInfoAllList.forEach((value) => {
        val.push(value.value)
      })
      this.checkboxInfoAll = val
    },
    personalInfoAgreeCheck(type) {
      this.checkboxHipass1 = true
      this.checkboxHipass2 = true
    },
    specialOrderAgreeCheck(type) {
      this.checkSpecial = true
      let val = []
      this.checkSpecialList.forEach((value) => {
        val.push(value.value)
      })
      this.checkSpecial2 = val
    },
    promotionAgreeCheck(type) {
      this.checkSale = true
      let val = []
      this.checkSaleList.forEach((value) => {
        val.push(value.value)
      })
      this.checkSale2 = val
    },
    displayCarAgreeCheck(type) {
      this.checkDisplay = true
      this.checkDisplay2 = true
    },
    staffDutyAgreeCheck(type) {
      this.checkStaff = true
      let val = []
      this.checkStaffList.forEach((value) => {
        val.push(value.value)
      })
      this.checkStaff2 = val
    }
  }
}
</script>
