<template>
  <div class="detail-info sale-point">
    <div class="info-grid-list">
      <ul>
        <!-- 직원혜택 -->
        <li>
          <div class="info-title full bold">직원혜택</div>
          <div class="info-group full">
            <ul class="desc-list">
              <li>
                <!-- 2021.03.23 (ver1.3) 수정 -->
                <!-- 2021.03.29 (ver1.4) 텍스트 수정 -->
                <v-checkbox :one-check="true" :checked.sync="checkboxEmployeeDiscount"
                  >직원 할인 (할인율 26%)</v-checkbox
                >
                <span class="price">(-) 100,000 원</span>
              </li>
              <!-- 2021.03.29 (ver1.4) 삭제 -->
              <!-- <li>
                <em>추가 혜택</em>
                <ul class="inbl-wrap">
                  <li>
                    <el-radio v-model="radioEmployee" label="무이자할부"></el-radio>
                  </li>
                  <li>
                    <el-radio v-model="radioEmployee" label="일시불 3% 할인"></el-radio>
                  </li>
                  <li>
                    <el-radio v-model="radioEmployee" label="선택안함"></el-radio>
                  </li>
                </ul>
                <span class="price">(-) 900,000 원</span>
              </li> -->
            </ul>
          </div>
        </li>
        <!-- 차량할인 -->
        <li>
          <strong class="info-title bold">차량할인</strong>
          <div class="info-group full">
            <ul class="desc-list">
              <li>
                <em>차량기본할인</em>
                <span class="price">(-) 0 원</span>
              </li>
              <!-- 법인 -->
              <li>
                <ul>
                  <li>
                    <v-checkbox :one-check="true" :checked.sync="checkboxDataDiscount">차량기본할인</v-checkbox>
                    <!-- 2021.03.23 (ver1.3) active 추가 -->
                    <span class="price" :class="{ active: checkboxDataDiscount }">(-) 900,000 원</span>
                  </li>
                  <li>
                    <v-checkbox :one-check="true" :checked.sync="checkboxDataDiscount2">금리할인상품명1</v-checkbox>
                    <v-btn
                      class="btn-info"
                      type="icon"
                      icon-class="icon-info"
                      @click="popVisible.discountConditions = true"
                      ><span class="offscreen">안내팝업보기</span></v-btn
                    >
                    <!-- 2021.03.23 (ver1.3) active 추가 -->
                    <span class="price" :class="{ active: checkboxDataDiscount2 }">(-) 900,000 원</span>
                  </li>
                  <li>
                    <v-checkbox :one-check="true" :checked.sync="checkboxDataDiscount3">금리할인상품명2</v-checkbox>
                    <v-btn
                      class="btn-info"
                      type="icon"
                      icon-class="icon-info"
                      @click="popVisible.discountConditions = true"
                      ><span class="offscreen">안내팝업보기</span></v-btn
                    >
                    <!-- 2021.03.23 (ver1.3) active 추가 -->
                    <span class="price" :class="{ active: checkboxDataDiscount3 }">(-) 900,000 원</span>
                  </li>
                </ul>
              </li>
              <!-- 2021.03.29 (ver1.4) 삭제 -->
              <!-- <li>
                <em>생산월할인</em>
                <span class="price">(-) 0 원</span>
              </li>
              <li>
                <em>특별재고할인</em>
                <span class="price">(-) 0 원</span>
              </li>
              <li>
                <em>전시할인</em>
                <span class="price">(-) 0 원</span>
              </li>
              <li>
                <em>판촉할인</em>
                <span class="price">(-) 0 원</span>
              </li> -->
              <!-- 2021.03.29 (ver1.4) 추가 -->
              <li>
                <em>기획전할인</em>
                <span class="price">(-) 0 원</span>
              </li>
            </ul>
          </div>
        </li>
        <!-- 타겟조건할인 -->
        <li>
          <div class="info-title full">
            <strong class="bold">타겟조건할인</strong>
            <p class="bullet-star">
              조건할인 선택 시, 결제 후 할인대상 심사를 위한 증빙서류 및 심사 기간이 필요할 수 있습니다.
            </p>
          </div>
          <div class="info-group full">
            <ul class="desc-list">
              <li v-for="(condition, index) in conditionData" :key="index">
                <v-checkbox :one-check="true" :checked.sync="condition.conditionCheck">{{
                  condition.conditionName
                }}</v-checkbox>
                <v-btn class="btn-info" type="icon" icon-class="icon-info" @click="popVisible.discountConditions = true"
                  ><span class="offscreen">안내팝업보기</span></v-btn
                >
                <!-- 2021.03.23 (ver1.3) active 추가 -->
                <span class="price" :class="{ active: condition.conditionCheck }"
                  >(-) {{ condition.conditionPrice }} 원</span
                >
              </li>
            </ul>
          </div>
        </li>
        <!-- 쿠폰할인 -->
        <li>
          <div class="info-title full">
            <strong class="bold">쿠폰할인</strong>
            <v-btn class="btn-more last" @click="popVisible.couponRegistration = true">쿠폰등록</v-btn>
          </div>
          <div class="info-group full">
            <ul v-if="couponData.length > 0" class="desc-list">
              <li v-for="(coupon, index) in couponData" :key="index">
                <v-checkbox :one-check="true" :checked.sync="coupon.couponCheck">{{ coupon.couponName }}</v-checkbox>
                <v-btn class="btn-info" type="icon" icon-class="icon-info" @click="popVisible.discountConditions = true"
                  ><span class="offscreen">안내팝업보기</span></v-btn
                >
                <!-- 2021.03.23 (ver1.3) active 추가 -->
                <span class="price" :class="{ active: coupon.couponCheck }">(-) {{ coupon.couponPrice }} 원</span>
              </li>
            </ul>
            <div v-else>
              <p>이번 계약에 사용 가능한 쿠폰이 없습니다.</p>
            </div>
          </div>
        </li>
        <!-- 지인추천할인 -->
        <li>
          <div class="info-title full bold">지인추천할인</div>
          <div class="info-group full">
            <ul class="desc-list">
              <li>
                <em>추천인 코드</em>
                <p>XTS0135792HO</p>
                <span class="price">(-) 0 원</span>
              </li>
            </ul>
          </div>
        </li>
      </ul>
    </div>
    <!-- 팝업 -->
    <discount-conditions
      :visible="popVisible.discountConditions"
      @close="popVisible.discountConditions = false"
    ></discount-conditions>
    <coupon-registration
      :visible="popVisible.couponRegistration"
      @close="popVisible.couponRegistration = false"
    ></coupon-registration>
  </div>
</template>

<script>
import DiscountConditions from '~/components/page/contract/popup/DiscountConditions'
import CouponRegistration from '~/components/page/estimation/popup/CouponRegistration'
export default {
  components: {
    DiscountConditions,
    CouponRegistration
  },
  data() {
    return {
      radioEmployee: '',
      checkboxDataDiscount: true,
      checkboxDataDiscount2: false,
      checkboxDataDiscount3: false,
      conditionData: [
        { conditionCheck: false, conditionName: '웰컴 H패밀리(2대)', conditionPrice: '100,000', popCondition: '' },
        { conditionCheck: false, conditionName: '타켓조건명', conditionPrice: '100,000', popCondition: '' },
        { conditionCheck: false, conditionName: '타켓조건명', conditionPrice: '100,000', popCondition: '' }
      ],
      couponData: [
        { couponCheck: false, couponName: '쿠폰명', couponPrice: '100,000', popCoupon: '' },
        { couponCheck: false, couponName: '쿠폰명', couponPrice: '100,000', popCoupon: '' },
        { couponCheck: false, couponName: '쿠폰명', couponPrice: '100,000', popCoupon: '' }
      ],
      // 팝업
      popVisible: {
        discountConditions: false,
        couponRegistration: false
      },
      // 2021.03.23 (ver1.3) 추가
      checkboxEmployeeDiscount: false
    }
  }
}
</script>
