<template>
  <!-- 2021.03.23 (ver1.3) step4 클래스 추가 -->
  <!-- 2021.03.31 (ver1.5) step4->step3로 수정 -->

  <!-- 2021.04.13 (ver1.6) 디자인 변경으로인한 전체적인 수정 -->
  <div class="page-step step3">

    <!-- 계약금 결제 단계 -->
    <div v-if="payment === true">
      <div class="matching-box">
        <div class="box-wrap">
          <div class="box-tit full">계약금 결제</div>
          <div class="box-desc full">
            <section class="information-detail">
              <div class="summary-info">
                <h1 class="title">결제 정보</h1>
              </div>
              <div class="detail-info">
                <div class="info-grid-list">
                  <ul>
                    <li>
                      <strong class="info-title">결제금액</strong>
                      <div class="info-group"><span class="bold">100,000</span> 원</div>
                    </li>
                    <li>
                      <strong class="info-title">결제기한</strong>
                      <div class="info-group">2021년 1월 20일 10시 27분까지</div>
                    </li>
                  </ul>
                </div>
              </div>
            </section>
            <section class="information-detail">
              <div class="summary-info">
                <h1 class="title">결제 방법</h1>
              </div>
              <div class="detail-info">
                <div class="info-grid-list">
                  <ul>
                    <li>
                      <strong class="info-title">결제수단</strong>
                      <div class="info-group">
                        <el-form ref="form" :rules="rules">
                          <v-tab class="tab-default" :data="tabList" :contents="true" @change="methodChange">
                            <template slot="contents">
                              <!-- 탭 : 신용카드 -->
                              <div data-id="tab1">
                                <div class="form-grid-list payment-method">
                                  <ul>
                                    <li>
                                      <strong class="form-label">결제자</strong>
                                      <div class="form-group">
                                        <div class="select inbl-wrap">
                                          <v-select v-model="purchaser" :data="purchaserList" placeholder="선택하세요" />
                                        </div>
                                      </div>
                                    </li>
                                    <li>
                                      <strong class="form-label">카드번호</strong>
                                      <div class="form-group">
                                        <div class="inbl-wrap card-number">
                                          <el-form-item prop="cardNumber">
                                            <div class="label-input">
                                              <label class="offscreen">첫번째 카드번호</label>
                                              <v-input v-model="cardNo.number00" type="number" maxlength="4" />
                                            </div>
                                            <div class="label-input">
                                              <label class="offscreen">두 번째 카드번호</label>
                                              <v-input v-model="cardNo.number01" type="number" maxlength="4" />
                                            </div>
                                            <div class="label-input">
                                              <label class="offscreen">세번째 카드번호</label>
                                              <v-input v-model="cardNo.number02" type="number" maxlength="4" />
                                            </div>
                                            <div class="label-input">
                                              <label class="offscreen">네번째 카드번호</label>
                                              <v-input v-model="cardNo.number03" type="number" maxlength="4" />
                                            </div>
                                            <span class="result">
                                              <i class="icon-check"></i>
                                              <i class="icon-x"></i>
                                            </span>
                                            <span class="card-company">현대카드</span>
                                          </el-form-item>
                                        </div>
                                      </div>
                                    </li>
                                    <li>
                                      <strong class="form-label ct">카드유효기간</strong>
                                      <div class="form-group">
                                        <el-form-item prop="datelimit" class="inbl-wrap card-limit">
                                          <div class="label-input">
                                            <label class="offscreen">년도 유효기간</label>
                                            <v-input
                                              v-model="cardPeriod.number00"
                                              type="number"
                                              maxlength="2"
                                              placeholder="MM"
                                            />
                                          </div>
                                          <div class="label-input">
                                            <label class="offscreen">월 유효기간</label>
                                            <v-input
                                              v-model="cardPeriod.number01"
                                              type="number"
                                              maxlength="2"
                                              placeholder="YY"
                                            />
                                          </div>
                                          <span class="result">
                                            <i class="icon-check"></i>
                                            <i class="icon-x"></i>
                                          </span>
                                        </el-form-item>
                                      </div>
                                    </li>
                                  </ul>
                                </div>
                              </div>
                              <!-- 탭 : 무통장입금 -->
                              <div data-id="tab2">
                                <div class="form-grid-list payment-method">
                                  <ul>
                                    <li>
                                      <strong class="form-label">입금은행</strong>
                                      <div class="form-group">
                                        <v-select v-model="depositBank" :data="depositBankData" placeholder="은행 선택" />
                                        <p class="form-text ct">입금 계좌번호 : 900252282011</p>
                                      </div>
                                    </li>
                                  </ul>
                                </div>
                              </div>
                            </template>
                          </v-tab>
                        </el-form>
                      </div>
                    </li>
                  </ul>
                </div>
              </div>
            </section>
            <p class="info-text">※ 특별주문차량 계약인 경우, 계약 취소 시 계약금을 환불받을 수 없습니다.</p>
          </div>
        </div>
      </div>
      <div class="btn-wrap">
        <v-btn class="btn lg gray r">이전</v-btn>
        <v-btn v-if="tabStatus == 'tab1'" class="btn lg blue r">계약금 결제</v-btn><!-- 신용카드 -->
        <v-btn v-if="tabStatus == 'tab2'" class="btn lg blue r">다음</v-btn><!-- 무통장 -->
      </div>
    </div>

    <!-- 신용카드 결제 완료 -->
    <div v-else-if="paymentCreditSuccess === true">
      <div class="matching-box payment-complete">
        <div class="title">신용카드 결제승인 완료</div>
        <p class="text">
          계약금 결제가 완료되었습니다.<br /><strong class="bold"
            >다음 단계로 이동하여 차량금액정보를 확인하고, 계약서 작성을 진행해 주세요.</strong
          >
        </p>
        <div class="info-grid-list">
          <ul>
            <li>
              <strong class="info-title">결제카드</strong>
              <div class="info-group">{{ cardCompanyName }}</div>
            </li>
            <li>
              <strong class="info-title">결제금액</strong>
              <div class="info-group"><span class="bold">{{ contractPrice }}</span> 원</div>
            </li>
          </ul>
        </div>
      </div>
      <div class="btn-wrap">
        <v-btn class="btn lg blue r">다음</v-btn>
      </div>
    </div>

    <!-- 무통장 입금정보 안내 -->
    <div v-else-if="paymentCashSuccess === true">
      <div class="matching-box payment-complete">
        <div class="title">무통장 입금정보 안내</div>
        <p class="text">
          <strong class="bold date">{{ paymentCompletionLimitDate }} 까지</strong> 계약금을 입금해 주세요.<br />입금기한
          내 입금하지 않는 경우 계약은 자동 취소됩니다.
        </p>
        <div class="info-grid-list bank">
          <ul>
            <li>
              <strong class="info-title">입금계좌번호</strong>
              <div class="info-group">{{ receiptsBankName }} {{ virtualAccount }}</div>
            </li>
            <li>
              <strong class="info-title">계약금</strong>
              <div class="info-group"><span class="bold">{{ paymentPrice }}</span>원</div>
            </li>
          </ul>
        </div>
        <div class="btn-wrap">
          <v-btn class="btn black md r">입금 계좌번호 복사</v-btn>
          <!-- asis -->
          <!-- <v-btn
            v-if="Object.keys(resultInfo).length > 0"
            v-clipboard:copy="resultInfo.virtualAccount"
            v-clipboard:success="onCopy"
          >입금 계좌번호 복사</v-btn> -->
          <v-btn class="btn black md r" @click="popVisible.accountNumberSms = true">입금 계좌번호 SMS 전송</v-btn>
          <v-btn class="btn-info" @click="popVisible.dutyCar = true"
            ><span class="offscreen">안내팝업보기</span></v-btn
          >
        </div>
        <p class="bullet-star">계약금 입금 확인은 마이페이지>나의 구매내역에서 확인하실 수 있습니다.</p>
      </div>
      <div class="btn-wrap">
        <v-btn class="btn lg blue r">다음</v-btn>
      </div>
    </div>

    <!-- 계약금 결제 완료 안내 -->
    <div v-else-if="paymentComplete === true">
      <div class="matching-box payment-complete">
        <div class="info-text">해당 차량은 계약금 결제가 이미 완료되었습니다.<br />다음 단계로 진행하시기 바랍니다.</div>
      </div>
      <div class="btn-wrap">
        <v-btn class="btn lg blue r">다음</v-btn>
      </div>
    </div>

    <!-- 팝업 : 입금 계좌번호 SMS 전송  -->
    <account-number-sms :visible="popVisible.accountNumberSms" @close="popVisible.accountNumberSms = false" />
  </div>
</template>

<script>
import AccountNumberSms from '~/components/page/contract/popup/AccountNumberSms'
export default {
  components: {
    AccountNumberSms
  },
  data() {
    return {
      // 계약금결제
      payment: true,
      // 신용카드 결제 완료
      paymentCreditSuccess: false,
      // 무통장입금 결제안내
      paymentCashSuccess: false,
      // 계약금 결제 완료안내
      paymentComplete: false,

      tabStatus: 'tab1',
      tabList: [
        { value: 'tab1', label: '신용카드' },
        { value: 'tab2', label: '무통장 입금' }
      ],
      purchaser: 'select1',
      purchaserList: [
        { value: 'select1', label: '김현대' },
        { value: 'select2', label: '김계약' }
      ],
      cardNo: {
        number00: null,
        number01: null,
        number02: null,
        number03: null
      },
      cardPeriod: {
        number00: null,
        number01: null
      },
      depositBank: 'bank1',
      depositBankData: [
        { value: 'bank1', label: '우리은행' },
        { value: 'bank2', label: '국민은행' }
      ],
      cardCompanyName: '신한카드',
      contractPrice: '100,000',
      paymentCompletionLimitDate: '2021년 1월 20일 10시 55분',
      receiptsBankName: '신한은행',
      virtualAccount: '90025222042',
      depositor: '김현대',
      paymentPrice: '100,000',
      paymentCompleteBtn: false,
      popVisible: {
        accountNumberSms: false
      }
    }
  },
  computed: {
    //2021.04.08(ver1.2) 마침표추가
    rules() {
      return {
        cardNumber: [
          {
            required: true,
            message: '* 카드번호를 입력해 주세요.',
            trigger: 'blur'
          }
        ],
        datelimit: [
          {
            required: true,
            message: '* 유효기간을 입력해 주세요.',
            trigger: 'blur'
          }
        ]
      }
    }
  },
  mounted() {
    console.log(this.type)
    this.setLabel((idg) => {
      // console.dir(idg) // 자동 생성된 ID 배열
    })
  },
  methods: {
    methodChange(val) {
      this.tabStatus = val.value
    }
  }
}
</script>
