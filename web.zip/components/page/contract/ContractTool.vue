<!-- 2021.04.13 삭제 -->
<template>
  <section id="scrollCurrent" class="purchase-tool">
    <div class="car-img">
      <v-img :src="carImg.src" :alt="carImg.alt"></v-img>
      <v-btn class="btn-3d" type="icon" icon-class="icon-3d" @click="popConfig = true"><span class="offscreen">3D configurator 보기</span></v-btn>
    </div>

    <div>
      <ul class="flag-list tooltip">
        <li v-if="type === '1'">
          <em>생산주문차</em>
          <v-popover trigger="hover" placement="bottom-start">
            <p>고객님이 원하는 사양으로 주문 생산되는<br />차량입니다. 생산 완료 시까지 일정 기간이<br />소요되며, 생산 완료 후 결제 안내를 위한<br />연락을 별도로 드립니다.</p>
            <v-btn slot="reference"><i class="icon-help"></i></v-btn>
          </v-popover>
        </li>
        <li v-else-if="type === '2'">
          <em>즉시출고차</em>
          <v-popover trigger="hover" placement="bottom-start">
            <p>고객님이 원하는 차량의 재고가 확인되어 계약<br />완료 후 바로 결제가 가능하고 출고가 진행될<br />수 있는 차량입니다.</p>
            <v-btn slot="reference"><i class="icon-help"></i></v-btn>
          </v-popover>
        </li>
        <li v-else-if="type === '3'">
          <em>특별주문차</em>
          <v-popover trigger="hover" placement="bottom-start">
            <p>고객님이 특별히 원하는 사양으로 특별 주문<br />생산되는 차량으로 생산 이후 취소 및 환불이<br />불가합니다. 취소 시 위약금이 발생할 수<br />있으니 반드시 확인 후 계약을 진행해 주시기<br />바랍니다.</p>
            <v-btn slot="reference"><i class="icon-help"></i></v-btn>
          </v-popover>
        </li>
        <li v-else-if="type === '4'">
          <em>할인재고차</em>
          <v-popover trigger="hover" placement="bottom-start">
            <p>할인이 가능한 차량입니다. 일부 차량의 경우<br />차량 보관장소로 직접 방문하여 인수해야 하오니<br />인수방법을 반드시 확인해 주시기 바랍니다.</p>
            <v-btn slot="reference"><i class="icon-help"></i></v-btn>
          </v-popover>
        </li>
        <li v-else-if="type === '5'">
          <em>전시차</em>
          <v-popover trigger="hover" placement="bottom-start">
            <p>할인이 가능한 차량입니다. 일부 차량의 경우<br />차량 보관장소로 직접 방문하여 인수해야 하오니<br />인수방법을 반드시 확인해 주시기 바랍니다.</p>
            <v-btn slot="reference"><i class="icon-help"></i></v-btn>
          </v-popover>
        </li>
        <li v-else-if="type === '6'">
          <em>판촉차(즉시출고)</em>
          <v-popover trigger="hover" placement="bottom-start">
            <p>정해진 계약 기간 내 계약 완료 하셔야 합니다.<br />계약기간 확인 후 기간 내 계약 완료 바랍니다. <br />또한, 상품보관장소로 직접 방문인수 하셔야<br />하오니 차량 인수지를 반드시 확인하시기<br />바랍니다.</p>
            <v-btn slot="reference"><i class="icon-help"></i></v-btn>
          </v-popover>
        </li>
        <li v-else-if="type === '7'">
          <em>신차사전계약</em>
          <v-popover trigger="hover" placement="bottom-start">
            <p>사전계약차량&#38;생산주문자<br />생산주문차 설명글 노출</p>
            <p>사전계약차량&#38;즉시출고차<br />즉시출고차 설명글 노출</p>
            <p>사전계약차량&#38;특별주문차<br />특별주문차 설명글 노출</p>
            <v-btn slot="reference"><i class="icon-help"></i></v-btn>
          </v-popover>
        </li>
      </ul>
      <h1>AX 스마트스트림 가솔린 1.1 터보 프리미엄 밀레니얼 A/T</h1>
      <div class="info-grid-list">
        <ul class="color-list">
          <li>코스믹 그레이</li>
          <li>블랙 모노톤</li>
        </ul>
        <ul>
          <li>
            <strong class="info-title">판매스펙</strong>
            <div class="info-group">ADSJ4RGT3AB5</div>
          </li>
          <li>
            <strong class="info-title">생산년월</strong>
            <div class="info-group">2021-02-07</div>
          </li>
          <li>
            <strong class="info-title">생산번호</strong>
            <div class="info-group">F2F766261</div>
          </li>
          <li>
            <strong class="info-title full">선택품목</strong>
            <div class="info-group full">
              <ul class="desc-list">
                <li v-for="(select, index) in selectData" :key="index">
                  {{ select.selectName }}
                </li>
              </ul>
            </div>
          </li>
          <!-- 2021.03.23 (ver1.3) 삭제 -->
          <!-- <li>
            <div class="info-title full">
              <strong>기본품목</strong>
              <v-btn class="btn btn-detail" type="icon" :icon-class="['icon-open-arrow', { active: isDetailShow }]" @click="isDetailShow = !isDetailShow"><span class="offscreen">상세보기</span></v-btn>
            </div>
            <div class="info-group full">
              <ul v-show="isDetailShow" class="desc-list">
                <li v-for="(basic, index) in basicData" :key="index">
                  {{ basic.basicName }}
                </li>
              </ul>
            </div>
          </li> -->
          <li>
            <div class="info-title full">
              <strong>H Genuine Accessories</strong>
              <v-btn class="btn btn-detail" type="icon" :icon-class="['icon-open-arrow', { active: isDetailShow2 }]" @click="isDetailShow2 = !isDetailShow2"><span class="offscreen">상세보기</span></v-btn>
            </div>
            <div class="info-group full">
              <ul v-show="isDetailShow2" class="desc-list">
                <li v-for="(accessory, index) in accessoryData" :key="index">
                  {{ accessory.accessoryName }}
                </li>
              </ul>
            </div>
          </li>
          <li>
            <div class="info-title full">
              <strong>N Performance</strong>
              <v-btn class="btn btn-detail" type="icon" :icon-class="['icon-open-arrow', { active: isDetailShow3 }]" @click="isDetailShow3 = !isDetailShow3"><span class="offscreen">상세보기</span></v-btn>
            </div>
            <div class="info-group full">
              <ul v-show="isDetailShow3" class="desc-list">
                <li v-for="(performance, index) in performanceData" :key="index">
                  {{ performance.performanceName }}
                </li>
              </ul>
            </div>
          </li>
          <li>
            <strong class="info-title full">할인사유</strong>
            <div class="info-group full">
              <ul class="desc-list line">
                <li>등록환입</li>
                <li>엔진, 변속기, ECM 교환</li>
              </ul>
            </div>
          </li>
          <li>
            <strong class="info-title full">주행거리</strong>
            <div class="info-group full">
              <ul class="desc-list">
                <li>383km</li>
              </ul>
            </div>
          </li>
          <!-- 2021.03.23 (ver1.3) 삭제 -->
          <!-- <li>
            <strong class="info-title full">차량상태</strong>
            <div class="info-group full">
              <ul class="desc-list">
                <li v-for="(state, index) in stateData" :key="index">
                  {{ state.stateName }}
                </li>
              </ul>
            </div>
          </li> -->
          <li class="total-price">
            <strong class="info-title bold">차량 가격</strong>
            <div class="info-group">
              <strong class="price bold">33,300,000</strong> 원
            </div>
          </li>
        </ul>
      </div>
    </div>

    <!-- 2021.03.31 (ver1.5) 삭제 -->
    <!-- <div class="btn-wrap">
      <v-btn class="btn md blue line r">간편 할부계산기</v-btn>
    </div> -->
    <!-- 2021.03.31 (ver1.5) 삭제 -->
    <!-- <p class="bullet-star">간편 할부계산기로 나에게 맞는 금융상품을 찾아보세요.</p> -->
  </section>
</template>

<script>
export default {
  components: {
  },
  props: {
    type: {
      type: String,
      default: () => '1'
    }
  },
  data() {
    return {

      carImg: {
        src: require('~/assets/images/temp/temp-payment-car-model.png'),
        alt: 'AX 스마트스트림 가솔린 1.1 터보 프리미엄 밀레니얼 A/T',
      },

      isDetailShow: false,
      isDetailShow2: false,
      isDetailShow3: false,


      selectData: [
        { selectName: '인조가죽시트' },
        { selectName: '인포테인먼트 내비' },
        { selectName: '익스테리어 디자인' },
      ],
      basicData: [
        { basicName: 'ISG 시스템' },
        { basicName: '통합 주행모드' },
        { basicName: '스마트스트림 디젤 2.2 엔진' },
        { basicName: '스마트스트림 습식 8단 DCT' },
        { basicName: '전자식 변속버튼' },
        { basicName: '전동식 파워 스티어링 (R-MDPS)' },
      ],
      accessoryData: [
        { accessoryName: '1열 방오 시트 커버 + 2열 방오 커버' },
        { accessoryName: 'ISOFIX 카시트' },
        { accessoryName: '하네스 ISOFIX 안전벨트 테더' },
      ],
      performanceData: [
        { performanceName: '인테리어 패키지' },
      ],
      stateData: [
        { stateName: '본네트 교환' },
        { stateName: '앞펜더 : 우 교환' },
        { stateName: '실내/시트 오염' },
        { stateName: '바닥 낙진 및 스크레치' },
      ],
    }
  },
}
</script>