<template>
  <button class="float">
    <!-- <img src="~static/images/pages/contract/icon-price.png" /> -->
    <span>구매금액 예상하기</span>
    <!-- <img src="~static/images/icon-page-next-ative.png" /> -->
  </button>
</template>
<script>
export default {
  data() {
    return {}
  }
}
</script>
