<template>
  <!-- 2021.04.13 (ver1.6) 디자인 변경으로인한 전체적인 수정 -->
  <div class="gauge">
    <div class="gauge-info">
      <span class="text">서명 완료 기한</span>
      <v-popover trigger="hover" placement="bottom-start">
        <p>
          완료 기한 내 전자서명까지 완료하셔야 계약이 완료됩니다. 기한 내 계약금 결제 및 전자서명 미완료 시 계약은 자동 취소 됩니다.
        </p>
        <v-btn slot="reference"><i class="icon-help"></i></v-btn>
      </v-popover>
      <div class="date"><span v-html="remainDate"></span> 남음</div>
    </div>
  </div>
</template>

<script>
export default {
  components: {
  },
  props: {
    type: {
      type: String,
      default: ''
    },
  },
  data() {
    return {
      remainDate: '1일 2시간 36분',
    }
  },
}
</script>
