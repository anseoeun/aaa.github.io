<template>

  <!-- 2021.04.13 (ver1.6) 디자인 변경으로인한 전체적인 수정 -->
  <div class="contract-step-info">
    <!-- 4 step -->
    <ol v-if="contractType">
      <li :class="{ active: index === '1' }">
        <strong class="step-num">1단계</strong>
        <p class="step-title">개인정보 수집·이용, 제공 및 구매 동의</p>
        <p class="step-explain">이제 계약을 진행하여 볼까요?<br />어렵지 않습니다.</p>
      </li>
      <li :class="{ active: index === '2' }">
        <strong class="step-num">2단계</strong>
        <p class="step-title">계약 기본 정보</p>
        <p class="step-explain">기본 정보를 입력해 주세요,<br />명의자를 정하는 단계입니다.</p>
      </li>
      <li :class="{ active: index === '3' }">
        <strong class="step-num">3단계</strong>
        <p class="step-title">계약금 결제</p>
        <p class="step-explain">계약금을 결제합니다.<br />이제 거의 다 끝났습니다.</p>
      </li>
      <li :class="{ active: index === '4' }">
        <strong class="step-num">4단계</strong>
        <p class="step-title">전자 서명 및 계약 완료</p>
        <p class="step-explain">모든 과정이 완료되었습니다.<br />전자서명을 하시면 계약이 완료됩니다.</p>
      </li>
    </ol>
    <!-- 3 step -->
    <ol v-else>
      <li :class="{ active: index === '1' }">
        <strong class="step-num">1단계</strong>
        <p class="step-title">개인정보 수집·이용, 제공 및 구매 동의</p>
        <p class="step-explain">이제 계약을 진행하여 볼까요?<br />어렵지 않습니다.</p>
      </li>
      <li :class="{ active: index === '2' }">
        <strong class="step-num">2단계</strong>
        <p class="step-title">계약 기본 정보</p>
        <p class="step-explain">기본 정보를 입력해 주세요,<br />명의자를 정하는 단계입니다.</p>
      </li>
      <li :class="{ active: index === '3' }">
        <strong class="step-num">3단계</strong>
        <p class="step-title">전자 서명 및 계약 완료</p>
        <p class="step-explain">모든 과정이 완료되었습니다.<br />전자서명을 하시면 계약이 완료됩니다.</p>
      </li>
    </ol>
  </div>
</template>

<script>
export default {
  components: {
  },
  props: {
    index: {
      type: String,
      default: ''
    }
  },
  data() {
    return {
      contractType: true,
    }
  }
}
</script>
