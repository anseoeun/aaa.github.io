<template>
  <ol class="step">
    <li class="step-list" :class="{ active: activeIndex === '0' }">
      <span class="step-label">
        계약신청완료 및<br />
        예상출고일 확인
      </span>
    </li>
    <li class="step-list" :class="{ active: activeIndex === '1' }">
      <span class="step-label">
        계약서 작성 및 계약금 입금
      </span>
      <span class="step-info">계약금은 차량에 따라 생략 가능</span>
    </li>
    <li class="step-list" :class="{ active: activeIndex === '2' }">
      <span class="step-label">차량 할인 및 대금 결제</span>
    </li>
    <li class="step-list" :class="{ active: activeIndex === '3' }">
      <span class="step-label">차량 출고/배송</span>
    </li>
  </ol>
</template>
<script>
export default {
  props: {
    activeIndex: {
      type: String,
      default: '0'
    }
  },
  data() {
    return {}
  }
}
</script>
<style lang="scss" scoped>
@import '~/assets/style/page/contract/step/ContractDefaultStep';
</style>
