<template>
  <v-popup
    :visible="visible"
    :width="'550px'"
    :footer="['confirm']"
    @close="
      $emit('close')
      popVisible = false
    "
    @confirm="
      $emit('close')
      popVisible = false
    "
  >

    <template slot="header">
      <div class="title">렌터카 장기 혜택 안내</div>
    </template>
    <template slot="body">
      <div style="width: 100%; height: 400px; background-color: #f6f3f2;">상세내용수급후설계예정</div>
    </template>
  </v-popup>
</template>

<script>
import { VPopup } from '~/components/element'
export default {
  components: {
    VPopup
  },
  props: {
    visible: {
      type: Boolean,
      default: false
    },
  },
}
</script>