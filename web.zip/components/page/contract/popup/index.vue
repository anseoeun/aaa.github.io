<template>
  <div class="">

    <!-- 고유식별정보처리동의에관한사항 -->
    <terms-identification :pop-visible="visible" />

    <!-- 통신사이용약관동의 -->
    <terms-mobile-carrier :pop-visible="visible" />

    <!-- 개인정보수집및이용에관한사항 -->
    <terms-personal-info :pop-visible="visible" />


  </div>
</template>

<script>
import termsIdentification from '~/components/page/contract/popup/TermsIdentification'
import termsMobileCarrier from '~/components/page/contract/popup/TermsMobileCarrier'
import termsPersonalInfo from '~/components/page/contract/popup/TermsPersonalInfo'

export default {
  components: {
    termsIdentification,
    termsMobileCarrier,
    termsPersonalInfo,
  },
  props: {
    visible: {
      type: Object,
      defualt: {},
      required: true
    }
  },
  data() {
    return {}
  },
  methods: {
    parentsSync(e) {
      this.visible = e
      this.$emit('visibleSync', this.visible)
    }
  }
}
</script>
