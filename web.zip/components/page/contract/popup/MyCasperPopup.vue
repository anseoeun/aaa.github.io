<template>
  <v-popup
    :visible="visible"
    :width="'776px'"
    @close="
      $emit('close')
      popVisible = false
    "
    @confirm="
      $emit('close')
      popVisible = false
    "
  >

    <template slot="header">
      <div class="title">나만의 캐스퍼</div>
    </template>
    <template slot="body">
      <div class="info-grid-list contract-info">
        <ul>
          <li class="car-info">
            <div class="info-title">
              <div class="car-img"><v-img :src="carImg.src" :alt="carImg.alt"></v-img></div>
            </div>
            <div class="info-group">
              <ul class="flag-list tooltip">
                <li v-if="type === '1'">
                  <em>생산주문차</em>
                  <v-popover trigger="hover" placement="bottom-start">
                    <p>고객님이 원하는 사양으로 주문 생산되는<br />차량입니다. 생산 완료 시까지 일정 기간이<br />소요되며, 생산 완료 후 결제 안내를 위한<br />연락을 별도로 드립니다.</p>
                    <v-btn slot="reference"><i class="icon-help"></i></v-btn>
                  </v-popover>
                </li>
                <li v-else-if="type === '2'">
                  <em>즉시출고차</em>
                  <v-popover trigger="hover" placement="bottom-start">
                    <p>고객님이 원하는 차량의 재고가 확인되어 계약<br />완료 후 바로 결제가 가능하고 출고가 진행될<br />수 있는 차량입니다.</p>
                    <v-btn slot="reference"><i class="icon-help"></i></v-btn>
                  </v-popover>
                </li>
                <li v-else-if="type === '3'">
                  <em>특별주문차</em>
                  <v-popover trigger="hover" placement="bottom-start">
                    <p>고객님이 특별히 원하는 사양으로 특별 주문<br />생산되는 차량으로 생산 이후 취소 및 환불이<br />불가합니다. 취소 시 위약금이 발생할 수<br />있으니 반드시 확인 후 계약을 진행해 주시기<br />바랍니다.</p>
                    <v-btn slot="reference"><i class="icon-help"></i></v-btn>
                  </v-popover>
                </li>
                <li v-else-if="type === '4'">
                  <em>할인재고차</em>
                  <v-popover trigger="hover" placement="bottom-start">
                    <p>할인이 가능한 차량입니다. 일부 차량의 경우<br />차량 보관장소로 직접 방문하여 인수해야 하오니<br />인수방법을 반드시 확인해 주시기 바랍니다.</p>
                    <v-btn slot="reference"><i class="icon-help"></i></v-btn>
                  </v-popover>
                </li>
                <li v-else-if="type === '5'">
                  <em>전시차</em>
                  <v-popover trigger="hover" placement="bottom-start">
                    <p>할인이 가능한 차량입니다. 일부 차량의 경우<br />차량 보관장소로 직접 방문하여 인수해야 하오니<br />인수방법을 반드시 확인해 주시기 바랍니다.</p>
                    <v-btn slot="reference"><i class="icon-help"></i></v-btn>
                  </v-popover>
                </li>
                <li v-else-if="type === '6'">
                  <em>판촉차(즉시출고)</em>
                  <v-popover trigger="hover" placement="bottom-start">
                    <p>정해진 계약 기간 내 계약 완료 하셔야 합니다.<br />계약기간 확인 후 기간 내 계약 완료 바랍니다. <br />또한, 상품보관장소로 직접 방문인수 하셔야<br />하오니 차량 인수지를 반드시 확인하시기<br />바랍니다.</p>
                    <v-btn slot="reference"><i class="icon-help"></i></v-btn>
                  </v-popover>
                </li>
                <li v-else-if="type === '7'">
                  <em>신차사전계약</em>
                  <v-popover trigger="hover" placement="bottom-start">
                    <p>사전계약차량&#38;생산주문자<br />생산주문차 설명글 노출</p>
                    <p>사전계약차량&#38;즉시출고차<br />즉시출고차 설명글 노출</p>
                    <p>사전계약차량&#38;특별주문차<br />특별주문차 설명글 노출</p>
                    <v-btn slot="reference"><i class="icon-help"></i></v-btn>
                  </v-popover>
                </li>
              </ul>
              <div class="bold full">{{ carModel }}</div>
            </div>
          </li>
          <li>
            <strong class="info-title">색상</strong>
            <div class="info-group">
              <ul class="desc-list">
                <li>
                  <em>{{ outColor.txt }}</em>
                  <span class="price"><strong class="bold">{{ outColor.price }}</strong> 원</span>
                </li>
                <li>
                  <em>{{ inColor.txt }}</em>
                  <span class="price"><strong class="bold">{{ inColor.price }}</strong> 원</span>
                </li>
              </ul>
            </div>
          </li>
          <li>
            <div class="info-title">
              <strong>선택품목</strong>
              <v-btn class="btn-detail last" :class="{ on: isAct(0) }" @click="setAct(0)">
                <span class="offscreen">상세보기</span>
              </v-btn>
            </div>
            <div class="info-group tog">
              <ul class="desc-list" :class="{ on: isAct(0) }">
                <li v-for="(item, index) in optList" :key="index">{{ item.opt }} <span class="price"><strong class="bold">{{ item.price }}</strong> 원</span></li>
              </ul>
            </div>
          </li>
          <li>
            <div class="info-title">
              <strong>H Genuine Accessories</strong>
              <v-btn class="btn-detail last" :class="{ on: isAct(1) }" @click="setAct(1)">
                <span class="offscreen">상세보기</span>
              </v-btn>
            </div>
            <div class="info-group tog">
              <ul class="desc-list" :class="{ on: isAct(1) }">
                <li v-for="(item, index) in hgList" :key="index">{{ item.opt }} <span class="price"><strong class="bold">{{ item.price }}</strong> 원</span></li>
              </ul>
            </div>
          </li>
          <li>
            <div class="info-title">
              <strong>N Performance</strong>
              <v-btn class="btn-detail last" :class="{ on: isAct(2) }" @click="setAct(2)">
                <span class="offscreen">상세보기</span>
              </v-btn>
            </div>
            <div class="info-group tog">
              <ul class="desc-list" :class="{ on: isAct(2) }">
                <li v-for="(item, index) in npList" :key="index">{{ item.opt }} <span class="price"><strong class="bold">{{ item.price }}</strong> 원</span></li>
              </ul>
            </div>
          </li>
          <li>
            <strong class="info-title">할인사유</strong>
            <div class="info-group">
              <ul class="desc-list line">
                <li>등록환입</li>
                <li>엔진, 변속기, ECM 교환</li>
              </ul>
            </div>
          </li>
          <li>
            <strong class="info-title">주행거리</strong>
            <div class="info-group">383km</div>
          </li>
        </ul>
      </div>
      <div class="info-grid-list price-info">
        <ul>
          <li>
            <strong class="info-title">차량금액</strong>
            <div class="info-group"><span class="price"><strong class="bold">30,800,000</strong> 원</span></div>
          </li>
          <li>
            <strong class="info-title">탁송료</strong>
            <div class="info-group"><span class="price"><strong class="bold">200,000</strong> 원</span></div>
          </li>
          <li>
            <strong class="info-title">할인/포인트</strong>
            <div class="info-group"><span class="price"><strong class="bold t-blue">(-) 30,800,000</strong> 원</span></div>
          </li>
          <li>
            <strong class="info-title">세액 감면 혜택</strong>
            <div class="info-group"><span class="price"><strong class="bold t-blue">(-) 30,800,000</strong> 원</span></div>
          </li>
          <li class="total-price">
            <strong class="info-title bold t-blue">결제예정금액</strong>
            <div class="info-group"><span class="price t-blue"><strong class="ebold">30,800,000</strong> 원</span></div>
          </li>
        </ul>
      </div>
    </template>
    <template slot="footer">
      <div class="btn-group">
        <v-btn class="btn" b-size="btn-md">확인</v-btn>
      </div>
    </template>
  </v-popup>
</template>

<script>
import { VPopup } from '~/components/element'
export default {
  components: {
    VPopup
  },
  props: {
    visible: {
      type: Boolean,
      default: false
    },
    type: {
      type: String,
      default: () => '1'
    },
  },
  data(){
    return{
      carImg: {
        src: require('~/assets/images/temp/temp-contract-car-visual.png'),
        alt: 'AX 스마트스트림 가솔린 1.1 터보 프리미엄 밀레니얼 A/T'
      },
      carModel: 'AX 스마트스트림 가솔린 1.1 터보 프리미엄 밀레니얼 A/T',

      inColor: { txt: '메테오 블루',  price: '0' },
      outColor: { txt: '쉬머링 실버',  price: '100,000' },

      optList: [
        { opt: '인조가죽 시트(인조가죽 도어 센터트림 포함)', price: '100,000' },
        { opt: '인포테인먼트 내비 I', price: '100,000' },
        { opt: '익스테리어 디자인 I', price: '100,000' }
      ],
      hgList: [
        { opt: '1열 방오 시트 커버 + 2열 방오 커버', price: '100,000' },
        { opt: 'ISOFIX 카시트', price: '100,000' },
        { opt: '하네스 ISOFIX 안전벨트 테더', price: '100,000' }
      ],
      npList: [
        { opt: '인테리어 패키지', price: '100,000' },
        { opt: 'N 퍼포먼스 서스펜션', price: '100,000' }
      ],
      listSelected: [false, false, false]
    }
  },
  updated() {
    if (this.visible) {
      this.setCaption()
    }
  },
  methods: {
    setAct(index) {
      if (this.listSelected[index] === false) {
        this.$set(this.listSelected, index, true)
      } else {
        this.$set(this.listSelected, index, false)
      }
    },
    isAct(index) {
      return this.listSelected[index] === true
    }
  }
}
</script>