<template>
  <v-popup
    :visible="visible"
    :footer="['confirm']"
    :width="'550px'"
    @close="
      $emit('close')
      popVisible = false
    "
    @confirm="
      $emit('close')
      popVisible = false
    "
  >
    <template slot="header">
      <div class="title">개별소비세 면세 차량 구입 안내</div>
    </template>
    <template slot="body">
      <div class="body-contents">
        <p class="text-main t-gray">
          개별소비세 면세 차량의 재구입 년한은 5년입니다.<br />
          과거 구입이력을 반드시 확인해 주세요.<br />
          또한 보유기간이 5년 경과하였더라도<br />
          면세 혜택을 받으시려면 폐차하거나 명의 이전을 하시기 바랍니다.
        </p>
      </div>
    </template>
  </v-popup>
</template>

<script>
import { VPopup } from '~/components/element'
export default {
  components: {
    VPopup
  },
  props: {
    visible: {
      type: Boolean,
      default: false
    }
  }
}
</script>