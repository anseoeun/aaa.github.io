<template>
  <v-popup
    :visible="visible"
    :width="'776px'"
    :is-close="false"
  >
    <template slot="body">
      <div class="security-wait">
        <p class="text">카카오톡 메시지로 보안문서가 전송되었습니다.</p>
        <p class="sub-text"><span>메시지 확인 후, 바로 전자서명을 진행하신 다음, 아래 버튼을 클릭해 주세요.</span><br />카카오페이 전자문서 서명 완료 여부 확인에 최대 1분 정도의 시간이 소요될 수 있습니다.</p>
        <v-btn class="btn white md r">전자서명 완료</v-btn>
      </div>
    </template>
  </v-popup>
</template>

<script>
import { VPopup } from '~/components/element'
export default {
  components: {
    VPopup,
  },
  props: {
    visible: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {

    }
  },
}
</script>
