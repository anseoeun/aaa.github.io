<template>
  <v-popup
    :visible="visible"
    :width="'1000px'"
    @close="
      $emit('close')
      popVisible = false
    "
  >

    <template slot="header">
      <div class="title">직원 차량의무보유기간 준수 동의</div>
    </template>
    <template slot="body">
      <div class="agreement-check-list">
        <ul>
          <li>
            <v-checkbox :one-check="true" :checked.sync="agreement1">본인은 아래 표에 기재되어 있는 임직원용 차량 정보를 최종 확인합니다.</v-checkbox>
            <div class="info-grid-list">
              <ul>
                <li>
                  <div class="info-title">차종</div>
                  <div class="info-group">AX 자가용 5인승 가솔린 1..6 2WD IVT Smart</div>
                </li>
                <li>
                  <div class="info-title">차량가격</div>
                  <div class="info-group">10,000,000원</div>
                </li>
                <li>
                  <div class="info-title">직원용 할인액</div>
                  <div class="info-group">600,000원</div>
                </li>
              </ul>
            </div>
          </li>
          <li><v-checkbox :one-check="true" :checked.sync="agreement2">1항) 임직원 복지 차원에서 회사가 규정한대로 근속년수 및 직원용 타겟 조건에 따른 할인을 받아 차량을 구입한 임직원은 본인(배우자 포함) 명의로 차량등록을 하여야 하며, 차량출고일로부터 2년 간 제3자에게 명의를 이전하지 않는다.<br /><br />예) 2017-02-15 출고, 2019-02-15부터 명의변경/매각/재출고 가능, 보유기간 종료일이 법정휴일인 경우 해당일에 이은 첫번째 평일부터 가능</v-checkbox></li>
          <li><v-checkbox :one-check="true" :checked.sync="agreement3">2항) 임직원의 개인사정으로 인해 출고일로부터 2년 내 부득이하게 차량을 타인 명의로 이전할 필요가 생긴 경우에는 사전에 회사에 서면 신고를 한 후 승인을 득하여야 하며, 사전신고를 한 임직원의 경우에는 직원용 할인액 중 잔여보유기간에 해당하는 비율만큼의 할인액을 현금 일시불로 회사에 반환하여야 한다.<br /><br />* 반환해야 할 할인액 = 직원용 할인액 x 잔여일수/730일(2년)</v-checkbox></li>
          <li><v-checkbox :one-check="true" :checked.sync="agreement4">3항) 본인명의로 차량등록 후 사전신고 없이 타인명의로 이전을 하거나, 미등록 상태에서 차량을 타인에게 전매한 경우에는 할인액 전액을 현금 일시불로 회사에 반납하여야 한다. (할인액의 반환과는 별도로 회사는 의무보유기간 지침을 위반한 임직원에 한해 징계를 할 수 있다.)</v-checkbox></li>
          <li><v-checkbox :one-check="true" :checked.sync="agreement5">4항) 제2항의 경우 사전 신고일 다음날로부터 그리고 제3항의 경우 의무보유기간 준수를 위반한 날로부터 할인액을 반환할 의무를 부담한다.</v-checkbox></li>
          <li><v-checkbox :one-check="true" :checked.sync="agreement6">5항) 별도의 약정이 없는 경우 지연 손해는 위 제4항의 각 날로부터 차량 매매계약 당시 계약서상의 지연손태배상규정이율에 의해 계산한다.</v-checkbox></li>
          <li><v-checkbox :one-check="true" :checked.sync="agreement7">6항) 기타 세부사항은 공지된 회사 임직원 차량 판매 지침에 따른다.</v-checkbox></li>
        </ul>
      </div>
    </template>
    <template slot="footer">
      <v-btn class="btn" b-size="btn-md">전체 동의</v-btn>
    </template>
  </v-popup>
</template>

<script>
import { VPopup, VCheckbox } from '~/components/element'
export default {
  components: {
    VPopup,
    VCheckbox
  },
  props: {
    visible: {
      type: Boolean,
      default: false
    },
  },
  data() {
    return {
      agreement1: false,
      agreement2: false,
      agreement3: false,
      agreement4: false,
      agreement5: false,
      agreement6: false,
      agreement7: false,
    }
  },
}
</script>