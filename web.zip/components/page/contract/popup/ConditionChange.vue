<template>
  <v-popup
    :visible="visible"
    :footer="['confirm']"
    :width="'550px'"
    @close="
      $emit('close')
      popVisible = false
    "
    @confirm="
      $emit('close')
      popVisible = false
    "
  >
    <template slot="header">
      <div class="title">할인조건 변경 안내</div>
      <p class="header-description">
        견적 진행 시 선택한 할인조건으로 <em>[일반법인]</em>은 할인 적용 불가합니다.<br />아래 변경 사항을 확인하고,
        할인조건을 다시 선택하세요.
      </p>
    </template>
    <template slot="body">
      <div class="body-contents">
        <p class="contents-head">변경 사항</p>
        <ul class="plan-info">
          <li>
            <p class="title">타겟조건할인명1</p>
            <p class="description t-blue">대상 아님</p>
          </li>
          <li>
            <p class="title">쿠폰명1</p>
            <p class="description t-blue">대상 아님</p>
          </li>
        </ul>
      </div>
    </template>
  </v-popup>
</template>

<script>
import { VPopup } from '~/components/element'
export default {
  components: {
    VPopup
  },
  props: {
    visible: {
      type: Boolean,
      default: false
    }
  }
}
</script>
