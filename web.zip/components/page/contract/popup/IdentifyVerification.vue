<template>
  <v-popup
    :visible="visible"
    :width="'550px'"
    @close="
      $emit('close')
      popVisible = false
    "
  >
    <template slot="header">
      <div class="title">본인 확인</div>
      <p class="header-description">아래 인증 수단 중 하나를 선택하고, 본인확인 절차를 인증해 주세요.</p>
    </template>
    <template slot="body">
      <div class="btn-wrap identification">
        <v-btn type="link" href="https://nice.checkplus.co.kr/CheckPlusSafeModel/checkplus.cb?m=auth_mobile_main" target="_blank" title="새창열림" class="btn md r black">휴대폰 인증</v-btn>
        <v-btn type="link" href="https://cert.vno.co.kr/IPIN/pubmain.cb" target="_blank" title="새창열림" class="btn md r black">신용카드 인증</v-btn>
        <v-btn type="link" href="" target="_blank" title="새창열림" class="btn md r black">I-PIN 인증</v-btn>
      </div>
    </template>
  </v-popup>
</template>

<script>
import { VPopup } from '~/components/element'
export default {
  components: {
    VPopup
  },
  props: {
    visible: {
      type: Boolean,
      default: false
    }
  },
}
</script>