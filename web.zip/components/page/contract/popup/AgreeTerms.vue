<template>
  <v-popup
    :visible="visible"
    :footer="['confirm']"
    :width="'550px'"
    @close="
      $emit('close')
      popVisible = false
    "
    @confirm="
      $emit('close')
      popVisible = false
    "
  >
    <template slot="header">
      <div class="title">개인정보 수집 &middot; 이용 동의</div>
    </template>
    <template slot="body">
      <ul class="body-contents">
        <li>
          <p class="contents-head">1. 개인정보 수집 &middot; 이용 목적</p>
          <ul class="bullet-list">
            <li>자동차 매매 계약상 의무이행을 위한 재화 &middot; 용역의 제공</li>
            <li>자동차 구매에 따른 탁송 &middot; 등록대행, 보증수리 및 차량관리(차량점검 &middot; 유지보수, 긴급출동 및 제작결함시정) 서비스 제공을 위한 본인 확인, 대금 청구서 발송 &middot; 대금 결제 &middot; 대금 추심을 위한 본인 확인, 분쟁 해결을 위한 기록 보존, 불만처리 등 민원 처리, 고지사항 전달, 서비스에 대한 만족도 조사</li>
          </ul>
        </li>
        <li>
          <p class="contents-head">2. 수집하는 개인정보항목</p>
          <ul class="bullet-list">
            <li>성명, 주민등록번호(외국인등록번호 또는 여권번호), 신분증 사본(사진), 상호, 사업자번호, 주소, 전화번호, 휴대폰번호, 이메일, 구입차량정보, 할부매매의 경우 '신용정보의 이용 및 보호에 관한 법률'상 개인신용정보</li>
          </ul>
        </li>
        <li>
          <p class="contents-head">3. 개인정보 보유 및 이용기간</p>
          <ul class="bullet-list">
            <li>현대자동차(주)는 상법 등 관련 법령의 규정에 의하여 보존할 의무가 있는 경우가 아닌 한, 개인정보의 수집 &middot; 이용에 관한 동의 목적을 달성할 때까지만 본인의 개인정보를 보유 &middot; 이용합니다.</li>
          </ul>
        </li>
        <li>
          <p class="contents-head">4. 개인정보(고유식별정보 포함) 수집 &middot; 이용 및 제공 미동의에 따른 불이익 사항</p>
          <ul class="bullet-list">
            <li>자동차 매매 계약을 거절할 수 있습니다.</li>
          </ul>
        </li>
      </ul>
    </template>
  </v-popup>
</template>

<script>
import { VPopup } from '~/components/element'
export default {
  components: {
    VPopup
  },
  props: {
    visible: {
      type: Boolean,
      default: false
    }
  },
}
</script>