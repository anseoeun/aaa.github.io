<template>
  <v-popup
    :visible="visible"
    :width="'1000px'"
    @close="
      $emit('close')
      popVisible = false
    "
  >
    <template slot="header">
      <div class="title">구매 동의</div>
    </template>
    <template slot="body">
      <div class="contract-agree-list">
        <v-carousel-new :items-to-show="1" :pagination="true" :navigation="true" :custom-item="6" :page-number="true">
          <template slot="slide1">
            <!-- slide1 : 자동차교환환불중재제도설명에대한이해및수락여부확인 -->
            <div>
              <p class="popup-sub-tit">자동차 교환 &middot; 환불 중재제도 설명에 대한 이해 및 수락여부 확인</p>
              <div class="agree-area">
                <ul class="body-contents">
                  <li>
                    <p class="contents-head">중재의 정의</p>
                    <ul class="body-description-list">
                      <li>"중재"는 분쟁 당사자들간의 합의로 그들의 분쟁을 중립적 사람(중재의원) 또는 중재부(중제관정부)의 결정(중재판정)에 의하여 해결하고 그 결정에 구속되는 부쟁해결절차를 말합니다.</li>
                    </ul>
                  </li>
                  <li>
                    <p class="contents-head">중재합의</p>
                    <ul class="body-description-list">
                      <li>① "중재합의"는 당사자 간에 이미 발생했거나 발생이 예상되는 분쟁의 전부 또는 일부를 중재에 의하여 해결하도록 하는 당사자 간의 합의를 말합니다.</li>
                      <li>② 자동차 교환 &middot; 환불 중재 규정(이하 "중재규정"이라 함)이 적용되는 중재합의는 양 당사자 모두가 자동차관리법 제 47조의 4 제1항에 따라 중재규정을 수락했을 때 성립합니다.</li>
                    </ul>
                  </li>
                  <li>
                    <p class="contents-head">중재합의의 성립과 효과</p>
                    <ul class="body-description-list">
                      <li>① 자동차관리법 제47조의 4 제1항에 따라 제작자가 사전에 중재규정을 수락하였고, 또한 동 제작자가 제작한 차량의 구매자가 매매계약을 체결할 때 또는 교환 &middot; 환불 중재를 신청할 때 중재규정을 수락한 경우, 자동차 교환 &middot; 환불 중재합의가 성립된 것으로 간주됩니다.</li>
                      <li>② 제1항에 따라 자동차 교환 &middot; 환불 중재합의가 성립되면 양 당사자는 동일한 내용의 교환 &middot; 환불을 이유로 법원에 소송을 제기할 수 없습니다.</li>
                      <li>③ 제1항에 따라 자동차 교환 &middot; 환불 중재합의가 성립되면 1985년 '외국중재판정의 승인 및 집행에 관한 뉴욕 협약' 제2조에 규정된 승인 및 집행의 요건으로서 중재에 대한 서면 합의 요건을 충족하는 것으로 봅니다.</li>
                    </ul>
                  </li>
                  <li>
                    <p class="contents-head">중재판정의 효력</p>
                    <ul class="body-description-list">
                      <li>중재판정은 제작자와 소유자에 대하여 법원의 확정판결과 동일한 효력이 있습니다.</li>
                    </ul>
                  </li>
                </ul>
              </div>
            </div>
          </template>
          <template slot="slide2">
            <!-- slide2 : 자동차교환환불중재제도설명에대한이해및수락여부확인 -->
            <div>
              <p class="popup-sub-tit">자동차 교환 &middot; 환불 중재제도 설명에 대한 이해 및 수락여부 확인</p>
              <div class="agree-area">
                <ul class="body-contents">
                  <li>
                    <p class="contents-head">자동차 교환 &middot; 환불 중재 규정을 수락한 사실</p>
                    <ul class="body-description-list">
                      <li>현대자동차는 자동차관리법 제47조 제1항 및 자동차관리법 제 47조의 7 제2항에 따른 자동차 안전 &middot; 하자심의위원회가 제정한 교환 &middot; 환불 중재 규정(이하 "중재규정"이라 칭함)을 수락하였음을 알려드립니다.</li>
                    </ul>
                  </li>
                  <li>
                    <p class="contents-head">신차로의 교환 &middot; 환불 보장</p>
                    <ul class="body-description-list">
                      <li>현대자동차는 자동차관리법 제 47조의 2 내지 6에 따른 자동차에 하자 발생 시 신차로의 교환 또는 환불을 보장하고, 서면계약의 특약 등으로 교환 &middot; 환불을 배제하지 않습니다.</li>
                    </ul>
                  </li>
                  <li>
                    <p class="contents-head">인도날짜</p>
                    <ul class="body-description-list">
                      <li>① 인도날짜는 자동차관리법 제47조의 2 제1항 제 1호에 따른 서면계약의 날짜로 하며, 중재규정 제2조 제8호에 따라 인도차량인수증 등을 통해 실제 인도를 증명할 수 있는 날짜 또는 제작사와 소유자가 합의하는 날짜로 갈음할 수 있습니다.</li>
                      <li>② 인도날짜는 자동차관리법 제47조의 2 자동차의 교환 또는 환불 요건의 소유자의 중재신청기한, 하자 재발 시점 및 누적수리기간 산정, 대상 자동차의 사용기간 등에 대한 기산 기준이 됩니다.</li>
                    </ul>
                  </li>
                  <li>
                    <p class="contents-head">통지방법</p>
                    <ul class="body-description-list">
                      <li>중재규정에 따른 통지 또는 그 밖의 연락은 수신인이 동의하는 경우 전자우편, 문자메시지, 팩스 기타 합리적인 방법에 의할 수 있습니다.</li>
                    </ul>
                  </li>
                </ul>
              </div>
            </div>
          </template>
          <template slot="slide3">
            <!-- slide3 : 특별주문차량구매동의 -->
            <div>
              <p class="popup-sub-tit">특별주문차량 구매 동의</p>
              <div class="agree-area">
                <ul class="body-contents">
                  <li>
                    <p class="contents-head">본인은 아래 표에 기재되어 있는 특별주문차량의 생산 요청을 최종 확인합니다.</p>
                    <div class="table-area">
                      <table>
                        <colgroup>
                          <col width="15%" />
                          <col width="auto" />
                          <col width="15%" />
                          <col width="auto" />
                        </colgroup>
                        <tbody>
                          <tr>
                            <th>차종</th>
                            <td class="t-left" colspan="3">AX 자가용 5인승 가솔린 1..6 2WD IVT Smart</td>
                          </tr>
                          <tr>
                            <th>계약일시</th>
                            <td class="t-left">2021년 1월 19일</td>
                            <th>주문요청일시</th>
                            <td class="t-left">2021년 1월 20일</td>
                          </tr>
                          <tr>
                            <th>외장칼라</th>
                            <td class="t-left">팬텀 블랙</td>
                            <th>내장칼라</th>
                            <td class="t-left">블랙 모노톤(블랙시트)</td>
                          </tr>
                          <tr>
                            <th>계약번호</th>
                            <td class="t-left" colspan="3">A3721CN00022</td>
                          </tr>
                          <tr>
                            <th>옵션</th>
                            <td class="t-left" colspan="3">
                              [선택 품목]<br />
                              개별 옵션 - 옵션 1, 옵션 2, 옵션3<br />
                              패키지 - 옵션 1, 옵션 2, 옵션3<br />
                              TUIX - 옵션 1, 옵션 2, 옵션3
                            </td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  </li>
                  <li>
                    <ul class="body-description-list">
                      <li>'전자상거래법 시행령 제21조'에 의거 상기 본인이 주문 요청한 특별주문생산 차량을 청약철회가 제한됨을 확인합니다.</li>
                    </ul>
                  </li>
                  <li>
                    <ul class="body-description-list">
                      <li>청약철회 제한에도 불구하고 본인은 계약을 해제할 수 있으며, '전자상거래법 제19조'에 의거 계약 해지 시 위약금 10만원이 발생됨을 확인합니다.</li>
                    </ul>
                  </li>
                  <li>
                    <ul class="body-description-list">
                      <li>본인이 이번 계약으로 납부한 계약금 10만원은 계약 해지 시 환불되지 않으며, 발생한 위약금 10만원으로 대체 납부한다는 사실을 확인합니다.</li>
                    </ul>
                  </li>
                </ul>
              </div>
            </div>
          </template>
          <template slot="slide4">
            <!-- slide4 : 판촉차량구매동의 -->
            <div>
              <p class="popup-sub-tit">판촉차량 구매 동의</p>
              <div class="agree-area">
                <ul class="body-contents">
                  <li>
                    <p class="contents-head">본인은 표에 기재되어 있는 현재 주요 문제 내역은 보증수리 불가함을 확인합니다.</p>
                    <div class="table-area">
                      <table>
                        <colgroup>
                          <col width="15%" />
                          <col width="auto" />
                          <col width="16%" />
                          <col width="auto" />
                        </colgroup>
                        <tbody>
                          <tr>
                            <th>차종</th>
                            <td class="t-left" colspan="3">AX 자가용 5인승 가솔린 1..6 2WD IVT Smart</td>
                          </tr>
                          <tr>
                            <th>차대번호</th>
                            <td class="t-left">KMHGR41EDKU321360</td>
                            <th>생산일자</th>
                            <td class="t-left">2021년 1월 20일</td>
                          </tr>
                          <tr>
                            <th>차량금액</th>
                            <td class="t-right">41,610,000원</td>
                            <th>판촉 할인금액</th>
                            <td class="t-right">22,000,000원</td>
                          </tr>
                          <tr>
                            <th>할인사유</th>
                            <td class="t-left" colspan="3">등록환입 | 엔진, 변속기, ECM 교환</td>
                          </tr>
                          <tr>
                            <th>현 주요문제</th>
                            <td class="t-left" colspan="3">
                              본네트 교환<br />
                              앞펜더: 우 교환<br />
                              실내/시트 오염<br />
                              바닥 낙진 및 스크래치<br />
                              엔진 교환 및 LH FRT BRP 긁힘
                            </td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  </li>
                  <li>
                    <ul class="body-description-list">
                      <li>본인은 귀사의 차량 판매가격에서 &#8361;0,000,000원을 할인(판매가격의 11.5%)받아 기재된 현재 주요문제 내역을 귀사로부터 매수할 당시 귀사와 본인이 인정하여 상호 합의한 문제부위에 대해서는 귀사의 약관 제 7조에서 정한 보증수리 책임을 청구하지 않음은 물론, 동 약관 각 조항에서 정한 귀사의 하자담보 책임과 관련한 일체 민 &middot; 형사상의 항변권을 포기할 것을 동의합니다.</li>
                    </ul>
                  </li>
                  <li>
                    <ul class="body-description-list">
                      <li>상기 차량을 제 3자에게 양도하는 경우 문제내역 고지 및 해당 문제에 대한 보증수리가 불가함을 통지할 의무가 있으며, 이러한 의무를 해태하여 귀사가 손해를 입는 경우 일체 손해를 배상하도록 하겠습니다.</li>
                    </ul>
                  </li>
                </ul>
              </div>
            </div>
          </template>
          <template slot="slide5">
            <!-- slide5 : 전시차량구매동의 -->
            <div>
              <p class="popup-sub-tit">전시차량 구매 동의</p>
              <div class="agree-area">
                <ul class="body-contents">
                  <li>
                    <p class="contents-head">아래 명시된 차량은 [강남대로] 지점 전시 차량임을 확인합니다.</p>
                    <div class="table-area">
                      <table>
                        <colgroup>
                          <col width="15%" />
                          <col width="auto" />
                          <col width="16%" />
                          <col width="auto" />
                        </colgroup>
                        <tbody>
                          <tr>
                            <th>차종</th>
                            <td class="t-left" colspan="3">AX 자가용 5인승 가솔린 1..6 2WD IVT Smart</td>
                          </tr>
                          <tr>
                            <th>차대번호</th>
                            <td class="t-left">KMHGR41EDKU321360</td>
                            <th>생산일자</th>
                            <td class="t-left">2021년 1월 20일</td>
                          </tr>
                          <tr>
                            <th>차량상태</th>
                            <td class="t-left" colspan="3">
                              바닥 낙진 및 스크래치
                            </td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  </li>
                  <li>
                    <ul class="body-description-list">
                      <li>본인은 귀사의 전시차량의 상태 및 특이사항에 대하여 충분히 숙지하고 확인하였습니다.</li>
                    </ul>
                  </li>
                </ul>
              </div>
            </div>
          </template>
          <template slot="slide6">
            <!-- slide6 : 직원차량의무보유기간준수동의 -->
            <div>
              <p class="popup-sub-tit">직원 차량의무보유기간 준수 동의</p>
              <div class="agree-area">
                <ul class="body-contents">
                  <li>
                    <p class="contents-head">본인은 아래 표에 기재되어 있는 직원용 차량 정보를 최종 확인합니다.</p>
                    <div class="table-area">
                      <table>
                        <colgroup>
                          <col width="15%" />
                          <col width="auto" />
                          <col width="16%" />
                          <col width="auto" />
                        </colgroup>
                        <tbody>
                          <tr>
                            <th>차종</th>
                            <td class="t-left" colspan="3">AX 자가용 5인승 가솔린 1..6 2WD IVT Smart</td>
                          </tr>
                          <tr>
                            <th>차량가격</th>
                            <td class="t-right">00,000,000원</td>
                            <th>직원용 할인액</th>
                            <td class="t-right">000,000원</td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  </li>
                  <li>
                    <ul class="body-description-list">
                      <li>1) 직원 복지 차원에서 회사가 규정한대로 근속년수 및 직원용 타겟 조건에 따른 할인을 받아 차량을 구입한 직원은 본인(배우자 포함) 명의로 차량등록을 하여야 하며, 차량출고일로부터 2년 간 제3자에게 명의를 이전하지 않는다.<br />예) 2017-02-15 출고, 2019-02-15부터 명의변경/매각/재출고 가능, 보유기간 종료일이 법정류일인 경우 해당일에 이은 첫번째 평일부터 가능</li>
                    </ul>
                  </li>
                  <li>
                    <ul class="body-description-list">
                      <li>2) 직원의 개인사정으로 인해 출고일로부터 2년 내 부득이하게 차량을 타인 명의로 이전할 필요가 생긴 경우에는 사전에 회사에 서면 신고를 한 후 승인을 득하여야 하며, 사전신고를 한 임직원의 경우에는 직원용 할인액 중 잔여보유기간에 해당하는 비율만큼의 할인액을 현금 일시불로 회사에 반환하여야 한다.</li>
                      <li class="bullet-star">반환해야 할 할인액 = 직원용 할인액×잔여일수/730일(2년)</li>
                    </ul>
                  </li>
                  <li>
                    <ul class="body-description-list">
                      <li>3) 본인 명의로 차량등록 후 사전신고 없이 타인명의로 이전하거나, 미등록 상태에서 차량을 타인에게 전매한 경우에는 할인액 전액을 현금 일시불로 회사에 반납하여야 한다. (할인액의 반환과는 별도로 회사는 의무보유기간 지침을 위한반 임직원에게 한해 징계를 할 수 있다.)</li>
                    </ul>
                  </li>
                  <li>
                    <ul class="body-description-list">
                      <li>4) 제2항의 경우 사전 신고일 다음날로부터 그리고 제3항의 경우 의무보유기간 준수를 위반한 날로부터 할인액을 변환할 의무를 부담한다.</li>
                    </ul>
                  </li>
                  <li>
                    <ul class="body-description-list">
                      <li>5) 별도의 약정이 없는 경우 지연 손해는 위 제4항의 각 날로부터 챠량 매매계약 당시 계약서상의 지연손해배상규정이율에 의해 계산한다.</li>
                    </ul>
                  </li>
                  <li>
                    <ul class="body-description-list">
                      <li>6) 기타 세부사항은 공지된 회사 임직원 차량 판매 지침에 따른다.</li>
                    </ul>
                  </li>
                </ul>
              </div>
            </div>
          </template>
        </v-carousel-new>
        <v-btn class="btn btn-md" b-size="btn-md" @click="$emit('close')">확인</v-btn>
      </div>
    </template>
  </v-popup>
</template>

<script>
import { VPopup } from '~/components/element'
export default {
  components: {
    VPopup,
  },
  props: {
    visible: {
      type: Boolean,
      default: false
    },
  },
  updated() {
    this.setCaption()
    this.setLabel((idg) => {
      // console.dir(idg) // 자동 생성된 ID 배열
    })
  }
}
</script>