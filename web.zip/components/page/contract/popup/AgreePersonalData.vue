<template>
  <v-popup
    :visible="visible"
    :width="'1000px'"
    @close="
      $emit('close')
      popVisible = false
    "
  >
    <template slot="header">
      <div class="title">개인정보 수집 &middot; 이용 제공 동의</div>
    </template>
    <template slot="body">
      <div class="contract-agree-list">
        <v-carousel-new :items-to-show="1" :pagination="true" :navigation="true" :custom-item="7" :page-number="true">
          <!-- slide1 : 필수적개인정보수집이용에대한사항 -->
          <template slot="slide1">
            <strong class="popup-sub-tit">필수적 개인정보 수집 &middot; 이용에 대한 사항</strong>
            <div class="agree-area">
              <ul class="body-contents">
                <li>
                  <p class="contents-head">개인정보 수집 &middot; 이용 목적</p>
                  <ul class="body-description-list">
                    <li>1. 자동차 매매 계약상 의무이행을 위한 재화 &middot; 용역의 제공</li>
                    <li>
                      2. 자동차 구매에 따른 탁송 &middot; 등록대행, 보증수리 및 차량관리(차량점검 &middot; 유지보수,
                      긴급출동 및 제작결함시정) 서비스 제공을 위한 본인 확인, 대금 청구서 발송 &middot; 대금 결제 &middot;
                      대금 추심을 위한 본인 확인, 분쟁 해결을 위한 기록 보존, 불만처리 등 민원 처리, 고지사항 전달,
                      서비스에 대한 만족도 조사
                    </li>
                  </ul>
                </li>
                <li>
                  <p class="contents-head">수집하는 개인정보항목</p>
                  <ul class="body-description-list">
                    <li>
                      성명, 주민등록번호(외국인등록번호 또는 여권번호), 신분증 사본(사진), 상호, 사업자번호, 주소,
                      전화번호, 휴대폰번호, 이메일, 구입차량정보, 할부매매의 경우 '신용정보의 이용 및 보호에 관한 법률'상
                      개인신용정보
                    </li>
                    <li class="bullet-star">
                      주민등록번호의 경우 세금계산서 발행, 주민등록 등 법정이 허용한 범위 내에서 해당 목적을 위해서만
                      수집합니다.
                    </li>
                  </ul>
                </li>
                <li>
                  <p class="contents-head">개인정보 보유 및 이용기간</p>
                  <ul class="body-description-list">
                    <li>
                      관련 법령의 규정에 의하여 보존할 의무가 있는 경우가 아닌 한, 개인정보의 수집 &middot; 이용에 관한
                      동의 목적을 달성할 때까지만 본인의 개인정보를 보유 &middot; 이용합니다.
                    </li>
                  </ul>
                </li>
                <li>
                  <p class="contents-head">
                    개인정보(고유식별정보 포함) 수집 &middot; 이용 및 제공 미동의에 따른 불이익 사항
                  </p>
                  <ul class="body-description-list">
                    <li>자동차 매매 계약을 거절할 수 있습니다.</li>
                  </ul>
                </li>
              </ul>
            </div>
          </template>
          <!-- slide2 : 필수적개인정보제3자제공에대한사항 -->
          <template slot="slide2">
            <strong class="popup-sub-tit">필수적 개인정보 제3자 제공에 대한 사항</strong>
            <div class="agree-area">
              <ul class="body-contents">
                <li>
                  <p class="contents-head">제공대상</p>
                  <ul class="body-description-list">
                    <li>1. 신용정보회사(NICE 신용평가정보(주)), 국토교통부</li>
                    <li>2. 현대해상화재보험(주)</li>
                    <li>3. 한국도로공사</li>
                  </ul>
                </li>
                <li>
                  <p class="contents-head">제공정보 이용목적</p>
                  <ul class="body-description-list">
                    <li>할부거래 이용자의 신용판단 및 본인확인, 자동차 신규등록 관련 서비스 제공</li>
                    <li>임시운행차량 의무보험 가입</li>
                    <li>하이패스 등록 서비스 제공</li>
                  </ul>
                </li>
                <li>
                  <p class="contents-head">제공하는 개인정보 항목</p>
                  <ul class="body-description-list">
                    <li>1. 성명, 주민등록번호, 상호, 사업자번호, 주소, 연락처, 휴대폰번호, 이메일, 구입차량정보</li>
                    <li>2. 성명, 주민등록번호, 상호, 사업자번호, 구입차량정보</li>
                    <li>3. 성명, 상호, 연락처, 휴대폰번호, 차량정보</li>
                  </ul>
                </li>
                <li>
                  <p class="contents-head">보유 및 이용기한</p>
                  <ul class="body-description-list">
                    <li>이용목적 달성 후 즉시 폐기</li>
                  </ul>
                </li>
                <li>
                  <p class="contents-head">미동의에 따른 불이익 사항</p>
                  <ul class="body-description-list">
                    <li>1. 자동차 매매 계약을 거절할 수 있으며, 신규등록 관련 서비스 제공을 할 수 없습니다.</li>
                    <li>2. 임시운행 의무보험에 가입할 수 없습니다.</li>
                    <li>3. 하이패스 서비스 제공을 할 수 없습니다.</li>
                  </ul>
                </li>
              </ul>
            </div>
          </template>
          <!-- slide3 : 한국도로공사-개인정보수집이용에대한사항 -->
          <template slot="slide3">
            <strong class="popup-sub-tit">한국도로공사-개인정보 수집 &middot; 이용에 대한 사항</strong>
            <div class="agree-area">
              <ul class="body-contents">
                <li>
                  <p class="contents-head">항목</p>
                  <ul class="body-description-list">
                    <li>1. 신청자 기본정보</li>
                    <li>2. 하이패스 이용정보</li>
                    <li>3. 하이패스 위반(에러) 정보</li>
                  </ul>
                </li>
                <li>
                  <p class="contents-head">수집 &middot; 이용하는 목적</p>
                  <ul class="body-description-list">
                    <li>1. 단말기 사후 관리</li>
                    <li>2. 통행료 정산, 교통정보 제공, 고객응대(민원해소) 및 이를 위한 서비스 향상</li>
                    <li>3. 단말기 사후 관리(A/S)</li>
                  </ul>
                </li>
                <li>
                  <p class="contents-head">수집 &middot; 이용하는 개인정보 항목</p>
                  <ul class="body-description-list">
                    <li>1. 성명, 휴대폰번호, 차명(차종), 차량번호</li>
                    <li>2. 통행일시, 진출입 요금소 요금, 단말기 번호, 하이패스 카드번호</li>
                    <li>3. 위반(에러) 발생정보: 통행일시, 진출입 요금소, 에러 유형, 회원 성명, 휴대폰번호, 차량번호</li>
                  </ul>
                </li>
                <li>
                  <p class="contents-head">개인정보 보유 및 이용기간</p>
                  <ul class="body-description-list">
                    <li>1. 단말기 해지 또는 명의변경 후 6개월</li>
                    <li>
                      2. 3년(전자금융거래법 시행령 제 12조)
                      <p class="bullet-star">개인정보 보유 및 이용기간 예외</p>
                      <ul>
                        <li>① 통행료를 납부하지 않은 경우 납부 완료시 까지</li>
                        <li>② 통행료 관련 분쟁이 발생한 경우 분쟁 완료시 까지</li>
                        <li>③ 다른 법령 또는 당사자의 합의에 따라 보유할 필요가 있는 경우</li>
                      </ul>
                    </li>
                    <li>3. 에러(위반)에 대한 사후관리(A/S) 목적 달성시 까지</li>
                  </ul>
                </li>
                <li>
                  <p class="contents-head">미동의에 따른 불이익 사항</p>
                  <ul class="body-description-list">
                    <li>
                      개인정보 수집 &middot; 이용에 관한 동의는 거부할 수 있으며, 거부할 경우 하이패스 차량 단말기 등록 및
                      서비스 이용을 할 수 없습니다.
                    </li>
                  </ul>
                </li>
              </ul>
            </div>
          </template>
          <!-- slide4 : 한국도로공사-필수적개인정보제3자제공조회에대한사항 -->
          <template slot="slide4">
            <strong class="popup-sub-tit">한국도로공사-필수적 개인정보 제3자 제공 조회에 대한 사항</strong>
            <div class="agree-area">
              <ul class="body-contents">
                <li>
                  <p class="contents-head">항목</p>
                  <ul class="body-description-list">
                    <li>1. 신청자 기본정보</li>
                    <li>2. 하이패스 이용정보</li>
                  </ul>
                </li>
                <li>
                  <p class="contents-head">제공 대상</p>
                  <ul class="body-description-list">
                    <li>통행료 정산 또는 통행료 수납업무의 위 &middot; 수탁 계약에 따른 연게유료도로 운영자</li>
                  </ul>
                </li>
                <li>
                  <p class="contents-head">수집 &middot; 이용하는 목적</p>
                  <ul class="body-description-list">
                    <li>통행일시, 진출입 요금소 요금, 단말기 번호, 하이패스 카드번호</li>
                  </ul>
                </li>
                <li>
                  <p class="contents-head">개인정보 보유 및 이용기간</p>
                  <ul class="body-description-list">
                    <li>1. 단말기 해지 또는 명의변경 후 6개월</li>
                    <li>
                      2. 3년(전자금융거래법 시행령 제 12조)
                      <p class="bullet-star">개인정보 보유 및 이용기간 예외</p>
                      <ul>
                        <li>① 통행료를 납부하지 않은 경우 납부 완료시 까지</li>
                        <li>② 통행료 관련 분쟁이 발생한 경우 분쟁 완료시 까지</li>
                        <li>③ 다른 법령 또는 당사자의 합의에 따라 보유할 필요가 있는 경우</li>
                      </ul>
                    </li>
                  </ul>
                </li>
                <li>
                  <p class="contents-head">미동의에 따른 불이익 사항</p>
                  <ul class="body-description-list">
                    <li>
                      개인정보 수집 &middot; 이용에 관한 동의는 거부할 수 있으며, 거부할 경우 하이패스 차량 단말기 등록 및
                      서비스 이용을 할 수 없습니다.
                    </li>
                  </ul>
                </li>
              </ul>
            </div>
          </template>

          <template slot="slide5">
            <!-- slide5 : 민감정보수집이용에대한사항 -->
            <div>
              <strong class="popup-sub-tit">민감정보 수집 &middot; 이용에 대한 사항</strong>
              <div class="agree-area">
                <ul class="body-contents">
                  <li>
                    <p class="contents-head">민감정보 수집 &middot; 이용 목적</p>
                    <ul class="body-description-list">
                      <li>장애인 차량 구입대상 확인, 면세신고 및 신규 등록대행</li>
                    </ul>
                  </li>
                  <li>
                    <p class="contents-head">수집하는 민감정보 항목</p>
                    <ul class="body-description-list">
                      <li>장애유형, 급 등 장애인 차량구입, 면세신고 및 신규등록을 위한 관련 정보</li>
                    </ul>
                  </li>
                  <li>
                    <p class="contents-head">민감정보 보유 및 이용기간</p>
                    <ul class="body-description-list">
                      <li>
                        관련 법령의 규정에 의하여 보전할 의무가 있는 경우가 아닌 한, 민감정보의 수집 &middot; 이용에 관한
                        동의 목적을 달성할 때까지만 보유 &middot; 이용합니다.
                      </li>
                    </ul>
                  </li>
                  <li>
                    <p class="contents-head">민감정보 수집 &middot; 이용 미동의에 따른 불이익 사항</p>
                    <ul class="body-description-list">
                      <li>장애인 차량 매매 계약을 거절할 수 있습니다.</li>
                    </ul>
                  </li>
                </ul>
              </div>
            </div>
          </template>

          <template slot="slide6">
            <!-- slide6 : 민감정보제3자제공에대한사항 -->
            <div>
              <strong class="popup-sub-tit">민감정보 제3자 제공에 대한 사항</strong>
              <div class="agree-area">
                <ul class="body-contents">
                  <li>
                    <p class="contents-head">민감정보 수집 &middot; 이용 목적</p>
                    <ul class="body-description-list">
                      <li>1. 국세청</li>
                      <li>1. 국토교통부</li>
                    </ul>
                  </li>
                  <li>
                    <p class="contents-head">제공정보 이용목적</p>
                    <ul class="body-description-list">
                      <li>신규등록 및 면세신고 관련 서비스 제공</li>
                    </ul>
                  </li>
                  <li>
                    <p class="contents-head">제공하는 개인정보 항목</p>
                    <ul class="body-description-list">
                      <li>장애유형, 등급 등 신규등록 및 면세신고를 위한 민감정보</li>
                    </ul>
                  </li>
                  <li>
                    <p class="contents-head">보유 및 이용기한</p>
                    <ul class="body-description-list">
                      <li>이용목적 달성 후 즉시 폐기</li>
                    </ul>
                  </li>
                  <li>
                    <p class="contents-head">미동의에 따른 불이익 사항</p>
                    <ul class="body-description-list">
                      <li>신규등록 및 면세신고를 할 수 없습니다.</li>
                    </ul>
                  </li>
                </ul>
              </div>
            </div>
          </template>

          <template slot="slide7">
            <!-- slide7 : 선택적개인정보수집이용및광고성정보수신에대한사항 -->
            <div>
              <p class="popup-sub-tit">선택적 개인정보 수집 &middot; 이용 및 광고성 정보 수신에 대한 사항</p>
              <div class="agree-area">
                <ul class="body-contents">
                  <li>
                    <p class="contents-head">개인정보 수집 &middot; 이용 목적</p>
                    <ul class="body-description-list">
                      <li>
                        신규서비스(제품) 안내, 전자적 전송매체를 이용한 영리목적의 광고성 정보 전송, 우편(DM) 발송 등 마케팅
                        활용, 시장조사, 차량 정기점검 및 정비상품 &middot; 이벤트 안내 등
                      </li>
                    </ul>
                  </li>
                  <li>
                    <p class="contents-head">수집하는 개인정보 항목</p>
                    <ul class="body-description-list">
                      <li>
                        [필수적 개인정보 수집 &middot; 이용에 대한 동의]란에서 수집하는 개인정보 항목 중 성명, 주소,
                        전화번호, 휴대폰 번호, 이메일 등 상기 목적을 달성하기 위하여 필요한 정보
                      </li>
                    </ul>
                  </li>
                  <li>
                    <p class="contents-head">개인정보 보유 및 이용기간</p>
                    <ul class="body-description-list">
                      <li>[필수적 개인정보 수집 &middot; 이용에 대한 동의]란에서 정하는 보유 및 이용기간과 동일</li>
                    </ul>
                  </li>
                  <li>
                    <p class="contents-head">미동의에 따른 불이익 사항</p>
                    <ul class="body-description-list">
                      <li>없음</li>
                    </ul>
                  </li>
                </ul>
              </div>
            </div>
          </template>
        </v-carousel-new>
        <v-btn class="btn btn-md" b-size="btn-md" @click="$emit('close')">확인</v-btn>
      </div>
    </template>
  </v-popup>
</template>

<script>
import { VPopup } from '~/components/element'
export default {
  components: {
    VPopup
  },
  props: {
    visible: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      // 슬라이드
      slideList: []
    }
  }
}
</script>
