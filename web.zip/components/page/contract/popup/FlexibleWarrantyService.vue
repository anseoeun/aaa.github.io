<template>
  <v-popup
    :visible="visible"
    :width="'550px'"
    :footer="['confirm']"
    @close="
      $emit('close')
      popVisible = false
    "
    @confirm="
      $emit('close')
      popVisible = false
    "
  >
    <template slot="header">
      <div class="title">선택형 보증제도 안내</div>
      <p class="header-description">
        고객 Life Style별 주행 패턴이 다양화됨에 따라 고객에게 좀 더 나은<br />보증수리 혜택을 제공하기 위해 당사 차량
        구매 시 차체/일반 및 냉난방 계통의<br />보증기간을 고객이 직접 선택할 수 있는 신개념의 보증제도 입니다.
      </p>
    </template>
    <template slot="body">
      <ul class="body-contents">
        <li>
          <p class="contents-head">대상 차종</p>
          <ul class="body-description-list">
            <li>현대 브랜드 전차종 (단, 제네시스 브랜드 / 포터 / 스타렉스 / 택시 / 상용 제외)</li>
          </ul>
        </li>
        <li>
          <p class="contents-head">적용 대상</p>
          <ul class="body-description-list">
            <li>차체/일반 및 냉난방 계통 보증기간 (엔진/동력 계통은 기존과 동일 5년/10만km)</li>
          </ul>
        </li>
        <li>
          <p class="contents-head">서비스 내용</p>
          <ul class="body-description-list">
            <li>2년/8만km 또는 3년/6만km 또는 4년/4만km 중 고객이 원하는 보증기간 출고 전/후 선택 가능</li>
            <li>고객이 별도로 선택하지 않을 경우 기본 3년/6만km 적용</li>
          </ul>
        </li>
        <li>
          <p class="contents-head">제공 기간</p>
          <ul class="body-description-list">
            <li>상기 보증기간 內 횟수에 상관없이 언제든 변경 가능</li>
          </ul>
        </li>
        <li>
          <p class="contents-head">변경 방법</p>
          <ul class="body-description-list">
            <li>서비스 거점 방문, 고객센터(080-600-6000), 마이카스토리 앱, 현대자동차 홈페이지에서 변경 가능</li>
          </ul>
        </li>
      </ul>
    </template>
  </v-popup>
</template>

<script>
import { VPopup } from '~/components/element'
export default {
  components: {
    VPopup
  },
  props: {
    visible: {
      type: Boolean,
      default: false
    }
  }
}
</script>
