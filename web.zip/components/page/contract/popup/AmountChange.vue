<template>
  <v-popup
    :visible="visible"
    :footer="['confirm']"
    :width="'550px'"
    @close="
      $emit('close')
      popVisible = false
    "
    @confirm="
      $emit('close')
      popVisible = false
    "
  >
    <template slot="header">
      <div class="title">판매조건 변경 안내</div>
      <!-- 2021.03.31 (ver1.2) 텍스트 수정 -->
      <p class="header-description">
        견적 시 선택하신 할인 정보가 변경되었습니다.<br />계약을 진행하시기 전 아래 변경 사항을 확인해 주세요.
      </p>
    </template>
    <template slot="body">
      <div class="body-contents">
        <p class="contents-head">변경 사항</p>

        <!-- 2021.03.24 (ver1.1) -->
        <ul class="plan-info">
          <li>
            <p class="title">특별조건할인명1</p>
            <p class="description t-blue">혜택 종료</p>
          </li>
          <li>
            <p class="title">특별조건할인명2</p>
            <p class="description t-blue">혜택 종료</p>
          </li>
          <li>
            <p class="title">금리할인상품명</p>
            <p class="description t-blue">금액 변동</p>
          </li>
          <li>
            <p class="title">쿠폰명</p>
            <p class="description t-blue">기간 만료</p>
          </li>
        </ul>
      </div>
    </template>
  </v-popup>
</template>

<script>
import { VPopup } from '~/components/element'
export default {
  components: {
    VPopup
  },
  props: {
    visible: {
      type: Boolean,
      default: false
    }
  }
}
</script>