<template>
  <v-popup
    :visible="visible"
    :footer="['confirm']"
    :width="'1000px'"
    @close="
      $emit('close')
      popVisible = false
    "
    @confirm="
      $emit('close')
      popVisible = false
    "
  >
    <template slot="header">
      <div class="title">장애 등급별 / 세금 종류별 면세 안내</div>
    </template>
    <template slot="body">
      <p class="contents-head">장애인 1인 1대에 한하여 아래 표와 같이 장애 등급별/세금 종류별 면세가 가능합니다.</p>
      <div class="table-area">
        <table>
          <colgroup>
            <col width="64px" />
            <col width="115px" />
            <col width="180px" />
            <col width="73px" />
            <col width="73px" />
            <col width="73px" />
            <col width="73px" />
            <col width="auto" />
          </colgroup>
          <thead>
            <tr>
              <th rowspan="2" colspan="2" scope="col">세금 항목별 면세내역</th>
              <th scope="col">국세(면세)<br />※ 배기량 제한 없음</th>
              <th colspan="4" scope="colgroup">지방세(조례 감면)<br />※ 배기량 2,000cc 이하 승용차<br />(서울시 기준)</th>
              <th rowspan="2" scope="col">제출 서류</th>
            </tr>
            <tr>
              <th scope="col">개별소비세<br />(최대 500만원 內 면제),<br />교육세</th>
              <th>등록세</th>
              <th>취득세</th>
              <th>공채</th>
              <th>자동차세</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td rowspan="4">장<br />애<br />인</td>
              <td>일반장애 1-3급</td>
              <td><strong class="t-blue">면세가능</strong></td>
              <td><strong class="t-blue">면제</strong></td>
              <td><strong class="t-blue">면제</strong></td>
              <td><strong class="t-blue">면제</strong></td>
              <td><strong class="t-blue">면제</strong></td>
              <td rowspan="4">장애인 복지카드,<br /><strong class="t-blue">(공동명의 시)</strong> 주민등록등본</td>
            </tr>
            <tr>
              <td>시각장애 4급</td>
              <td>면세불가</td>
              <td><strong class="t-blue">면제</strong></td>
              <td><strong class="t-blue">면제</strong></td>
              <td><strong class="t-blue">면제</strong></td>
              <td><strong class="t-blue">면제</strong></td>
            </tr>
            <tr>
              <td>시각장애 5급,<br />일반장애 4~6급</td>
              <td>면세불가</td>
              <td>납세</td>
              <td>납세</td>
              <td><strong class="t-blue">면제</strong></td>
              <td>납세</td>
            </tr>
            <tr>
              <td>기타 장애등급</td>
              <td>면세불가</td>
              <td>납세</td>
              <td>납세</td>
              <td>납세</td>
              <td>납세</td>
            </tr>
            <tr>
              <td colspan="2">국가유공 상이자<br />(1-7급)</td>
              <td><strong class="t-blue">면세가능</strong></td>
              <td><strong class="t-blue">면제</strong></td>
              <td><strong class="t-blue">면제</strong></td>
              <td><strong class="t-blue">면제</strong></td>
              <td><strong class="t-blue">면제</strong></td>
              <td>국가유공자증,<br /><strong class="t-blue">(공동명의 시)</strong> 주민등록등본</td>
            </tr>
            <tr>
              <td colspan="2">고엽제 후유증<br />(검도-고도)</td>
              <td><strong class="t-blue">면세가능</strong></td>
              <td><strong class="t-blue">면제</strong></td>
              <td><strong class="t-blue">면제</strong></td>
              <td><strong class="t-blue">면제</strong></td>
              <td><strong class="t-blue">면제</strong></td>
              <td>고엽제범 적용대상 확인원<br />(장애등급 표기)<br /><strong class="t-blue">(공동명의 시)</strong> 주민등록등본</td>
            </tr>
            <tr>
              <td colspan="2">광주민주화 운동 부상자<br />(1급-14급)</td>
              <td><strong class="t-blue">면세가능</strong></td>
              <td><strong class="t-blue">면제</strong></td>
              <td><strong class="t-blue">면제</strong></td>
              <td><strong class="t-blue">면제</strong></td>
              <td><strong class="t-blue">면제</strong></td>
              <td>광주민주유공자증(장애등급 표기)<br /><strong class="t-blue">(공동명의 시)</strong> 주민등록등본</td>
            </tr>
          </tbody>
        </table>
      </div>
      <div class="notice">
        <div class="title">유의사항</div>
        <ul class="bullet-list">
          <li>지방세 면제 내용은 자자체 조례에 따라 상이하므로 반드시 구입 전 해당 지자체로 문의하시기 바랍니다.</li>
          <li>배기량 2,000cc 이상의 승용차도 인승에 따라 지방세 감면 혜택이 상이하므로, 인승별 지방세 감면 혜택은 관할 관청에 문의하시기 바랍니다.</li>
        </ul>
      </div>
    </template>
  </v-popup>
</template>

<script>
import { VPopup } from '~/components/element'
export default {
  components: {
    VPopup
  },
  props: {
    visible: {
      type: Boolean,
      default: false
    }
  },
  updated() {
    if (this.visible) {
      this.setCaption()
    }
  },
}
</script>