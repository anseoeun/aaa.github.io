<template>
  <!-- 2021.03.23 (ver1.3) step6 클래스 추가 -->
  <!-- 2021.03.29 (ver1.4) 추가 -->
  <!-- 2021.03.31 (ver1.5) step6->step4로 수정 -->

  <!-- 2021.04.13 (ver1.6) 디자인 변경으로인한 전체적인 수정 -->
  <div class="page-step step4">

    <!-- 계약확인 -->
    <div v-if="contractInfo === true" class="contract-confirmation">
      <div class="matching-box">
        <div class="box-wrap">
          <div class="box-tit">계약내역<br />확인</div>
          <div class="box-desc">
            <div class="info-grid-list contract-info">
              <ul>
                <li class="car-info">
                  <div class="info-title">
                    <div class="car-img"><v-img :src="carImg.src" :alt="carImg.alt"></v-img></div>
                  </div>
                  <div class="info-group bold">{{ carModel }}</div>
                </li>
                <li>
                  <strong class="info-title bold">색상</strong>
                  <div class="info-group">
                    <ul class="desc-list">
                      <li>
                        <em>외장색상</em>
                        <ul class="color-list">
                          <li>
                            <div class="color">
                              <div class="color-sample" :style="`background-image:url(${outColor.src})`"></div>
                              <div class="color-txt">{{ outColor.txt }}</div>
                            </div>
                          </li>
                        </ul>
                      </li>
                      <li>
                        <em>내장색상</em>
                        <ul class="color-list">
                          <li>
                            <div class="color">
                              <div class="color-sample" :style="`background-image:url(${inColor.src})`"></div>
                              <div class="color-txt">{{ inColor.txt }}</div>
                            </div>
                          </li>
                        </ul>
                      </li>
                    </ul>
                  </div>
                </li>
                <li>
                  <strong class="info-title bold">기본품목</strong>
                  <div class="info-group tog">
                    <ul class="desc-list" :class="{ on: isAct(0) }">
                      <li>SG 시스템</li>
                    </ul>
                    <v-btn class="btn-detail last" :class="{ on: isAct(0) }" @click="setAct(0)">
                      <span class="offscreen">상세보기</span>
                    </v-btn>
                  </div>
                </li>
                <li>
                  <strong class="info-title bold">선택품목</strong>
                  <div class="info-group tog">
                    <ul class="desc-list" :class="{ on: isAct(1) }">
                      <li v-for="(item, index) in optList" :key="index">{{ item.opt }}</li>
                    </ul>
                    <v-btn class="btn-detail last" :class="{ on: isAct(1) }" @click="setAct(1)">
                      <span class="offscreen">상세보기</span>
                    </v-btn>
                  </div>
                </li>
                <li>
                  <strong class="info-title bold">H Genuine Accessories</strong>
                  <div class="info-group tog">
                    <ul class="desc-list" :class="{ on: isAct(2) }">
                      <li v-for="(item, index) in hgList" :key="index">{{ item.opt }}</li>
                    </ul>
                    <v-btn class="btn-detail last" :class="{ on: isAct(2) }" @click="setAct(2)">
                      <span class="offscreen">상세보기</span>
                    </v-btn>
                  </div>
                </li>
                <li>
                  <strong class="info-title bold">N Performance</strong>
                  <div class="info-group tog">
                    <ul class="desc-list" :class="{ on: isAct(3) }">
                      <li v-for="(item, index) in npList" :key="index">{{ item.opt }}</li>
                    </ul>
                    <v-btn class="btn-detail last" :class="{ on: isAct(3) }" @click="setAct(3)">
                      <span class="offscreen">상세보기</span>
                    </v-btn>
                  </div>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
      <div class="matching-box">
        <div class="box-wrap">
          <div class="box-tit">계약조항</div>
          <div class="box-desc line">
            <p>계약을 완료하기 전 반드시 현대자동차 계약조항을 확인해 주시기 바랍니다.</p>
            <v-checkbox :one-check="true" :checked.sync="checkboxDataVal" @change="chkChange"
              >계약조항 확인하기</v-checkbox
            >
          </div>
        </div>
      </div>
      <div class="matching-box">
        <div class="box-wrap">
          <div class="box-tit">구매 동의 내역</div>
          <div class="box-desc">
            <div class="info-grid-list">
              <ul>
                <li>
                  <div class="info-group">
                    <ul class="desc-list">
                      <li>
                        <p>자동차 교환ㆍ환불 중재제도 설명에 대한 이해 및 수락여부</p>
                        <span class="t-blue last">동의</span>
                      </li>
                      <li>
                        <p>특별주문차량 구매 동의</p>
                        <span class="t-blue last">동의</span>
                      </li>
                      <li>
                        <p>판촉차량 구매 동의</p>
                        <span class="t-blue last">동의</span>
                      </li>
                      <li>
                        <p>전시차량 구매 동의</p>
                        <span class="t-blue last">동의</span>
                      </li>
                      <li>
                        <p>직원 차량의무보유기간 준수 동의</p>
                        <span class="t-blue last">동의</span>
                      </li>
                    </ul>
                  </div>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
      <div class="matching-box">
        <div class="box-wrap">
          <div class="box-tit">
            명의자 정보
          </div>
          <div class="box-desc">
            <p class="text">명의자 총 {{ resInitNomineeInfo.length }}명</p>
            <div v-for="(item, index) in resInitNomineeInfo" :key="index" class="info-grid-list owner-info">
              <ul>
                <li>
                  <strong v-if="item.mainOwner" class="info-title bold">주계약자</strong>
                  <strong v-else class="info-title bold">공동명의자 {{ `${index}` }}</strong>
                  <div class="info-group sign">
                    <span v-if="item.signState" class="complete">전자서명 완료</span>
                    <span v-else>전자서명 미완료</span>
                  </div>
                </li>
                <li>
                  <strong class="info-title">이름</strong>
                  <div class="info-group">{{ item.relationPersonName }}</div>
                </li>
                <li>
                  <strong class="info-title">주민등록번호</strong>
                  <div class="info-group">{{ item.inhabitantsIdentificationNumber }}</div>
                </li>
                <li>
                  <strong class="info-title">연락처</strong>
                  <div class="info-group">
                    {{ item.mobilePhoneNumber1 }}-{{ item.mobilePhoneNumber2 }}-{{ item.mobilePhoneNumber3 }}
                  </div>
                </li>
                <li>
                  <strong class="info-title">이메일</strong>
                  <div class="info-group">{{ item.emailAddress }}</div>
                </li>
                <li>
                  <strong class="info-title">주소</strong>
                  <div class="info-group">
                    ({{ item.zipCode }}) {{ item.addressContents }} {{ item.detailAddressContents }}
                  </div>
                </li>
              </ul>
              <div class="btn-wrap">
                <v-btn class="btn white md r">카카오톡으로 전자서명</v-btn>
                <v-btn class="btn white md r">공인인증서로 전자서명</v-btn>
                <!-- 법인 -->
                <!-- <v-btn class="btn white md r">법인 공인인증서로 전자서명</v-btn> -->
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="btn-wrap">
        <p class="bullet-star">
          현대자동차 계약조항을 확인하셨나요? [계약서 작성완료] 버튼 클릭하기 전 계약조항을 먼저 확인해 주세요.
        </p>
        <v-btn class="btn lg gray r">이전</v-btn>
        <v-btn class="btn lg blue r">계약서 작성 완료</v-btn>
      </div>
    </div>

    <!-- 계약서 완료 -->
    <div v-else-if="contractDocument === true" class="contract-complete">
      <div class="title">계약서 작성을 완료하였습니다.</div>
      <div class="complete-info">
        <p class="contract-number">
          계약번호 <span>{{ contractNumber }}</span>
        </p>
        <div class="car-img"><v-img :src="carImg.src" :alt="carImg.alt"></v-img></div>
        <strong class="contract-model">{{ carModel }}</strong>
        <div class="sign-info">전자서명 미서명 명의자 <span>홍길동</span></div>
        <p class="contract-date">
          <span>{{ contractCompletionLimitDate }}까지</span> 전자서명 및 계약금 입금을 완료해 주세요.<br />기한 내
          진행하지 않으면 계약은 자동 취소됩니다.
        </p>
        <div class="btn-wrap">
          <v-btn class="btn lg blue r">구매내역 상세보기</v-btn>
        </div>
      </div>
    </div>

    <!-- 계약 완료 -->
    <div v-else-if="contractComplete === true" class="contract-complete">
      <div class="title">계약이 완료되었습니다.</div>
      <p class="sub-text">계약금 결제 및 전자서명 완료를 확인하였습니다.</p>
      <div class="complete-info">
        <p class="contract-number">
          계약번호 <span>{{ contractNumber }}</span>
        </p>
        <div class="car-img"><v-img :src="carImg.src" :alt="carImg.alt"></v-img></div>
        <strong class="contract-model">{{ carModel }}</strong>
        <p>계약이 완료되어 차량 준비가 시작됩니다.<br />자세한 진행 상황은 마이페이지>구매내역 상세에서 확인하세요.</p>
        <div class="btn-wrap">
          <v-btn class="btn lg blue r">구매내역 상세보기</v-btn>
        </div>
      </div>
    </div>

    <!-- 팝업 -->
    <terms-hyundai-car-clause
      :visible="popVisible.termsHyundaiCarClause"
      @close="popVisible.termsHyundaiCarClause = false"
    ></terms-hyundai-car-clause>
  </div>
</template>

<script>
import TermsHyundaiCarClause from '~/components/page/contract/popup/TermsHyundaiCarClause'
export default {
  components: {
    TermsHyundaiCarClause
  },
  data() {
    return {
      // 계약확인
      contractInfo: true,
      // 계약서완료
      contractDocument: false,
      // 계약완료
      contractComplete: false,

      carModel: 'AX 스마트스트림 가솔린 1.1 터보 프리미엄 밀레니얼 A/T',
      contractNumber: 'A3721CN000090',
      checkboxDataVal: false,
      carImg: {
        src: require('~/assets/images/temp/temp-contract-car-visual.png'),
        alt: 'AX 스마트스트림 가솔린 1.1 터보 프리미엄 밀레니얼 A/T'
      },
      inColor: { txt: '메테오 블루', src: require('~/assets/images/temp/temp-color-4.png') },
      outColor: { txt: '쉬머링 실버', src: require('~/assets/images/temp/temp-color-1.png') },
      optList: [
        { opt: '인조가죽 시트(인조가죽 도어 센터트림 포함)' },
        { opt: '인포테인먼트 내비 I' },
        { opt: '익스테리어 디자인 I' }
      ],
      hgList: [
        { opt: '1열 방오 시트 커버 + 2열 방오 커버' },
        { opt: 'ISOFIX 카시트' },
        { opt: '하네스 ISOFIX 안전벨트 테더' }
      ],
      npList: [{ opt: '인테리어 패키지' }, { opt: 'N 퍼포먼스 서스펜션' }],
      resInitNomineeInfo: [
        {
          mainOwner: true,
          relationPersonName: '김현대',
          inhabitantsIdentificationNumber: '991230-1*****',
          mobilePhoneNumber1: '010',
          mobilePhoneNumber2: '1234',
          mobilePhoneNumber3: '5678',
          emailAddress: 'hyundai@naver.com',
          zipCode: '06719',
          addressContents: '서울특별시 서초구',
          detailAddressContents: '남부순환로 2415 (서초동) 123',
          signState: true
        },
        {
          mainOwner: false,
          relationPersonName: '홍길동',
          inhabitantsIdentificationNumber: '991230-1*****',
          mobilePhoneNumber1: '010',
          mobilePhoneNumber2: '5678',
          mobilePhoneNumber3: '1234',
          emailAddress: 'hyundai@naver.com',
          zipCode: '06719',
          addressContents: '서울특별시 서초구',
          detailAddressContents: '남부순환로 2415 (서초동) 123',
          signState: false
        },
        {
          mainOwner: false,
          relationPersonName: '이현대',
          inhabitantsIdentificationNumber: '991230-1*****',
          mobilePhoneNumber1: '010',
          mobilePhoneNumber2: '5678',
          mobilePhoneNumber3: '1234',
          emailAddress: 'hyundai@naver.com',
          zipCode: '06719',
          addressContents: '서울특별시 서초구',
          detailAddressContents: '남부순환로 2415 (서초동) 123',
          signState: false
        },
        {
          mainOwner: false,
          relationPersonName: '최현대',
          inhabitantsIdentificationNumber: '991230-1*****',
          mobilePhoneNumber1: '010',
          mobilePhoneNumber2: '5678',
          mobilePhoneNumber3: '1234',
          emailAddress: 'hyundai@naver.com',
          zipCode: '06719',
          addressContents: '서울특별시 서초구',
          detailAddressContents: '남부순환로 2415 (서초동) 123',
          signState: true
        }
      ],
      contractCompletionLimitDate: '2021년 1월 20일 10시 55분',
      popVisible: {
        termsHyundaiCarClause: false
      },
      listSelected: [false, false, false, false]
    }
  },
  methods: {
    chkChange() {
      if (this.checkboxDataVal) {
        this.popVisible.termsHyundaiCarClause = true
      }
    },
    setAct(index) {
      if (this.listSelected[index] === false) {
        this.$set(this.listSelected, index, true)
      } else {
        this.$set(this.listSelected, index, false)
      }
    },
    isAct(index) {
      return this.listSelected[index] === true
    }
  }
}
</script>
