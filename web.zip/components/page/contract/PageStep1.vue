<template>
  <!-- 2021.03.31 (ver1.5) 약관 전체적인 수정, 추가 -->

  <!-- 2021.04.13 (ver1.6) 디자인 변경으로인한 전체적인 수정 -->
  <div class="page-step step1">
    <div class="matching-box">
      <div class="box-wrap">
        <div class="box-tit">개인정보<br />수집 · 이용 및<br />제공 동의</div>
        <div class="box-desc">
          <div class="agree-check">
            <p class="text">
              개인정보보호법, 신용정보 이용 및 보호에 관한 법률 규정에 따라 개인정보의 수집 · 이용 및 제공 동의가
              필요합니다.
            </p>
            <div class="right">
              <!-- 2021.04.09 (ver) 클래스 수정 -->
              <v-btn class="btn md blue line r" :class="{ on: agreeCheck }" type="button" @click="allAgree('privacy')"
                >전체 동의</v-btn
              >
            </div>
          </div>

          <!-- 필수적 개인정보 수집 · 이용에 대한 사항 -->
          <section class="information-detail">
            <div class="summary-info">
              <h1 class="title full">필수적 개인정보 수집 · 이용에 대한 사항</h1>
              <div class="right">
                <!-- 2021.04.13 (ver1.6) agree 클래스 추가 -->
                <v-radio
                  v-model="agreeCheckVal[0]"
                  class="radio-round-button agree"
                  type="button"
                  :data="checkList1"
                  @input="agreeChange"
                />
              </div>
              <v-btn
                class="btn-detail"
                type="icon"
                :icon-class="['icon-open', { active: isActive(1) }]"
                @click="setActive(1)"
                ><span class="offscreen">상세보기</span></v-btn
              >
            </div>
            <div v-if="isActive(1)" class="detail-info">
              <div class="info-grid-list">
                <ul>
                  <li>
                    <strong class="info-title">개인정보 수집 · 이용 목적</strong>
                    <div class="info-group">
                      <ol>
                        <li>1. 자동차 매매 계약상 의무 이행을 위한 재화 · 용역의 제공</li>
                        <li>
                          2. 자동차 구매에 따른 탁송 · 등록대행, 보증수리 및 차량관리(차량점검 · 유지보수, 긴급출동
                          및<br />제작결함 시정) 서비스 제공을 위한 본인 확인, 대금 청구서 발송 · 대금결제 · 대금추심을
                          위한 본인확인,<br />분쟁해결을 위한 기록보존, 불만처리 등 민원처리, 고지사항 전달, 서비스에
                          대한 만족도 조사
                        </li>
                      </ol>
                    </div>
                  </li>
                  <li>
                    <strong class="info-title">수집하는 개인정보 항목</strong>
                    <div class="info-group">
                      성명, 주민등록번호(외국인등록번호 또는 여권번호), 신분증 사본(사진), 상호, 사업자번호, 주소,<br />전화번호,
                      휴대폰번호, 이메일, 구입 차량번호, 할부매매의 경우 ‘신용정보의 이용 및 보호에 관한 법률’ 상<br />개인신용정보
                      <p class="bullet">
                        주민등록번호의 경우 세금계산서 발행, 주민등록 등 법정이 허용한 범위 내에서 해당 목적을 위해서만
                        수집합니다.
                      </p>
                    </div>
                  </li>
                  <li>
                    <strong class="info-title">개인정보 보유 및 이용기간</strong>
                    <div class="info-group">
                      관련 법령의 규정에 의하여 보존할 의무가 있는 경우가 아닌 한, 개인정보의 수집 · 이용에 관한 동의<br />목적을
                      달성할때까지만 보유 · 이용합니다.
                    </div>
                  </li>
                  <li>
                    <strong class="info-title"
                      >개인정보(고유식별정보 포함)<br />수집 · 이용 미동의에 따른<br />불이익 사항</strong
                    >
                    <div class="info-group">자동차 매매 계약을 거절할 수 있습니다.</div>
                  </li>
                </ul>
              </div>
            </div>
          </section>

          <!-- 필수적 개인정보 제3자 제공에 대한 사항 -->
          <section class="information-detail">
            <div class="summary-info">
              <h1 class="title full">필수적 개인정보 제3자 제공에 대한 사항</h1>
              <div class="right">
                <!-- 2021.04.13 (ver1.6) agree 클래스 추가 -->
                <v-radio
                  v-model="agreeCheckVal[1]"
                  class="radio-round-button agree"
                  type="button"
                  :data="checkList2"
                  @input="agreeChange"
                />
              </div>
              <v-btn
                class="btn-detail"
                type="icon"
                :icon-class="['icon-open', { active: isActive(2) }]"
                @click="setActive(2)"
                ><span class="offscreen">상세보기</span></v-btn
              >
            </div>
            <div v-if="isActive(2)" class="detail-info">
              <div class="table-area">
                <table>
                  <colgroup>
                    <col width="20%" />
                    <col width="20%" />
                    <col width="20%" />
                    <col width="20%" />
                    <col width="20%" />
                  </colgroup>
                  <thead>
                    <tr>
                      <th>제공대상</th>
                      <th>제공정보 이용목적</th>
                      <th>제공하는 개인정보 항목</th>
                      <th>보유 및 이용기한</th>
                      <th>제공 미동의에 따른<br />불이익 사항</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>신용정보회사<br />(NICE 신용평가정보(주))</td>
                      <td rowspan="2">
                        할부거래 이용자의<br />신용판단 및 본인확인,<br />자동차 신규등록 관련<br />서비스 제공
                      </td>
                      <td rowspan="2">
                        성명, 주민등록번호, 상호,<br />사업자번호, 주소, 연락처,<br />휴대폰번호, 이메일,<br />구입차량정보
                      </td>
                      <td rowspan="4">이용목적 달성 후<br />즉시 폐기</td>
                      <td rowspan="2">
                        자동차 매매 계약을 거절할<br />수 있으며, 신규등록 관련<br />서비스 제공을 할 수<br />없습니다.
                      </td>
                    </tr>
                    <tr>
                      <td>국토교통부</td>
                    </tr>
                    <tr>
                      <td>현대해상화재보험(주)</td>
                      <td>임시운행차량 의무보험<br />가입</td>
                      <td>성명, 주민등록번호, 상호,<br />사업자번호, 구입차정보</td>
                      <td>임시운행 의무보험에<br />가입할 수 없습니다.</td>
                    </tr>
                    <tr>
                      <td>한국도로공사</td>
                      <td>하이패스 등록 서비스<br />제공</td>
                      <td>성명, 상호, 연락처,<br />휴대폰번호, 차량정보</td>
                      <td>하이패스 서비스 제공을<br />할 수 없습니다.</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </section>

          <!-- 한국도로공사-개인정보 수집 이용에 대한 사항 -->
          <section class="information-detail">
            <div class="summary-info">
              <h1 class="title full">한국도로공사-개인정보 수집 이용에 대한 사항</h1>
              <div class="right">
                <!-- 2021.04.13 (ver1.6) agree 클래스 추가 -->
                <v-radio
                  v-model="agreeCheckVal[2]"
                  class="radio-round-button agree"
                  type="button"
                  :data="checkList3"
                  @input="agreeChange"
                />
              </div>
              <v-btn
                class="btn-detail"
                type="icon"
                :icon-class="['icon-open', { active: isActive(3) }]"
                @click="setActive(3)"
                ><span class="offscreen">상세보기</span></v-btn
              >
            </div>
            <div v-if="isActive(3)" class="detail-info">
              <div class="table-area">
                <table>
                  <colgroup>
                    <col width="20%" />
                    <col width="20%" />
                    <col width="20%" />
                    <col width="20%" />
                    <col width="20%" />
                  </colgroup>
                  <thead>
                    <tr>
                      <th>항목</th>
                      <th>수집 &middot; 이용하는 목적</th>
                      <th>수집 &middot; 이용하는 개인정보 항목</th>
                      <th>개인정보 보유 및 이용기간</th>
                      <th>동의를 거부할 권리 및 미동의에 따른<br />불이익 사항</th>
                    </tr>
                  </thead>
                  <tbody class="t-left">
                    <tr>
                      <td>신청자 기본정보</td>
                      <td>단말기 사후 관리</td>
                      <td>성명, 휴대폰번호, 차명(차종), 차량번호</td>
                      <td>단말기 해지 또는<br />명의변경 후 6개월</td>
                      <td rowspan="3">
                        개인정보 수집 &middot; 이용에 관한 동의는 거부할 수 있으며, 거부할 경우 하이패스 차량 단말기
                        등록 및 서비스 이용을 할 수 없습니다.
                      </td>
                    </tr>
                    <tr>
                      <td>하이패스 이용정보</td>
                      <td>
                        통행료 정산,<br />교통정보 제공,<br />고객응대(민원해소)<br />및 이를 위한<br />서비스 향상
                      </td>
                      <td>통행일시<br />진출입 요금소 요금<br />단말기 번호<br />하이패스 카드 번호</td>
                      <td>
                        3년(전자금융거래법 시행령 제12조)<br />※ 개인정보 보유 및 이용기간 예외<br />1. 통행료를
                        납부하지 않은 경우 납부 완료 시까지<br />2. 통행료 관련 분쟁이 발생한 경우 분쟁 완료 시까지<br />3.
                        다른 법령 또는 당사자의 합의에 따라 보유할 필요가 있는 경우
                      </td>
                    </tr>
                    <tr>
                      <td>하이패스<br />위반(에러) 정보</td>
                      <td>단말기 사후 관리(A/S)</td>
                      <td>위반(에러) 발생정보 통행일시, 진출입 요금소, 에러유형, 회원 성명, 휴대폰번호, 차량번호</td>
                      <td>에러(위반)에 대한 사후관리(A/S) 목적 달성 시까지</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </section>

          <!-- 한국도로공사-필수적 개인정보 제3자 제공 조회에 대한 사항 -->
          <section class="information-detail">
            <div class="summary-info">
              <h1 class="title full">한국도로공사-필수적 개인정보 제3자 제공 조회에 대한 사항</h1>
              <div class="right">
                <!-- 2021.04.13 (ver1.6) agree 클래스 추가 -->
                <v-radio
                  v-model="agreeCheckVal[3]"
                  class="radio-round-button agree"
                  type="button"
                  :data="checkList4"
                  @input="agreeChange"
                />
              </div>
              <v-btn
                class="btn-detail"
                type="icon"
                :icon-class="['icon-open', { active: isActive(4) }]"
                @click="setActive(4)"
                ><span class="offscreen">상세보기</span></v-btn
              >
            </div>
            <div v-if="isActive(4)" class="detail-info">
              <div class="table-area">
                <table>
                  <colgroup>
                    <col width="16.66%" />
                    <col width="16.66%" />
                    <col width="16.66%" />
                    <col width="16.66%" />
                    <col width="16.66%" />
                  </colgroup>
                  <thead>
                    <tr>
                      <th>항목</th>
                      <th>제공대상</th>
                      <th>수집 &middot; 이용하는 목적</th>
                      <th>수집 &middot; 이용하는 개인정보 항목</th>
                      <th>개인정보 보유 및 이용기간</th>
                      <th>동의를 거부할 권리 및 미동의에 따른<br />불이익 사항</th>
                    </tr>
                  </thead>
                  <!-- 2021.04.13 (ver1.6) t-left 클래스 추가 -->
                  <tbody class="t-left">
                    <tr>
                      <td>신청자 기본정보</td>
                      <td rowspan="2">통행료 정산 또는 통행료 수납업무의 위ㆍ수탁 계약에 따른 연계유료도로 운영자</td>
                      <td rowspan="2">통행료 정산, 고객응대 및 이를 위한 서비스 향상</td>
                      <td rowspan="2">통행일시<br />진출입 요금소 요금<br />단말기 번호<br />하이패스 카드 번호</td>
                      <td>단말기 해지 또는<br />명의변경 후 6개월</td>
                      <td rowspan="2">
                        개인정보 수집 &middot; 이용에 관한 동의는 거부할 수 있으며, 거부할 경우 하이패스 차량 단말기
                        등록 및 서비스 이용을 할 수 없습니다.
                      </td>
                    </tr>
                    <tr>
                      <td>하이패스 이용정보</td>
                      <td>
                        3년(전자금융거래법 시행령 제12조)<br />※ 개인정보 보유 및 이용기간 예외<br />1. 통행료를
                        납부하지 않은 경우 납부 완료 시까지<br />2. 통행료 관련 분쟁이 발생한 경우 분쟁 완료 시까지<br />3.
                        다른 법령 또는 당사자의 합의에 따라 보유할 필요가 있는 경우
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </section>

          <!-- 민감정보 수집 · 이용에 대한 사항 -->
          <section class="information-detail">
            <div class="summary-info">
              <h1 class="title full">민감정보 수집 · 이용에 대한 사항</h1>
              <div class="right">
                <!-- 2021.04.13 (ver1.6) agree 클래스 추가 -->
                <v-radio
                  v-model="agreeCheckVal[4]"
                  class="radio-round-button agree"
                  type="button"
                  :data="checkList5"
                  @input="agreeChange"
                />
              </div>
              <v-btn
                class="btn-detail"
                type="icon"
                :icon-class="['icon-open', { active: isActive(5) }]"
                @click="setActive(5)"
                ><span class="offscreen">상세보기</span></v-btn
              >
            </div>
            <div v-if="isActive(5)" class="detail-info">
              <div class="info-grid-list">
                <ul>
                  <li>
                    <strong class="info-title">민감정보 수집 · 이용 목적</strong>
                    <div class="info-group">장애인 차량 구입대상 확인, 면세신고 및 신규 등록대행</div>
                  </li>
                  <li>
                    <strong class="info-title">수집하는 민감정보 항목</strong>
                    <div class="info-group">장애유형, 급 등 장애인 차량구입, 면세신고 및 신규등록을 위한 관련 정보</div>
                  </li>
                  <li>
                    <strong class="info-title">민감정보 보유 및 이용기간</strong>
                    <div class="info-group">
                      관련 법령의 규정에 의하여 보전할 의무가 있는 경우가 아닌 한, 민감정보의 수집 · 이용에 관한 동의<br />목적을
                      달성할때까지만 보유 · 이용합니다.
                    </div>
                  </li>
                  <li>
                    <strong class="info-title">민감정보 수집 · 이용 미동의에<br />따른 불이익 사항</strong>
                    <div class="info-group">장애인 차량 매매 계약을 거절할 수 있습니다.</div>
                  </li>
                </ul>
              </div>
            </div>
          </section>

          <!-- 민감정보 제3자 제공에 대한 사항 -->
          <section class="information-detail">
            <div class="summary-info">
              <h1 class="title full">민감정보 제3자 제공에 대한 사항</h1>
              <div class="right">
                <!-- 2021.04.13 (ver1.6) agree 클래스 추가 -->
                <v-radio
                  v-model="agreeCheckVal[5]"
                  class="radio-round-button agree"
                  type="button"
                  :data="checkList6"
                  @input="agreeChange"
                />
              </div>
              <v-btn
                class="btn-detail"
                type="icon"
                :icon-class="['icon-open', { active: isActive(6) }]"
                @click="setActive(6)"
                ><span class="offscreen">상세보기</span></v-btn
              >
            </div>
            <div v-if="isActive(6)" class="detail-info">
              <div class="table-area">
                <table>
                  <colgroup>
                    <col width="20%" />
                    <col width="20%" />
                    <col width="20%" />
                    <col width="20%" />
                    <col width="20%" />
                  </colgroup>
                  <thead>
                    <tr>
                      <th>제공대상</th>
                      <th>제공정보 이용목적</th>
                      <th>제공하는 개인정보 항목</th>
                      <th>보유 및 이용기한</th>
                      <th>제공 미동의에 따른<br />불이익 사항</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>국세청</td>
                      <td rowspan="2">신규등록 및 면세신고<br />관련 서비스 제공</td>
                      <td rowspan="2">장애유형, 등급 등<br />신규등록 및 면세신고를<br />위한 민감정보</td>
                      <td rowspan="2">이용목적 달성 후<br />즉시 폐기</td>
                      <td rowspan="2">신규등록 및 면세신고를<br />할 수 없습니다.</td>
                    </tr>
                    <tr>
                      <td>국토교통부</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </section>

          <!-- 선택적 개인정보 수집 · 이용 및 광고성 정보 수신에 대한 사항 -->
          <section class="information-detail">
            <div class="summary-info">
              <h1 class="title full">선택적 개인정보 수집 · 이용 및 광고성 정보 수신에 대한 사항 (선택)</h1>
              <div class="right">
                <!-- 2021.04.13 (ver1.6) agree 클래스 추가 -->
                <v-radio
                  v-model="agreeCheckVal[6]"
                  class="radio-round-button agree"
                  type="button"
                  :data="checkList7"
                  @change="agreeChange(7)"
                />
              </div>
              <v-btn
                class="btn-detail"
                type="icon"
                :icon-class="['icon-open', { active: isActive(7) }]"
                @click="setActive(7)"
                ><span class="offscreen">상세보기</span></v-btn
              >
            </div>
            <div v-if="isActive(7)" class="detail-info">
              <div class="info-grid-list">
                <ul>
                  <li>
                    <strong class="info-title">개인정보 수집 · 이용 목적</strong>
                    <div class="info-group">
                      신규서비스(제품) 안내, 전자적 전송매체를 이용한 영리목적의 광고정 정보 전송, 우편(DM) 발송 등
                      마케팅 활용, 시장조사, 차량 정기점검 및 정비상품 · 이벤트 안내 등
                    </div>
                  </li>
                  <li>
                    <strong class="info-title">수집하는 개인정보 항목</strong>
                    <div class="info-group">
                      [필수적 개인정보 수집 · 이용에 대한 동의]란에서 수집하는 개인정보 항목 중 성명, 주소, 전화번호,
                      휴대폰 번호, 이메일 등 상기 목적을 달성하기 위하여 필요한 정보
                    </div>
                  </li>
                  <li>
                    <strong class="info-title">개인정보 보유 및 이용기간</strong>
                    <div class="info-group">
                      [필수적 개인정보 · 이용에 대한 동의]란에서 정하는 보유 및 이용기간과 동일
                    </div>
                  </li>
                  <li>
                    <strong class="info-title"
                      >개인정보(고유식별정보 포함)<br />수집 · 이용 · 제공 미동의에 따른<br />불이익 사항</strong
                    >
                    <div class="info-group">없음</div>
                  </li>
                </ul>
              </div>
              <!-- 2021.04.13 (ver1.6) 위치이동 -->
              <!-- <div class="all-check-list">
                <v-checkbox
                  v-model="checkboxAll"
                  :data="checkboxAllList"
                  all-chk-name="정보수신방법"
                  @change="innerCheck(7)"
                />
              </div> -->
            </div>
          </section>

          <!-- 2021.04.13 (ver1.6) 위치이동, 수정 -->
          <div class="all-check-list">
            <strong class="title">정보수신방법</strong>
            <v-checkbox v-model="checkboxAll" :data="checkboxAllList" />
            <!-- <v-checkbox
                  v-model="checkboxAll"
                  :data="checkboxAllList"
                  all-chk-name="정보수신방법"
                  @change="innerCheck(7)"
                />
              </div> -->
          </div>
        </div>
      </div>
    </div>

    <!-- 구매 -->
    <div class="matching-box">
      <div class="box-wrap">
        <div class="box-tit">구매 동의</div>
        <div class="box-desc">
          <div class="agree-check">
            <p class="text">구매를 위한 중요 안내사항 입니다. 각 항목을 모두 확인하고, 동의하셔야 계약이 진행됩니다.</p>
            <div class="right">
              <!-- 2021.04.13 (ver1.6) 클래스 수정 -->
              <v-btn class="btn md blue line r" :class="{ on: buyingAgreeCheck }" type="button" @click="allAgree('buying')"
                >전체 동의</v-btn
              >
            </div>
          </div>

          <!-- 자동차 교환ㆍ환불 중재제도 설명에 대한 이해 및 수락여부 확인 -->
          <section class="information-detail">
            <div class="summary-info">
              <h1 class="title full">자동차 교환ㆍ환불 중재제도 설명에 대한 이해 및 수락여부 확인</h1>
              <div class="right">
                <!-- 2021.04.13 (ver1.6) agree 클래스 추가 -->
                <v-radio
                  v-model="buyingAgreeCheckVal[0]"
                  class="radio-round-button agree"
                  type="button"
                  :data="buyingCheckList1"
                  @input="buyingAgreeChange(1)"
                />
              </div>
              <v-btn
                class="btn-detail"
                type="icon"
                :icon-class="['icon-open', { active: isActive(8) }]"
                @click="setActive(8)"
                ><span class="offscreen">상세보기</span></v-btn
              >
            </div>
            <div v-if="isActive(8)" class="detail-info">
              <div class="table-area">
                <div class="table-top">
                  <strong class="title">교환&middot;환불 중재 제도 요지</strong>
                </div>
                <table>
                  <colgroup>
                    <col width="150px" />
                    <col width="auto" />
                  </colgroup>
                  <!-- 2021.04.13 (ver1.6) t-left 클래스 추가 -->
                  <tbody class="t-left">
                    <tr>
                      <th>중재의 정의</th>
                      <td>
                        “중재”는 분쟁 당사자들간의 합의로 그들의 분쟁을 중립적 사람(중재위원) 또는 중재부(중제관정부)의
                        결정(중재판정)에 의하여 해결하고 그 결정에 구속되는 분쟁해결절차를 말합니다.
                      </td>
                    </tr>
                    <tr>
                      <th>중재합의</th>
                      <td>
                        ① “중재합의＂는 당사자 간에 이미 발생했거나 발생이 예상되는 분쟁의 전부 또는 일부를 중재에
                        의하여 해결하도록 하는 당사자 간의 합의를 말합니다.<br />② 자동차 교환ㆍ환불 중재 규정(이하
                        “중재규정“이라 함)이 적용되는 중재합의는 양 당사자 모두가 자동차관리법 제47조의 4 제1항에 따라
                        중재규정을 수락했을 때 성립합니다.
                      </td>
                    </tr>
                    <tr>
                      <th>중재합의의<br />성립과 효과</th>
                      <td>
                        ① 자동차관리법 제47조의 4 제1항에 따라 제작자가 사전에 중재규정을 수락하였고, 또한 동 제작자가
                        제작한 차량의 구매자가 매매계약을 체결할 때 또는 교환ㆍ환불 중재를 신청할 때 중재규정을 수락한
                        경우, 자동차 교환ㆍ환불 중재합의가 성립된 것으로 간주됩니다.<br />② 제1항에 따라 자동차
                        교환ㆍ환불 중재합의가 성립되면 양 당사자는 동일한 내용의 교환ㆍ환불을 이유로 법원에 소송을
                        제기할 수 없습니다.<br />③ 제1항에 따라 자동차 교환ㆍ환불 중재합의가 성립되면 1985년
                        ‘외국중재판정의 승인 및 집행에 관한 뉴욕 협약’ 제2조에 규정된 승인 및 집행의 요건으로서 중재에
                        대한 서면 합의 요건을 충족하는 것으로 봅니다.
                      </td>
                    </tr>
                    <tr>
                      <th>중재판정의 효력</th>
                      <td>중재판정은 제작자와 소유자에 대하여 법원의 확정판결과 동일한 효력이 있습니다.</td>
                    </tr>
                  </tbody>
                </table>
              </div>
              <div class="table-area">
                <div class="table-top">
                  <strong class="title">중요 안내 사항</strong>
                </div>
                <table>
                  <colgroup>
                    <col width="150px" />
                    <col width="auto" />
                  </colgroup>
                  <!-- 2021.04.13 (ver1.6) t-left 클래스 추가 -->
                  <tbody class="t-left">
                    <tr>
                      <th>자동차 교환ㆍ환불 중재 규정을 수락한 사실</th>
                      <td>
                        “중재”는 분쟁 당사자들간의 합의로 그들의 분쟁을 중립적 사람(중재위원) 또는 중재부(중제관정부)의
                        결정(중재판정)에 의하여 해결하고 그 결정에 구속되는 분쟁해결절차를 말합니다.
                      </td>
                    </tr>
                    <tr>
                      <th>신차로의 교환ㆍ환불 보장</th>
                      <td>
                        현대자동차는 자동차관리법 제47조 제1항 및 자동차관리법 제47조의 7 제2항에 따른 자동차 안전ㆍ하자
                        심의위원회가 제정한 교환ㆍ환불 중재 규정(이하 “중재규정”이라 칭함)을 수락하였음을 알려드립니다.
                      </td>
                    </tr>
                    <tr>
                      <th>인도날짜</th>
                      <td>
                        ① “중재합의＂는 당사자 간에 이미 발생했거나 발생이 예상되는 분쟁의 전부 또는 일부를 중재에
                        의하여 해결하도록 하는 당사자 간의 합의를 말합니다.<br />② 자동차 교환ㆍ환불 중재 규정(이하
                        “중재규정” 이라 칭함)이 적용되는 중재합의는 양 당사자 모두가 자동차관리법 제47조의 제1항에 따라
                        중재규정을 수락했을 때 성립합니다.
                      </td>
                    </tr>
                    <tr>
                      <th>통지방법</th>
                      <td>
                        현대자동차는 자동차관리법 제47조 제1항 및 자동차관리법 제47조의 7 제2항에 따른 자동차 안전ㆍ하자
                        심의위원회가 제정한 교환ㆍ환불 중재 규정(이하 “중재규정”이라 칭함)을 수락하였음을 알려드립니다.
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
              <div class="agree-box">
                <strong class="title">하자재발통보</strong>
                <v-checkbox
                  v-model="checkDefect"
                  class="check-list"
                  :custom-label="true"
                  :data="checkDefectList"
                  @change="buyingInnerCheck(1)"
                >
                  <template slot-scope="props"
                    ><span>{{ props.item.label }}</span
                    ><span v-html="props.item.text"></span
                  ></template>
                </v-checkbox>
              </div>
              <div class="agree-box">
                <strong class="title"
                  >본인은 자동차 교환ㆍ환불 중재 규정에 대한 수락 시점을 다음 중에서 선택합니다.</strong
                >
                <v-radio v-model="radioDefect" :data="radioDefectList" @change="buyingInnerCheck(1)" />
                <v-checkbox :one-check="true" :checked.sync="checkDefect2" @change="buyingInnerCheck(1)"
                  >본인은 자동차 교환ㆍ환불 중재 규정에 따른 통지 및 연락을 전자우편, 문자메시지, 팩스 등을 통해
                  받겠습니다.<br />(미동의 시 직접 교부, 등기우편 등 발송 및 수취를 증명할 수 있는 우편방법
                  이용)</v-checkbox
                >
              </div>
            </div>
          </section>

          <!-- 특별주문차량 구매 동의 -->
          <section class="information-detail">
            <div class="summary-info">
              <h1 class="title full">특별주문차량 구매 동의</h1>
              <div class="right">
                <!-- 2021.04.13 (ver1.6) agree 클래스 추가 -->
                <v-radio
                  v-model="buyingAgreeCheckVal[1]"
                  class="radio-round-button agree"
                  type="button"
                  :data="buyingCheckList2"
                  @input="buyingAgreeChange(2)"
                />
              </div>
              <v-btn
                class="btn-detail"
                type="icon"
                :icon-class="['icon-open', { active: isActive(9) }]"
                @click="setActive(9)"
                ><span class="offscreen">상세보기</span></v-btn
              >
            </div>
            <div v-if="isActive(9)" class="detail-info">
              <div class="info-grid-list">
                <v-checkbox :one-check="true" :checked.sync="checkSpecial" @change="buyingInnerCheck(2)"
                  >본인은 아래 표에 기재되어 있는 특별주문차량의 생산 요청을 최종 확인합니다.</v-checkbox
                >
                <ul>
                  <li>
                    <strong class="info-title">차종</strong>
                    <div class="info-group">AX 자가용 5인승 가솔린 1.6 2WD IVT Smart</div>
                  </li>
                  <li>
                    <strong class="info-title">계약일시</strong>
                    <div class="info-group">2021년 1월 19일</div>
                  </li>
                  <li>
                    <strong class="info-title">주문요청일시</strong>
                    <div class="info-group">2021년 1월 20일</div>
                  </li>
                  <li>
                    <strong class="info-title">외장칼라</strong>
                    <div class="info-group">팬텀 블랙</div>
                  </li>
                  <li>
                    <strong class="info-title">내장칼라</strong>
                    <div class="info-group">블랙 모노톤(블랙시트)</div>
                  </li>
                  <li>
                    <strong class="info-title">계약번호</strong>
                    <div class="info-group">A3721CN000022</div>
                  </li>
                  <li>
                    <strong class="info-title">옵션</strong>
                    <div class="info-group">
                      <em class="full">[선택옵션]</em>
                      <ul>
                        <li>개별 옵션- 옵션 1, 옵션 2, 옵션 3</li>
                        <li>패키지- 옵션 1, 옵션 2, 옵션 3</li>
                        <li>TUIX – 옵션 1, 옵션 2, 옵션 3</li>
                      </ul>
                    </div>
                  </li>
                </ul>
              </div>
              <v-checkbox
                v-model="checkSpecial2"
                :data="checkSpecialList"
                class="check-list"
                @change="buyingInnerCheck(2)"
              />
            </div>
          </section>

          <!-- 판촉차량 구매 동의 -->
          <section class="information-detail">
            <div class="summary-info">
              <h1 class="title full">판촉차량 구매 동의</h1>
              <div class="right">
                <!-- 2021.04.13 (ver1.6) 클래스 추가 -->
                <v-radio
                  v-model="buyingAgreeCheckVal[2]"
                  class="radio-round-button agree"
                  type="button"
                  :data="buyingCheckList3"
                  @input="buyingAgreeChange(3)"
                />
              </div>
              <v-btn
                class="btn-detail"
                type="icon"
                :icon-class="['icon-open', { active: isActive(10) }]"
                @click="setActive(10)"
                ><span class="offscreen">상세보기</span></v-btn
              >
            </div>
            <div v-if="isActive(10)" class="detail-info">
              <div class="info-grid-list">
                <v-checkbox :one-check="true" :checked.sync="checkSale" @change="buyingInnerCheck(3)"
                  >본인은 아래 표에 기재되어 있는 현재 주요 문제 내역은 보증수리 불가함을 확인합니다.</v-checkbox
                >
                <ul>
                  <li>
                    <strong class="info-title">차종</strong>
                    <div class="info-group">AX 자가용 5인승 가솔린 1.6 2WD IVT Smart</div>
                  </li>
                  <li>
                    <strong class="info-title">차대번호</strong>
                    <div class="info-group">KMHGR41EDKU321360</div>
                  </li>
                  <li>
                    <strong class="info-title">생산일자</strong>
                    <div class="info-group">2021년 1월 20일</div>
                  </li>
                  <li>
                    <strong class="info-title">차량금액</strong>
                    <div class="info-group">41,610,000 원</div>
                  </li>
                  <li>
                    <strong class="info-title">판촉 할인금액</strong>
                    <div class="info-group">22,000,000 원</div>
                  </li>
                  <li>
                    <strong class="info-title">할인사유</strong>
                    <div class="info-group">등록환입 | 엔진, 변속기, ECM 교환</div>
                  </li>
                  <li>
                    <strong class="info-title">현 주요문제</strong>
                    <div class="info-group">
                      <ul>
                        <li>본네트 교환</li>
                        <li>앞펜더: 우 교환</li>
                        <li>실내/시트 오염</li>
                        <li>바닥 낙진 및 스크래치</li>
                        <li>엔진 교환 및 LH FRT BPR 긁힘</li>
                      </ul>
                    </div>
                  </li>
                </ul>
              </div>
              <v-checkbox v-model="checkSale2" class="check-list" :data="checkSaleList" @change="buyingInnerCheck(3)" />
            </div>
          </section>

          <!-- 전시차량 구매 동의 -->
          <section class="information-detail">
            <div class="summary-info">
              <h1 class="title full">전시차량 구매 동의</h1>
              <div class="right">
                <!-- 2021.04.13 (ver1.6) 클래스 추가 -->
                <v-radio
                  v-model="buyingAgreeCheckVal[3]"
                  class="radio-round-button agree"
                  type="button"
                  :data="buyingCheckList4"
                  @input="buyingAgreeChange(4)"
                />
              </div>
              <v-btn
                class="btn-detail"
                type="icon"
                :icon-class="['icon-open', { active: isActive(11) }]"
                @click="setActive(11)"
                ><span class="offscreen">상세보기</span></v-btn
              >
            </div>
            <div v-if="isActive(11)" class="detail-info">
              <div class="info-grid-list">
                <v-checkbox :one-check="true" :checked.sync="checkDisplay" @change="buyingInnerCheck(4)"
                  >아래 명시된 차량은 [테헤란] 지점 전시 차량임을 확인합니다.</v-checkbox
                >
                <ul>
                  <li>
                    <div class="info-title">차종</div>
                    <div class="info-group">AX 자가용 5인승 가솔린 1.6 2WD IVT Smart</div>
                  </li>
                  <li>
                    <div class="info-title">차대번호</div>
                    <div class="info-group">KMHGR41EDKU321360</div>
                  </li>
                  <li>
                    <div class="info-title">생산일자</div>
                    <div class="info-group">2021년 1월 20일</div>
                  </li>
                  <li>
                    <div class="info-title">차량상태</div>
                    <div class="info-group">바닥 낙진 및 스크래치</div>
                  </li>
                </ul>
              </div>
              <v-checkbox
                class="check-list"
                :one-check="true"
                :checked.sync="checkDisplay2"
                @change="buyingInnerCheck(4)"
                >본인은 귀사의 전시차량의 상태 및 특이사항에 대하여 충분히 숙지하고 확인하였습니다.</v-checkbox
              >
            </div>
          </section>

          <!-- 직원 차량의무보유기간 준수 동의 -->
          <section class="information-detail">
            <div class="summary-info">
              <h1 class="title full">직원 차량의무보유기간 준수 동의</h1>
              <div class="right">
                <!-- 2021.04.13 (ver1.6) agree 클래스 추가 -->
                <v-radio
                  v-model="buyingAgreeCheckVal[4]"
                  class="radio-round-button agree"
                  type="button"
                  :data="buyingCheckList5"
                  @input="buyingAgreeChange(5)"
                />
              </div>
              <v-btn
                class="btn-detail"
                type="icon"
                :icon-class="['icon-open', { active: isActive(12) }]"
                @click="setActive(12)"
                ><span class="offscreen">상세보기</span></v-btn
              >
            </div>
            <div v-if="isActive(12)" class="detail-info">
              <div class="info-grid-list">
                <v-checkbox :one-check="true" :checked.sync="checkStaff" @change="buyingInnerCheck(5)"
                  >본인은 아래 표에 기재되어 있는 임직원용 차량 정보를 최종 확인합니다.</v-checkbox
                >
                <ul>
                  <li>
                    <strong class="info-title">차종</strong>
                    <div class="info-group">AX 자가용 5인승 가솔린 1.6 2WD IVT Smart</div>
                  </li>
                  <li>
                    <strong class="info-title">차량가격</strong>
                    <div class="info-group">10,000,000원</div>
                  </li>
                  <li>
                    <strong class="info-title">직원용 할인액</strong>
                    <div class="info-group">600,000원</div>
                  </li>
                </ul>
              </div>
              <v-checkbox
                v-model="checkStaff2"
                class="check-list"
                :custom-label="true"
                :data="checkStaffList"
                @change="buyingInnerCheck(5)"
              >
                <template slot-scope="props"
                  ><span>{{ props.item.label }}</span
                  ><span v-html="props.item.text"></span
                ></template>
              </v-checkbox>
            </div>
          </section>
        </div>
      </div>
    </div>

    <!-- 자동차 소유(예정)자 본인확인 -->
    <!-- 2021.04.13 (ver1.6) identification 클래스 삭제 -->
    <!-- <div class="matching-box identification"> -->
      <div class="matching-box">
      <div class="box-wrap">
        <div class="box-tit">자동차<br />소유(예정)자<br />본인확인</div>
        <div class="box-desc">
          <!-- 2021.04.13 (ver1.6) 삭제 -->
          <!-- <section class="information-detail">
            <div class="summary-info"><h1 class="title full">자동차 소유(예정)자 본인확인</h1>
              <v-checkbox :one-check="true" :checked.sync="contractCheck" class="right"
                >배우자 단독명의 계약</v-checkbox
              >
            </div>
            <div class="detail-info">
              <el-form ref="form">
                <div class="form-grid-list">
                  <ul>
                    <li>
                      <div class="form-label">성명</div>
                      <div class="form-group">
                        <div class="label-input inbl-wrap">
                          <label class="offscreen">성명</label>
                          <v-input v-model="userName" :disabled="true" />
                        </div>
                      </div>
                    </li>
                    <li>
                      <div class="form-label">주민등록 번호</div>
                      <div class="form-group">
                        <div class="inbl-wrap">
                          <div class="label-input">
                            <label class="offscreen">주민등록 앞자리</label>
                            <v-input v-model="socialNmber1" maxlength="6" :disabled="true" />
                          </div>
                          <div class="label-input">
                            <label class="offscreen">주민등록 뒷자리</label>
                            <v-input v-model="socialNmber2" type="number" maxlength="7" placeholder="7자리" />
                          </div>
                        </div>
                        <v-btn class="btn-more">본인확인</v-btn>
                      </div>
                    </li>
                  </ul>
                </div>
              </el-form>
              <ul class="bullet-list">
                <li>본인의 주민번호 뒷자리를 입력해 주세요.</li>
                <li>
                  개명 등으로 표시된 정보와 다를 경우 회원정보에서 먼저 정보를 변경한 후 계약을 진행해 주시기 바랍니다.
                </li>
                <li>
                  배우자 단독명의 계약을 진행하시려면 '배우자 단독명의 계약'에 체크하시고 배우자 성명과 주민등록번호를
                  입력해 주세요.<br />배우자 단독명의 계약은 변경할 수 없고, 취소만 가능합니다.
                </li>
                <li>외국인의 경우, 주민등록번호 대신 외국인 등록번호 13자리를 입력해 주세요.</li>
              </ul>
            </div>
          </section> -->

          <!-- 2021.04.13 (ver1.6) 추가 -->
          <el-form ref="form" :model="step1Form" :rules="rules">
            <div class="form-grid-list">
              <ul>
                <li>
                  <v-checkbox :one-check="true" :checked.sync="contractCheck">배우자 단독명의 계약</v-checkbox>
                </li>
                <li>
                  <div class="form-label">성명</div>
                  <div class="form-group">
                    <el-form-item prop="userName">
                      <div class="label-input inbl-wrap">
                        <label class="offscreen">성명</label>
                        <v-input v-model="step1Form.userName" :disabled="true" />
                        <v-btn class="btn line blue r md">본인확인</v-btn>
                      </div>
                    </el-form-item>
                  </div>
                </li>
                <li>
                  <div class="form-label">주민등록 번호</div>
                  <div class="form-group">
                    <div class="inbl-wrap">
                      <el-form-item prop="socialNmber1">
                        <div class="label-input">
                          <label class="offscreen">주민등록 앞자리</label>
                          <v-input v-model="step1Form.socialNmber1" maxlength="6" :disabled="true" />
                        </div>
                      </el-form-item>
                      <el-form-item prop="socialNmber2">
                        <div class="label-input">
                          <label class="offscreen">주민등록 뒷자리</label>
                          <v-input v-model="step1Form.socialNmber2" type="number" maxlength="7" placeholder="7자리" />
                        </div>
                      </el-form-item>
                    </div>
                  </div>
                </li>
              </ul>
            </div>
            <ul class="bullet-list">
              <li>본인의 주민번호 뒷자리를 입력해 주세요.</li>
              <li>개명 등으로 표시된 정보와 다를 경우 회원정보에서 먼저 정보를 변경한 후 계약을 진행해 주시기 바랍니다.</li>
              <li>배우자 단독명의 계약을 진행하시려면 '배우자 단독명의 계약'에 체크하시고 배우자 성명과 주민등록번호를 입력해 주세요.<br />배우자 단독명의 계약은 변경할 수 없고, 취소만 가능합니다.</li>
              <li>외국인의 경우, 주민등록번호 대신 외국인 등록번호 13자리를 입력해 주세요.</li>
            </ul>
          </el-form>
        </div>
      </div>
    </div>

    <!-- 자동차 소유(예정) 법인확인 : 추후 작업예정 -->
    <!-- <div class="matching-box identification">
      <div class="box-wrap">
        <div class="box-desc">
          <section class="information-detail">
            <div class="summary-info">
              <h1 class="title full">자동차 소유(예정) 법인확인</h1>
            </div>
            <div class="detail-info">
              <el-form ref="form2" :rules="rules">
                <div class="form-grid-list">
                  <ul>
                    <li>
                      <div class="form-label">사업자번호</div>
                      <div class="form-group">
                        <el-form-item prop="corporateNmber" class="inbl-wrap">
                          <div class="label-input">
                            <label class="offscreen">사업자번호 앞자리</label>
                            <v-input v-model="corporateNmber1" type="number" maxlength="3" />
                          </div>
                          <div class="label-input">
                            <label class="offscreen">사업자번호 둘째자리</label>
                            <v-input v-model="corporateNmber2" type="number" maxlength="2" />
                          </div>
                          <div class="label-input">
                            <label class="offscreen">사업자번호 셋째자리</label>
                            <v-input v-model="corporateNmber3" type="number" maxlength="5" />
                          </div>
                        </el-form-item>
                      </div>
                    </li>
                    <li>
                      <div class="form-label">상호명</div>
                      <div class="form-group">
                        <el-form-item prop="corporateName">
                          <div class="label-input inbl-wrap">
                            <label class="offscreen">상호명</label>
                            <v-input v-model="corporateName" />
                          </div>
                        </el-form-item>
                      </div>
                    </li>
                    <li>
                      <div class="form-label">업태</div>
                      <div class="form-group">
                        <el-form-item prop="corporateType1">
                          <v-select v-model="corporateType1" :data="corporateTypeList" class="lg" />
                        </el-form-item>
                      </div>
                    </li>
                    <li>
                      <div class="form-label">종목</div>
                      <div class="form-group">
                        <el-form-item prop="corporateType2">
                          <div class="label-input inbl-wrap">
                            <label class="offscreen">종목</label>
                            <v-input v-model="corporateType2" />
                          </div>
                        </el-form-item>
                      </div>
                    </li>
                  </ul>
                </div>
              </el-form>
            </div>
          </section>
        </div>
      </div>
    </div> -->

    <div class="btn-wrap">
      <v-btn class="btn lg blue r" type="button">다음</v-btn>
    </div>

    <!-- 개인정보동의 전체동의 팝업 -->
    <agree-personal-data
      :visible="popVisible.agreePersonalData"
      @close="popVisible.agreePersonalData = false"
    ></agree-personal-data>

    <!-- 구매동의 전체동의 팝업 -->
    <agree-purchase :visible="popVisible.agreePurchase" @close="popVisible.agreePurchase = false"></agree-purchase>
  </div>
</template>
<script>
import AgreePersonalData from '~/components/page/contract/popup/AgreePersonalData'
import AgreePurchase from '~/components/page/contract/popup/AgreePurchase'
export default {
  components: {
    AgreePersonalData,
    AgreePurchase
  },
  data() {
    return {
      isOptionsShow: '',
      agreeCheck: false,
      buyingAgreeCheck: false,
      agreeCheckVal: Array(8).fill(false),
      buyingAgreeCheckVal: Array(5).fill(false),
      checkList1: [
        { value: 'noagree', label: '동의안함' },
        { value: 'agree', label: '동의' }
      ],
      checkList2: [
        { value: 'noagree', label: '동의안함' },
        { value: 'agree', label: '동의' }
      ],
      checkList3: [
        { value: 'noagree', label: '동의안함' },
        { value: 'agree', label: '동의' }
      ],
      checkList4: [
        { value: 'noagree', label: '동의안함' },
        { value: 'agree', label: '동의' }
      ],
      checkList5: [
        { value: 'noagree', label: '동의안함' },
        { value: 'agree', label: '동의' }
      ],
      checkList6: [
        { value: 'noagree', label: '동의안함' },
        { value: 'agree', label: '동의' }
      ],
      checkList7: [
        { value: 'noagree', label: '동의안함' },
        { value: 'agree', label: '동의' }
      ],
      buyingCheckList1: [
        { value: 'noagree', label: '동의안함' },
        { value: 'agree', label: '동의' }
      ],
      buyingCheckList2: [
        { value: 'noagree', label: '동의안함' },
        { value: 'agree', label: '동의' }
      ],
      buyingCheckList3: [
        { value: 'noagree', label: '동의안함' },
        { value: 'agree', label: '동의' }
      ],
      buyingCheckList4: [
        { value: 'noagree', label: '동의안함' },
        { value: 'agree', label: '동의' }
      ],
      buyingCheckList5: [
        { value: 'noagree', label: '동의안함' },
        { value: 'agree', label: '동의' }
      ],

      step1Form: {
        userName: '홍길동',
        socialNmber1: '210131',
        socialNmber2: '',
      },

      corporateNmber1: '',
      corporateNmber2: '',
      corporateNmber3: '',
      corporateName: '',
      corporateType1: '',
      corporateTypeList: [
        { value: 'Type1', label: '업태1' },
        { value: 'Type2', label: '업태2' },
        { value: 'Type3', label: '업태3' },
        { value: 'Type4', label: '업태4' }
      ],
      corporateType2: '',

      contractCheck: false,
      checkboxAll: [],
      checkboxAllList: [
        { value: 'check1', label: '문자(SMS)' },
        { value: 'check2', label: '이메일' },
        { value: 'check3', label: '우편(DM)' },
        { value: 'check4', label: '휴대폰/전화' }
      ],

      popVisible: {
        agreePersonalData: false,
        agreePurchase: false
      },

      // 구매동의 - 자동차 교환ㆍ환불 중재제도 설명에 대한 이해 및 수락여부 확인
      checkDefect: [],
      checkDefectList: [
        {
          value: 'defect1',
          label: '등기우편 : 서울 동작구 노량진로53 현대자동차 고객센터',
          text:
            '<br />전자우편 : 현대자동차 홈페이지<a href="http://www.hyundai.com" target="_blank" title="새창열기">(http://www.hyundai.com)</a> 또는 제네시스 홈페이지<a href="http://www/genesis.com" target="_blank" title="새창열기">(http://www/genesis.com)</a><br />하자재발통보서 접수'
        },
        {
          value: 'defect2',
          label: '대표(수신인) : 현대자동차 고객센터'
        },
        {
          value: 'defect3',
          label:
            '본인은 자동차 교환ㆍ환불 중재 제도 요지 및 중요 안내 사항을 읽고 숙지하여 충분히 이해하였음을 확인합니다.'
        }
      ],
      radioDefect: false,
      radioDefectList: [
        { value: 'rdDefect1', label: '추후 중재 신청 시 수락하겠습니다' },
        { value: 'rdDefect2', label: '지금 수락하겠습니다. (수락 시점 이후 법원에 소송제기 불가)' }
      ],
      checkDefect2: false,

      // 구매동의 - 특별주문차량
      checkSpecial: false,
      checkSpecial2: [],
      checkSpecialList: [
        { value: 'special1', label: '본인은 상기 특별주문차량의 생산 요청을 최종 확인합니다.' },
        {
          value: 'special2',
          label:
            '‘전자상거래법 시행령 제21조’에 의거 상기 본인이 주문 요청한 특별주문생산 차량은 청약철회가 제한됨을 확인합니다.'
        },
        {
          value: 'special3',
          label:
            '청약철회 제한에도 불구하고 본인은 계약을 해제할 수 있으며, ‘전자상거래법 제19조’에 의거 계약 해지 시 위약금 10만원이 발생됨을 확인합니다.'
        },
        {
          value: 'special4',
          label:
            '본인이 금번 계약으로 납부한 계약금 10만원은 계약 해지 시 환불되지 않으며, 발생한 위약금 10만원으로 대체 납부한다는 사실을 확인합니다.'
        }
      ],

      // 구매동의 - 판촉차량
      checkSale: false,
      checkSale2: [],
      checkSaleList: [
        {
          value: 'sale1',
          label:
            '본인은 귀사의 차량 판매가격에서 ￦0,000,000원을 할인(판매가격의 11.5%) 받아 기재된 현재 주요문제 내역을 귀사로부터 매수할 당시 귀사와 본인이 인정하여 상호 합의한 문제부위에 대해서는 귀사의 약관 제7조에서 정한 보증수리 책임을 청구하지 않음은 물론, 동 약관 각 조항에서 정한 귀사의 하자담보 책임과 관련한 일체 민ㆍ형사상의 항변권을 포기할 것을 동의합니다.'
        },
        {
          value: 'sale2',
          label:
            '상기 차량을 제 3자에게 양도하는 경우 문제내역 고지 및 해당 문제에 대한 보증수리가 불가함을 통지할 의무가 있으며, 이러한 의무를 해태하여 귀사가 손해를 입는 경우 일체 손해를 배상하도록 하겠습니다.'
        }
      ],

      // 구매동의 - 전시차량
      checkDisplay: false,
      checkDisplay2: false,

      // 구매동의 - 직원
      checkStaff: false,
      checkStaff2: [],
      checkStaffList: [
        {
          value: 'staff1',
          label:
            '1항) 임직원 복지 차원에서 회사가 규정한대로 근속년수 및 직원용 타겟 조건에 따른 할인을 받아 차량을 구입한 임직원은 본인(배우자 포함) 명의로 차량등록을 하여야 하며, 차량출고일로부터 2년 간 제3자에게 명의를 이전하지 않는다.',
          text:
            '*예) 2017-02-15 출고, 2019-02-15부터 명의변경/매각/재출고 가능, 보유기간 종료일이 법정휴일인 경우 해당일에 이은 첫번째 평일부터 가능'
        },
        {
          value: 'staff2',
          label:
            '2항) 임직원의 개인사정으로 인해 출고일로부터 2년 내 부득이하게 차량을 타인 명의로 이전할 필요가 생긴 경우에는 사전에 회사에 서면 신고를 한 후 승인을 득하여야 하며, 사전신고를 한 임직원의 경우에는 직원용 할인액 중 잔여보유기간에 해당하는 비율만큼의 할인액을 현금 일시불로 회사에 반환하여야 한다.',
          text: '* 반환해야 할 할인액 = 직원용 할인액 x 잔여일수/730일(2년)'
        },
        {
          value: 'staff3',
          label:
            '3항) 본인명의로 차량등록 후 사전신고 없이 타인명의로 이전을 하거나, 미등록상태에서 차량을 타인에게 전매한 경우에는 할인액 전액을 현금 일시불로 회사에 반납하여야 한다. (할인액의 반환과는 별도로 회사는 의무보유기간 지침을 위반한 임직원에 한해 징계를 할 수 있다.)'
        },
        {
          value: 'staff4',
          label:
            '4항) 제2항의 경우 사전신고일 다음날로부터 그리고 제3항의 경우 의무보유기간의 준수를 위반한 날로부터 할인액을 반환할 의무를 부담한다.'
        },
        {
          value: 'staff5',
          label:
            '5항) 별도의 약정이 없는 경우 지연손해는 위 제4항의 각 날로부터 차량매매계약 당시 계약서상의 지연손해배상규정이율에 의해 계산한다.'
        },
        { value: 'staff6', label: '6항) 기타 세부사항은 공지된 회사 임직원 차량 판매지침에 따른다.' }
      ]
    }
  },


  computed: {
    rules() {
      return {
         // 2021.04.09 추가
         userName: [
          {
            required: true,
            message: '* 주민등록번호를 입력해 주세요',
            trigger:  ['blur', 'change']
          }
        ],
        socialNmber1: [
          {
            required: true,
            message: '* 주민등록번호를 입력해 주세요',
            trigger:  ['blur', 'change']
          }
        ],
        socialNmber2: [
          {
            required: true,
            message: '* 주민등록번를 입력해 주세요',
            trigger:  ['blur', 'change']
          }
        ],

        corporateNmber: [
          {
            required: true,
            message: '* 사업자번호를 입력해 주세요',
            trigger: 'blur'
          }
        ],
        corporateName: [
          {
            required: true,
            message: '* 상호명을 입력해주세요.',
            trigger: 'blur'
          }
        ],
        corporateType1: [
          {
            required: true,
            message: '* 사업자등록 상 업태를 1개만 입력해 주세요.',
            trigger: 'blur'
          }
        ],
        corporateType2: [
          {
            required: true,
            message: '* 사업자등록 상 종목을 1개만 입력해 주세요.',
            trigger: 'blur'
          }
        ]
      }
    }
  },
  mounted() {
    this.setLabel((idg) => {
      // console.dir(idg) // 자동 생성된 ID 배열
    })
  },
  updated() {
    this.setCaption()
  },
  methods: {
    allAgree(agreeType) {
      if (agreeType === 'privacy') {
        this.agreeCheckVal = ['agree', 'agree', 'agree', 'agree', 'agree', 'agree', 'agree']
        this.agreeCheck = true
        this.popVisible.agreePersonalData = true
        // 2021.04.09 (ver) 삭제
        // this.agreeChange(7, 'agree')
      } else if (agreeType === 'buying') {
        this.buyingAgreeCheckVal = ['agree', 'agree', 'agree', 'agree', 'agree']
        this.buyingAgreeCheck = true
        this.popVisible.agreePurchase = true
        this.buyingAgreeChange(1, 'agree')
        this.buyingAgreeChange(2, 'agree')
        this.buyingAgreeChange(3, 'agree')
        this.buyingAgreeChange(4, 'agree')
        this.buyingAgreeChange(5, 'agree')
      }
    },
    agreeChange(type, agree) {
      let agreeChk = []
      this.agreeCheckVal.forEach((value, index) => {
        if (value === 'noagree') {
          this.agreeCheck = false
          return
        } else if (value === 'agree') {
          agreeChk.push('agree')
        }
      })
      if (agreeChk.length == this.agreeCheckVal.length) {
        this.agreeCheck = true
      }
      // 2021.04.09 (ver1.6) 삭제
      //inner check 정보수신방법
      // if (type === 7) {
      //   if (this.agreeCheckVal[type - 1] === 'agree' || agree === 'agree') {
      //     let val = []
      //     this.checkboxAllList.forEach((value, index) => {
      //       val.push(value.value)
      //       if (this.checkboxAllList.length === val.length) {
      //         val.unshift('all')
      //       }
      //     })
      //     this.checkboxAll = val
      //   } else {
      //     this.checkboxAll = []
      //   }
      // }
    },

    // 2021.04.09 (ver1.6) buyingAllAgreeCheck 추가
    buyingAllAgreeCheck(){
      let agreeChk = []
      this.buyingAgreeCheckVal.forEach((value, index) => {
        if (value === 'noagree' || value === false) {
          this.buyingAgreeCheck = false
          return
        } else if (value === 'agree') {
          agreeChk.push('agree')
        }
      })
      if (agreeChk.length == this.buyingAgreeCheckVal.length) {
        this.buyingAgreeCheck = true
      }
    },
    buyingAgreeChange(type, agree) {
      this.buyingAllAgreeCheck()
      //inner check
      if (type === 1) {
        if (this.buyingAgreeCheckVal[type - 1] === 'agree' || agree === 'agree') {
          this.checkListAllCheck('checkDefectList', 'checkDefect')
          this.radioDefect = 'rdDefect1'
          this.checkDefect2 = true
        } else {
          this.checkDefect = []
          this.radioDefect = false
          this.checkDefect2 = false
        }
      } else if (type === 2) {
        if (this.buyingAgreeCheckVal[type - 1] === 'agree' || agree === 'agree') {
          this.checkSpecial = true
          this.checkListAllCheck('checkSpecialList', 'checkSpecial2')
        } else {
          this.checkSpecial = false
          this.checkSpecial2 = []
        }
      } else if (type === 3) {
        if (this.buyingAgreeCheckVal[type - 1] === 'agree' || agree === 'agree') {
          this.checkSale = true
          this.checkListAllCheck('checkSaleList', 'checkSale2')
        } else {
          this.checkSale = false
          this.checkSale2 = []
        }
      } else if (type === 4) {
        if (this.buyingAgreeCheckVal[type - 1] === 'agree' || agree === 'agree') {
          this.checkDisplay = true
          this.checkDisplay2 = true
        } else {
          this.checkDisplay = false
          this.checkDisplay2 = false
        }
      } else if (type === 5) {
        if (this.buyingAgreeCheckVal[type - 1] === 'agree' || agree === 'agree') {
          this.checkStaff = true
          this.checkListAllCheck('checkStaffList', 'checkStaff2')
        } else {
          this.checkStaff = false
          this.checkStaff2 = []
        }
      }
    },
    innerCheck(number) {
      if (number === 7) {
        //선택적 개인정보 수집 · 이용 및 광고성 정보 수신에 대한 사항 (선택)
        if (this.checkboxAll.length === 0) this.agreeCheckVal[number - 1] = 'noagree'
        else this.agreeCheckVal[number - 1] = 'agree'
      }
    },
    buyingInnerCheck(number) {
      if (number === 1) {
        //자동차 교환ㆍ환불 중재제도 설명에 대한 이해 및 수락여부 확인
        if (this.checkDefect.length === 0 && this.radioDefect === false && this.checkDefect2 === false) this.buyingAgreeCheckVal[number - 1] = 'noagree'
        else if ( this.checkDefect.length === this.checkDefectList.length && this.radioDefect !== false && this.checkDefect2 ) this.buyingAgreeCheckVal[number - 1] = 'agree'
        else this.buyingAgreeCheckVal[number - 1] = false
      } else if (number === 2) {
        //특별주문차량 구매 동의
        if (!this.checkSpecial && this.checkSpecial2.length === 0) this.buyingAgreeCheckVal[number - 1] = 'noagree'
        else if (this.checkSpecial && this.checkSpecial2.length == this.checkSpecialList.length) this.buyingAgreeCheckVal[number - 1] = 'agree'
        else this.buyingAgreeCheckVal[number - 1] = false
      } else if (number === 3) {
        //판촉차량 구매 동의
        if (!this.checkSale && this.checkSale2.length === 0) this.buyingAgreeCheckVal[number - 1] = 'noagree'
        else if (this.checkSale && this.checkSale2.length == this.checkSaleList.length) this.buyingAgreeCheckVal[number - 1] = 'agree'
        else this.buyingAgreeCheckVal[number - 1] = false
      } else if (number === 4) {
        //전시차량 구매 동의
        if (!this.checkDisplay && !this.checkDisplay2) this.buyingAgreeCheckVal[number - 1] = 'noagree'
        else if (this.checkDisplay && this.checkDisplay2) this.buyingAgreeCheckVal[number - 1] = 'agree'
        else this.buyingAgreeCheckVal[number - 1] = false
      } else if (number === 5) {
        //직원 차량의무보유기간 준수 동의
        if (!this.checkStaff && this.checkStaff2.length === 0) this.buyingAgreeCheckVal[number - 1] = 'noagree'
        else if (this.checkStaff && this.checkStaff2.length == this.checkStaffList.length) this.buyingAgreeCheckVal[number - 1] = 'agree'
        else this.buyingAgreeCheckVal[number - 1] = false
      }

      this.buyingAllAgreeCheck()
    },
    checkListAllCheck(list, value) {
      let val = []
      this[list].forEach((value) => {
        val.push(value.value)
      })
      this[value] = val
    },
    setActive(index) {
      if (this.isOptionsShow == index) {
        this.isOptionsShow = 0
      } else {
        this.isOptionsShow = index
      }
    },
    isActive(index) {
      return this.isOptionsShow == index
    }
  },

}
</script>
