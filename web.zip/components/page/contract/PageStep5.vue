<!-- 2021.03.31 STEP 삭제 -->
<template>
  <!-- 2021.03.23 (ver1.3) step5 클래스 추가 -->
  <div class="page-step step5">
    <div class="purchase-wrap">
      <!-- 2021.03.23 (ver1.3) payment-info 클래스 삭제 -->
      <!-- <div class="purchase-info payment-info"> -->
      <div class="purchase-info">
        <!--  차량정보 -->
        <section class="information-detail">
          <div class="summary-info">
            <h1 class="title">차량정보</h1>
            <div class="total-price">총 차량금액 <span class="price">20,811,832</span> 원</div>
          </div>
          <div class="detail-info">
            <div class="info-grid-list">
              <ul>
                <li>
                  <strong class="info-title bold">모델</strong>
                  <div class="info-group">
                    <div class="model">
                      <p>X 스마트스트림 가솔린 1.1 터보 프리미엄 밀레니얼 A/T</p>
                      <p>배기량 1600CC <span>평균연비 15km/ℓ</span></p>
                    </div>
                    <span class="price">33,000,000 원</span>
                  </div>
                </li>
                <li>
                  <strong class="info-title bold">색상</strong>
                  <div class="info-group">
                    <ul class="desc-list">
                      <li>
                        <em class="ct">외장색상</em>
                        <ul class="color-list">
                          <li>
                            <div class="color">
                              <div class="color-sample" :style="`background-image:url(${outColor.src})`"></div>
                              <div class="color-txt">{{ outColor.txt }}</div>
                            </div>
                          </li>
                        </ul>
                        <span class="price">{{ outColor.price }} 원</span>
                      </li>
                      <li>
                        <em class="ct">내장색상</em>
                        <ul class="color-list">
                          <li>
                            <div class="color">
                              <div class="color-sample" :style="`background-image:url(${inColor.src})`"></div>
                              <div class="color-txt">{{ inColor.txt }}</div>
                            </div>
                          </li>
                        </ul>
                        <span class="price">{{ inColor.price }} 원</span>
                      </li>
                    </ul>
                  </div>
                </li>
                <li>
                  <strong class="info-title bold">선택품목</strong>
                  <div class="info-group">
                    <ul class="desc-list">
                      <li v-for="(item, index) in optList" :key="index">
                        <p>{{ item.opt }}</p>
                        <span class="price">{{ item.price }} 원</span>
                      </li>
                    </ul>
                  </div>
                </li>
                <li>
                  <strong class="info-title bold">H Genuine<br />Accessories</strong>
                  <div class="info-group">
                    <ul class="desc-list">
                      <li v-for="(item, index) in hgList" :key="index">
                        <p>{{ item.opt }}</p>
                        <span class="price">{{ item.price }} 원</span>
                      </li>
                    </ul>
                  </div>
                </li>
                <li>
                  <strong class="info-title bold">N Performance</strong>
                  <div class="info-group">
                    <ul class="desc-list">
                      <li v-for="(item, index) in npList" :key="index">
                        <p>{{ item.opt }}</p>
                        <span class="price">{{ item.price }} 원</span>
                      </li>
                    </ul>
                  </div>
                </li>
              </ul>
            </div>
            <ul class="total-price">
              <li>
                <em>차량 가격</em>
                <span class="price">21,200,000 원</span>
              </li>
              <li>
                <em>세액 감면 혜택</em>
                <span class="price">(-) 380,000 원</span>
              </li>
            </ul>
          </div>
        </section>

        <!-- 인수정보 -->
        <section class="information-detail">
          <div class="summary-info">
            <h1 class="title">
              인수정보
              <v-popover trigger="hover" placement="bottom-start">
                <p v-if="takeoverType">
                  탁송기사가 고객님이 요청하신 장소로 차량을 배달해 드리면 인수 절차를 진행하시면 됩니다.<br />
                  * 탁송료 = 차량이 생산된 공장에서 차량이 위치한 출고센터까지의 배송료 + 차량이 위치했던 출고 센터에서
                  고객님이 요청하신 지역까지의 탁송료<br />
                  정확한 탁송료는 결제 시 탁송지를 입력하실 때 확인하실 수 있으며, 이때 계약 당시의 탁송지역과 다른 경우
                  금액이 변동될 수 있습니다.
                </p>
                <!-- 직접인수 -->
                <p v-else>전시 지점에 직접 방문하여 차량 상태를 확인 후 인수 하셔야 합니다.</p>
                <v-btn slot="reference"><i class="icon-help"></i></v-btn>
              </v-popover>
            </h1>
            <div class="total-price">탁송료 <span class="price">300,000</span> 원</div>
          </div>
          <div class="detail-info simple-list">
            <div class="info-grid-list">
              <ul>
                <li>
                  <strong class="info-title ct">탁송지역</strong>
                  <div class="info-group">
                    <v-select v-model="locationSelected1" :data="locationList1" placeholder="선택" />
                    <v-select
                      v-model="locationSelected2"
                      :data="locationList2"
                      placeholder="시/군/구 선택"
                      :disabled="locationSelected1 == '' ? true : false"
                    />
                  </div>
                </li>
                <li>
                  <div class="info-title">
                    <strong>예상출고일</strong>
                    <v-popover trigger="hover" placement="bottom-start">
                      <p>
                        현 시점 계약완료 기준으로 재고 및<br />생산계획 기반 산출된 예상출고일이며,<br />당사 사정에
                        의하여 변경될 수 있으니<br />단순 참고만 하시기 바랍니다.
                      </p>
                      <v-btn slot="reference"><i class="icon-help"></i></v-btn>
                    </v-popover>
                  </div>
                  <div class="info-group">2021년 4월</div>
                </li>
              </ul>
            </div>
          </div>
        </section>

        <!-- 할인정보 -->
        <section class="information-detail">
          <div class="summary-info">
            <h1 class="title">할인정보</h1>
          </div>
          <!-- PS-MCT_044 공용으로 쓰기 위해 component로 분리 -->
          <sale-point></sale-point>
        </section>

        <!-- 결제예정금액 -->
        <section class="information-detail">
          <div class="summary-info">
            <h1 class="title">결제예정금액</h1>
            <div class="total-price"><span class="price">20,811,832</span> 원</div>
          </div>
          <!-- 2021.03.23 (ver1.3) 클래스 수정 -->
          <div class="detail-info payment-amount">
            <div class="info-grid-list">
              <ul>
                <li>
                  <strong class="info-title">차량금액</strong>
                  <div class="info-group">
                    <span class="price">000,000 원</span>
                  </div>
                </li>
                <!-- 2021.03.23 (ver1.3) 클래스 추가 -->
                <li class="plus">
                  <strong class="info-title">탁송료</strong>
                  <div class="info-group">
                    <span class="price">000,000 원</span>
                  </div>
                </li>
                <!-- 2021.03.23 (ver1.3) 클래스 추가 -->
                <li class="minus">
                  <strong class="info-title">할인금액 합계</strong>
                  <div class="info-group">
                    <span class="price">000,000 원</span>
                  </div>
                </li>
                <!-- 2021.03.23 (ver1.3) 클래스 추가 -->
                <li class="total-price">
                  <!-- 2021.03.29 (ver1.4) 텍스트 수정 -->
                  <strong class="info-title">결제예정금액</strong>
                  <div class="info-group">
                    <!-- 2021.03.23 (ver1.3) 클래스 삭제, 수정 -->
                    <span class="price">000,000</span>&nbsp;원
                  </div>
                </li>
              </ul>
            </div>
          </div>
        </section>
      </div>

      <contract-tool />
    </div>
    <div class="btn-wrap">
      <v-btn class="btn lg gray r">이전</v-btn>
      <v-btn class="btn lg blue r">다음</v-btn>
    </div>
  </div>
</template>

<script>
import SalePoint from '~/components/page/contract/SalePoint'
import ContractTool from '~/components/page/contract/ContractTool'
export default {
  components: {
    SalePoint,
    ContractTool
  },
  data() {
    return {
      inColor: { txt: '메테오 블루', src: require('~/assets/images/temp/temp-color-4.png'), price: '0' },
      outColor: { txt: '쉬머링 실버', src: require('~/assets/images/temp/temp-color-1.png'), price: '100,000' },
      optList: [
        { opt: '인조가죽 시트(인조가죽 도어 센터트림 포함)', price: '100,000' },
        { opt: '인포테인먼트 내비 I', price: '100,000' },
        { opt: '익스테리어 디자인 I', price: '100,000' }
      ],
      hgList: [
        { opt: '1열 방오 시트 커버 + 2열 방오 커버', price: '100,000' },
        { opt: 'ISOFIX 카시트', price: '100,000' },
        { opt: '하네스 ISOFIX 안전벨트 테더', price: '100,000' }
      ],
      npList: [
        { opt: '인테리어 패키지', price: '100,000' },
        { opt: 'N 퍼포먼스 서스펜션', price: '100,000' }
      ],
      takeoverType: true,
      locationSelected1: '',
      locationList1: [
        {
          label: '서울',
          value: '00'
        },
        {
          label: '경기도',
          value: '01'
        },
        {
          label: '강원도',
          value: '02'
        }
      ],
      locationSelected2: '',
      locationList2: [
        {
          label: '서울',
          value: '00'
        },
        {
          label: '경기도',
          value: '01'
        },
        {
          label: '강원도',
          value: '02'
        }
      ]
    }
  }
}
</script>
