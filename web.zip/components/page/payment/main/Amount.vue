<template>
  <section class="information-detail">
    <div class="summary-info">
      <!-- 2021.03.17 (ver1.0) 수정 start -->
      <!-- 2021.04.14 (ver1.3) 띄어쓰기 -->
      <h1 class="title">차량 금액</h1>
      <div class="total-price">
        결제예정 차량금액 <span class="price">20,711,832</span> 원
      </div>
      <!-- end -->
      <v-btn class="btn-detail" type="icon" :icon-class="['icon-open', { active: isOptionsShow} ]" @click="isOptionsShow = !isOptionsShow"><span class="offscreen">상세보기</span></v-btn>
    </div>
    <div v-show="isOptionsShow" class="detail-info" :class="{ active: isOptionsShow }">
      <div class="info-grid-list">
        <ul>
          <!-- 2021.04.14 (ver1.3) 수정 -->
          <li class="model">
            <div class="info-title">
              <div class="car-img"><v-img :src="carImg.src" :alt="carImg.alt"></v-img></div>
            </div>
            <div class="info-group">
              <strong class="bold">AX 자가용 5인승 가솔린 1.6 2WD IVT Smart</strong>
            </div>
          </li>
          <li>
            <strong class="info-title bold">가격정보</strong>
            <!-- 2021.04.14 (ver1.3) full 클래스 삭제 -->
            <div class="info-group">
              <ul class="desc-list">
                <li>
                  <em>차량가격</em>
                  <span class="price">21,200,000 원</span>
                </li>
                <li>
                  <em>세액 감면 혜택</em><!-- 2021.03.17 (ver1.0) 수정 start -->
                  <!-- 2021.04.14 (ver1.3) t-blue 클래스 추가 -->
                  <span class="price t-blue">(-) 388,168 원</span>
                </li>
                <li>
                  <em>계약금</em>
                  <!-- 2021.04.14 (ver1.3) t-blue 클래스 추가 -->
                  <span class="price t-blue">(-) 100,000 원</span>
                </li>
                <!-- 2021.04.14 (ver1.3) 삭제 -->
                <!-- <li>
                  <em>결제예정금액</em>
                  <span class="price t-blue">20,711,832 원</span>
                </li> -->
              </ul>
            </div>
          </li>
        </ul>
      </div>
    </div>
  </section>
</template>

<script>
export default {
  data() {
    return {
      isOptionsShow: false,
      carImg: {
        src: require('~/assets/images/temp/temp-payment-car-model.png'),
        alt: 'AX 스마트스트림 가솔린 1.1 터보 프리미엄 밀레니얼 A/T',
      },
    }
  },
}
</script>
