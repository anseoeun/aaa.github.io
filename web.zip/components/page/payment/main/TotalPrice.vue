<template>
  <section class="information-detail">
    <div class="summary-info">
      <h1 class="title">최종 금액 정보</h1>
      <div class="total-price">
        미입력금액 <span class="price">4,644,966</span> 원
      </div>
      <v-btn class="btn-detail" type="icon" :icon-class="['icon-open', { active: isOptionsShow} ]" @click="isOptionsShow = !isOptionsShow"><span class="offscreen">상세보기</span></v-btn>
    </div>
    <div v-show="isOptionsShow" class="detail-info" :class="{ active: isOptionsShow }">
      <div class="info-grid-list">
        <ul>
          <li>
            <strong class="info-title">최종결제금액</strong>
            <div class="info-group">
              <span class="price">24,644,966 원</span>
            </div>
          </li>
          <li>
            <strong class="info-title">할부금액</strong>
            <div class="info-group">
              <span class="price">(-) 0 원</span>
            </div>
          </li>
          <li>
            <strong class="info-title">결제입력금액</strong>
            <div class="info-group">
              <span class="price">(-) 20,000,000 원</span>
            </div>
          </li>
          <li>
            <strong class="info-title">미입력금액</strong>
            <div class="info-group">
              <span class="price t-blue">4,644,966 원</span>
            </div>
          </li>
        </ul>
        <p class="bullet">미입력 금액이 있습니다. 남은 결제금액을 입력해주세요. 결제 금액 전체 입력 완료되어야만 결제 진행이 가능합니다.</p>
      </div>
    </div>
  </section>
</template>

<script>
export default {
  components: {
  },
  data() {
    return {
      isOptionsShow: false,
    }
  },
}
</script>
