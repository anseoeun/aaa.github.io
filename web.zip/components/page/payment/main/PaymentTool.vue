<template>
  <section id="scrollCurrent" class="purchase-tool">
    <h1 class="title bold">최종 결제 내역</h1>
    <div class="info-grid-list">
      <strong class="sub-title bold">결제할 금액</strong>
      <!-- type1 -->
      <ul>
        <li>
          <strong class="info-title">결제 예정 차량 금액</strong>
          <div class="info-group">
            <span class="price">18,160,800 원</span>
          </div>
        </li>
        <li>
          <strong class="info-title">탁송료</strong>
          <div class="info-group">
            <span class="price">225,000 원</span>
          </div>
        </li>
        <li>
          <strong class="info-title">단기 의무보험료</strong>
          <div class="info-group">
            <span class="price">2,300 원</span>
          </div>
        </li>
        <!-- 2021.03.17 (ver1.0) 수정 -->
        <li>
          <div class="info-title full">
            <strong>할인</strong>
            <!-- 2021.04.14 (ver1.3) t-blue 클래스 추가 -->
            <span class="price t-blue">(-) 5,336,000 원</span>
          </div>
          <div class="info-group full">
            <ul class="desc-list">
              <li>
                <em>할인차감액</em>
                <span class="price">50,000 원</span>
              </li>
            </ul>
          </div>
        </li>
        <!-- 2021.03.17 (ver1.0) 위치이동 -->
        <!-- <li class="t-blue">
          <strong class="info-title">할인차감액</strong>
          <div class="info-group">
            <span class="price">50,000 원</span>
          </div>
        </li> -->
        <li>
          <strong class="info-title">할부 인지대</strong>
          <div class="info-group">
            <span class="price">100,000 원</span>
          </div>
        </li>
        <li class="total-price">
          <strong class="info-title">총 결제금액</strong>
          <div class="info-group">
            <div class="price">
              <div class="discount">
                <span class="t-blue">할인 17.5%</span>
                <v-popover trigger="hover" placement="bottom-end">
                  <p>
                    총 할인금액은 차량금액의 최대 30%를 초과할 수 없습니다.<br />제공되는 할인율은 포인트 할인 적용
                    정책에 따라 실제 적용되는 비율과 약간의 차이가 있을 수 있습니다.
                  </p>
                  <v-btn slot="reference"><i class="icon-help"></i></v-btn>
                </v-popover>
              </div>
              <!-- 2021.04.14 (ver1.3) 클래스 추가, 수정 -->
              <span class="t-blue"><strong class="ebold">12,827,100</strong>원</span>
            </div>
          </div>
        </li>
      </ul>

      <!-- 2021.04.14 추가 -->
      <!-- type2 -->
      <ul>
        <li>
          <div class="info-title full">
            <strong>총 결제할 금액</strong>
            <span class="price">18,160,800 원</span>
          </div>
          <div class="info-group full">
            <ul class="desc-list">
              <li>
                <em class="t-black">결제완료 금액</em>
              </li>
              <li>
                <em>신용카드 / 현대</em>
                <span class="price">500,000 원</span>
              </li>
              <li>
                <em>무통장입금</em>
                <span class="price">300,000 원</span>
              </li>
            </ul>
          </div>
        </li>
        <li>
          <strong class="info-title bold">미결제금액</strong>
          <div class="info-group">
            <span class="price"><strong class="ebold">10,160,800</strong> 원</span>
          </div>
        </li>
      </ul>
    </div>
    <div class="info-grid-list">
      <strong class="sub-title bold">입력한 결제금액</strong>

      <!-- 2021.03.17 (ver1.0) 수정 -->
      <p v-if="enteredData === '1'">선택된 결제수단이 없습니다.</p>

      <ul v-else-if="enteredData == '2'">
        <li v-for="(item, index) in pointData" :key="index">
          <strong class="info-title full">{{ item.pointType }}</strong>
          <div class="info-group full">
            <ul class="desc-list">
              <li v-for="(point, idx) in item.pointList" :key="idx">
                <em>{{ point.name }}</em>
                <span class="price">{{ point.pointPrice }} 원</span>
              </li>
            </ul>
          </div>
        </li>
        <li v-for="(item, index) in optionData" :key="index" :class="item.class">
          <strong class="info-title">{{ item.optionName }}</strong>
          <div class="info-group">
            <span class="price">{{ item.optionPrice }}</span
            >&nbsp;원
          </div>
        </li>
      </ul>
      <!-- // end -->

      <v-checkbox :one-check="true" :checked.sync="checkPurchase"
        >구매내용 및 조건을 확인하였으며,<br />결제 조건에 동의합니다.</v-checkbox
      >
    </div>
    <div class="btn-wrap">
      <v-btn class="btn md blue r" type="button">결제하기</v-btn>
    </div>
    <div class="register-vehicle">
      <strong class="title">차량 등록 비용</strong>
      <v-btn class="btn-more">확인하기</v-btn>
      <v-btn class="btn-more" @click="$emit('popRegistrationFee')">자세히 보기</v-btn>
      <div class="price">
        금액
        <span>154,000 원</span>
      </div>
      <ul class="bullet-list">
        <li>등록비는 결제금액에 포함되지 않습니다.<br />(별도 지불 필요)</li>
        <li>공채 할인금액은 지자체별 할인율이 매일 변동됨에<br />따라 실제와 차이가 있을 수있습니다.</li>
      </ul>
    </div>
  </section>
</template>

<script>
export default {
  data() {
    return {
      enteredData: '2',

      pointData: [
        {
          pointType: '블루멤버스 포인트',
          pointList: [
            { name: '이현대', pointPrice: '500,000' },
            { name: '김현대', pointPrice: '10,000' }
          ]
        },
        {
          pointType: 'M포인트',
          pointList: [
            { name: '이현대', pointPrice: '500,000' },
            { name: '김현대', pointPrice: '10,000' }
          ]
        }
      ],

      optionData: [
        { optionName: '블루멤버스 포인트 선사용', optionPrice: '10,000' },
        { optionName: '세이브-오토', optionPrice: '500,000' },
        { optionName: '할부', optionPrice: '9,000,000' },
        { optionName: '현금(무통장입금)', optionPrice: '3,000,000' },
        { optionName: '신용카드 / 현대', optionPrice: '1,000,000' },
        { optionName: '미입력금액', optionPrice: '12,827,100', class: 'not-paid' }
      ],
      checkPurchase: false
    }
  }
}
</script>
