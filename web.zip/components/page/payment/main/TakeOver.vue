<template>
  <section class="information-detail">
    <div class="summary-info">
      <!-- 2021.04.14 (ver1.3) 띄어쓰기 -->
      <h1 class="title">인수 정보</h1>
      <!-- 2021.03.17 (ver1.0) 수정 start -->
      <v-popover trigger="hover" placement="bottom-start">
        <!-- 배달탁송 -->
        <p v-if="takeOverHowRadio === '1'">
          탁송기사가 고객님이 요청하신 장소로 차량을 배달해 드리면 인수 절차를 진행하시면 됩니다.<br />
          * 탁송료 = 차량이 생산된 공장에서 차량이 위치한 출고센터까지의 배송료 + 차량이 위치했던 출고 센터에서 고객님이
          요청하신 지역까지의 탁송료<br />
          정확한 탁송료는 결제 시 탁송지를 입력하실 때 확인하실 수 있으며, 이때 계약 당시의 탁송지역과 다른 경우 금액이
          변동될 수 있습니다.
        </p>
        <!-- 직접인수 -->
        <p v-if="takeOverHowRadio === '2'">전시 지점에 직접 방문하여 차량 상태를 확인 후 인수 하셔야 합니다.</p>
        <v-btn slot="reference"><i class="icon-help"></i></v-btn>
      </v-popover>
      <!-- end -->
      <div class="total-price">탁송료 <span class="price">225,000</span> 원</div>
      <v-btn
        class="btn-detail"
        type="icon"
        :icon-class="['icon-open', { active: isOptionsShow }]"
        @click="isOptionsShow = !isOptionsShow"
        ><span class="offscreen">상세보기</span></v-btn
      >
    </div>
    <div v-show="isOptionsShow" class="detail-info" :class="{ active: isOptionsShow }">
      <!-- 2021.03.17 (ver1.0) 수정 -->
      <el-form ref="identifyForm" :model="relationPerson" :rules="rules">
        <!-- 배달탁송 -->
        <!-- <div v-if="takeOverHowRadio === '1'" class="form-grid-list take-over"> -->
        <div class="form-grid-list take-over">
          <ul>
            <li>
              <div class="form-label">
                <strong>서비스 물품</strong>
                <v-popover width="255" trigger="hover" placement="bottom-start">
                  <p class="tooltip-txt">
                    썬팅 무료시공을 선택하시면 등록서비스나<br />차량검수 패키지 또는 두가지 서비스 모두 신청<br />가능합니다.<br />차량을
                    직접 등록하기를 원하시는 고객님은<br />브랜드 KIT를 선택하시면 됩니다.
                  </p>
                  <v-btn slot="reference"><i class="icon-help"></i></v-btn>
                </v-popover>
              </div>
              <div class="form-group">
                <ul class="inbl-wrap ct">
                  <li>
                    <el-radio v-model="serviceCheck" label="1">썬팅 무료시공</el-radio>
                    <v-btn class="btn-info" type="icon" icon-class="icon-info" @click="$emit('tintingCoupon')"
                      ><span class="offscreen">썬팅무료시공안내팝업보기</span></v-btn
                    >
                  </li>
                  <li>
                    <el-radio v-model="serviceCheck" label="2">브랜드 KIT</el-radio>
                    <v-btn class="btn-info" type="icon" icon-class="icon-info" @click="$emit('brandKitCoupon')"
                      ><span class="offscreen">브랜드KIT안내팝업보기</span></v-btn
                    >
                  </li>
                </ul>
              </div>
            </li>
            <li>
              <!-- 2021.03.31 (ver1.2) 텍스트 수정 -->
              <strong class="form-label">등록 서비스</strong>
              <div class="form-group">
                <ul class="inbl-wrap ct">
                  <li>
                    <!-- 2021.03.31 (ver1.2) 텍스트 수정 -->
                    <el-radio v-model="employeeServiceCode" label="1">등록대행 서비스 신청 (수수료 33,000 원)</el-radio>
                    <v-popover width="255" trigger="hover" placement="bottom-start">
                      <!-- 2021.03.31 (ver1.2) 텍스트 수정 -->
                      <p class="tooltip-txt">
                        썬팅과 자동차 등록(번호판 발급)을 동시에 받는 원스탑 서비스입니다. 서비스를 신청하시면 오토클릭
                        콜센터 (02-711-2768)에서 안내 전화를 드리며, 상담원 안내에 따라 등록 비용을 납부하시면 됩니다.<br />
                        등록대행 서비스를 신청하시고, 현대캐피탈 할부금융 상품을 이용하시면 등록대행 서비스를 무료로 제공해 드립니다.
                      </p>
                      <v-btn slot="reference"><i class="icon-help"></i></v-btn>
                    </v-popover>
                  </li>
                  <li>
                    <!-- 2021.03.31 (ver1.2) 텍스트 수정 -->
                    <el-radio v-model="employeeServiceCode" label="2">미신청</el-radio>
                  </li>
                </ul>
              </div>
            </li>
            <li>
              <div class="form-label">
                <strong>차량검수 패키지</strong>
                <v-popover width="255" trigger="hover" placement="bottom-start">
                  <p class="tooltip-txt">
                    차량검수패키지 안내
                  </p>
                  <v-btn slot="reference"><i class="icon-help"></i></v-btn>
                </v-popover>
              </div>
              <div class="form-group">
                <ul class="inbl-wrap ct">
                  <li>
                    <!-- 2021.03.31 (ver1.2) 텍스트 수정 -->
                    <el-radio v-model="vehicleCheckService" label="1">신청 (수수료 33,000 원)</el-radio>
                  </li>
                  <li>
                    <el-radio v-model="vehicleCheckService" label="2">미신청</el-radio>
                  </li>
                </ul>
              </div>
            </li>
            <li>
              <strong class="form-label">인수자</strong>
              <div class="form-group inbl-wrap">
                <el-select v-model="relationPerson.peopleValue" placeholder="선택하세요">
                  <el-option v-for="item in takeOverPeople" :key="item.value" :label="item.name" :value="item.value">
                  </el-option>
                  <!-- asis -->
                  <!-- <el-option
                    v-for="item in resApiEPurchase012.data.relationPersonList"
                    :key="item.relationPersonSerialNumber"
                    :label="item.relationPersonName"
                    :value="item.relationPersonSerialNumber"
                  ></el-option> -->
                </el-select>
              </div>
            </li>
            <li>
              <strong class="form-label">인수자 연락처</strong>
              <div class="form-group inbl-wrap label-input">
                <label class="offscreen">인수자 연락처</label>
                <v-input v-model="relationPerson.acceptorTelephonNumber" maxlength="11" />
              </div>
            </li>
            <li>
              <strong class="form-label">인수지 주소</strong>
              <div class="form-group take-over-address">
                <ul class="desc-list">
                  <li class="btn-wrap ct">
                    <!-- 2021.04.14 (ver1.3) 클래스 수정 -->
                    <v-btn :class="{ active: viewType === 'tinting' }" class="btn md gray line r" @click="viewType = 'tinting'"
                      >썬팅 장착점</v-btn
                    >
                    <!-- 2021.04.14 (ver1.3) 클래스 수정 -->
                    <v-btn
                      :class="{ active: viewType === 'bluehands' }"
                      class="btn md gray line r"
                      @click="viewType = 'bluehands'"
                      >블루핸즈</v-btn
                    >
                    <!-- 2021.04.14 (ver1.3) 클래스 수정 -->
                    <v-btn :class="{ active: viewType === 'direct' }" class="btn md gray line r" @click="viewType = 'direct'"
                      >주소지정</v-btn
                    >
                  </li>
                  <li v-show="viewType === 'tinting'">
                    <strong class="bold">{{ tintingAddress.name }}</strong>
                    <p class="text">
                      {{ tintingAddress.address }}<br />{{ tintingAddress.tel }} / {{ tintingAddress.phone }}
                    </p>
                  </li>
                  <li v-show="viewType === 'bluehands'">
                    <strong class="bold">{{ bluehandsAddress.name }}</strong>
                    <p class="text">
                      {{ bluehandsAddress.address }}<br />{{ bluehandsAddress.tel }} / {{ bluehandsAddress.phone }}
                    </p>
                  </li>
                  <li v-show="viewType === 'direct'">
                    <el-form-item prop="address" class="form-address full">
                      <div class="label-input inbl-wrap">
                        <label class="offscreen">우편번호</label>
                        <v-input v-model="relationPerson.acceptorCenterPost" type="text" disabled="disabled" />
                        <v-btn class="btn-more" @click="$emit('postCode')">우편번호</v-btn>
                      </div>
                      <div class="label-input">
                        <label class="offscreen">기본주소</label>
                        <v-input v-model="relationPerson.acceptorCenterAddress" type="text" />
                      </div>
                      <div class="label-input">
                        <label class="offscreen">상세주소</label>
                        <v-input v-model="relationPerson.acceptorCenterAddressDetail" type="text" />
                      </div>
                    </el-form-item>
                  </li>
                </ul>
              </div>
            </li>
            <li>
              <strong class="form-label">기타 요청사항</strong>
              <div class="form-group request">
                <ul class="desc-list">
                  <li>
                    <el-select v-model="etcContentSelect" placeholder="배달기사님께 전달할 메시지를 선택해 주세요.">
                      <el-option
                        v-for="item in etcContentSelectList"
                        :key="item.value"
                        :label="item.name"
                        :value="item.value"
                      >
                      </el-option>
                    </el-select>
                  </li>
                  <li>
                    <v-input v-model="etcContent" type="textarea" maxlength="50" :rows="3" />
                  </li>
                </ul>
              </div>
            </li>
            <li>
              <strong class="form-label">탁송료</strong>
              <div class="form-group ct">
                <span class="price">{{ relationPerson.consignmentAmount }} 원</span>
              </div>
            </li>
          </ul>
        </div>
        <!-- 직접인수 -->
        <!-- <div v-if="takeOverHowRadio === '2'" class="form-grid-list take-over"> -->
        <div class="form-grid-list take-over">
          <div class="apply-agent">
            <v-checkbox v-model="relationPerson.isAgentChecked" :one-check="true">대리인 신청</v-checkbox>
          </div>
          <ul>
            <!-- 대리인 신청 -->
            <template v-if="relationPerson.isAgentChecked">
              <li>
                <strong class="form-label">대리 인수자명</strong>
                <div class="form-group inbl-wrap">
                  <el-form-item prop="acceptorName">
                    <div class="label-input">
                      <label class="offscreen">대리 인수자명</label>
                      <v-input ref="acceptorName" v-model="relationPerson.acceptorName" />
                    </div>
                  </el-form-item>
                </div>
              </li>
              <li>
                <strong class="form-label">대리인 연락처</strong>
                <div class="form-group inbl-wrap">
                  <el-form-item prop="agentTelephonNumber">
                    <div class="label-input">
                      <label class="offscreen">대리 연락처</label>
                      <v-input v-model="relationPerson.agentTelephonNumber" maxlength="11" />
                    </div>
                  </el-form-item>
                </div>
              </li>
              <li>
                <strong class="form-label">대리인 생년월일</strong>
                <div class="form-group inbl-wrap form-birth">
                  <el-form-item prop="acceptorBirth">
                    <el-select ref="birthYear" v-model="relationPerson.birthYear" placeholder="년도">
                      <!-- <el-option
                      v-for="item in birthYearList"
                      :key="item"
                      :label="item"
                      :value="item"
                    ></el-option> -->
                    </el-select>
                    <el-select
                      ref="birthMonth"
                      v-model="relationPerson.birthMonth"
                      class="birth-month"
                      placeholder="월"
                    >
                      <!-- <el-option v-for="item in 12" :key="item" :label="item" :value="item"></el-option> -->
                    </el-select>
                    <el-select ref="birthDay" v-model="relationPerson.birthDay" class="birth-day" placeholder="일">
                      <!-- <el-option v-for="item in 31" :key="item" :label="item" :value="item"></el-option> -->
                    </el-select>
                  </el-form-item>
                </div>
              </li>
              <li>
                <strong class="form-label">성별</strong>
                <div class="form-group inbl-wrap">
                  <el-form-item prop="acceptorGender">
                    <el-radio ref="gender" v-model="relationPerson.gender" label="M">남자</el-radio>
                    <el-radio v-model="relationPerson.gender" label="F">여자</el-radio>
                  </el-form-item>
                </div>
              </li>
            </template>
            <!-- // 대리인 신청 = true -->
            <!-- 인수자 -->
            <template v-else>
              <li>
                <strong class="form-label">인수자</strong>
                <div class="form-group inbl-wrap">
                  <el-select v-model="relationPerson.peopleValue" placeholder="선택하세요">
                    <el-option v-for="item in takeOverPeople" :key="item.value" :label="item.name" :value="item.value">
                    </el-option>
                    <!-- asis -->
                    <!-- <el-option
                    v-for="item in resApiEPurchase012.data.relationPersonList"
                    :key="item.relationPersonSerialNumber"
                    :label="item.relationPersonName"
                    :value="item.relationPersonSerialNumber"
                  ></el-option> -->
                  </el-select>
                </div>
              </li>
              <li>
                <strong class="form-label">인수자 연락처</strong>
                <div class="form-group inbl-wrap label-input">
                  <label class="offscreen">인수자 연락처</label>
                  <v-input v-model="relationPerson.acceptorTelephonNumber" maxlength="11" />
                </div>
              </li>
            </template>
            <!-- // 인수자 -->
            <li>
              <strong class="form-label">차량보관장소</strong>
              <div class="form-group ct">강남지점 / 서울특별시 강남구 테헤란로 20길 9</div>
            </li>
          </ul>
        </div>
      </el-form>
    </div>
  </section>
</template>

<script>
export default {
  components: {},
  data() {
    return {
      isOptionsShow: false,
      // 배달탁송, 직접인수
      takeOverHowRadio: '2',
      employeeServiceCode: '1',
      vehicleCheckService: '1',
      serviceCheck: '1',
      // 인수지 주소 선택
      viewType: '',
      // 인수자
      takeOverPeople: [
        {
          value: '1',
          name: '홍길동'
        },
        {
          value: '2',
          name: '김현대'
        },
        {
          value: '3',
          name: '성춘향'
        }
      ],
      relationPerson: {
        peopleValue: '2',
        acceptorTelephonNumber: '010-1234-5678',
        acceptorCenterPost: '06061',
        acceptorCenterAddress: '서울특별시 강남구',
        acceptorCenterAddressDetail: '학동로 609 10-001 (청담동)',
        consignmentAmount: '100,000',
        isAgentChecked: false,
        acceptorName: null,
        birthYear: null,
        birthMonth: null,
        birthDay: null,
        birth: null,
        gender: null,
        agentTelephonNumber: null
      },
      tintingAddress: {
        name: '배달오토탱크',
        address: '서울 특별시 강동구 양재대로 1227가길 1 (길동)',
        tel: '02-3421-2255',
        phone: '010-3421-2255'
      },
      bluehandsAddress: {
        name: '(주) 강남정비센터 (종합블루핸즈)',
        address: '서울 특별시 강동구',
        tel: '02-1234-5678',
        phone: '010-3421-2255'
      },
      etcContentSelect: '',
      etcContentSelectList: [],
      etcContent: '',
      birthYearList: [],
      popVisible: {
        tintingCoupon: false,
        brandKitCoupon: false
      }
    }
  },
  computed: {
    rules() {
      return {
        acceptorName: [
          {
            required: true,
            message: '* 대리 인수자명을 입력해 주세요.',
            trigger: 'blur'
          }
        ],
        agentTelephonNumber: [
          {
            required: true,
            message: '* 연락처를 입력해 주세요.',
            trigger: 'blur'
          }
        ],
        acceptorBirth: [
          {
            required: true,
            message: '* 생년월일을 선택해 주세요.',
            trigger: 'blur'
          }
        ],
        acceptorGender: [
          {
            required: true,
            message: '* 성별을 선택해 주세요.',
            trigger: 'blur'
          }
        ],
        address: [
          {
            required: true,
            message: '* 주소를 입력해 주세요.',
            trigger: 'blur'
          }
        ]
      }
    }
  },
  // 2021.03.19 (ver1.1) mounted -> updated로 수정
  updated() {
    this.setLabel((idg) => {
      console.dir(idg) // 자동 생성된 ID 배열, 예) 첫번째 입력폼 ID : idg[0]
    })
  }
}
</script>
