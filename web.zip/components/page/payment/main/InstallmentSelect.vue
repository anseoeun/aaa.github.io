<template>
  <section class="information-detail">
    <div class="summary-info">
      <!-- 2021.04.14 (ver1.3) 띄어쓰기 -->
      <h1 class="title">할부 정보</h1>
      <!-- 2021.04.14 (ver1.3) 삭제 -->
      <!-- <div class="total-price">
        할부 적용 금액 <span class="price">15,000,00</span> 원
      </div> -->
      <v-btn class="btn-detail" type="icon" :icon-class="['icon-open', { active: isOptionsShow} ]" @click="isOptionsShow = !isOptionsShow"><span class="offscreen">상세보기</span></v-btn>
    </div>
    <div v-show="isOptionsShow" class="detail-info" :class="{ active: isOptionsShow }">
      <!-- 2021.04.14 (ver1.3) 클래스 추가 / 전체적인 수정 start -->
      <div class="info-grid-list installment">
        <!-- type1 -->
        <ul>
          <li>
            <strong class="info-title bold">나의 할부 한도</strong>
            <div class="info-group">
              <!-- 외부링크 / 실패시 팝업 -->
              <!-- <v-btn type="link" class="last btn md white r" target="_blank" title="새창열림">내 할부한도 조회</v-btn> -->
              <v-btn class="last btn md white r" @click="$emit('installmentWaiting')">내 할부한도 조회</v-btn>
            </div>
            <p class="text-info">할부한도를 조회해 주세요. 한도 조회를 완료하셔야 할부상품 선택이 가능합니다.</p>
            <p class="bullet">등록대행 서비스를 신청하시고, 현대캐피탈 할부금융상품을 이용하시면 등록대행 서비스를 무료로 제공해 드립니다.</p>
          </li>
        </ul>

        <!-- type2 -->
        <ul>
          <li>
            <strong class="info-title bold">나의 할부 한도</strong>
            <div class="info-group">
              <span class="price">15,000,000 원</span>
              <v-btn class="last btn md white r" @click="$emit('installmentProducts')">할부상품 선택</v-btn>
            </div>
            <ul class="bullet-list">
              <li>등록대행 서비스를 신청하시고, 현대캐피탈 할부금융상품을 이용하시면 등록대행 서비스를 무료로 제공해 드립니다.</li>
              <li>할부한도 조회를 완료하셔야만 결제 신청이 가능합니다.</li>
            </ul>
          </li>
        </ul>

        <!-- type3 -->
        <ul>
          <li>
            <strong class="info-title bold">나의 할부 한도</strong>
            <div class="info-group">
              <!-- 외부링크 / 실패시 팝업 -->
              <!-- <v-btn type="link" class="last btn md white r" target="_blank" title="새창열림">내 할부한도 조회</v-btn> -->
              <v-btn class="last btn md white r" @click="$emit('installmentWaiting')">내 할부한도 조회</v-btn>
            </div>
            <div class="info-group full">
              <ul class="desc-list">
                <li>
                  <em>할부 상품</em>
                  <div>
                    할부상품명
                    <v-btn class="btn-more" @click="$emit('installmentAgree')">변경</v-btn>
                    <v-btn class="btn-more">삭제</v-btn>
                  </div>
                </li>
                <li>
                  <em>할부 상세</em>
                  <ul>
                    <li>
                      <em>할부원금</em>
                      <span class="price">15,000,000 원</span>
                    </li>
                    <li>
                      <em>선수금</em>
                      <span class="price">21,200,000 원</span>
                    </li>
                    <li>
                      <em>할부기간</em>
                      <span class="last">36개월</span>
                    </li>
                    <li>
                      <em>월납입금 / 금리</em>
                      <span class="last">88,000 원 / 무이자</span>
                    </li>
                    <li>
                      <v-btn class="btn-more last" @click="$emit('repaymentPlan')">상환계획 조회</v-btn>
                    </li>
                  </ul>
                </li>
              </ul>
            </div>
            <ul class="bullet-list">
              <li>등록대행 서비스를 신청하시고, 현대캐피탈 할부금융상품을 이용하시면 등록대행 서비스를 무료로 제공해 드립니다.</li>
              <li>할부한도 조회를 완료하셔야만 결제 신청이 가능합니다.</li>
            </ul>
          </li>
        </ul>

        <!-- type4 -->
        <ul>
          <li>
            <strong class="info-title bold">나의 할부 한도</strong>
            <div class="info-group">
              <span class="price">30,000,000 원</span>
              <v-btn class="last btn md white r">할부 승인 요청하기</v-btn>
            </div>
            <div class="info-group full">
              <ul class="desc-list">
                <li>
                  <em>할부 상품</em>
                  <div>
                    할부상품명
                    <v-btn class="btn-more" @click="$emit('installmentAgree')">변경</v-btn>
                    <v-btn class="btn-more">삭제</v-btn>
                    <p class="bullet-star">선택하신 M할부 상품은 현대카드로 선수금 10% 결제 시에만 승인 가능합니다.</p>
                  </div>
                </li>
                <li>
                  <em>승인상태</em>
                  <span>승인요청 중</span>
                  <v-btn class="btn-more">승인요청 취소</v-btn>
                </li>
                <li>
                  <em>할부 상세</em>
                  <ul>
                    <li>
                      <em>할부원금</em>
                      <ul>
                        <li><span class="price">15,000,000 원</span></li>
                        <li><span class="last">실 납입 할부금 14,550,000 원</span></li>
                      </ul>
                    </li>
                    <li>
                      <em>선수금</em>
                      <span class="price">21,200,000 원</span>
                    </li>
                    <li>
                      <em>할부기간</em>
                      <span class="last">36개월</span>
                    </li>
                    <li>
                      <em>월납입금 / 금리</em>
                      <span class="last">88,000 원 / 무이자</span>
                    </li>
                    <li>
                      <v-btn class="btn-more last" @click="$emit('repaymentPlan')">상환계획 조회</v-btn>
                    </li>
                    <li>
                      <em>할부인지대</em>
                      <span class="price">20,000 원</span>
                    </li>
                  </ul>
                </li>
              </ul>
            </div>
            <ul class="bullet-list">
              <li>등록대행 서비스를 신청하시고, 현대캐피탈 할부금융상품을 이용하시면 등록대행 서비스를 무료로 제공해 드립니다.</li>
              <li>할부원금 5,000만원 초과로 할부인지대가 발생하였습니다. 할부인지대는 현금(무통장입금) 결제만 가능합니다.</li>
            </ul>
          </li>
        </ul>
        <!-- 2021.04.14 (ver1.3) 삭제 -->
        <!-- <p class="bullet-star">타 금융사의 할부상품 이용을 원하실 경우 할부 에정금액을 현금(무통장입금)으로 입력한 후, 해당 캐피탈 사에 문의 하세요.</p> -->
      </div>
      <!-- end -->
    </div>
  </section>
</template>

<script>
export default {
  components: {
  },
  props : {
    type: {
      type: String,
      default: '',
    },
  },
  data() {
    return {
      isOptionsShow: false,
    }
  }
}
</script>
