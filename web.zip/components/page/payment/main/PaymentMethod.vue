<template>
  <section class="information-detail">
    <!-- 결제, 다시결제 -->
    <!-- 2021.03.17 (ver1.0) v-if 삭제 -->
    <div class="summary-info">
      <!-- 2021.03.31 (ver1.2) 텍스트 수정 -->
      <h1 class="title">결제수단</h1>
      <div class="total-price">결제 예정 금액 <span class="price">20,711,832</span> 원</div>
      <v-btn
        class="btn-detail"
        type="icon"
        :icon-class="['icon-open', { active: isOptionsShow }]"
        @click="isOptionsShow = !isOptionsShow"
        ><span class="offscreen">상세보기</span></v-btn
      >
    </div>
    <!-- 2021.03.17 (ver1.0) 삭제 -->
    <!-- 추가결제 -->
    <!-- <div v-else class="summary-info">
      <h1 class="title">추가 결제</h1>
      <div class="total-price">
        추가 결제 금액 <span class="price">200,000</span> 원
      </div>
      <p class="bullet-star">추가 결제 사유 : 포인트 사용승인 거절</p>
    </div> -->
    <div v-show="isOptionsShow" class="detail-info" :class="{ active: isOptionsShow }">
      <el-form ref="form" :rules="rules">
        <div class="tab-default payment-method tab-wrap">
          <!-- 2021.03.17 (ver1.0) 수정 -->
          <!-- 2021.03.31 (ver1.2) 변경 -->
          <div class="tab-menu">
            <ul>
              <li :class="{ active: paymentTypeList == '1' }">
                <v-btn @click="paymentTypeList = '1'">신용카드</v-btn>
              </li>
              <li :class="{ active: paymentTypeList == '2' }">
                <v-btn @click="paymentTypeList = '2'">현금(무통장입금)</v-btn>
              </li>

              <!-- 2021.03.17 (ver1.0) 삭제 -->
              <!-- 2021.03.31 (ver1.2) 다시 추가 -->
              <li :class="{ active: paymentTypeList == '3' }">
                <v-btn
                  @click="paymentTypeList = '3'"
                >현금(무통장입금) + 신용카드</v-btn>
              </li>
            </ul>
          </div>

          <!-- 2021.03.17 (ver1.0) 전체적인 내용 수정 -->
          <div class="tab-contents">

            <!-- 2021.03.31 (ver1.2) 기존 UI로 다시 수정 -->
            <!-- 탭 : 신용카드 -->
            <template v-if="paymentTypeList == '1'">
              <div class="payment-wrap">
                <div class="title">
                  <strong class="bold">신용카드</strong>
                </div>
                <div class="payment-card-list">
                  <!-- 신용카드 1 -->
                  <div class="form-grid-list">
                    <ul>
                      <li>
                        <strong class="form-label bold">결제예정금액</strong>
                        <div class="form-group inbl-wrap">
                          <p v-if="creditPrice" class="total-price ct">20,711,832 원</p>
                          <div v-else class="label-input">
                            <label class="offscreen">결제예정금액 입력</label>
                            <v-input v-model="creditPaymentPrice" type="text" />
                          </div>
                          <el-radio v-model="creditDepositRadio" label="1">단기의무보험 포함</el-radio>
                          <v-btn
                            class="btn-info"
                            type="icon"
                            icon-class="icon-info"
                            @click="$emit('tempInsurance')"
                            ><span class="offscreen">단기의무보험안내팝업보기</span></v-btn
                          >
                        </div>
                      </li>
                      <li>
                        <div class="form-label full">
                          <strong class="bold">카드정보</strong>
                          <div class="btn-wrap">
                            <v-btn class="btn-more" @click="$emit('installmentIncreaseGuide')"
                              >신용카드 한도 일시상향 안내</v-btn
                            >
                            <v-btn class="btn-more" @click="$emit('privacy')">나의 현대카드 혜택 알아보기</v-btn>
                          </div>
                        </div>
                        <div class="form-group full">
                          <ul class="desc-list">
                            <li>
                              <em>소유주</em>
                              <v-select v-model="creditOwn" :data="creditOwnData" />
                            </li>
                            <li>
                              <em>카드번호</em>
                              <div class="inbl-wrap card-number">
                                <el-form-item prop="cardNumber">
                                  <div class="label-input">
                                    <label class="offscreen">첫번째 카드번호</label>
                                    <v-input v-model="cardNumber[0]" type="number" maxlength="4" />
                                  </div>
                                  <div class="label-input">
                                    <label class="offscreen">두 번째 카드번호</label>
                                    <v-input v-model="cardNumber[1]" type="number" maxlength="4" />
                                  </div>
                                  <div class="label-input">
                                    <label class="offscreen">세번째 카드번호</label>
                                    <v-input v-model="cardNumber[2]" type="number" maxlength="4" />
                                  </div>
                                  <div class="label-input">
                                    <label class="offscreen">네번째 카드번호</label>
                                    <v-input v-model="cardNumber[3]" type="number" maxlength="4" />
                                  </div>
                                  <span class="result">
                                    <i class="icon-check"></i>
                                    <i class="icon-x"></i>
                                  </span>
                                  <span class="card-company">현대카드</span>
                                </el-form-item>
                              </div>
                            </li>
                            <li>
                              <em>유효기간</em>
                              <div class="form-group">
                                <el-form-item prop="datelimit" class="inbl-wrap card-limit">
                                  <div class="label-input">
                                    <label class="offscreen">년도 유효기간</label>
                                    <v-input v-model="datelimit[1]" type="number" maxlength="2" placeholder="MM" />
                                  </div>
                                  <div class="label-input">
                                    <label class="offscreen">월 유효기간</label>
                                    <v-input v-model="datelimit[2]" type="number" maxlength="2" placeholder="YY" />
                                  </div>
                                  <span class="result">
                                    <i class="icon-check"></i>
                                    <i class="icon-x"></i>
                                  </span>
                                </el-form-item>
                              </div>
                            </li>
                            <li>
                              <em>할부기간</em>
                              <div class="form-group inbl-wrap">
                                <v-select v-model="creditSelect" :data="creditSelectData" />
                                <!-- 직접입력 폼 추가 -->
                                <div class="label-input">
                                  <label class="offscreen">직접입력</label>
                                  <v-input />
                                </div>
                                <v-popover trigger="hover" placement="bottom-start" class="ct">
                                  <p>
                                    할부 가능여부 및 이율은 각 신용카드사 정책 및 카드종류에 따라 다를 수 있으므로
                                    사전에 해당 카드사에 확인하고 선택하시기 바랍니다.
                                  </p>
                                  <v-btn slot="reference"><i class="icon-help"></i></v-btn>
                                </v-popover>
                              </div>
                            </li>
                          </ul>
                        </div>
                      </li>
                      <li>
                        <strong class="form-label bold">제휴혜택</strong>
                        <div class="form-group ct">
                          <ul class="select-mix">
                            <li :class="{ active: methodVal === 1 }">
                              <v-btn class="chk" @click="checkMethod(1)">캐시백 1.3</v-btn>
                            </li>
                            <li :class="{ active: methodVal === 2 }">
                              <v-btn class="chk" @click="checkMethod(2)">포인트적립 1.5</v-btn>
                            </li>
                            <li :class="{ active: methodVal === 3 }">
                              <el-dropdown trigger="click" class="chk">
                                <span>
                                  <span>{{ interestCaseLabel }}</span> <i class="el-icon-arrow-down el-icon--right"></i>
                                </span>
                                <el-dropdown-menu slot="dropdown">
                                  <el-dropdown-item v-for="(item, index) in interestList" :key="index"
                                    ><v-btn @click="checkMethod(3, item)">{{ item.label }}</v-btn></el-dropdown-item
                                  >
                                </el-dropdown-menu>
                              </el-dropdown>
                            </li>
                          </ul>
                        </div>
                      </li>
                      <li>
                        <strong class="form-label bold">혜택 신청</strong>
                        <div class="form-group ct">
                          <ul class="desc-list">
                            <li>
                              <v-checkbox :one-check="true" :checked.sync="requestCheck"
                                >카드 한도 상향 신청</v-checkbox
                              >
                            </li>
                            <li class="save-auto">
                              <v-checkbox :one-check="true" :checked.sync="saveCheck">세이브-오토 20만</v-checkbox>
                              <v-btn class="btn-info" type="icon" icon-class="icon-info" @click="$emit('saveAutoGuide')"
                                ><span class="offscreen">안내팝업보기</span></v-btn
                              >
                              <span class="state">신청완료</span>
                              <v-btn class="btn-more">신청결과 확인하기</v-btn>
                              <v-btn class="btn-more">취소하기</v-btn>
                            </li>
                            <li>
                              <v-btn class="btn-more">신청하기</v-btn>
                            </li>
                          </ul>
                        </div>
                      </li>
                    </ul>
                  </div>
                  <!-- // 신용카드 1 -->
                  <!-- 신용카드 2 -->
                  <div class="form-grid-list">
                    <ul>
                      <li>
                        <strong class="form-label bold">결제예정금액</strong>
                        <div class="form-group inbl-wrap">
                          <p v-if="creditPrice" class="total-price ct">20,711,832 원</p>
                          <div v-else class="label-input">
                            <label class="offscreen">결제예정금액 입력</label>
                            <v-input v-model="creditPaymentPrice" type="text" />
                          </div>
                          <el-radio v-model="creditDepositRadio" label="2">단기의무보험 포함</el-radio>
                          <v-btn
                            class="btn-info"
                            type="icon"
                            icon-class="icon-info"
                            @click="$emit('tempInsurance')"
                            ><span class="offscreen">단기의무보험안내팝업보기</span></v-btn
                          >
                        </div>
                      </li>
                      <li>신용카드2 내용 (신용카드1과 동일)</li>
                    </ul>
                    <!-- 신용카드 2 삭제 -->
                    <v-btn class="btn-delete" type="icon" icon-class="icon-delete"
                      ><span class="offscreen">삭제</span></v-btn
                    >
                  </div>
                  <!-- // 신용카드 2 -->
                  <!-- 신용카드 추가  -->
                  <div class="btn-wrap">
                    <v-btn class="btn md white r">신용카드 추가</v-btn>
                  </div>
                </div>
              </div>
            </template>

            <!-- 2021.03.31 (ver1.2) 기존 UI로 다시 수정 -->
            <!-- 탭 : 현금(무통장입금) -->
            <template v-if="paymentTypeList == '2'">
              <div class="payment-wrap">
                <div class="title">
                  <strong class="bold">현금(무통장입금)</strong>
                </div>
                <div class="form-grid-list">
                  <ul>
                    <li>
                      <strong class="form-label bold">결제예정금액</strong>
                      <div class="form-group inbl-wrap">
                        <p class="total-price ct">20,711,832 원</p>
                        <el-radio v-model="bankRadio" label="1">단기의무보험 포함</el-radio>
                        <v-btn
                          class="btn-info"
                          type="icon"
                          icon-class="icon-info"
                          @click="$emit('tempInsurance')"
                          ><span class="offscreen">단기의무보험안내팝업보기</span></v-btn
                        >
                      </div>
                    </li>
                    <li>
                      <strong class="form-label bold">입금정보</strong>
                      <div class="form-group full">
                        <ul class="desc-list">
                          <li class="inbl-wrap">
                            <em>입금은행</em>
                            <v-select v-model="depositBank" :data="depositBankData" placeholder="은행선택" />
                            <p class="form-text ct">입금계좌 : 900252282011</p>
                          </li>
                        </ul>
                      </div>
                    </li>
                  </ul>
                </div>
              </div>
            </template>

            <!-- 2021.03.17 (ver1.0) 삭제 -->
            <!-- 2021.03.31 (ver1.2) 기존 UI로 다시 수정 -->
            <!-- 탭 : 무통장입금 + 신용카드 -->
            <template v-if="paymentTypeList == '3'">
              <!-- 무통장 -->
              <div class="payment-wrap">
                <div class="title">
                  <strong class="bold">무통장 입금</strong>
                </div>
                <div class="form-grid-list">
                  <ul>
                    <li>
                      <strong class="form-label bold">결제예정금액</strong>
                      <div class="form-group inbl-wrap">
                        <p class="total-price ct">20,711,832 원</p>
                        <el-radio v-model="bankCreditRadio" label="1">단기의무보험 포함</el-radio>
                        <v-btn
                          class="btn-info"
                          type="icon"
                          icon-class="icon-info"
                          @click="$emit('tempInsurance')"
                          ><span class="offscreen">단기의무보험안내팝업보기</span></v-btn
                        >
                      </div>
                    </li>
                    <li>
                      <strong class="form-label bold">입금정보</strong>
                      <div class="form-group full">
                        <ul class="desc-list">
                          <li class="inbl-wrap">
                            <em>입금은행</em>
                            <v-select v-model="depositBank" :data="depositBankData" placeholder="은행선택" />
                            <p class="form-text ct">입금계좌 : 900252282011</p>
                          </li>
                        </ul>
                      </div>
                    </li>
                  </ul>
                </div>
              </div>
              <!-- 신용카드 -->
              <div class="payment-wrap">
                <div class="title">
                  <strong class="bold">신용카드</strong>
                </div>
                <div class="payment-card-list">
                  <!-- 신용카드 1 -->
                  <div class="form-grid-list">
                    <ul>
                      <li>
                        <strong class="form-label bold">결제예정금액</strong>
                        <div class="form-group inbl-wrap">
                          <p v-if="creditPrice" class="total-price ct">20,711,832 원</p>
                          <div v-else class="label-input">
                            <label class="offscreen">결제예정금액 입력</label>
                            <v-input v-model="creditPaymentPrice" type="text" />
                          </div>
                          <el-radio v-model="bankCreditRadio" label="2">단기의무보험 포함</el-radio>
                          <v-btn
                            class="btn-info"
                            type="icon"
                            icon-class="icon-info"
                            @click="$emit('tempInsurance')"
                            ><span class="offscreen">단기의무보험안내팝업보기</span></v-btn
                          >
                        </div>
                      </li>
                      <li>
                        <div class="form-label full">
                          <strong class="bold">카드정보</strong>
                          <div class="btn-wrap">
                            <v-btn class="btn-more" @click="$emit('installmentIncreaseGuide')"
                              >신용카드 한도 일시상향 안내</v-btn
                            >
                            <v-btn class="btn-more" @click="$emit('privacy')">나의 현대카드 혜택 알아보기</v-btn>
                          </div>
                        </div>
                        <div class="form-group full">
                          <ul class="desc-list">
                            <li>
                              <em>소유주</em>
                              <v-select v-model="creditOwn" :data="creditOwnData" />
                            </li>
                            <li>
                              <em>카드번호</em>
                              <div class="inbl-wrap card-number">
                                <el-form-item prop="cardNumber">
                                  <div class="label-input">
                                    <label class="offscreen">첫번째 카드번호</label>
                                    <v-input v-model="cardNumber[0]" type="number" maxlength="4" />
                                  </div>
                                  <div class="label-input">
                                    <label class="offscreen">두 번째 카드번호</label>
                                    <v-input v-model="cardNumber[1]" type="number" maxlength="4" />
                                  </div>
                                  <div class="label-input">
                                    <label class="offscreen">세번째 카드번호</label>
                                    <v-input v-model="cardNumber[2]" type="number" maxlength="4" />
                                  </div>
                                  <div class="label-input">
                                    <label class="offscreen">네번째 카드번호</label>
                                    <v-input v-model="cardNumber[3]" type="number" maxlength="4" />
                                  </div>
                                  <span class="result">
                                    <i class="icon-check"></i>
                                    <i class="icon-x"></i>
                                  </span>
                                  <span class="card-company">현대카드</span>
                                </el-form-item>
                              </div>
                            </li>
                            <li>
                              <em>유효기간</em>
                              <div class="form-group">
                                <el-form-item prop="datelimit" class="inbl-wrap card-limit">
                                  <div class="label-input">
                                    <label class="offscreen">년도 유효기간</label>
                                    <v-input v-model="datelimit[1]" type="number" maxlength="2" placeholder="MM" />
                                  </div>
                                  <div class="label-input">
                                    <label class="offscreen">월 유효기간</label>
                                    <v-input v-model="datelimit[2]" type="number" maxlength="2" placeholder="YY" />
                                  </div>
                                  <span class="result">
                                    <i class="icon-check"></i>
                                    <i class="icon-x"></i>
                                  </span>
                                </el-form-item>
                              </div>
                            </li>
                            <li>
                              <em>할부기간</em>
                              <div class="form-group inbl-wrap">
                                <v-select v-model="creditSelect" :data="creditSelectData" />
                                <!-- 직접입력 폼 추가 -->
                                <div class="label-input">
                                  <label class="offscreen">직접입력</label>
                                  <v-input />
                                </div>
                                <v-popover trigger="hover" placement="bottom-start" class="ct">
                                  <p>
                                    할부 가능여부 및 이율은 각 신용카드사 정책 및 카드종류에 따라 다를 수 있으므로
                                    사전에 해당 카드사에 확인하고 선택하시기 바랍니다.
                                  </p>
                                  <v-btn slot="reference"><i class="icon-help"></i></v-btn>
                                </v-popover>
                              </div>
                            </li>
                          </ul>
                        </div>
                      </li>
                      <li>
                        <strong class="form-label bold">제휴혜택</strong>
                        <div class="form-group ct">
                          <ul class="select-mix">
                            <li :class="{ active: methodVal === 1 }">
                              <v-btn class="chk" @click="checkMethod(1)">캐시백 1.3</v-btn>
                            </li>
                            <li :class="{ active: methodVal === 2 }">
                              <v-btn class="chk" @click="checkMethod(2)">포인트적립 1.5</v-btn>
                            </li>
                            <li :class="{ active: methodVal === 3 }">
                              <el-dropdown trigger="click" class="chk">
                                <span>
                                  <span>{{ interestCaseLabel }}</span> <i class="el-icon-arrow-down el-icon--right"></i>
                                </span>
                                <el-dropdown-menu slot="dropdown">
                                  <el-dropdown-item v-for="(item, index) in interestList" :key="index"
                                    ><v-btn @click="checkMethod(3, item)">{{ item.label }}</v-btn></el-dropdown-item
                                  >
                                </el-dropdown-menu>
                              </el-dropdown>
                            </li>
                          </ul>
                        </div>
                      </li>
                      <li>
                        <strong class="form-label bold">혜택 신청</strong>
                        <div class="form-group ct">
                          <ul class="desc-list">
                            <li>
                              <v-checkbox :one-check="true" :checked.sync="requestCheck"
                                >카드 한도 상향 신청</v-checkbox
                              >
                            </li>
                            <li class="save-auto">
                              <v-checkbox :one-check="true" :checked.sync="saveCheck">세이브-오토 20만</v-checkbox>
                              <v-btn class="btn-info" type="icon" icon-class="icon-info" @click="$emit('saveAutoGuide')"
                                ><span class="offscreen">안내팝업보기</span></v-btn
                              >
                              <span class="state">신청완료</span>
                              <v-btn class="btn-more">신청결과 확인하기</v-btn>
                              <v-btn class="btn-more">취소하기</v-btn>
                            </li>
                            <li>
                              <v-btn class="btn-more">신청하기</v-btn>
                            </li>
                          </ul>
                        </div>
                      </li>
                    </ul>
                  </div>
                  <!-- // 신용카드 1 -->
                  <!-- 신용카드 2 -->
                  <div class="form-grid-list">
                    <ul>
                      <li>
                        <strong class="form-label bold">결제예정금액</strong>
                        <div class="form-group inbl-wrap">
                          <p v-if="creditPrice" class="total-price ct">20,711,832 원</p>
                          <div v-else class="label-input">
                            <label class="offscreen">결제예정금액 입력</label>
                            <v-input v-model="creditPaymentPrice" type="text" />
                          </div>
                          <el-radio v-model="bankCreditRadio" label="3">단기의무보험 포함</el-radio>
                          <v-btn
                            class="btn-info"
                            type="icon"
                            icon-class="icon-info"
                            @click="$emit('tempInsurance')"
                            ><span class="offscreen">단기의무보험안내팝업보기</span></v-btn
                          >
                        </div>
                      </li>
                      <li>신용카드2 내용 (신용카드1과 동일)</li>
                    </ul>
                    <!-- 신용카드 2 삭제 -->
                    <v-btn class="btn-delete" type="icon" icon-class="icon-delete"
                      ><span class="offscreen">삭제</span></v-btn
                    >
                  </div>
                  <!-- // 신용카드 2 -->
                  <!-- 신용카드 추가  -->
                  <div class="btn-wrap">
                    <v-btn class="btn md white r">신용카드 추가</v-btn>
                  </div>
                </div>
              </div>
            </template>
          </div>
        </div>

        <div class="info-list">
          <p class="bullet-star">아래 사항을 반드시 확인해 주세요.</p>
          <v-checkbox v-model="agreeCheck" :data="agreeCheckData" />
        </div>

        <!-- 2021.03.17 (ver1.0) 추가 -->
        <ul class="bullet-list">
          <li>카드한도 상향을 하지 않을 경우 결제가 실패될 수 있습니다. 결제 전 반드시 카드 결제 한도를 체크해 주세요.</li>
          <li>카드한도 일시 상향은 일시불 결제를 기준으로 하며, 할부 결제 시에는 일시 상향 금액과는 무관하게 승인 거절이 될 수 있습니다.</li>
          <li>카드사별 제휴 혜택은 수시로 변경되는 사항으로, 결제 완료 시점에 따라 적용 금액에 차이가 있을 수 있습니다.</li>
          <li>신용카드 결제 시 단기의무보험료는 차량 가액 결제 완료 후 별도 승인 됩니다.</li>
          <li>현대카드 M할부 상품은 현대카드(제휴카드 포함)로 선수금 10% 결제 시에만 승인 가능합니다.</li>
        </ul>
      </el-form>
    </div>
  </section>
</template>

<script>
export default {
  components: {},
  props: {
    type: {
      type: String,
      default: ''
    }
  },
  data() {
    // 2021.03.17 (ver1.0) 수정
    return {
      isOptionsShow: false,
      tabList: [
        { value: 'tab1', label: '신용카드' },
        { value: 'tab2', label: '무통장 입금' }
        // { value: 'tab3', label: '무통장 입금 + 신용카드' }
      ],
      paymentTypeList: '1', // 할부, 일시불 선택
      checkboxDataVal: false, // 할부금융 신청을 위한 개인정보 제3자 제공 동의
      listSelected: [false, false, false, false, false], // 신용카드, 현금 토글
      creditDepositRadio: '', // 단기의무보험
      creditPaymentPrice: '', // 신용카드1 결제예정금액
      creditPaymentPrice2: '', // 신용카드2 결제예정금액
      cardNumber: ['', '', '', ''], // 신용카드번호
      datelimit: ['', ''], // 카드유효기간
      creditOwn: 'own1', // 카드소유주
      creditOwnData: [
        { value: 'own1', label: '박창석' },
        { value: 'own2', label: '홍길동' }
      ],
      creditSelect: 'date1', // 할부기간
      creditSelectData: [
        { value: 'date1', label: '일시불' },
        { value: 'date2', label: '2개월' }
      ],
      // 제휴혜택
      methodVal: '',
      interestVal: '',
      interestCaseLabel: '무이자 할부',
      interestList: [
        { value: 'val1', label: '무이자(2개월)' },
        { value: 'val2', label: '무이자(3개월)' },
        { value: 'val3', label: '무이자(6개월)' },
        { value: 'val4', label: '무이자(12개월)' }
      ],
      requestCheck: false, // 카드 한도 상향 신청
      saveCheck: false, // 세이브오토
      // 확인사항
      agreeCheck: '',
      agreeCheckData: [
        {
          value: 'check1',
          label: '상기 입력하신 할인/포인트/할부/결제수단 등 결제정보는 결제완료 후 변경이 불가합니다.'
        },
        {
          value: 'check2',
          label: '차량결제 관련 신용카드 헤택은 당사와 무관하므로 각 카드사에 적용 기준을 확인하고 입력하시기 바랍니다.'
        },
        { value: 'check3', label: '신용카드 결제 시 단기의무보험료는 차량 가액 결제와 분할되어 별도 승인 처리됩니다.' },
        {
          value: 'check4',
          label: '결제요청 후 출고처리가 진행되며 출고처리 후에 취소하는 경우에는 왕복탁송료가 발생합니다.'
        }
      ],
      bankPaymentPrice: '', // 무통장 결제예정금액
      deposit: 'deposit1', // 무통장 입금자
      depositData: [
        { value: 'deposit1', label: '박창석' },
        { value: 'deposit2', label: '홍길동' }
      ],
      depositBank: '', // 무통장 은행
      depositBankData: [
        { value: 'bank1', label: '우리은행' },
        { value: 'bank2', label: '국민은행' }
      ],

      // 2021.03.31 (ver1.2) 추가
      creditPrice: true,
      bankRadio: true,
      bankCreditRadio: true,
    }
  },
  computed: {
    rules() {
      return {
        cardNumber: [
          {
            required: true,
            message: '* 카드번호를 입력해 주세요.',
            trigger: 'blur'
          }
        ],
        datelimit: [
          {
            required: true,
            message: '* 유효기간을 입력해 주세요.',
            trigger: 'blur'
          }
        ]
      }
    }
  },
  // 2021.03.17 (ver1.0) 추가
  updated() {
    this.setLabel((idg) => {
      // console.dir(idg) // 자동 생성된 ID 배열
    })
  },
  // 2021.03.17 (ver1.0) 추가
  methods: {
    setAct(index) {
      if (this.listSelected[index] === false) {
        this.$set(this.listSelected, index, true)
      } else {
        this.$set(this.listSelected, index, false)
      }
    },
    isAct(index) {
      return this.listSelected[index] === true
    },
    setInterest(item) {
      this.interestCaseLabel = item.label
    },
    checkMethod(val, item) {
      this.methodVal = val
      this.interestVal = ''
      if (val === 3) {
        this.setInterest(item)
        this.interestVal = item.value
      }
    }
  }
}
</script>
