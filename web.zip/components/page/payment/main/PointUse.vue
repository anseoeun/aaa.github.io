<template>
  <section class="information-detail">
    <div class="summary-info">
      <h1 class="title">포인트정보</h1>
      <div class="total-price">사용 금액 <span class="price">225,000</span> 원</div>
      <v-btn
        class="btn-detail"
        type="icon"
        :icon-class="['icon-open', { active: isOptionsShow }]"
        @click="isOptionsShow = !isOptionsShow"
        ><span class="offscreen">상세보기</span></v-btn
      >
    </div>
    <div v-show="isOptionsShow" class="detail-info" :class="{ active: isOptionsShow }">
      <!-- 2021.03.17 (ver1.0) 수정 -->
      <div class="form-grid-list point-use">
        <div class="sub-title bold">포인트 사용</div>
        <ul>
          <li>
            <div class="form-label full">
              <strong>블루멤버스 포인트</strong>
              <v-popover width="255" trigger="hover" placement="bottom-start">
                <p class="tooltip-txt">
                  블루멤버스 포인트는 5년간 최대 200만<br />포인트까지 차량금액 총 할인한도(30%)<br />내에서 사용
                  가능합니다.
                </p>
                <v-btn slot="reference"><i class="icon-help"></i></v-btn>
              </v-popover>
            </div>
            <div class="form-group full">
              <ul class="desc-list">
                <li v-for="(item, index) in bluePointList" :key="index">
                  <v-checkbox :one-check="true" :checked.sync="item.value">{{ item.name }}</v-checkbox>
                  <ul>
                    <li class="btn-wrap">
                      <v-btn class="btn-more">포인트 조회</v-btn>
                      <v-btn class="btn-more">사용하기</v-btn>
                      <v-btn class="btn-more">취소하기</v-btn>
                    </li>
                    <li class="point-wrap">
                      <div class="point-state ct">
                        사용가능 {{ item.maxLimitUsablePoint }} P <span>보유 {{ item.myAccumulatedPoint }} P</span>
                      </div>
                      <div class="point-box">
                        <v-checkbox :one-check="true" :checked.sync="item.totalUse" @change="totalSet(item)"
                          >전액사용</v-checkbox
                        >
                        <div class="label-input">
                          <label class="offscreen">포인트 사용</label>
                          <v-input v-model="item.inputTotal" />
                        </div>
                        <!-- asis -->
                        <!-- <el-input
                          v-model="point"
                          :disabled="pointUseSuccess"
                          @focus="point = String(point).replace(/[^\d]+/g, '')"
                          @keydown="$utils.onlyNumber"
                          @blur="onFocusoutPoint"
                        >
                        </el-input> -->
                      </div>
                    </li>
                  </ul>
                </li>
              </ul>
            </div>
          </li>
          <li>
            <div class="form-label full">
              <strong>M포인트</strong>
              <v-popover width="255" trigger="hover" placement="bottom-start">
                <p class="tooltip-txt">
                  M포인트는 M계열 카드로 어디서든 쓰면<br />쓸수록 더 쌓아주는 포인트로 다양한 영역에서<br />사용할 수 있습니다.
                </p>
                <v-btn slot="reference"><i class="icon-help"></i></v-btn>
              </v-popover>
            </div>
            <div class="form-group full">
              <ul class="desc-list">
                <li v-for="(item, index) in mPointList" :key="index">
                  <v-checkbox :one-check="true" :checked.sync="item.value">{{ item.name }}</v-checkbox>
                  <ul>
                    <li class="btn-wrap">
                      <v-btn class="btn-more">포인트 조회</v-btn>
                      <v-btn class="btn-more">사용하기</v-btn>
                      <v-btn class="btn-more">취소하기</v-btn>
                    </li>
                    <li class="point-wrap">
                      <div class="point-state ct">
                        사용가능 {{ item.maxLimitUsablePoint }} P <span>보유 {{ item.myAccumulatedPoint }} P</span>
                      </div>
                      <div class="point-box">
                        <v-checkbox :one-check="true" :checked.sync="item.totalUse" @change="totalSet(item)"
                          >전액사용</v-checkbox
                        >
                        <div class="label-input">
                          <label class="offscreen">포인트 사용</label>
                          <v-input v-model="item.inputTotal" />
                        </div>
                        <!-- asis -->
                        <!-- <el-input
                          v-model="point"
                          :disabled="pointUseSuccess"
                          @focus="point = String(point).replace(/[^\d]+/g, '')"
                          @keydown="$utils.onlyNumber"
                          @blur="onFocusoutPoint"
                        >
                        </el-input> -->
                      </div>
                    </li>
                  </ul>
                </li>
              </ul>
            </div>
          </li>
        </ul>
      </div>

      <div class="point-info">
        <div class="point-using">
          <strong class="bold">포인트 사용금액</strong>
          <span class="price">{{ pointUseSuccess }} 원</span>
        </div>
        <p class="bullet">실제 적용할 수 있는 포인트 사용금액은 사용가능 포인트보다 적을 수 있습니다.</p>
        <div class="point-saving">
          <strong class="bold">블루멤버스 적립예정 포인트</strong>
          <span class="price t-blue">{{ intendedBluemembersPoint }} P</span>
        </div>
        <div class="point-plane">
          <v-checkbox :one-check="true" :checked.sync="planePoint">적립 예정 포인트 선사용</v-checkbox>
          <span class="price">{{ planPointUse }} P</span>
        </div>
        <ul class="bullet-list">
          <li>차량판매가의 0.3%가 블루멤버스 포인트로 적립됩니다. 적립 대상은 주계약자에 한합니다.</li>
          <li>차량판매가=(차종 + 색상 + 옵션 + H Genuine Accessories) - 할인금액</li>
        </ul>
      </div>
    </div>
  </section>
</template>
<script>
export default {
  components: {},
  data() {
    return {
      isOptionsShow: false,
      bluePointList: [
        {
          name: '박창석',
          value: false,
          totalUse: false,
          maxLimitUsablePoint: '200,000',
          myAccumulatedPoint: '1,500',
          inputTotal: ''
        },
        {
          name: '김효중',
          value: false,
          totalUse: false,
          maxLimitUsablePoint: '10,000',
          myAccumulatedPoint: '1,000',
          inputTotal: ''
        },
        {
          name: '이숙영',
          value: false,
          totalUse: false,
          maxLimitUsablePoint: '500,000',
          myAccumulatedPoint: '100,000',
          inputTotal: ''
        }
      ],
      mPointList: [
        {
          name: '김현대',
          value: false,
          totalUse: false,
          maxLimitUsablePoint: '200,000',
          myAccumulatedPoint: '1,500',
          inputTotal: ''
        },
        {
          name: '이현대',
          value: false,
          totalUse: false,
          maxLimitUsablePoint: '10,000',
          myAccumulatedPoint: '1,000',
          inputTotal: ''
        },
        {
          name: '박현대',
          value: false,
          totalUse: false,
          maxLimitUsablePoint: '500,000',
          myAccumulatedPoint: '100,000',
          inputTotal: ''
        }
      ],
      pointUseSuccess: '225,000',
      intendedBluemembersPoint: '000,000',
      planePoint: false,
      planPointUse: '00,000',
    }
  },

  // 2021.03.19 (ver1.1) mounted -> updated로 수정
  updated() {
    this.setLabel((idg) => {
      // console.dir(idg) // 자동 생성된 ID 배열
    })
  },
  methods: {
    totalSet(item) {
      item.totalUse ? (item.inputTotal = item.myAccumulatedPoint) : (item.inputTotal = '')
    }
  }
}
</script>
