<template>
  <section class="information-detail">
    <div class="summary-info">
      <!-- 2021.04.14 (ver1.3) 띄어쓰기 -->
      <h1 class="title">할인 정보</h1>
      <div class="total-price">총 할인 금액 <span class="minus">(-)</span><span class="price">9,386,070</span> 원</div>
      <v-btn
        class="btn-detail"
        type="icon"
        :icon-class="['icon-open', { active: isOptionsShow }]"
        @click="isOptionsShow = !isOptionsShow"
        ><span class="offscreen">상세보기</span></v-btn
      >
    </div>
    <div v-show="isOptionsShow" class="detail-info" :class="{ active: isOptionsShow }">
      <!-- 2021.04.14 (ver1.3) sale 클래스 추가 -->
      <div class="info-grid-list sale">
        <ul>
          <!-- 2021.04.14 (ver1.3) 수정 -->
          <li>
            <div class="info-title">
              <strong class="bold">직원할인</strong>
              <span class="t-blue">(할인율 26%)</span>
            </div>
            <div class="info-group">
              <span class="price t-blue">(-) 5,385,070 원</span>
            </div>
            <p class="text-info">직원 인증을 위한 유효기간이 만료되었습니다. 결제 후 증빙서류 제출 바랍니다.</p>
          </li>
          <li>
            <!-- 2021.04.14 (ver1.3) bold 클래스 추가 -->
            <strong class="info-title bold">차량할인</strong>
            <div class="info-group">
              <!-- 2021.04.14 (ver1.3) 수정 start -->
              <ul class="desc-list">
                <li>
                  <em>기본할인</em>
                  <span class="price t-blue">(-) 100,000 원</span>
                </li>
                <li>
                  <em>금리할인상품명</em>
                  <span class="last">표준형 할부 / 금리 1.25%</span>
                </li>
                <li>
                  <em>기획전할인</em>
                  <span class="price t-blue">(-) 100,000 원</span>
                </li>
              </ul>
              <!-- end -->
            </div>
          </li>
          <li>
            <!-- 2021.04.14 (ver1.3) bold 클래스 추가 -->
            <strong class="info-title bold">타겟조건할인</strong>
            <div class="info-group">
              <ul class="desc-list">
                <li>
                  <em>타겟조건할인명 1</em>
                  <!-- 2021.04.14 (ver1.3) t-blue 클래스 추가 -->
                  <span class="price t-blue">(-) 321,000 원</span>
                </li>
                <li>
                  <em>타겟조건할인명 1</em>
                  <!-- 2021.04.14 (ver1.3) t-blue 클래스 추가 -->
                  <span class="price t-blue">(-) 321,000 원</span>
                </li>
              </ul>
            </div>
          </li>
          <li>
            <!-- 2021.04.14 (ver1.3) bold 클래스 추가 -->
            <strong class="info-title bold">쿠폰할인</strong>
            <div class="info-group">
              <ul class="desc-list">
                <li>
                  <em>온라인 쿠폰명</em>
                  <!-- 2021.04.14 (ver1.3) t-blue 클래스 추가 -->
                  <span class="price t-blue">(-) 100,000 원</span>
                </li>
              </ul>
            </div>
          </li>
          <li>
            <!-- 2021.04.14 (ver1.3) bold 클래스 추가 -->
            <strong class="info-title bold">지인추천할인</strong>
            <div class="info-group">
              <ul class="desc-list">
                <li>
                  <!-- 2021.04.14 (ver1.3) 수정 -->
                  <em>추천인 코드 <span>XTS0135792HO</span></em>
                  <!-- 2021.04.14 (ver1.3) t-blue 클래스 추가 -->
                  <span class="price t-blue">(-) 100,000 원</span>
                </li>
              </ul>
            </div>
          </li>
        </ul>

        <!-- 2021.03.31 (ver1.2) 추가 -->
        <!-- 2021.04.14 (ver1.3) t-blue 클래스 수정 -->
        <p class="bullet">할인정보를 변경하시려면 [할인정보 변경] 버튼을 클릭하세요. <v-btn class="btn-more" @click="discountChangePopup = true">할인정보 변경</v-btn></p>

        <!-- 2021.03.31 (ver1.2) 팝업 추가 -->
        <discount-change-popup :visible="discountChangePopup" @close="discountChangePopup = false" />

      </div>
    </div>
  </section>
</template>

<script>
import DiscountChangePopup from '~/components/page/mypage/purchase/contract-detail/popups/DiscountChangePopup'
export default {
  components: {
    DiscountChangePopup,
  },
  data() {
    return {
      isOptionsShow: false,
      // 2021.03.31 (ver1.2) 팝업 추가
      discountChangePopup: false,
    }
  }
}
</script>
