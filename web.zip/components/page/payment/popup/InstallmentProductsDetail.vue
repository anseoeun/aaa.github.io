<template>
  <div>
    <!-- Popup - 할부상품 > 표준형 -->
    <v-popup :visible="isPopupPay1" :footer="['confirm']" :width="'776px'" popup-type="v2 auto" @close="closePopUp">
      <template slot="header">
        <div class="title">할부 상품 안내</div>
      </template>
      <template slot="body">
        <p class="popup-sub-tit">표준형</p>
        <p class="text-main">할부기간 동안 매월 일정한 금액을 납부하는 방식</p>
        <div class="paygraph-wrap type1">
          <span class="offscreen">그래프 이미지 (하단 표 데이터 참조)</span>
        </div>
        <div class="table-area nohead">
          <table class="noline">
            <colgroup>
              <col width="113px" />
              <col width="auto" />
            </colgroup>
            <tbody>
              <tr>
                <th class="bold">상환방법</th>
                <td class="left">
                  <ul class="table-list">
                    <li>원리금 균등상환 방식</li>
                    <li>할부기간 동안 매월 일정한 금액의 월 납입금 상환</li>
                    <li>최고 60개월까지 할부기간을 설정하여 월 납입금 부담 감소</li>
                  </ul>
                </td>
              </tr>
              <tr>
                <th class="bold">추천고객</th>
                <td class="left">
                  <ul class="table-list">
                    <li>수입이 일정한 고객</li>
                    <li>월 납입금 부담을 줄이고 싶은 고객</li>
                  </ul>
                </td>
              </tr>
              <tr>
                <th class="bold">기본조건</th>
                <td class="left">
                  <ul class="table-list">
                    <li>
                      <span>기간</span>
                      <em>3-60개월</em>
                    </li>
                    <li>
                      <span>선수율</span>
                      <em>제한없음</em>
                    </li>
                    <li>
                      <span>금리</span>

                      <!-- 2021.03.24 (ver1.2) -->
                      <em>4.5%</em>
                    </li>
                  </ul>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </template>
    </v-popup>

    <!-- Popup - 할부상품 > 잔가보장형 -->
    <v-popup :visible="isPopupPay2" :footer="['confirm']" :width="'776px'" popup-type="v2 auto" @close="closePopUp">
      <template slot="header">
        <div class="title">할부 상품 안내</div>
      </template>
      <template slot="body">
        <p class="popup-sub-tit">잔가보장형</p>
        <p class="text-main">
          총 할부금의 일부는 원금과 이자를 일정하게 납부하고,<br />남은 원금은 이자만 납부하다가 만기 시 한번에 상환하는
          방식<br />단, 만기에 차량 반납만으로 최대유예율 수준 잔가 보장
        </p>
        <div class="paygraph-wrap type2">
          <span class="offscreen">그래프 이미지 (하단 표 데이터 참조)</span>
        </div>
        <div class="table-area nohead">
          <table class="noline">
            <colgroup>
              <col width="113px" />
              <col width="auto" />
            </colgroup>
            <tbody>
              <tr>
                <th class="bold">상환방법</th>
                <td class="left">
                  <ul class="table-list">
                    <li>원금 일부를 유예하여 월 납입금 부담을 완화하는 상환방식</li>
                    <li>만기 시 차량 반납/만기 연장/일시 상환 중 택일하여 잔여 유예금을 납부</li>
                    <li>차량 반납 보장률에 따라 보장하며, 매각대금 정산 후 잔액은 고객에게 송금</li>
                  </ul>
                </td>
              </tr>
              <tr>
                <th class="bold">추천고객</th>
                <td class="left">
                  <ul class="table-list">
                    <li>자동차 교체주기가 3-4년으로 짧은 고객</li>
                    <li>원하는 차종의 월 납입금이 부담스러운 고객</li>
                  </ul>
                </td>
              </tr>
              <tr>
                <th class="bold">기본조건</th>
                <td class="left">
                  <ul class="table-list">
                    <li>
                      <span>기간</span>
                      <em>36개월, 48개월</em>
                    </li>
                    <li>
                      <span>선수율</span>
                      <em>제한없음</em>
                    </li>
                    <li>
                      <span>금리</span>
                      <em>5.5%-5.7%</em>
                    </li>
                  </ul>
                </td>
              </tr>
            </tbody>
          </table>
        </div>

        <!-- 2021.03.24 (ver1.2) -->
        <div class="notice">
          <div class="contents-head">차량가치 보장 안내</div>
          <ul class="bullet-list">
            <li>차량 반납 신청 시, 아래의 “적용 불가” 경우 확인 후 반납 절차 진행</li>
            <li>
              차량 경매 후, 낙찰금액에 대해 고객 동의 후 최종 낙찰<br />(미동의 시 재경매 또는 반환하며, 반환할 경우에는
              차량 반환 탁송료 5만원 부과)
            </li>
            <li>찰 매각대금으로 할부 잔액 정산 후, 잔여금은 고객 송금</li>
            <li>낙찰 매각대금이 최소 보장금액보다 낮은 경우 현대캐피탈이 부담하여 정산 또는 송금</li>
          </ul>
          <p class="bullet-star">최소 보장금액 : 차량 구매 가격 x 차종별 최소 보장률</p>

          <div class="contents-head">차량가치 보장 “적용 불가” 경우</div>
          <ul class="bullet-list">
            <li>연간 운행거리 (연 30,000 Km)를 초과한 차량 또는 주행거리 조작 차량</li>
            <li>대출상품이 중도해지, 연체 등의 사유로 효력을 상실한 경우</li>
            <li>차량의 소유권이 제 3자에게 이전되거나 소유권 이전에 장애가 잇는 경우</li>
            <li>
              차량의 파손 (전손, 화재, 침수, 반파) 부품의 도난·망실, 수리 및 교체 불능으로 원상 복구가 되지 않을 경우
            </li>
            <li>차량의 엔진, 동력장치, 조향장치, 제동장치의 이상으로 정상적인 작동이 불가능한 경우</li>
            <li>반납 시, 제품의 결함으로 인한 제품회수 (Recall) 대상차량인 경우</li>
          </ul>

          <div class="contents-head">반납 시 유의사항</div>
          <ul class="bullet-list">
            <li>
              경매출품 수수료, 탁송료, 낙찰 수수료는 면제 (단, 고객 미동의로 유찰 시, 차량 반환 탁송료 5만원 고객 부담)
            </li>
            <li>차량 매각 후 명의 이전 시점까지 차량 보험 유지 필수 (고객 부담)</li>
            <li>반납/경매 과정에서 발생하는 추가 비용 (설정/압류 해지비용, 범칙금 등)은 고객 부담</li>
          </ul>
        </div>
      </template>
    </v-popup>

    <!-- Popup - 할부상품 > 거치형 -->
    <v-popup :visible="isPopupPay3" :footer="['confirm']" :width="'776px'" popup-type="v2 auto" @close="closePopUp">
      <template slot="header">
        <div class="title">할부 상품 안내</div>
      </template>
      <template slot="body">
        <p class="popup-sub-tit">거치형</p>
        <p class="text-main">초기 1년간 이자만 내고, 1년 후부터 일정한 할부금을 매월 일정하게 나눠내는 상환 방식</p>
        <div class="paygraph-wrap type3">
          <span class="offscreen">그래프 이미지 (하단 표 데이터 참조)</span>
        </div>
        <div class="table-area nohead">
          <table class="noline">
            <colgroup>
              <col width="113px" />
              <col width="auto" />
            </colgroup>
            <tbody>
              <tr>
                <th class="bold">상환방법</th>
                <td class="left">
                  <ul class="table-list">
                    <li>1년간 이자만 납부하면서 월 납입금을 최소화하는 방식</li>
                    <li>이후 남은 할부원금은 2-3년에 걸쳐 분할 상환</li>
                    <li>할부 전 기간 중도상환 수수료 면제 혜택</li>
                  </ul>
                </td>
              </tr>
              <tr>
                <th class="bold">추천고객</th>
                <td class="left">
                  <ul class="table-list">
                    <li>신규 사업자, 신입사원 등 초기 월 납입금이 부담되는 고객</li>
                    <li>목돈이 생기면 자유롭게 상환하고 싶은 고객</li>
                  </ul>
                </td>
              </tr>
              <tr>
                <th class="bold">기본조건</th>
                <td class="left">
                  <ul class="table-list">
                    <li>
                      <span>기간</span>
                      <em>36개월, 48개월, 60개월</em>
                    </li>
                    <li>
                      <span>선수율</span>
                      <em>제한없음</em>
                    </li>
                    <li>
                      <span>금리</span>
                      <em>5.5%-5.7%</em>
                    </li>
                  </ul>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </template>
    </v-popup>

    <!-- Popup - 할부상품 > 유예형 -->
    <v-popup :visible="isPopupPay4" :footer="['confirm']" :width="'776px'" popup-type="v2 auto" @close="closePopUp">
      <template slot="header">
        <div class="title">할부 상품 안내</div>
      </template>
      <template slot="body">
        <p class="popup-sub-tit">유예형</p>
        <p class="text-main">
          총 할부금의 일부는 원금과 이자를 일정하게 납부하고,<br />남은 원금은 이자만 일정하게 납부하다가 만기시 한번에
          상환하는 방식
        </p>
        <div class="paygraph-wrap type4">
          <span class="offscreen">그래프 이미지 (하단 표 데이터 참조)</span>
        </div>
        <div class="table-area nohead">
          <table class="noline">
            <colgroup>
              <col width="113px" />
              <col width="auto" />
            </colgroup>
            <tbody>
              <tr>
                <th class="bold">상환방법</th>
                <td class="left">
                  <ul class="table-list">
                    <li>원금 일부를 유예하여 월 납입금 부담을 완화하는 상환 방식</li>
                    <li>3년 최대 5%, 4년 45%까지 원금 유예 가능</li>
                    <li>만기 시 잔여 유예금에 대해 만기연장 가능</li>
                  </ul>
                </td>
              </tr>
              <tr>
                <th class="bold">추천고객</th>
                <td class="left">
                  <ul class="table-list">
                    <li>자동차 교체 주기가 짧은 고객</li>
                    <li>월 납입금에 부담을 느끼는 고객</li>
                  </ul>
                </td>
              </tr>
              <tr>
                <th class="bold">기본조건</th>
                <td class="left">
                  <ul class="table-list">
                    <li>
                      <span>기간</span>

                      <!-- 2021.03.24 (ver1.2) -->
                      <em>36개월, 48개월</em>
                    </li>
                    <li>
                      <span>선수율</span>
                      <em>제한없음</em>
                    </li>
                    <li>
                      <span>금리</span>
                      <em>5.5%-5.7%</em>
                    </li>
                    <li>
                      <span>최대 유예율</span>
                      <em>36개월 최대 55% / 48개월 최대 45%</em>
                    </li>
                  </ul>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </template>
    </v-popup>
  </div>
</template>

<script>
import { VPopup } from '~/components/element'
export default {
  components: {
    VPopup
  },
  props: {
    visible: {
      type: Boolean,
      default: false
    },
    isPopupModel: {
      type: Boolean,
      default: false
    },
    isPopupPay1: {
      type: Boolean,
      default: false
    },
    isPopupPay2: {
      type: Boolean,
      default: false
    },
    isPopupPay3: {
      type: Boolean,
      default: false
    },
    isPopupPay4: {
      type: Boolean,
      default: false
    }
    // popVisible: {
    //   type: Object,
    //   default: () => { return {} },
    //   required: true
    // },
  },
  data() {
    return {}
  },
  watch: {
    isPopupModel(value) {
      this.isPopupModel = value
    }
  },

  // 2021.03.17 (ver1.1)
  updated() {
    this.setCaption()
  },
  methods: {
    closePopUp() {
      this.$emit('onClose')
    }
  }
}
</script>
