<template>
  <v-popup
    :visible="popVisible.tinting"
    :width="'776px'"
    @close="popVisible.tinting = false"
  >
    <template slot="header">
      <div class="title">썬팅 장착점 조회</div>
    </template>
    <template slot="body">
      <div class="location-input">
        <v-select v-model="locationSelect1" :data="location1" placeholder="시/도 선택"></v-select>
        <v-select v-model="locationSelect2" :data="location2" :disabled="locationSelect1 === '' ? true : false" placeholder="시/군/구 선택"></v-select>
        <!-- 2021.03.23(ver1.1) 썬팅지 선택 삭제 -->
      </div>
      <div class="location-map">
        <ul class="area-map-list">
          <li v-for="(map, index) in mapList" :key="index">
            <div class="map-info">
              <div class="tit">
                <strong>{{ map.store }}</strong>
                <!-- <span class="tag">(종합블루핸즈)</span> -->
              </div>
              <div class="desc">
                <div class="left">
                  <p class="store-address">
                    {{ map.address }}
                  </p>
                  <p class="store-call">{{ map.tel }} / {{ map.phone }}</p>
                </div>
                <div class="right">
                  <v-btn type="icon" class="btn-map" :icon-class="['icon-tog-arr', { on: isActive(index)}]" @click="setActive(index)">지도</v-btn>
                  <v-btn
                    class="btn md white r"
                    @click="popVisible.tinting = false"
                  >
                    선택
                  </v-btn>
                </div>
              </div>
            </div>
            <div v-if="isActive(index)" class="map-view">
              <div style="height:100%;background:#f9f9f9"> 지도영역</div>
            </div>
          </li>
        </ul>
      </div>
    </template>
    <template v-if="locationResult" slot="footer">
      <v-pagination :total="100" />
    </template>
  </v-popup>
</template>

<script>
import { VPopup, VBtn, VPagination, VSelect } from '~/components/element'
export default {
  components: {
    VPopup,
    VBtn,
    VSelect,
    VPagination
  },
  props: {
    popVisible: {
      type: Object,
      defualt: {},
      required: true
    }
  },
  data() {
    return {
      visible: true,
      locationSelect1:'',
      locationSelect2:'',
      location1: [
        {
          name: '1',
          value: '서울시'
        },
        {
          name: '2',
          value: '경기도'
        },
        {
          name: '3',
          value: '인천광역시'
        }
      ],
      location2: [
        {
          name: '1',
          value: '강남구'
        },
        {
          name: '2',
          value: '강북구'
        },
        {
          name: '3',
          value: '강서구'
        }
      ],
      locationSelectValue: '',
      locationResult: true,
      isMapView: false,
      listSelected:'',
      mapList:[
        {store:'오토뱅크', address:'서울 특별시 강동구 양재대로 122 가길 1 (길동)', tel:'02-459-8330', phone:'010-5325-0234'},
        {store:'스파이&플럭스 ', address:'서울특별시 강남구 개포로22길 34(개포동) 스파이&플럭스 오토', tel:'02-459-8330', phone:'010-5325-0234'},
      ]
    }
  },
  watch:{
    popVisible: {
      deep: true,
      handler() {
       this.listSelected = 0
       this.locationSelect1 = ''
       this.locationSelect2 = ''
       this.locationSelect3 = ''
      },
    },
  },
  methods:{
    setActive(index){
      if(this.listSelected == index+1){
        this.listSelected = 0
      }else{
        this.listSelected = index+1
      }
    },
    isActive(index){
      return this.listSelected == index+1
    }
  }
}
</script>
