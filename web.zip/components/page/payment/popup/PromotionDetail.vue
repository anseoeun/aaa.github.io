<template>
  <v-popup
    :visible="popVisible.promotionDetail"
    :width="popupWidth"
    :footer="footerBtn"
    @close="popVisible.promotionDetail = false"
  >
    <template slot="header">
      <h3 class="header-title">뉴스타트페스타 특별 저금리</h3>
      <p class="header-description">
        파격적인 할인과 파격적인 금리!<br />
        1.25%의 초저금리 이용가능
      </p>
    </template>
    <template slot="body">
      <div class="body-contents">
        <ul class="depth-1">
          <li class="single-list">
            <p class="title">할부상품</p>
            <div class="description">
              <ul class="depth-2">
                <li>표준형 할부 상품</li>
              </ul>
            </div>
          </li>
          <li>
            <p class="title">추천고객</p>
            <div class="description">
              <ul class="depth-2">
                <li>월 소득액이 일정한 고객</li>
                <li>할인 혜택과 금리혜택을 동시에 누리고 싶어 하는 경제적 민감도 高 고객</li>
                <li>고금리 시대 낮은 금리를 선호하는 금리 민감 고객</li>
              </ul>
            </div>
          </li>
          <li class="is-sub-contents">
            <p class="title">기본조건</p>
            <div class="description">
              <div class="sub-contents">
                <ul class="sub-list">
                  <li>
                    <p class="sub-title">적용 차종</p>
                    <p class="sub-description">
                      아반떼 19년 1월 이전
                      <span class="is-mo">생산재고에 한하여 적용</span>
                    </p>
                  </li>
                  <li>
                    <p class="sub-title">기간</p>
                    <p class="sub-description">36개월 이하</p>
                  </li>
                  <li>
                    <p class="sub-title">금리</p>
                    <p class="sub-description">1.25% 저금리</p>
                  </li>
                </ul>
              </div>
            </div>
          </li>
        </ul>
        <p class="notice">해당 상품은 밸류플러스와 중복 적용 불가합니다.</p>
      </div>
    </template>
  </v-popup>
</template>

<script>
import { VPopup } from '~/components/element'
export default {
  components: {
    VPopup
  },
  props: {
    popVisible: {
      type: Object,
      defualt: {},
      required: true
    }
  },
  data() {
    return {
      footerBtn: [],
      popupWidth: '820px'
    }
  },
  mounted() {
   this.footerBtn = []
  }
}
</script>