<template>
  <v-popup
    :visible="popVisible.infoFund"
    :footer="['confirm']"
    :width="'1000px'"
    @confirm="popVisible.infoFund = false"
    @close="popVisible.infoFund = false"
  >
    <template slot="header">
      <div class="title">공채 안내</div>
    </template>
    <template slot="body">
      <ul class="bullet-list">
        <li>
          공채는 자동차를 등록할 때 매입해야 하는 지방채로 지자체별로 채권의 종류, 매입액 등이 다르고, 등록 시점에 따라 변경될 수 있습니다.
        </li>
        <li>
          채권은 차량 등록 지역에 따라 도시철도 채권 이나 지역개발채권으로 구분하여 매입합니다.
        </li>
        <li>
          채권 매입금액은 등록할 차량의 차종 그리고 해당 지역 공채매입 요율에 의해서 채권 매입액이 산출됩니다.
        </li>
        <li>
          <strong>공채매입금액(계산) = 차량가격(세금계산서금액, 부가세, 탁송료)/1.1 x 등록지역 공채매입 요율</strong>
        </li>
      </ul>

      <p class="contents-head">* 공채 할인</p>
      <ul class="bullet-list">
        <li>
          자동차 구입 초기 비용 부담을 덜기 위해 채권 매입 후 금융사에 일정 할인을 적용해서 즉시 매도하는 것으로, 차량등록사업소 내 은행출장소에서 할인비용만 지급하여 처리할 수 있습니다.
        </li>
        <li>
          할인비용 = 공채매입금액 x 할인율(채권별로 매일 변동되며 등록지역 차량등록사업소에서 확인 가능합니다.)
        </li>
      </ul>

      <p class="contents-head">* 채권의 종류</p>
      <div class="table-area">
        <table>
          <colgroup>
            <col width="25%" />
            <col width="25%" />
            <col width="25%" />
            <col width="25%" />
          </colgroup>
          <thead>
            <tr>
              <th>종류</th>
              <th>지역</th>
              <th>원금/이자상환</th>
              <th>선택 품목</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td rowspan="2">도시철도채권<br />(지하철 공채)</td>
              <td>서울</td>
              <td>7년 거치 후 일시 상환</td>
              <td>
                연 2.0 % <br />
                최초 5년간 1년 단위로 복리<br />
                나머지 2년은 단리로 계산
              </td>
            </tr>
            <tr>
              <td>부산, 대구</td>
              <td>5년 거치 후 일시 상환</td>
              <td>연 2.0 % 1년 단위 복리</td>
            </tr>
            <tr>
              <td>지역개발채권</td>
              <td>기타 지역</td>
              <td>5년 거치 후 일시 상환</td>
              <td>연 2.0 % 1년 단위 복리</td>
            </tr>
          </tbody>
        </table>
      </div>

      <p class="contents-head">
        * 비사업용 차량 채권 매입금액 요율 – 서울(도시철도채권) 신규등록기준
      </p>
      <div class="table-area">
        <colgroup>
          <col width="113px" />
          <col width="113px" />
          <col width="auto" />
          <col width="225px" />
        </colgroup>
        <table>
          <thead>
            <tr>
              <th colspan="2">종류</th>
              <th>원금/이자상환</th>
              <th>도시철도채권(예:서울)</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td rowspan="9">비사업용</td>
              <td rowspan="6">승용</td>
              <td>1,000cc 미만</td>
              <td>0%</td>
            </tr>
            <tr>
              <td>
                소형(1,000cc~1,600cc 로 길이 4.7m, 너비 1.7m, 높이 2m 이하인 것)
              </td>
              <td>9%</td>
            </tr>
            <tr>
              <td>
                중형(1600cc~2,000cc 미만이거나 <br />
                길이,너비,높이중 어느 하나라도 소형을 초과하는 것)
              </td>
              <td>12%</td>
            </tr>
            <tr>
              <td>
                대형(2,000cc 이상이거나 길이,너비,높이 모두 소형을 초과 하는 것)
              </td>
              <td>20%</td>
            </tr>
            <tr>
              <td>
                다목적 형
              </td>
              <td>5%</td>
            </tr>
            <tr>
              <td>
                7-10인승
              </td>
              <td>39만원 정액</td>
            </tr>
            <tr>
              <td rowspan="2">승합</td>
              <td>
                소형(승차정원 11명 이상 15명 이하인 승합자동차로서 길이 4.7미터, 너비 1.7 미터, 높이 2.0미터 이하인 것)
              </td>
              <td>39만원 정액</td>
            </tr>
            <tr>
              <td>
                중형(길이, 너비, 높이 어느 하나라도 소형을 초과 한 것)
              </td>
              <td>65만원 정액</td>
            </tr>
            <tr>
              <td>화물</td>
              <td>
                최대적재량 1톤 이하로써 총중량 3.5톤 이하인 것
              </td>
              <td>19.5만원 정액</td>
            </tr>
          </tbody>
        </table>
      </div>

      <p class="contents-head">* 장애인 공채매입면제</p>
      <div class="table-area">
        <table class="noline">
          <colgroup>
            <col width="563px" />
            <col width="auto" />
          </colgroup>
          <thead>
            <tr>
              <th>대상</th>
              <th>차종</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td class="left">
                <ul class="bullet-list">
                  <li>장애인으로서 장애등급 제1등급부터 제6급까지에 해당하는 사람</li>
                  <li>국가유공자로서 상이등급 1급부터 7급까지의 판정을 받은 사람</li>
                  <li>5.18 민주화운동부상자로서 신체장해등급 1급부터 14급까지의 판정을 받은 사람</li>
                  <li>고엽제 후유의증환자로서 경도(輕度) 장애 이상의 장애등급 판정을 받은 사람</li>
                </ul>
              </td>
              <td class="left top">
                <ul class="bullet-list">
                  <li>도시철도채권: 승용차(배기량 제한 없음), 15인승 이하 승합차</li>
                  <li>지역개발채권: 1인 1대(배기량, 차종 제한 없음)</li>
                </ul>
              </td>
            </tr>
          </tbody>
        </table>
      </div>

      <p class="contents-head">* 채권의 종류</p>
      <div class="table-area">

        <!-- 선택품목날짜경과했음 확인필요 -->
        <table class="noline">
          <colgroup>
            <col width="225px" />
            <col width="auto" />
            <col width="225px" />
          </colgroup>
          <thead>
            <tr>
              <th>차종</th>
              <th>감면 내용</th>
              <th>선택 품목</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>하이브리드</td>
              <td class="left">
                <ul class="table-list">
                  <li>서울,인천,부산,대구(달성군제외) : 200만원까지</li>
                  <li>기타지역 : 150만원까지</li>
                </ul>
              </td>
              <td>2020년 12월 31일까지</td>
            </tr>
            <tr>
              <td>전기차</td>
              <td class="left">
                <ul class="table-list">
                  <li>서울,부산,대구(달성군제외) : 250만원까지</li>
                  <li>기타지역 : 전액</li>
                </ul>
              </td>
              <td>2020년 12월 31일까지</td>
            </tr>
            <tr>
              <td>수소차</td>
              <td class="left">
                <ul class="table-list">
                  <li>서울,부산,대구(달성군제외) : 250만원까지</li>
                  <li>기타지역 : 전액</li>
                </ul>
              </td>
              <td>2020년 12월 31일까지</td>
            </tr>
          </tbody>
        </table>
      </div>
    </template>
  </v-popup>
</template>
<script>
import { VPopup } from '~/components/element'
export default {
  components: {
    VPopup
  },
  props: {
    popVisible: {
      type: Object,
      defualt: {},
      required: true
    },
  },
  mounted() {
  },

  // 2021.03.17 (ver1.1)
  updated() {
    this.setCaption()
  },
}
</script>
