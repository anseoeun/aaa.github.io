<template>
  <v-popup
    :visible="popVisible.installmentIncreaseGuide"
    :width="'550px'"
    :footer="['confirm']"
    @confirm="popVisible.installmentIncreaseGuide = false"
    @close="popVisible.installmentIncreaseGuide = false"
  >
    <template slot="header">
      <div class="title">신용카드사별 한도상향 안내</div>
    </template>
    <template slot="body">
      <div class="body-contents">
        <ul class="card-list">
          <li v-for="(item, index) in cardInfo" :key="index">
            <p class="title">{{ item.companyName }}</p>
            <p class="call">{{ item.companyTel }}</p>
          </li>
        </ul>
      </div>
      <div class="notice">
        <ul class="bullet-list">
          <li>카드사 별 고객센터에 신용카드 한도 일시 상향에 관해 문의해주세요.</li>
          <li>
            현대카드의 경우 카드번호 입력 후 나의 현대카드 혜택 조회를 통해 카드한도 상향 신청이 가능합니다.
          </li>
        </ul>
      </div>
    </template>
  </v-popup>
</template>

<script>
import { VPopup } from '~/components/element'
export default {
  components: {
    VPopup
  },
  props: {
    popVisible: {
      type: Object,
      defualt: {},
      required: true
    },
  },
  data() {
    return {
      cardInfo: [
        {
          companyName: '롯데카드',
          companyTel: '1588-8100'
        },
        {
          companyName: '비씨카드',
          companyTel: '1588-4000'
        },
        {
          companyName: '농협카드',
          companyTel: '1644-4000'
        },
        {
          companyName: '씨티카드',
          companyTel: '1588-7000'
        },
        {
          companyName: '삼성카드',
          companyTel: '1588-8700'
        },
        {
          companyName: '하나카드',
          companyTel: '1800-1111'
        },
        {
          companyName: '현대카드',
          companyTel: '1577-6000'
        },
        {
          companyName: '국민카드',
          companyTel: '1588-1688'
        },
        {
          companyName: '신한카드',
          companyTel: '1544-7000'
        }
      ]
    }
  }
}
</script>
