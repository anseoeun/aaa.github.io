<template>
  <v-popup
    :visible="popVisible.textInput"
    :width="'550px'"
    @close="popVisible.textInput = false"
  >
    <template slot="header">
      <div class="title">{{ text.installmentIncreaseHyndai.title }}</div>
      <p class="header-description">
        {{ text.installmentIncreaseHyndai.description1 }}<br />
        {{ text.installmentIncreaseHyndai.description2 }}
      </p>
    </template>
    <template slot="body">
      <!-- <div class="text">
        <p>
          {{ text.saveAuto.description1 }}<br />
          {{ text.saveAuto.description2 }}<br />
        </p>
        <div v-if="notice" class="notice">
          <p>
            {{ text.saveAuto.notice1 }} <br />
            {{ text.saveAuto.notice2 }}
          </p>
        </div>
      </div> -->
      <div class="phone-input" :class="{ inputBorder: border }">
        <p class="phone-input-title">휴대폰 번호</p>
        <v-input v-model="phoneInput" placeholder="-없이 숫자만 입력" />
      </div>
    </template>
    <template slot="footer">
      <v-btn @click="popVisible.textInput = false">
        {{ text.commonSubmit }}
      </v-btn>
    </template>
  </v-popup>
</template>

<script>
import { VPopup, VBtn, VInput } from '~/components/element'
export default {
  components: {
    VPopup,
    VBtn,
    VInput
  },
  props: {
    popVisible: {
      type: Object,
      default: () => { return {} },
      required: true
    }
  },
  data() {
    return {
      phoneInput: '',
      textInput: false,
      notice: true,
      border: false,
      text: {
        installmentIncreaseHyndai: {
          title: '카드 한도 상향 신청',
          description1: '간편하게 한도를 조회할 수 있는 URL을 보내드립니다.',
          description2: '휴대폰 번호를 입력해 주세요.'
        },
        saveAuto: {
          title: '세이브-오토 신청',
          description1: '현대자동차 신차 구매 시 포인트를 미리 받아 차량 구매 후',
          description2: '매달 M포인트로 상환하는 현대카드 프로그램 입니다.',
          // description3: '매달 M포인트로 상환하는 현대카드 프로그램입니다.',
          // description4: '휴대폰 번호를 입력하시면',
          // description5: '세이브-오토 신청 링크를 보내드립니다.'
        },
        saveAutoCard: {
          title: '카드 한도 상향 / 세이브-오토 신청',
          description1: '카드 한도 조회 및 세이브-오토 신청 URL을 보내드립니다.',
          description2: '휴대폰 번호를 입력해 주세요.',
          // notice1: '* 세이브-오토는 현대자동차 신차 구매 시 포인트를 미리 받아',
          // notice2: '차량 구매 후 매달 M 포인트로 상환하는 현대카드 프로그램입니다.'
        },
        commonSubmit: '전송하기'
      }
    }
  }
}
</script>
