<template>
  <v-popup
    :visible="popVisible.saveAuto"
    :width="'550px'"
    @close="popVisible.saveAuto = false"
  >
    <template slot="header">
      <div class="title">세이브-오토 신청</div>
      <p v-if="isComplete === 'default'" class="header-description">
        현대자동차 신차 구매 시 포인트를 미리 받아 차량 구매 후<br />매달 M포인트로 상환하는 현대카드 프로그램 입니다.
      </p>
    </template>

    <template v-if="isComplete === 'default'">
      <template slot="body">
        <el-form ref="form" :model="phoneForm" :rules="rules">
          <el-form-item prop="phoneNumber">
            <div class="form-grid">
              <div class="label-input">
                <label class="form-title">휴대폰 번호</label>
                <v-input v-model="phoneForm.phoneNumber" class="form-group" type="number" maxlength="12" placeholder="'-'없이 숫자만 입력" />
              </div>
            </div>
          </el-form-item>
        </el-form>
      </template>
      <template slot="footer">
        <v-btn class="btn btn-md" b-size="btn-md">전송하기</v-btn>
      </template>
    </template>

    <template v-if="isComplete === 'result'">
      <template slot="body">
        <div class="body-contents t-center">
          <p>입력하신 <span>010-0000-0000</span> 으로 URL을 전송하였습니다.<br /><br />세이브-오토 신청 심사를 진행해 주세요.</p>
          <p>심사 완료 후 하단 [완료] 버튼을 선택하시면 결제를 진행합니다.</p>
        </div>
      </template>
      <template slot="footer">
        <v-btn class="btn btn-md" b-size="btn-md">완료</v-btn>
      </template>
    </template>
  </v-popup>
</template>

<script>
import { VPopup, VBtn, VInput } from '~/components/element'
export default {
  components: {
    VPopup,
    VBtn,
    VInput
  },
  props: {
    popVisible: {
      type: Object,
      default: () => { return {} },
      required: true
    },
    isComplete: {
      type: String,
      default: 'default',
    },
  },
  data() {
    return {
      phoneForm: {
        phoneNumber: '',
      }
    }
  },
  computed: {
    rules() {
      return {
        phoneNumber: [
          {
            required: true,
            message: '* 휴대폰번호를 입력해 주세요',
            trigger: 'blur'
          }
        ],
      }
    },
  },

  // 2021.03.17 (ver1.1)
  updated() {
    this.setLabel((idg) => {
      // console.dir(idg) // 자동 생성된 ID 배열, 예) 첫번째 입력폼 ID : idg[0]
    })
  },
}
</script>
