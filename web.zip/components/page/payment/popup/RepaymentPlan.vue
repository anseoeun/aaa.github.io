<template>
  <v-popup
    :width="'776px'"
    :visible="popVisible.repaymentPlan"
    :footer="['confirm']"
    @confirm="popVisible.repaymentPlan = false"
    @close="popVisible.repaymentPlan = false"
  >
    <template slot="header">
      <div class="title">상환 계획</div>
    </template>
    <template slot="body">
      <!-- 2021.03.24 (ver1.2) -->
      <div class="repayment-plan-wrap">
        <!-- 2021.04.15 (ver1.3) plan-info안에 strong태그추가 -->
        <ul class="plan-info">
          <li>
            <p class="title">할부 상품</p>
            <p class="description">표준형 + (초저금리 M)</p>
          </li>
          <li>
            <p class="title">할부 원금</p>
            <p class="description"><strong>11,000,000 원</strong></p>
          </li>
          <li>
            <p class="offscreen">실 납입 할부금</p>
            <p class="description">(실 납입 할부금 14,550,000원)</p>
          </li>
          <li>
            <p class="title">선수금</p>
            <p class="description"><strong>00,000,000 원</strong></p>
          </li>
          <li>
            <p class="title"><strong>총 금액</strong></p>
            <p class="description"><strong>14,040,000 원</strong></p>
          </li>
        </ul>
        <div class="table-area">
          <table class="noline">
            <colgroup>
              <col width="auto" />
              <col width="135px" />
              <col width="155px" />
              <col width="150px" />
              <col width="155px" />
            </colgroup>
            <thead>
              <tr>
                <th>회차</th>
                <th>납입 원금</th>
                <th>할부 이자</th>
                <th>월 납입금</th>
                <th>할부 잔금</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>1</td>
                <td class="right">496,660원</td>
                <td class="right">0원</td>
                <td class="right">496,660원</td>
                <td class="right">17,383,340원</td>
              </tr>
              <tr>
                <td>2</td>
                <td class="right">496,660원</td>
                <td class="right">0원</td>
                <td class="right">496,660원</td>
                <td class="right">17,383,340원</td>
              </tr>
              <tr>
                <td>3</td>
                <td class="right">496,660원</td>
                <td class="right">0원</td>
                <td class="right">496,660원</td>
                <td class="right">17,383,340원</td>
              </tr>
              <tr>
                <td>4</td>
                <td class="right">496,660원</td>
                <td class="right">0원</td>
                <td class="right">496,660원</td>
                <td class="right">17,383,340원</td>
              </tr>
              <tr>
                <td>5</td>
                <td class="right">496,660원</td>
                <td class="right">0원</td>
                <td class="right">496,660원</td>
                <td class="right">17,383,340원</td>
              </tr>
              <tr>
                <td>6</td>
                <td class="right">496,660원</td>
                <td class="right">0원</td>
                <td class="right">496,660원</td>
                <td class="right">17,383,340원</td>
              </tr>
              <tr>
                <td>7</td>
                <td class="right">496,660원</td>
                <td class="right">0원</td>
                <td class="right">496,660원</td>
                <td class="right">17,383,340원</td>
              </tr>
              <tr>
                <td>8</td>
                <td class="right">496,660원</td>
                <td class="right">0원</td>
                <td class="right">496,660원</td>
                <td class="right">17,383,340원</td>
              </tr>
              <tr>
                <td>9</td>
                <td class="right">496,660원</td>
                <td class="right">0원</td>
                <td class="right">496,660원</td>
                <td class="right">17,383,340원</td>
              </tr>
              <tr>
                <td>10</td>
                <td class="right">496,660원</td>
                <td class="right">0원</td>
                <td class="right">496,660원</td>
                <td class="right">17,383,340원</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </template>
  </v-popup>
</template>
<script>
import { VPopup } from '~/components/element'
export default {
  components: {
    VPopup
  },
  props: {
    popVisible: {
      type: Object,
      defualt: {},
      required: true
    }
  },

  // 2021.03.17 (ver1.1)
  updated() {
    this.setCaption()
  }
}
</script>
