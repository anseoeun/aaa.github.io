<template>
  <!-- 2021.03.24 (ver1.1) -->
  <v-popup
    :visible="visible"
    :width="'776px'"
    :footer="['confirm']"
    @close="
      $emit('close')
      popVisible = false
    "
    @confirm="
      $emit('close')
      popVisible = false
    "
  >
    <template slot="header">
      <div class="title">등록대행 서비스</div>
      <p class="header-description">썬팅과 자동차 등록(번호판 발급)을 동시에 받는 원스탑 서비스입니다.</p>
    </template>
    <template slot="body">
      <ul class="body-contents">
        <li>
          <p class="contents-head">서비스 안내</p>
          <ul class="body-description-list">
            <li>등록대행 서비스를 받기 위해서는 썬팅 지정 장착점으로 차량을 탁송받으셔야 합니다.</li>
            <li>
              썬팅 지정 장착점은 당사 주 사업장(양재 본사, 남양 연구소, 울산/아산/전주공장)인근에 위치하고 있으며,
              선택하실 수 있습니다.
            </li>
            <li>
              서비스를 신청하시면 오토클릭 콜센터(02-711-2768)에서 안내 전화를 드리며, 상담원 안내에 따라 등록 비용을
              납부하시면 됩니다.
            </li>
          </ul>
        </li>
      </ul>
      <div class="notice">
        <ul class="bullet-list">
          <li>비과세 대상자의 경우 해당 서비스 이용이 불가합니다. (장애인, 다자녀 취득세 감면 희망자는 이용 불가)</li>
          <li>해당 서비스로는 공채 매입, 취득세 카드 납부 및 분할 납부가 불가합니다.</li>
        </ul>
      </div>
    </template>
  </v-popup>
</template>

<script>
import { VPopup } from '~/components/element'
export default {
  components: {
    VPopup
  },
  props: {
    visible: {
      type: Boolean,
      default: false
    }
  }
}
</script>
