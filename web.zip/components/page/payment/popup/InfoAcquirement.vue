<template>
  <v-popup
    :visible="popVisible.infoAcquirement"
    :footer="['confirm']"
    :width="'1000px'"
    @confirm="popVisible.infoAcquirement = false"
    @close="popVisible.infoAcquirement = false"
  >
    <template slot="header">
      <div class="title">취득세 안내</div>
    </template>
    <template slot="body">
      <p class="contents-head">* 취득세는 자동차 등록시 부과되는 지방세로 차량 공급가격의 4~7% 입니다.</p>
      <div class="table-area">
        <table>
          <colgroup>
            <col width="113px" />
            <col width="113px" />
            <col width="auto" />
            <col width="113px" />
            <col width="113px" />
            <col width="113px" />
          </colgroup>
          <thead>
            <tr>
              <th rowspan="2">세목</th>
              <th rowspan="2">과세기준액</th>
              <th rowspan="2">경차 세율</th>
              <th colspan="2">비영업용 세율</th>
              <th rowspan="2">영업용 세율</th>
            </tr>
            <tr>
              <th>승용</th>
              <th>승합/화물</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>취득세</td>
              <td>판매가 - 부가세</td>
              <td class="left">
                <ul class="bullet-list">
                  <li>50만원 한도 내 면제 (2021년 말까지)</li>
                  <li>4% (2022년 이후)</li>
                </ul>
              </td>
              <td>7%</td>
              <td>5%</td>
              <td>4%</td>
            </tr>
          </tbody>
        </table>
      </div>

      <p class="contents-head">* 친환경차 취득세 감면(취득세 산출금액에서 감면)</p>
      <div class="table-area">
        <table class="noline">
          <colgroup>
            <col width="338px" />
            <col width="auto" />
            <col width="338px" />
          </colgroup>
          <thead>
            <tr>
              <th>차종</th>
              <th>감면한도</th>
              <th>기타</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>하이브리드</td>
              <td>20년 90만원 / 21년 40만원</td>
              <td></td>
            </tr>
            <tr>
              <td>전기차</td>
              <td>140만원</td>
              <td>2021년 까지</td>
            </tr>
            <tr>
              <td>수소차</td>
              <td>140만원</td>
              <td>2021년 까지</td>
            </tr>
          </tbody>
        </table>
      </div>

      <p class="contents-head">* 취득세 장애인 면제</p>
      <div class="table-area">
        <table class="noline">
          <colgroup>
            <col width="auto" />
            <col width="225px" />
          </colgroup>
          <thead>
            <tr>
              <th>대상</th>
              <th>차종</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td class="left top">
                <ul class="bullet-list">
                  <li>장애인으로서 장애등급 제1등급부터 제3급(시각장애인등급 4급 포함)까지에 해당하는 사람</li>
                  <li>국가유공자로서 상이등급 1급부터 7급까지의 판정을 받은 사람</li>
                  <li>5.18 민주화운동부상자로서 신체장애등급 1급부터 14급까지의 판정을 받은 사람</li>
                  <li>고엽제 후유의증환자로서 경도(輕度) 장애 이산의 장애등급 판정을 받은 사람</li>
                </ul>
              </td>
              <td class="left">
                <ul class="bullet-list">
                  <li>2000cc이하 승용차</li>
                  <li>7인승 이상 승용차</li>
                  <li>15인승 이하 승용차</li>
                </ul>
              </td>
            </tr>
          </tbody>
        </table>
      </div>

      <p class="contents-head">* 취득세 다가구자녀 면제</p>
      <div class="table-area">
        <table class="noline">
          <colgroup>
            <col width="225px" />
            <col width="auto" />
            <col width="225px" />
          </colgroup>
          <thead>
            <tr>
              <th>대상</th>
              <th>차종/혜택</th>
              <th>시한</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td class="left top">다자녀가구<br />(가족등록부 기준 18세 미만의 자녀 3명 이상)</td>
              <td class="left">
                <ul class="bullet-list">
                  <li>6인승 이하 승용차: 140만원까지 면제</li>
                  <li>7인승 이상 승용차: 취득세 200만원 초과 시 취득세 금액의 15% 과세</li>
                  <li>15인승 이하 승용차: 취득세 200만원 초과 시 취득세 금액의 15% 과세</li>
                </ul>
              </td>
              <td class="left top">
                <ul class="bullet-list">
                  <li>2021년 12월 31일까지</li>
                </ul>
              </td>
            </tr>
          </tbody>
        </table>
      </div>


    </template>
  </v-popup>
</template>

<script>
import { VPopup } from '~/components/element'
export default {
  components: {
    VPopup
  },
  props: {
    popVisible: {
      type: Object,
      defualt: {},
      required: true
    },
  },

  // 2021.03.17 (ver1.1)
  updated() {
    this.setCaption()
  },
}
</script>
