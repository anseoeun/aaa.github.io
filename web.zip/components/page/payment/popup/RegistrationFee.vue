<template>
  <div>
    <!-- 2021.03.24 (ver1.1) -->
    <v-popup
      :visible="popVisible.feePop"
      :width="'1000px'"
      :footer="['confirm']"
      @confirm="popVisible.feePop = false"
      @close="popVisible.feePop = false"
    >
      <template slot="header">
        <div class="title">등록 비용 확인하기</div>
      </template>
      <template slot="body">
        <p class="text-main t-gray t-left">차량 등록시의 비용을 미리 확인해 보세요.</p>
        <div class="body-contents bktop">
          <div class="info-grid-list">
            <ul>
              <li>
                <div class="info-title"><strong>구분</strong></div>
                <div class="info-group">
                  <v-select v-model="optionSelectValue" :data="optionSelect"> </v-select>
                  <v-checkbox :one-check="true" :checked.sync="checkInfo" class="ct"
                    >다자녀(18세 미만 3인 이상)</v-checkbox
                  >
                </div>
              </li>
              <li>
                <div class="info-title">
                  <strong>취득세</strong>
                  <v-btn class="btn-info" type="icon" icon-class="icon-info" @click="popVisible.infoAcquirement = true"
                    ><span class="offscreen">취득세안내팝업보기</span></v-btn
                  >
                </div>
                <div class="info-group">
                  <span class="price">100,000 원</span>
                </div>
              </li>
              <li>
                <div class="info-title ct">
                  <strong>공채</strong>
                  <v-btn class="btn-info" type="icon" icon-class="icon-info" @click="popVisible.infoFund = true"
                    ><span class="offscreen">공채안내팝업보기</span></v-btn
                  >
                </div>
                <div class="info-group">
                  <v-select v-model="locationSelectValue" :data="locationSelect" placeholder="시/도"> </v-select>
                  <v-select v-model="locationSelectValue" :data="locationSelect" placeholder="시/군/구"> </v-select>
                  <v-radio v-model="costRadio" :data="costRadioList" />
                  <span class="price ct">0 원</span>
                </div>
              </li>
              <li>
                <strong class="info-title">증지대(수입인지)</strong>
                <div class="info-group">
                  <span class="price">100,000 원</span>
                </div>
              </li>
              <li>
                <strong class="info-title">차량번호판</strong>
                <div class="info-group">
                  <span class="price">100,000 원</span>
                </div>
              </li>
              <li>
                <strong class="info-title">등록 대행 수수료</strong>
                <div class="info-group">
                  <span class="price">100,000 원</span>
                </div>
              </li>
              <li class="total">
                <strong class="info-title">총 차량 등록 비용</strong>
                <div class="info-group">
                  <span class="price">100,000 원</span>
                </div>
              </li>
            </ul>
          </div>
        </div>
        <div class="notice">
          <ul class="bullet-list">
            <li>등록비는 결제금액에 포함되지 않습니다.</li>
            <li>공채 할인금액은 지자체별 할인율이 매일 변동됨에 따라 실제와 다소 차이가 있을 수 있습니다.</li>
          </ul>
        </div>
      </template>
    </v-popup>
  </div>
</template>

<script>
import { VPopup } from '~/components/element'
export default {
  components: {
    VPopup
  },
  props: {
    popVisible: {
      type: Object,
      defualt: {},
      required: true
    },
    data: {
      type: Object,
      default: () => {}
    }
  },
  data() {
    return {
      checkInfo: false,
      costSelcet: '',
      costRadio: '',
      costRadioList: [
        { value: '01', label: '할인' },
        { value: '02', label: '매입' }
      ],
      locationSelect: [
        {
          name: '1',
          value: '서울시'
        },
        {
          name: '2',
          value: '경기도'
        },
        {
          name: '3',
          value: '인천광역시'
        }
      ],
      locationSelectValue: '',
      optionSelect: [
        { value: '', label: '일반' },
        { value: '2', label: '일반장애 1급~3급 (시각장애 3급 포함)' },
        { value: '3', label: '일반장애 4급' },
        { value: '4', label: '일반장애 4급~6급 (시각장애 5~6급)' },
        { value: '5', label: '국가유공상이자 1급~7급' },
        { value: '6', label: '고엽제등급판정자 고도~경도' },
        { value: '7', label: '5.18 광주민주화운동 부상자 1~14급' }
      ],
      optionSelectValue: ''
    }
  }
}
</script>