<template>
  <v-popup :visible="popVisible.paymentWait" :width="'776px'" @close="popVisible.paymentWait = false">
    <template slot="body">
      <div class="payment-wait">
        <div class="progress-loading" style="position: relative">
          <svg
            class="paying-outline"
            width="210"
            height="210"
            viewBox="0 0 210 210"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            <circle
              class="bg-circle"
              cx="105"
              cy="105"
              r="100"
              stroke="#efefef"
              stroke-dasharray="6, 36"
              stroke-linecap="round"
              stroke-width="8"
            />
            <circle
              class="paying-circle"
              cx="105"
              cy="105"
              r="100"
              stroke="#00a8cf"
              stroke-linecap="round"
              stroke-width="8"
            />
          </svg>
          <p class="paying-status">{{ loadPercent }}%</p>
        </div>

        <!-- 2021.03.24 (ver1.1) -->
        <p class="text">결제 요청 중입니다.</p>
        <p class="sub-text">잠시만 기다려 주세요.<br />결제 도중 화면을 닫으시면 결제 요청이 취소될 수 있습니다.</p>
      </div>
    </template>
  </v-popup>
</template>

<script>
import { VPopup } from '~/components/element'
export default {
  components: {
    VPopup
  },
  props: {
    popVisible: {
      type: Object,
      defualt: {},
      required: true
    }
  },
  data() {
    return {
      visible: true,
      loadPercent: 0
    }
  },
  mounted() {
    this.dataSample()
  },
  updated() {
    if (this.popVisible.paymentWait) {
      this.paying()
    } else {
      this.loadPercent = 0
    }
  },
  methods: {
    paying() {
      let payingLine = this.$el.querySelector('.paying-circle')
      let rec = Number(payingLine.getAttribute('r'))
      let payingLineLength = this.isMs() ? 2 * Math.PI * rec : payingLine.getTotalLength()
      payingLine.style.strokeDasharray = payingLineLength
      payingLine.style.strokeDashoffset = payingLineLength * (1 + this.loadPercent / 100)
    },
    dataSample() {
      setInterval(() => {
        if (this.loadPercent < 100) {
          return (this.loadPercent = this.loadPercent + 1)
        } else {
          clearInterval(this)
        }
      }, 500)
    }
  }
}
</script>
