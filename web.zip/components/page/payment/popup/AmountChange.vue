<template>
  <v-popup
    :visible="popVisible.amountChange"
    :footer="['confirm']"
    :width="'550px'"
    @confirm="popVisible.amountChange = false"
    @close="popVisible.amountChange = false"
  >
    <template slot="header">
      <div class="title">판매조건 변경 안내</div>
      <!-- 2021.03.31 (ver1.2) 텍스트 수정 -->
      <p class="header-description">
        계약 진행 시 선택하신 할인 정보가 변경되었습니다.<br />결제하시기 전 아래 변경 사항을 확인해 주세요.
      </p>
    </template>
    <template slot="body">
      <div class="body-contents">
        <!-- 2021.04.15 (ver1.3) 텍스트 수정 -->
        <p class="contents-head">변동 사항</p>

        <!-- 2021.03.24 (ver1.1) -->
        <ul class="plan-info">
          <li>
            <p class="title">타겟(할인)조건명1</p>
            <p class="description t-blue">혜택 종료</p>
          </li>
          <li>
            <p class="title">타겟(할인)조건명2</p>
            <p class="description t-blue">혜택 종료</p>
          </li>
          <li>
            <p class="title">타겟(할인)조건명3</p>
            <p class="description t-blue">금액 변동</p>
          </li>
        </ul>
      </div>
    </template>
  </v-popup>
</template>

<script>
import { VPopup } from '~/components/element'
export default {
  components: {
    VPopup
  },
  props: {
    popVisible: {
      type: Object,
      defualt: {},
      required: true
    }
  }
}
</script>
