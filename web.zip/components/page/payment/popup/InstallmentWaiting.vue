<template>
  <v-popup :visible="popVisible.installmentWaiting" :width="'550px'" @close="popVisible.installmentWaiting = false">
    <template slot="header">
      <div class="title">내 할부한도 조회</div>
      <p class="header-description">
        모바일에서 할부한도 조회를 완료하시고<br />하단 [한도조회완료] 버튼을 클릭해 주세요.
      </p>
    </template>
    <template slot="body">
      <div class="install-waiting"></div>
    </template>
    <template slot="footer">
      <v-btn class="btn" b-size="btn-md">한도 조회 완료</v-btn>
    </template>
  </v-popup>
</template>

<script>
import { VPopup } from '~/components/element'
export default {
  components: {
    VPopup
  },
  props: {
    popVisible: {
      type: Object,
      defualt: {},
      required: true
    }
  }
}
</script>
