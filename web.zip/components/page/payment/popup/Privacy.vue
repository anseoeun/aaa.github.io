<template>
  <v-popup
    :visible="popVisible.privacy"
    :width="'550px'"
    :footer="['cancel','agree']"
    @close="popVisible.privacy = false"
  >
    <template slot="header">
      <div class="title">개인정보 제3자 제공 동의</div>
    </template>
    <template slot="body">
      <div class="table-area nohead">
        <table class="noline">
          <colgroup>
            <col width="118px" />
            <col width="auto" />
          </colgroup>
          <tbody>
            <tr>
              <th class="bold">제공 받는 자</th>
              <td class="left">현대카드</td>
            </tr>
            <tr>
              <th class="bold">제공 목적</th>
              <td class="left">카드 금융서비스, 세이브오토 제공</td>
            </tr>
            <tr>
              <th class="bold">제공 항목</th>
              <td class="left">성명, 생년월일 성별, 주소, 휴대폰번호, 이메일, 구입차량정보, 신용평가기관의 본인인증값(CI), 카드번호</td>
            </tr>
            <tr>
              <th class="bold">보유 및 이용기간</th>
              <td class="left">이용 목적 달성 후 폐기</td>
            </tr>
          </tbody>
        </table>
      </div>
      <div class="notice">
        <p>
          <span>동의에 거부할 권리가 있으나, 거부 시 서비스를 제공받을 수 없습니다.</span>
        </p>
      </div>
    </template>
  </v-popup>
</template>

<script>
import { VPopup } from '~/components/element'
export default {
  components: {
    VPopup
  },
  props: {
    popVisible: {
      type: Object,
      defualt: {},
      required: true
    },
  },

  // 2021.03.17 (ver1.1)
  updated() {
    this.setCaption()
  },
}
</script>