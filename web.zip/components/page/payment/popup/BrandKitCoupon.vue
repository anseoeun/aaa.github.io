<template>
  <!-- 2021.03.17 (ver1.0) -->
  <v-popup
    :visible="popVisible.brandKitCoupon"
    :width="'550px'"
    :footer="['confirm']"
    @confirm="popVisible.brandKitCoupon = false"
    @close="popVisible.brandKitCoupon = false"
  >
    <template slot="header">
      <div class="title">브랜드 KIT</div>

      <!-- 2021.03.24 (ver1.1) -->
      <p class="header-description">현대자동차 서비스 KIT 상품을 제공해 드립니다.<br />(출고 시 차량 내 비치)</p>
    </template>
    <template slot="body">
      <div class="contents-image">
        <v-img :src="require('~/assets/images/payment/brand-kit.png')" alt="브랜드KIT상품이미지"></v-img>
      </div>
      <div class="image-info">
        <div class="text-main t-left">* 구성품</div>
        <p>먼지털이개, 담요, LED 라이트바 키트, 목베개, 전면 유리커버, 트렁크 정리함</p>
      </div>
    </template>
  </v-popup>
</template>

<script>
import { VPopup, VImg } from '~/components/element'
export default {
  components: {
    VPopup,
    VImg
  },
  props: {
    // 2021.03.17 (ver1.0)
    popVisible: {
      type: Object,
      defualt: {},
      required: true
    }
  }
}
</script>
