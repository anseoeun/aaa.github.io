<template>
  <v-popup
    :visible="popVisible.installmentSearch"
    :width="'550px'"
    :footer="['confirm']"
    @confirm="popVisible.installmentSearch = false"
    @close="popVisible.installmentSearch = false"
  >
    <template slot="header">
      <div class="title">내 할부한도 조회하기</div>
    </template>
    <template slot="body">
      현대캐피탈 한도조회
    </template>
  </v-popup>
</template>

<script>
import { VPopup } from '~/components/element'
export default {
  components: {
    VPopup
  },
  props: {
    popVisible: {
      type: Object,
      defualt: {},
      required: true
    },
  },
}
</script>
