<template>
  <v-popup
    :visible="popVisible.installmentInfo"
    :width="'776px'"
    :is-close="false"
    @close="popVisible.installmentInfo = false"
  >
    <template slot="body">
      <div class="request-approve">
        <div>현대캐피탈에 고객님의 정보를 전달하여 할부승인 요청 중에 있습니다.</div>
        <p>할부 승인완료 시까지 몇 분의 시간이 소요될 수 있습니다. 창을 닫지 말고 잠시만 기다려 주세요.</p>
      </div>
    </template>
  </v-popup>
</template>

<script>
import { VPopup } from '~/components/element'
export default {
  components: {
    VPopup
  },
  props: {
    popVisible: {
      type: Object,
      defualt: {},
      required: true
    }
  }
}
</script>
