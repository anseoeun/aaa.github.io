<template>
  <v-popup
    :visible="popVisible.installmentAgree"
    :width="'1000px'"
    @close="popVisible.installmentAgree = false"
  >
    <template slot="header">
      <div class="title">할부금융 신청을 위한 개인정보 제3자 정보제공 동의</div>
    </template>
    <template slot="body">
      <div class="table-area">
        <table>
          <colgroup>
            <col width="210px" />
            <col width="115px" />
            <col width="auto" />
            <col width="180px" />
          </colgroup>
          <thead>
            <tr>
              <th>제공대상</th>
              <th>이용목적</th>
              <th>제공하는 개인정보항목</th>
              <th>보유 및 이용기간</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>현대자동차(주) → 현대캐피탈(주)</td>
              <td rowspan="2">자동차 할부 금융서비스 제공</td>
              <td>성명, (행정상)생년월일, 성별, 상호, 사업자번호, 주소, 연락처, 휴대폰번호, 이메일, 구입차량정보, 신용평가기관의 본인인증 값(CI)</td>
              <td rowspan="2">할부 한도결과 조회 및 할부상품 신청 후 즉시 폐기</td>
            </tr>
            <tr>
              <td>현대캐피탈(주) → 현대자동차(주)</td>
              <td>신용평가기관의 본인인증값(CI), 할부가능 금액, 할부가능 조건, 이용가능 상품, 한도조회 일시</td>
            </tr>
          </tbody>
        </table>
      </div>
      <div class="notice">
        <p>개인정보 제공 동의를 거부할 권리가 있으나 동의하지 않을 경우 현대캐피탈 AUTO DIGITAL을 통한 할부한도 조회 및 할부상품 신청이 불가합니다.</p>
      </div>
    </template>
    <template slot="footer">
      <v-btn class="btn btn-gray" b-size="btn-md" b-color="btn-gray">거부</v-btn>
      <v-btn class="btn" b-size="btn-md" @click="[ popVisible.installmentAgree = false, popVisible.installmentWaiting = true ]">동의</v-btn>
      <v-btn class="btn" b-size="btn-md" @click="[ popVisible.installmentAgree = false, popVisible.installmentSearch = true ]">동의</v-btn>
    </template>
  </v-popup>
</template>

<script>
import { VPopup } from '~/components/element'
export default {
  components: {
    VPopup
  },
  props: {
    popVisible: {
      type: Object,
      defualt: {},
      required: true
    },
  },
  updated() {
    this.setCaption()
    this.setLabel((idg) => {
      // console.dir(idg) // 자동 생성된 ID 배열
    })
  }
}
</script>
