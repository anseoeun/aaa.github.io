<template>
  <v-popup
    :visible="popVisible.saveAutoGuide"
    :footer="['confirm']"
    :width="'550px'"
    @confirm="popVisible.saveAutoGuide = false"
    @close="popVisible.saveAutoGuide = false"
  >
    <template slot="header">
      <div class="title">현대카드 세이브-오토</div>
    </template>
    <template slot="body">
      <div class="body-contents">
        <ul class="bullet-list">
          <li>
            현대자동차 신차 구입 시 현대카드 M을 이용하여 선수금을 10만원 이상 결제하시는 경우 차량 구매 대금 중 일부를
            해당 포인트(20만/30만/50만)만큼 선 할인해 드립니다.
          </li>
          <li>
            선 할인 받으신 금액은 이후 36개월 동안 고객님의 현대카드M 사용실적에 따라 적립되는 포인트로 상환하게 되며,
            미상환 시 익월 카드대금 청구에서 전액 청구 됩니다.
          </li>

          <!-- 2021.04.15 (ver1.1) 텍스트수정 -->
          <li>
            세이브-오토 프로그램은 적용을 원하시는 고객께서 신청하는 경우에만 적용되고, 이용기간 중 미상환 포인트에 대한
            대금 청구 시 이자는 부과되지 않습니다.
          </li>
          <li>
            세이브-오토를 통해 할인받은 금액은 세금계산서에서 제외되지 않고 60%는 현대자동차가, 40%는 현대카드사에서
            지원하고 있습니다. 따라서 현대카드사 부담분(40%)은 현대자동차 차량판매에 대한 세금계산서상 할인매출로
            인식되지 않습니다.
          </li>
          <li>
            보다 자세한 내용은 현대카드 홈페이지에서 확인하실 수 있습니다.<br />(<a
              class="t-blue"
              href="https://www.hyundaicard.com/"
              target="_blank"
              title="새창 열기"
              >https://www.hyundaicard.com/</a
            >)
          </li>
        </ul>
      </div>
    </template>
  </v-popup>
</template>

<script>
import { VPopup } from '~/components/element'
export default {
  components: {
    VPopup
  },
  props: {
    popVisible: {
      type: Object,
      defualt: {},
      required: true
    }
  }
}
</script>
