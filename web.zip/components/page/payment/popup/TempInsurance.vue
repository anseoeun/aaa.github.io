<template>
  <!-- 2021.04.15 (ver1.1) width수정 -->
  <v-popup
    :visible="popVisible.tempInsurance"
    :footer="['confirm']"
    :width="'776px'"
    @confirm="popVisible.tempInsurance = false"
    @close="popVisible.tempInsurance = false"
  >
    <template slot="header">
      <!-- 2021.04.15 (ver1.1) 텍스트수정 -->
      <div class="title">임시운행 의무보험</div>
    </template>
    <template slot="body">
      <ul class="body-contents">
        <li>의무보험은 차량이 출고센터를 통해 출고되어 임시운행기간동안에만 유효한 보험입니다.</li>
        <li>
          이는 임시운행 기간중 발생되는 교통사고 피해자의 피해배상 보장을 위한 자동차 손해배상 보장법 개정으로
          임시운행허가 차량의 의무보험 가입이 법제화 되었습니다.
        </li>
        <li>
          보상책인기간은 출고일부터 임시운행허가 기간인 10일(기간 만료일 24시까지)동안이고 보험료는 차종별 정액보험료가
          적용됩니다.<br />(대부분의 경우 1만원 이내)
        </li>
        <li>
          따라서 차량을 구입하신 고객께서는 임시운행허가기간 종료 이전에 1년만기 책임보험, 혹은 종합보험에 반드시
          가입하셔야 합니다.
        </li>
        <li>
          의무보험은 1회 소멸성 보험으로 임시운행증을 반납하거나 다른 책임보험에 가입하시는 경우 자동으로 해지가 됩니다.
        </li>
      </ul>
    </template>
  </v-popup>
</template>

<script>
import { VPopup } from '~/components/element'
export default {
  components: {
    VPopup
  },
  props: {
    popVisible: {
      type: Object,
      defualt: {},
      required: true
    }
  }
}
</script>