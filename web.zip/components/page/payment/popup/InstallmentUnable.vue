<template>
  <v-popup
    :visible="popVisible.installmentUnable"
    :width="'550px'"
    :footer="['close']"
    @close="popVisible.installmentUnable = false"
  >
    <template slot="header">
      <div class="title">한도 조회 불가</div>
      <p class="header-description">
        고객님은 온라인 할부한도 조회가 불가능합니다.<br />현대캐피탈 금융상품 담당 콜센터로 문의해 주세요.
      </p>
    </template>
    <template slot="body">
      <div class="unable-check">
        <div class="text-main">1588-5330</div>
        <p class="text-main t-gray">(평일 09:00 - 18:00)</p>
      </div>
    </template>
  </v-popup>
</template>

<script>
import { VPopup } from '~/components/element'
export default {
  components: {
    VPopup
  },
  props: {
    popVisible: {
      type: Object,
      defualt: {},
      required: true
    }
  }
}
</script>
