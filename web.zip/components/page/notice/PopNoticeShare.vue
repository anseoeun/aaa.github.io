<template>
  <v-popup
    :visible="visible"
    :width="'550px'"
    @close="
      $emit('close')
      popVisible = false
    "
  >

    <template slot="header">
      <div class="title">공유하기</div>
    </template>
    <template slot="body">
      <div class="form-grid">
        <div class="label-input">
          <label class="offscreen">URL 입력폼</label>
          <v-input v-model="urlForm" class="form-group" />
        </div>
      </div>
    </template>
    <template slot="footer">
      <div class="btn-group">
        <v-btn class="btn" b-size="btn-md">URL 복사</v-btn>
        <v-btn class="btn btn-lg" b-size="btn-lg">카카오톡 공유</v-btn>
        <v-btn class="btn btn-lg" b-size="btn-lg">페이스북 공유</v-btn>
      </div>
    </template>
  </v-popup>
</template>

<script>
import { VPopup } from '~/components/element'
export default {
  components: {
    VPopup
  },
  props: {
    visible: {
      type: Boolean,
      default: false
    },
  },
  data() {
    return {
      urlForm: 'https://www.hyundai.com/KSDLFKWEGVL',
    }
  },
  updated() {
    if (this.visible) {
      this.setLabel((idg) => {
      })
    }
  }
}
</script>