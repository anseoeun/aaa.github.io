<template>
  <v-popup
    :visible="visible"
    :width="'1000px'"
    @close="
      $emit('close')
      popVisible = false
    "
  >
    <template slot="header">
      <div class="title">구매후기 상세</div>
    </template>
    <template slot="body">
      <div class="pop-review-detail">
        <div class="review-detail-wrap">
          <div class="detail-img">
            <v-img :src="reviewPhoto.src" :alt="reviewPhoto.alt"></v-img>
          </div>
          <div class="detail-info">
            <div class="title">{{ detailinfo.title }}</div>
            <div class="date">{{ detailinfo.contractDate }} {{ detailinfo.user }}</div>
            <div class="grade-wrap">
              <span>만족도</span>
              <v-rate v-model="grade" class="grade-check sm-size view"></v-rate>
            </div>
            <ul class="satisfaction-list">
              <li v-for="(item, index) in satisfaction" :key="index">
                <span class="flag">{{ item.cate }}</span>
                <span class="value">{{ item.text }}</span>
              </li>
            </ul>
            <div class="etc-menus">
              <v-btn class="good"> 도움이 되었어요 <span class="up"> 7 </span></v-btn>
              <v-btn class="btn-more">동일사양 견적내기</v-btn>
            </div>
          </div>
        </div>
        <!-- 사진 -->
        <div class="upload-view-list-wrap">
          <v-carousel-new
            :data="fileList"
            :navigation="true"
            :items-to-show="5"
            :items-to-slide="1"
            class="upload-view-list sm-size"
          >
            <template slot-scope="props">
              <div class="item">
                <v-btn class="img" @click="changePhoto(props.item.src)">
                  <v-img :src="props.item.src" :alt="props.item.alt"></v-img>
                </v-btn>
              </div>
            </template>
          </v-carousel-new>
        </div>
        <div class="review-text">{{ reviewText }}</div>
      </div>
    </template>
  </v-popup>
</template>

<script>
import { VImg, VRate, VCarouselNew } from '~/components/element'
export default {
  components: {
    VImg,
    VRate,
    VCarouselNew
  },
  props: {
    visible: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      reviewPhoto: {
        src: require('~/assets/images/temp/temp-car-option2.png'),
        alt: '구매후기사진'
      },
      detailinfo: {
        title: '캐스퍼 센슈어스 (가솔린1.6T) Primium ( 자가용 스마트 스트림 가솔린 1.6 터보)',
        contractDate: '2021.10.20',
        user: '(30, 남성)'
      },
      grade: 3,
      satisfaction: [
        {
          cate: '구매과정',
          text: '생각보다 쉬워요.'
        },
        {
          cate: '가성비',
          text: '가격대비 최고예요.'
        },
        {
          cate: '디자인',
          text: '화면처럼 맘에들어요.'
        },
        {
          cate: '승차감',
          text: '무척 좋아요.'
        }
      ],
      fileList: [
        {
          src: require('~/assets/images/temp/temp-car-option2.png'),
          alt: '구매후기사진'
        },
        {
          src: require('~/assets/images/temp/temp-car-option.png'),
          alt: '구매후기사진'
        },
        {
          src: require('~/assets/images/temp/temp-car-option2.png'),
          alt: '구매후기사진'
        },
        {
          src: require('~/assets/images/temp/temp-car-option.png'),
          alt: '구매후기사진'
        },
        {
          src: require('~/assets/images/temp/temp-car-option2.png'),
          alt: '구매후기사진'
        },
        {
          src: require('~/assets/images/temp/temp-car-option.png'),
          alt: '구매후기사진'
        }
      ],
      reviewText:
        '빠르고 친절한 응대 너무 감사드립니다!!ㅎㅎ 첫차라 걱정도 많았지만 친절하고 정확하게 안내해주시고 차도 안전하게 잘 인도해 주셨습니다~ 요즘같은 때에 차 타고 다니다 마스크 없으면 난감한 상황이 많이 발생하는데 그런 걱정할 일 없이 마스크도 많이 넣어주시고 너무 센스쟁이세요~!! 첫차인 만큼 관리하는 방법이나 팁도 많이 알려주셔서 앞으로는 걱정 없이 예쁘고 안전하게 운전할 일만 남은 것 같습니다ㅎㅎ 다시 한 번 더 감사드립니다! 올 한해도 대박나세요~!! (>_<)/'
    }
  },
  methods: {
    changePhoto(src) {
      this.reviewPhoto.src = src
    }
  }
}
</script>
