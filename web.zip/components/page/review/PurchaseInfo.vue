<template>
  <v-popup
    :visible="visible"
    :width="'776px'"
    @close="
      $emit('close')
      popVisible = false
    "
  >
    <template slot="header">
      <div class="title">구매 상세 정보</div>
    </template>
    <template slot="body">
      <div class="review-purchase-info">
        <v-tab class="tab-default" :data="tabList" :contents="true">
          <template slot="contents">
            <!-- Tab1: 차량정보 -->
            <div data-id="tab1">
              <ul class="date">
                <li>계약일 : <span>2021.09.01</span></li>
                <li>출고일 : <span>2021.09.01</span></li>
              </ul>
              <div class="total">
                <div class="tit">차량가격</div>
                <div class="price strong"><span>20,000,000</span> 원</div>
              </div>
              <ul class="info-box">
                <li>
                  <div class="info-top">
                    <span class="tit">모델</span>
                    <span>캐스퍼 1.6 가솔린 터보 FLUX 스마트 스트림</span>
                    <em class="price">19,100,000 원</em>
                  </div>
                </li>
                <li>
                  <div class="info-top">
                    <span class="tit">색상</span>
                    <em class="price">300,000 원</em>
                  </div>
                  <ul class="info-list">
                    <li>
                      <ul>
                        <li>
                          <div class="detail-tit">외장</div>
                          <div class="option-sample" style="background: #f2f2f2"></div>
                          <span>색상명</span>
                          <em class="price">0 원</em>
                        </li>
                        <li>
                          <div class="detail-tit">내장</div>
                          <div class="option-sample" style="background: #f2f2f2"></div>
                          <span>색상명</span>
                          <em class="price">100,000 원</em>
                        </li>
                      </ul>
                    </li>
                  </ul>
                </li>
                <li>
                  <div class="info-top">
                    <span class="tit">선택품목</span>
                    <em class="price">6,000,000 원</em>
                  </div>
                  <ul class="info-list">
                    <li>
                      <div class="option-tit">옵션</div>
                      <ul>
                        <li>
                          <div class="option-sample" style="background: #f2f2f2"></div>
                          <span>옵션명 전체 출력</span>
                          <em class="price">2,000,000 원</em>
                        </li>
                        <li>
                          <div class="option-sample" style="background: #f2f2f2"></div>
                          <span>옵션명 전체 출력</span>
                          <em class="price">2,000,000 원</em>
                        </li>
                      </ul>
                    </li>
                    <li>
                      <div class="option-tit">TULX</div>
                      <ul>
                        <li>
                          <div class="option-sample" style="background: #f2f2f2"></div>
                          <span>전체명칭 출력</span>
                          <em class="price">2,000,000 원</em>
                        </li>
                      </ul>
                    </li>
                  </ul>
                </li>
              </ul>
            </div>

            <!-- Tab2: 구매정보 -->
            <div data-id="tab2">
              <ul class="date">
                <li>계약일 : <span>2021.09.01</span></li>
                <li>출고일 : <span>2021.09.01</span></li>
              </ul>
              <div class="total">
                <div class="tit">총 결제금액</div>
                <div class="price"><span>18,945,000</span> 원</div>
              </div>
              <ul class="info-box">
                <li>
                  <div class="info-top">
                    <span class="tit">결제</span>
                    <em class="price strong">26,902,300 원</em>
                  </div>
                  <ul class="info-list">
                    <li>
                      <ul>
                        <li>
                          <span>차량가격</span>
                          <em class="price">26,600,000 원</em>
                        </li>
                        <li>
                          <span>탁송료</span>
                          <em class="price">300,000 원</em>
                        </li>
                        <li>
                          <span>단기의무보험</span>
                          <em class="price">2,300 원</em>
                        </li>
                      </ul>
                    </li>
                  </ul>
                </li>
                <li>
                  <div class="info-top">
                    <span class="tit">할인</span>
                    <em class="price strong">(-) 7,998,000 원</em>
                  </div>
                  <ul class="info-list">
                    <li>
                      <ul>
                        <li>
                          <span>생산월 조건 할인 (생산월 할인)</span>
                          <em class="price">1,599,600 원</em>
                        </li>
                        <li>
                          <span>일시불 3% 할인</span>
                          <em class="price">799,000 원</em>
                        </li>
                        <li>
                          <span>포인트</span>
                          <em class="price">(-) 1,000,000 원</em>
                        </li>
                      </ul>
                    </li>
                  </ul>
                </li>
              </ul>
            </div>
          </template>
        </v-tab>
      </div>
    </template>
    <template slot="footer">
      <v-btn class="btn btn-lg" b-size="btn-lg">동일차량 견적내기</v-btn>
    </template>
  </v-popup>
</template>

<script>
import { VTab } from '~/components/element'
export default {
  components: {
    VTab
  },
  props: {
    visible: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      tabList: [
        { value: 'tab1', label: '차량정보' },
        { value: 'tab2', label: '구매정보' }
      ]
    }
  }
}
</script>
