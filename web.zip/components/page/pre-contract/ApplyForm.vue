<template>
  <div class="apply-form-wrap">
    <form action="">
      <fieldset>
        <model-form />
        <delivery-form />
        <price-form />
        <part-price-form />
      </fieldset>
      <div class="btn-box">
        <!-- 2021.04.08(ver1.2) 사전계약하기 띄어쓰기 제거 -->
        <v-btn type="nlink" class="btn btn lg blue r">사전계약하기</v-btn>
      </div>
    </form>
  </div>
</template>


<script>
import ModelForm from './applyForms/ModelForm'
import DeliveryForm from './applyForms/DeliveryForm'
import PriceForm from './applyForms/PriceForm'
import PartPriceForm from './applyForms/PartPriceForm'

export default {
  components: {
    ModelForm,
    DeliveryForm,
    PriceForm,
    PartPriceForm,
  },
}
</script>
