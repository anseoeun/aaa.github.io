<template>
  <div class="matching-box">
    <div class="box-wrap">
      <div class="box-tit">
        결제 수단
      </div>
      <div class="box-desc">
        <el-form ref="form" :model="form" :rules="rules">
          <v-tab class="tab-default line" :data="tabList" :contents="true" :init="true">
            <template slot="contents">
              <div data-id="tab1">
                <div class="form-grid-list">
                  <ul>
                    <li>
                      <div class="form-label">카드번호</div>
                      <div class="form-group">
                        <el-form-item prop="cardNumber1" class="inbl-wrap">
                          <div class="label-input">
                            <label class="offscreen">첫번째 카드번호</label>
                            <v-input v-model="form.cardNumber1" type="number" maxlength="4" style="width:100px" />
                          </div>
                          <div class="label-input">
                            <label class="offscreen">두 번째 카드번호</label>
                            <v-input v-model="form.cardNumber2" type="number" maxlength="4" style="width:100px" />
                          </div>
                          <div class="label-input">
                            <label class="offscreen">세번째 카드번호</label>
                            <v-input v-model="form.cardNumber3" type="number" maxlength="4" style="width:100px" />
                          </div>
                          <div class="label-input">
                            <label class="offscreen">네번째 카드번호</label>
                            <v-input v-model="form.cardNumber4" type="number" maxlength="4" style="width:100px" />
                          </div>
                          <span class="result">
                            <i class="icon-check"></i>
                            <i class="icon-x"></i>
                          </span>
                        </el-form-item>
                      </div>
                    </li>
                    <li>
                      <div class="form-label">카드유효기간</div>
                      <div class="form-group">
                        <el-form-item prop="datelimitMonth" class="inbl-wrap">
                          <div class="label-input">
                            <label class="offscreen">월 유효기간</label>
                            <v-input v-model="form.datelimitMonth" type="number" maxlength="2" placeholder="MM" style="width:100px" />
                          </div>
                          <div class="label-input">
                            <label class="offscreen">년도 유효기간</label>
                            <v-input v-model="form.datelimitYear" type="number" maxlength="2" placeholder="YY" style="width:100px" />
                          </div>
                          <span class="result">
                            <i class="icon-check"></i>
                            <i class="icon-x"></i>
                          </span>
                        </el-form-item>
                      </div>
                    </li>
                  </ul>
                </div>
              </div>
              <div data-id="tab2">
                <div class="form-grid-list">
                  <ul>
                    <li>
                      <div class="form-label">입금은행</div>
                      <div class="form-group">
                        <v-select v-model="form.bankSelected" :data="bankList" placeholder="은행 선택" style="width:200px" />
                        <span v-if="form.bankSelected !== ''" class="guide-txt">예금주: {{ form.bankSelected }}</span>
                      </div>
                    </li>
                  </ul>
                </div>
              </div>
            </template>
          </v-tab>
        </el-form>
      </div>
    </div>
  </div>
</template>

<script>
import { VSelect, VInput } from '~/components/element/'
export default {
  components: {
    VInput,
    VSelect
  },
  data() {
    return {
      tabList: [
        { value: 'tab1', label: '신용카드' },
        { value: 'tab2', label: '무통장입금' },
      ],
      form: {
        cardNumber1: '',
        cardNumber2: '',
        cardNumber3: '',
        cardNumber4: '',
        datelimit:['', ''],
        depositor:'',
        bankSelected: '',
      },
      bankList: [
        {
          label: '은행 선택',
          value: ''
        },
        {
          label: '국민은행',
          value: '현대자동차(123456-12-1234)'
        },
        {
          label: '우리은행',
          value: '현대자동차(1234-12-12345)'
        }
      ]
    }
  },
  computed: {
    //2021.0408(ver1.2) 마침표추가
    rules() {
      return {
        cardNumber1: [
          {
            required: true,
            message: '* 카드번호를 입력해 주세요.',
            trigger: ['blur', 'change'],
          },
        ],
        datelimitMonth: [
          {
            required: true,
            message: '* 유효기간을 입력해 주세요.',
            trigger:  ['blur', 'change'],
          },
        ],
      }
    },
  },
  mounted() {
    this.setLabel((idg) => {
      // console.dir(idg) // 자동 생성된 ID 배열
    })
  },
}
</script>
