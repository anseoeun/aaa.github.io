<template>
  <div class="matching-box">
    <div class="box-wrap">
      <div class="box-tit">
          주계약자 정보
      </div>
      <div class="box-desc">
        <!-- 폼리스트 -->
        <el-form ref="form" :model="contractorForm" :rules="rules">
          <div class="form-grid-list">
            <ul>
              <li>
                <div class="form-label">성명 </div>
                <div class="form-group">
                  <div class="label-input inbl-wrap">
                    <label class="offscreen">성명</label>
                    <v-input v-model="contractorForm.userName" :disabled="true" />
                  </div>
                </div>
              </li>
              <li>
                <div class="form-label">주민등록 번호</div>
                <div class="form-group">
                  <el-form-item prop="socialNmber2" class="inbl-wrap">
                    <div class="label-input">
                      <label class="offscreen">주민등록 앞자리</label>
                      <v-input v-model="contractorForm.socialNmber1" maxlength="6" :disabled="true" />
                    </div>
                    <div class="dash-line"></div>
                    <div class="label-input">
                      <label class="offscreen">주민등록 뒷자리</label>
                      <v-input v-model="contractorForm.socialNmber2" type="number" maxlength="7" placeholder="7자리" />
                    </div>
                    <span class="result"><i class="icon-check"></i> <i class="icon-x"></i></span>
                  </el-form-item>
                </div>
              </li>
              <li>
                <div class="form-label">휴대전화</div>
                <div class="form-group">
                  <el-form-item prop="phoneNumber" class="inbl-wrap">
                    <div class="label-input">
                      <label class="offscreen">휴대전화</label>
                      <v-input v-model="contractorForm.phoneNumber" type="number" placeholder="-없이 입력하세요." />
                    </div>
                  </el-form-item>
                </div>
              </li>
              <li>
                <div class="form-label">이메일</div>
                <div class="form-group">
                  <el-form-item prop="emailAddress" class="inbl-wrap">
                    <div class="label-input">
                      <label class="offscreen">이메일 주소</label>
                      <v-input v-model="contractorForm.emailAddress" type="text" placeholder="이메일 주소" />
                    </div>
                    <span class="at">@</span>
                    <div class="label-input">
                      <label class="offscreen">이메일 제공자</label>
                      <v-input
                        v-model="contractorForm.emailProvider"
                        type="text"
                        :disabled="contractorForm.mailSelected == '' ? false : true"
                        :value="contractorForm.mailSelected == '직접입력' ? '' : contractorForm.mailSelected"

                      />
                    </div>
                    <div class="select">
                      <v-select v-model="contractorForm.mailSelected" :data="mailList" placeholder="선택" />
                    </div>
                    </el-form-item>
                </div>
              </li>
            </ul>
          </div>
        </el-form>
        <!-- // 폼리스트 -->
        <!-- 약관동의 -->
        <div class="agreement-list">
          <div class="tit">필수적인 개인정보 수집 및 이용에 대한 동의</div>
          <ol class="rule-list">
            <li>
              1. 개인정보의 수집 및 이용목적
              <div class="txt-dash">자동차 매매계약상 의무이행을 위한 재화 · 용역의 제공</div>
              <div class="txt-dash">
                자동차 구매에 따른 탁송 · 등록대행 · 보증수리, 차량 점검·정비 및 유지보수 서비스, 긴급출동서비스 및 제작결함시정서비스 제공을 위한 본인확인, <br />
                  대금 청구서 발송 · 대금결제 · 대금추심을 위한 본인확인, 분쟁해결을 위한 기록보존, 불만처리 등 민원처리, 고지사항 전달, 서비스에 대한 만족도 조사
              </div>
            </li>
            <li>
              2. 수집하는 개인정보의 항목
              <div class="txt-dash">성명, 주민등록번호(외국인 등록번호 또는 여권번호), 상호, 사업자번호, 주소, 전화번호, 휴대폰번호, 이메일, 구입차량정보, <br />  할부매매의 경우 '신용정보의 이용 및 보호에 관한 법률'상 개인신용정보, 국가유공자/장애인의 경우 증명/복지할인 관련 정보
              </div>
            </li>
            <li>
              3. 개인정보의 보유 및 이용기간
              <div class="txt-dash">회사는 고객의 개인정보를 수집한 때로부터 개인정보의 수집 및 이용에 관한 동의 목적을 달성할 때까지 고객의 개인정보를 보유 및 이용하며,  <br />  개인정보 수집 및 이용목적이 달성된 경우에는 해당 정보를 지체 없이 파기합니다.
                <div class="txt-star">*상세한 내용은 현대자동차(주) 홈페이지(<v-btn type="link" class="link" href="http://www.hyundai.com">http://www.hyundai.com</v-btn>) ‘개인정보처리방침’에서 확인할 수 있습니다.</div>
              </div>
            </li>
              <li>
                4. 개인정보(고유식별정보포함) 수집.이용.제공 미동의에 따른 불이익사항
                <div class="txt-dash">자동차 매매계약을 거절할 수 있습니다.</div>
              </li>
          </ol>
          <div class="agreement-check">
            <v-checkbox :one-check="true" :checked.sync="isAgree">
              본인은 귀사가 상기 목적으로 본인의 개인정보를 수집·이용하는 것에 동의합니다.
            </v-checkbox>
            <v-checkbox :one-check="true" :checked.sync="isAgree2">
              본인은 귀사가 상기 목적으로 상기 보유·이용 기간 동안 본인의 고유식별정보(주민등록번호, 운전면허번호, 여권번호, 외국인등록번호)를 수집·이용하는 것에 동의합니다.
            </v-checkbox>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import {VInput, VCheckbox, VSelect } from '~/components/element/'
export default {
  components: {
    VInput,
    VCheckbox,
    VSelect
  },
  data() {
    return {
      contractorForm: {
        userName: '김현대',
        socialNmber1: '910320',
        socialNmber2: '',
        phoneNumber: '',
        emailAddress: '',
        emailProvider: '',
        mailSelected: '',
      },
      mailList: [
        {
          label: '직접 입력',
          value: ''
        },
        {
          label: 'gmail.com',
          value: 'gmail.com'
        },
        {
          label: 'naver.com',
          value: 'naver.com'
        },
        {
          label: 'daum.net',
          value: 'daum.net'
        }
      ],
      isAgree: false,
      isAgree2: false,
    }
  },
  computed: {
    //2021.04.08(ver1.2) 마침표추가
    rules() {
      return {
        socialNmber2: [
          {
            required: true,
            message: '* 주민등록번호 뒷자리를 입력해 주세요.',
            trigger: ['blur', 'change']
          },
        ],
        phoneNumber: [
          {
            required: true,
            message: '* 휴대전화를 입력해 주세요.',
            trigger: ['blur', 'change']
          },
        ],
        emailAddress: [
          {
            required: true,
            message: '* 이메일을 입력해 주세요.',
            trigger: ['blur', 'change']
          },
        ],
      }
    },
  },
  mounted() {
    this.setLabel((idg) => {
      // console.dir(idg) // 자동 생성된 ID 배열
    })
  },
}
</script>
