<template>
  <v-popup :visible="popVisible.precontrctPop" :width="'550px'" @close="popVisible.precontrctPop = false">
    <!-- <h3 slot="header">썬팅 지정 장착점 조회하기</h3> -->
    <template slot="header">
      <div class="title">사전계약 신청확인</div>
    </template>
    <template slot="body">
      <!-- 2021.03.22(ver1.1) 전체적인 내용 수정 -->
      <p class="precontract-check-text">
        이미 신청한 사전계약건이 있습니다. <br />
        계약번호 <span class="contract-num t-blue">202106470997</span>
      </p>
      <p class="precontract-check-text">
        이미 신청한 사전계약건이 있습니다. <br />
        <!-- 2021.04.08(ver1.2) 아래텍스트변경 -->
        추가 계약을 신청하시려면 [계약하러가기] 버튼을 선택해 주세요.
      </p>
      <div class="popup-footer">
        <div class="btn-group">
          <v-btn type="button" class="btn" @click="popVisible.precontrctPop = false">나의 계약 확인 하기</v-btn>
          <!-- 2021.04.08(ver1.2) 계약하러가기로변경 -->
          <v-btn type="nlink" to="/" data-id="confirm" class="btn">계약하러가기</v-btn>
        </div>
      </div>
    </template>
  </v-popup>
</template>

<script>
export default {
  props: {
    popVisible: {
      type: Object,
      defualt: {},
      required: true
    }
  }
}
</script>
