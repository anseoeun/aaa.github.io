<template>
  <div class="delivery-form-wrap">
    <div class="apply-box">
      <div class="title">탁송지역 선택</div>
      <div class="con-box">
        <ul class="delivery-form">
          <li>
            <div class="label-input">
              <label>시/도</label>
              <div class="select-form">
                <v-select v-model="locationSelected1" :data="locationList1" placeholder="선택" />
              </div>
            </div>
          </li>
          <li>
            <div class="label-input">
              <label>시/군/구</label>
              <div class="select-form">
                <v-select v-model="locationSelected2" :data="locationList2" placeholder="선택"
                  :disabled="locationSelected1 == '' ? true : false"
                 />
              </div>
            </div>
          </li>
        </ul>
      </div>
    </div>
  </div>
</template>

<script>
import VSelect from '~/components/element/VSelect'
export default {
  components: {
    VSelect
  },
  data() {
    return {
      locationSelected1: '',
      locationList1: [
        {
          label: '서울',
          value: '00'
        },
        {
          label: '경기도',
          value: '01'
        },
        {
          label: '강원도',
          value: '02'
        }
      ],
      locationSelected2: '',
      locationList2: [
        {
          label: '서울',
          value: '00'
        },
        {
          label: '경기도',
          value: '01'
        },
        {
          label: '강원도',
          value: '02'
        }
      ]
    }
  }
}
</script>
