<template>
  <div class="precontract-payment-wrap">
    <!-- 선택차량 정보 -->
    <div class="matching-box">
        <div class="box-wrap">
          <div class="box-tit">
              선택차량 정보
          </div>
          <div class="box-desc">
              <div class="car-amount">
                <div class="img"><v-img :src="carImg" alt="자동차 이미지"></v-img></div>
                <div class="amount">
                    <p class="txt">
                      선택한 옵션의 금액 범위입니다. (1대당) <br />
                      신차 사전 계약 이후 선택 차량의 옵션과 가격이 변동 될 수 있습니다.
                    </p>
                    <div class="price">
                      {{ priceMin }} ~ {{ priceMax }} <span class="unit">원 내외</span>
                    </div>
                </div>
              </div>
              <div class="info-grid-list">
                <ul>
                  <li>
                    <strong class="info-title">엔진/트림</strong>
                    <div class="info-group">AX00000O0 가솔린 2.5 5인승 2WD / Premium Choice</div>
                  </li>
                  <li>
                    <strong class="info-title">색상</strong>
                    <div class="info-group">
                      <ul class="color-list">
                        <li>
                          <div class="tit">외장색상</div>
                          <div class="color">
                            <div class="color-sample" :style="`background-image:url(${outColor.src})`"></div>
                            <div class="color-txt">{{ outColor.txt }}</div>
                          </div>
                        </li>
                        <li>
                          <div class="tit">내장색상</div>
                          <div class="color">
                            <div class="color-sample" :style="`background-image:url(${inColor.src})`"></div>
                            <div class="color-txt">{{ inColor.txt }}</div>
                          </div>
                        </li>
                      </ul>
                    </div>
                  </li>
                  <li>
                    <strong class="info-title">선택옵션</strong>
                    <div class="info-group">
                        <ul class="opt-list">
                          <li v-for="(item, index) in optList" :key="index">{{ item.opt }}</li>
                        </ul>
                    </div>
                  </li>
                </ul>
              </div>
          </div>
        </div>
    </div>
    <!-- // 선택차량 정보 -->
    <!-- 탁송지역 정보 -->
    <div class="matching-box">
        <div class="box-wrap">
          <div class="box-tit">
              탁송지역 정보
          </div>
          <div class="box-desc"><div class="one-line">서울특별시 강남구</div></div>
        </div>
    </div>
    <!-- //탁송지역 정보 -->
    <!-- 주계약자 정보 -->
    <main-contractor />
    <!-- // 주계약자 정보 -->
    <!-- 결제정보 -->
    <div class="matching-box">
        <div class="box-wrap">
          <div class="box-tit">
              결제정보
          </div>
          <div class="box-desc"><div class="one-line">계약금액 &nbsp;&nbsp;100,000 원</div></div>
        </div>
    </div>
    <!-- //결제정보 -->
    <!-- 결제수단 -->
    <payment-methods />
    <!-- //결제수단 -->
  </div>
</template>
<script>
import MainContractor from '~/components/page/pre-contract/PaymentForms/MainContractor'
import PaymentMethods from '~/components/page/pre-contract/PaymentForms/PaymentMethods'
export default {
  components: {
    MainContractor,
    PaymentMethods
  },
  data(){
    return{
      carImg: require('~/assets/images/temp/temp-precontact-car-visual2.png'),
      priceMin:'18,000,000',
      priceMax:'20,000,000',
      inColor:{txt:'메테오 블루', src: require('~/assets/images/temp/temp-color-4.png')},
      outColor:{txt:'쉬머링 실버', src: require('~/assets/images/temp/temp-color-1.png')},
      optList:[
        {opt:'현대스마트센스'},
        {opt:'펫 패키지Ⅰ(강아지얼굴,소형)-모노민트'},
        {opt:'펫 패키지Ⅲ(소형)-모노옐로우'},
        {opt:'[N퍼포먼스 파츠] 인테리어 패키지'},
      ]
    }
  },
}
</script>
