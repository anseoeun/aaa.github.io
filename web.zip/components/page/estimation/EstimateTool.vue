<template>
  <section id="scrollCurrent" class="purchase-tool">
    <!-- 2021.03.22 (ver1.1) 3d 버튼 추가 -->
    <div class="car-img">
      <v-img :src="mainImg.src" :alt="mainImg.alt"></v-img>
      <v-btn class="btn-3d" type="icon" icon-class="icon-3d" @click="popConfig = true"
        ><span class="offscreen">3D configurator 보기</span></v-btn
      >
    </div>
    <ul class="flag-list">
      <li v-for="(flag, index) in flagData" :key="index">{{ flag.flagName }}</li>
    </ul>
    <h1>AX 스마트스트림 가솔린 1.1 터보 프리미엄 밀레니얼 A/T</h1>
    <ul class="option-list">
      <li v-for="(option, index) in optionData" :key="index">{{ option.optionName }}</li>
    </ul>
    <!-- <div class="payment-amount"> -->
    <div class="info-grid-list">
      <!-- 2021.03.31 (ver1.3) 수정 start -->
      <ul>
        <li>
          <div class="info-title full">
            <strong>총 차량 구입금액</strong>
            <v-btn
              class="btn btn-detail"
              type="icon"
              :icon-class="['icon-open-arrow', { active: isOptionsShow }]"
              @click="isOptionsShow = !isOptionsShow"
              ><span class="offscreen">상세보기</span></v-btn
            >
            <span class="price t-blue">(-) 1,800,000 원</span>
          </div>
          <div v-show="isOptionsShow" class="info-group full">
            <ul class="desc-list">
              <li>
                <strong class="info-title">차량금액</strong>
                <div class="info-group">
                  <span class="price">33,300,000 원</span>
                </div>
              </li>
              <li>
                <strong class="info-title">탁송료</strong>
                <div class="info-group">
                  <span class="price">270,000 원</span>
                </div>
              </li>
              <li>
                <div class="info-title full">
                  <strong>할인/포인트</strong>
                  <v-btn
                    class="btn btn-detail"
                    type="icon"
                    :icon-class="['icon-open-arrow', { active: isPointShow }]"
                    @click="isPointShow = !isPointShow"
                    ><span class="offscreen">상세보기</span></v-btn
                  >
                  <span class="price t-blue">(-) 1,800,000 원</span>
                </div>
                <div class="info-group full">
                  <ul v-show="isPointShow" class="desc-list">
                    <li v-for="(point, index) in pointData" :key="index">
                      <em>{{ point.pointName }}</em>
                      <span class="price">(-) {{ point.pointPrice }} 원</span>
                    </li>
                  </ul>
                </div>
              </li>
              <li>
                <strong class="info-title">세액 감면 혜택</strong>
                <div class="info-group">
                  <span class="price">33,300,000 원</span>
                </div>
              </li>
            </ul>
          </div>
        </li>
        <li>
          <strong class="info-title">임시운행 의무보험료</strong>
          <div class="info-group"><span class="price">2,300 원</span></div>
        </li>
        <li>
          <strong class="info-title">할부인지대</strong>
          <div class="info-group"><span class="price">2,300 원</span></div>
        </li>
        <li class="total-price">
          <strong class="info-title bold">총 견적 합계</strong>
          <div class="info-group"><strong class="price bold">33,300,000</strong> 원</div>
        </li>
        <li>
          <div class="info-title full">
            <strong>할부원금</strong>
            <v-btn
              class="btn btn-detail"
              type="icon"
              :icon-class="['icon-open-arrow', { active: isDetailShow }]"
              @click="isDetailShow = !isDetailShow"
              ><span class="offscreen">상세보기</span></v-btn
            >
            <span class="price">(-) 1,800,000 원</span>
          </div>
          <div v-show="isDetailShow" class="info-group full">
            <ul class="desc-list">
              <li>
                <strong class="info-title">월 납입금 A (48개월)</strong>
                <div class="info-group">
                  <span class="price">100,000 원</span>
                </div>
              </li>
              <li>
                <strong class="info-title">월 납입금 B (36개월)</strong>
                <div class="info-group">
                  <span class="price">50,000 원</span>
                </div>
              </li>
            </ul>
          </div>
        </li>
        <li>
           <strong class="info-title bold">출고 전 납입총액</strong>
           <div class="info-group"><span class="price bold">2,300 원</span></div>
        </li>
        <li>
          <strong class="info-title">등록비용 (별도 납부)</strong>
          <div class="info-group"><span class="price">2,300 원</span></div>
        </li>
      </ul>
    </div>
    <!-- end -->

    <div class="btn-wrap">
      <v-btn class="btn md blue r">계약하기</v-btn>
      <v-btn class="btn md blue line r">견적 저장하기</v-btn>
    </div>
  </section>
</template>

<script>
export default {
  components: {},
  data() {
    return {
      isOptionsShow: false,
      isDetailShow: false,
      isPointShow: false,
      flagData: [{ flagName: '8월 생산 할인차' }, { flagName: '장애인' }],
      optionData: [{ optionName: '화이트' }, { optionName: '베이지' }, { optionName: '옵션 2개' }],
      pointData: [
        { pointName: '직원할인', pointPrice: '1,000,000' },
        { pointName: '차량할인', pointPrice: '300,000' },
        { pointName: '조건할인', pointPrice: '100,000' },
        { pointName: '지인추천할인', pointPrice: '100,000' },
        { pointName: '쿠폰할인', pointPrice: '100,000' },
        { pointName: '포인트사용', pointPrice: '100,000' }
      ],
      mainImg: {
        src: require('~/assets/images/temp/temp-payment-car-model.png'),
        alt: 'AX 스마트스트림 가솔린 1.1 터보 프리미엄 밀레니얼 A/T'
      }
    }
  }
}
</script>
