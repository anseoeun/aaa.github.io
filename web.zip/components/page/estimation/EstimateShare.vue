<template>
  <div class="estimate-share">
    <div class="purchase-wrap">
      <div class="estimate-description">
        <div class="car-img">
          <v-img :src="carImg.src" :alt="carImg.alt"></v-img>
          <!-- 2021.03.22 (ver1.2) 다운로드페이지에서 버튼삭제를 위해 v-if 추가 -->
          <v-btn v-if="type != 'download'" class="btn-3d" type="icon" icon-class="icon-3d" @click="popConfig = true"
            ><span class="offscreen">3D configurator 보기</span></v-btn
          >
        </div>
        <div class="info-grid-list">
          <ul>
            <li>
              <strong class="info-title">견적 번호</strong>
              <p class="info-group full">U00000040282</p>
            </li>
            <li>
              <strong class="info-title">견적 기준일</strong>
              <p class="info-group full">2021년 1월 25일</p>
            </li>
            <li class="total-price">
              <strong class="info-title"><span class="bold">홍길동</span> 님의</strong>
              <div class="info-group full">
                <p class="t-blue">총 차량 금액 <strong class="price">37,000,000</strong> 원</p>
              </div>
            </li>
          </ul>
          <p class="bullet">
            견적기준일 이후 재 견적 시 가격 및 정책 등의 변경에 의하여 같은 조건의 차량에 대한 견적이 일치하지 않을 수
            있습니다.
          </p>
        </div>

        <!-- 2021.03.22 (ver1.2) 다운로드페이지에서 버튼삭제를 위해 v-if 추가 -->
        <div v-if="type != 'download'" class="btn-wrap">
          <v-btn class="btn lg blue line r">이 차로 새 견적내기</v-btn>
          <v-btn class="btn lg blue r">계약하기</v-btn>
        </div>
      </div>
      <!-- 견적사항 -->
      <section class="information-detail">
        <div class="summary-info">
          <h1 class="title">견적사항</h1>
        </div>
        <div class="detail-info">
          <div class="info-grid-list">
            <ul>
              <li>
                <strong class="info-title">모델</strong>
                <div class="info-group">
                  <p>AX 스마트스트림 가솔린 1.1 터보 프리미엄 밀레니얼 A/T</p>
                  <span class="price">33,000,000 원</span>
                </div>
              </li>
              <li>
                <strong class="info-title">외장 색상</strong>
                <div class="info-group">
                  <ul class="color-list">
                    <li>
                      <!-- 2021.03.22 (ver1.2) 추후 디자인 확정시 일괄 수정예정 -->
                      <div class="color">
                        <div class="color-sample" :style="`background-image:url(${outColor.src})`"></div>
                        <div class="color-txt">{{ outColor.txt }}</div>
                      </div>
                    </li>
                  </ul>
                  <!-- 2021.03.15 (ver1.1) price 추가 -->
                  <span class="price">{{ outColor.price }} 원</span>
                </div>
              </li>
              <li>
                <strong class="info-title">내장 색상</strong>
                <div class="info-group">
                  <ul class="color-list">
                    <li>
                      <div class="color">
                        <div class="color-sample" :style="`background-image:url(${inColor.src})`"></div>
                        <div class="color-txt">{{ inColor.txt }}</div>
                      </div>
                    </li>
                  </ul>
                  <!-- 2021.03.15 (ver1.1) price 추가 -->
                  <span class="price">{{ inColor.price }} 원</span>
                </div>
              </li>
              <li>
                <strong class="info-title">옵션</strong>
                <div class="info-group">
                  <!-- 2021.03.29 (ver1.3) v-if 추가 -->
                  <ul v-if="optionData.length > 0" class="desc-list">
                    <li v-for="(option, index) in optionData" :key="index">
                      <em>{{ option.name }}</em>
                      <ul>
                        <!-- 옵션명 클릭시 사양안내팝업(미작업) 호출 예정 (기획 3/24수정내용) -->
                        <li v-for="(subopt, idx) in option.subOption" :key="idx">
                          {{ subopt.name }} <span class="price">{{ subopt.price }} 원</span>
                        </li>
                      </ul>
                    </li>
                  </ul>
                  <!-- 2021.03.29 (ver1.3) 추가 -->
                  <p v-else class="no-data">추가 선택한 옵션이 없습니다.</p>
                  <!-- 2021.03.29 (ver1.3) 추가 : 추후 항목보기(탐색) 팝업연결 예정 -->
                  <div class="full"><v-btn class="btn-more">기본포함 품목보기</v-btn></div>
                </div>
              </li>
              <li>
                <strong class="info-title">탁송료</strong>
                <div class="info-group">
                  <p>배달탁송 / 서울시 ( 3월 2주차 출고예정 )</p>
                  <v-popover trigger="hover" placement="bottom-start">
                    <p>
                      현 시점 계약완료 기준으로 재고 및<br />생산계획 기반 산출된 예상출고일이며,<br />당사 사정에
                      의하여 변경될 수 있으니<br />단순 참고만 하시기 바랍니다.
                    </p>
                    <v-btn slot="reference"><i class="icon-help"></i></v-btn>
                  </v-popover>
                  <span class="price">0 원</span>
                </div>
              </li>
              <li>
                <strong class="info-title">할인/포인트</strong>
                <div class="info-group">
                  <ul class="desc-list">
                    <li v-for="(discountRate, index) in discountData" :key="index">
                      <em>{{ discountRate.discountName }}</em>
                      <span class="price">{{ discountRate.discountPrice }} 원</span>
                    </li>
                  </ul>
                </div>
              </li>
              <!-- 2021.03.29 (ver1.3) 삭제 -->
              <!-- <li>
                <strong class="info-title">면세조건</strong>
                <div class="info-group">
                  <ul class="desc-list">
                    <li>
                      <em><span class="flag">경차</span>일반인 (다자녀)</em>
                    </li>
                    <li>
                      <em>세액 감면 혜택</em>
                      <span class="price">(-) 100,000 원</span>
                    </li>
                  </ul>
                </div>
              </li> -->
            </ul>
          </div>
          <!-- 2021.03.22 (ver1.2) 삭제 -->
          <!-- <div class="info-grid-list">
            <ul>
              <li>
                <strong class="info-title bold full">블루멤버스</strong>
                <div class="info-group full">
                  <ul class="desc-list">
                    <li>
                      <em>적립 예정 포인트</em>
                      <p>차량 구매 1회차</p>
                      <span class="last">5,000 P</span>
                    </li>
                  </ul>
                </div>
              </li>
            </ul>
          </div> -->
        </div>
      </section>

      <!-- 2021.03.22 (ver1.2) 견적금액영역 추가 -->
      <section class="information-detail">
        <div class="summary-info">
          <h1 class="title">견적금액</h1>
        </div>
        <div class="detail-info estimate-price">
          <div class="info-grid-list">
            <ul>
              <li>
                <!-- 2021.03.29 (ver1.3) 텍스트 수정 -->
                <strong class="info-title">차량금액</strong>
                <div class="info-group"><span class="price">33,200,000 원</span></div>
              </li>
              <li class="plus">
                <!-- 2021.03.29 (ver1.3) 텍스트 수정 -->
                <strong class="info-title">탁송료</strong>
                <div class="info-group"><span class="price">270,000 원</span></div>
              </li>
              <li class="minus">
                <strong class="info-title">총 할인/포인트</strong>
                <div class="info-group"><span class="price">1,800,000 원</span></div>
              </li>
              <li class="minus">
                <!-- 2021.03.29 (ver1.3) 텍스트 수정 -->
                <strong class="info-title">세금 감면 혜택</strong>
                <div class="info-group"><span class="price">300,000 원</span></div>
              </li>
              <li class="total-price">
                <!-- 2021.03.29 (ver1.3) 텍스트 수정 -->
                <strong class="info-title full">차량 견적금액</strong>
                <div class="info-group"><span class="price">38,000,000</span>&nbsp;원</div>
              </li>
            </ul>
            <div class="bluemembers">
              <strong>블루멤버스 적립 예정 포인트</strong>
              <span>차량 구매 1회차</span>
              <span class="last">5,000 P</span>
            </div>
          </div>
        </div>
      </section>

      <!-- 일시불 -->
      <section class="information-detail">
        <div class="summary-info">
          <h1 class="title">구입 예상 비용</h1>
        </div>
        <!-- 2021.03.22 (ver1.2) expectation 클래스 추가 -->
        <div class="detail-info expectation">
          <div class="info-grid-list line">
            <ul>
              <li>
                <strong class="info-title">결제 수단</strong>
                <div class="info-group">
                  <p>일시불 <span class="sub-text">(현금/신용카드)</span></p>
                </div>
              </li>
              <li>
                <strong class="info-title">출고 전 납입 총액</strong>
                <div class="info-group">
                  <span class="price">85,300 원</span>
                  <ul class="desc-list">
                    <li>
                      <em>계약금</em>
                      <span class="price">100,000 원</span>
                    </li>
                    <li>
                      <em>인도금</em>
                      <span class="price">100,000 원</span>
                    </li>
                    <li>
                      <em>단기의무보험료</em>
                      <span class="price">100,000 원</span>
                    </li>
                  </ul>
                </div>
              </li>
              <li>
                <!-- 2021.03.29 (ver1.3) 텍스트 수정  -->
                <strong class="info-title">등록비 <span class="sub-text">(별도 납부)</span></strong>
                <div class="info-group">
                  <span class="price">85,300 원</span>
                  <ul class="desc-list">
                    <li>
                      <em>취득세</em>
                      <span class="price">0 원</span>
                    </li>
                    <li>
                      <em>공채 <span class="sub-text">(서울/할인 기준)</span></em>
                      <span class="price">0 원</span>
                    </li>
                    <li>
                      <em>종지대 <span class="sub-text">(수입인지)</span></em>
                      <span class="price">0 원</span>
                    </li>
                    <li>
                      <em>차량번호판</em>
                      <span class="price">0 원</span>
                    </li>
                    <li>
                      <em>등록대행 수수료</em>
                      <span class="price">0 원</span>
                    </li>
                  </ul>
                </div>
              </li>
            </ul>
          </div>
        </div>
      </section>
      <div class="purchase-total-price">
        <ul>
          <li class="t-blue">
            총 차량 견적 금액
            <strong class="price">38,000,000</strong> 원
          </li>
          <li>
            출고 전 납입총액
            <strong class="price">38,000,000</strong> 원
            <p class="sub-text">단기의무 보험교 포함</p>
          </li>
        </ul>
      </div>

      <!-- 할부 -->
      <section class="information-detail">
        <div class="summary-info">
          <h1 class="title">구입 예상 비용</h1>
        </div>
        <!-- 2021.03.22 (ver1.2) expectation 클래스 추가 -->
        <div class="detail-info expectation">
          <div class="info-grid-list line">
            <ul>
              <li>
                <strong class="info-title">결제 수단</strong>
                <div class="info-group">
                  <p>할부 (임직원 무이자 + 표준형)</p>
                </div>
              </li>
              <li>
                <strong class="info-title">월 납입금액</strong>
                <div class="info-group">
                  <ul class="desc-list">
                    <li>
                      <em>A. 표준형</em>
                      <span class="price">월 150,000 원</span>
                      <ul class="desc-sub-list">
                        <li>
                          <em>할부원금</em>
                          <span class="price">1,000,000 원</span>
                        </li>
                        <li>
                          <em>할부기간</em>
                          <span class="last">36 개월</span>
                        </li>
                        <li>
                          <em>금리</em>
                          <span class="last">4.5 %</span>
                        </li>
                      </ul>
                    </li>
                    <li>
                      <em>B. 무이자</em>
                      <span class="price">월 240,000 원</span>
                      <ul class="desc-sub-list">
                        <li>
                          <em>할부원금</em>
                          <span class="price">1,000,000 원</span>
                        </li>
                        <li>
                          <em>할부기간</em>
                          <span class="last">36 개월</span>
                        </li>
                        <li>
                          <em>금리</em>
                          <span class="last">4.5 %</span>
                        </li>
                      </ul>
                    </li>
                  </ul>
                </div>
              </li>
              <li>
                <!-- 2021.03.29 (ver1.3) 텍스트 수정  -->
                <strong class="info-title">등록비 <span class="sub-text">(별도 납부)</span></strong>
                <div class="info-group">
                  <span class="price">85,300 원</span>
                  <ul class="desc-list">
                    <li>
                      <em>취득세</em>
                      <span class="price">0 원</span>
                    </li>
                    <li>
                      <em>공채 <span class="sub-text">(서울/할인 기준)</span></em>
                      <span class="price">0 원</span>
                    </li>
                    <li>
                      <em>종지대 <span class="sub-text">(수입인지)</span></em>
                      <span class="price">0 원</span>
                    </li>
                    <li>
                      <em>차량번호판</em>
                      <span class="price">0 원</span>
                    </li>
                    <li>
                      <em>등록대행 수수료</em>
                      <span class="price">0 원</span>
                    </li>
                  </ul>
                </div>
              </li>
            </ul>
          </div>
        </div>
      </section>
      <!-- 2021.03.22 (ver1.2) installment 클래스 추가 -->
      <div class="purchase-total-price installment">
        <ul>
          <li class="t-blue">
            총 차량 견적 금액
            <strong class="price">38,000,000</strong> 원
          </li>
          <li>
            출고 전 납입총액
            <strong class="price">38,000,000</strong> 원
            <p class="sub-text">단기의무보험료, 할부인지대 포함</p>
            <!-- 2021.03.22 (ver1.2) 텍스트 수정 -->
          </li>
          <li>
            월 납입금액
            <strong class="price">340,000</strong> 원
          </li>
        </ul>
      </div>

      <!-- 2021.03.22 (ver1.2) PLCC 추가 -->
      <!-- 구입예상비용 -->
      <section class="information-detail">
        <div class="summary-info">
          <h1 class="title">구입 예상 비용</h1>
        </div>
        <div class="detail-info expectation">
          <div class="info-grid-list line">
            <ul>
              <li>
                <strong class="info-title">결제 수단</strong>
                <div class="info-group">
                  PLCC 카드
                </div>
              </li>
              <li>
                <strong class="info-title">제휴 혜택</strong>
                <div class="info-group">
                  포인트형
                </div>
              </li>
              <li>
                <strong class="info-title">출고 전 납입 총액</strong>
                <div class="info-group">
                  <span class="price">85,300 원</span>
                  <ul class="desc-list">
                    <li>
                      <em>계약금</em>
                      <span class="price">100,000 원</span>
                    </li>
                    <li>
                      <em>인도금</em>
                      <span class="price">100,000 원</span>
                    </li>
                    <li>
                      <em>단기의무보험료</em>
                      <span class="price">100,000 원</span>
                    </li>
                  </ul>
                </div>
              </li>
              <li>
                <!-- 2021.03.29 (ver1.3) 텍스트 수정  -->
                <strong class="info-title">등록비 <span class="sub-text">(별도 납부)</span></strong>
                <div class="info-group">
                  <span class="price">85,300 원</span>
                  <ul class="desc-list">
                    <li>
                      <em>취득세</em>
                      <span class="price">0 원</span>
                    </li>
                    <li>
                      <em>공채 <span class="sub-text">(서울/할인 기준)</span></em>
                      <span class="price">0 원</span>
                    </li>
                    <li>
                      <em>종지대 <span class="sub-text">(수입인지)</span></em>
                      <span class="price">0 원</span>
                    </li>
                    <li>
                      <em>차량번호판</em>
                      <span class="price">0 원</span>
                    </li>
                    <li>
                      <em>등록대행 수수료</em>
                      <span class="price">0 원</span>
                    </li>
                  </ul>
                </div>
              </li>
            </ul>
          </div>
        </div>
      </section>
      <!-- 총금액 -->
      <div class="purchase-total-price">
        <ul>
          <li class="t-blue">
            총 차량 견적 금액
            <strong class="price">38,000,000</strong> 원
          </li>
          <li>
            출고 전 납입총액
            <strong class="price">38,000,000</strong> 원
            <p class="sub-text">단기의무 보험교 포함</p>
          </li>
        </ul>
      </div>
    </div>
    <div class="banner-wrap">배너영역</div>
    <div class="link-list">
      <ul>
        <li><nuxt-link to="/" target="_blank" title="새창 열기">시승신청</nuxt-link></li>
        <!-- 2021.03.31 (ver1.3) 텍스트 추가, 수정 start -->
        <li><nuxt-link to="/" target="_blank" title="새창 열기">전시장 찾기</nuxt-link></li>
        <li><nuxt-link to="/" target="_blank" title="새창 열기">구매 혜택 알아보기</nuxt-link></li>
        <!-- end -->
        <li><nuxt-link to="/" target="_blank" title="새창 열기">중고차 시세 조회</nuxt-link></li>
        <li><nuxt-link to="/" target="_blank" title="새창 열기">자동차 보험료 계산</nuxt-link></li>
        <li><nuxt-link to="/" target="_blank" title="새창 열기">할부 한도 조회</nuxt-link></li>
      </ul>
    </div>
    <notice-info />
  </div>
</template>

<script>
import NoticeInfo from '~/components/page/estimation/NoticeInfo'
export default {
  components: {
    NoticeInfo
  },
  props: {
    type: {
      type: String,
      default: ''
    }
  },
  data() {
    return {
      carImg: {
        src: require('~/assets/images/temp/temp-payment-car-model.png'),
        alt: 'AX 스마트스트림 가솔린 1.1 터보 프리미엄 밀레니얼 A/T'
      },
      priceMin: '18,000,000',
      priceMax: '20,000,000',
      // 2021.03.15 (ver1.1) price 추가, 2021.03.22 (ver1.2) 추후 디자인 확정시 일괄 수정예정
      inColor: { txt: '메테오 블루', src: require('~/assets/images/temp/temp-color-4.png'), price: '0' },
      outColor: { txt: '쉬머링 실버', src: require('~/assets/images/temp/temp-color-1.png'), price: '100,000' },
      optList: [
        { opt: '현대스마트센스' },
        { opt: '펫 패키지Ⅰ(강아지얼굴,소형)-모노민트' },
        { opt: '펫 패키지Ⅲ(소형)-모노옐로우' },
        { opt: '[N퍼포먼스 파츠] 인테리어 패키지' }
      ],
      optionData: [
        {
          name: '옵션',
          subOption: [
            { name: '옵션명', price: '100,000' },
            { name: '옵션명', price: '100,000' }
          ]
        },
        {
          name: 'H Genuine Accessories',
          subOption: [
            { name: '옵션명', price: '100,000' },
            { name: '옵션명', price: '100,000' },
            { name: '옵션명', price: '100,000' }
          ]
        },
        { name: 'N Performance', subOption: [{ name: '옵션명', price: '100,000' }] }
      ],
      discountData: [
        { discountName: '직원할인', discountPrice: '100,000' },
        { discountName: '기본할인', discountPrice: '100,000' },
        // 2021.03.29 (ver1.3) 수정
        { discountName: '기획전할인', discountPrice: '100,000' },
        { discountName: '타겟조건할인', discountPrice: '100,000' },
        { discountName: '지인추천할인', discountPrice: '100,000' },
        { discountName: '쿠폰할인', discountPrice: '100,000' },
        { discountName: '세이브-오토', discountPrice: '100,000' },
        { discountName: 'M포인트 사용', discountPrice: '100,000' },
        { discountName: '블루멤버스 포인트 사용', discountPrice: '100,000' },
        { discountName: '블루멤버스 포인트 선사용', discountPrice: '100,000' }
      ]
    }
  }
}
</script>
