<template>
  <v-popup
    :visible="visible"
    :width="'550px'"
    @close="
      $emit('close')
      popVisible = false
    "
    @confirm="
      $emit('close')
      popVisible = false
    "
  >
    <template slot="header">
      <div class="title">쿠폰 등록</div>
      <p v-if="isComplete === 'default'" class="header-description">쿠폰 일련번호를 입력하세요.</p>
    </template>

    <template v-if="isComplete === 'default'">
      <template slot="body">
        <el-form ref="form" :model="couponForm" :rules="rules">
          <el-form-item prop="couponNumber">
            <div class="form-grid">
              <div class="label-input">
                <label class="form-title">쿠폰일련번호</label>
                <v-input v-model="couponForm.couponNumber" class="form-group" type="number" maxlength="10" placeholder="일련번호 10자리를 입력하세요." />
              </div>
            </div>
          </el-form-item>
        </el-form>
        <ul class="bullet-list">
          <li>쿠폰 등록 후 유효기간, 혜택, 사용조건 등을 꼭 확인하세요.</li>
          <li>동일한 할인 조건의 쿠폰은 중복 등록되지 않습니다.</li>
        </ul>
      </template>
      <template slot="footer">
        <v-btn class="btn btn-lg" b-size="btn-lg">등록</v-btn>
      </template>
    </template>

    <template v-if="isComplete === 'result'">
      <template slot="body">
        <p class="text-main">쿠폰이 등록되었습니다.</p>
      </template>
      <template slot="footer">
        <v-btn class="btn btn-lg" b-size="btn-lg">확인</v-btn>
      </template>
    </template>

  </v-popup>
</template>

<script>
import { VPopup } from '~/components/element'
export default {
  components: {
    VPopup
  },
  props: {
    visible: {
      type: Boolean,
      default: false
    },
    isComplete: {
      type: String,
      default: 'default',
    },
  },
  data() {
    return {
      couponForm: {
        couponNumber: '',
      }
    }
  },
  computed: {
    rules() {
      return {
        couponNumber: [
          {
            required: true,
            message: '* 쿠폰 일련번호를 입력해주세요.',
            trigger: 'blur'
          }
        ],
      }
    },
  },
  updated() {
    if (this.visible) {
      this.setLabel((idg) => {
        // console.dir(idg) // 자동 생성된 ID 배열, 예) 첫번째 입력폼 ID : idg[0]
      })
    }
  },
}
</script>