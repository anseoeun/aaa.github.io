<template>
  <v-popup
    :visible="visible"
    :full-popup="true"
    class="full-popup"
    @close="
      $emit('close')
    "
  >

    <template slot="header">
    </template>
    <template slot="body">
      <div style="width: 100%; height:calc(100vh - 100px); background-color: #f6f3f2;"></div>
    </template>
  </v-popup>
</template>

<script>
import { VPopup } from '~/components/element'
export default {
  components: {
    VPopup
  },
  props: {
    visible: {
      type: Boolean,
      default: false
    },
  },
}
</script>