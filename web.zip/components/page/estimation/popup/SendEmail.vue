<template>
  <v-popup
    :visible="visible"
    :width="'550px'"
    @close="
      $emit('close')
      popVisible = false
    "
    @confirm="
      $emit('close')
      popVisible = false
    "
  >
    <template slot="header">
      <div class="title">이메일 보내기</div>
      <p class="header-description">견적서를 받아보실 이메일 주소를 입력해주세요.</p>
    </template>
    <template slot="body">
      <el-form ref="form" :model="emailForm" :rules="rules">
        <el-form-item prop="emailNumber">
          <div class="form-grid">
            <div class="label-input">
              <label class="form-title">이메일 주소</label>
              <v-input v-model="emailForm.emailNumber" class="form-group" type="number" maxlength="10" placeholder="이메일 주소를 입력해주세요." />
            </div>
          </div>
        </el-form-item>
      </el-form>
      <p>※ 입력한 이메일주소는 견적서 발송 이외의 다른용도로 사용되지 않습니다.</p>
    </template>

    <template slot="footer">
      <v-btn class="btn btn-lg" b-size="btn-lg">이메일 보내기</v-btn>
    </template>
  </v-popup>
</template>

<script>
import { VPopup } from '~/components/element'
export default {
  components: {
    VPopup
  },
  props: {
    visible: {
      type: Boolean,
      default: false
    },
  },
  data() {
    return {
      emailForm: {
        emailNumber: '',
      }
    }
  },
  computed: {
    rules() {
      return {
        emailNumber: [
          {
            required: true,
            message: '* 이메일 주소를 다시 확인해주세요.',
            trigger: 'blur'
          }
        ],
      }
    },
  },
  updated() {
    if (this.visible) {
      this.setLabel((idg) => {
        // console.dir(idg) // 자동 생성된 ID 배열, 예) 첫번째 입력폼 ID : idg[0]
      })
    }
  },
}
</script>