<template>
  <v-popup
    :visible="visible"
    :width="'776px'"
    :footer="['confirm']"
    @close="
      $emit('close')
      popVisible = false
    "
    @confirm="
      $emit('close')
      popVisible = false
    "
  >

    <template slot="header">
      <div class="title">임직원 할인 혜택 안내</div>
    </template>
    <template slot="body">
      <div class="terms-area">

        <strong>그룹사 및 관계사 직원분들께서는 임직원 할인을 받으실 수 있습니다.</strong>

        <strong>1) 할인방법</strong>
        <p>: 마이페이지에서 직원 인증을 완료하셔야 임직원 할인이 적용된 견적을 내보실 수 있으며 최종 할인 여부 및 할인 금액은 차량 결제시 재인증을 통해 확정됩니다.</p>

        <strong>-1차 : 임직원 인증</strong>
        <p>임직원 할인이 적용된 견적을 산출하기 위해 임직원을 인증하는 단계로 [마이페이지&gt;임직원인증]에서 임직원 정보는 입력하고 증빙서류를 등록하시면 고객센터에서 심사 후 임직원 여부를 등록해드립니다.</p>

        <strong>-2차 : 임직원 재직 확인</strong>
        <p>임직원 할인 여부 및 할인 금액은 차량 결제 당시 고객님의 재직 상태에 따라 달라지기 때문에 마이페이지에서 임직원 인증을 완료하셨더라도 차량 결제시 재직 확인이 필요하며 결제시 고객센터 안내에 따라 재인증해주시면 심사 후 임직원 할인을 적용받아 차량 구매가 가능합니다.</p>

        <strong>2)재구입 연한 : 임직원 할인 구매는 2년에 1회만 적용 가능합니다.</strong>

        <strong>3) 의무보유기간</strong>
        <ul>
          <li>- 퇴임 중역, 대리점, 당사 임직원 동일 처우 직원의 경우, 임직원 할인 적용 차량을 2년간 의무 보유 하셔야 합니다.</li>
          <li>- 계약직의 경우, 퇴사시까지 임직원 할인 적용 차량을 의무 보유 하셔야 합니다.</li>
          <li>- 퇴직 전에 임직원 할인 적용 차량을 구입한 당사 정년 퇴직자(명예사원증 보유자)라도 해당 차량을 2년간 보유하지 않으면 임직원 할인을 받으실 수 없습니다.<br />(2년 內 전매한 경우는 1회에 한해 재 구매 불가)</li>
        </ul>

        <strong>※ 할인율 등의 자세한 사항은 근무하시는 회사의 담당부서 및 캐스퍼 전용 고객센터(080-500-6000)로 문의 바랍니다.</strong>

      </div>
    </template>
  </v-popup>
</template>

<script>
import { VPopup } from '~/components/element'
export default {
  components: {
    VPopup
  },
  props: {
    visible: {
      type: Boolean,
      default: false
    },
  },
}
</script>