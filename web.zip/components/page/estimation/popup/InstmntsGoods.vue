<template>
  <div class="sale-product-select">
    <v-popup
      :visible="popVisible.instmntsGoods"
      :width="'1000px'"
      :footer="['choiceEnd']"
      @confirm="popVisible.instmntsGoods = false"
      @close="popVisible.instmntsGoods = false"
    >
      <template slot="header">
        <div class="title">할부상품 선택</div>
      </template>
      <template slot="body">
        <!-- sale-product-choice-wrap -->
        <div class="sale-product-choice-wrap">
          <div class="all-price">
            <strong>결제 예정 금액</strong>
            <span class="account"><span class="price">15,630,000</span> <span class="unit">원</span></span>
          </div>
          <!-- sale-slider-wrap -->
          <div class="sale-slider-wrap">
            <div class="slider-box label-input">
              <label><strong>할부원금</strong></label>
              <div class="slider-text">
                <p class="set-text">할부로 납입할 금액을 설정해 주세요.</p>
              </div>
              <v-slider
                v-model="installmentValue"
                :min="100000"
                :max="30050000"
                :step="100000"
                :marks="{
                  100000: {
                    label: this.$createElement('strong', '100,000')
                  },
                  30050000: {
                    label: this.$createElement('strong', '30,050,000')
                  }
                }"
                class="default-slider"
              />
              <div class="slider-input">
                <div class="account">
                  <v-input v-model="installmentValue" /><span class="unit">원</span>
                  <span class="advance">선수금 <span>4212,000 원</span></span>
                </div>
              </div>
            </div>
            <div class="slider-box label-input">
              <label><strong>할부기간</strong></label>
              <div class="slider-text">
                <p class="set-text">할부 납입기간을 설정해 주세요</p>
              </div>
              <v-slider
                v-model="installmentPeriod"
                :min="2"
                :max="60"
                :step="1"
                :marks="{
                  2: {
                    label: this.$createElement('strong', '2')
                  },
                  60: {
                    label: this.$createElement('strong', '60')
                  }
                }"
                class="default-slider"
              />
              <div class="slider-input">
                <div class="account"><v-input v-model="installmentPeriod" /><span class="unit">개월</span></div>
              </div>
            </div>
          </div>
          <!-- // sale-slider-wrap -->

          <!-- 할인 및 포인트에서 '임직원 할부' 선택후 보이는 부분 -->
          <div class="sale-product-result-wrap">
            <p class="total-txt">* 총 {{ staffProductList.length }}개의 할부 상품이 있습니다.</p>
            <div class="sale-product-result">
              <ul class="benefit-list staff">
                <li
                  v-for="(product, index) in staffProductList"
                  :key="index"
                  :class="{ on: staffProduct != null && staffProduct == index }"
                >
                  <div class="desc">
                    <b class="tit">
                      <v-radio v-model="staffProduct" :one-check="true" :label="index">{{ product.name }}</v-radio>
                    </b>
                  </div>
                  <div class="setting">
                    <div v-for="(prd, idx) in product.product" :key="idx" class="prd-desc">
                      <div class="more">
                        <div v-if="isNan(prd.subname)" class="sub-name">{{ prd.subname }}</div>
                        <v-btn class="btn-more" type="button" @click="popVisible.repaymentPlan = true"
                          >상환 계획 조회</v-btn
                        >
                        <!--  @click="$emit('repaymentPlan')" -->
                      </div>
                      <div class="form-area inbl-wrap">
                        <div v-if="isNan(prd.totalPrice)" class="total-price label-input">
                          <label class="offscreen">상환계획금</label>
                          <v-input v-model="prd.totalPrice" />
                          <span class="unit">원</span>
                        </div>
                        <v-select v-model="prd.month" :data="optsList" />
                      </div>
                      <div class="etc-desc">
                        <div class="flag rate">
                          <span v-if="prd.rate == 0">금리 무이자</span>
                          <span v-else>금리 {{ prd.rate }}%</span>
                        </div>
                        <div class="account">
                          월 <span class="price">{{ prd.price }}</span> <span class="unit">원</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </li>
              </ul>
            </div>
          </div>
          <!-- 기본 -->
          <div class="sale-product-result-wrap">
            <p class="total-txt">* 총 {{ productList.length }}개의 할부 상품이 있습니다.</p>
            <div class="sale-product-result">
              <ul class="benefit-list normal">
                <li
                  v-for="(product, index) in productList"
                  :key="index"
                  :class="{ on: normalProduct != null && normalProduct == index }"
                >
                  <div class="desc">
                    <b class="tit">
                      <v-radio v-model="normalProduct" :one-check="true" :label="index">{{ product.name }}</v-radio>
                      <v-btn v-if="product.code !== undefined" @click="goodsInfoClick(product.code)"
                        ><i class="icon-info"></i
                      ></v-btn>
                    </b>
                    <p class="exp" v-html="product.exp"></p>
                    <div v-if="product.more !== undefined" class="more">
                      <v-btn class="btn-more">자세히보기</v-btn>
                    </div>
                  </div>
                  <div class="setting">
                    <div class="more">
                      <v-btn class="btn-more" type="button" @click="popVisible.repaymentPlan = true"
                        >상환 계획 조회</v-btn
                      >
                      <!--  @click="$emit('repaymentPlan')" -->
                    </div>
                    <div class="form-area inbl-wrap">
                      <span v-if="isNan(product.sub)" class="flag rate">{{ product.sub }}</span>
                      <div v-if="isNan(product.totalPrice)" class="total-price label-input">
                        <label class="offscreen">상환계획금</label>
                        <v-input v-model="product.totalPrice" />
                        <span class="unit">원</span>
                      </div>
                      <v-select v-model="product.month" :data="optsList" />
                    </div>
                    <p v-if="product.interestTxt !== ''" class="interest-text bullet-star">{{ product.interestTxt }}</p>
                    <div class="etc-desc">
                      <div class="flag rate">금리 {{ product.rate }}%</div>
                      <div class="account">
                        월 <span class="price">{{ product.price }}</span> <span class="unit">원</span>
                      </div>
                    </div>
                    <p v-if="product.installmentTxt !== undefined" class="installment-text">
                      {{ product.installmentTxt }}
                    </p>
                  </div>
                </li>
              </ul>
            </div>
          </div>
        </div>
        <!-- // sale-product-choice-wrap -->
      </template>
    </v-popup>
    <!-- Popup - 할부상품-->
    <installment-products-detail
      :is-popup-pay1="isPopupPay1"
      :is-popup-pay2="isPopupPay2"
      :is-popup-pay3="isPopupPay3"
      :is-popup-pay4="isPopupPay4"
      :is-popup-pay5="isPopupPay5"
      @onClose="onClose"
    />
  </div>
</template>

<script>
import InstallmentProductsDetail from '~/components/page/payment/popup/InstallmentProductsDetail'
import { VPopup, VBtn, VSlider } from '~/components/element'

export default {
  components: {
    VPopup,
    VBtn,
    VSlider,
    InstallmentProductsDetail
  },
  props: {
    popVisible: {
      type: Object,
      defualt: {},
      required: true
    }
  },
  data() {
    return {
      value1: 0,
      installmentValue: 20050000,
      installmentPeriod: 36,
      selected: '',
      optsList: [
        { value: 'select1', label: '2 개월' },
        { value: 'select2', label: '36 개월' },
        { value: 'select3', label: '60 개월' }
      ],
      normalProduct: null,
      staffProduct: null,
      productList: [
        {
          name: '금융할부판촉상품명1',
          more: '',
          exp: '파격적인 할인! 파격적인 초 저금리!',
          month: '36개월',
          price: '443,270',
          rate: '1.25',
          interestTxt: ''
        },
        {
          name: '금융할부판촉상품명2',
          more: '',
          exp: '파격적인 할인! 파격적인 초 저금리!',
          month: '36개월',
          price: '443,270',
          rate: '1.25',
          interestTxt: '할부금 감면 3~5% (할부 개월수에 따라 차등)'
        },
        {
          name: '표준형',
          code: 'JA',
          exp: '매일 똑같은 금액을 나눠내는 상환 방식',
          month: '36개월',
          price: '443,270',
          rate: '1.25',
          interestTxt: ''
        },
        {
          name: '거치형',
          code: 'JF',
          exp: '초기 1년간 이자만 내고<br />이후 원금을 자유롭게나눠내는 상환 방식',
          month: '36개월',
          price: '47,270',
          rate: '1.25',
          interestTxt: '할부금 감면 3~5% (할부 이용 개월수에 따라 차등)',
          installmentTxt: '1년 이후 월 483,450원'
        },
        {
          name: '유예형',
          code: 'XA',
          exp: '현금 일부를 유예하여<br /> 월 납입금 부답을 완화하는상환 방식',
          month: '36개월',
          sub: '유예금 21.1%',
          price: '243,270',
          totalPrice: '40,000,000',
          rate: '1.25',
          interestTxt: ''
        },
        // {name:'초기부담 Zero형', code:'JN', exp:'차량가 전액 할부 금액 및 자동차 구매에 필요한<br />부대비용 추가 대출 금액을 할부기간 내 매월<br />일정한 금액으로 납부하는 방식', month:'36개월', sub:'추가대출금 25%', price:'243,270', totalPrice:'40,000,000', rate:'1.25'},
        {
          name: '잔가보장형',
          code: 'XC',
          exp:
            '총 할부금의 일부는 원금과 이자를 일정하게<br />납부하고, 남은 원금은 이자만 납부하다가 <br />만기 시 한번에 상환하는 방식',
          month: '36개월',
          sub: '유예금 21.1%',
          price: '243,270',
          totalPrice: '40,000,000',
          rate: '1.25',
          interestTxt: '할부금 감면 3~5% (할부 이용 개월수에 따라 차등)'
        }
      ],
      staffProductList: [
        { name: '직원 무이자 할부', product: [{ month: '36개월', price: '443,270', rate: '0' }] },
        {
          name: '직원 무이자 + 표준형',
          product: [
            { subname: 'A 직원 무이자', month: '36개월', price: '243,270', totalPrice: '40,000,000', rate: '1.25' },
            { subname: 'B 표준형', month: '36개월', price: '243,270', totalPrice: '40,000,000', rate: '1.25' }
          ]
        }
      ],
      isPopupPay1: false,
      isPopupPay2: false,
      isPopupPay3: false,
      isPopupPay4: false,
      isPopupPay5: false,
      InterestFree: '20,000,000'
    }
  },
  updated() {
    if (this.popVisible.installmentProducts) {
      this.setLabel((idg) => {
        // console.dir(idg) // 자동 생성된 ID 배열
      })
    }
  },
  methods: {
    goodsInfoClick(code) {
      this.isPopupPay1 = false
      this.isPopupPay2 = false
      this.isPopupPay3 = false
      this.isPopupPay4 = false
      this.isPopupPay5 = false
      if (code === 'JA') {
        this.isPopupPay1 = true
      } else if (code === 'XC') {
        this.isPopupPay2 = true
      } else if (code === 'JF') {
        this.isPopupPay3 = true
      } else if (code === 'XA') {
        this.isPopupPay4 = true
      } else if (code === 'JN') {
        this.isPopupPay5 = true
      }
    },
    onClose() {
      // 상세팝업 off
      this.isPopupPay1 = false
      this.isPopupPay2 = false
      this.isPopupPay3 = false
      this.isPopupPay4 = false
      this.isPopupPay5 = false
    },
    isNan(val) {
      return val != undefined && val != null && val != '' ? true : false
    }
  }
}
</script>
