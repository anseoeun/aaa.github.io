<template>
  <v-popup
    :visible="visible"
    :width="'550px'"
    :footer="['cancel','confirm']"
    @close="
      $emit('close')
      popVisible = false
    "
  >

    <template slot="header">
      <div class="title">할인 조건 중복 안내</div>
      <p class="header-description">이미 적용된 할인과 중복 적용이 불가능합니다.<br />지금 선택하신 할인으로 변경하시겠습니까?</p>
    </template>
    <template slot="body">
      <div class="table-area nohead">
        <table class="noline">
          <colgroup>
            <col width="113px" />
            <col width="auto" />
            <col width="113px" />
          </colgroup>
          <tbody>
            <tr>
              <th class="bold">현재</th>
              <td class="left">웰컴 패밀리 (3대)</td>
              <td class="right">(-) <span>100,000</span>원</td>
            </tr>
            <tr>
              <th class="bold">변경</th>
              <td class="left">웰컴 패밀리 (4대이상)</td>
              <td class="right">(-) <span>100,000</span>원</td>
            </tr>
          </tbody>
        </table>
      </div>
    </template>
  </v-popup>
</template>

<script>
import { VPopup } from '~/components/element'
export default {
  components: {
    VPopup
  },
  props: {
    visible: {
      type: Boolean,
      default: false
    },
  },
  updated() {
    if (this.visible) {
      this.setCaption()
    }
  },
}
</script>