<template>
  <v-popup
    :visible="visible"
    :width="'776px'"
    :footer="['confirm']"
    @close="
      $emit('close')
      popVisible = false
    "
    @confirm="
      $emit('close')
      popVisible = false
    "
  >

    <template slot="header">
      <div class="title">경차 면세 안내</div>
      <div class="header-description">캐스퍼를 구입하시는 경우 경차 세금 혜택을 적용받아 차량 구입이 가능합니다.</div>
    </template>
    <template slot="body">
      <div class="table-area">
        <table>
          <colgroup>
            <col width="100px" />
            <col width="125px" />
            <col width="auto" />
          </colgroup>
          <thead>
            <tr>
              <th colspan="2" scope="col">세금 종류</th>
              <th scope="col">세부 내역</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <th rowspan="3" scope="row" class="t-gray">차량구매시</th>
              <th scope="row" class="t-gray">개별소비세</th>
              <td class="left"><strong>면제</strong></td>
            </tr>
            <tr>
              <th scope="row" class="t-gray">교육세</th>
              <td class="left"><strong>면제</strong></td>
            </tr>
            <tr>
              <th scope="row" class="t-gray">부가가치세</th>
              <td class="left">(공장도가격+개소세+고육세)의 10%</td>
            </tr>
            <tr>
              <th rowspan="2" scope="row" class="t-gray">차량등록시</th>
              <th scope="row" class="t-gray">취득세</th>
              <td class="left">(공장도가격+개소세+교육세) X <strong>4%</strong> 한 금액에서 50만원 공제</td>
            </tr>
            <tr>
              <th scope="row" class="t-gray">공채</th>
              <td class="left"><strong>면제</strong></td>
            </tr>
            <tr>
              <th rowspan="2" class="t-gray">소유시</th>
              <th scope="row" class="t-gray">자동차세</th>
              <td class="left"><strong>CC당 80원</strong></td>
            </tr>
            <tr>
              <th scope="row" class="t-gray">자동차교육세</th>
              <td class="left">자동차세액의 30%</td>
            </tr>
          </tbody>
        </table>
      </div>
    </template>
  </v-popup>
</template>

<script>
import { VPopup } from '~/components/element'
export default {
  components: {
    VPopup
  },
  props: {
    visible: {
      type: Boolean,
      default: false
    },
  },

  // 2021.03.17 (ver1.1)
  updated() {
    if (this.visible) {
      this.setCaption()
    }
  },

}
</script>