<template>
  <v-popup
    :visible="visible"
    :width="'776px'"
    :footer="['confirm']"
    @close="
      $emit('close')
      popVisible = false
    "
    @confirm="
      $emit('close')
      popVisible = false
    "
  >

    <template slot="header">
      <div class="title">블루멤버스 포인트 적립 예정 안내</div>
    </template>
    <template slot="body">
      <!-- 2021.03.31 (ver1.1) 텍스트 수정 start -->
      <p class="bullet">현대자동차 블루멤버스 멤버십에 가입하시면 현대자동차 또는 다양한 제휴처에서 차량 구입하거나 서비스 이용시 블루멤버스 포인트를 적립하고 사용할 수 있습니다.</p>
      <p class="contents-head">적립안내</p>
      <ul class="bullet-list">
        <li>대상 : 캐스퍼 구매 고객</li>
        <li>적립방법 : 현대 브랜드의 승용, RV, 소형상용<br />차량 구매가 구매 횟수에 따라 점율(0.7% ~ 3%)로 포인트를 적립</li>
      </ul>
      <!-- end -->
      <div class="table-area">
        <table>
          <colgroup>
            <col width="75px" />
            <col width="auto" />
            <col width="75px" />
            <col width="75px" />
            <col width="75px" />
            <col width="75px" />
            <col width="75px" />
            <col width="75px" />
          </colgroup>
          <thead>
            <tr>
              <th scope="col" colspan="2">구분</th>
              <th scope="col" colspan="7">구매횟수별 포인트 지급기준(%)</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <!-- 2021.03.31 (ver1.1) rowspan 4->3으로 수정 -->
              <th scope="row" rowspan="3" class="t-gray">개인회원</th>
              <th scope="row" rowspan="2" class="t-gray">일반회원<br />(개인/개인사업자)</th>
              <td>첫구매</td>
              <td>2회차</td>
              <td>3회차</td>
              <td>4회차</td>
              <td>5회차</td>
              <td>6회차</td>
            </tr>
            <tr>
              <td>0.7</td>
              <td>1.1</td>
              <td>1.5</td>
              <td>2.0</td>
              <td>2.5</td>
              <td>3.0</td>
            </tr>
            <!-- 2021.03.31 (ver1.1) 영역 삭제 -->
            <!-- <tr>
              <th scope="row" class="t-gray">개인택시</th>
              <td colspan="6">신규/재구매 0.7% 동일</td>
            </tr> -->
            <tr>
              <th scope="row" class="t-gray">렌트/리스<br />이용개인</th>
              <td colspan="6">신규/재구매 0.3% 동일</td>
            </tr>
            <tr>
              <th scope="row" class="t-gray">법인회원</th>
              <th scope="row" class="t-gray">일반 법인<br />렌트/리스사<br />렌트/리스<br />이용개인</th>
              <td colspan="6">신규/재구매 0.3% 동일</td>
            </tr>
          </tbody>
        </table>
        <small>(1포인트 = 1원)</small>
      </div>
    </template>
  </v-popup>
</template>

<script>
import { VPopup } from '~/components/element'
export default {
  components: {
    VPopup
  },
  props: {
    visible: {
      type: Boolean,
      default: false
    },
  },
  updated() {
    if (this.visible) {
      this.setCaption()
    }
  },
}
</script>