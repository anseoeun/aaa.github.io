<template>
  <div class="">
    <!-- 할부상품 선택 -->
    <instmnts-goods :pop-visible="visible" />
  </div>
</template>

<script>
import InstmntsGoods from '~/components/page/estimation/popup/InstmntsGoods'

export default {
  components: {
    InstmntsGoods
  },
  props: {
    visible: {
      type: Object,
      defualt: {},
      required: true
    }
  },
  data() {
    return {}
  },
  methods: {
    parentsSync(e) {
      this.visible = e
      this.$emit('visibleSync', this.visible)
    }
  }
}
</script>
