<template>
  <v-popup
    :visible="visible"
    :width="'550px'"
    :footer="['cancel','confirm']"
    @close="
      $emit('close')
      popVisible = false
    "
  >

    <!-- 2021.03.05 (ver1.1) -->
    <template slot="header">
      <div class="title">직원할인 재구매 제한 안내</div>
    </template>
    <template slot="body">
      <div class="text-main"><span>홍길동</span> 님은 최근 2년 내에 임직원 할인 적용 차량을 구매하셨기 때문에<br />재구매는 <em>2022년 9월 25일</em>(출고일 기준)부터 가능합니다.<br />계속 임직원 할인을 적용하여 견적을 하시겠습니까?</div>
    </template>
  </v-popup>
</template>

<script>
import { VPopup } from '~/components/element'
export default {
  components: {
    VPopup
  },
  props: {
    visible: {
      type: Boolean,
      default: false
    },
  },
}
</script>