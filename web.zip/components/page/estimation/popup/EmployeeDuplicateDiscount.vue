<template>
  <v-popup
    :visible="visible"
    :width="'550px'"
    :footer="['cancel', 'confirm']"
    @close="
      $emit('close')
      popVisible = false
    "
  >
    <template slot="header">
      <div class="title">직원할인 중복불가 안내</div>
      <!-- 2021.03.31 (ver1.1) 텍스트 수정 -->
      <p class="header-description">
        직원할인 적용 시 아래의 할인을 받으실 수 없습니다.<br />그래도 직원할인으로 변경하시겠습 니까?
      </p>
    </template>
    <template slot="body">
      <div class="table-area nohead">
        <table class="noline-in">
          <colgroup>
            <col width="50%" />
            <col width="50%" />
          </colgroup>
          <tbody>
            <tr>
              <th class="left">타겟조건명</th>
              <td class="right">(-) <span>100,000</span>원</td>
            </tr>
            <tr>
              <th class="left">쿠폰명</th>
              <td class="right">(-) <span>100,000</span>원</td>
            </tr>
          </tbody>
        </table>
      </div>
    </template>
  </v-popup>
</template>

<script>
import { VPopup } from '~/components/element'
export default {
  components: {
    VPopup
  },
  props: {
    visible: {
      type: Boolean,
      default: false
    }
  },
  updated() {
    if (this.visible) {
      this.setCaption()
    }
  }
}
</script>