<template>
  <section class="information-detail">
    <div class="summary-info" :class="{ active: isOptionsShow }">
      <h1 class="title">차량 정보</h1>
      <p class="summary-text">AX 스마트스트림 가솔린 1.1 터보 프리미엄 밀레니얼 A/T</p>
      <v-btn class="btn-more" type="nlink" to="/">변경</v-btn>
      <!-- 2021.03.31 (ver1.3) 텍스트 추가 -->
      <div class="total-price">차량금액<span class="price">100,000</span> 원</div>
      <v-btn
        class="btn-detail"
        type="icon"
        :icon-class="['icon-open', { active: isOptionsShow }]"
        @click="isOptionsShow = !isOptionsShow"
      >
        <span class="offscreen">상세보기</span>
      </v-btn>
    </div>
    <div v-show="isOptionsShow" class="detail-info" :class="{ active: isOptionsShow }">
      <div class="info-grid-list">
        <ul>
          <li>
            <div class="info-title">
              <strong>모델</strong>
              <!-- 2021.03.22 (ver1.1) 변경버튼 삭제 -->
              <!-- <v-btn class="btn-more" type="nlink" to="/">변경</v-btn> -->
            </div>
            <div class="info-group">
              <p>AX 스마트스트림 가솔린 1.1 터보 프리미엄 밀레니얼 A/T</p>
              <span class="price">100,000 원</span>
            </div>
          </li>
          <li>
            <div class="info-title">
              <strong>외장색상</strong>
              <!-- 2021.03.22 (ver1.1) 변경버튼 삭제 -->
              <!-- <v-btn class="btn-more" type="nlink" to="/">변경</v-btn> -->
            </div>
            <div class="info-group">
              <p>폴라화이트</p>
              <span class="price">100,000 원</span>
            </div>
          </li>
          <li>
            <div class="info-title">
              <strong>내장색상</strong>
              <!-- 2021.03.22 (ver1.1) 변경버튼 삭제 -->
              <!-- <v-btn class="btn-more" type="nlink" to="/">변경</v-btn> -->
            </div>
            <div class="info-group">
              <p>블랙모노톤(블랙시트)</p>
              <span class="price">100,000 원</span>
            </div>
          </li>
          <li>
            <div class="info-title">
              <strong>옵션</strong>
              <!-- 2021.03.22 (ver1.1) 변경버튼 삭제 -->
              <!-- <v-btn class="btn-more" type="nlink" to="/">변경</v-btn> -->
            </div>
            <div class="info-group">
              <ul v-if="optionData.length > 0" class="desc-list">
                <li v-for="(option, index) in optionData" :key="index">
                  <em>{{ option.name }}</em>
                  <ul>
                    <li v-for="(subopt, idx) in option.subOption" :key="idx">
                      <!-- 2021.03.31 (ver1.3) 팝업 -->
                      <!-- 일반 사양 팝업 -->
                      <template v-if="subopt.guide">
                        <v-btn @click="popVisible.specGuide = true">{{ subopt.name }}</v-btn>
                        <span class="price">{{ subopt.price }} 원</span>
                      </template>
                      <!-- 패키지 사양 팝업 -->
                      <template v-else>
                        <v-btn @click="popVisible.packageGuide = true">{{ subopt.name }}</v-btn>
                        <span class="price">{{ subopt.price }} 원</span>
                      </template>
                    </li>
                  </ul>
                </li>
              </ul>
              <!-- 2021.03.29 (ver1.2) 텍스트 수정 -->
              <p v-else class="no-data">추가 선택한 옵션이 없습니다.</p>
              <!-- 2021.03.29 (ver1.2) 추가 : 추후 항목보기(탐색) 팝업연결 예정 -->
              <div class="full"><v-btn class="btn-more">기본포함 품목보기</v-btn></div>
            </div>
          </li>
        </ul>
      </div>
    </div>

    <!-- 2021.03.31 (ver1.3) 팝업 추가 -->
    <spec-guide :pop-visible="popVisible" @close="popVisible.specGuide = false" />
    <package-guide :pop-visible="popVisible" @close="popVisible.packageGuide = false" />

  </section>
</template>

<script>
import SpecGuide from '~/components/page/vehicles/popup/SpecGuide'
import PackageGuide from '~/components/page/vehicles/popup/PackageGuide'
export default {
  components: {
    SpecGuide,
    PackageGuide,
  },
  data() {
    return {
      isOptionsShow: false,
      optionData: [
        {
          name: '옵션',
          subOption: [
            { name: '옵션명', guide: true, price: '100,000' },
            { name: '옵션명', guide: false, price: '100,000' }
          ]
        },
        {
          name: 'H Genuine Accessories',
          subOption: [
            { name: '옵션명', guide: true, price: '100,000' },
            { name: '옵션명', guide: false, price: '100,000' },
            { name: '옵션명', guide: false, price: '100,000' }
          ]
        },
        { name: 'N Performance', subOption: [{ name: '옵션명', price: '100,000' }] }
      ],

      // 2021.03.31 (ver1.3) 팝업 추가
      popVisible: {
        specGuide: false,
        packageGuide: false
      },
    }
  }
}
</script>
