<template>
  <section class="information-detail">
    <div class="summary-info">
      <!-- 2021.03.22 (ver1.1) 텍스트 수정 -->
      <h1 class="title">
        면세 조건
        <v-btn class="btn-info" type="icon" icon-class="icon-info" @click="popTaxFree = true"
          ><span class="offscreen">면세구분안내팝업보기</span></v-btn
        >
      </h1>
      <div class="detail-info tax-registation">
        <div class="info-grid-list">
          <ul>
            <!-- 2021.03.22 (ver1.1) 추가 -->
            <li>
              <strong class="info-title full">경차</strong>
              <div class="info-group full">
                <p class="bullet">
                  경차는 개별소비세 비과세 대상으로, 캐스퍼의 차량가에는 개별소비세가 면제되어 있습니다.
                </p>
              </div>
            </li>
            <!-- 2021.03.22 (ver1.1) 수정 -->
            <li>
              <div class="info-title full">
                <v-select v-model="taxSelect" :data="taxSelectList" placeholder="선택하세요" />
                <v-checkbox v-model="taxCheck" :data="taxCheckList" class="ct" />
              </div>
              <div class="info-group full">
                <p class="bullet">
                  면세구분 선택에 따라 개별소비세 과세/면세가 계산되어 차량 총 견적 금액에 적용됩니다.
                </p>
              </div>
            </li>
          </ul>
        </div>
      </div>
    </div>

    <!-- 팝업 -->
    <tax-free :visible="popTaxFree" @close="popTaxFree = false" />
  </section>
</template>

<script>
import TaxFree from '~/components/page/estimation/popup/TaxFree'
export default {
  components: {
    TaxFree
  },
  data() {
    return {
      taxCheck: '',
      taxCheckList: [
        { value: 'check1', label: '다자녀(19세 미만 3인 이상)' }
        // { value: 'check2', label: '노후 경유차 감면 대상' },
      ],
      taxSelect: 'city0',
      taxSelectList: [{ value: 'city0', label: '일반인' }],
      popTaxFree: false
    }
  }
}
</script>
