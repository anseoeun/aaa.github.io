<template>
  <section class="information-detail">
    <div class="summary-info" :class="{ active: isOptionsShow }">
      <h1 class="title">등록비 정보</h1>
      <!-- 2021.03.22 (ver1.1) 클래스 수정 -->
      <!-- 2021.03.29 (ver1.2) 텍스트 수정  -->
      <p class="info-text">(별도 납부)</p>
      <div class="total-price"><span class="price">100,000</span> 원</div>
      <v-btn
        class="btn-detail"
        type="icon"
        :icon-class="['icon-open', { active: isOptionsShow }]"
        @click="isOptionsShow = !isOptionsShow"
      >
        <span class="offscreen">상세보기</span>
      </v-btn>
    </div>
    <div v-show="isOptionsShow" class="detail-info">
      <div class="info-grid-list">
        <ul>
          <!-- 2021.03.29 (ver1.2) 면세구분 추가 start -->
          <li>
            <div class="info-title">
              <strong>면세구분</strong>
              <v-btn class="btn-info" type="icon" icon-class="icon-info" @click="popTaxFree = true"
                ><span class="offscreen">면세구분안내팝업보기</span></v-btn
              >
            </div>
            <div class="info-group">
              <v-select v-model="taxSelect" :data="taxSelectList" placeholder="선택하세요" />
              <v-checkbox v-model="taxCheck" :data="taxCheckList" class="ct" />
            </div>
          </li>
          <!-- end -->

          <li>
            <div class="info-title">
              <strong>취득세</strong>
              <v-btn class="btn-info" type="icon" icon-class="icon-info" @click="popVisible.infoAcquirement = true"
                ><span class="offscreen">취득세안내팝업보기</span></v-btn
              >
            </div>
            <div class="info-group">
              <span class="price">100,000 원</span>
            </div>
          </li>
          <li class="bond">
            <div class="info-title ct">
              <strong>공채</strong>
              <v-btn class="btn-info" type="icon" icon-class="icon-info" @click="popVisible.infoFund = true"
                ><span class="offscreen">공채안내팝업보기</span></v-btn
              >
            </div>
            <div class="info-group">
              <v-select v-model="costSelcet" :data="costSelcetList" placeholder="선택하세요" />
              <v-radio v-model="costRadio" :data="costRadioList" />
              <span class="price ct">100,000 원</span>
            </div>
          </li>
          <li>
            <strong class="info-title">증지대(수입인지)</strong>
            <div class="info-group">
              <!-- 2021.03.22 (ver1.1) ct 클래스 제거 -->
              <span class="price">100,000 원</span>
            </div>
          </li>
          <li>
            <strong class="info-title">차량번호판</strong>
            <div class="info-group">
              <span class="price">100,000 원</span>
            </div>
          </li>
          <li>
            <strong class="info-title">등록 대행 수수료</strong>
            <div class="info-group">
              <span class="price">100,000 원</span>
            </div>
          </li>
        </ul>
        <ul class="bullet-list">
          <li>등록비는 견적금액에 포함되지 않습니다.</li>
          <li>공채 할인금액은 지자체별 할인율이 매일 변동됨에 따라 실제와 다소 차이가 있을 수 있습니다.</li>
          <li>차량번호판과 등록대행수수료는 지역별로 차이가 있으므로 단순 참고만 하시기 바랍니다.</li>
        </ul>
      </div>
    </div>

    <!-- 팝업 -->
    <info-acquirement :pop-visible="popVisible" @close="popVisible.infoAcquirement = false" />
    <info-fund :pop-visible="popVisible" @close="popVisible.infoFund = false" />

    <!-- 2021.03.29 (ver1.2) 팝업 추가 -->
    <tax-free :visible="popTaxFree" @close="popTaxFree = false" />
  </section>
</template>

<script>
import InfoAcquirement from '~/components/page/payment/popup/InfoAcquirement'
import InfoFund from '~/components/page/payment/popup/InfoFund'
// 2021.03.29 (ver1.2) 팝업 추가
import TaxFree from '~/components/page/estimation/popup/TaxFree'
export default {
  components: {
    InfoAcquirement,
    InfoFund,
    // 2021.03.29 (ver1.2) 팝업 추가
    TaxFree
  },
  data() {
    return {
      isOptionsShow: false,
      costSelcet: '',
      costSelcetList: [{ value: '01', label: '일반인' }],
      costRadio: '',
      costRadioList: [
        { value: '01', label: '할인' },
        { value: '02', label: '매입' }
      ],
      popVisible: {
        infoAcquirement: false,
        infoFund: false
      },

      // 2021.03.29 (ver1.2) 추가
      popTaxFree: false,
      taxCheck: '',
      taxCheckList: [
        { value: 'check1', label: '다자녀(19세 미만 3인 이상)' }
        // { value: 'check2', label: '노후 경유차 감면 대상' },
      ],
      taxSelect: 'city0',
      taxSelectList: [{ value: 'city0', label: '일반인' }]
    }
  }
}
</script>
