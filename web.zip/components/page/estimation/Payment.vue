<template>
  <section class="information-detail">
    <div class="summary-info">
      <h1 class="title">결제 수단</h1>
      <p class="summary-text">(견적금액+단기의무보험료)</p>
      <!-- 2021.03.31 (ver1.3) 텍스트 수정 -->
      <div class="total-price">총 차량 구입금액 <span class="price">30,472,300</span> 원</div>
    </div>
    <div class="detail-info payment">
      <!-- 2021.03.22 (ver1.1) 전체적인 구조 수정 -->
      <v-tab class="tab-default square" :data="tabList" :contents="true" :custom-label="true">
        <template slot="label" slot-scope="props">
          {{ props.item.label }}
          <span v-if="isNan(props.item.html)" v-html="props.item.html"></span>
        </template>
        <template slot="contents">
          <!-- 할부 -->
          <div data-id="tab1">
            <div class="info-grid-list">
              <ul>
                <li>
                  <div class="info-title full">
                    <strong>할부상품</strong>
                    <em class="product bold">표준형</em>
                    <v-btn class="btn-more" @click="popVisible.installmentProducts = true">할부조건 변경</v-btn>
                  </div>
                </li>
                <li>
                  <div class="info-title full">
                    <strong>월 납입금액</strong>
                    <span class="price bold">월 289,959 원</span>
                  </div>
                  <div class="info-group full">
                    <ul class="desc-list">
                      <li>
                        <em>할부원금</em>
                        <span class="price">2,000,000 원</span>
                      </li>
                      <li>
                        <em>할부기간</em>
                        <span class="last">36개월</span>
                      </li>
                      <li>
                        <em>금리</em>
                        <span class="last">4.5%</span>
                      </li>
                    </ul>
                  </div>
                </li>
                <li>
                  <div class="info-title full">
                    <!-- 2021.03.31 (ver1.3) 텍스트 수정 -->
                    <strong>출고 전 납입 금액</strong>
                    <!-- 2021.03.31 (ver1.3) 텍스트 추가 -->
                    <em>a+b+c-d</em>
                    <span class="price bold">10,472,300 원</span>
                  </div>
                  <div class="info-group full">
                    <!-- 2021.03.31 (ver1.3) 텍스트 수정 start -->
                    <ul class="desc-list">
                      <li>
                        <em>차량 구입금액 (a)</em>
                        <span class="price">100,000 원</span>
                      </li>
                      <li>
                        <em>임시운행 의무보험료 (b)</em>
                        <span class="price">100,000 원</span>
                      </li>
                      <li>
                        <em>할부인지대 (c)</em>
                        <span class="price">100,000 원</span>
                      </li>
                      <li>
                        <em>할부원금 (d)</em>
                        <span class="price">100,000 원</span>
                      </li>
                    </ul>
                    <!-- end -->
                  </div>
                </li>
              </ul>

              <!-- 임직원 -->
              <!-- <ul>
                <li>
                  <div class="info-title full">
                    <strong>할부상품</strong>
                    <em class="product bold">임직원무이자+표준형</em>
                    <v-btn class="btn-more" @click="popVisible.installmentProducts = true">할부조건 변경</v-btn>
                  </div>
                </li>
                <li>
                  <div class="info-title full">
                    <strong>월 납입금액</strong>
                    <p>A. 표준형</p>
                    <span class="price bold">월 289,959 원</span>
                  </div>
                  <div class="info-group full">
                    <ul class="desc-list">
                      <li>
                        <em>할부원금</em>
                        <span class="price">2,000,000 원</span>
                      </li>
                      <li>
                        <em>할부기간</em>
                        <span class="last">36개월</span>
                      </li>
                      <li>
                        <em>금리</em>
                        <span class="last">4.5%</span>
                      </li>
                    </ul>
                  </div>
                </li>
                <li>
                  <div class="info-title full">
                    <strong></strong>
                    <p>B. 무이자</p>
                    <span class="price bold">월 289,959 원</span>
                  </div>
                  <div class="info-group full">
                    <ul class="desc-list">
                      <li>
                        <em>할부원금</em>
                        <span class="price">2,000,000 원</span>
                      </li>
                      <li>
                        <em>할부기간</em>
                        <span class="last">36개월</span>
                      </li>
                      <li>
                        <em>금리</em>
                        <span class="last">4.5%</span>
                      </li>
                    </ul>
                  </div>
                </li>
              </ul> -->
            </div>
            <div class="info-text">
              <span class="bullet">할부 한도 조회를 통해 나의 정확한 할부 이용 가능 금액을 알아보세요.</span>
              <v-btn type="link" class="btn-more" target="_blank" title="새창열기">내 할부한도 조회</v-btn>
            </div>
          </div>
          <!-- PLCC 카드 -->
          <div data-id="tab2">
            <div class="info-grid-list">
              <ul>
                <li class="benefit-type">
                  <strong class="info-title">제휴혜택</strong>
                  <div class="info-group">
                    <ul class="desc-list">
                      <li>
                        <em>혜택유형</em>
                        <ul>
                          <li class="radio-round-button">
                            <div class="el-radio-group">
                              <v-radio v-model="benefitType" :one-check="true" label="1" type="button"
                                >포인트형</v-radio
                              >
                              <v-radio v-model="benefitType" :one-check="true" label="2" type="button"
                                >캐시백형</v-radio
                              >
                              <v-radio v-model="benefitType" :one-check="true" label="3" type="button"
                                >무이자할부형</v-radio
                              >
                            </div>
                          </li>
                          <li>
                            <!-- 포인트형 -->
                            <div v-if="benefitType === '1'" class="benefit-type-cont">
                              <div>
                                <!-- 2021.03.31 (ver1.3) 텍스트 수정 -->
                                <span class="bullet-star">블루멤버스 모빌리티 신용카드 결제 시 최대 1.5% 적립</span>
                                <!-- 2021.03.31 (ver1.3) 텍스트 수정, 추가 -->
                                <div class="full">
                                  <v-btn class="btn-more">자세히 보기</v-btn>
                                  <v-btn class="btn-more">발급 신청</v-btn>
                                </div>
                              </div>
                              <div>
                                <span>적립예상포인트</span>
                                <span class="last">블루멤버스 포인트 최대 425,000 적립</span>
                                <v-popover trigger="hover" placement="bottom-start">
                                  <p>
                                    최대 적립률 기준입니다. (일시불 1.5%)<br />※ 적립기준 및 적립률은 카드 유형과 결제
                                    시 결제금액에 따라 달라질 수 있습니다.
                                  </p>
                                  <v-btn slot="reference"><i class="icon-help"></i></v-btn>
                                </v-popover>
                              </div>
                            </div>
                            <!-- 캐시백형 -->
                            <div v-if="benefitType === '2'" class="benefit-type-cont">
                              <div>
                                <!-- 2021.03.31 (ver1.3) 텍스트 수정 -->
                                <span class="bullet-star">블루멤버스 모빌리티 신용카드 결제 시 최대 1.2% 캐시백</span>
                                <!-- 2021.03.31 (ver1.3) 텍스트 수정, 추가 -->
                                <div class="full">
                                  <v-btn class="btn-more">자세히 보기</v-btn>
                                  <v-btn class="btn-more">발급 신청</v-btn>
                                </div>
                              </div>
                              <div>
                                <span>캐시백 예상금액</span>
                                <span class="last">최대 500,000 캐시백</span>
                                <v-popover trigger="hover" placement="bottom-start">
                                  <p>
                                    최대 혜택 금액 기준입니다. (일시불 1.2%)<br />※ 캐시백 지급율은 결제 시 결제금액,
                                    신규고객 여부에 따라 달라질 수 있습니다.
                                  </p>
                                  <v-btn slot="reference"><i class="icon-help"></i></v-btn>
                                </v-popover>
                              </div>
                            </div>
                            <!-- 무이자할부형 -->
                            <div v-if="benefitType === '3'" class="benefit-type-cont">
                              <div>
                                <ul class="bullet-star-list">
                                  <li>2/3/6/12개월 무이자할부 서비스 혜택입니다.</li>
                                  <li>단, 포인트 및 캐시백이 지급되지 않습니다.</li>
                                </ul>
                                <!-- 2021.03.31 (ver1.3) 텍스트 수정, 추가 -->
                                <div class="full">
                                  <v-btn class="btn-more">자세히 보기</v-btn>
                                  <v-btn class="btn-more">발급 신청</v-btn>
                                </div>
                              </div>
                            </div>
                          </li>
                        </ul>
                      </li>
                    </ul>
                  </div>
                </li>
                <li>
                  <div class="info-title full">
                    <!-- 2021.03.31 (ver1.3) 텍스트 수정 -->
                    <strong>출고 전 납입 금액</strong>
                    <!-- 2021.03.31 (ver1.3) 텍스트 추가 -->
                    <em>a+b</em>
                    <span class="price bold">10,472,300 원</span>
                  </div>
                  <div class="info-group full">
                    <!-- 2021.03.31 (ver1.3) 텍스트 수정 start -->
                    <ul class="desc-list">
                      <li>
                        <em>차량 구입금액 (a)</em>
                        <span class="price">100,000 원</span>
                      </li>
                      <li>
                        <em>임시운행 의무보험료 (b)</em>
                        <span class="price">100,000 원</span>
                      </li>
                    </ul>
                    <!-- end -->
                  </div>
                </li>
              </ul>
            </div>
          </div>
          <!-- 현금/신용카드 -->
          <div data-id="tab3">
            <div class="info-grid-list">
              <ul>
                <li>
                  <div class="info-title full">
                    <!-- 2021.03.31 (ver1.3) 텍스트 수정 -->
                    <strong>출고 전 납입 금액</strong>
                    <span class="price bold">10,472,300 원</span>
                  </div>
                  <div class="info-group full">
                    <!-- 2021.03.31 (ver1.3) 텍스트 수정 start -->
                    <ul class="desc-list">
                      <li>
                        <em>차량 구입금액 (a)</em>
                        <span class="price">100,000 원</span>
                      </li>
                      <li>
                        <em>임시운행 의무보험료 (b)</em>
                        <span class="price">100,000 원</span>
                      </li>
                    </ul>
                    <!-- end -->
                  </div>
                </li>
              </ul>
            </div>
          </div>
        </template>
      </v-tab>
    </div>

    <!-- 2021.03.22 (ver1.1) 팝업 추가 -->
    <installment-products :pop-visible="popVisible" @close="popVisible.installmentProducts = false" />
  </section>
</template>

<script>
import InstallmentProducts from '~/components/page/payment/popup/InstallmentProducts'
export default {
  components: {
    InstallmentProducts
  },
  data() {
    return {
      isOptionsShow: true,
      // 2021.03.22 (ver1.1) 탭수정, 추가
      // tabList: [
      //   { value: 'tab1', label: '할부 월 100,000 원 ~' },
      //   { value: 'tab2', label: 'PLCC 카드<br /><span>최대 500,000원 캐시백</span>' },
      //   { value: 'tab3', label: '현금/신용카드' },
      // ],
      tabList: [
        { value: 'tab1', label: '할부', html: '월 100,000 원 ~' },
        // 2021.03.31 (ver1.3) 텍스트 수정
        { value: 'tab2', label: '블루멤버스 모빌리티 신용카드', html: '<span>최대 500,000원 캐시백</span>' },
        { value: 'tab3', label: '현금/신용카드' }
      ],
      benefitType: '2',
      popVisible: {
        installmentProducts: false
      }
    }
  },
  // 2021.03.22 (ver1.1) 추가
  methods: {
    isNan(val) {
      return val != undefined && val != null && val != '' ? true : false
    }
  }
}
</script>
