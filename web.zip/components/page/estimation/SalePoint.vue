<template>
  <section class="information-detail">
    <div class="summary-info" :class="{ active: isOptionsShow }">
      <h1 class="title">할인/포인트</h1>
      <!-- 2021.03.31 (ver1.3) 텍스트 추가 -->
      <div class="total-price">할인/포인트<span class="price">(-) 500,000</span> 원</div>
      <v-btn
        class="btn-detail"
        type="icon"
        :icon-class="['icon-open', { active: isOptionsShow }]"
        @click="isOptionsShow = !isOptionsShow"
        ><span class="offscreen">상세보기</span></v-btn
      >
    </div>
    <div v-show="isOptionsShow" class="detail-info sale-point">
      <div class="info-grid-list">
        <ul>
          <!-- 직원할인 -->
          <li>
            <div class="info-title full">
              <strong class="bold">직원할인</strong>
              <v-btn class="btn-info" type="icon" icon-class="icon-info" @click="popEmployeeInfo = true"
                ><span class="offscreen">직원할인안내팝업보기</span></v-btn
              >
              <v-checkbox :one-check="true" :checked.sync="checkboxEmployee">직원할인 적용</v-checkbox>
            </div>
            <div class="info-group full">
              <ul class="desc-list">
                <li>
                  <em>직원할인</em>
                  <span class="price">(-) 100,000 원</span>
                </li>
                <li>
                  <em>직원선택할인</em>
                  <ul>
                    <li>
                      <el-radio v-model="radioEmployee" label="선택안함"></el-radio>
                    </li>
                    <li>
                      <el-radio v-model="radioEmployee" label="일시불 3% 할인"></el-radio>
                      <span class="price">(-) 900,000 원</span>
                    </li>
                    <li>
                      <el-radio v-model="radioEmployee" label="임직원 무이자"></el-radio>
                      <!-- 2021.03.29 (ver1.2) 텍스트 수정 -->
                      <span class="last">30개월 1천만원 무이자</span>
                    </li>
                  </ul>
                </li>
              </ul>
            </div>
          </li>
          <!-- 일반할인 -->
          <li>
            <strong class="info-title bold">일반할인</strong>
            <div class="info-group full">
              <ul class="desc-list">
                <li>
                  <em>차량할인</em>
                  <ul>
                    <li>
                      <em>기본할인</em>
                      <span class="price">(-) 0 원</span>
                    </li>
                    <li>
                      <em>기본할인</em>
                      <ul>
                        <li>
                          <el-radio v-model="radioSale" label="금액할인"></el-radio>
                          <span class="price">(-) 900,000 원</span>
                        </li>
                        <li>
                          <el-radio v-model="radioSale" label="금리할인 (뉴스타 페스타 프로모션)"></el-radio>
                          <v-btn class="btn-info" type="icon" icon-class="icon-info" @click="popDiscountInfo = true"
                            ><span class="offscreen">안내팝업보기</span></v-btn
                          >
                          <!-- 2021.03.22 (ver1.1) 클래스, 텍스트 수정 -->
                          <span class="last">(표준형) 금리 1.5%</span>
                        </li>
                        <li>
                          <el-radio v-model="radioSale" label="금리할인 (금융상품명)"></el-radio>
                          <v-btn class="btn-info" type="icon" icon-class="icon-info" @click="popDiscountInfo = true"
                            ><span class="offscreen">안내팝업보기</span></v-btn
                          >
                          <!-- 2021.03.22 (ver1.1) 클래스, 텍스트 수정 -->
                          <span class="last">(거치형) 금리 1.5%</span>
                        </li>
                      </ul>
                    </li>
                    <!-- 2021.03.29 (ver1.2) 삭제 -->
                    <!-- <li>
                      <em>생산월할인</em>
                      <span class="price">(-) 0 원</span>
                    </li>
                    <li>
                      <em>특별재고할인</em>
                      <span class="price">(-) 0 원</span>
                    </li>
                    <li>
                      <em>전시할인</em>
                      <span class="price">(-) 0 원</span>
                    </li>
                    <li>
                      <em>판촉할인</em>
                      <span class="price">(-) 0 원</span>
                    </li> -->

                    <!-- 2021.03.29 (ver1.2) 추가 -->
                    <li>
                      <em>기획전 할인</em>
                      <span class="price">(-) 0 원</span>
                    </li>
                  </ul>
                </li>
                <li>
                  <!-- 2021.03.22 (ver1.1) 텍스트 수정 -->
                  <em>타겟조건할인</em>
                  <ul>
                    <li v-for="(condition, index) in conditionData" :key="index">
                      <v-checkbox :one-check="true" :checked.sync="condition.conditionCheck">{{
                        condition.conditionName
                      }}</v-checkbox>
                      <v-btn class="btn-info" type="icon" icon-class="icon-info" @click="popCondition = true"
                        ><span class="offscreen">안내팝업보기</span></v-btn
                      >
                      <!-- 2021.03.22 (ver1.1) active 추가 -->
                      <span class="price" :class="{ active: condition.conditionCheck }"
                        >(-) {{ condition.conditionPrice }} 원</span
                      >
                    </li>
                  </ul>
                </li>
                <li>
                  <em>지인추천할인</em>
                  <span class="price">(-) 0 원</span>
                </li>
              </ul>
            </div>
          </li>
          <!-- 쿠폰할인 -->
          <li>
            <div class="info-title full">
              <strong class="bold">쿠폰할인</strong>
              <!-- 2021.03.31 (ver1.3) 버튼 추가, 수정 -->
              <div class="last">
                <v-btn class="btn-more">쿠폰받기</v-btn>
                <v-btn class="btn-more" @click="popCouponRegistration = true">쿠폰등록</v-btn>
              </div>
            </div>
            <div class="info-group full">
              <ul class="desc-list">
                <li>
                  <em>사용 가능 쿠폰</em>
                  <ul v-if="couponData.length > 0">
                    <li v-for="(coupon, index) in couponData" :key="index">
                      <!-- 2021.03.29 (ver1.2) 쿠폰유효기간 추가 -->
                      <v-checkbox :one-check="true" :checked.sync="coupon.couponCheck"
                        >{{ coupon.couponName }} (~ {{ coupon.couponDate }})</v-checkbox
                      >
                      <v-btn class="btn-info" type="icon" icon-class="icon-info" @click="popCoupon = true"
                        ><span class="offscreen">안내팝업보기</span></v-btn
                      >
                      <!-- 2021.03.22 (ver1.1) active 추가 -->
                      <span class="price" :class="{ active: coupon.couponCheck }">(-) {{ coupon.couponPrice }} 원</span>
                    </li>
                  </ul>
                  <div v-else>
                    <p>사용가능한 쿠폰이 없습니다.</p>
                    <p>
                      로그인 후 쿠폰할인 적용 견적을 낼 수 있습니다.
                      <v-btn class="btn-more" type="nlink" to="/">로그인하기</v-btn>
                    </p>
                  </div>
                </li>
              </ul>
            </div>
          </li>
          <!-- 포인트사용 -->
          <li>
            <strong class="info-title bold">포인트 사용</strong>
            <div class="info-group full">
              <ul class="desc-list">
                <li>
                  <!-- 2021.03.29 (ver1.2) 클래스 수정 -->
                  <div class="point-title">
                    세이브-오토<v-btn
                      class="btn-info"
                      type="icon"
                      icon-class="icon-info"
                      @click="popVisible.saveAutoGuide = true"
                      ><span class="offscreen">안내팝업보기</span></v-btn
                    >
                  </div>
                  <ul>
                    <li>
                      <v-checkbox :one-check="true" :checked.sync="saveCheck">세이브-오토 30만</v-checkbox>
                      <span>(현대카드M 10만원 이상 결제 조건)</span>
                      <span class="price">(-) 0 원</span>
                      <!-- 2021.03.31 (ver1.3) 버튼 추가 -->
                      <div class="full"><v-btn class="btn-more">세이브-오토 상환 계산기</v-btn></div>
                    </li>
                    <li>
                      <v-checkbox :one-check="true" :checked.sync="saveCheck"></v-checkbox>
                      <v-select v-model="saveAuto" :data="saveAutoSelect" />
                      <span>(현대카드M 10만원 이상 결제 조건)</span>
                      <span class="price">(-) 0 원</span>
                      <!-- 2021.03.31 (ver1.3) 버튼 추가 -->
                      <div class="full"><v-btn class="btn-more">세이브-오토 상환 계산기</v-btn></div>
                    </li>
                  </ul>
                </li>
                <li>
                  <!-- 2021.03.29 (ver1.2) 수정, 버튼 추가 -->
                  <div class="point-title">
                    M포인트<v-btn class="btn-info" type="icon" icon-class="icon-info" @click="popMPoint = true"
                      ><span class="offscreen">안내팝업보기</span></v-btn
                    >
                  </div>
                  <ul>
                    <li>
                      <!-- 2021.03.29 (ver1.2) last 클래스 추가 -->
                      <v-btn class="btn-more last">포인트 조회</v-btn>
                      <!-- 2021.03.22 (ver1.1) 수정 -->
                      <!-- 2021.03.29 (ver1.2) 삭제 -->
                      <!-- <div class="price label-input">
                        <label class="offscreen">포인트 입력</label>
                        <v-input v-model="mPointModel" disabled class="ip-suffix point"><i slot="suffix">P</i></v-input>
                      </div> -->
                    </li>
                    <li>
                      <!-- 2021.03.22 (ver1.1) 수정 -->
                      <div class="point-use">
                        사용 가능 1000P<span class="my-point">보유 1400P</span><v-btn class="btn-more">전액사용</v-btn>
                      </div>
                      <!-- 2021.03.22 (ver1.1) 수정 -->
                      <div class="price label-input">
                        <label class="offscreen">포인트 입력</label>
                        <v-input v-model="mPointModel" class="ip-suffix point"><i slot="suffix">P</i></v-input>
                      </div>
                    </li>
                  </ul>
                </li>
                <li>
                  <!-- 2021.03.29 (ver1.2) 수정, 버튼 추가 -->
                  <div class="point-title">
                    블루멤버스 포인트<v-btn
                      class="btn-info"
                      type="icon"
                      icon-class="icon-info"
                      @click="popBluemembersPoint = true"
                      ><span class="offscreen">안내팝업보기</span></v-btn
                    >
                  </div>

                  <ul>
                    <li>
                      <v-btn class="btn-more last">포인트 조회</v-btn>
                      <!-- 2021.03.22 (ver1.1) 수정 -->
                      <!-- <div class="price label-input">
                        <label class="offscreen">포인트 입력</label>
                        <v-input v-model="bPoint" disabled class="ip-suffix point"><i slot="suffix">P</i></v-input>
                      </div> -->
                    </li>
                    <li>
                      <!-- 2021.03.22 (ver1.1) 수정 -->
                      <div class="point-use">
                        사용 가능 1000P<span class="my-point">보유 1400P</span><v-btn class="btn-more">전액사용</v-btn>
                      </div>
                      <div class="price label-input">
                        <label class="offscreen">포인트 입력</label>
                        <v-input v-model="bPoint" class="ip-suffix point"><i slot="suffix">P</i></v-input>
                      </div>
                    </li>
                  </ul>
                </li>
                <!-- 2021.03.22 (ver1.1) 위치 이동 -->
                <!-- <li>
                  <em>블루멤버스 포인트<br />선사용</em>
                  <v-checkbox :one-check="true" :checked.sync="checkBlue">적립 예정 포인트 선사용</v-checkbox>
                  <span class="last">(-) 40,000 P</span>
                </li> -->
              </ul>
            </div>
            <ul class="bullet-list">
              <li>상기 할인율 및 할인 조건은 현재 시점을 기준으로 적용된 사항입니다.</li>
              <li>실제 해당 차량 구매 시의 할인 금액은 계약 시전에 따라 변경될 수 있습니다.</li>
              <!-- 2021.03.29 (ver1.2) 텍스트 수정 -->
              <li>
                현대자동차 그룹사/관계사 직원분들은 마이페이지에서 직원 인증을 하시면 직원 할인가로 견적을 내보실 수
                있습니다.
              </li>
            </ul>
          </li>
          <!-- 블루멤버스 적립 예정 포인트 -->
          <li>
            <div class="info-title full">
              <strong class="bold">블루멤버스 적립 예정 포인트</strong>
              <v-btn class="btn-info" type="icon" icon-class="icon-info" @click="popBluemembers = true"
                ><span class="offscreen">안내팝업보기</span></v-btn
              >
            </div>
            <div class="info-group full">
              <ul class="desc-list">
                <li>
                  <em>구매횟수</em>
                  <p>차량 구매 1회차</p>
                </li>
                <li>
                  <em class="ct">구매횟수</em>
                  <v-select v-model="bpointNumber" :data="bpointNumberList" />
                </li>
                <li>
                  <em>적립 예정 포인트</em>
                  <!-- 2021.03.22 (ver1.1) 추가 -->
                  <ul>
                    <li>40,000 P</li>
                    <li>
                      <v-checkbox :one-check="true" :checked.sync="checkBlue">적립 예정 포인트 선사용</v-checkbox>
                      <span class="last">(-) 100,000 원</span>
                    </li>
                  </ul>
                </li>
              </ul>
            </div>
            <ul class="bullet-list">
              <li>구매회차 1회(금번 구매회차 포함)로 차량판매가의 3%의 포인트가 적립됩니다.</li>
              <li>직원할인 적용 시에는 차량구매가의 0.3%가 일괄적용됩니다.</li>
              <li>차량판매가 = (차종 + 색상 + 내장 + 옵션 + H Genuine Accessories) - 할인금액</li>
              <li>과세 공동명의, 영업용(택시), 상용, 렌트리스 구입은 구매횟수에 포함되지 않습니다.</li>
              <li>블루멤버스 포인트는 최대 200만 포인트까지 적립됩니다.</li>
            </ul>
          </li>
        </ul>
      </div>
    </div>

    <!-- 팝업 -->
    <employee-discount :visible="popEmployeeInfo" @close="popEmployeeInfo = false" />
    <discount-conditions :visible="popCondition" @close="popCondition = false" />
    <blue-members-point-guide :visible="popBluemembers" @close="popBluemembers = false" />
    <coupon-registration :visible="popCouponRegistration" @close="popCouponRegistration = false" />
    <save-auto-guide :pop-visible="popVisible" @close="popVisible.saveAutoGuide = false" />

    <!-- 2021.03.29 (ver1.2) 팝업 추가 -->
    <m-point :visible="popMPoint" @close="popVisible.popMPoint = false" />
    <blue-members-point :visible="popBluemembersPoint" @close="popBluemembersPoint = false" />
  </section>
</template>

<script>
import EmployeeDiscount from '~/components/page/estimation/popup/EmployeeDiscount'
import DiscountConditions from '~/components/page/estimation/popup/DiscountConditions'
import BlueMembersPointGuide from '~/components/page/estimation/popup/BlueMembersPointGuide'
import CouponRegistration from '~/components/page/estimation/popup/CouponRegistration'
import SaveAutoGuide from '~/components/page/payment/popup/SaveAutoGuide'
// 2021.03.29 (ver1.2) 팝업 추가
import MPoint from '~/components/page/estimation/popup/MPoint'
import BlueMembersPoint from '~/components/page/estimation/popup/BlueMembersPoint'
export default {
  components: {
    EmployeeDiscount,
    DiscountConditions,
    BlueMembersPointGuide,
    CouponRegistration,
    SaveAutoGuide,
    // 2021.03.29 (ver1.2) 팝업 추가
    MPoint,
    BlueMembersPoint
  },
  data() {
    return {
      isOptionsShow: false,
      checkboxEmployee: false,
      radioEmployee: '',
      radioSale: '',
      conditionData: [
        { conditionCheck: false, conditionName: '웰컴 H패밀리(2대)', conditionPrice: '100,000', popCondition: '' },
        { conditionCheck: false, conditionName: '타켓조건명', conditionPrice: '100,000', popCondition: '' },
        { conditionCheck: false, conditionName: '타켓조건명', conditionPrice: '100,000', popCondition: '' }
      ],
      couponData: [
        { couponCheck: false, couponName: '쿠폰명', couponDate: '21.03.31', couponPrice: '100,000', popCoupon: '' },
        { couponCheck: false, couponName: '쿠폰명', couponDate: '21.04.15', couponPrice: '100,000', popCoupon: '' },
        { couponCheck: false, couponName: '쿠폰명', couponDate: '20.05.20', couponPrice: '100,000', popCoupon: '' }
      ],
      saveCheck: '',
      saveAuto: 'save1',
      saveAutoSelect: [{ value: 'save1', label: '세이브 오토 50만' }],
      mPointModel: '',
      bPoint: '',
      checkBlue: false,
      bpointNumber: 'check1',
      bpointNumberList: [{ value: 'check1', label: '차량 구매 5회차' }],
      // 팝업
      popEmployeeInfo: false,
      popCondition: false,
      popCouponRegistration: false,
      popVisible: {
        saveAutoGuide: false
      },
      popBluemembers: false,

      // 2021.03.29 (ver1.2) 팝업 추가
      popMPoint: false,
      popBluemembersPoint: false
    }
  },
  // 2021.03.22 (ver1.1) 추가
  updated() {
    this.setLabel((idg) => {
      // console.dir(idg) // 자동 생성된 ID 배열
    })
  }
}
</script>
