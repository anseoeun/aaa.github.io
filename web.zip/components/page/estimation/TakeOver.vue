<template>
  <section class="information-detail">
    <div class="summary-info" :class="{ active: isOptionsShow }">
      <h1 class="title">인수 정보</h1>
      <!-- 2021.03.22 (ver1.1) 텍스트 수정 -->
      <div class="summary-text">
        배달탁송 / 서울시 (예상출고일 : 3월 2주차)
        <v-popover trigger="hover" placement="bottom-start">
          <p>
            현 시점 계약완료 기준으로 재고 및<br />생산계획 기반 산출된 예상출고일이며,<br />당사 사정에 의하여 변경될
            수 있으니<br />단순 참고만 하시기 바랍니다.
          </p>

          <!-- 2021.03.22 (ver1.1) 법인 추가 -->
          <!-- <p>예상 출고일은 현 시점 계약 시 예상되는<br />출고일이며, 당사 사정에 따라 변경될 수 있습니다.<br />법인 대량 구매 시 가장 빨리 출고되는 차량<br />기준으로 안내되며, 출고일은 차량별로<br />상이할 수 있습니다.</p> -->
          <v-btn slot="reference"><i class="icon-help"></i></v-btn>
        </v-popover>
      </div>
      <!-- 2021.03.31 (ver1.3) 텍스트 추가 -->
      <div class="total-price">탁송료<span class="price">100,000</span> 원</div>
      <v-btn
        class="btn-detail"
        type="icon"
        :icon-class="['icon-open', { active: isOptionsShow }]"
        @click="isOptionsShow = !isOptionsShow"
        ><span class="offscreen">상세보기</span></v-btn
      >
    </div>
    <div v-show="isOptionsShow" class="detail-info">
      <div class="info-grid-list">
        <ul>
          <li>
            <strong class="info-title">인수방법</strong>
            <div class="info-group">
              <p>배달탁송</p>
              <v-popover trigger="hover" placement="bottom-start">
                <p>
                  고객님이 요청하신 장소로 차량을<br />배달해드리며, 생산된 공장에서부터의<br />차량운반비용이 탁송료로
                  부과됩니다.
                </p>
                <v-btn slot="reference"><i class="icon-help"></i></v-btn>
              </v-popover>
            </div>
          </li>
          <li>
            <strong class="info-title">인수방법</strong>
            <div class="info-group">
              <p>직접인수</p>
              <v-popover trigger="hover" placement="bottom-start">
                <p>전시차량은 온라인 구매 후 전시지점에<br />직접 방문 인수하셔야 합니다.</p>
                <v-btn slot="reference"><i class="icon-help"></i></v-btn>
              </v-popover>
            </div>
          </li>
          <li>
            <strong class="info-title ct">탁송지역</strong>
            <div class="info-group">
              <v-select v-model="locationSelectValue" :data="locationSelect" placeholder="시/도"> </v-select>
              <v-select v-model="locationSelectValue" :data="locationSelect" placeholder="시/군/구"> </v-select>
            </div>
          </li>
          <li>
            <strong class="info-title">예상출고일</strong>
            <div class="info-group">
              <p>3월 2주차</p>
              <v-popover trigger="hover" placement="bottom-start">
                <p>
                  현 시점 계약완료 기준으로 재고 및<br />생산계획 기반 산출된 예상출고일이며,<br />당사 사정에 의하여
                  변경될 수 있으니<br />단순 참고만 하시기 바랍니다.
                </p>
                <v-btn slot="reference"><i class="icon-help"></i></v-btn>
              </v-popover>
            </div>
          </li>
          <li>
            <strong class="info-title">인수지</strong>
            <div class="info-group">
              <p>강남논현지점 (서울시 강남구 테헤란로 22길 12)</p>
            </div>
          </li>
        </ul>
      </div>
    </div>
  </section>
</template>

<script>
export default {
  components: {},
  data() {
    return {
      isOptionsShow: false,
      locationSelect: [
        {
          name: '1',
          value: '서울시'
        },
        {
          name: '2',
          value: '경기도'
        },
        {
          name: '3',
          value: '인천광역시'
        }
      ],
      locationSelectValue: ''
    }
  }
}
</script>
