<template>
  <section class="similar-recommend-list">
    <h1>빠른 출고를<br />원한다면?</h1>
    <div class="slide-list">
      <v-carousel-new
        :data="slideList"
        :pagination="true"
        :navigation="true"
        :items-to-show="3"
        :items-to-slide="3"
        :touch-drag="false"
        :infinite-scroll="false"
      >
        <template slot-scope="props">
          <nuxt-link to="/" role="button">
            <!-- 2021.03.22 (ver1.1) div 추가 -->
            <div class="car-img">
              <v-img :src="props.item.carImg.src" :alt="props.item.carImg.alt"></v-img>
            </div>
            <ul class="flag-list">
              <li>빠른 출고 가능</li>
            </ul>
            <strong class="name">{{ props.item.name }}</strong>
            <ul class="detail">
              <li class="fullname" v-html="props.item.fullName"></li>
              <li class="out-color">{{ props.item.outColor }}</li>
              <li class="in-color">{{ props.item.inColor }}</li>
              <li class="option" :class="props.item.optionClass">
                {{ props.item.optionType }} <span>{{ props.item.option }}</span>
              </li>
            </ul>
            <ul class="price">
              <li class="total-price">
                <strong>{{ props.item.totalPirce }}</strong> 원
              </li>
              <li>
                <span
                  >탁송료 <em>{{ props.item.takeOver }}</em> 원</span
                >
              </li>
              <li class="change-price">
                <span
                  >변경금액 <em>{{ props.item.changePrice }}</em> 원</span
                >
              </li>
            </ul>
          </nuxt-link>
        </template>
      </v-carousel-new>
    </div>
  </section>
</template>

<script>
export default {
  data() {
    return {
      // 슬라이드
      slideList: [
        {
          carImg: {
            src: require('~/assets/images/temp/temp-payment-car-model.png'),
            alt: '베뉴 자가용 LPG 1.6<br />Modern A/T'
          },
          name: '베뉴',
          fullName: '베뉴 자가용 LPG 1.6<br />Modern A/T',
          outColor: '미드나잇블랙',
          inColor: '블랙모노톤(블랙시트)',
          optionType: '동일옵션',
          option: '',
          optionClass: '',
          totalPirce: '23,220,000',
          takeOver: '134,000',
          changePrice: '(+) 100,000'
        },
        {
          carImg: {
            src: require('~/assets/images/temp/temp-payment-car-model.png'),
            alt: '베뉴 자가용 LPG 1.6<br />Modern A/T'
          },
          name: '그랜저',
          fullName: '그랜저 자가용 LPG 1.6<br />Modern A/T',
          outColor: '미드나잇블랙',
          inColor: '블랙모노톤(블랙시트)',
          optionType: '추가옵션',
          option: '앞좌석통풍+뒷자석열선',
          optionClass: '',
          totalPirce: '23,220,000',
          takeOver: '134,000',
          changePrice: '(+) 100,000'
        },
        {
          carImg: {
            src: require('~/assets/images/temp/temp-payment-car-model.png'),
            alt: '베뉴 자가용 LPG 1.6<br />Modern A/T'
          },
          name: '그랜저',
          fullName: '그랜저 자가용 LPG 1.6<br />Modern A/T',
          outColor: '미드나잇블랙',
          inColor: '블랙모노톤(블랙시트)',
          optionType: '제외옵션',
          option: '앞좌석통풍+뒷자석열선',
          optionClass: 'cancle',
          totalPirce: '23,220,000',
          takeOver: '134,000',
          changePrice: '(-) 100,000'
        },
        {
          carImg: {
            src: require('~/assets/images/temp/temp-payment-car-model.png'),
            alt: '베뉴 자가용 LPG 1.6<br />Modern A/T'
          },
          name: '그랜저',
          fullName: '그랜저 자가용 LPG 1.6<br />Modern A/T',
          outColor: '미드나잇블랙',
          inColor: '블랙모노톤(블랙시트)',
          optionType: '추가옵션',
          option: '앞좌석통풍+뒷자석열선',
          optionClass: '',
          totalPirce: '23,220,000',
          takeOver: '134,000',
          changePrice: '(+) 100,000'
        },
        {
          carImg: {
            src: require('~/assets/images/temp/temp-payment-car-model.png'),
            alt: '베뉴 자가용 LPG 1.6<br />Modern A/T'
          },
          name: '베뉴',
          fullName: '베뉴 자가용 LPG 1.6<br />Modern A/T',
          outColor: '미드나잇블랙',
          inColor: '블랙모노톤(블랙시트)',
          optionType: '동일옵션',
          option: '',
          optionClass: '',
          totalPirce: '23,220,000',
          takeOver: '134,000',
          changePrice: '(+) 100,000'
        },
        {
          carImg: {
            src: require('~/assets/images/temp/temp-payment-car-model.png'),
            alt: '베뉴 자가용 LPG 1.6<br />Modern A/T'
          },
          name: '그랜저',
          fullName: '그랜저 자가용 LPG 1.6<br />Modern A/T',
          outColor: '미드나잇블랙',
          inColor: '블랙모노톤(블랙시트)',
          optionType: '제외옵션',
          option: '앞좌석통풍+뒷자석열선',
          optionClass: 'cancle',
          totalPirce: '23,220,000',
          takeOver: '134,000',
          changePrice: '(-) 100,000'
        }
      ]
    }
  }
}
</script>
