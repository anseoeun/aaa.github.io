<template>
  <img :style="getStyle" :src="src" :alt="alt" @error="onError" />
</template>

<script>
export default {
  props: {
    src: {
      type: String,
      default: ''
    },
    alt: {
      type: String,
      default: ''
    },
    width: {
      type: String,
      default: null
    },
    height: {
      type: String,
      default: null
    },
  },

  computed: {
    getStyle() {
      return this.width && this.height ? `width: ${this.width}; height: ${this.height}` : ''
    },
  },

  methods: {
    onError() {
      // console.log('error')
    }
  }
}
</script>