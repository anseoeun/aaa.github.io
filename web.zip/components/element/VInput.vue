<template>
  <el-input
    :id="id"
    :type="type"
    :class="`${inline ? 'inline' : ''} ${inputType}`"
    :value="value"
    :placeholder="placeholder"
    :disabled="disabled"
    :clearable="clearable"
    :rows="rows"
    :readonly="readonly"
    :maxlength="maxlength"
    :data-id="useIdCall()"
    @input="onInput"
    @focus="onFocus"
    @blur="onFocusOut"
    @keydown.native="onKeydown"
    @clear="onClear"
  >
    <i v-if="prefixIcon !== ''" slot="prefix" :class="getPrefixIcon" @click="onPrefixClick"></i>
    <i v-if="suffixIcon !== ''" slot="suffix" :class="getSuffixIcon" @click="onSuffixClick"></i>
    <template v-if="$slots.suffix" slot="suffix">
      <slot name="suffix"></slot>
    </template>
  </el-input>
</template>

<script>
export default {
  props: {
    value: {
      type: [String, Number],
      default: ''
    },
    id: {
      type: String,
      default: ''
    },
    type: {
      type: String,
      default: 'text'
    },
    inline: {
      type: Boolean,
      default: false
    },
    placeholder: {
      type: String,
      default: ''
    },
    disabled: {
      type: Boolean,
      default: false
    },
    clearable: {
      type: Boolean,
      default: false
    },
    prefixIcon: {
      type: String,
      default: ''
    },
    suffixIcon: {
      type: String,
      default: ''
    },
    inputType: {
      type: String,
      default: ''
    },
    readonly: {
      type: Boolean,
      default: false
    },
    rows: {
      type: Number,
      default: 2
    },
    maxlength: {
      type: [String, Number],
      default: ''
    },
  },
  computed: {
    getPrefixIcon() {
      return `el-input__icon ${this.prefixIcon}`
    },
    getSuffixIcon() {
      return `el-input__icon ${this.suffixIcon}`
    }
  },
  methods: {
    onInput(value) {
      if (this.maxlength !== '' && value.length > this.maxlength){
        value = value.slice(0, this.maxlength)
      }
      this.$emit('input', value)
    },
    onFocus(e) {
      this.$emit('focus', e)
    },
    onFocusOut(e) {
      this.$emit('blur', e)
    },
    onKeydown(e) {
      this.$emit('keydown', e)
    },
    onPrefixIcon(e) {
      this.$emit('prefixClick', e)
    },
    onSuffixClick(e) {
      this.$emit('suffixClick', e)
    },
    onClear(e) {
      this.$emit('clear', e)
    },
    useIdCall() {
      return this._uid
    },
  }
}
</script>


