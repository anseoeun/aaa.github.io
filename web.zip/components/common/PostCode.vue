<template>
  <v-popup :width="'776px'" :visible="popVisible.postCode" @close="popVisible.postCode = false">
    <template slot="header">
      <div class="title">주소 검색</div>
      <p class="header-description">주소명(도로명, 건물번호)을 입력해주세요.</p>
    </template>
    <template slot="body">
      <div class="post-code-search label-input">
        <label><span class="offscreen">검색입력</span></label>
        <v-input v-model="postCode" class="post-code-input" placeholder="예) 헌릉로 12, 양재동 231"></v-input>
        <v-btn class="btn btn md white r">검색</v-btn>
      </div>

      <!-- 2021.03.24 (ver1.2) -->
      <ul class="bullet-star-list">
        <li>주민등록 상 주소(법인인 경우 사업자등록 상 주소)로 검색하고 선택해 주세요.</li>
        <li>
          주소 미확인으로 출고 후 구매 취소 발생 시 왕복탁송료 이외 부대비용은 본인 부담이니 이 점 반드시 유의하시기
          바랍니다.
        </li>
      </ul>
      <p class="contents-head">* 검색결과 {{ total }} 건</p>
      <div v-if="addrList.length > 0">
        <div class="table-area">
          <table class="noline-in">
            <colgroup>
              <col width="200px" />
              <col width="auto" />
            </colgroup>
            <thead>
              <tr>
                <th>우편번호</th>
                <th>주소</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="(addr, index) in addrList" :key="index">
                <td>{{ addr.code }}</td>
                <td class="left">{{ addr.address }}</td>
              </tr>
            </tbody>
          </table>
        </div>
        <v-pagination :total="100" />
      </div>
      <!-- 결과없음 -->
      <div v-else class="addr-no-result">검색결과가 없습니다.</div>
    </template>
  </v-popup>
</template>
<script>
import { VBtn, VInput, VPopup, VPagination } from '~/components/element'
export default {
  components: {
    VPopup,
    VBtn,
    VInput,
    VPagination
  },
  props: {
    popVisible: {
      type: Object,
      defualt: {},
      required: true
    }
  },
  data() {
    return {
      postCode: '',
      addrList: [
        { code: '06711', address: '서울특별시 서초구 남부순환로317길 (서초동, 서초동 코아아파트)' },
        { code: '06717', address: '서울특별시 서초구 남부순환로317길 (서초동, 서초동 코아아파트)' },
        { code: '06720', address: '서울특별시 서초구 남부순환로317길 (서초동, 서초동 코아아파트)' },
        { code: '06711', address: '서울특별시 서초구 남부순환로317길 (서초동, 서초동 코아아파트)' },
        { code: '06717', address: '서울특별시 서초구 남부순환로317길 (서초동, 서초동 코아아파트)' },
        { code: '06720', address: '서울특별시 서초구 남부순환로317길 (서초동, 서초동 코아아파트)' }
      ]
    }
  },
  computed: {
    total() {
      return this.addrList.length
    }
  },

  // 2021.03.17 (ver1.1)
  updated() {
    this.setCaption()
    this.setLabel((idg) => {
      // console.dir(idg) // 자동 생성된 ID 배열
    })
  }
}
</script>
