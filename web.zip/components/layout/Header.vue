<template>
  <div class="header-wrap" @mouseleave="subMenuToggle = false">
    <h1 class="logo">
      <!-- <nuxt-link to="/" @focus="subMenuToggle = false">AX</nuxt-link> -->
      <a href="javascript:void(0);" @focus="subMenuToggle = false"><span class="offscreen">AX</span></a>
    </h1>
    <nav>
      <div class="main-menu" :class="{ active: subMenuToggle }">
        <ul>
          <li
            v-for="(menu, index) in gnbMenu"
            :key="index"
            :class="{ 'util-menu': index == 5 || index == 6 }"
          >
            <nuxt-link :to="menu.to" @focus.native="subMenuToggle = true">{{
              menu.name
            }}</nuxt-link>
            <ul v-show="subMenuToggle" class="sub-menu">
              <li v-for="(submenu, idx) in menu.subMenu" :key="idx">
                <nuxt-link :to="submenu.to" @focus.native="subMenuToggle = true">{{
                  submenu.name
                }}</nuxt-link>
              </li>
            </ul>
          </li>
        </ul>
        <div class="my-menu">
          <a
            href="javascript:void(0);"
            role="button"
            @focus="subMenuToggle = true"
            ><span class="offscreen">마이메뉴</span></a
          >
          <ul class="sub-menu">
            <li><nuxt-link to="/">로그인</nuxt-link></li>
            <li><nuxt-link to="/">마이페이지</nuxt-link></li>
            <li><nuxt-link to="/" @focusout="subMenuToggle = false">회원가입</nuxt-link></li>
            <li><a href="javascript:void(0);" role="button" @focusout="subMenuToggle = false">로그아웃</a></li>
          </ul>
        </div>
      </div>
    </nav>
    <div class="notice">
      <!-- 활성화 : active -->
      <button
        type="button"
        class="btn-notice active"
        @click="alrampopVisible = true"
      >
        <span class="offscreen">알림</span>
      </button>
    </div>
    <my-notice-header :alrampop-visible="alrampopVisible" :is-login="isLogin" :is-alarm="isAlarm" :data="alarmList" @close="alrampopVisible = false" />
  </div>
</template>

<script>
import MyNoticeHeader from '~/components/layout/MyNoticeHeader'
export default {
  components: {
    MyNoticeHeader
  },
  data() {
    return {
      isLogin: true,
      gnbMenu: [
        {
          name: '소개',
          to: 'javascript:void(0)',
          subMenu: [
            { name: '하이라이트', to: '/' },
            { name: '디지털 쇼룸', to: '/' },
            { name: '갤러리', to: '/' },
            { name: '제원/가격', to: '/' },
            { name: '모델비교', to: '/' },
          ],
        },
        {
          name: '체험',
          to: '/',
          subMenu: [
            { name: '시승신청', to: '/' },
            { name: '전시장 안내', to: '/' },
          ],
        },
        {
          name: '구매',
          to: '/',
          subMenu: [
            { name: '나만의 캐스퍼 만들기', to: '/' },
          ],
        },
        {
          name: '혜택',
          to: '/',
          subMenu: [
            { name: '쿠폰', to: '/' },
            { name: '이벤트', to: '/' },
            { name: '제휴카드', to: '/' },
          ],
        },
        { name: '후기', to: '/', subMenu: [{ name: '구매후기', to: '/' }] },
        { name: '구매가이드', to: '/' },
        { name: '고객지원', to: '/' },
      ],
      subMenuToggle: false,
      // alarm
      isAlarm: true,
      alrampopVisible: false,
      alarmList: [
        {
          tag: '계약해지 안내',
          date: '2021.01.29 12:34',
          text:
            '진행중인 차량 계약의 차량대급결제가 기한 내 완료되지 않아 자동 해약처리 되었습니다.',
        },
        {
          tag: '전자서명 요청',
          date: '2021.01.29 12:34',
          text:
            '진행중인 차량 계약의 차량대급결제가 기한 내 완료되지 않아 자동 해약처리 되었습니다.',
        },
        {
          tag: '전자서명 미완료 안내',
          date: '2021.01.29 12:34',
          text:
            '진행중인 차량 계약의 차량대급결제가 기한 내 완료되지 않아 자동 해약처리 되었습니다.',
        },
        {
          tag: '전자서명 미완료 안내',
          date: '2021.01.29 12:34',
          text:
            '진행중인 차량 계약의 차량대급결제가 기한 내 완료되지 않아 자동 해약처리 되었습니다.',
        },
      ],
    }
  },
}
</script>
