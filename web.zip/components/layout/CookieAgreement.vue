<template>
  <div class="cookie-wrap">
    <div class="cookie-inner">
      <div class="cookie-text">
        <p>웹사이트 이용 시 알맞은 정보와 경험을 제공하고자 쿠키정보를 사용합니다. 본사이트를 계속 이용하는 것은 이에 동의함을 의미합니다.</p>
        <p>더 자세한 정보는 <span>개인정보처리방침</span>과<span>이용약관</span>을 확인해 주세요.</p>
      </div>
      <v-btn class="btn md white line r" type="button">동의하고 닫기</v-btn>
    </div>
    <v-btn class="close" type="button"><span class="offscreen">닫기</span></v-btn>
  </div>
</template>

<script>
export default {
}
</script>
