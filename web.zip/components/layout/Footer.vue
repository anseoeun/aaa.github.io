<template>
  <div class="footer">
    <!-- notice -->
    <div class="notice-wrap">
      <div class="notice-box">
        <nuxt-link to="/" class="title">공지사항</nuxt-link>

        <!-- notice slide -->
        <v-carousel :data="noticeList" indicator-position="none" class="notice-slide">
          <template slot-scope="props">
            <nuxt-link :to="props.item.to">{{ props.item.noticeCont }}</nuxt-link>
          </template>
        </v-carousel>

      </div>
      <div class="support-box">
        <ul>
          <!-- 2021.03.29 문구수정 / 디자인 확인해야함 -->
          <li>고객센터 080-500-6000</li>
          <li><nuxt-link to="/">자주하는 질문</nuxt-link></li>
          <li><nuxt-link to="/">1:1문의하기</nuxt-link></li>
        </ul>
      </div>
    </div>
    <!-- footer -->
    <div class="footer-wrap">
      <div class="footer-cont">
        <div class="logo"><span class="offscreen">AX</span></div>
        <div class="footer-menu">
          <ul>
            <li><nuxt-link to="/">이용약관</nuxt-link></li>
            <li>
              <nuxt-link to="/"><strong>개인정보보호방침</strong></nuxt-link>
            </li>
            <li>
              <a
                href="https://www.hyundai.com"
                target="_blank"
                title="새창 열기"
                >현대닷컴</a
              >
            </li>
          </ul>
          <ul class="footer-info">
            <li>사업자등록번호 101-81-09147</li>
            <li>통신판매업신고번호 2002-01546</li>
            <li>
              대표이사 김현대<a
                href="javascript:void(0);"
                target="_blank"
                title="새창 열기"
                >사업자정보확인 &gt;</a
              >
            </li>
            <li>대표전화 02-3488-0200</li>
            <li>주소 서울시 서초구 헌릉로 12</li>
            <li>호스팅서비스제공 업체명</li>
          </ul>
          <p class="copyright">
            COPYRIGHT ⓒ HYUNDAI MOTOR COMPANY, ALL RIGHTS RESERVED.
          </p>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      noticeList: [
        {
          to: '/',
          noticeCont: '국내 독자기술 기반 수소연료전지 발전 시스템 본격 가동',
        },
        {
          to: '/',
          noticeCont: '해외 독자기술 기반 수소연료전지 발전 시스템 본격 가동 중지',
        },
        {
          to: '/',
          noticeCont: '국내 독자기술 기반 수소연료전지 발전 시스템 본격 가동 국내 독자기술 기반 수소연료전지 발전 시스템 본격 가동',
        },
        {
          to: '/',
          noticeCont: '문구테스트입니다 문구가 길어질땐 어쩌죠 말줄임인가요 테스트테스트 테스트 문구테스트입니다 문구가 길어질땐 어쩌죠 말줄임인가요 테스트테스트 테스트',
        },
      ],
    }
  }
}
</script>