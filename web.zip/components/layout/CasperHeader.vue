<template>
  <div class="casper-header">
      <h1 class="logo-casper"><span class="offscreen">CASPER</span></h1>
      <div class="csper-step">
        <ol>
          <li><v-btn class="btn-step on"><span>1단계. 나만의 캐스퍼 만들기</span></v-btn></li>
          <li><v-btn class="btn-step"><span>2단계. 견적내기</span></v-btn></li>
          <li><v-btn class="btn-step"><span>3단계. 계약하기</span></v-btn></li>
        </ol>
      </div>
      <v-btn class="btn-casper-close">종료</v-btn>
  </div>
</template>

<script>
export default {
  data() {
    return {

    }
  },
}
</script>
