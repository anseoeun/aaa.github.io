<template>
  <div class="mycar-header-wrap">
    <h1 class="logo">
      <nuxt-link to="/"><span class="offscreen">AX</span></nuxt-link>
      <span>내 차 만들기</span>
    </h1>
    <button type="button" class="btn-close" @click="onClose()"><span>창닫기</span></button>
  </div>
</template>

<script>
export default {
  methods: {
    onClose() {

    }
  }
}
</script>
