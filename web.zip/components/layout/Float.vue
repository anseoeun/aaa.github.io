<template>

  <div>
    <ul class="floating-list">
      <li v-if="type === 'vehicles'">
        <v-btn role="button" class="btn-floating-vehicle no-hover" @click="popVehicleVisible = true">
          <span class="vehicle-list"
            ><em>최근 본 차량(</em><strong class="number">12</strong
            ><em>) 바로가기 &gt;</em></span
          >
        </v-btn>
      </li>
      <!-- 2021.03.31 (ver1.1) 견적 플로팅 추가 -->
      <li v-if="type === 'contract' || type === 'payment' || type === 'estimation' ">
        <v-btn role="button" class="btn-floating-faq no-hover" @click="popFaqVisible = true">
          <span class="offscreen">FAQ &gt;</span>
        </v-btn>
      </li>
      <li>
        <nuxt-link to="/" role="button" class="btn-floating-chat">
          <span>실시간 톡상담 서비스입니다.</span>
        </nuxt-link>
      </li>
      <li><v-top /></li>
    </ul>
    <faq-pop :visible="popFaqVisible" @close="popFaqVisible = false"></faq-pop>
    <vehicle-pop :visible="popVehicleVisible" @close="popVehicleVisible = false"></vehicle-pop>
  </div>
</template>

<script>
import VTop from '~/components/element/VTop'
import FaqPop from '~/components/page/support/faq/FaqPop'
import VehiclePop from '~/components/page/vehicles/popup/VehiclePop'
export default {
  components: {
    VTop,
    FaqPop,
    VehiclePop
  },
  props: {
    type: {
      type: String,
      default: '',
    },
  },
  data(){
    return {
      popFaqVisible: false,
      popVehicleVisible: false
    }
  }
}
</script>
