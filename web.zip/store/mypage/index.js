const state = () => ({
  estimateData: [
    {
      seq:'1',
      estimateCheck: false,
      estimateDate: '2021.02.11 13:59',
      flagData: [{ flagName: '8월 생산 할인차' }],
      name: 'AX 스마트스트림 가솔린 1.1 터보 프리미엄 밀레니얼 A/T ',
      optionData: [{ optionName: '폴라화이트' }, { optionName: '베이지' }, { optionName: '옵션 2개' }],
      carImg: require('~/assets/images/temp/temp-payment-car-model.png'),
      price: '31800000',
      carPrice: '23,085,000',
      consignmentFee: '9,858,734',
      salePoint: '1,000,000',
      displacement: '1598',
      averageFuel: '13.8',
      margin: '100000',
      payment: '일시불<br />(현금/신용카드)',

      outColor: {name:'폴라화이트111', price:'100000', src: require('~/assets/images/temp/temp-color-4.png')},
      inColor:{name:'블랙모노톤 (블랙시트)111', price:'0', src: require('~/assets/images/temp/temp-color-1.png')},
      option: {totalPrice:'300000', opts:[
        {name:'현대스마트센트', price:'1,000,000'},
        {name:'옵션명이 길경우 두줄입니다', price:'1,000,000'},
        {name:'옵션명', price:'1,000,000'},
        {name:'옵션명', price:'1,000,000'}
      ]},

      powerTrain:[
        '전/후륜 디스크 브레이크 (전륜 1111)',
        'Ce 260(터보 직분사 가솔린)엔진',
        '랙 구동형 전자식 파워스티어링 (R-EPS)',
      ],
      exterior: [
        '16인치 알로이 휠 타이어 111',
        '16인치 알로이 ',
      ],

      takeOverFee: '100,000',
      takeOverType: '배달탁송',
      takeOverArea: '서울',
      releaseDate: '2021.08.01',

      totalSalePrice: '11,672,500',
      saleList: [
        {name:'직원 할인1111', list:[
          {name:'직원할인', price:'100,000'},
          {name:'직원<br>(일시불 3%할인)', price:'100,000'},
        ]},
        {name:'일반 할인 111', list:[
          {name:'기본할인', price:'100,000'},
          {name:'기획전 할인', price:'100,000'},
          {name:'타겟조건명', price:'100,000'},
          {name:'지인추천할인', price:'100,000'},
        ]},
        {name:'쿠폰 할인', list:[
          {name:'쿠폰명', price:'100,000'},
        ]},
        // {name:'지인추천 할인', price:'100,000'}
      ],
      pointList: [
        {name:'세이브오트', price:'300,000'},
        {name:'M포인트', price:'300,000'},
        {name:'블루멤버스 포인트', price:'300,000'},
      ],

      blueMembersPoint: '11,672,511',

      beforeReleasePrice: '25,000,111',
      paymentMethod:{
        type :'일시불',
        list:[
          {name:'지불조건', option:[
            {name:'계약금', price:'100,000'},
            {name:'인도금', price:'27,855,227'},
            {name:'단기의무보험료', price:'2,300 '},
          ]}
        ]
      },

      carRegistFee: '25,000,111',
      carRegistFeeList: [
        {name:'면세조건', text:'일반'},
        {name:'취득세', price:'27,855,227'},
        // {name:'공채(할인)', area:'서울', price:'2,300'},
        {name:'중지대(수입인지)', price:'100,000 '},
        {name:'차량번호판', price:'25,000 '},
        {name:'등록대행수수료', price:'35,000 '},
      ]
    },
    {
      seq:'2',
      estimateCheck: false,
      estimateDate: '2021.02.11 13:59',
      flagData: '',
      name: 'AX 스마트스트림 가솔린 1.1 터보 ',
      optionData: [{ optionName: '폴라화이트' }, { optionName: '베이지' }],
      carImg: require('~/assets/images/temp/temp-precontact-car-visual.png'),
      price: '32800000',
      carPrice: '23,085,000',
      consignmentFee: '9,858,734',
      salePoint: '1,000,000',
      displacement: '1598',
      averageFuel: '13.8',
      margin: '0',
      payment: '할부',

      outColor: {name:'옥스퍼드 블루222', price:'50000', color:'#e2e2e2'},
      inColor:{name:'블랙모노톤22', price:'100000', color:'#e2e2e2'},
      option:{totalPrice:'100000', opts:[
        {name:'현대스마트센트2', price:'1,000,000'},
        {name:'옵션명이 길경우 두줄입니다', price:'1,000,000'},
        {name:'옵션명', price:'1,000,000'},
        {name:'옵션명', price:'1,000,000'}
      ]},

      powerTrain: [
        '전/후륜 디스크 브레이크 (전륜 22222)',
        'Ce 260(터보 직분사 가솔린)엔진',
        '랙 구동형 전자식 파워스티어링 (R-EPS)',
      ],
      exterior: [
        '16인치 알로이 휠 타이어 222',
        '16인치 알로이 ',
      ],

      takeOverFee: '100,000',
      takeOverType: '배달탁송',
      takeOverArea: '경기',
      releaseDate: '공지사항 참조',

      totalSalePrice: '11,672,500',
      saleList: [
        {name:'직원 할인2222', list:[
          {name:'직원할인', price:'100,000'},
          {name:'직원<br>(일시불 3%할인)', price:'100,000'},
        ]},
        {name:'일반 할인 222', list:[
          {name:'기본할인', price:'100,000'},
          {name:'기획전 할인', price:'100,000'},
          {name:'타겟조건명', price:'100,000'},
          {name:'지인추천할인', price:'100,000'},
        ]},
        {name:'쿠폰 할인', list:[
          {name:'쿠폰명', price:'100,000'},
        ]},
        // {name:'지인추천 할인', price:'100,000'}
      ],
      pointList: [
        {name:'세이브오트', price:'300,000'},
        {name:'M포인트', price:'300,000'},
        {name:'블루멤버스 포인트', price:'300,000'},
      ],

      blueMembersPoint: '11,672,522',

      beforeReleasePrice: '25,000,222',
      paymentMethod:{
        type :'할부',
        list:[
          {name:'지불조건', option:[
            {name:'계약금', price:'100,000'},
            {name:'인도금', price:'27,855,227'},
            {name:'단기의무보험료', price:'2,300 '},
          ]},
          {name:'할부상품', option:[
            {name:'상품명', productName:'잔가보장형'},
            {name:'할부원금', price:'24,500,000'},
            {name:'할부금 감면', price:'-728,800'},
            {name:'할부 기간', productName:'36개월'},
            {name:'금리', rate:'4.5'},
            {name:'월 납입금', price:'월 289,959'},
          ]},
          {name:'출고 전 납입 금액', option:[
            {name:'차량 구입금액', price:'31,155,137'},
            {name:'임시운행 의무보험료', price:'155,137'},
            {name:'할부인지대', price:'0'},
            {name:'할부 원금', price:'728,800'},
          ]},
          {name:'제휴 혜택', option:[
            {name:'혜택 유형', productName:'캐시백형'},
            {name:'캐시백 예상금액', price:'최대 500,000'},
          ]},
        ]
      },

      carRegistFee: '25,000,222',
      carRegistFeeList: [
        {name:'면세조건', text:'장애 1~3급'},
        {name:'취득세', price:'0'},
        // {name:'공채(할인)', area:'서울', price:'2,300'},
        {name:'중지대(수입인지)', price:'100,000 '},
        {name:'차량번호판', price:'25,000 '},
        {name:'등록대행수수료', price:'35,000 '},
      ]
    },
    {
      seq:'3',
      estimateCheck: false,
      estimateDate: '2021.02.11 13:59',
      flagData: '',
      name: 'AX 스마트스트림 가솔린 1.1 터보 3333333 ',
      optionData: [{ optionName: '폴라화이트' }, { optionName: '베이지' }],
      carImg: require('~/assets/images/temp/temp-precontact-car-visual.png'),
      price: '33800000',
      carPrice: '23,085,000',
      consignmentFee: '9,858,734',
      salePoint: '1,000,000',
      displacement: '1598',
      averageFuel: '13.8',
      margin: '50000',
      payment: '할부',

      outColor: {name:'폴라화이트333', price:'70000', color:'#e2e2e2'},
      inColor:{name:'블랙모노톤333 (블랙시트)', price:'0', color:'#414141'},
      option: {totalPrice:'300000', opts:[
        {name:'현대스마트센트', price:'1,000,000'},
        {name:'옵션명이 길경우 두줄입니다', price:'1,000,000'},
        {name:'옵션명', price:'1,000,000'},
        {name:'옵션명', price:'1,000,000'}
      ]},

      powerTrain:[
        '전/후륜 디스크 브레이크 (전륜 3333)',
        'Ce 260(터보 직분사 가솔린)엔진',
        '랙 구동형 전자식 파워스티어링 (R-EPS)',
      ],
      exterior: [
        '16인치 알로이 휠 타이어 333',
        '16인치 알로이 ',
      ],

      takeOverFee: '100,000',
      takeOverType: '배달탁송',
      takeOverArea: '서울',
      releaseDate: '2021.08.01',

      totalSalePrice: '11,672,500',
      saleList: [
        {name:'직원 할인3333', list:[
          {name:'직원할인', price:'100,000'},
          {name:'직원<br>(일시불 3%할인)', price:'100,000'},
        ]},
        {name:'일반 할인 333', list:[
          {name:'기본할인', price:'100,000'},
          {name:'기획전 할인', price:'100,000'},
          {name:'타겟조건명', price:'100,000'},
          {name:'지인추천할인', price:'100,000'},
        ]},
        {name:'쿠폰 할인', list:[
          {name:'쿠폰명', price:'100,000'},
        ]},
        // {name:'지인추천 할인', price:'100,000'}
      ],
      pointList: [
        {name:'세이브오트', price:'300,000'},
        {name:'M포인트', price:'300,000'},
        {name:'블루멤버스 포인트', price:'300,000'},
      ],

      blueMembersPoint: '11,672,533',

      beforeReleasePrice: '25,000,333',
      paymentMethod:{
        type :'일시불',
        list:[
          {name:'지불조건', option:[
            {name:'계약금', price:'100,000'},
            {name:'인도금', price:'27,855,227'},
            {name:'단기의무보험료', price:'2,300 '},
          ]},
          {name:'할부상품', option:[
            {name:'상품명', productName:'잔가보장형'},
            {name:'할부원금', price:'24,500,000'},
            {name:'할부금 감면', price:'-728,800'},
            {name:'할부 기간', productName:'36개월'},
            {name:'금리', rate:'4.5'},
            {name:'월 납입금', price:'월 289,959'},
          ]},
          {name:'출고 전 납입 금액', option:[
            {name:'차량 구입금액', price:'31,155,137'},
            {name:'임시운행 의무보험료', price:'155,137'},
            {name:'할부인지대', price:'0'},
            {name:'할부 원금', price:'728,800'},
          ]},
          {name:'제휴 혜택', option:[
            {name:'혜택 유형', productName:'캐시백형'},
            {name:'캐시백 예상금액', price:'최대 500,000'},
          ]},
        ]
      },

      carRegistFee: '25,000,333',
      carRegistFeeList: [
        {name:'면세조건', text:'일반'},
        {name:'취득세', price:'27,855,227'},
        // {name:'공채(할인)', area:'서울', price:'2,300'},
        {name:'중지대(수입인지)', price:'100,000 '},
        {name:'차량번호판', price:'25,000 '},
        {name:'등록대행수수료', price:'35,000 '},
      ]
    },
    {
      seq:'4',
      estimateCheck: false,
      estimateDate: '2021.02.11 13:59',
      flagData: '',
      name: 'AX 스마트스트림 가솔린 1.1 터보 444444',
      optionData: [{ optionName: '폴라화이트' }, { optionName: '베이지' }],
      carImg: require('~/assets/images/temp/temp-precontact-car-visual.png'),
      price: '34800000',
      carPrice: '23,085,000',
      consignmentFee: '9,858,734',
      salePoint: '1,000,000',
      displacement: '1598',
      averageFuel: '13.8',
      margin: '0',
      payment: '할부',

      outColor: {name:'옥스퍼드 블루444', price:'50000', color:'#e2e2e2'},
      inColor:{name:'블랙모노톤444', price:'100000', color:'#e2e2e2'},
      option:{totalPrice:'100000', opts:[
        {name:'현대스마트센트2', price:'1,000,000'},
        {name:'옵션명이 길경우 두줄입니다', price:'1,000,000'},
        {name:'옵션명', price:'1,000,000'},
        {name:'옵션명', price:'1,000,000'}
      ]},

      powerTrain:[
        '전/후륜 디스크 브레이크 (전륜 4444)',
        'Ce 260(터보 직분사 가솔린)엔진',
        '랙 구동형 전자식 파워스티어링 (R-EPS)',
      ],
      exterior: [
        '16인치 알로이 휠 타이어 444',
        '16인치 알로이 ',
      ],

      takeOverFee: '100,000',
      takeOverType: '배달탁송',
      takeOverArea: '서울',
      releaseDate: '2021.08.01',

      totalSalePrice: '11,672,500',
      saleList: [
        {name:'직원 할인444', list:[
          {name:'직원할인', price:'100,000'},
          {name:'직원<br>(일시불 3%할인)', price:'100,000'},
        ]},
        {name:'일반 할인 444', list:[
          {name:'기본할인', price:'100,000'},
          {name:'기획전 할인', price:'100,000'},
          {name:'타겟조건명', price:'100,000'},
          {name:'지인추천할인', price:'100,000'},
        ]},
        {name:'쿠폰 할인', list:[
          {name:'쿠폰명', price:'100,000'},
        ]},
        // {name:'지인추천 할인', price:'100,000'}
      ],
      pointList: [
        {name:'세이브오트', price:'300,000'},
        {name:'M포인트', price:'300,000'},
        {name:'블루멤버스 포인트', price:'300,000'},
      ],

      blueMembersPoint: '11,672,544',

      beforeReleasePrice: '25,000,444',
      paymentMethod:{
        type :'일시불',
        list:[
          {name:'지불조건', option:[
            {name:'계약금', price:'100,000'},
            {name:'인도금', price:'27,855,227'},
            {name:'단기의무보험료', price:'2,300 '},
          ]},
          {name:'할부상품', option:[
            {name:'상품명', productName:'잔가보장형'},
            {name:'할부원금', price:'24,500,000'},
            {name:'할부금 감면', price:'-728,800'},
            {name:'할부 기간', productName:'36개월'},
            {name:'금리', rate:'4.5'},
            {name:'월 납입금', price:'월 289,959'},
          ]},
          {name:'출고 전 납입 금액', option:[
            {name:'차량 구입금액', price:'31,155,137'},
            {name:'임시운행 의무보험료', price:'155,137'},
            {name:'할부인지대', price:'0'},
            {name:'할부 원금', price:'728,800'},
          ]},
          {name:'제휴 혜택', option:[
            {name:'혜택 유형', productName:'캐시백형'},
            {name:'캐시백 예상금액', price:'최대 500,000'},
          ]},
        ]
      },

      carRegistFee: '25,000,444',
      carRegistFeeList: [
        {name:'면세조건', text:'일반'},
        {name:'취득세', price:'27,855,227'},
        // {name:'공채(할인)', area:'서울', price:'2,300'},
        {name:'중지대(수입인지)', price:'100,000 '},
        {name:'차량번호판', price:'25,000 '},
        {name:'등록대행수수료', price:'35,000 '},
      ]
    },
    {
      seq:'5',
      estimateCheck: false,
      estimateDate: '2021.02.11 13:59',
      flagData: '',
      name: 'AX 스마트스트림 가솔린 1.1 터보 555555',
      optionData: [{ optionName: '폴라화이트' }, { optionName: '베이지' }],
      carImg: require('~/assets/images/temp/temp-precontact-car-visual.png'),
      price: '35800000',
      carPrice: '23,085,000',
      consignmentFee: '9,858,734',
      salePoint: '1,000,000',
      displacement: '1598',
      averageFuel: '13.8',
      margin: '0',
      payment: '할부',

      outColor: {name:'폴라화이트555', price:'100000', color:'#e2e2e2'},
      inColor:{name:'블랙모노톤555 (블랙시트)', price:'0', color:'#414141'},
      option: {totalPrice:'300000', opts:[
        {name:'현대스마트센트', price:'1,000,000'},
        {name:'옵션명이 길경우 두줄입니다', price:'1,000,000'},
        {name:'옵션명', price:'1,000,000'},
        {name:'옵션명', price:'1,000,000'}
      ]},

      powerTrain:[
        '전/후륜 디스크 브레이크 (전륜 5555)',
        'Ce 260(터보 직분사 가솔린)엔진',
        '랙 구동형 전자식 파워스티어링 (R-EPS)',
      ],
      exterior: [
        '16인치 알로이 휠 타이어 555',
        '16인치 알로이 ',
      ],

      takeOverFee: '100,000',
      takeOverType: '배달탁송',
      takeOverArea: '서울',
      releaseDate: '2021.08.01',

      totalSalePrice: '11,672,500',
      saleList: [
        {name:'직원 할인5555', list:[
          {name:'직원할인', price:'100,000'},
          {name:'직원<br>(일시불 3%할인)', price:'100,000'},
        ]},
        {name:'일반 할인 555', list:[
          {name:'기본할인', price:'100,000'},
          {name:'기획전 할인', price:'100,000'},
          {name:'타겟조건명', price:'100,000'},
          {name:'지인추천할인', price:'100,000'},
        ]},
        {name:'쿠폰 할인', list:[
          {name:'쿠폰명', price:'100,000'},
        ]},
        // {name:'지인추천 할인', price:'100,000'}
      ],
      pointList: [
        {name:'세이브오트', price:'300,000'},
        {name:'M포인트', price:'300,000'},
        {name:'블루멤버스 포인트', price:'300,000'},
      ],

      blueMembersPoint: '11,672,555',

      beforeReleasePrice: '25,000,555',
      paymentMethod:{
        type :'일시불',
        list:[
          {name:'지불조건', option:[
            {name:'계약금', price:'100,000'},
            {name:'인도금', price:'27,855,227'},
            {name:'단기의무보험료', price:'2,300 '},
          ]}
        ]
      },

      carRegistFee: '25,000,555',
      carRegistFeeList: [
        {name:'면세조건', text:'일반'},
        {name:'취득세', price:'27,855,227'},
        // {name:'공채(할인)', area:'서울', price:'2,300'},
        {name:'중지대(수입인지)', price:'100,000 '},
        {name:'차량번호판', price:'25,000 '},
        {name:'등록대행수수료', price:'35,000 '},
      ]
    },
  ],
  selectedData: [],
})

const getters = {
  estimateData: (state) => state.estimateData,
  selectedData: (state) => state.selectedData,
}
const mutations = {
  setChecked(state, {index, val}) {
    state.estimateData[index].estimateCheck = val
  },
  setSelectedData(state, data) {
    state.selectedData = data
  },
}

const actions = {

}

export default {
  namespaced: true,
  getters,
  state,
  actions,
  mutations
}
