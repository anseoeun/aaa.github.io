const state = () => ({
  testDrivingStep: '',
  enginData: [
    { value: 'check1', label: '전체'},
    { value: 'check2', label: '가솔린1.1'},
    { value: 'check3', label: '가솔린 1.1 터보'},
  ],
  checkedEngin: null,
  mapList: [
    {
      seq:'1',
      name: '서초 전시장',
      address: '서울특별시 서초구 반포대로 54 (서초동, 문창빌딩) 1층',
      phone: '010-812-7365',
      distence: '12',
      flag: ['팝업 전시', ' 상담 가능', ' 시승 가능'],
    },{
      seq:'2',
      name: '구로 전시장',
      address: '서울특별시 구로 반포대로 54 (서초동, 문창빌딩) 1층',
      phone: '010-812-7365',
      distence: '12',
      flag: ['팝업 전시', ' 상담 가능', ' 시승 가능'],
    },{
      seq:'3',
      name: '강서 전시장',
      address: '서울특별시 강서 반포대로 54 (서초동, 문창빌딩) 1층',
      phone: '010-812-7365',
      distence: '12',
      flag: ['팝업 전시', ' 상담 가능', ' 시승 가능'],
    },
  ],
  checkedMap : '',
  drivingMethod: [
    { value: 'check1', label: '셀프 시승 서비스'},
    { value: 'check2', label: '동승 시승 서비스'},
  ],
  checkedDrivingMethod : 'check1',
  carList :[
    {
      seq: '1',
      carImg: {
        src: require('~/assets/images/temp/temp-payment-car-model.png'),
        alt: 'AX 스마트스트림 가솔린 1.1 터보 프리미엄 밀레니얼 A/T',
      },
      name :'AX 스마트스트림 가솔린 1.1 Turbo 프리미엄 밀레니얼 A/T',
      outColor :' 미드나잇 블랙',
      inColor :' 베이지',
      opt :' 썬루프, 네비게이션, 컴포트 패키지 II, 옵션명, 옵션명, 옵션명, 옵션명'
    },
    {
      seq: '2',
      carImg: {
        src: require('~/assets/images/temp/temp-payment-car-model.png'),
        alt: 'AX 스마트스트림 가솔린 1.1 터보 프리미엄 밀레니얼 A/T',
      },
      name :'가솔린 트림  프리미엄 밀레 1.1 Turbo TT',
      outColor :' 미드나잇 블랙',
      inColor :' 베이지',
      opt :' 썬루프, 네비게이션, 컴포트 패키지 II, 옵션명, 옵션명, 옵션명, 옵션명'
    }
  ],
  checkedCar : '',
  drivingData: {
    '2021-3-3': ['10:00', '14:00'],
    '2021-3-11': ['10:00', '14:00'],
    '2021-3-16': ['10:00', '14:00'],
    '2021-3-30': ['10:00', '14:00'],
    '2021-4-3': ['10:00', '14:00'],
    '2021-4-11': ['10:00', '14:00'],
    '2021-4-16': ['10:00', '14:00'],
    '2021-4-30': ['10:00', '14:00'],
    '2021-5-3': ['10:00', '14:00'],
    '2021-5-11': ['10:00', '14:00'],
    '2021-5-16': ['10:00', '14:00'],
    '2021-5-30': ['10:00', '14:00'],
  },
  checkedDriving : {
    date: '',
    time: ''
  },
})

const getters = {
  testDrivingStep: (state) => state.testDrivingStep,
  enginData: (state) => state.enginData,
  checkedEngin: (state) => state.checkedEngin,
  mapList: (state) => state.mapList,
  checkedMap: (state) => state.checkedMap,
  drivingMethod: (state) => state.drivingMethod,
  checkedDrivingMethod: (state) => state.checkedDrivingMethod,
  carList: (state) => state.carList,
  checkedCar: (state) => state.checkedCar,
  drivingData: (state) => state.drivingData,
  checkedDriving: (state) => state.checkedDriving,
}
const mutations = {
  setEnginCheck(state, value) {
    state.checkedEngin = value
  },
  setTestDrivingStep(state, value) {
    state.testDrivingStep = value
  },
  setMapCheck(state, index) {
    state.checkedMap = state.mapList[index]
  },
  setDrivingMethod(state, value) {
    state.checkedDrivingMethod = value
  },
  setSelectedCar(state, value) {
    state.checkedCar = value
  },
  setSelectedDriving(state, value) {
    state.drivingData = value
  },
}

const actions = {

}

export default {
  namespaced: true,
  getters,
  state,
  actions,
  mutations
}
