import vihiclesModules from './vehicles'
import mypageModules from './mypage'

export const strict = false
export const modules = {
  vihiclesModules,
  mypageModules,
}
