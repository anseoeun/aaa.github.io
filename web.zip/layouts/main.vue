<template>
  <div class="wrap">
    <a href="javascript:void(0);" class="skip-nav" role="button"
      >본문 바로가기</a
    >
    <header>
      <header-comp />
    </header>
    <div class="container">
      <Nuxt />
    </div>

    <cookie-agreement />

  </div>
</template>

<script>
import Header from '~/components/layout/Header'
import CookieAgreement from '../components/layout/CookieAgreement'
export default {
  head() {
    return {
      meta: [
        {
          hid: 'keywords',
          name: 'keywords',
          content: ''
        },
        {
          hid: 'description',
          name: 'description',
          content: ''
        },
        {
          hid: 'author',
          name: 'author',
          content: ''
        },
        {
          property: 'og:type',
          content: ''
        },
        {
          property: 'og:title',
          content: ''
        },
        {
          property: 'og:description',
          content: ''
        },
        {
          property: 'og:image',
          content: ''
        },
        {
          property: 'og:url',
          content: ''
        },
      ],
    }
  },
  components: {
    HeaderComp: Header,
    CookieAgreement,
  }
}
</script>

<style lang="scss">
@import '~/assets/style/shop.scss';
</style>
