<template>
  <div class="wrap">
    <a href="javascript:void(0);" class="skip-nav" role="button"
      >본문 바로가기</a
    >
    <header>
      <header-comp />
    </header>
    <div class="container">
      <Nuxt />
    </div>
    <footer>
      <footer-comp />
    </footer>
    <div class="floating-menu">
      <float :type="menuType" />
    </div>
  </div>
</template>

<script>
import Header from '~/components/layout/Header'
import Footer from '~/components/layout/Footer'
import Float from '~/components/layout/Float'
export default {
  head() {
    return {
      meta: [
        {
          hid: 'keywords',
          name: 'keywords',
          content: ''
        },
        {
          hid: 'description',
          name: 'description',
          content: ''
        },
        {
          hid: 'author',
          name: 'author',
          content: ''
        },
        {
          property: 'og:type',
          content: ''
        },
        {
          property: 'og:title',
          content: ''
        },
        {
          property: 'og:description',
          content: ''
        },
        {
          property: 'og:image',
          content: ''
        },
        {
          property: 'og:url',
          content: ''
        },
      ],
    }
  },
  components: {
    HeaderComp: Header,
    FooterComp: Footer,
    Float,
  },
  data(){
    return{
      menuType: ''
    }
  },
  mounted(){
    this.menuTypeCheck()
  },
  methods: {
    menuTypeCheck(){
      let menu = this.$route.fullPath.split('/')[1].split('/')[0]
      if(menu === 'contract') {
        this.menuType = 'contract'
      } else if(menu === 'payment') {
        this.menuType = 'payment'
        // 2021.03.31 (ver1.1) 견적 플로팅 추가
      }else if(menu === 'estimation') {
        this.menuType = 'estimation'
      }else if(menu === 'vehicles') {
        this.menuType = 'vehicles'
      }
    }
  }

}
</script>

<style lang="scss">
@import '~/assets/style/shop.scss';
</style>
