<template>
  <div class="content precontract precontract-payment">
    <payment-form />

    <div class="btn-box">
      <v-btn type="button" class="btn lg blue r">결제하기</v-btn>
    </div>
  </div>
</template>

<script>
import { VBtn } from '~/components/element'
import PaymentForm from '~/components/page/pre-contract/PaymentForm'
export default {
  head() {
    return {
      title: '사전계약 > 결제',
    }
  },
  components: {
    VBtn,
    PaymentForm
  },
}
</script>
