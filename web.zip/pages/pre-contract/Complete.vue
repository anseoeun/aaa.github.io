<template>
  <div class="content precontract precontract-complete">
    <!-- 2021.03.22 (ver1.1) page-infotext 텍스트변경 -->
    <v-pageheader
      page-title="사전계약 완료"
      page-infotext="캐스퍼 사전계약이 완료되었습니다."
    >
    </v-pageheader>
    <v-pageheader
      page-title="사전계약 접수 완료"
      page-infotext="캐스퍼 사전계약 완료를 위해 입금을 서둘러 주세요."
    >
    </v-pageheader>

    <div class="matching-box">
      <div class="box-wrap">
        <div class="box-tit">
            접수정보
        </div>
        <div class="box-desc">
            <div class="matching-list">
              <ul>
                <li>
                  <div class="tit">계약번호</div>
                  <div class="txt auto t-blue">202106470997</div>
                </li>
                <!-- 2021.03.22 (ver1.1) 예상금액 추가 -->
                <li>
                  <div class="tit">예상금액</div>
                  <div class="txt auto">18,000,000 ~ 20,000,000원 내외</div>
                </li>
                <li>
                  <div class="tit">주계약자</div>
                  <div class="txt auto">202C김현대 (010-****-5678)106470997</div>
                </li>
                <li>
                  <div class="tit">엔진/트림</div>
                  <div class="txt auto">AX00000O0 가솔린 2.5 5인승 2WD / Premium Choice</div>
                </li>
                <li>
                  <div class="tit">색상</div>
                  <div class="txt auto">외장  마테오블루  /  내장  쉬머링실버</div>
                </li>
                <li>
                  <div class="tit">선택옵션</div>
                  <div class="txt auto">
                      <ul class="list">
                        <li v-for="(item, index) in optList" :key="index">{{ item.opt }}</li>
                      </ul>
                  </div>
                </li>
                <li>
                  <div class="tit">탁송지역</div>
                  <div class="txt auto">서울특별시 강남구</div>
                </li>
              </ul>
            </div>
        </div>
      </div>
    </div>
   <!-- 신용카드 -->
    <div class="matching-box">
      <div class="box-wrap">
        <div class="box-tit">
            결제정보
        </div>
        <div class="box-desc">
            <div class="matching-list">
              <ul>
                <li>
                  <div class="tit">결제수단</div>
                  <div class="txt auto t-blue">신용카드</div>
                </li>
                <li>
                  <div class="tit">결제카드</div>
                  <div class="txt auto">현대카드(4668-****-****-*****)</div>
                </li>
                <li>
                  <div class="tit">결제일시</div>
                  <div class="txt auto">2021-01-04 오후 17:03:25</div>
                </li>
                <li>
                  <div class="tit">결제금액</div>
                  <div class="txt auto t-blue">100,000원</div>
                </li>
              </ul>
            </div>
        </div>
      </div>
    </div>
   <!-- 무통장입금 -->
    <div class="matching-box">
      <div class="box-wrap">
        <div class="box-tit">
            결제정보
        </div>
        <div class="box-desc">
            <div class="matching-list">
              <ul>
                <li>
                  <div class="tit">결제수단</div>
                  <div class="txt auto">무통장입금</div>
                </li>
                <li>
                  <div class="tit">입금계좌</div>
                  <div class="txt auto">KB국민은행  03545898851 (예금주 : 현대자동차)</div>
                </li>
                <li>
                  <div class="tit">결제금액</div>
                  <div class="txt auto t-blue">100,000원</div>
                </li>
                <li>
                  <div class="tit">입금기한</div>
                  <div class="txt auto"><span class="t-blue">2021년 01월 29일 까지</span> (미 입금 시 계약이 자동 취소됩니다.)</div>
                </li>
              </ul>
            </div>
        </div>
      </div>
    </div>
    <!-- 유의사항 -->
    <div class="matching-box">
      <div class="box-wrap">
        <div class="box-tit">
            유의사항
        </div>
        <div class="box-desc">
            <!-- 2021.04.08(ver1.1) 텍스트수정 마이페이지 색상변경 -->
          <ul class="bullet-list">
            <li>사전계약 차량은 추후 등록하신 주계약자 휴대전화 번호로 공식계약 일정을 공지합니다.</li>
            <li>공식계약 마감일 이내에 계약으로 전환해주세요.</li>
            <li>공식계약 일정 내 계약하지 않는 경우 자동으로 사전계약이 취소됩니다.</li>
            <li>추후 판매개시 및 공식계약 진행 시 차량 모델.옵션을 변경할 수 있습니다.</li>
            <li>자세한 사전계약내역 확인 및 계약 진행사항은 <v-btn type="nlink" to="/" class="t-blue">마이페이지</v-btn>에서 확인 가능합니다.</li>
          </ul>
        </div>
      </div>
    </div>
    <div class="btn-box">
      <v-btn type="nlink" to="/" class="btn lg blue r">홈으로 가기</v-btn>
    </div>
  </div>
</template>

<script>
export default {
  head() {
    return {
      title: '사전계약 > 완료',
    }
  },
  data(){
    return{
      optList:[
        {opt:'현대스마트센스'},
        {opt:'펫 패키지Ⅰ(강아지얼굴,소형)-모노민트'},
        {opt:'펫 패키지Ⅲ(소형)-모노옐로우'},
        {opt:'[N퍼포먼스 파츠] 인테리어 패키지'},
      ]
    }
  }
}
</script>
