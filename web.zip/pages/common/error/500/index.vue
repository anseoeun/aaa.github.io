<template>
  <div class="content error">
    <div class="error-wrap">
      <i class="icon-setup"></i>
      <div class="text-main">서버 에러가 발생하였습니다.</div>
      <div class="text-sub">
        서버 내부 사정으로 오류가 발생하여 접속이 불가능합니다.<br />잠시 후 다시 이용해주세요.<br /><strong>서비스 이용에 불편을 드려 죄송합니다.</strong>
      </div>
      <div class="btn-wrap">
        <v-btn class="btn lg blue r" type="nlink" to="/">홈으로</v-btn>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  head() {
    return {
      title: 'ERROR PAGE > NOT FOUND'
    }
  },
  components: {}
}
</script>
