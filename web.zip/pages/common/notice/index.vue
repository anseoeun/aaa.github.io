<template>
  <div class="content notice">
    <v-pageheader
      :top-breadcrumb="topBreadcrumb"
      page-title="공지사항"
      page-infotext="현대자동차에서 전해드리는 공지사항입니다."
    />

    <!-- list-board -->
    <div class="notice-list-wrap">
      <template v-if="noticeBoardList.length > 0">
        <ul>
          <li v-for="(item, index) in noticeBoardList" :key="index">
            <nuxt-link to="/" role="button">
              <div class="date">{{ item.date }}</div>
              <div class="desc">
                <div class="title">{{ item.title }}</div>
                <div class="cont">{{ item.cont }}</div>
                <div v-if="isNan(item.file)" class="file">{{ item.file }}</div>
              </div>
            </nuxt-link>
          </li>
        </ul>
        <v-pagination :total="100" />
      </template>
      <template v-else>
        <!-- 2021.03.24 (ver1.1) -->
        <div class="list-null">
          <p>등록된 공지사항이 없습니다.</p>
        </div>
      </template>
    </div>
  </div>
</template>

<script>
import { VPageheader, VPagination } from '~/components/element'

export default {
  head() {
    return {
      title: '공지사항'
    }
  },
  components: {
    VPageheader,
    VPagination
  },
  data() {
    return {
      topBreadcrumb: [{ linkName: '공지사항', link: '/' }],
      noticeBoardList: [
        {
          date: '2021.03.04',
          title: '현대자동차 홈페이지 시스템 점검 일정 공지',
          cont:
            '안녕하세요. 현대자동차입니다. 항상 현대자동차를 아껴주시고 사랑해 주시는 회원 여러분께 감사드립니다. 더 안정적인 서비스를 위해 시스템 점검이 진행됨을 안내 드립니다. 점검 작업 동안 차량 계약정보 조회가 불가하오니 양해 부탁 드립니다. ■ 시스템 점검 일시 : 10/2(금) 08:00 ~ 10/5(월) 04:00',
          file: '첨부파일명.jpg'
        },
        {
          date: '2021.01.11',
          title: '21년도 보도사진 대행사 경쟁입찰 공고',
          cont:
            '안녕하세요. 현대자동차입니다. 현대자동차와 함께할 역량 있는 홍보 대행사를 모집합니다. 1. 대행사업 : 현대자동차 국내 관련 보도용 사진 촬영 일체 2. 대행기간 : 2021년 1월~ 2021년 12월 / 연간 (발생 건별 실비 정산) 3. 입찰 방법 : 제안서 서류 심사',
          file: ''
        },
        {
          date: '2020.09.24',
          title: '블루링크 서비스 일시 중지 안내',
          cont:
            '안녕하세요. 블루링크입니다. 현대자동차를 사랑해주시는 고객 여러분께 감사드립니다. 시스템 개선 작업으로 인해 블루링크 일부 서비스가 일시 중지됨을 알려드립니다. ■ 시스템 개선 일시 : 2020년 9월 25일(금) 01시 00분 ~ 04시 00분 ■ 대상 서비스 : 내 차 위치 공유 서비스',
          file: ''
        },
        {
          date: '2020.09.17',
          title: '블루멤버스 제휴처 점검 일정 공지 (현대해상)',
          cont:
            '안녕하세요. 블루멤버스입니다. 현대자동차를 사랑해 주시는 고객 여러분께 감사드립니다. 블루멤버스 제휴처인 현대해상의 시스템 점검으로 인하여 현대해상 하이카다이렉트와의 제휴서비스 제공이 잠시 중단될 예정입니다. 서비스 이용에 불편 없으시도록 참고하여 주시기 바랍니다.',
          file: '첨부파일명.jpg'
        },
        {
          date: '2020.08.07',
          title: '대자동차 개인정보 개인정보 처리방침(차량구매, 정비고객) 개정',
          cont:
            '안녕하세요. 현대자동차입니다. 현대자동차를 사랑해주시고 아껴주시는 회원 여러분께 감사드립니다. 현대자동차 개인정보 처리방침(차량구매, 정비고객)이 아래와 같이 변경됨을 알려 드립니다. ■ 개정 주요 내용 개인정보의 제 3자 제공 수정',
          file: ''
        }
      ]
    }
  },
  methods: {
    isNan(val) {
      return val != undefined && val != null && val != '' ? true : false
    }
  }
}
</script>
