<template>
  <div class="content notice">
    <v-pageheader
      :top-breadcrumb="topBreadcrumb"
      page-title="공지사항"
      page-infotext="현대자동차에서 전해드리는 공지사항입니다."
    />

    <div class="notice-board-view">
      <div class="board-view-info">
        <ul>
          <li>
            <div class="board-title">제목</div>
            <div class="info-title">블루링크 서비스 일시 중지 안내</div>
          </li>
          <li>
            <div class="board-title">날짜</div>
            <div class="info-date">2021.03.08</div>
          </li>
          <li>
            <div class="board-title">첨부파일</div>
            <ul v-if="noticeImgList.length > 0" class="file-wrap">
              <li v-for="(file, index) in noticeImgList" :key="index">
                <v-btn type="button">{{ file.fileName }}</v-btn>
              </li>
            </ul>
            <p v-else>첨부파일이 없습니다.</p>
          </li>
        </ul>
        <v-btn class="btn page-share" @click="popShare = true"><span class="offscreen">공유하기</span></v-btn>
      </div>
      <div class="board-view-cont">
        <div class="board-title">내용</div>
        <div class="info-cont">
          안녕하세요. 블루링크입니다<br />현대자동차를 사랑해주시는 고객 여러분께 감사드립니다.<br /><br />시스템 개선
          작업으로 인해 블루링크 일부 서비스가 일시 중지됨을 알려드립니다.<br /><br />■ 시스템 개선 일시 : 2020년 9월
          25일(금) 01시 00분 ~ 04시 00분<br />■ 대상 서비스 : 내 차 위치 공유 서비스<br /><br />고객님께 불편을 끼쳐드려
          죄송합니다.<br />서비스 품질 향상을 위한 불가피한 조치이오니 고객님의 너그러운 양해 부탁드립니다.<br /><br />감사합니다.
        </div>
      </div>
      <div class="board-list-box">
        <ul>
          <li>
            <div class="board-title">이전</div>
            <nuxt-link to="/">21년도 보도사진 대행사 경쟁입찰 공고</nuxt-link>
          </li>
          <li>
            <div class="board-title">다음</div>
            <nuxt-link to="/">21년도 보도사진 대행사 경쟁입찰 공고</nuxt-link>
          </li>
        </ul>
      </div>
      <div class="board-btn-wrap">
        <v-btn type="button" class="btn lg blue r">목록</v-btn>
      </div>
    </div>

    <!-- 팝업 -->
    <notice-share :visible="popShare" @close="popShare = false" />
  </div>
</template>

<script>
import { VPageheader } from '~/components/element'
import NoticeShare from '~/components/page/notice/PopNoticeShare'

export default {
  head() {
    return {
      title: '공지사항'
    }
  },
  components: {
    VPageheader,
    NoticeShare
  },
  data() {
    return {
      topBreadcrumb: [{ linkName: '공지사항', link: '/' }],
      popShare: false,
      noticeImgList: [{ fileName: '첨부파일명.jpg' }]
    }
  }
}
</script>
