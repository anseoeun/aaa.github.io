<template>
  <div class="content agreement">
    <v-pageheader :top-breadcrumb="topBreadcrumb" page-title="AX 홈페이지 이용 약관" />
    <div class="title-date">
      <v-select v-model="selectListVal" :data="selectList" class="no-st" />
      <v-btn class="btn md white r" type="button">선택</v-btn>
    </div>
    <div class="agreement-wrap">
      <div class="agreement-inner">
        <div class="list_law">
          <!-- 현대닷컴 이용약관 동일(https://www.hyundai.com/kr/ko/agreements) -->
          기획TBD
        </div>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  head() {
    return {
      title: '이용약관'
    }
  },
  components: {},
  data() {
    return {
      topBreadcrumb: [{ linkName: '이용약관', link: '/' }],
      selectListVal: 'select1',
      selectList: [
        { value: 'select1', label: '2020년 10월 27일 ~ 현재' },
        { value: 'select2', label: '2019년 02월 13일 ~ 2020년 10월 26일' },
        { value: 'select3', label: '2017년 12월 28일 ~ 2019년 02월 12일' }
      ]
    }
  }
}
</script>
