<template>
  <div class="content agreement">
    <v-pageheader :top-breadcrumb="topBreadcrumb" page-title="AX 홈페이지 개인정보 처리방침 (차량구매)" />
    <div class="title-date">
      <v-select v-model="selectListVal" :data="selectList" class="no-st" />
      <v-btn class="btn md white r" type="button">선택</v-btn>
    </div>
    <div class="agreement-wrap">
      <div class="agreement-inner">
        <div class="list_law">
          <!-- 현대닷컴 개인정보처리방침 동일(https://www.hyundai.com/kr/ko/agreements) -->
          기획TBD
        </div>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  head() {
    return {
      title: '개인정보처리방침'
    }
  },
  components: {},
  data() {
    return {
      topBreadcrumb: [{ linkName: '개인정보처리방침', link: '/' }],
      selectListVal: 'select1',
      selectList: [
        { value: 'select1', label: '2021년 03월 05일 ~ 현재' },
        { value: 'select2', label: '2021년 02월 01일  ~ 2021년 03월 04일' },
        { value: 'select3', label: '2020년 12월 07일  ~ 2021년 01월 31일' },
        { value: 'select4', label: '2020년 08월 10일  ~ 2020년 12월 06일' },
        { value: 'select5', label: '2020년 07월 29일  ~ 2020년 08월 09일' },
        { value: 'select6', label: '2020년 04월 24일  ~ 2020년 07월 28일' },
        { value: 'select7', label: '2019년 06월 25일  ~ 2020년 04월 23일' },
        { value: 'select8', label: '2019년 02월 08일  ~ 2019년 06월 24일' },
        { value: 'select9', label: '2019년 01월 01일  ~ 2019년 02월 07일' },
        { value: 'select10', label: '2018년 11월 27일  ~ 2018년 12월 31일' },
        { value: 'select11', label: '2017년 11월 01일  ~ 2018년 11월 26일' }
      ]
    }
  }
}
</script>
