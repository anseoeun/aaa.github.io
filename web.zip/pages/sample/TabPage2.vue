<template>
  <div class="">TabPage2</div>
</template>

<script>
export default {
  name: 'TabPage2',
  data() {
    return {}
  },
}
</script>

<style lang="scss"></style>
