<template>
  <div id="TabPage1">TabPage1</div>
</template>

<script>
export default {
  name: 'TabPage1',
  layout: 'Layout',
  data() {
    return {}
  },
  mounted() {
    // console.log(this.$el)
    // this.$emit('page', value)
  },
}
</script>

<style lang="scss"></style>
