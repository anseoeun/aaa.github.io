<template>
  <div style="width: 1200px; margin: 0 auto; padding: 30px 0">
    <v-pageheader
      :top-breadcrumb="topBreadcrumb"
      page-title="AX 사전계약"
      page-infotext="온라인에서 진행하는 ooooooo의 사전 계약을 시작합니다."
    >
      <div class="term">사전계약기간 : 2021.01.31 ~ 2021. 03.30</div>
    </v-pageheader>

    <h2 style="font-size:20px;font-weight: 500;margin-top:20px;">텍스트</h2>

    <br />

    <p class="bullet">면세구분 선택에 따라 개별소비세 과세/면세가 계산되어 차량 총 견적 금액에 적용됩니다.</p>

    <br />

    <ul class="bullet-list">
      <li>등록비는 견적금액에 포함되지 않습니다.</li>
      <li>공채 할인금액은 지자체별 할인율이 매일 변동됨에 따라 실제와 다소 차이가 있을 수 있습니다.</li>
      <li>차량번호판과 등록대행수수료는 지역별로 차이가 있으므로 단순 참고만 하시기 바랍니다.</li>
    </ul>

    <br />

    <ul class="bullet-star-list">
      <li>
        모델, 색상, 옵션 등 차량 정보를 변경할 수 있습니다. [차량정보 변경] 버튼을 클릭하고 나만의 캐스퍼 만들기로
        이동하여 다른 사양으로 변경해 보세요
      </li>
      <li>차량정보 변경은 결제 전까지 언제든 가능합니다. 단, 변경하시는 품목에 따라 차량 가격이 달라질 수 있습니다.</li>
    </ul>

    <br />

    <p class="bullet-star">아래 사항을 반드시 확인해 주세요.</p>

    <br />

    <div class="content-box">
      <strong class="title">유의사항</strong>
      <ul class="bullet-list">
        <li>
          본 견적서는 고객님의 차량 구입(청약) 의사결정에 도움을 드리고자 작성된것으로, 계약을 원하실 경우 계약하기를
          선택 후 계약을 완료하셔야 합니다.
        </li>
        <li>
          실제 계약 내용은 고객께서 청약하실 시점의 판매조건이나 캐피탈사의 대출 조건에 따라 본 견적 내용과 달라질 수
          있습니다.
        </li>
        <li>
          세이브오토는 당사와 제휴사와의 별도 약정에 따라 차량대금의 일부를 선 지급해드리는 상품으로 향후 고객께서
          포인트를 적립하여 상환하여야 하며, 별도 신청서 상의 소정 요건을 충족 시키지 못할 경우 미상환액을 현금으로
          상환하셔야 합니다.
        </li>
        <li>
          표시된 예상출고일은 견적 시점에서 계산된 것이므로 계약시점에 따라 달라질 수 있으며, 당사 사정에 따라 변경될 수
          있습니다.
        </li>
        <li>
          탁송료 및 공제할인율은 출고지, 등록일에 따라서 변경될 수 있습니다. 등록대행 수수료는 당사에 등록을 의뢰하실
          경우 발생되는 항목이며 의뢰지역, 의뢰방법에 따라 달라질 수 있습니다.
        </li>
      </ul>
    </div>

    <br />

    <div class="info-grid-list">
      <ul>
        <li>
          <strong class="info-title">모델명</strong>
          <div class="info-group">AX 자가용 5인승 가솔린 1.6 2WD IVT Smart</div>
        </li>
        <li>
          <strong class="info-title">계약완료일</strong>
          <div class="info-group">2021.08.10</div>
        </li>
        <li>
          <strong class="info-title">외장색상</strong>
          <div class="info-group">그레이</div>
        </li>
        <li>
          <strong class="info-title">선택품목</strong>
          <div class="info-group">스마트스트림 가솔린 1.6 엔진 외 5개</div>
        </li>
        <li>
          <strong class="info-title">계약금액</strong>
          <div class="info-group">
            <span class="price">100,000원</span>
          </div>
        </li>
        <li class="t-blue">
          <strong class="info-title">예상출고일</strong>
          <div class="info-group">2019.05.01</div>
        </li>
      </ul>
    </div>

    <br />

    <div class="matching-box">
      <div class="box-wrap">
        <div class="box-tit full">기본 사항</div>
        <div class="box-desc full">
          <div class="info-grid-list">
            <ul class="default-info">
              <li>
                <strong class="info-title">증빙서류</strong>
                <div class="info-group">
                  <ul class="desc-list">
                    <li>
                      <em>목록</em>
                      <v-btn class="btn-more last">증빙서류 제출하기</v-btn>
                    </li>
                    <li>주민등록등본</li>
                    <li>4대 보험 가입 확인서</li>
                  </ul>
                </div>
              </li>
              <li>
                <strong class="info-title">무통장입금 정보</strong>
                <div class="info-group">
                  <ul class="desc-list">
                    <li>
                      <em>계좌번호</em>
                      <div class="last">
                        <span class="bank-company">신한은행</span>
                        <span>900252282042</span>
                      </div>
                    </li>
                    <li>
                      <em>예금주</em>
                      <p class="last">홍길동_현대자동차</p>
                    </li>
                    <li>
                      <em>입금액</em>
                      <p class="price">2,000,000 원</p>
                    </li>
                  </ul>
                </div>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>

    <br />

    <div class="list-null">
      <i class="icon-doc-none"></i>
      <p>구매 내역이 없습니다.</p>
    </div>

    <div class="list-null">
      <i class="icon-coupon-none"></i>
      <p>사용 가능한 쿠폰이 없습니다.</p>
    </div>

    <br />

    <div class="matching-box">
      <div class="box-wrap">
        <div class="box-tit full">자주하는 질문</div>
        <div class="box-desc full">
          <div class="toggle-list">
            <v-list-group v-model="subSelected" :accordion="true">
              <v-list-item v-for="(item, index) in faqList" :key="index" :data-id="String(index + 1)">
                <template slot="label">
                  <span class="list-category">{{ item.category }}</span>
                  <span class="list-content"><span v-html="item.title"></span></span>
                </template>
                <div v-html="item.content"></div>
              </v-list-item>
            </v-list-group>
          </div>
        </div>
      </div>
    </div>

    <br />

    <div class="agree-check">
      <el-form ref="identifyForm" :model="ruleForm" :rules="rules">
        <div prop="type">
          <el-form-item prop="agreeCheck">
            <v-checkbox v-model="ruleForm.agreeCheck" :data="agreeCheckData1" />
          </el-form-item>
          <el-form-item prop="agreeCheck">
            <v-checkbox v-model="ruleForm.agreeCheck" :data="agreeCheckData2" />
          </el-form-item>
        </div>
      </el-form>
    </div>

  </div>
</template>
<script>
export default {
  data() {
    return {
      topBreadcrumb: [
        { linkName: '계약하기', link: '/' },
        { linkName: '결제하기', link: '/' }
      ],
      subSelected: [],
      faqList: [
        {
          seq: 1,
          category: `[차량구매]`,
          title: `차량 계약 후 해지시 계약금은 환불 받을 수 있습니까?`,
          content: `<div class="faq-cont">즉시출고차, 할인차, 전시차, 판촉차, 생산주문 차량의 경우 차량 대금 결제 전, 마이페이지에서 계약 해약 시 계약금 환불이 가능합니다. 하지만 특별주문 차량의 경우 계약 해지시 계약금 환불이 불가합니다. 계약금을 현금으로 납부하셨다면 계약 해지시 입력하신 환불계좌로 계약금이 환불되며, 계약금을 카드로 납부하셨다면 7일 이내 카드 결제가 취소 됩니다.</div>`
        },
        {
          seq: 2,
          category: `[차량구매]`,
          title: `차량 구입시 신용카드는 여러개의 카드로 결제가 가능한가요?`,
          content: `<div class="faq-cont">즉시출고차, 할인차, 전시차, 판촉차, 생산주문 차량의 경우 차량 대금 결제 전, 마이페이지에서 계약 해약 시 계약금 환불이 가능합니다. 하지만 특별주문 차량의 경우 계약 해지시 계약금 환불이 불가합니다. 계약금을 현금으로 납부하셨다면 계약 해지시 입력하신 환불계좌로 계약금이 환불되며, 계약금을 카드로 납부하셨다면 7일 이내 카드 결제가 취소 됩니다.</div>`
        },
        {
          seq: 3,
          category: `[차량구매]`,
          title: `장애인 면세 공동명의로 차량 구입하려고 하는데 장애인을 외1인으로 해도 되나요?`,
          content: `<div class="faq-cont">즉시출고차, 할인차, 전시차, 판촉차, 생산주문 차량의 경우 차량 대금 결제 전, 마이페이지에서 계약 해약 시 계약금 환불이 가능합니다. 하지만 특별주문 차량의 경우 계약 해지시 계약금 환불이 불가합니다. 계약금을 현금으로 납부하셨다면 계약 해지시 입력하신 환불계좌로 계약금이 환불되며, 계약금을 카드로 납부하셨다면 7일 이내 카드 결제가 취소 됩니다.</div>`
        }
      ],
      ruleForm: {
        agreeCheck: [],
      },
      agreeCheckData1: [
        { value: 'agree', label: '본인은 귀사가 상기 목적으로 본인의 개인정보를 수집·이용하는 것에 동의합니다.' },
      ],
      agreeCheckData2: [
        { value: 'agree', label: '본인은 귀사가 상기 목적으로 상기 보유·이용 기간 동안 본인의 고유식별정보(주민등록번호, 운전면허번호, 여권번호, 외국인등록번호)를 수집·이용하는 것에 동의합니다.' },
      ],
    }
  },
  computed: {
    rules() {
      return {
        agreeCheck: [
          {
            required: true,
            message: '* 약관에 동의해 주세요.',
            trigger: 'change'
          }
        ],
      }
    }
  },
}
</script>

<style lang="scss">
@import '~/assets/style/shop.scss';
</style>
