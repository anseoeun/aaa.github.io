<template>
  <div class="samplePage">

      <ul class="select-mix">
        <li :class="{active: methodVal === 1}"> <v-btn class="chk" @click="checkMethod(1)">캐시백 1.3</v-btn> </li>
        <li :class="{active: methodVal === 2}"> <v-btn class="chk" @click="checkMethod(2)">포인트적립 1.5</v-btn> </li>
        <li :class="{active: methodVal === 3}">
          <el-dropdown trigger="click" class="chk">
            <span>
              <span>{{ interestCaseLabel }}</span> <i class="el-icon-arrow-down el-icon--right"></i>
            </span>
            <el-dropdown-menu slot="dropdown">
              <el-dropdown-item v-for="(item, index) in interestList" :key="index"><v-btn @click="checkMethod(3, item)">{{ item.label }}</v-btn></el-dropdown-item>
            </el-dropdown-menu>
          </el-dropdown>
        </li>
      </ul>

  </div>
</template>

<script>
export default {
  components: {},
  data() {
    return {
      methodVal:'',
      interestVal:'',
      interestCaseLabel : '무이자 할부',
      interestList: [
        {value: 'val1', label: '무이자(2개월)'},
        {value: 'val2', label: '무이자(3개월)'},
        {value: 'val3', label: '무이자(6개월)'},
        {value: 'val4', label: '무이자(12개월)'},
      ]
    }
  },
  watch: {},
  mounted() {},

  methods: {
    setInterest(item){
      this.interestCaseLabel = item.label
    },
    checkMethod(val, item){
      this.methodVal = val
      this.interestVal = ''
      if(val === 3){
        this.setInterest(item)
        this.interestVal = item.value
      }
    }

  }
}
</script>
