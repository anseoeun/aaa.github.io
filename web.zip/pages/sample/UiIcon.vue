<template>
  <div class="icon-sample">
    <div class="box">
      <strong>로고</strong>
      <ul>
        <li>
          <p>@include logoBlack</p>
          <div class="logo-sample1"></div>
        </li>
        <li>
          <p>@include logoGray</p>
          <div class="logo-sample2"></div>
        </li>
        <li>
          <p>@include logoWhite</p>
          <div class="logo-sample3"></div>
        </li>
      </ul>
    </div>
    <div class="box">
      <strong>엑스버튼</strong>
      <ul>
        <li>
          <p>@include btnClose</p>
          <div class="btn-close"></div>
        </li>
      </ul>
    </div>
    <div class="box">
      <strong>화살표</strong>
      <ul>
        <li>
          <p>@include arrowSimpleLeft</p>
          <div class="arrow-rolling-left"></div>
        </li>
        <li>
          <p>@include arrowSimpleRight</p>
          <div class="arrow-rolling-right"></div>
        </li>
        <li>
          <p>@include arrowLink</p>
          <div class="arrow-link"></div>
        </li>
        <li>
          <p>@include arrowRoundRight</p>
          <div class="arrow-round-right"></div>
        </li>
      </ul>
    </div>
    <div class="box">
      <strong>아이콘</strong>
      <ul>
        <li>
          <p>@include icoMypage</p>
          <div class="icon-mypage"></div>
        </li>
        <li>
          <p>@include icoNotice</p>
          <div class="icon-notice"></div>
        </li>
        <li>
          <i class="icon-info"></i>
        </li>
        <li>
          <i class="icon-help"></i>
        </li>
        <li>
          <i class="icon-x"></i>
        </li>
        <li>
          <i class="icon-check"></i>
        </li>
        <li>
          <i class="icon-open"></i>
        </li>
        <li>
          <i class="icon-open-arrow"></i>
        </li>
        <li>
          <i class="icon-search"></i>
        </li>
        <li>
          <i class="icon-expiration"></i>
        </li>
      </ul>
      <ul>
        <li>
          <i class="icon-doc-check"></i>
        </li>
        <li>
          <i class="icon-doc-none"></i>
        </li>
        <li>
          <i class="icon-tog-arr"></i>
          <i class="icon-tog-arr on"></i>
          <i class="icon-tog-arr off-gray"></i>
          <i class="icon-tog-arr on off-gray"></i>
        </li>
      </ul>
    </div>
  </div>
</template>

 <style lang="scss" scoped>
  /* 삭제 예정 */
  .icon-sample { width: 1000px; margin: 0 auto; padding: 30px 0; }
  .icon-sample .box + .box { margin-top: 30px; }
  .icon-sample .box strong { display: block; margin-bottom: 10px; }
  .icon-sample .box ul { @include flexbox; border-left: 1px solid #ccc;}
  .icon-sample .box ul li { @include sizing; width: 25%; padding: 20px; text-align: center; border: 1px solid #ccc; border-left: 0; background: #eee; }
  .icon-sample .box ul li p { margin-bottom: 10px; }

  .logo-sample1 { @include logoBlack; }
  .logo-sample2 { @include logoGray; }
  .logo-sample3 { @include logoWhite; }
</style>