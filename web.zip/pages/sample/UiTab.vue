<template>
  <div class="tab-default tab-wrap">
    <div class="tab-menu">
      <ul>
        <li :class="{ active: tabList == '1' }">
          <v-btn
            @click="tabList = '1'"
          >신용카드 </v-btn>
        </li>
        <li :class="{ active: tabList == '2' }">
          <v-btn
            @click="tabList = '2'"
          >무통장 입금</v-btn>
        </li>
      </ul>
    </div>
    <div class="tab-contents">
      <template v-if="tabList == '1'">
        신용카드 탭 내용
      </template>
      <template v-if="tabList == '2'">
        무통장 입금 탭 내용
      </template>
    </div>
  </div>
</template>

<script>
export default {
  components: {},
  data() {
    return {
      tabList: '1',
    }
  },
  watch: {},
  mounted() {},

  methods: {

  }
}
</script>
