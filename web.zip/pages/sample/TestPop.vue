<template>

  <v-popup
    :visible="visible"
    @close="
      $emit('close')
    "
  >
    <template slot="header">
      <div class="title">타이틀1</div>
      <p class="header-description">타이틀설명111111111111111111</p>
    </template>
    <template slot="body">팝업내용1</template>
    <template slot="footer">
        <div class="btn-group">
          <v-btn class="btn" b-size="btn-md" @click="$emit('test')">테스트버튼</v-btn>
        </div>
    </template>
  </v-popup>
</template>

<script>
import { VPopup } from '~/components/element'
export default {
  components: {
    VPopup
  },
  props: {
    visible: {
      type: Boolean,
      default: false
    },
    data: {
      type: Object,
      default: () => {}
    }
  },

}
</script>

