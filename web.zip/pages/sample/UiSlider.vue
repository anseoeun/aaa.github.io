<template>
  <div class="samplePage">
    <v-carousel :custom-item="true" height="300px" :autoplay="true" indicator-position="outside">
      <template>
        <el-carousel-item>
          <img
            src="https://tep.hmc.co.kr/static/images/model/g70/20fl/g70_performance_awd_lsd_integrated_control_system.jpg"
            alt="G70 AWD + LSD 통합 제어 시스템"
          />
        </el-carousel-item>
        <el-carousel-item>
          <img
            src="https://tep.hmc.co.kr/static/images/model/g70/20fl/g70_performance_variable_exhaust_muffler.jpg"
            alt="G70 AWD + LSD 통합 제어 시스템"
          />
        </el-carousel-item>
      </template>
    </v-carousel>

    <v-carousel
      :data="slideList"
      height="300px"
    >
      <template slot-scope="props">
        <div class="event-item">
          <div class="event-item-info">
            <h3>{{ props.item.title }}</h3>
            <p>{{ props.item.desc }}</p>
          </div>
        </div>
      </template>
    </v-carousel>

    <!-- <v-carousel :custom-item="true" height="138px"  class="faq-box">
      <el-carousel-item
        v-for="(data, index) in faqQuestions"
        :key="index"
        class="list"
      >
        <div class="question-number">Q 0{{ index + 1 }}</div>
        <div class="question-text">
          {{ data.faqQuestion }}
        </div>
      </el-carousel-item>
    </v-carousel> -->

    <h2> 신규슬라이더 </h2>
    <v-carousel-new
        :data="slideList"
        :pagination="true"
        :navigation="true"
    >
    <!--
        :autoPlay="true"
        :infiniteScroll="true"
        -->
    <template slot-scope="props">
        <div class="event-item">
            <h3>{{ props.item.title }}</h3>
            <p>{{ props.item.desc }}</p>
        </div>
    </template>
    </v-carousel-new>

    <v-carousel-new
    class="btm-nav-paging"
        :data="slideList"
        :pagination="true"
        :navigation="true"

        style="height:200px"
    >
        <!--
            :autoPlay="true"
            :infiniteScroll="true"
            -->
        <template slot-scope="props">
            <div class="event-item">
                <h3>{{ props.item.title }}</h3>
                <p>{{ props.item.desc }}</p>
            </div>
        </template>
        </v-carousel-new>

    <v-carousel-new
    class="btm-nav-paging"
        :data="slideList"
        :pagination="true"
        :navigation="true"
        :items-to-show="3"
        :items-to-slide="3"
        :touch-drag="false"
        :infinite-scroll="true"
        style="height:200px"
    >
        <template slot-scope="props">
            <div class="event-item">
                <h3>{{ props.item.title }}</h3>
                <p>{{ props.item.desc }}</p>
            </div>
        </template>
        </v-carousel-new>


    <!-- custom -->
    <v-carousel-new
        :data="slideList"
        :items-to-show="2"
        :pagination="true"
        :navigation="true"
        :custom-item="4"
        :page-number="true"
    >
      <template slot="slide1">
        슬라이드1
     </template>
      <template slot="slide2">
        슬라이드2
     </template>
      <template slot="slide3">
        슬라이드3
     </template>
      <template slot="slide4">
        슬라이드4
     </template>
    </v-carousel-new>
  </div>
</template>

<script>
import { VCarouselNew} from '~/components/element'
export default {
  name: 'UiSlider',
  components: {
    VCarouselNew,
  },
  data() {
    return {
      // 슬라이드
      slideList: [
        {
          title: 'VENUE1',
          desc: '혼라이프 SUV, VENUE를 만나보세요.',
          bg: 'red',
          routeName: '',
        },
        {
          title: 'VENUE1',
          desc: '혼라이프 SUV, VENUE를 만나보세요.',
          bg: 'red',
          routeName: '',
        }
      ],
      faqQuestions: [
        {
          faqCode: '001',
          faqQuestion: '차량에 부과되는 세금은 어떤 종류가 있나요?',
        },
        {
          faqCode: '002',
          faqQuestion: '탬퍼러리 타이어(임시 타이어)를 적용하는 이유는 뭔가요?',
        },
        {
          faqCode: '003',
          faqQuestion: '인터넷으로 정비예약은 어떻게 하는건가요?',
        },
        {
          faqCode: '004',
          faqQuestion:
            '냉매량이 부족한지 에어컨 냉방성능이 떨어진 것 같습니다.',
        },
        {
          faqCode: '005',
          faqQuestion: '에어백을 장착하는게 오히려 사고 시 위험한가요?',
        },
      ],
    }
  },
}
</script>
<style lang="scss">

/* hooper bottom page arrow type */
.btm-nav-paging .hooper {
  height: 100%;
  .hooper-navigation {
    position: absolute;
    bottom: 0;
    left: 50%;
    text-align: center;
    transform: translateX(-50%);
    -webkit-transform: translateX(-50%);
    button {
      position: relative;
      padding: 0;
      top: 0;
      transform: translateY(0);
      -webkit-transform: translateY(0);
    }
  }
  .hooper-pagination {
    position: absolute;
    bottom: 0;
    left: 50%;
    text-align: center;
    transform: translateX(-50%);
    -webkit-transform: translateX(-50%);
    .hooper-indicators {
      position: absolute;
      bottom: 0;
      left: 50%;
      text-align: center;
      transform: translateX(-50%);
      -webkit-transform: translateX(-50%);
    }
  }
}
</style>