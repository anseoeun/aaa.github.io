<template>
  <div class="samplePage">
    <v-btn @click="popVisible.postCode = true">우편번호 팝업오픈</v-btn>
    <br />
    <v-btn @click="testPop = true">테스트 오픈</v-btn>
    <br />
    <v-btn @click="overviewEvidencesPop = true">OverviewEvidences</v-btn>

    <post-code :pop-visible="popVisible" />
    <overview-evidences :visible="overviewEvidencesPop"
      @close="overviewEvidencesPop = false"
     />
     <test-pop :visible="testPop" @close="testPop = false" @test="testPop = false, popVisible.postCode = true"></test-pop>
  </div>
</template>


<script>
import PostCode from '~/components/common/PostCode'
import OverviewEvidences from '~/components/page/mypage/purchase-list/OverviewEvidences'
import TestPop from '~/pages/sample/TestPop'
export default {
  components: {
    PostCode,
    OverviewEvidences,
    TestPop
  },
  data() {
    return {
      overviewEvidencesPop: false,
      testPop: false,
      popVisible: {
        postCode : false,
      }
    }
  },
  watch: {},
  mounted() {},

  methods: {

  }
}
</script>
