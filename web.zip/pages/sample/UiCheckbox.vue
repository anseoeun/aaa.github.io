<template>
  <div class="samplePage">
    <h2>리스트형으로 사용시</h2>
    <v-checkbox v-model="checkboxDataVal2" :data="checkboxListData2" all-chk-name="전체체크" />

    <br />

    <h2>단독 + 리스트형으로 사용시 (methods 필요)</h2>
    <v-checkbox :one-check="true" :checked.sync="allCheck" @change="allCheckChange"
      >전체체크</v-checkbox>
    <v-checkbox v-model="checkboxDataVal" :data="checkboxListData" @change="checkChange" />

    <br />

    <h2>팝업열림</h2>
    <v-checkbox :one-check="true" :checked.sync="checkboxBenefit" @change="popOpen">이번 계약에서 혜택 받기</v-checkbox>
    <flexible-warranty-service
          :visible="popVisible.flexibleWarrantyService"
          @close="popVisible.flexibleWarrantyService = false"
        ></flexible-warranty-service>

  </div>
</template>

<script>
import { VCheckbox} from '~/components/element'

import FlexibleWarrantyService from '~/components/page/contract/popup/FlexibleWarrantyService'

export default {
  name: 'UiComponent',
  components: {
    VCheckbox,
    FlexibleWarrantyService,
  },
  data() {
    return {
      allCheck: false,
      checkboxDataVal: [],
      checkboxListData: [
        { value: 'check1', label: '체크박스1'},
        { value: 'check2', label: '체크박스2'},
        { value: 'check3', label: '체크박스3'},
        { value: 'check4', label: '체크박스4'},
      ],
      checkboxDataVal2: [],
      checkboxListData2: [
        { value: 'check1', label: '체크박스1'},
        { value: 'check2', label: '체크박스2'},
        { value: 'check3', label: '체크박스3'},
        { value: 'check4', label: '체크박스4'},
      ],

      popVisible: {
        flexibleWarrantyService: false,
      },
      checkboxBenefit: false
    }
  },

  mounted() {

  },
  methods: {
    allCheckChange() {
    if(this.allCheck){
        let val = []
        this.checkboxListData.forEach((value, index) => {
            val.push(value.value)
        })
        this.allCheck = true
        this.checkboxDataVal = val
      }else{
       this.allCheck = false
       this.checkboxDataVal = []
      }
    },
    checkChange() {
      if(this.checkboxListData.length !== this.checkboxDataVal.length) {
         this.allCheck = false
      }else{
         this.allCheck = true
      }
    },
    popOpen(){
      if(this.checkboxBenefit) {
        this.popVisible.flexibleWarrantyService = true
      }
    }
  },
}
</script>

