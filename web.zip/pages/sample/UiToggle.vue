<template>
  <div class="samplePage">
    <h2>토글 리스트 v-for</h2>
    <ul>
      <li v-for="(item, index) in dataList" :key="index">
        <div>
          <div class="tit">
            {{ item.txt }}
          </div>
          <div class="desc">
            <div class="right">
              <v-btn type="icon" :icon-class="['icon-tog-arr', { on: isAct(index) }]" @click="setAct(index)"
                >버튼</v-btn
              >
            </div>
          </div>
        </div>
        <div v-if="isAct(index)">
          <div style="height:100%;background:#f9f9f9">영역</div>
        </div>
      </li>
    </ul>

    <h2>토글 리스트</h2>
    <ul>
      <li>
        <div>
          <div class="tit">텍스트</div>
          <div class="desc">
            <div class="right">
              <v-btn type="icon" :icon-class="['icon-tog-arr', { on: isAct(0) }]" @click="setAct(0)">버튼</v-btn>
            </div>
          </div>
        </div>
        <div v-if="isAct(0)">
          <div style="height:100%;background:#f9f9f9">영역</div>
        </div>
      </li>
      <li>
        <div>
          <div class="tit">텍스트</div>
          <div class="desc">
            <div class="right">
              <v-btn type="icon" :icon-class="['icon-tog-arr', { on: isAct(1) }]" @click="setAct(1)">버튼</v-btn>
            </div>
          </div>
        </div>
        <div v-if="isAct(1)">
          <div style="height:100%;background:#f9f9f9">영역</div>
        </div>
      </li>
      <li>
        <div>
          <div class="tit">텍스트</div>
          <div class="desc">
            <div class="right">
              <v-btn type="icon" :icon-class="['icon-tog-arr', { on: isAct(2) }]" @click="setAct(2)">버튼</v-btn>
            </div>
          </div>
        </div>
        <div v-if="isAct(2)">
          <div style="height:100%;background:#f9f9f9">영역</div>
        </div>
      </li>
    </ul>

    <h2>토글 리스트 하나만 열림</h2>
    <ul>
      <li>
        <div>
          <div class="tit">텍스트</div>
          <div class="desc">
            <div class="right">
              <v-btn type="icon" :icon-class="['icon-tog-arr', { on: isOptionsShow == 0 }]" @click="setActive(0)">버튼</v-btn>
            </div>
          </div>
        </div>
        <div v-if="isOptionsShow == 0">
          <div style="height:100%;background:#f9f9f9">영역</div>
        </div>
      </li>
      <li>
        <div>
          <div class="tit">텍스트</div>
          <div class="desc">
            <div class="right">
              <v-btn type="icon" :icon-class="['icon-tog-arr', { on: isOptionsShow == 1 }]" @click="setActive(1)">버튼</v-btn>
            </div>
          </div>
        </div>
        <div v-if="isOptionsShow == 1">
          <div style="height:100%;background:#f9f9f9">영역</div>
        </div>
      </li>
      <li>
        <div>
          <div class="tit">텍스트</div>
          <div class="desc">
            <div class="right">
              <v-btn type="icon" :icon-class="['icon-tog-arr', { on: isOptionsShow == 2 }]" @click="setActive(2)">버튼</v-btn>
            </div>
          </div>
        </div>
        <div v-if="isOptionsShow == 2">
          <div style="height:100%;background:#f9f9f9">영역</div>
        </div>
      </li>
    </ul>
  </div>
</template>

<script>
export default {
  components: {},
  data() {
    return {
      dataList: [{ txt: '텍스트' }, { txt: '텍스트' }, { txt: '텍스트' }],
      listSelected: [false, false, false],
      isOptionsShow: -1
    }
  },
  watch: {},
  mounted() {},

  methods: {
    //모두열리는 타입
    setAct(index) {
      if (this.listSelected[index] === false) {
        this.$set(this.listSelected, index, true)
      } else {
        this.$set(this.listSelected, index, false)
      }
    },
    isAct(index) {
      return this.listSelected[index] === true
    },

    //하나만열리는 타입
    setActive(index){
      if(this.isOptionsShow == index){
        this.isOptionsShow = -1
      }else{
        this.isOptionsShow = index
      }
    },
  }
}
</script>
