<template>
  <!-- 공유견적보기와 동일 (헤더,풋터제거) -->
  <!-- 2021.03.22 (ver1.1) 수정 -->
  <div class="content estimate">
    <v-pageheader page-title="견적서" />
    <estimate-share type="download" />
  </div>
</template>

<script>
import VPageheader from '~/components/element/VPageheader'
import EstimateShare from '~/components/page/estimation/EstimateShare'
export default {
  layout: 'download',
  head() {
    return {
      title: '견적 > 견적서 다운로드'
    }
  },
  components: {
    VPageheader,
    EstimateShare
  },
  data() {
    return {}
  }
}
</script>
