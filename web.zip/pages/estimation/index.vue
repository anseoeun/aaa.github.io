<template>
  <div class="content estimate">
    <v-pageheader page-title="견적 내기" page-infotext="내 차의 상세견적을 보실 수 있습니다." />
    <div class="purchase-wrap">
      <div class="purchase-info">
        <div class="estimate-description">
          <div class="info-grid-list">
            <ul>
              <li>
                <strong class="info-title full">견적 번호</strong>
                <p class="info-group full">U00000040282</p>
              </li>
              <li>
                <!-- 2021.03.22 (ver1.1) 텍스트 수정 -->
                <strong class="info-title full">견적일</strong>
                <div class="info-group full">
                  2021년 1월 25일
                  <!-- 2021.03.22 (ver1.1) 텍스트 삭제 -->
                  <!-- <v-popover trigger="hover" placement="bottom-start">
                    <p>견적기준일 이후 재 견적 시 가격 및<br />정책 등의 변경에 의하여 같은 조건의 차량에<br />대한 견적이 일치하지 않을 수 있습니다.</p>
                    <v-btn slot="reference"><i class="icon-help"></i></v-btn>
                  </v-popover> -->
                </div>
              </li>
            </ul>
          </div>
          <div class="btn-desc">
            <v-btn class="btn" @click="popShare = true">공유하기</v-btn>
            <v-btn class="btn">PDF 다운로드</v-btn>
          </div>
        </div>
        <vehicle-options />
        <take-over />
        <sale-point />
        <!--  -->
        <!-- <tax-registration /> -->
        <payment />
        <registration-cost />
      </div>
      <estimate-tool />
    </div>

    <div class="banner-wrap">배너영역</div>
    <notice-info />
    <similar-recommend />

    <vehicle-best />

    <!-- 팝업 -->
    <estimate-share :visible="popShare" @close="popShare = false" />
  </div>
</template>

<script>
import VPageheader from '~/components/element/VPageheader'
import VehicleOptions from '~/components/page/estimation/VehicleOptions'
import TakeOver from '~/components/page/estimation/TakeOver'
import SalePoint from '~/components/page/estimation/SalePoint'
// import TaxRegistration from '~/components/page/estimation/TaxRegistration'
import Payment from '~/components/page/estimation/Payment'
import RegistrationCost from '~/components/page/estimation/RegistrationCost'
import NoticeInfo from '~/components/page/estimation/NoticeInfo'
import EstimateTool from '~/components/page/estimation/EstimateTool'
import SimilarRecommend from '~/components/page/estimation/SimilarRecommend'
import EstimateShare from '~/components/page/estimation/popup/EstimateShare'

import VehicleBest from '~/components/page/estimation/VehicleBest'

export default {
  head() {
    return {
      title: '견적 > 견적내기'
    }
  },
  components: {
    VPageheader,
    VehicleOptions,
    TakeOver,
    SalePoint,
    // TaxRegistration,
    Payment,
    RegistrationCost,
    NoticeInfo,
    EstimateTool,
    SimilarRecommend,
    EstimateShare,
    VehicleBest
  },
  data() {
    return {
      popShare: false
    }
  }
}
</script>