<template>
  <div class="content vehicles promotion">
    <v-pageheader
      page-title=""
    />
    <div class="promotion-wrap">


    </div>
  </div>
</template>

<script>
export default {
  head() {
    return {
      title: '탐색 > 차량상세',
    }
  },
  components: {
  },
  data() {
    return {

    }
  },
}
</script>