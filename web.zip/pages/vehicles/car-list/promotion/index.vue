<template>
  <div class="content vehicles promotion">
    <!-- 2021.03.09 (ver1.1) 기획전 종료 v-if추가 -->
    <v-pageheader v-if="!promotionEnd" page-title="기획전 타이틀" />

    <!-- 2021.03.09 (ver1.1) 기획전 종료 추가 -->
    <div v-if="promotionEnd" class="promotion-end">
      <div class="title">아쉽지만 본 기획전은 종료되었습니다.</div>
      <nuxt-link to="/" class="btn gray r lg">홈으로</nuxt-link>
    </div>

    <!-- 2021.03.09 (ver1.1) 기획전 종료 v-else추가 -->
    <div v-else class="promotion-wrap">
      <div class="promotion-top">
        <div class="take-over">
          <i class="icon-map"></i>
          나의 탁송지역 <span>서울시</span>
          <v-btn class="btn-more">변경</v-btn>
        </div>
        <div class="filter">
          <v-select v-model="filterSelect" :data="filterSelectList" class="no-st" />
        </div>
        <ul class="view-type">
          <li>
            <button type="button" :class="{ active: viewType === 'card-type' }" @click="viewType = 'card-type'">
              카드형
            </button>
          </li>
          <li>
            <button type="button" :class="{ active: viewType === 'list-type' }" @click="viewType = 'list-type'">
              리스트형
            </button>
          </li>
        </ul>
      </div>
      <div :class="viewType === 'card-type' ? 'card-type' : 'list-type'">
        <car-info />
      </div>
    </div>
  </div>
</template>

<script>
import CarInfo from '~/components/page/vehicles/list/CarInfo'
export default {
  head() {
    return {
      title: '탐색 > 기획전'
    }
  },
  components: {
    CarInfo
  },
  data() {
    return {
      filterSelect: 'select1',
      filterSelectList: [
        { value: 'select1', label: '높은 할인 순' },
        { value: 'select2', label: '낮은 가격 순' },
        { value: 'select3', label: '생산일순' }
      ],
      viewType: 'card-type',
      // 2021.03.09 (ver1.1) 기획전 종료 추가
      promotionEnd: false
    }
  }
}
</script>
