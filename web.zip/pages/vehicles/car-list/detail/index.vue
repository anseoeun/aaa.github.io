<template>
  <div class="content vehicles car-list-detail">
    <div class="car-list-detail-wrap">
      <div class="car-desc">
        <div class="vr-360">
          <div class="vr">
            <v-img :src="require('~/assets/images/temp/vr360.png')"></v-img>
          </div>
          <p class="txt">※ 차량 이미지는 소비자의 이해를 돕기 위함 3D 이미지로 실제와 차이가 있을 수 있습니다.</p>
        </div>
        <car-summary @viewMap="viewMap" />
      </div>
      <!-- 상세 -->
      <div class="car-detail">
        <v-tab class="tab-default" :data="tabList" :contents="true" :value="tabStatus">
          <template slot="contents">
            <div data-id="tab1">
              <!-- 상세설명 -->
              <promotion />
            </div>
            <div data-id="tab2">
              <spec />
            </div>
            <div data-id="tab3">
              <registration-info />
            </div>
            <div data-id="tab4">
              <delivery />
            </div>
            <div data-id="tab5">
              <take-out-info />
            </div>
          </template>
        </v-tab>

      </div>
      <!-- 유사차량 추천영역 -->
      <recommendation />
    </div>
  </div>
</template>

<script>
import CarSummary from '~/components/page/vehicles/car-list/detail/Summary'
import Promotion from '~/components/page/vehicles/car-list/detail/Promotion'
import Spec from '~/components/page/vehicles/car-list/detail/Spec'
import RegistrationInfo from '~/components/page/vehicles/car-list/detail/RegistrationInfo'
import Delivery from '~/components/page/vehicles/car-list/detail/Delivery'
import TakeOutInfo from '~/components/page/vehicles/car-list/detail/TakeOutInfo'
import Recommendation from '~/components/page/vehicles/car-list/detail/Recommendation'
export default {
  head() {
    return {
      title: '탐색 > 상세'
    }
  },
  components: {
    CarSummary,
    Promotion,
    Spec,
    RegistrationInfo,
    Delivery,
    TakeOutInfo,
    Recommendation
  },
  data() {
    return {
      tabStatus: 'tab1',
      tabList: [
        { value: 'tab1', label: '판촉차 상세설명' },
        { value: 'tab2', label: '상세 스펙' },
        { value: 'tab3', label: '구매절차 및 유의사항' },
        { value: 'tab4', label: '배달탁송 및 인수 절차안내' },
        { value: 'tab5', label: '직접 인수 방법안내' }
      ]
    }
  },
  methods: {
    viewMap(){
      this.tabStatus = 'tab5'
     setTimeout(() => {
      let map = document.querySelector('.map-area')
      document.documentElement.scrollTop = map.offsetTop
     }, 100)
    }
  }
}
</script>
