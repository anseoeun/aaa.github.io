<template>
  <div class="content vehicles offline-showroom">
    <v-pageheader
      :top-breadcrumb="topBreadcrumb"
      page-title="전시장 안내"
      page-infotext="전시장을 방문하여 직접 캐스퍼를 만나보세요!"
    />
    <!-- offline-showroom-wrap -->
    <div class="offline-showroom-detail-wrap">
      <div class="offline-showroom-detail">
        <div class="title">
          <b>스튜디오 하남</b>
          <span class="flag-wrap">
            <span class="flag">팝업 전시</span>
            <span class="flag">상담 가능</span>
            <span class="flag">시승 가능</span>
          </span>
        </div>
        <!-- detail-desc -->
        <div class="detail-desc">
          <div class="info-grid-list">
            <ul>
              <li>
                <strong class="info-title">주소</strong>
                <div class="info-group">
                    경기도 하남시 미사대로 750번지 스타필드 하남 2층
                </div>
              </li>
              <li>
                <strong class="info-title">운영 기간</strong>
                <div class="info-group">2021. 03. 02 ~ 2021. 12. 31</div>
              </li>
              <li>
                <strong class="info-title">운영 시간</strong>
                <div class="info-group">10:00 ~ 22:00 연중무휴</div>
              </li>
              <li>
                <strong class="info-title">전화번호</strong>
                <div class="info-group">02-1111-2222</div>
              </li>
            </ul>
          </div>
          <p class="text">스튜디오 하남은 겉으로 드러나는 화려함을 걷어내고 본질적인 가치에 집중합니다. 내후성 강판과 노출 콘크리트로 연출된 인테리어는 시간이 지날수록 깊어지는 가치를 선사합니다.</p>
          <p class="text">시승서비스 이용을 원하시는 고객님께서는 시승신청을 통해 예약 후 방문해주세요.</p>
          <div class="btn-wrap">
            <v-btn type="nlink" to="/" class="btn md white r">시승 신청</v-btn>
          </div>
        </div>
        <!-- // detail-desc -->

        <div class="showrooms-visual">
          <div class="title">전시장 이미지</div>
            <div class="showrooms-img">
              <div class="img">
                <v-img :src="carImg.src" :alt="carImg.alt"></v-img>
              </div>
              <v-pagination :total="100" />
            </div>
        </div>

        <div class="showrooms-car">
          <div class="title">전시중인 차</div>
          <ul>
            <li v-for="(item, index) in carList" :key="index">
              <div class="car">
                <div class="img">
                  <v-img :src="item.carImg.src" :alt="item.carImg.alt"></v-img>
                </div>
                <div class="desc">
                  <p class="tit">{{ item.name }}</p>
                    <ul>
                      <li>
                        <div class="tit">외장색상</div>
                        <div class="txt">{{ item.outColor }}</div>
                      </li>
                      <li>
                        <div class="tit">내장색상</div>
                        <div class="txt">{{ item.inColor }}</div>
                      </li>
                    </ul>
                </div>
              </div>
            </li>
          </ul>
          <p class="bullet-star">전시장의 상황에 따라 전시 중인 차는 사전 예고없이 변경될 수 있습니다.</p>
        </div>
      </div>
      <!-- offline-showroom-detail -->
      <div class="map-view">
        <div class="title">
          전시장 위치 안내
        </div>
        <div style="height:480px;background:#f9f9f9">지도영역</div>
      </div>
      <div class="btn-box">
        <v-btn type="nlink" to="/" class="btn lg blue r">목록</v-btn>
      </div>
    </div>
    <!-- // offline-showroom-wrap -->
  </div>
</template>

<script>
export default {
  head() {
    return {
      title: '체험 > 전시장안내',
    }
  },
  components: {
  },
  data() {
    return {
      topBreadcrumb: [
        { linkName: '체험', link: '/' },
        { linkName: '전시장 안내', link: '/' },
      ],
      carImg: {
        src: require('~/assets/images/temp/temp-payment-car-model.png'),
        alt: 'AX 스마트스트림 가솔린 1.1 터보 프리미엄 밀레니얼 A/T',
      },
      carList :[
        {
          carImg: {
            src: require('~/assets/images/temp/temp-payment-car-model.png'),
            alt: 'AX 스마트스트림 가솔린 1.1 터보 프리미엄 밀레니얼 A/T',
          },
          name :'AX 스마트스트림 가솔린 1.1 Turbo 프리미엄 밀레니얼 A/T',
          outColor :' 미드나잇 블랙',
          inColor :' 베이지'
        },
        {
          carImg: {
            src: require('~/assets/images/temp/temp-payment-car-model.png'),
            alt: 'AX 스마트스트림 가솔린 1.1 터보 프리미엄 밀레니얼 A/T',
          },
          name :'AX 스마트스트림 가솔린 1.1 Turbo 프리미엄 밀레니얼 A/T',
          outColor :' 미드나잇 블랙',
          inColor :' 베이지'
        }
      ]
    }
  },
}
</script>
