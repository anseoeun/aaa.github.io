<template>
  <div class="content vehicles offline-showroom">
    <v-pageheader
      :top-breadcrumb="topBreadcrumb"
      page-title="전시장 안내"
      page-infotext="전시장을 방문하여 직접 캐스퍼를 만나보세요!"
    />

    <div class="offline-showroom-wrap">
      <div class="top-noti-info">
        <div class="left">
          <p class="title">내 위치
              <span class="stxt">서울특별시 강남구 강남대로 464 &nbsp; <v-btn class="btn-more" @click="popupVisible.address = true">위치수정</v-btn></span>
          </p>
        </div>
      </div>
      <div class="map-guide-area">
        <div class="map-list">
          <div class="total">검색결과 2건</div>
          <ul class="list">
            <li v-for="(item, index) in dataList" :key="index">
              <div class="pos-info">
                <div class="title">
                  <span class="seq">{{ item.seq }}</span>
                  <b class="bold">{{ item.name }}</b>
                </div>
                <div class="address">
                  {{ item.address }}
                </div>
                <div class="date">기간 :  {{ item.date }}</div>
                <div class="txt">전시차 {{ item.carnum }}대</div>
                <div class="txt">
                  {{ item.distence }}km
                  <div class="right">
                    <v-btn type="nlink" to="/" class="btn-more">전시장 안내</v-btn>
                  </div>
                </div>
                <div v-if="item.flag.length > 0" class="flag-list">
                  <span v-for="(flag, idx) in item.flag" :key="idx" class="flag">{{ flag }}</span>
                </div>
              </div>
            </li>
          </ul>
        </div>
        <div class="map-view">
          <div class="map-tooltip" style="top:142px;left:415px;">
            <v-btn class="close"><span class="offscreen">툴팁닫기</span></v-btn>
            <div class="pos-info">
              <div class="title">
                <span class="seq">{{ dataChecked.seq }}</span>
                <b class="bold">{{ dataChecked.name }}</b>
              </div>
              <div class="address">
                {{ dataChecked.address }}
              </div>
                <div class="date">기간 :  {{ dataChecked.date }}</div>
                <div class="txt">전시차 {{ dataChecked.carnum }}대</div>
              <div class="flag-list">
                <div class="left">
                  <template v-if="dataChecked.flag.length > 0" class="flag-list">
                    <span v-for="(flag, idx) in dataChecked.flag" :key="idx" class="flag">{{ flag }}</span>
                  </template>
                </div>
                <div class="right">
                  <v-btn type="nlink" to="/" class="btn-more">전시장 안내</v-btn>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- 위치수정  -->
    <!-- 2020.03.23 (ver1.1) 팝헙형태수정 (관련 import, data 같이수정) -->
    <popup :visible.sync="popupVisible" />
  </div>
</template>

<script>
import Popup from '~/components/page/vehicles/test-driving/popup'
export default {
  head() {
    return {
      title: '체험 > 전시장안내',
    }
  },
  components: {
    Popup
  },
  data() {
    return {
      topBreadcrumb: [
        { linkName: '체험', link: '/' },
        { linkName: '전시장 안내', link: '/' },
      ],
      dataChecked : {
          seq: 1,
          name: '서초 전시장',
          address: '서울특별시 서초구 반포대로 54 (서초동, 문창빌딩) 1층',
          date: '2021. 1. 3 ~ 2021. 12. 1',
          carnum: '5',
          distence: '12',
          flag: ['팝업 전시', ' 상담 가능', ' 시승 가능'],
        },
      dataList: [
        {
          seq: 1,
          name: '서초 전시장',
          address: '서울특별시 서초구 반포대로 54 (서초동, 문창빌딩) 1층',
          date: '2021. 1. 3 ~ 2021. 12. 1',
          carnum: '5',
          distence: '12',
          flag: ['팝업 전시', ' 상담 가능', ' 시승 가능'],
        },{
          seq: 2,
          name: '구로 전시장',
          address: '서울특별시 구로 반포대로 54 (서초동, 문창빌딩) 1층',
          date: '2021. 1. 3 ~ 2021. 12. 1',
          carnum: '5',
          distence: '12',
          flag: ['팝업 전시', ' 상담 가능', ' 시승 가능'],
        },{
          seq: 3,
          name: '강동 전시장',
          address: '서울특별시 강동 반포대로 54 (서초동, 문창빌딩) 1층',
          date: '2021. 1. 3 ~ 2021. 12. 1',
          carnum: '5',
          distence: '12',
          flag: ['팝업 전시', ' 상담 가능', ' 시승 가능'],
        },
      ],
      popupVisible: {
        address: false,
      }
    }
  },
}
</script>
