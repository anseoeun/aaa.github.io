<template>
  <div class="content vehicles vehicles-review">
    <v-pageheader
      :top-breadcrumb="topBreadcrumb"
      page-title="구매 후기"
      page-infotext="캐스퍼의 구매후기를 확인해 보세요"
    />

    <div class="vehicles-review-wrap">
        <!-- total-satisfy -->
      <div class="total-satisfy">
        <div class="content-inner">
          <div class="rate-satisfy">
            <p class="txt">{{ satisfy.personNum }}명 만족도</p>
            <div class="grade">{{ satisfy.grade }}</div>
            <div class="grade-gage"><div class="bar" :style="`width:${satisfy.gage}%`"></div></div>
            <v-btn class="btn-more" @click="popupVisible.satisfaction = true">자세히 보기</v-btn>
          </div>
          <div class="detail-satisfy">
            <ul>
              <li v-for="(item, index) in satisfy.detail" :key="index">
                <span class="flag">{{ item.label }}</span>
                <div class="per">{{ item.per }}%</div>
                <p class="txt">{{ item.review }}</p>
              </li>
            </ul>
          </div>
        </div>
        <!-- // total-satisfy -->
      </div>

      <div class="content-inner">
        <div class="top-noti-info">
          <div class="left">
            <p class="title">후기목록</p>
          </div>
          <div class="right inbl-wrap">
              <span class="btn-order">
                <v-btn class="on">최신순</v-btn>
                <v-btn>평점높은순</v-btn>
                <v-btn>평점낮은순</v-btn>
              </span>
              <v-checkbox :one-check="true" :checked.sync="photoReviewVal"
                >포토후기</v-checkbox>
          </div>
        </div>
        <div class="top-noti-info sub-noti">
          <div class="left">
            <v-select
              v-model="enginVal"
              :data="enginList"
              class="no-st"
            />
            <v-select
              v-model="trimVal"
              :data="trimList"
              class="no-st"
            />
            <span class="btns">
              <v-btn class="btn md white r" type="button">검색</v-btn>
              <v-btn class="btn md gray line r" type="button">초기화</v-btn>
            </span>
          </div>
          <div class="right inbl-wrap">
            <v-btn class="btn md blue r btn-review-write" type="button">구매후기 작성</v-btn>
          </div>
        </div>
        <!-- list-board -->
        <div class="buying-review-list">
          <template v-if="buyReviewList.length > 0">
          <ul>
            <li v-for="(item, index) in buyReviewList" :key="index">
              <div class="img"><v-img :src="item.carImg.src" :alt="item.carImg.alt"></v-img></div>
              <!-- 2021.03.31 (ver 1.1) desc내부 html 구조수정 -->
              <div class="desc">
                <div class="title-wrap">
                  <div class="title">{{ item.title }}</div>
                   <div class="right">
                    <v-rate v-model="item.grade" class="grade-check xs-size view"></v-rate>
                  </div>
                </div>
                <div class="date">
                 {{ item.contractDate }} {{ item.user }}
                </div>
                <div class="review" :class="{on: item.reviewOpen}">
                    <v-btn type="link" href="javascript:void(0);" class="review-text" @click="item.reviewOpen = true">
                      {{ item.review }}
                    </v-btn>
                    <v-btn v-if="item.reviewOpen" class="btn-review-close" @click="item.reviewOpen = false">닫기 -</v-btn>
                </div>
                <ul class="review-list">
                  <li v-for="(list, idx) in item.reviews" :key="idx">
                    <span class="flag">{{ list.label }}</span> <span class="txt">{{ list.review }}</span>
                  </li>
                </ul>
                <!-- 사진 -->
                <div class="upload-view-list-wrap">
                  <v-carousel-new
                    :data="item.fileList"
                    :navigation="true"
                    :items-to-show="5"
                    :items-to-slide="1"
                    class="upload-view-list sm-size"
                  >
                  <template slot-scope="props">
                      <div class="item">
                        <v-btn class="img" @click="popupVisible.photoDetail = true">
                          <v-img :src="props.item.src" :alt="props.item.alt"></v-img>
                        </v-btn>
                      </div>
                  </template>
                  </v-carousel-new>
                </div>
                <div class="etc-menus">
                  <span class="good"> 도움이 되었어요 <span class="up"><span class="icon"></span><span class="num">5</span></span></span>
                  <v-btn class="btn-more">동일사양 견적내기</v-btn>

                  <!-- 2021.04.13 (ver1.2) 버튼추가 -->
                  <v-btn class="btn-more" @click="popupVisible.purchaseInfo = true">구매 상세 정보</v-btn>
                </div>
              </div>
            </li>
          </ul>
          </template>
           <template v-else>
              <div class="list-null only-text">
                <p>구매 내역이 없습니다.</p>
              </div>
           </template>
        </div>
        <div v-if="buyReviewList.length <= 0" class="btn-box t-right">
          <v-btn class="btn md white r" type="nlink">구매후기 보러가기</v-btn>
        </div>
        <v-pagination :total="100" />
        <!-- 안내사항 -->
        <div class="page-notice">
          <div class="title big">유의사항</div>
          <p class="only-txt">아래 사항에 해당하는 경우 통보 없이 게시글이 삭제될 수 있습니다. <br />1) 차량과 무관한 내용 2) 명애훼손성, 모욕성 게시글 3) 그외 욕설 , 비방글 등 본 게시판 목적에 부적절한 게시글</p>
        </div>
        <!-- // 안내사항 -->
      </div>
    </div>
    <photo-detail :visible="popupVisible.photoDetail" @close="popupVisible.photoDetail = false" />
    <satisfaction :visible="popupVisible.satisfaction" @close="popupVisible.satisfaction = false" />

    <!-- 2021.04.13 (ver1.2) 팝업추가 -->
    <purchase-info :visible="popupVisible.purchaseInfo" @close="popupVisible.purchaseInfo = false" />
  </div>
</template>

<script>
import { VBtn } from '~/components/element'
import PhotoDetail from '~/components/page/review/Detail'
import Satisfaction from '~/components/page/review/Satisfaction'
import PurchaseInfo from '~/components/page/review/PurchaseInfo'
export default {
  components: {
    VBtn,
    PhotoDetail,
    Satisfaction,
    PurchaseInfo
  },
  data() {
    return {
      topBreadcrumb: [
        { linkName: '후기', link: '/' },
        { linkName: '구매 후기', link: '/' },
      ],
      satisfy: {
        personNum: '12',
        grade: 4.6,
        gage: 90,
        detail: [
            {label: '구매과정', review: '생각보다 쉬워요', per:'92'},
            {label: '가성비', review: '예정된 날짜에 받았어요', per:'90'},
            {label: '디자인', review: '화면처럼 맘에 들어요', per:'95'},
            {label: '승차감', review: '굿이에요', per:'85'},
        ]
      },
      photoReviewVal: false,
      enginVal: 'select0',
      enginList: [
        { value: 'select0', label: '엔진전체' },
        { value: 'select1', label: '엔진선택1' },
        { value: 'select2', label: '엔진선택2' },
        { value: 'select3', label: '엔진선택3' },
      ],
      trimVal: 'select0',
      trimList: [
        { value: 'select0', label: '트림전체' },
        { value: 'select1', label: '트림선택1' },
        { value: 'select2', label: '트림선택2' },
        { value: 'select3', label: '트림선택3' },
      ],
      isView: false,
      listSelected:'',
      buyReviewList: [
        {
          carImg: {
            src: require('~/assets/images/temp/temp-review-car.png'),
            alt: '쏘나타 센슈어스(가솔린 1.6T) Premium (자가용 스마트스트림 가솔린 1.6 터보)',
          },
          title:'쏘나타 센슈어스(가솔린 1.6T) Premium (자가용 스마트스트림 가솔린 1.6 터보)',
          grade: 3,
          gage: 70,
          review: '후기내용 최대 2줄 까지 표시가 됩니다.후기내용 최대 2줄 까지 표시가 됩니다.후기내용 최대 2줄 까후기내용 최대 2줄 까지 표시가 됩니다.후기내용 최대 2줄 까지 표시가 됩니다.후기내용 최대 2줄 까지 표시가 됩니다.후기내용 최대 2줄 까지 표시가 됩니다.후기내용 최대 2줄 까후기내용 최대 2줄 까지 표시가 됩니다.후기내용 최대 2줄 까지 표시가 됩니다후기내용 최대 2줄 까지 표시가 됩니다.후기내용 최대 2줄 까지 표시가 됩니다.후기내용 최대 2줄 까후기내용 최대 2줄 까지 표시가 됩니다.후기내용 최대 2줄 까지 표시가 됩니다후기내용 최대 2줄 까지 표시가 됩니다.후기내용 최대 2줄 까지 표시가 됩니다.후기내용 최대 2줄 까후기내용 최대 2줄 까지 표시가 됩니다.후기내용 최대 2줄 까지 표시가 됩니다',
          contractDate: '2021.10.30',
          user: '(30대,남성)',
          reviewOpen: false,
          reviews: [
            {label: '구매과정', review: '생각보다 쉬워요'},
            {label: '가성비', review: '예정된 날짜에 받았어요'},
            {label: '디자인', review: '화면처럼 맘에 들어요'},
            {label: '승차감', review: '굿이에요'},
          ],
          // 사진 슬라이드
          fileList: [
            {
              src: require('~/assets/images/temp/temp-review-car.png'),
              alt: 'AX 센슈어스(가솔린 1.6T) Premium (자가용 스마트스트림 가솔린 1.6 터보',
            },
            {
              src: require('~/assets/images/temp/temp-review-car.png'),
              alt: 'AX 센슈어스(가솔린 1.6T) Premium (자가용 스마트스트림 가솔린 1.6 터보',
            },
            {
              src: require('~/assets/images/temp/temp-review-car.png'),
              alt: 'AX 센슈어스(가솔린 1.6T) Premium (자가용 스마트스트림 가솔린 1.6 터보',
            },
            {
              src: require('~/assets/images/temp/temp-review-car.png'),
              alt: 'AX 센슈어스(가솔린 1.6T) Premium (자가용 스마트스트림 가솔린 1.6 터보',
            },
            {
              src: require('~/assets/images/temp/temp-review-car.png'),
              alt: 'AX 센슈어스(가솔린 1.6T) Premium (자가용 스마트스트림 가솔린 1.6 터보',
            },
            {
              src: require('~/assets/images/temp/temp-review-car.png'),
              alt: 'AX 센슈어스(가솔린 1.6T) Premium (자가용 스마트스트림 가솔린 1.6 터보',
            }
          ],
        },
        {
          carImg: {
            src: require('~/assets/images/temp/temp-review-car.png'),
            alt: '쏘나타 센슈어스(가솔린 1.6T) Premium (자가용 스마트스트림 가솔린 1.6 터보)',
          },
          title:'쏘나타 센슈어스(가솔린 1.6T) Premium (자가용 스마트스트림 가솔린 1.6 터보)',
          grade: 1,
          gage: 85,
          review: '후기내용 최대 2줄 까지 표시가 됩니다.후기내용 최대 2줄 까지 표시가 됩니다.후기내용 최대 2줄 까후기내용 최대 2줄 까지 표시가 됩니다.후기내용 최대 2줄 까지 표시가 됩니다.후기내용 최대 2줄 까지 표시가 됩니다.후기내용 최대 2줄 까지 표시가 됩니다.후기내용 최대 2줄 까후기내용 최대 2줄 까지 표시가 됩니다.후기내용 최대 2줄 까지 표시가 됩니다후기내용 최대 2줄 까지 표시가 됩니다.후기내용 최대 2줄 까지 표시가 됩니다.후기내용 최대 2줄 까후기내용 최대 2줄 까지 표시가 됩니다.후기내용 최대 2줄 까지 표시가 됩니다후기내용 최대 2줄 까지 표시가 됩니다.후기내용 최대 2줄 까지 표시가 됩니다.후기내용 최대 2줄 까후기내용 최대 2줄 까지 표시가 됩니다.후기내용 최대 2줄 까지 표시가 됩니다',
          contractDate: '2021.10.30',
          user: '(30대,남성)',
          reviewOpen: false,
          reviews: [
            {label: '구매과정', review: '생각보다 쉬워요'},
            {label: '가성비', review: '예정된 날짜에 받았어요'},
            {label: '디자인', review: '화면처럼 맘에 들어요'},
            {label: '승차감', review: '굿이에요'},
          ],
          // 사진 슬라이드
          fileList: [
            {
              src: require('~/assets/images/temp/temp-review-car.png'),
              alt: 'AX 센슈어스(가솔린 1.6T) Premium (자가용 스마트스트림 가솔린 1.6 터보',
            },
            {
              src: require('~/assets/images/temp/temp-review-car.png'),
              alt: 'AX 센슈어스(가솔린 1.6T) Premium (자가용 스마트스트림 가솔린 1.6 터보',
            },
            {
              src: require('~/assets/images/temp/temp-review-car.png'),
              alt: 'AX 센슈어스(가솔린 1.6T) Premium (자가용 스마트스트림 가솔린 1.6 터보',
            },
            {
              src: require('~/assets/images/temp/temp-review-car.png'),
              alt: 'AX 센슈어스(가솔린 1.6T) Premium (자가용 스마트스트림 가솔린 1.6 터보',
            },
            {
              src: require('~/assets/images/temp/temp-review-car.png'),
              alt: 'AX 센슈어스(가솔린 1.6T) Premium (자가용 스마트스트림 가솔린 1.6 터보',
            },
          ],
        },
      ],
      popupVisible: {
        photoDetail: false,
        satisfaction: false,

        // 2021.04.13 (ver1.2) 팝업추가
        purchaseInfo: false,
      }
    }
  },
  methods:{

  }
}
</script>
