<template>
  <div class="toggle-area4">
    <div class="information-detail" :class="{ active: isOptionsShow }">
      <div class="summary-info">
          <h1 class="title">STEP 4. 시승 일정</h1>
          <div class="right">
            <span v-if="selectedDate.date !== '' && selectedDate.date !== undefined" class="text bold">{{ getSelectedDateTime }} </span>
            <v-btn v-if="selectedDate.date !== '' && selectedDate.date !== undefined" class="btn-more" @click="showChange">변경<span v-if="isOptionsShow">취소</span></v-btn>
          </div>
      </div>
    </div>
    <div class="detail-info" :class="{ active: isOptionsShow }" style="display:none">
      <p class="step-guide-text">
        원하시는 날짜와 시간을 선택해주세요. <br />
        차량 준비 및 이동 시간을 포함하여 1시간 30분 ~ 2시간 동안 시승서비스를 이용하실 수 있습니다.</p>
      <div class="driving-schedule">
        <div class="schedule-header">
          <div class="status">
            <span><i class="able"></i>신청가능</span>
            <span><i class="disable"></i>신청마감</span>
          </div>
          <div class="year-month">{{ year }}년 {{ month | fillzero }}월</div>
          <div class="prev-next">
            <span class="prev"><button type="button" class="btn-prev" :disabled="parseInt(limitedStart.replace('-', '')) >= getYearMonth() " @click="calendarData(-1)">이전달</button></span>
            <span class="next"><button type="button" class="btn-next" :disabled="parseInt(limitedEnd.replace('-', '')) <= getYearMonth()" @click="calendarData(1)">다음달</button></span>
          </div>
        </div>
        <table class="schedule-table">
          <thead>
            <tr>
              <th v-for="day in days" :key="day">{{ day }}</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for=" (date, idx) in dates" :key="idx">
              <td
                v-for="(day, secondIdx) in date"
                :key="secondIdx"
                :class="{ 'has-text-prev-empty': idx === 0 && day >= lastMonthStart,
                'has-text-next-empty': dates.length - 1 === idx && nextMonthStart > day,
                'today': isToday(year, month, day),
                'prevday' : isPrevDate(year, month, day)
                }"
              >
              <div class="date">
                {{ day }}
              </div>
                <div
                  v-if="isToday(year, month, day)"
                class="today-txt">오늘</div>
                <div v-if="!isToday(year, month, day) && !isPrevDate(year, month, day)" class="check-time">
                  <ul>
                    <li v-for="(time, index) in timeList" :key="index">
                      <v-btn
                      :class="{ on: selectedDate.date === year+'-'+month+'-'+day && selectedDate.time === time}"
                      :disabled="isDate(year, month, day, time)"
                      @click="setDate(year, month, day, time)"
                      >{{ time }}</v-btn></li>
                  </ul>
                </div>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</template>

<script>
import { mapGetters, mapMutations } from 'vuex'
export default {
  filters:{
    fillzero(val){
      return val < 10 ? '0'+val : val
    }
  },
  data() {
    return {
      isOptionsShow: false,
      days: [
        '일',
        '월',
        '화',
        '수',
        '목',
        '금',
        '토',
      ],
      dates: [],
      currentYear: 0,
      currentMonth: 0,
      year: 0,
      month: 0,
      lastMonthStart: 0,
      nextMonthStart: 0,
      today: 0,
      timeList : ['10:00', '13:00', '14:00', '16:00'],
      selectedDate: {
        date: '',
        time: ''
      },
      limitedStart: '2021-03',
      limitedEnd:'2021-09'
    }
  },
  computed: {
    ...mapGetters({
      testDrivingStep: 'vihiclesModules/testDrivingStep',
      drivingData: 'vihiclesModules/drivingData',
      checkedDriving: 'vihiclesModules/checkedDriving',
    }),
    getSelectedDateTime(){
      let d = this.selectedDate.date.split('-')[0] + '년 ' +
            this.selectedDate.date.split('-')[1] + '월 ' +
            this.selectedDate.date.split('-')[2] + '일 ' +
            this.selectedDate.time
      return d
    }
  },
  watch:{
    testDrivingStep(oldVal, newVal){
       if(newVal !== oldVal){
          this.setStep()
       }
    },
  },
  created() {
    const date = new Date()
    this.currentYear = date.getFullYear() // 이하 현재 년, 월 가지고 있기
    this.currentMonth = date.getMonth() + 1
    this.year = this.currentYear
    this.month = this.currentMonth
    this.today = date.getDate() // 오늘 날짜
    this.calendarData()
  },
  mounted(){
    this.setStep()
    //값설정되어있을시
    this.selectedDate = this.checkedDriving
  },
  methods: {
    ...mapMutations({
      setTestDrivingStep: 'vihiclesModules/setTestDrivingStep',
      setSelectedDriving: 'vihiclesModules/setSelectedDriving',
    }),
    setStep(){
      this.testDrivingStep === 4
        ? [this.testDrivingSlideToggle(4,'open'), this.isOptionsShow = true]
        : [this.testDrivingSlideToggle(4,'close'), this.isOptionsShow = false]
    },
    showChange(){
      this.isOptionsShow = !this.isOptionsShow
      if(this.isOptionsShow === true){
        this.setTestDrivingStep(4)
      }else{
        this.setTestDrivingStep('')
        this.$emit('completed', ['step4', this.selectedDate])
      }
    },
    calendarData(arg) { // 인자를 추가
      if (arg < 0) { // -1이 들어오면 지난 달 달력으로 이동
        this.month -= 1
      } else if (arg === 1) { // 1이 들어오면 다음 달 달력으로 이동
        this.month += 1
      }
      if (this.month === 0) { // 작년 12월
        this.year -= 1
        this.month = 12
      } else if (this.month > 12) { // 내년 1월
        this.year += 1
        this.month = 1
      }
      const [
        monthFirstDay,
        monthLastDate,
        lastMonthLastDate,
      ] = this.getFirstDayLastDate(this.year, this.month)
      this.dates = this.getMonthOfDays(
        monthFirstDay,
        monthLastDate,
        lastMonthLastDate,
      )
    },
    getYearMonth(arg) {
      let currentYear = this.year
      let currentMonth = this.month
      let year = this.year
      let month = this.month
      if(arg !== undefined) {
        if (arg < 0) { // -1이 들어오면 지난 달 달력으로 이동
          month = currentMonth -= 1
        } else if (arg === 1) { // 1이 들어오면 다음 달 달력으로 이동
          month = currentMonth += 1
        }
        if (month === 0) { // 작년 12월
          year = currentYear -= 1
          month = currentMonth = 12
        } else if (month > 12) { // 내년 1월
          year = currentYear += 1
          month = currentMonth = 1
        }
      }
      month = month < 10 ? '0'+month : month
      return parseInt(year+''+ month)
    },
    getFirstDayLastDate(year, month) {
      const firstDay = new Date(year, month - 1, 1).getDay() // 이번 달 시작 요일
      const lastDate = new Date(year, month, 0).getDate() // 이번 달 마지막 날짜
      let lastYear = year
      let lastMonth = month - 1
      if (month === 1) {
        lastMonth = 12
        lastYear -= 1
      }
      const prevLastDate = new Date(lastYear, lastMonth, 0).getDate() // 지난 달 마지막 날짜
      return [firstDay, lastDate, prevLastDate]
    },
    getMonthOfDays(
      monthFirstDay,
      monthLastDate,
      prevMonthLastDate,
    ) {
      let day = 1
      let prevDay = (prevMonthLastDate - monthFirstDay) + 1
      const dates = []
      let weekOfDays = []
      while (day <= monthLastDate) {
        if (day === 1) {
          // 1일이 어느 요일인지에 따라 테이블에 그리기 위한 지난 셀의 날짜들을 구할 필요가 있다.
          for (let j = 0; j < monthFirstDay; j += 1) {
            if (j === 0) this.lastMonthStart = prevDay // 지난 달에서 제일 작은 날짜
            weekOfDays.push(prevDay)
            prevDay += 1
          }
        }
        weekOfDays.push(day)
        if (weekOfDays.length === 7) {
          // 일주일 채우면
          dates.push(weekOfDays)
          weekOfDays = [] // 초기화
        }
        day += 1
      }
      const len = weekOfDays.length
      if (len > 0 && len < 7) {
        for (let k = 1; k <= 7 - len; k += 1) {
          weekOfDays.push(k)
        }
      }
      if (weekOfDays.length > 0) dates.push(weekOfDays) // 남은 날짜 추가
      this.nextMonthStart = weekOfDays[0] // 이번 달 마지막 주에서 제일 작은 날짜
      return dates
    },

    isDate(year, month, day, time){
      return this.drivingData[year+'-'+ month+'-'+ day] !== undefined ? this.drivingData[year+'-'+ month+'-'+ day].includes(time) : false
    },
    setDate(year, month, day, time) {
      this.selectedDate.date = year+'-'+month+'-'+day
      this.selectedDate.time =  time
      this.setSelectedDriving(this.selectedDate)
      this.showChange()
    },
    isToday(year, month, day){
      if(day === this.today && month === this.currentMonth && year === this.currentYear){
        return true
      }else{
        return false
      }
    },
    isPrevDate(year, month, day){
      let now = new Date()
      let yesterday = new Date(now.setDate(now.getDate() - 1))
      let date =  new Date(year+'-'+month+'-'+day)

      return yesterday.getTime()  > date.getTime() ? true : false
    },
  },
}
</script>
