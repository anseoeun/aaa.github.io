<template>
  <div class="toggle-area5">
    <div class="information-detail" :class="{ active: isOptionsShow }">
        <div class="summary-info">
            <h1 class="title">STEP 5. 신청자 정보 확인 및 고지사항 확인</h1>
        </div>
    </div>
    <div class="detail-info" :class="{ active: isOptionsShow }" style="display:none">
        <div class="matching-list">
          <div class="list-row">
            <div class="tit"><b>시승자 정보</b></div>
            <div class="auto">
              <ul class="cell-list">
                <li>
                  <div class="cell-tit wide">이름</div>
                  <div class="cell-txt">홍길동</div>
                </li>
                <li>
                  <div class="cell-tit wide">휴대전화번호</div>
                  <div class="cell-txt">010-1234-5678</div>
                </li>
              </ul>
              <br />
              <p class="bullet-star">시승 신청 후 고객님께 안내 전화를 드립니다. 잘못된 연락처로 인해 시승이 불가하실 수 있으니 정확한 연락처를 확인해주세요.</p>
            </div>
          </div>
          <div class="list-row">
            <div class="tit"><b>안내 사항</b></div>
            <div class="auto">
              <ul class="bullet-list">
                <li>시승 거점 방문 시 운전면허증을 지참해주세요.</li>
                <li>시승 시 안전한 운행과 교통법규를 지켜주세요. 과속, 위험운전 및 기타 운행이 불가능하다고 판단될 경우 고객님의 안전을 위해시승이 제한될 수 있습니다.</li>
                <li>혹시 모를 사고가 발생할 경우 자기부담금은 최대 10만원까지만 부과됩니다.</li>
              </ul>
            </div>
          </div>
          <div class="list-row">
            <div class="tit"><b>서비스 이용 동의</b></div>
            <div class="auto">
              <v-checkbox v-model="checkboxDataListVal" :data="checkboxListData" class="block" @change="agreeCheck" />
            </div>
          </div>
        </div>
    </div>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
export default {
  data() {
    return {
      isOptionsShow: false,
      visible:{
        testDrive: false
      },
      checkboxDataListVal: [],
      checkboxListData: [
        { value: 'check1', label: '(필수) 시승차 이용 및 서비스 이용에 따른 주요 고지사항 및 이용약관 안내'},
        { value: 'check2', label: '(필수) 개인정보 수집 및 이용 안내'},
        { value: 'check3', label: '(필수) 개인정보 처리 위탁 안내'},
        { value: 'check4', label: '(선택) 차량구입관련 사항 및 각종 정보제공 안내 (마케팅 활용 및 광고성 정보 전송)'},
      ],
    }
  },
  computed: {
    ...mapGetters({
      testDrivingStep: 'vihiclesModules/testDrivingStep',
    }),
  },
  watch:{
    testDrivingStep(oldVal, newVal){
       if(newVal !== oldVal){
          this.setStep()
       }
    },
    checkboxDataListVal(newVal, odlVal){
      if(newVal.length > odlVal.length){
        const val = newVal[newVal.length-1]
        if(val == 'check1') this.$emit('testDrivePopup')
        else if(val == 'check2') this.$emit('privacyInfoPopup')
        else if(val == 'check3') this.$emit('privacyTrustPopup')
        else if(val == 'check4') this.$emit('carBuyPopup')
      }
    }
  },
  mounted(){
    this.setStep()
  },
  methods: {
    setStep(){
      this.testDrivingStep === 5
        ? [this.testDrivingSlideToggle(5,'open'), this.isOptionsShow = true]
        : [this.testDrivingSlideToggle(5,'close'), this.isOptionsShow = false]
    },
    agreeCheck(){
      this.$emit('agreeCheck', this.checkboxDataListVal.length === 4)
    }
  }
}
</script>
