<template>
  <div class="content vehicles test-driving">
    <v-pageheader
      :top-breadcrumb="topBreadcrumb"
      page-title="시승 신청"
      page-infotext="현대자동차에서 제공하는 편리한 시승 신청 서비스를 이용해보세요."
    />

    <div class="test-driving-wrap">
      <div ref="wrap" class="test-driving-complete">
         <div class="title">
            <b class="tit">시승 신청 완료</b>
            <p class="stxt">시승 신청이 완료되었습니다. <br />고객님께서 신청하신 내용은 아래와 같습니다.</p>
         </div>
         <div class="car-img">
            <v-img :src="carImg.src" :alt="carImg.alt"></v-img>
         </div>
          <!-- 정보 -->
          <div class="matching-list driving-info">
            <ul>
              <li>
                <div class="tit">신청상태</div>
                <div class="right">
                    <span class="flag">시승대기</span>
                </div>
              </li>
              <li>
                <div class="tit">드라이빙 라운지</div>
                <div class="right">
                  <b class="bold roung-name">드라이빙라운지 서초</b>
                  서울특별시 서초구 반포대로 54 (서초동, 문창빌딩) 1층 &nbsp;
                  <v-btn class="btn-more" @click="popupVisible.drivingLounge = true">찾아오는 길</v-btn>
                  <br />
                  02-812-7365
                </div>
              </li>
              <li>
                <div class="tit">시승차량</div>
                <div class="right">
                  AX 스마트스트림 가솔린 1.1 모던 A/T <br />
                  <!-- 2021-04-16(1.2) 태그추가 -->
                  <div class="color">
                    <span>외장색상 : 미드나잇블랙</span>
                    <span>내장색상 : 베이지</span>
                  </div>
                </div>
              </li>
              <li>
                <div class="tit">시승방법</div>
                <div class="right">
                  셀프 시승 서비
                </div>
              </li>
              <li>
                <div class="tit">시승일시</div>
                <div class="right">
                  2021년 2월 15일 13:00
                </div>
              </li>
            </ul>
            <ul>
              <li>
                <div class="tit">시승자 정보</div>
                <div class="righ">
                  <div class="matching-list driver-info">
                    <ul>
                      <li>
                        <!-- 2021.04.14(ver1.1) 시승자정보 -> 이름 -->
                        <div class="tit bold">이름</div>
                        <div class="txt">홍길동</div>
                      </li>
                      <li>
                        <div class="tit bold">휴대폰번호</div>
                        <div class="txt">010-1234-5678</div>
                      </li>
                    </ul>
                  </div>
                </div>
              </li>
            </ul>
          </div>
          <!-- // 정보 -->

          <ul class="bullet-list">
            <li>시승 거점 방문 시 운전면허증을 지참해주세요.</li>
            <li>시승 당일 취소 시 추후 시승 서비스 참여에 제약이 있으실 수 있습니다.</li>
          </ul>
      </div>
    </div>
    <div class="btn-box">
      <v-btn class="btn lg gray r" type="button" @click="popupVisible.checkPoint = true">시승 체크포인트</v-btn>
      <v-btn type="nlink" to="/" class="btn lg blue r">시승 신청 내역 보기</v-btn>
    </div>

    <popup :visible.sync="popupVisible" />
  </div>
</template>

<script>
import Popup from '~/components/page/vehicles/test-driving/popup'
export default {
  head() {
    return {
      title: '탐색 > 시승 신청',
    }
  },
  components: {
    Popup
  },
  data() {
    return {
      topBreadcrumb: [
        { linkName: '탐색', link: '/' },
        { linkName: '시승 신청', link: '/' },
      ],
      carImg: {
        src: require('~/assets/images/temp/temp-contract-car-visual.png'),
        alt: 'AX 스마트스트림 가솔린 1.1 터보 프리미엄 밀레니얼 A/T',
      },
      popupVisible: {
        drivingLounge: false,
        checkPoint: false,
      }
    }
  },
}
</script>
