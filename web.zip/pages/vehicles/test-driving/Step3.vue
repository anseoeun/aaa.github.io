<template>
  <div class="toggle-area3">
    <div class="information-detail" :class="{ active: isOptionsShow }">
      <div class="summary-info">
          <h1 class="title">STEP 3. 시승 차량 및 시승 방법</h1>
          <div class="right">
            <span class="text bold">{{ selectedValue }}</span>
            <v-btn v-if="selectedValue !== ''" class="btn-more" @click="showChange">변경<span v-if="isOptionsShow">취소</span></v-btn>
          </div>
      </div>
    </div>
    <div class="detail-info" :class="{ active: isOptionsShow }" style="display:none">
        <p class="step-guide-text">원하시는 차량과 시승 방법을 선택해주세요.</p>
        <div class="matching-list">
          <div class="list-row">
            <div class="tit"><b>시승 차량</b></div>
            <div class="auto">
                <div class="test-car">
                  <ul>
                    <li v-for="(item, index) in carList" :key="index">
                      <v-btn type="link" href="javascript:void(0);" class="car"
                        :class="{ on: carCheck.seq == item.seq }"
                        @click="carSelected(index)"
                      >
                        <div class="img">
                          <v-img :src="item.carImg.src" :alt="item.carImg.alt"></v-img>
                        </div>
                        <div class="desc">
                          <p class="tit">{{ item.name }}</p>
                            <ul>
                              <li>
                                <div class="tit">외장색상</div>
                                <div class="txt">{{ item.outColor }}</div>
                              </li>
                              <li>
                                <div class="tit">내장색상</div>
                                <div class="txt">{{ item.inColor }}</div>
                              </li>
                              <li>
                                <div class="tit">옵션</div>
                                <div class="txt">{{ item.opt }}</div>
                              </li>
                            </ul>
                        </div>
                      </v-btn>
                    </li>
                  </ul>
                </div>
            </div>
          </div>
          <div class="list-row">
            <div class="tit"><b>시승 방법</b>
                <v-popover trigger="hover" placement="bottom-center" style-type="popover-bottom-center">
                  <p>
                    셀프 시승 서비스 <br />
                    : 고객님이 시승거점으로 직접 방문 후 혼자 시승하는 서비스
                    <br /> <br />
                    동승 시승 서비스 <br />
                    : 고객님이 시승거점으로 직접 방문 후 담당 직원과 동승하여 차량에 대한 안내와 함께 시승하는 서비스
                  </p>
                  <v-btn slot="reference"><i class="icon-help"></i></v-btn>
                </v-popover>
            </div>
            <div class="auto">
                <v-radio v-model="drivingMethodCheck" class="radio-round-button sm-w" type="button" :data="drivingMethod" @change="methodSelected" />
            </div>
          </div>
        </div>
    </div>

  </div>
</template>

<script>
import { mapGetters, mapMutations } from 'vuex'
export default {
  components: {
  },
  data() {
    return {
      isOptionsShow: false,
      carCheck: '',
      drivingMethodCheck: false,
      selectedValue: ''
    }
  },
  computed: {
    ...mapGetters({
      testDrivingStep: 'vihiclesModules/testDrivingStep',
      carList: 'vihiclesModules/carList',
      checkedCar: 'vihiclesModules/checkedCar',
      drivingMethod: 'vihiclesModules/drivingMethod',
      checkedDrivingMethod: 'vihiclesModules/checkedDrivingMethod',
    }),
    drivingMethodCheckLabel() {
      let value = this.drivingMethodCheck
      let label = ''
      this.drivingMethod.forEach((item, index) => {
        if(item.value === value){
          label = item.label.replace('서비스', '')
        }
      })
      return label
    }
  },
  watch:{
    testDrivingStep(oldVal, newVal){
       if(newVal !== oldVal){
          this.setStep()
       }
    },
  },
  mounted() {
    this.setStep()
    //값설정되어있을시
    this.drivingMethodCheck = this.checkedDrivingMethod
    this.carCheck = this.checkedCar
  },
  methods: {
    ...mapMutations({
      setTestDrivingStep: 'vihiclesModules/setTestDrivingStep',
      setDrivingMethod: 'vihiclesModules/setDrivingMethod',
      setSelectedCar: 'vihiclesModules/setSelectedCar',
    }),
    setStep(){
      this.testDrivingStep === 3
        ? [this.testDrivingSlideToggle(3,'open'), this.isOptionsShow = true]
        : [this.testDrivingSlideToggle(3,'close'), this.isOptionsShow = false]
    },
    carSelected(index) {
      this.carCheck = this.carList[index]
      this.setSelectedCar(this.carCheck)

      if(this.drivingMethodCheck === false) return
      this.selectedValue = this.carCheck.name + '('+ this.drivingMethodCheckLabel +')'

      this.isOptionsShow = !this.isOptionsShow
      this.setTestDrivingStep('')
      this.$emit('completed', ['step3', this.carCheck])
    },
    methodSelected(){
      this.setDrivingMethod(this.drivingMethodCheck)

      if(this.carCheck.name === undefined) return
      this.selectedValue = this.carCheck.name + '('+ this.drivingMethodCheckLabel +')'

      this.isOptionsShow = !this.isOptionsShow
      this.setTestDrivingStep('')
      this.$emit('completed', ['step3', this.carCheck])
    },
    showChange(){
      this.isOptionsShow = !this.isOptionsShow
      if(this.isOptionsShow === true){
        this.setTestDrivingStep(3)
      }else{
        this.setTestDrivingStep('')
        this.$emit('completed', ['step3', this.carCheck])
      }
    },
  },
}
</script>
