<template>
  <div class="toggle-area1">
    <div class="information-detail" :class="{ active: isOptionsShow }">
        <div class="summary-info">
            <h1 class="title">STEP 1. 시승 모델 (엔진)</h1>
            <div class="right">
              <span class="text bold">{{ enginCheckLabel }}</span>
              <v-btn v-if="enginCheckLabel !== ''" class="btn-more" @click="showChange">변경<span v-if="isOptionsShow">취소</span></v-btn>
            </div>
        </div>
      </div>
      <div class="detail-info" :class="{ active: isOptionsShow }">
        <p class="step-guide-text">원하시는 엔진을 선택해주세요. </p>
        <div class="matching-list">
          <div class="list-row">
            <div class="tit"><b>엔진</b></div>
            <div class="auto">
                <v-radio v-model="enginCheck" class="radio-round-button sm-w" type="button" :data="enginData" />
            </div>
          </div>
        </div>
    </div>
  </div>
</template>

<script>
import { mapGetters, mapMutations } from 'vuex'
export default {
  data() {
    return {
      enginCheck: '',
      mapChecked: '',
      isOptionsShow: false
    }
  },
  computed: {
    ...mapGetters({
      testDrivingStep: 'vihiclesModules/testDrivingStep',
      enginData: 'vihiclesModules/enginData',
      checkedEngin: 'vihiclesModules/checkedEngin',
    }),
    enginCheckLabel() {
      let value = this.enginCheck
      let label = ''
      this.enginData.forEach((item, index) => {
        if(item.value === value){
          label = item.label
        }
      })
      return label
    }
  },
  watch:{
    enginCheck(oldVal, newVal){
       if(newVal !== oldVal){
         this.setEnginCheck(newVal)
         this.$emit('completed', ['step1', this.enginCheck])
       }
    },
    testDrivingStep(oldVal, newVal){
       if(newVal !== oldVal){
         this.setStep()
       }
    },
  },
  mounted() {
    this.setStep()
    //값설정되어있을시
    this.enginCheck = this.checkedEngin
  },
  methods: {
    ...mapMutations({
      setTestDrivingStep: 'vihiclesModules/setTestDrivingStep',
      setEnginCheck: 'vihiclesModules/setEnginCheck',
    }),
    setStep(){
    console.log(this.testDrivingStep)
      this.testDrivingStep === 1
        ? [this.testDrivingSlideToggle(1,'open'), this.isOptionsShow = true]
        : [this.testDrivingSlideToggle(1,'close'), this.isOptionsShow = false]
    },
    showChange(){
      this.isOptionsShow = !this.isOptionsShow
      if(this.isOptionsShow === true){
        this.setTestDrivingStep(1)
      }else{
        this.setTestDrivingStep('')
        this.$emit('completed', ['step1', this.enginCheck])
      }
    }
  },

}
</script>
