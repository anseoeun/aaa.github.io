<template>
  <div class="toggle-area2">
    <div class="information-detail" :class="{ active: isOptionsShow }">
      <div class="summary-info">
          <h1 class="title">STEP 2. 드라이빙 라운지</h1>
          <div class="right">
            <span class="text bold">{{ checkedMap.name }}</span>
            <v-btn v-if="checkedMap.name !== undefined" class="btn-more" @click="showChange">변경<span v-if="isOptionsShow">취소</span></v-btn>
          </div>
      </div>
    </div>
    <transition name="slide">
    <div class="detail-info" :class="{ active: isOptionsShow }" style="display:none">
        <p class="step-guide-text">원하시는 드라이빙 라운지를 선택해주세요.</p>
        <div class="matching-list">
          <div class="list-row">
            <div class="tit"><b>내 위치</b></div>
            <div class="auto">
                <span class="t-gray">서울특별시 강남구 강남대로 464</span>  &nbsp;
                <v-btn class="btn-more" @click="$emit('addressPop')">위치수정</v-btn>
            </div>
          </div>
        </div>
        <div class="map-guide-area">
          <div class="map-list">
            <div class="total">검색결과 2건</div>
            <ul class="list">
              <li v-for="(item, index) in mapList" :key="index">
                <div class="pos-info" @click="mapChange(index)">
                  <div class="title">
                    <span class="seq">{{ index + 1 }}</span>
                    <b class="bold">{{ item.name }}</b>
                  </div>
                  <div class="address">
                    {{ item.address }}
                  </div>
                  <div class="phone">{{ item.phone }}</div>
                  <div class="txt">
                    {{ item.distence }}km
                    <div class="right">
                      <v-btn class="btn-more" @click="mapSelected(index)">선택</v-btn>
                    </div>
                  </div>
                  <div v-if="item.flag.length > 0" class="flag-list">
                    <span v-for="(flag, idx) in item.flag" :key="idx" class="flag">{{ flag }}</span>
                  </div>
                </div>
              </li>
            </ul>
          </div>
          <div class="map-view">
          <div v-if="mapCheck !== ''" class="map-tooltip" style="top:142px;left:415px;">
            <v-btn class="close"><span class="offscreen">툴팁닫기</span></v-btn>
            <div class="pos-info">
              <div class="title">
                <span class="seq">{{ mapCheck.seq }}</span>
                <b class="bold">{{ mapCheck.name }}</b>
              </div>
              <div class="address">
                {{ mapCheck.address }}
              </div>
              <div class="phone">{{ mapCheck.phone }}</div>
              <div class="flag-list">
                <div class="left">
                  <template v-if="mapCheck.flag.length > 0" class="flag-list">
                    <span v-for="(flag, idx) in mapCheck.flag" :key="idx" class="flag">{{ flag }}</span>
                  </template>
                </div>
                <div class="right">
                  <v-btn class="btn-more" @click.stop="mapSelected(mapCheck.seq -1 )">선택</v-btn>
                </div>
              </div>
            </div>
          </div>
          </div>
        </div>
    </div>
    </transition>
  </div>
</template>

<script>
import { mapGetters, mapMutations } from 'vuex'
export default {
  data() {
    return {
      isOptionsShow: false,
      addressPopVisible: false,
      mapCheck: '',
    }
  },
  computed: {
    ...mapGetters({
      testDrivingStep: 'vihiclesModules/testDrivingStep',
      mapList: 'vihiclesModules/mapList',
      checkedMap: 'vihiclesModules/checkedMap',
    }),
  },
  watch:{
    testDrivingStep(oldVal, newVal){
       if(newVal !== oldVal){
          this.setStep()
       }
    }
  },
  mounted() {
    this.setStep()
  },
  methods: {
    ...mapMutations({
      setTestDrivingStep: 'vihiclesModules/setTestDrivingStep',
      setMapCheck: 'vihiclesModules/setMapCheck',
    }),
    setStep(){
      this.testDrivingStep === 2
        ? [this.testDrivingSlideToggle(2,'open'), this.isOptionsShow = true]
        : [this.testDrivingSlideToggle(2,'close'), this.isOptionsShow = false]
    },
    mapChange(index){
     this.mapCheck = this.mapList[index]
    },
    mapSelected(index) {
      this.setMapCheck(index)
      this.isOptionsShow = !this.isOptionsShow
      this.mapCheck = this.mapList[index]
      this.setTestDrivingStep('')
      this.$emit('completed', ['step2', this.mapCheck])
    },
    showChange(){
      this.isOptionsShow = !this.isOptionsShow
      if(this.isOptionsShow === true){
        this.setTestDrivingStep(2)
      }else{
        this.setTestDrivingStep('')
        this.$emit('completed', ['step2', this.mapCheck])
      }
    }
  },
}
</script>