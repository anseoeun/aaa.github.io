<template>
  <!-- 2021.04.14(ver1.1) 액션관련하여 step1~ step5까지 전체적인 수정있음 -->
  <div class="content vehicles test-driving">
    <v-pageheader
      :top-breadcrumb="topBreadcrumb"
      page-title="시승 신청"
      page-infotext="현대자동차에서 제공하는 편리한 시승 신청 서비스를 이용해보세요."
    />

    <div ref="wrap" class="test-driving-wrap">
      <!-- STEP 1. 시승 모델 (엔진) -->
      <step1 @completed="checkNextStep" />
      <!-- STEP 2. 드라이빙 라운지 -->
      <step2 @completed="checkNextStep"
        @addressPop="popupVisible.address = true"
       />
      <!-- STEP 3. 시승 차량 및 시승 방법 -->
      <step3 @completed="checkNextStep" />
      <!-- STEP 4. 시승 일정 -->
      <step4 @completed="checkNextStep" />
      <!-- STEP 5. 신청자 정보 확인 및 고지사항 확인 -->
      <step5
        @testDrivePopup="popupVisible.testDrive = true"
        @privacyInfoPopup="popupVisible.privacyInfo = true"
        @privacyTrustPopup="popupVisible.privacyTrust = true"
        @carBuyPopup="popupVisible.carBuy = true"
        @agreeCheck="agreeCheck"
       />

      <div class="btn-box">
        <v-btn class="btn lg blue r" type="button" :disabled="btnCheck">시승 신청</v-btn>
      </div>

      <!-- 유의사항 -->
      <div class="notice-wrap">
        <div class="content-box">
          <strong class="title">유의사항</strong>
          <ul class="bullet-list">
            <li>시승 신청은 만 21세 이상 운전면허 소지자면 누구나 이용 가능합니다.</li>
            <li>시승 신청은 개인/법인 당 1건만 가능합니다.</li>
            <li>많은 고객님께 시승서비스를 제공하기 위해 고객님 한 분당 연간 6회까지의 시승 신청이 가능합니다.</li>
            <li>시승 차종의 색상 및 세부 사양은 사전 예고없이 변경될 수 있습니다.</li>
          </ul>
        </div>
      </div>
      <!-- // 유의사항 -->
    </div>

    <popup :visible.sync="popupVisible" />
  </div>
</template>

<script>
import { mapGetters, mapMutations } from 'vuex'
import Step1 from '~/pages/vehicles/test-driving/Step1'
import Step2 from '~/pages/vehicles/test-driving/Step2'
import Step3 from '~/pages/vehicles/test-driving/Step3'
import Step4 from '~/pages/vehicles/test-driving/Step4'
import Step5 from '~/pages/vehicles/test-driving/Step5'
import Popup from '~/components/page/vehicles/test-driving/popup'
export default {
  head() {
    return {
      title: '탐색 > 시승 신청',
    }
  },
  components: {
    Step1,
    Step2,
    Step3,
    Step4,
    Step5,
    Popup
  },
  data() {
    return {
      topBreadcrumb: [
        { linkName: '탐색', link: '/' },
        { linkName: '시승 신청', link: '/' },
      ],
      enginCheck: '',
      mapCheck: '',
      carCheck: '',
      selectedDate: {
        date: '',
        time: ''
      },
      btnCheck : true,
      popupVisible: {
        testDrive: false,
        privacyInfo: false,
        privacyTrust: false,
        carBuy: false,
        address: false,
      }
    }
  },
  computed: {
    ...mapGetters({
      testDrivingStep: 'vihiclesModules/testDrivingStep',
    }),
  },
  mounted(){
    this.setTestDrivingStep(1)
  },
  methods: {
    ...mapMutations({
      setTestDrivingStep: 'vihiclesModules/setTestDrivingStep',
    }),
    isNan(value){
      if(value !== undefined && value !== '' && value !== null){
        return true
      }else{
        return false
      }
    },
    checkNextStep(value){
      let index = 0
      if(value[0] === 'step1') {
        this.enginCheck = value[1]
      }else if(value[0] === 'step2') {
        this.mapCheck = value[1]
      }else if(value[0] === 'step3') {
        this.carCheck = value[1]
      }else if(value[0] === 'step4') {
        this.selectedDate = value[1]
      }

      if(this.isNan(this.enginCheck) === false) {
        index = 1
      }else if(this.isNan(this.mapCheck) === false) {
        index = 2
      }else if(this.isNan(this.carCheck) === false) {
         index = 3
      }else if(this.isNan(this.selectedDate.date) === false) {
         index = 4
      }else{
         index = 5
      }

      // console.log(index)

        this.setTestDrivingStep(index)
        //scroll
        document.documentElement.scrollTop = 187 * (index-1) + this.$refs.wrap.offsetTop
    },
    agreeCheck(val){
      if(val) this.btnCheck  = false
      else  this.btnCheck  = true
    }
  }
}
</script>
