<template>
  <div class="content vehicles model">
    <v-pageheader
      :top-breadcrumb="topBreadcrumb"
      page-title="모델비교"
    />
    <div class="car-model-wrap">
      <!-- comparision-model -->
      <div ref="fix" class="comparision-model-wrap">
        <div class="comparision-model">
          <div class="model-wrap">
            <div class="top-info-menu small-hide">
              <div class="left"><span class="txt">엔진 및 세부 등급은 가장 낮은 가격 기준이 기본으로 선택되고 아래에서 각 차량별 변경 가능합니다.</span></div>
              <div class="right">
                <span class="t-blue">전체 초기화 <i class="icon-reset"></i></span>
              </div>
            </div>
            <div class="model-list">
              <ul>
                <template v-for="idx in 4">
                    <li v-if="idx <= descData.length" :key="idx">
                      <div class="desc">
                          <v-btn v-if="idx > 1" class="delete small-hide"><span class="offscreen">삭제</span></v-btn>
                          <!-- 2021.04.06(ver1.2) logoTxt로변경 -->
                          <div class="logo">{{ descData[idx - 1].logoTxt }}</div>
                          <div class="car-name">{{ descData[idx - 1].name }}</div>
                          <!-- 2021.04.06(ver1.2) go-my-car 삭제
                          <div class="go-my-car small-hide"><v-btn type="nlink">내차 만들기</v-btn></div>
                           -->
                          <div class="car-img small-hide">
                            <v-img :src="descData[idx - 1].carImg.img" :alt="descData[idx - 1].carImg.alt"></v-img>
                          </div>
                          <div class="select small-hide">
                              <v-select
                                v-model="descData[idx - 1].enginValue"
                                :data="descData[idx - 1].enginList"
                                placeholder="Select"
                              />
                              <v-select
                                v-model="descData[idx - 1].trimValue"
                                :data="descData[idx - 1].trimList"
                                placeholder="Select"
                              />
                          </div>
                          <div class="total-price">
                            <div v-if="parseInt(descData[0].price) !== parseInt(descData[idx - 1].price)" class="margin">
                              <span v-if="parseInt(descData[0].price) > parseInt(descData[idx - 1].price)" class="down">{{ descData[0].price - descData[idx - 1].price | comma }} 원</span>
                              <span v-if="parseInt(descData[0].price) < parseInt(descData[idx - 1].price)" class="up">{{ descData[idx - 1].price - descData[0].price | comma }} 원</span>
                            </div>
                            <div class="account">
                              <div class="tit">총 구입 비용</div>
                              <div class="price"><b>{{ descData[idx - 1].price | comma }}</b> <span class="unit">원</span></div>
                            </div>
                          </div>
                          <ul class="matching-list small-hide">
                            <li>
                              <div class="tit">차량가격</div>
                              <div class="txt auto">{{ descData[idx - 1].carPrice }} 원</div>
                            </li>
                            <li>
                              <div class="tit">유지비용(3년)</div>
                              <div class="txt auto">(-) {{ descData[idx - 1].supportPrice }} 원</div>
                            </li>
                          </ul>
                          <!-- 2021.04.06(ver1.2) 고정된경우 나만의 캐스퍼 만들기로 구분 -->
                          <button v-if="descData[idx - 1].fixed" type="button" class="btn md white r small-hide">나만의 캐스퍼 만들기</button>
                          <button v-else type="button" class="btn md white r small-hide">변경하기</button>
                      </div>
                    </li>
                    <li v-else :key="idx">
                      <div class="car-select">
                        <p class="txt">비교차량을<br />선택해 주세요</p>
                        <i class="plus small-hide"></i>
                        <v-btn class="btn md white r" type="button" @click="comparisonPop = true">선택하기</v-btn>
                      </div>
                    </li>
                </template>
              </ul>
            </div>
          </div>
        </div>
      </div>
      <!-- // comparision-model -->

      <result />
    </div>

    <!-- 유의사항 -->
    <div class="notice-wrap">
      <div class="content-box">
        <strong class="title">유의사항</strong>
        <ul class="bullet-list">
          <li>자동차 이미지는 참조용으로 구입 시점과 제조사 수시 변경으로 판매차량과 다를 수 있으니 해당 모델 판매점에 확인바랍니다.</li>
          <li>상기 내용은 고객님의 차량 구입 의사 결정에 도움을 드리고자 제공하는 서비스로 법적인 효력이 없으며, 실제 구입 시 가격 및 조건에 따라 차이가 있을 수 있습니다.</li>
          <li>상기 차량별 비교 정보는 각 제조업체의 카탈로그 및 홈페이지에 공개된 자료를 바탕으로 작성 되었습니다.</li>
          <li>수시로 최신정보를 갱신하고 있으나 간혹 업데이트가 늦어지는 경우가 발생할 수 있습니다.</li>
        </ul>
      </div>
    </div>
    <!-- // 유의사항 -->

    <!-- 차량비교 팝업 -->
    <comparison-pop :visible="comparisonPop" @close="comparisonPop = false" @popFrequentlyCoparison="frequentlyCoparisonPop = true" />
    <!-- 공채 안내 -->
    <frequently-coparison :visible="frequentlyCoparisonPop" @close="frequentlyCoparisonPop = false" />
  </div>
</template>

<script>
import Result from './result'
import ComparisonPop from '~/components/page/vehicles/comparison/popup/Comparison'
import FrequentlyCoparison from '~/components/page/vehicles/comparison/popup/FrequentlyCoparison'
export default {
  head() {
    return {
      title: '모델 > 모델비교',
    }
  },
  components: {
    Result,
    ComparisonPop,
    FrequentlyCoparison
  },
  filters:{
    comma(val){
      return String(val).replace(/\B(?=(\d{3})+(?!\d))/g, ',')
    }
  },
  data() {
    return {
      topBreadcrumb: [
        { linkName: '모델', link: '/' },
        { linkName: '모델비교', link: '/' },
      ],
      descData: [
        {
          logoTxt:'캐스퍼',
          carImg:{
            img:  require('~/assets/images/temp/temp-payment-car-model.png'),
            alt: 'AX 스마트스트림 가솔린 1.1 터보 프리미엄 밀레니얼 A/T'
          },
          name:'캐스퍼',
          enginValue: '',
          enginList: [
            {value:'engin1', label:'엔진1'},
            {value:'engin2', label:'엔진2'},
            {value:'engin3', label:'엔진3'}
          ],
          trimValue: '',
          trimList: [
            {value:'trim1', label:'트림1'},
            {value:'trim2', label:'트림2'},
            {value:'trim3', label:'트림3'}
          ],
          price: '31800000',
          carPrice: '23,085,000',
          supportPrice: '19,858,734',
          fixed: true
        },
        {
          logoTxt:'제네시스',
          carImg:{
            img:  require('~/assets/images/temp/temp-payment-car-model.png'),
            alt: 'AX 스마트스트림 가솔린 1.1 터보 프리미엄 밀레니얼 A/T'
          },
          name:'G70',
          enginValue: '',
          enginList: [
            {value:'engin1', label:'엔진1'},
            {value:'engin2', label:'엔진2'},
            {value:'engin3', label:'엔진3'}
          ],
          trimValue: '',
          trimList: [
            {value:'trim1', label:'트림1'},
            {value:'trim2', label:'트림2'},
            {value:'trim3', label:'트림3'}
          ],
          price: '47085543 ',
          carPrice: '23,085,000',
          supportPrice: '19,858,734',
          fixed: false
        },
        {
          logoTxt:'현대',
          carImg:{
            img:  require('~/assets/images/temp/temp-payment-car-model.png'),
            alt: 'AX 스마트스트림 가솔린 1.1 터보 프리미엄 밀레니얼 A/T'
          },
          name:'베뉴',
          enginValue: '',
          enginList: [
            {value:'engin1', label:'엔진1'},
            {value:'engin2', label:'엔진2'},
            {value:'engin3', label:'엔진3'}
          ],
          trimValue: '',
          trimList: [
            {value:'trim1', label:'트림1'},
            {value:'trim2', label:'트림2'},
            {value:'trim3', label:'트림3'}
          ],
          price: '47085543 ',
          carPrice: '23,085,000',
          supportPrice: '19,858,734',
          fixed: false
        }
      ],
      comparisonPop: false,
      frequentlyCoparisonPop: false
    }
  },
  beforeMount () {
    window.addEventListener('scroll', this.handleScroll)
  },
  beforeDestroy() {
    window.removeEventListener('scroll', this.handleScroll)
  },
  mounted() {
    this.setLabel((idg) => {
      // console.dir(idg) // 자동 생성된 ID 배열, 예) 첫번째 입력폼 ID : idg[0]
    })
  },
  methods: {
    handleScroll () {
      // 2021.03.23 (ver1.1) window.scrollY -- > window.pageYOffset 으로변경 (익스문제)
      if(window.pageYOffset > this.$refs.fix.offsetTop){
        this.$refs.fix.classList.add('fix')
      }else{
        this.$refs.fix.classList.remove('fix')
      }
    }
  },
}
</script>