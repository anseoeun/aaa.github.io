<template>
  <div class="content vehicles event">
    <v-pageheader :top-breadcrumb="topBreadcrumb" page-title="이벤트" page-infotext="다양한 이벤트를 만나보세요" />
    <div class="event-wrap">
      <div class="content-inner">
        <v-tab class="tab-default" :data="tabList" :custom-label="true" :contents="true">
          <template slot="label" slot-scope="props"
            >{{ props.item.label }} <span v-if="props.item.value == 'tab1'">({{ evtList.length }})</span></template
          >
          <template slot="contents">
            <div data-id="tab1">
              <div class="event-list">
                <template v-if="evtList.length > 0">
                  <ul>
                    <li v-for="(item, index) in evtList" :key="index">
                      <v-btn type="nlink" to="/" role="button">
                        <div class="img">
                          <v-img :src="item.src" :alt="item.title" />
                        </div>
                        <p class="tit">{{ item.title }}</p>
                        <p class="date">{{ item.date }}</p>
                      </v-btn>
                    </li>
                  </ul>
                  <v-pagination :total="100" />
                </template>
                <template v-else>
                  <div class="no-event">
                      진행중인 이벤트가 없습니다.
                  </div>
                </template>
              </div>
            </div>
            <div data-id="tab2">
              <past-event />
            </div>
          </template>
        </v-tab>
      </div>
    </div>
  </div>
</template>

<script>
import { VPagination } from '~/components/element'
import PastEvent from '~/components/page/vehicles/enent/PastEvent'
export default {
  head() {
    return {
      title: '이벤트'
    }
  },
  components: {
    VPagination,
    PastEvent
  },
  data() {
    return {
      topBreadcrumb: [{ linkName: '이벤트', link: '/' }],
      tabList: [
        { value: 'tab1', label: '진행중인 이벤트' },
        { value: 'tab2', label: '지난 이벤트' }
      ],
      evtList: [
        {
          src: require('~/assets/images/temp/temp-event.jpg'),
          title: '9월 제휴 카드 구매 혜택',
          date: '2012.01.02 ~ 2021.01.31'
        },
        {
          src: require('~/assets/images/temp/temp-event.jpg'),
          title: '9월 제휴 카드 구매 혜택',
          date: '2012.01.02 ~ 2021.01.31'
        },
        {
          src: require('~/assets/images/temp/temp-event.jpg'),
          title: '9월 제휴 카드 구매 혜택',
          date: '2012.01.02 ~ 2021.01.31'
        },
        {
          src: require('~/assets/images/temp/temp-event.jpg'),
          title: '9월 제휴 카드 구매 혜택',
          date: '2012.01.02 ~ 2021.01.31'
        },
        {
          src: require('~/assets/images/temp/temp-event.jpg'),
          title: '9월 제휴 카드 구매 혜택',
          date: '2012.01.02 ~ 2021.01.31'
        },
        {
          src: require('~/assets/images/temp/temp-event.jpg'),
          title: '9월 제휴 카드 구매 혜택',
          date: '2012.01.02 ~ 2021.01.31'
        },
        {
          src: require('~/assets/images/temp/temp-event.jpg'),
          title: '9월 제휴 카드 구매 혜택',
          date: '2012.01.02 ~ 2021.01.31'
        },
        {
          src: require('~/assets/images/temp/temp-event.jpg'),
          title: '9월 제휴 카드 구매 혜택',
          date: '2012.01.02 ~ 2021.01.31'
        }
      ]
    }
  },
  mounted() {},
  methods: {}
}
</script>
