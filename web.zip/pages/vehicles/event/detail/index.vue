<template>
  <div class="content vehicles event-detail">
    <div class="event-detail-header">
      <v-pageheader
        :top-breadcrumb="topBreadcrumb"
      />
      <div class="date">2021.09.01 ~ 2021.09.31</div>
    </div>
    <div class="event-wrap">
      <div class="event-detail">
        <div class="event-view">
          이벤트 상세 <br />
          이벤트 상세 <br />
          이벤트 상세 <br />
          이벤트 상세 <br />
          이벤트 상세 <br />
          이벤트 상세 <br />
          이벤트 상세 <br />
          이벤트 상세 <br />
          <div class="content-inner">
            이벤트 상세 <br />
            이벤트 상세 <br />
            이벤트 상세 <br />
            이벤트 상세 <br />
            이벤트 상세 <br />
            이벤트 상세 <br />
            이벤트 상세 <br />
            이벤트 상세 <br />
          </div>
        </div>
        <div class="btn-box">
          <v-btn class="btn md white r" type="button">목록</v-btn>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  head() {
    return {
      title: '이벤트',
    }
  },
  components: {
  },
  data() {
    return {
      topBreadcrumb: [
        { linkName: '이벤트', link: '/' },
        { linkName: '이벤트명이 출력됩니다', link: '/' },
      ],
      data:[]
    }
  },
  mounted() {

  },
  methods: {

  },
}
</script>