<template>
  <div class="content mypage mypage-notice">
    <v-pageheader
      :top-breadcrumb="topBreadcrumb"
      page-title="MY 알림"
      page-infotext="이용 중인 현대자동차 서비스를 마이페이지에서 확인하세요."
    />

    <mypage-lnb />

    <div class="mypage-wrap">
      <div class="top-noti-info">
        <div class="right">
          <v-select
            v-model="selectListVal"
            :data="selectList"
            class="no-st"
          />
        </div>
      </div>
      <div class="alarm-list-wrap">
        <ul v-if="data.length > 0" class="alarm-list">
          <li v-for="(item, index) in data" :key="index">
            <div class="info-box">
              <span v-if="isNan(item.timeText)" class="date">{{ item.timeText }}</span>
              <div class="top">
                <span class="tag">{{ item.messageAffairsSectionName }}</span>
                <span v-if="isNan(item.timeInfo)" class="time">{{ item.timeInfo }}</span>
              </div>
              <p class="text" v-html="item.customerIntegrationNoticeSubstance"></p>
              <ul v-if="isNan(item.contract)" class="contract-info bullet-list">
                <li>계약번호 : {{ item.contract.number }}</li>
                <li>모델 : {{ item.contract.model }}</li>
              </ul>
              <nuxt-link v-if="isNan(item.link)" :to="item.link.linkAddr" class="btn-more">{{ item.link.linkText }}</nuxt-link>
            </div>
          </li>
        </ul>
        <div v-else class="no-alarm">
          <i></i>
          <strong class="title">{{ getCategoryName }} 내역의 새로운 알림이 없습니다.</strong>
          <p class="text">{{ getCategoryName }} 진행상태 및 관련 정보를 알림으로 받을 수 있습니다.</p>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import MypageLnb from '~/components/page/mypage/index/MypageLnb'
export default {
  head() {
    return {
      title: '마이페이지 > MY알림전체보기',
    }
  },
  name:'Mypage',
  components: {
    MypageLnb,
  },
  data() {
    return {
      topBreadcrumb: [
        { linkName: '마이페이지', link: '/' },
        { linkName: 'MY 알림', link: '/' },
        { linkName: 'MY 알림 전체보기', link: '/' },
      ],
      selectListVal: 'select1',
      selectList: [
        { value: 'select1', label: '전체보기' },
        { value: 'select2', label: '차량구매' },
        { value: 'select3', label: '신차사전예약' },
        { value: 'select4', label: '시승예약' },
        { value: 'select5', label: '1:1문의' },
        { value: 'select6', label: '기타' },
      ],
      getCategoryName: '신차사전예약',
      data: [
        {
          timeText: '오늘',
          messageAffairsSectionName: '전자서명 요청',
          timeInfo: '8분전',
          customerIntegrationNoticeSubstance: '[현대자동차 임직원차량구매] 계약작성기한 만료 안내 계약작성기한이 만료되어 해당계약이 자동 해약처리 되었습니다. 신규계약으로 차량구매 진행하시기 바랍니다.',
          contract: {
            number: 'A3721CN000009',
            model: '아반떼 CN7 자가용 가솔린 1.6 Modern A/T 런칭'
          },
          link: {
            linkText: '전자서명 하러가기',
            linkAddr: '/',
          },
        },
        {
          messageAffairsSectionName: '계약금 입금요청',
          timeInfo: '3시간전',
          customerIntegrationNoticeSubstance: '[현대자동차 임직원차량구매] 입금기한까지 계약금을 입금하셔야 계약이 완료됩니다. 계약금 입금은 발송된 알림통에서 확인부탁드립니다.',
          contract: {
            number: 'A3721CN000009',
            model: '아반떼 CN7 자가용 가솔린 1.6 Modern A/T 런칭'
          },
        },
        {
          timeText: '2021.02.05 금요일',
          messageAffairsSectionName: '1:1문의 답변',
          customerIntegrationNoticeSubstance: '고객님께서 등록하신 문의에 답변이 등록되었습니다.',
          link: {
            linkText: '1:1문의 답변 보러가기',
            linkAddr: '/',
          },
        },
        {
          timeText: '2021.02.01 월요일',
          messageAffairsSectionName: '시승예약',
          customerIntegrationNoticeSubstance: '시승예약이 완료되었습니다.<br />시승예약일 이전에 취소 가능하며, 취소 시 시승에 제한이 있을 수 있습니다.',
          link: {
            linkText: '시승예약 확인가기',
            linkAddr: '/',
          },
        },
      ],
    }
  },
  methods:{
    isNan(val) {
      return val != undefined &&  val != null && val != '' ? true : false
    }
  }
}
</script>
