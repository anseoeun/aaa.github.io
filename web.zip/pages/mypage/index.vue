<template>
  <div class="content mypage main">
    <v-pageheader :top-breadcrumb="topBreadcrumb"></v-pageheader>

    <section class="intro">
      <div class="title">
        <h1><em>김현대</em> 님 안녕하세요</h1>
        <p class="sub-text">이용 중인 현대자동차 서비스를 마이페이지에서 확인하세요.</p>
      </div>
      <ul class="my-info">
        <li>
          <nuxt-link to="/" role="button">
            <i class="icon-vehicles"></i>
            <em>최근 본 차량</em>
            <strong><span>10</span> 대</strong>
          </nuxt-link>
        </li>
        <li>
          <nuxt-link to="/" role="button">
            <i class="icon-coupon"></i>
            <em>보유쿠폰</em>
            <strong><span>2</span> 개</strong>
          </nuxt-link>
        </li>
        <li>
          <nuxt-link to="/" role="button">
            <i class="icon-point"></i>
            <em>블루멤버스 포인트</em>
            <strong><span>5,000</span> P</strong>
          </nuxt-link>
        </li>
      </ul>
      <ul class="my-menu">
        <li>
          <strong>나의<br />계약</strong>
          <ul>
            <li><nuxt-link to="/">구매(계약/결제) 내역</nuxt-link></li>
            <li><nuxt-link to="/">증빙서류 제출 내역</nuxt-link></li>
            <li><nuxt-link to="/">면세신고 내역</nuxt-link></li>
          </ul>
        </li>
        <li>
          <strong>나의<br />활동</strong>
          <ul>
            <li><nuxt-link to="/">견적 내역</nuxt-link></li>
            <li><nuxt-link to="/">구매후기</nuxt-link></li>
            <li><nuxt-link to="/">시승신청 내역</nuxt-link></li>
            <li><nuxt-link to="/">지인 추천 내역</nuxt-link></li>
            <li><nuxt-link to="/">1:1 문의 내역</nuxt-link></li>
          </ul>
        </li>
        <li>
          <strong>나의<br />혜택</strong>
          <ul>
            <li><nuxt-link to="/">쿠폰 내역</nuxt-link></li>
            <li><nuxt-link to="/">임직원 인증</nuxt-link></li>
          </ul>
        </li>
        <li>
          <strong>알림</strong>
          <ul>
            <li><nuxt-link to="/">MY 알림 전체보기</nuxt-link></li>
          </ul>
        </li>
      </ul>
    </section>

    <!-- 최근 계약 현황 -->
    <section class="my-contract">
      <div class="mypage-wrap">
        <div class="title">
          <h1>최근 계약 현황</h1>
          <v-btn type="nlink" to="/" class="btn-more">진행중인 계약 전체보기</v-btn>
        </div>
        <div class="contract-info">
          <ul>
            <li>계약번호<strong>A3720NX000265</strong></li>
            <li>모델명<strong>캐스퍼 가솔린 1.0 스마트 A/T 2WD</strong></li>
          </ul>
          <v-btn type="nlink" to="/" class="btn black sm r">자세히 보기</v-btn>
        </div>
        <div class="current-state">
          <div class="car-img"><v-img :src="mainImg.src" :alt="mainImg.alt"></v-img></div>
          <ol>
            <li>계약</li>
            <li>차량준비</li>
            <li class="active">결제</li>
            <li>배달탁송</li>
            <li>배달탁송완료</li>
          </ol>
        </div>
        <div class="contract-noti">
          <strong>절차 안내</strong>
          <p>
            현재 배달탁송 준비 중입니다.<br />선택형 서비스를 구매하실 수 있으며,<br />차량인수 확정 처리를 하실 수
            있습니다.
          </p>
          <v-btn type="nlink" to="/" class="btn blue sm r">선택형 서비스 구매<i class="icon-info"></i></v-btn>
          <v-btn type="nlink" to="/" class="btn blue sm r">차량인수 확정 처리<i class="icon-info"></i></v-btn>
        </div>
      </div>
    </section>

    <!-- 최근 견적 -->
    <section class="my-estimate">
      <div class="title">
        <h1>최근 견적</h1>
        <v-btn type="nlink" to="/" class="btn-more">전체보기</v-btn>
      </div>
      <ul v-if="estimteData.length > 0" class="estimate-list">
        <li v-for="(estimte, idx) in estimteData" :key="idx">
          <nuxt-link to="/" role="button">
            <div class="visual">
              <div class="car-img"><v-img :src="estimte.carImg.src" :alt="estimte.carImg.alt"></v-img></div>
              <div class="price">{{ estimte.price }} 원</div>
            </div>
            <ul class="flag-list">
              <li v-for="(flag, index) in estimte.flagData" :key="index">{{ flag.flagName }}</li>
            </ul>
            <strong class="name" v-html="estimte.name"></strong>
            <ul class="option-list">
              <li v-for="(option, idex) in estimte.optionData" :key="idex">{{ option.optionName }}</li>
            </ul>
          </nuxt-link>
        </li>
        <li class="add-estimate">
          <nuxt-link to="/">더 만들기</nuxt-link>
        </li>
      </ul>
      <!-- 디자인 TBD -->
      <div v-else class="no-data">
        <p>저장된 견적서가 없습니다. 나만의 캐스퍼를 만들고 견적으로 가격까지 알아보세요</p>
        <v-btn class="btn">나만의 캐스퍼 만들기</v-btn>
      </div>
    </section>
  </div>
</template>

<script>
export default {
  head() {
    return {
      title: '마이페이지'
    }
  },
  components: {},
  data() {
    return {
      topBreadcrumb: [{ linkName: '마이페이지', link: '/' }],
      mainImg: {
        src: require('~/assets/images/temp/temp-mypage-car-visual.png'),
        alt: '베뉴 자가용 LPG 1.6<br />Modern A/T'
      },
      estimteData: [
        {
          carImg: {
            src: require('~/assets/images/temp/temp-payment-car-model.png'),
            alt: '베뉴 자가용 LPG 1.6<br />Modern A/T'
          },
          price: '12,800,000',
          flagData: [{ flagName: '9월 할인차' }, { flagName: '할부' }],
          name: '캐스퍼 가솔린 1.0 터보 스마트 A/T 2WD',
          optionData: [{ optionName: '아틀라스 화이트' }, { optionName: '블랙모노 ' }, { optionName: '옵션2 ' }]
        },
        {
          carImg: {
            src: require('~/assets/images/temp/temp-mypage-car-visual.png'),
            alt: '베뉴 자가용 LPG 1.6<br />Modern A/T'
          },
          price: '12,800,000',
          flagData: [{ flagName: '일시불' }],
          name: '캐스퍼 가솔린 1.0 터보 스마트 A/T 2WD',
          optionData: [{ optionName: '아틀라스 화이트' }, { optionName: '블랙모노 ' }, { optionName: '옵션2 ' }]
        },
        {
          carImg: {
            src: require('~/assets/images/temp/temp-payment-car-model.png'),
            alt: '베뉴 자가용 LPG 1.6<br />Modern A/T'
          },
          price: '12,800,000',
          flagData: [{ flagName: '일시불' }],
          name: '캐스퍼 가솔린 터보 1.0<br />인스퍼레이션 A/T 2WD',
          optionData: [{ optionName: '아틀라스 화이트' }, { optionName: '블랙모노 ' }]
        }
      ]
    }
  }
}
</script>
