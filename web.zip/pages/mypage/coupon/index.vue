<template>
  <div class="content mypage mypage-coupon">
    <v-pageheader
      :top-breadcrumb="topBreadcrumb"
      page-title="쿠폰 내역"
      page-infotext="이용 중인 현대자동차 서비스를 마이페이지에서 확인하세요."
    />

    <mypage-lnb />

    <div class="mypage-wrap">
      <v-tab class="tab-default" :data="tabList" :contents="true">
        <template slot="contents">
          <!-- 보유 쿠폰 -->
          <div data-id="tab1">
            <div class="top-noti-info">
              <div class="left">
                <p class="bullet">쿠폰의 유효기간, 혜택, 사용조건 등을 사용전에 꼭 확인해주세요.</p>
              </div>
              <div class="right">
                <v-btn class="btn md white r">쿠폰등록</v-btn>
              </div>
            </div>
            <div class="list-board">
              <div class="list-header">
                <div class="title">쿠폰명</div>
                <div class="rate">할인금액/할인율</div>
                <div class="condition">사용조건</div>
                <div class="date">유효기간</div>
              </div>
              <div class="list-body">
                <template v-if="couponList.length > 0">
                  <ul>
                    <li v-for="(item, index) in couponList" :key="index">
                      <div class="desc">
                        <div class="title">{{ item.title }}</div>
                        <div class="rate">{{ item.rate }}</div>
                        <div class="condition">
                          <v-btn class="btn-detail">사용조건 자세히 보기</v-btn>
                        </div>
                        <div class="date">{{ item.date }}</div>
                      </div>
                    </li>
                  </ul>
                  <v-pagination :total="100" />
                </template>
                <template v-else>
                  <div class="list-null">
                    <i class="icon-coupon-none"></i>
                    <p>사용 가능한 쿠폰이 없습니다.</p>
                  </div>
                </template>
              </div>
            </div>
            <div class="page-notice">
              <ul class="bullet-list">
                <li>사용하지 않은 쿠폰은 유효기간이 만료되면 사용여부와 상관없이 자동 소멸됩니다.</li>
                <li>계약 취소 시 유효기간이 만료된 쿠폰은 복원되지 않으며 재사용할 수 있습니다.</li>
              </ul>
            </div>
          </div>
          <!-- 지난 쿠폰 내역 -->
          <div data-id="tab2">
            <past-coupon />
          </div>
        </template>
      </v-tab>
    </div>
  </div>
</template>

<script>
import MypageLnb from '~/components/page/mypage/index/MypageLnb'
import PastCoupon from '~/components/page/mypage/coupon/PastCoupon'
export default {
  head() {
    return {
      title: '마이페이지 > 쿠폰내역'
    }
  },
  components: {
    MypageLnb,
    PastCoupon
  },
  data() {
    return {
      topBreadcrumb: [
        { linkName: '마이페이지', link: '/' },
        { linkName: '나의 혜택', link: '/' },
        { linkName: '쿠폰 내역', link: '/' }
      ],
      tabList: [
        { value: 'tab1', label: '보유 쿠폰' },
        { value: 'tab2', label: '지난 쿠폰 내역' }
      ],
      couponList: [
        { title: 'AX 출시 기념 할인쿠폰', rate: '100,000원 할인', date: '2021.01.08 ~ 2021.02.07' },
        { title: '온라인 첫 차 구매 할인쿠폰', rate: '3% 할인', date: '2021.01.08 ~ 2021.02.07' },
        { title: 'AX 출시 기념 할인쿠폰', rate: '100,000원 할인', date: '2021.01.08 ~ 2021.02.07' }
      ]
    }
  }
}
</script>
