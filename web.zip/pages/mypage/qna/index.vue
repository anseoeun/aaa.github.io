<template>
  <div class="content mypage mypage-qna">
    <v-pageheader
      :top-breadcrumb="topBreadcrumb"
      page-title="1:1 문의 내역"
      page-infotext="이용 중인 현대자동차 서비스를 마이페이지에서 확인하세요."
    />

    <mypage-lnb />

    <div class="mypage-wrap">
      <div class="top-noti-info">
        <div class="right inbl-wrap">
          <v-select v-model="selectListVal" :data="selectList" class="no-st" style="width:110px" />
          <v-select v-model="selectListVal" :data="selectList" class="no-st" style="width:110px" />
          <v-btn class="note-btn btn-more" type="nlink">조회</v-btn>
        </div>
      </div>
      <!-- list-board -->
      <div class="list-board">
        <div class="list-header">
          <div class="cate">분류</div>
          <div class="title">제목</div>
          <div class="date">문의일자</div>
          <div class="status">진행상태</div>
          <div class="toggle"></div>
        </div>
        <div class="list-body">
          <template v-if="questionList.length > 0">
            <ul>
              <li v-for="(item, index) in questionList" :key="index">
                <div class="desc">
                  <div class="cate">[{{ item.cate }}]</div>
                  <div class="title">{{ item.title }}</div>
                  <div class="date">{{ item.date }}</div>
                  <div class="status">{{ item.status }}</div>
                  <div class="toggle">
                    <v-btn
                      type="icon"
                      :class="['icon-tog-arr off-gray', { on: isActive(index) }]"
                      @click="setActive(index)"
                      ><span class="offscreen">내용보기</span></v-btn
                    >
                  </div>
                </div>
                <div v-if="isActive(index)" class="detail">
                  <div class="view-wrap">
                    <div class="view">
                      <div class="text" v-html="item.content"></div>
                      <div class="file">
                        <a :href="`${item.file}`">{{ item.file }}</a>
                      </div>
                    </div>
                    <div class="delete">
                      <v-btn type="button" class="t-blue">삭제</v-btn>
                    </div>
                  </div>
                  <div class="answer-wrap">
                    <div class="answer">
                      <b class="tit">답변</b>
                      <div class="text" v-html="item.answer"></div>
                    </div>
                  </div>
                </div>
              </li>
            </ul>
            <v-pagination :total="100" />
          </template>
          <template v-else>
            <div class="list-null">
              <i class="icon-doc-none"></i>
              <p>작성하신 1:1문의가 없습니다.</p>
            </div>
          </template>
        </div>
      </div>
      <!-- // list-board -->
      <div class="btn-box t-right">
        <v-btn class="btn md white r" type="nlink">1:1 문의하기</v-btn>
      </div>
      <!-- 안내사항 -->
      <div class="page-notice">
        <div class="title">안내사항</div>
        <ul class="bullet-list">
          <li>문의하신 내용은 접수 처리 후, 담당자가 확인하여 성심껏 답변을 드리도록 하겠습니다.</li>
          <li>
            답변은 고객님 E-mail 계정으로 자동 발송되며, (<v-btn type="nlink" class="t-blue"
              >마이페이지 > 나의 1:1 문의내역</v-btn
            >)에서도 확인하실 수 있습니다.
          </li>
          <li>
            문의 작성 시 ‘SMS 알림 받기’에 체크하신 경우, 답변 완료 시 등록된 휴대폰 번호로 알림을 받으실 수 있습니다.
          </li>
          <li>한번 등록된 상담내용은 수정 불가능하며, 접수 전 상태인 경우 삭제 후 다시 문의해주시기 바랍니다.</li>
          <li>답변 완료된 내역은 삭제하실 수 있습니다.</li>
        </ul>
      </div>
      <!-- // 안내사항 -->
    </div>
  </div>
</template>

<script>
import MypageLnb from '~/components/page/mypage/index/MypageLnb'
import { VBtn } from '~/components/element'
export default {
  components: {
    MypageLnb,
    VBtn
  },
  data() {
    return {
      topBreadcrumb: [
        { linkName: '마이페이지', link: '/' },
        { linkName: '나의 활동', link: '/' },
        { linkName: '1:1문의 내역', link: '/' }
      ],
      selectListVal: '',
      selectList: [
        { value: '', label: '전체' },
        { value: 'select1', label: '선택1' },
        { value: 'select2', label: '선택2' },
        { value: 'select3', label: '선택3' }
      ],
      isView: false,
      listSelected: '',
      questionList: [
        {
          title: '1차량 계약 후 해지시 계약금은 환불 받을 수 있습니까?',
          cate: '차량구매 > 일반',
          date: '2021.01.08',
          status: '미확인',
          content:
            '즉시출고차, 할인차, 전시차, 판촉차, 생산주문 차량의 경우 차량 대금 결제 전, 마이페이지에서 계약 해약 시 계약금 환불이 가능합니다. 계약금을 현금으로 납부하셨다면 계약 해지시 입력하신 환불계좌로 계약금이 환불되며, 계약금을 카드로 납부하셨다면 7일 이내 카드 결제가 취소 됩니다.',
          answer:'즉시출고차, 할인차, 전시차, 판촉차, 생산주문 차량의 경우 차량 대금 결제 전, 마이페이지에서 계약 해약 시 계약금 환불이 가능합니다. <br /> 계약금을 현금으로 납부하셨다면 계약 해지시 입력하신 환불계좌로 계약금이 환불되며, 계약금을 카드로 납부하셨다면 7일 이내 카드 결제가 취소 됩니다.',
          file: 'hyundai.jpg'
        },
        {
          title: '2차량 계약 후 해지시 계약금은 환불 받을 수 있습니까?',
          cate: '차량구매 > 일반',
          date: '2021.01.08',
          status: '미확인',
          content:
            '즉시출고차, 할인차, 전시차, 판촉차, 생산주문 차량의 경우 차량 대금 결제 전, 마이페이지에서 계약 해약 시 계약금 환불이 가능합니다. 계약금을 현금으로 납부하셨다면 계약 해지시 입력하신 환불계좌로 계약금이 환불되며, 계약금을 카드로 납부하셨다면 7일 이내 카드 결제가 취소 됩니다.',
          answer:'즉시출고차, 할인차, 전시차, 판촉차, 생산주문 차량의 경우 차량 대금 결제 전, 마이페이지에서 계약 해약 시 계약금 환불이 가능합니다. <br /> 계약금을 현금으로 납부하셨다면 계약 해지시 입력하신 환불계좌로 계약금이 환불되며, 계약금을 카드로 납부하셨다면 7일 이내 카드 결제가 취소 됩니다.',
          file: 'hyundai.jpg'
        },
        {
          title: '3차량 계약 후 해지시 계약금은 환불 받을 수 있습니까?',
          cate: '차량구매 > 일반',
          date: '2021.01.08',
          status: '미확인',
          content:
            '즉시출고차, 할인차, 전시차, 판촉차, 생산주문 차량의 경우 차량 대금 결제 전, 마이페이지에서 계약 해약 시 계약금 환불이 가능합니다. 계약금을 현금으로 납부하셨다면 계약 해지시 입력하신 환불계좌로 계약금이 환불되며, 계약금을 카드로 납부하셨다면 7일 이내 카드 결제가 취소 됩니다.',
          answer:'즉시출고차, 할인차, 전시차, 판촉차, 생산주문 차량의 경우 차량 대금 결제 전, 마이페이지에서 계약 해약 시 계약금 환불이 가능합니다. <br /> 계약금을 현금으로 납부하셨다면 계약 해지시 입력하신 환불계좌로 계약금이 환불되며, 계약금을 카드로 납부하셨다면 7일 이내 카드 결제가 취소 됩니다.',
          file: 'hyundai.jpg'
        }
      ]
    }
  },
  methods: {
    setActive(index) {
      if (this.listSelected == index + 1) {
        this.listSelected = 0
      } else {
        this.listSelected = index + 1
      }
    },
    isActive(index) {
      return this.listSelected == index + 1
    }
  }
}
</script>
