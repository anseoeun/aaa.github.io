<template>
  <div class="content mypage test-driving">
    <v-pageheader
      :top-breadcrumb="topBreadcrumb"
      page-title="시승 신청 내역"
      page-infotext="예약하신 시승 내역을 확인해보세요."
    />

    <mypage-lnb />

    <div class="mypage-wrap ">
      <div class="test-driving-wrap">
        <div class="top-noti-info">
          <div class="left">
            <p class="title">시승신청상세 </p>
          </div>
        </div>
        <!-- 정보 -->
        <div class="matching-list driving-info">
          <ul>
            <li>
              <div class="tit">신청상태</div>
              <div class="right">
                  <span class="flag">시승대기</span>
              </div>
            </li>
            <li>
              <div class="tit">드라이빙 라운지</div>
              <div class="right">
                <b class="bold">드라이빙라운지 서초</b> <br />
                서울특별시 서초구 반포대로 54 (서초동, 문창빌딩) 1층 &nbsp;
                <v-btn class="btn-more" @click="popupVisible.drivingLounge = true">찾아오는 길</v-btn>
                <br />
                <!-- 2021-03-23 (ver1.1) 전화번호추가 -->
                02-812-7365
              </div>
            </li>
            <li>
              <div class="tit">시승차량</div>
              <div class="right">
                AX 스마트스트림 가솔린 1.1 모던 A/T <br />
                외장색상 : 미드나잇블랙     내장색상 : 베이지
              </div>
            </li>
            <li>
              <div class="tit">시승방법</div>
              <div class="right">
                셀프 시승 서비
              </div>
            </li>
            <li>
              <div class="tit">시승일시</div>
              <div class="right">
                2021년 2월 15일 13:00
              </div>
            </li>
          </ul>
          <ul>
            <li>
              <div class="tit">시승자 정보</div>
              <div class="righ">
                <div class="matching-list driver-info">
                  <ul>
                    <li>
                      <div class="tit bold">이름</div>
                      <div class="txt">홍길동</div>
                    </li>
                    <li>
                      <div class="tit bold">휴대폰번호</div>
                      <div class="txt">010-1234-5678</div>
                    </li>
                  </ul>
                </div>
              </div>
            </li>
          </ul>
        </div>
        <!-- // 정보 -->
        <div class="btm-noti-info">
          <div class="left">
            <p class="noti-txt">시승당일 취소 시 추후 시승 서비스 참여에 제약이 있으실 수 있습니다.</p>
          </div>
          <div class="right">
            <v-btn class="btn md white r">신청취소</v-btn>
          </div>
        </div>
      </div>
    </div>

    <driving-lounge :pop-visible="popupVisible" />
  </div>
</template>

<script>
import MypageLnb from '~/components/page/mypage/index/MypageLnb'
import DrivingLounge from '~/components/page/vehicles/test-driving/popup/DrivingLounge'
export default {
  head() {
    return {
      title: '마이페이지 > 나의 활동 > 시승 신청 내역',
    }
  },
  components: {
    MypageLnb,
    DrivingLounge
  },
  data() {
    return {
      topBreadcrumb: [
        { linkName: '마이페이지', link: '/' },
        { linkName: '나의 활동', link: '/' },
        { linkName: '시승 신청 내역', link: '/' },
      ],
      tabList: [
        { value: 'tab1', label: '보유 쿠폰' },
        { value: 'tab2', label: '지난 쿠폰 내역' },
      ],
      couponList: [
        { title: 'AX 출시 기념 할인쿠폰', rate: '100,000원 할인', date:'2021.01.08 ~ 2021.02.07', },
        { title: '온라인 첫 차 구매 할인쿠폰', rate: '3% 할인', date:'2021.01.08 ~ 2021.02.07', },
        { title: 'AX 출시 기념 할인쿠폰', rate: '100,000원 할인', date:'2021.01.08 ~ 2021.02.07', },
      ],
      popupVisible: {
        drivingLounge: false,
      }
    }
  },
}
</script>
