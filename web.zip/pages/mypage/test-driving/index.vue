<template>
  <div class="content mypage test-driving">
    <v-pageheader
      :top-breadcrumb="topBreadcrumb"
      page-title="시승 신청 내역"
      page-infotext="예약하신 시승 내역을 확인해보세요."
    />

    <mypage-lnb />

    <div class="mypage-wrap ">
      <div class="test-driving-wrap">
        <div class="top-noti-info">
          <div class="right">
            <v-btn class="btn-more">시승 체크포인트</v-btn>
          </div>
        </div>
        <div class="list-board">
          <div class="list-header">
            <div class="driving-date">시승일시</div>
            <div class="driving-rounge">드라이빙 라운지</div>
            <div class="driving-car">시승차량</div>
            <div class="status">상태</div>
            <div class="toggle"></div>
          </div>
          <div class="list-body">
            <template v-if="dataList.length > 0">
              <ul>
                <li v-for="(item, index) in dataList" :key="index">
                  <div class="desc">
                    <div class="driving-date">{{ item.date }}</div>
                    <div class="driving-rounge">{{ item.rounge }}</div>
                    <div class="driving-car">{{ item.car }}</div>
                    <div class="status">
                      <span class="flag">{{ item.status }}</span>
                    </div>
                    <div class="toggle">
                      <v-btn type="icon" :class="['icon-tog-arr off-gray', { on: isActive(index)}]" @click="setActive(index)"><span class="offscreen">내용보기</span></v-btn>
                    </div>
                  </div>
                  <div v-if="isActive(index)" class="detail">
                    <div class="view">
                      <div class="text">상세내용 TBD</div>
                    </div>
                  </div>
                </li>
              </ul>
              <v-pagination :total="100" />
            </template>
            <template v-else>
              <div class="list-null">
                <i class="icon-doc-none"></i>
                <p>시승 내역이 없습니다.</p>
              </div>
            </template>
          </div>
        </div>
        <!-- 안내사항 -->
        <div class="page-notice">
          <div class="title">안내사항</div>
          <ul class="bullet-list">
            <li>신청당일 취소 시 추후 시승서비스 참여에 제약이 있을 수 있습니다.</li>
            <li>시승은 한 해에 총6회만 가능합니다.</li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import MypageLnb from '~/components/page/mypage/index/MypageLnb'
export default {
  head() {
    return {
      title: '마이페이지 > 나의 활동 > 시승 신청 내역',
    }
  },
  components: {
    MypageLnb,
  },
  data() {
    return {
      topBreadcrumb: [
        { linkName: '마이페이지', link: '/' },
        { linkName: '나의 활동', link: '/' },
        { linkName: '시승 신청 내역', link: '/' },
      ],
      dataList: [
        { date: '2021.01.23 12:00~13:00', rounge: '드라이빙 라운지 강남', car:'아반떼 / Inspiration / 플루이드 메탈 / 가솔린 1.6 ', status:'시승대기' },
        { date: '2021.01.23 12:00~13:00', rounge: '드라이빙라운지 원효', car:'AX 스마트스트림 가솔린 1.1 터보 모던', status:'취소' },
      ],
      listSelected: ''
    }
  },
  methods:{
    setActive(index) {
      if(this.listSelected == index+1){
        this.listSelected = 0
      }else{
        this.listSelected = index+1
      }
    },
    isActive(index) {
      return this.listSelected == index+1
    },
  }
}
</script>
