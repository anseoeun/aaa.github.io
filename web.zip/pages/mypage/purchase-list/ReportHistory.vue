<template>
  <div class="content mypage report-history">
    <v-pageheader
      :top-breadcrumb="topBreadcrumb"
      page-title="차량 면세신고 내역"
      page-infotext="이용 중인 현대자동차 서비스를 마이페이지에서 확인하세요."
    />
    <mypage-lnb />

    <div class="mypage-wrap">
    <!-- report-historys-wrap -->
    <div class="report-history-wrap">
      <div class="top-noti-info noline">
        <div class="left inbl-wrap">
          <div class="date-wrap">
            <div class="label-input">
              <span class="offscreen">시작일</span>
              <v-date-picker v-model="startDate" class="datepicker" />
            </div>
            <span class="dash"></span>
            <div class="label-input">
              <span class="offscreen">종료일</span>
              <v-date-picker v-model="endDate" class="datepicker" />
            </div>
          </div>
          <v-select v-model="selectCalVal" :data="selectCalList" class="no-st" @change="calChange" />
        </div>
        <div class="right">
          <v-select v-model="statusListVal" :data="statusList" class="no-st" />
          <v-btn class="btn white md r">조회</v-btn>
        </div>
      </div>

      <div class="table-area report-list">
        <table>
          <colgroup>
            <col width="315px" />
            <col width="" />
          </colgroup>
          <tbody>
            <template v-if="dataList.length > 0">
              <tr v-for="(item, index) in dataList" :key="index">
                <td>
                  <div class="car-img"><v-img :src="item.carImg.src" :alt="item.carImg.alt"></v-img></div>
                </td>
                <td>
                  <div class="contract-num">
                    <span class="txt">계약번호</span>
                    <span class="num">{{ item.contractNum }}</span>
                  </div>
                  <div class="inner-table">
                    <table class="noline">
                      <colgroup>
                        <col width="140px" />
                        <col width="160px" />
                        <col width="" />
                        <col width="160px" />
                      </colgroup>
                      <thead>
                        <tr>
                          <th>결제일</th>
                          <th>자동차제작증 발급일</th>
                          <th>상태</th>
                          <th>면세신고</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr v-for="(detail, idx) in item.detailList" :key="idx">
                          <td>{{ detail.paymentDate }}</td>
                          <td>{{ detail.IssueDate }}</td>
                          <td>
                            <span class="flag">{{ detail.statusTxt }}</span>
                          </td>
                          <td>
                            <v-btn v-if="detail.status == 'before-noacc'" class="btn-more" :disabled="true">작성하기</v-btn>
                            <v-btn v-if="detail.status == 'after-noacc'" type="nlink" to="/" class="btn-more">작성하기</v-btn>
                            <v-btn v-if="detail.status == 'wait'" type="nlink" to="/" class="btn-more">수정하기</v-btn>
                            <v-btn v-if="detail.status == 'ing'" type="nlink" to="/" class="btn-more">내역보기</v-btn>
                            <v-btn v-if="detail.status == 'complete'" type="nlink" to="/" class="btn-more">내역보기</v-btn>
                            <div v-if="detail.sign" class="sign">
                              <v-btn class="btn-link">전자서명 메시지 재전송</v-btn>
                            </div>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </td>
              </tr>
            </template>
            <!-- 결과없음 -->
            <tr v-else>
              <td colspan="2">
                <div class="list-null">
                  <i class="icon"></i>
                  <!-- 2021.03.24 (ver1.1) 면세신고텍스트 추가-->
                  <p>면세신고 내역이 없습니다.</p>
                </div>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
      <v-pagination :total="100" />

      <!-- 안내사항 -->
      <div class="page-notice">
        <div class="title">안내사항</div>
        <ul class="bullet-list">
          <li>면세신고 작성 및 접수는 차량 등록 이후에 진행 가능합니다.</li>
          <li>차량 등록 및 증빙서류 승인과정을 포함하여 면세신고기한 내에 면세신고 완료 바랍니다.</li>
        </ul>
      </div>
    </div>
    </div>
  </div>
</template>

<script>
import MypageLnb from '~/components/page/mypage/index/MypageLnb'
export default {
  head() {
    return {
      title: '마이페이지 > 나의계약 > 차량 면세신고 내역'
    }
  },
  components: {
    MypageLnb,
  },
  data() {
    return {
      topBreadcrumb: [
        { linkName: '마이페이지', link: '/' },
        { linkName: '나의계약', link: '/' },
        { linkName: '차량 면세신고 내역', link: '/' }
      ],
      startDate: '',
      endDate: '',
      selectCalVal: '',
      selectCalList: [
        { value: '', label: '선택' },
        { value: 'week', label: '1주일' },
        { value: 'month', label: '1개월' }
      ],
      statusListVal: 'status1',
      statusList: [
        { value: 'status1', label: '전체상태' },
        { value: 'status2', label: '미접수' },
        { value: 'status3', label: '심사대기' }
      ],
      dataList: [
        {
          carImg: {
            src: require('~/assets/images/temp/temp-review-car.png'),
            alt: 'AX 스마트스트림 가솔린 1.1 터보 프리미엄 밀레니얼 A/T'
          },
          contractNum: 'AX123456748906',
          detailList: [
            {
               paymentDate: '2021.02.01',
               IssueDate: '2021.02.11',
               statusTxt:'미접수',
               status: 'before-noacc'
            },
            {
               paymentDate: '2021.02.01',
               IssueDate: '2021.02.11',
               statusTxt:'미접수',
               status: 'after-noacc'
            },
          ]
        },
         {
          carImg: {
            src: require('~/assets/images/temp/temp-review-car.png'),
            alt: 'AX 스마트스트림 가솔린 1.1 터보 프리미엄 밀레니얼 A/T'
          },
          contractNum: 'AX123456748906',
          detailList: [
            {
               paymentDate: '2021.02.01',
               IssueDate: '2021.02.11',
               statusTxt:'심사대기',
               status: 'wait'
            }
          ]
        },
         {
          carImg: {
            src: require('~/assets/images/temp/temp-review-car.png'),
            alt: 'AX 스마트스트림 가솔린 1.1 터보 프리미엄 밀레니얼 A/T'
          },
          contractNum: 'AX123456748906',
          detailList: [
            {
               paymentDate: '2021.02.01',
               IssueDate: '2021.02.11',
               statusTxt:'진행중',
               status: 'ing'
            }
          ]
        },
        {
          carImg: {
            src: require('~/assets/images/temp/temp-review-car.png'),
            alt: 'AX 스마트스트림 가솔린 1.1 터보 프리미엄 밀레니얼 A/T'
          },
          contractNum: 'AX123456748906',
          detailList: [
            {
               paymentDate: '2021.02.01',
               IssueDate: '2021.02.11',
               statusTxt:'심사승인',
               status: 'complete',
               sign: true
            }
          ]
        },
      ]
    }
  },
  methods: {
    //달력
    getDateStr(myDate) {
      let year = myDate.getFullYear()
      let month = myDate.getMonth() + 1
      let day = myDate.getDate()

      month = month < 10 ? '0' + String(month) : month
      day = day < 10 ? '0' + String(day) : day

      return year + '.' + month + '.' + day
    },
    today() {
      let d = new Date()
      return this.getDateStr(d)
    },
    lastWeek() {
      let d = new Date()
      let dayOfMonth = d.getDate()
      d.setDate(dayOfMonth - 7)
      return this.getDateStr(d)
    },
    lastMonth() {
      let d = new Date()
      let monthOfYear = d.getMonth()
      d.setMonth(monthOfYear - 1)
      return this.getDateStr(d)
    },
    calChange(value) {
      if (value == 'week') {
        this.startDate = this.today()
        this.endDate = this.lastWeek()
      } else if (value == 'month') {
        this.startDate = this.today()
        this.endDate = this.lastMonth()
      }
    }
  }
}
</script>
