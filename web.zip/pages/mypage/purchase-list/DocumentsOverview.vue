<template>
  <div class="content mypage document-detail">
    <v-pageheader
      :top-breadcrumb="topBreadcrumb"
      page-title="차량 증빙서류 제출 내역"
      page-infotext="이용 중인 현대자동차 서비스를 마이페이지에서 확인하세요."
    />

    <mypage-lnb />

    <div class="mypage-wrap">
      <!-- document-detail-wrap -->
      <div class="document-detail-wrap">
        <!-- 제출전 -->
        <div class="top-noti-info">
          <div class="left">
            <p class="title">
              [#]증빙서류 제출
              <span class="stxt">심사항목을 참고하여 제출바랍니다.</span>
            </p>
          </div>
        </div>
        <div class="matching-list judge-desc">
          <ul>
            <li>
              <div class="tit">계약번호</div>
              <div class="right f-row">
                <b>AX123456748904</b>
              </div>
            </li>
            <li>
              <div class="tit">접수/심사 결과</div>
              <div class="right"><span class="flag">미접수</span></div>
            </li>
          </ul>
        </div>
        <!-- // 제출전 -->
        <!-- 제출후 수정가능 -->
        <div class="top-noti-info">
          <div class="left">
            <p class="title">
              [#]증빙서류 제출
              <span class="stxt">업로드한 파일 수정이 가능합니다.</span>
            </p>
          </div>
        </div>
        <div class="matching-list judge-desc">
          <ul>
            <li>
              <div class="tit">계약번호</div>
              <div class="right f-row">
                <b>AX123456748904</b>
              </div>
            </li>
            <li>
              <div class="tit">접수/심사 결과</div>
              <div class="right"><span class="flag">심사대기</span></div>
            </li>
          </ul>
        </div>
        <!-- // 제출후 수정가능 -->
        <!-- 제출실패 -->
        <div class="top-noti-info">
          <div class="left">
            <p class="title">
              [#]증빙서류 제출
              <span class="stxt">실패사유를 확인 후 서류를 재 업로드 해주세요.</span>
            </p>
          </div>
        </div>
        <div class="matching-list judge-desc">
          <ul>
            <li>
              <div class="tit">계약번호</div>
              <div class="right f-row">
                <b>AX123456748904</b>
                  <!-- 2021.03.24 (ver1.1) 심사완료일 추가 -->
                  <div class="right">
                      <span class="t-gray">심사완료일 : 2021.03.31</span>
                  </div>
                </div>
            </li>
            <li>
              <div class="tit">접수/심사 결과</div>
              <div class="right"><span class="flag">심사실패(재검사)</span></div>
            </li>
          </ul>
        </div>
        <!-- // 제출실패 -->


        <div class="judge-cont">
          <!-- 접수하기 수정하기  judge-apply -->
          <div class="judge-apply">
            <v-tab class="tab-default free" :data="tabList" :contents="true" :value="tabStatus" @change="setTabStatus">
              <template slot="contents">
                <div data-id="tab1">
                  <p class="text-judge-list">
                    심사항목 : 주민등록등본, 장애인 복지카드
                  </p>
                  <ul class="bullet-list">
                    <li>공인인증서로 서류 제출없이 간편하게 심사 가능합니다. 무서류 간편 심사를 진행해 보세요.</li>
                    <li>
                      무서류 간편 심사는 공인인증서 로그인 한번으로 서류제출없이 자동으로 심사하는 시스템입니다. 동의사항
                      체크 후 진행해주세요.
                    </li>
                    <li>
                      무서류 증빙 심사 진행이 힘드시거나, 원치 않으시면 직접 파일 업로드하여 제출 가능합니다.
                      <span class="btn-go">
                        <v-btn class="btn-more" @click="tabStatus = 'tab2'">직접 파일 업로드하여 제출하기</v-btn>
                      </span>
                    </li>
                  </ul>
                  <!-- 심사서류 동의 -->
                  <div class="matching-list agree-list">
                    <ul>
                      <li>
                        <div class="tit">주민등록 등본</div>
                        <div class="right">
                          <div class="f-row">
                            <div class="agree">
                              <v-checkbox :one-check="true" :checked.sync="agreeVal1"
                                >공인인증서 제출을 통해 심사정보를 수집하는 것에 동의합니다.</v-checkbox
                              >
                              <ul class="bullet-list">
                                <li>대상 : 정부민원포탈 민원24</li>
                                <li>수집항목 : 주민등록등본</li>
                              </ul>
                            </div>
                            <div class="btn">
                              <v-btn class="btn md white r" type="button" :disabled="!agreeVal1">무서류 간편 심사</v-btn>
                            </div>
                          </div>
                        </div>
                      </li>
                      <li>
                        <div class="tit">장애인 복지카드</div>
                        <div class="right">
                          <div class="f-row">
                            <div class="agree">
                              <v-checkbox :one-check="true" :checked.sync="agreeVal2"
                                >공인인증서 제출을 통해 심사정보를 수집하는 것에 동의합니다.</v-checkbox
                              >
                              <ul class="bullet-list">
                                <li>대상 : 정부민원포탈 민원24</li>
                                <!-- 2021.03.24 (ver1.1) 텍스트변경 -->
                                <li>수집항목 : 장애인증명서, 장애인 복지카드</li>
                              </ul>
                            </div>
                            <div class="btn">
                              <v-btn class="btn md white r" type="button" :disabled="!agreeVal2">무서류 간편 심사</v-btn>
                            </div>
                          </div>
                        </div>
                      </li>
                    </ul>
                  </div>
                </div>
                <div data-id="tab2">
                  <p class="text-judge-list">
                    심사항목 : 주민등록등본, 장애인 복지카드
                  </p>
                  <p class="text-tit">선택한 항목에 알맞은 서류를 증명해 주세요.</p>
                  <ul class="bullet-list">
                    <li>확장자는 jpg, jpeg, png, gif, pdf만 가능합니다. (파일당 3MB 미만)</li>
                    <li>첨부파일에 주민등록번호 뒷부분 7자리가 있는 경우, 해당 내역은 가리고 업로드 바랍니다.</li>
                    <li>업로드한 파일이 있을 경우, 파일 삭제 후 재 업로드 하시기 바랍니다.</li>
                  </ul>
                  <div class="judge-file-upload">
                    <!-- 업로드전 -->
                    <ul>
                      <li v-for="(item, index) in fileList" :key="index">
                        <div class="seq">증빙 {{ index + 1 }}</div>
                        <div class="file-label">{{ item.name }}</div>
                        <div class="file-name">
                          <div class="file-input label-input">
                            <label class="offscreen">파일첨부</label>
                            <input
                              :ref="`fileInput`"
                              type="file"
                              :class="`offscreen fileInput${index}`"
                              @change="changeFile($event, index)"
                            />
                          </div>
                          <span v-if="item.val != ''" class="file">
                            {{ item.val }}
                            <v-btn class="btn-file-delete" type="button" @click="fileDelete(index)"
                              ><span class="offscreen">파일삭제</span></v-btn
                            >
                          </span>
                        </div>
                        <div class="file-btn">
                          <v-btn
                            class="file-btn btn-more"
                            :disabled="item.val != ''"
                            type="button"
                            @click="fileOpen(index)"
                            >파일업로드</v-btn
                          >
                        </div>
                      </li>
                    </ul>
                    <!-- 업로드후, 수정등 fileList2를 fileList로변경해야 업로드 정상작동 -->
                    <ul>
                      <li v-for="(item, index) in fileList2" :key="index">
                        <div class="seq">증빙 {{ index + 1 }}</div>
                        <div class="file-label">{{ item.name }}</div>
                        <div class="file-name">
                          <div class="file-input label-input">
                            <label class="offscreen">파일첨부</label>
                            <input
                              :ref="`fileInput`"
                              type="file"
                              :class="`offscreen fileInput${index}`"
                              @change="changeFile($event, index)"
                            />
                          </div>
                          <span v-if="item.val != ''" class="file">
                            {{ item.val }}
                            <v-btn class="btn-file-delete" type="button" @click="fileDelete(index)"
                              ><span class="offscreen">파일삭제</span></v-btn
                            >
                          </span>
                          <!-- 2021.03.24 (ver1.1) 실패 사유 메세지 추가 -->
                          <span v-if="item.val != ''" class="error">실패 사유 메세지를 노출해주세요</span>
                        </div>
                        <div class="file-btn">
                          <v-btn
                            class="file-btn btn-more"
                            :disabled="item.val != ''"
                            type="button"
                            @click="fileOpen(index)"
                            >파일업로드</v-btn
                          >
                        </div>
                        <!-- 2021.03.24 (ver1.1) 제출/심사승인 추가 -->
                        <div class="status t-gray">제출/심사승인</div>
                      </li>
                    </ul>
                    <p class="noti-txt">
                      서류를 찾기 어려우신가요?
                      <span class="btn-go">
                        <v-btn class="btn-more" @click="tabStatus = 'tab1'">무서류 간편 심사 진행하기</v-btn>
                      </span>
                    </p>
                  </div>
                  <!-- 2021.03.24 (ver1.1) btn-box 파일첨부심사 탭안으로 이동 -->
                  <div class="btn-box">
                    <v-btn class="btn lg blue line r" type="button">임시저장</v-btn>
                    <v-btn class="btn lg blue r" type="button">접수하기</v-btn>
                  </div>
                  <div class="btn-box">
                    <v-btn class="btn lg blue r" type="button">수정하기</v-btn>
                  </div>
                </div>
              </template>
            </v-tab>
          </div>
          <!-- // judge-apply -->
          <!-- 심사완료 result -->
          <div class="judge-result">
            <div class="completes-message">
              <i class="icon icon-complete-cehck"></i>
              무서류 차량 증빙 심사가 정상적으로 완료되었습니다.
            </div>
            <div class="completes-message">
              <i class="icon icon-complete-cehck"></i>
              차량 증빙 심사가 정상적으로 완료되었습니다.
            </div>
            <p class="text-tit">증빙항목</p>
            <div class="judge-file-upload">
              <ul>
                <li v-for="(item, index) in fileList3" :key="index">
                  <div class="seq">증빙 {{ index + 1 }}</div>
                  <div class="file-label">{{ item.name }}</div>
                  <div class="file-name">
                    <div v-if="item.val != ''" class="file">
                      {{ item.val }}
                    </div>
                  </div>
                  <div class="status">제출/승인완료</div>
                </li>
              </ul>
            </div>
            <div class="btn-box">
              <v-btn class="btn lg blue r" type="button">확인</v-btn>
            </div>
          </div>
          <!-- // 심사완료 result -->
          <!-- 심사중 result -->
          <div class="judge-result">
            <div class="completes-message">
              <i class="icon icon-complete-cehck"></i>
              <!-- 2021.03.24 (ver1.1) '차량' 텍스트 제거 -->
              접수된 증빙 서류를 심사중입니다.
            </div>
            <p class="text-tit">증빙항목</p>
            <div class="judge-file-upload">
              <ul>
                <li v-for="(item, index) in fileList2" :key="index">
                  <div class="seq">증빙 {{ index + 1 }}</div>
                  <div class="file-label">{{ item.name }}</div>
                  <div class="file-name">
                    <div v-if="item.val != ''" class="file">
                      {{ item.val }}
                    </div>
                  </div>
                  <!-- 2021.03.24 (ver1.1) 심사진행중으로 텍스트변경 -->
                  <div class="status">제출/심사진행중</div>
                </li>
              </ul>
            </div>
            <div class="btn-box">
              <v-btn class="btn lg blue r" type="button">확인</v-btn>
            </div>
          </div>
          <!-- // 심사중 result -->
        </div>
      </div>
    </div>

    <overview-evidences :visible="popVisible"
      @close="popVisible = false"
      @simpleJudge="tabStatus = 'tab1'"
      @fileupload="tabStatus = 'tab2'"
     />
  </div>
</template>

<script>
import MypageLnb from '~/components/page/mypage/index/MypageLnb'
import OverviewEvidences from '~/components/page/mypage/purchase-list/OverviewEvidences'
export default {
  head() {
    return {
      title: '마이페이지 > 차량 증빙서류 제출 내역'
    }
  },
  components: {
    MypageLnb,
    OverviewEvidences
  },
  data() {
    return {
      topBreadcrumb: [
        { linkName: '마이페이지', link: '/' },
        { linkName: '나의계약', link: '/' },
        { linkName: '차량 증빙서류 제출내역', link: '/' }
      ],
      popVisible: false,
      agreeVal1: false,
      agreeVal2: false,
      tabStatus: 'tab1',
      tabList: [
        { value: 'tab1', label: '무서류 간편 심사' },
        { value: 'tab2', label: '파일첨부 심사' }
      ],
      fileList: [
        { name: '장애인 복지카드(앞면)', val: '' },
        { name: '장애인 복지카드(뒷면)', val: '' },
        { name: '주민등록등본', val: '' }
      ],
      fileList2: [
        { name: '장애인 복지카드(앞면)', val: '장애인 복지카드(앞면).jpg' },
        { name: '장애인 복지카드(뒷면)', val: '장애인 복지카드(뒷면).jpg' },
        { name: '자동차 등록원', val: '' },
        { name: '주민등록등본', val: '' }
      ],
      fileList3: [
        { name: '장애인 복지카드(앞면)', val: '장애인 복지카드(앞면).jpg' },
        { name: '장애인 복지카드(뒷면)', val: '장애인 복지카드(뒷면).jpg' },
        { name: '주민등록등본', val: '' }
      ]
    }
  },
  mounted() {
    this.setLabel((idg) => {
      //console.dir(idg) // 자동 생성된 ID 배열
    })
    this.popVisible = true
  },
  methods: {
    setTabStatus(e) {
      this.tabStatus = e.value
    },
    changeFile(e, index) {
      var files = e.target.files || e.dataTransfer.files
      this.fileList[index].val = files[0].name
    },
    fileDelete(index) {
      this.fileList[index].val = ''
      // document.querySelector(`.fileInput${index}`).value = ''
    },
    fileOpen(index) {
      document.querySelector(`.fileInput${index}`).click()
    }
  }
}
</script>
