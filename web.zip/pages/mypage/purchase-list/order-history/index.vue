<template>
  <div class="content mypage mypage-purchase">
    <v-pageheader
      :top-breadcrumb="topBreadcrumb"
      page-title="구매 내역"
      page-infotext="저장된 차량 구매내역을 확인하실 수 있습니다."
    />
    <mypage-lnb />
    <order-history />
  </div>
</template>

<script>
import MypageLnb from '~/components/page/mypage/index/MypageLnb'
import OrderHistory from '~/components/page/mypage/purchase-list/OrderHistory.vue'

export default {
  head() {
    return {
      title: '마이페이지 > 구매 내역'
    }
  },
  components: {
    MypageLnb,
    OrderHistory
  },
  data() {
    return {
      topBreadcrumb: [
        { linkName: '마이페이지', link: '/' },
        { linkName: '나의 구매내역', link: '/' },
        { linkName: '구매 내역', link: '/' }
      ]
    }
  }
}
</script>
