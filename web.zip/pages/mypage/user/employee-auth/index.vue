<template>
  <div class="content mypage mypage-user">
    <v-pageheader
      :top-breadcrumb="topBreadcrumb"
      page-title="직원 인증"
      page-infotext="현대자동차 그룹사 및 협력사 임직원만 등록 가능합니다.<br>현재 재직중인 현대자동차 임직원은 사내 비즈니스지원라운지를 이용해주세요."
    >
      <!-- 2021.04.08 (ver1.2) 팝업추가 -->
      <v-btn class="btn-more" type="button" @click="PopAuthGuide = true">직원 할인 구매방법 안내</v-btn>
    </v-pageheader>

    <mypage-lnb />

    <div class="mypage-wrap employee-auth">
      <!-- 2021.03.31 (ver1.1) 전체수정 -->
      <div class="employee-auth-list">
        <div class="top-noti-info">
          <ul class="progress-type">
            <li> <!-- v-if="type === '1'" -->
              <div class="bullet">
                <strong>직원인증을 위해 기본 서류를 등록해 주세요. 서류 등록 후 심사가 시작됩니다.</strong>
              </div>
              <v-btn class="btn-info" type="icon" icon-class="icon-info" @click="PopEmployeeAuth = true"
                ><span class="offscreen">진행상태안내팝업보기</span></v-btn
              >
            </li>
            <li> <!-- v-if="type === '2'" -->
              <p class="title">
                진행상태
                <v-btn class="btn-info" type="icon" icon-class="icon-info" @click="PopEmployeeAuth = true"
                  ><span class="offscreen">진행상태안내팝업보기</span></v-btn
                >
              </p>
              <span class="flag">심사 대기</span>
              <div class="progress-text">올려주신 서류 확인을 위해 담당자를 배정하고 있습니다.</div>
            </li>
            <li> <!-- v-if="type === '3'" -->
              <p class="title">
                진행상태
                <v-btn class="btn-info" type="icon" icon-class="icon-info" @click="PopEmployeeAuth = true"
                  ><span class="offscreen">진행상태안내팝업보기</span></v-btn
                >
              </p>
              <span class="flag">심사 중</span>
              <div class="progress-text">
                현재 직원 인증 서류를 심사 중입니다. 심사 중에는 서류를 변경하실 수 없습니다.
              </div>
            </li>
            <!-- 2021.04.08 (ver1.3) 서류재요청type원복 -->
            <li> <!-- v-if="type === '4'" -->
              <p class="title">
                진행상태
                <v-btn class="btn-info" type="icon" icon-class="icon-info" @click="PopEmployeeAuth = true"
                  ><span class="offscreen">진행상태안내팝업보기</span></v-btn
                >
              </p>
              <span class="flag">서류 재요청</span>
              <div class="progress-text">
                등재해주셨던 서류에 이상이 있어 서류 재등록을 요청하였습니다. 사유 확인 후 서류를 다시 등록해주세요
              </div>
            </li>
            <li> <!-- v-if="type === '5'" -->
              <p class="title">
                진행상태
                <v-btn class="btn-info" type="icon" icon-class="icon-info" @click="PopEmployeeAuth = true"
                  ><span class="offscreen">진행상태안내팝업보기</span></v-btn
                >
              </p>
              <span class="flag">추가서류 요청</span>
              <div class="progress-text">
                인증 및 혜택 확인을 위해 추가 서류가 필요합니다. 아래 추가 서류를 등록해주세요.
              </div>
            </li>
            <li> <!-- v-if="type === '6'" -->
              <div class="bullet"><strong>인증성공!</strong> 직원인증이 성공적으로 완료되었습니다.</div>
              <v-btn class="btn-info" type="icon" icon-class="icon-info" @click="PopEmployeeAuth = true"
                ><span class="offscreen">진행상태안내팝업보기</span></v-btn
              >
            </li>
            <li> <!-- v-if="type === '7'" -->
              <div class="bullet">
                <strong><span>홍길동</span> 님은</strong> 현대자동차 그룹사 및 협력사 직원 인증 대상이 아닙니다.
              </div>
              <v-btn class="btn-info" type="icon" icon-class="icon-info" @click="PopEmployeeAuth = true"
                ><span class="offscreen">진행상태안내팝업보기</span></v-btn
              >
            </li>
          </ul>
        </div>

        <!-- 진행상태 : 기본서류요청 / 심사대기 / 추가서류요청 -->
        <el-form ref="askForm" :model="askForm" label-position="top">
          <div class="info-grid-list">
            <ul>
              <li>
                <strong class="info-title ct">이름</strong>
                <div class="info-group ct">홍길동</div>
              </li>
              <li>
                <strong class="info-title ct">기본서류</strong>

                <!-- 2021.04.08 (ver1.3) 서류재요청 원복 -->
                <div class="info-group">
                  <div class="file-upload-wrap">
                    <ul class="file-upload-list">
                      <li v-for="(item, index) in fileList" :key="index">
                        <div class="file-label">{{ item.name }}</div>
                        <div class="file-desc">
                          <template v-if="item.complete">
                            <div class="form-text">홍길동 가족관계증명서.jpg<span class="flag">완료</span></div>
                          </template>
                          <template v-else>
                            <div class="file-upload">
                              <div class="file-input">
                                <label class="offscreen">{{ item.name }}</label>
                                <input
                                  ref="fileInput"
                                  type="file"
                                  :class="`offscreen fileInput`"
                                  @change="changeFile($event, index)"
                                />
                                <v-input v-model="item.val" class="file-value" />
                                <v-btn class="btn-file-delete" type="button" @click="fileDelete(index)"
                                  ><span>파일삭제</span></v-btn
                                >
                              </div>
                              <v-btn class="file-btn btn-more" type="button" @click="fileOpen(index)">찾기</v-btn>
                            </div>
                            <p v-if="item.noti !== undefined" class="t-blue bullet-star">{{ item.noti }}</p>
                          </template>
                        </div>
                      </li>
                    </ul>
                    <ul class="bullet-list">
                      <li>
                        <!-- 2021.04.08 (ver1.3) 사진 파일 가능하며, 삭제 -->
                        파일 업로드 시, 파일당 3MB 를 넘지 않아야 합니다. 확장자는 jpg, jpeg, gif,
                        pdf 만 가능합니다.
                      </li>
                      <li>
                        업로드할 정보 중 주민등록번호 뒷부분 7자리가 있는 경우, 해당 내역은 가리고 업로드 바랍니다.
                        <v-btn class="btn-more" @click="PopIdNumSecure = true">예시</v-btn>
                      </li>
                    </ul>
                  </div>
                </div>
              </li>
              <li>
                <strong class="info-title ct">메모</strong>
                <div class="info-group">
                  <!-- 2021.04.08 (ver1.3) 텍스트수정 -->
                  <div class="form-label">회사명/소속/직원명/사번 입력</div>
                  <div class="label-input">
                    <label class="offscreen">회사명/소속/직원명/사번 입력</label>
                    <el-form-item label="" prop="titleName">
                      <v-input v-model="askForm.titleName" />
                    </el-form-item>
                  </div>
                </div>
              </li>
              <li>
                <strong class="info-title ct">추가서류</strong>

                <!-- 2021.04.08 (ver1.2) 서류재요청type삭제/수정 -->
                <div class="info-group">
                  <div class="file-upload-wrap">
                    <ul class="file-upload-list">
                      <li v-for="(item, index) in fileList2" :key="index">
                        <div class="file-label">{{ item.name }}</div>
                        <div class="file-desc">
                          <template v-if="item.complete">
                            <div class="form-text">홍길동 가족관계증명서.jpg<span class="flag">완료</span></div>
                          </template>
                          <template v-else>
                            <div class="file-upload">
                              <div class="file-input">
                                <label class="offscreen">{{ item.name }}</label>
                                <input
                                  ref="fileInput"
                                  type="file"
                                  :class="`offscreen fileInput${index}`"
                                  @change="changeFile($event, index)"
                                />
                                <v-input v-model="item.val" class="file-value" />
                                <v-btn class="btn-file-delete" type="button" @click="fileDelete(index)"
                                  ><span>파일삭제</span></v-btn
                                >
                              </div>
                              <v-btn class="file-btn btn-more" type="button" @click="fileOpen(index)">파일찾기</v-btn>
                            </div>
                          </template>
                        </div>
                      </li>
                    </ul>
                    <ul class="bullet-list">
                      <li>
                        <!-- 2021.04.08 (ver1.3) 사진 파일 가능하며, 삭제 -->
                        파일 업로드 시, 파일당 3MB 를 넘지 않아야 합니다. 확장자는 jpg, jpeg, gif,
                        pdf 만 가능합니다.
                      </li>
                      <li>
                        업로드할 정보 중 주민등록번호 뒷부분 7자리가 있는 경우, 해당 내역은 가리고 업로드 바랍니다.
                        <v-btn class="btn-more" @click="PopIdNumSecure = true">예시</v-btn>
                      </li>
                    </ul>
                  </div>
                </div>
              </li>
            </ul>
          </div>
        </el-form>

        <!-- 진행상태 : 심사중 / 인증완료 -->
        <div class="info-grid-list">
          <ul>
            <li>
              <strong class="info-title ct">이름</strong>
              <div class="info-group ct">홍길동</div>
            </li>
            <li>
              <strong class="info-title ct">기본서류</strong>
              <div class="info-group">
                <div class="file-upload-wrap">
                  <ul class="file-upload-list">
                    <li>
                      <div class="form-text">홍길동 재직증명서.jpg<span class="flag">완료</span></div>
                    </li>
                    <li>
                      <div class="form-text">홍길동 가족관계증명서.jpg<span class="flag">완료</span></div>
                    </li>
                  </ul>
                </div>
              </div>
            </li>
            <li>
              <strong class="info-title ct">메모</strong>
              <div class="info-group">
                <div class="form-text">현대위아 123456789</div>
              </div>
            </li>
            <li>
              <strong class="info-title ct">추가서류</strong>
              <div class="info-group">
                <div class="file-upload-wrap">
                  <ul class="file-upload-list">
                    <li><div class="form-text">차량구입대상자 확인서.jpg</div></li>
                    <li><div class="form-text">주민등록등본 or 가족관계증명서.pdf</div></li>
                    <li><div class="form-text">4대보험가입자 가입내역확인서.pdf</div></li>
                    <li><div class="form-text">근속DC 확인서.pdf</div></li>
                    <li><div class="form-text">개인사업자등록증.pdf</div></li>
                  </ul>
                </div>
              </div>
            </li>
            <li>
              <strong class="info-title ct">혜택 정보</strong>
              <div class="info-group ct">판매대리점 대표자</div>
            </li>
            <li>
              <strong class="info-title ct">할인율</strong>
              <div class="info-group ct">20% 할인</div>
            </li>
            <li>
              <strong class="info-title ct">최근 직원용 차량 구매일</strong>
              <div class="info-group ct">2022.01.06</div>
            </li>
            <li>
              <strong class="info-title ct">다음 직원용 차량 구매 가능일</strong>
              <div class="info-group ct">2022.01.06 - 이후</div>
            </li>
            <li>
              <strong class="info-title ct">인증 유효기간</strong>
              <div class="info-group ct">- 2021.03.13 까지</div>
            </li>
          </ul>
        </div>

        <!-- 진행상태 : 인증불가 -->
        <div class="info-grid-list">
          <p>자세한 사항은 고객지원 &gt; 1:1문의에 문의해주세요.</p>
        </div>

        <!-- 인증성공상태일때 노출 -->
        <p class="bullet-star">이직, 근속년수 증가 등으로 할인혜택 변경이 예상될 경우, 임직원 재인증을 진행하세요.</p>
      </div>

      <div v-if="type === '1'" class="btn-box t-center">
        <v-btn type="button" class="btn lg gray r">취소</v-btn>
        <v-btn type="button" class="btn lg blue r">등록</v-btn>
      </div>
      <div v-if="type === '2'" class="btn-box t-center">
        <v-btn type="button" class="btn lg gray r">취소</v-btn>
        <v-btn type="button" class="btn lg blue r">재등록</v-btn>
      </div>
      <div v-if="type === '3'" class="btn-box t-center">
        <v-btn type="button" class="btn lg blue r">확인</v-btn>
      </div>

      <!-- 2021.04.08 (ver1.2) 서류재요청type삭제/수정 -->
      <div v-if="type === '4'" class="btn-box t-center">
        <v-btn type="button" class="btn lg gray r">취소</v-btn>
        <v-btn type="button" class="btn lg blue r">등록</v-btn>
      </div>
      <div v-if="type === '5'" class="btn-box t-center">
        <v-btn type="button" class="btn lg blue r">직원 재인증</v-btn>
      </div>
      <div v-if="type === '6'" class="btn-box t-center">
        <v-btn type="button" class="btn lg blue r">임직원 재인증</v-btn>
      </div>

      <!-- 안내사항 -->
      <div class="page-notice">
        <div class="title">안내사항</div>
        <ul class="bullet-list">
          <li>재구입 연한 : 임직원 할인 구매는 2년에 1회만 적용 가능합니다.</li>
          <li>
            의무보유기간
            <ul>
              <li>
                <!-- 2021.04.08 (ver1.2) 텍스트수정 -->
                - 퇴임 중역, 대리점, 당사 임직원 동일 처우 직원의 경우, 임직원 할인 적용 차량을 2년간 의무 보유 하셔야
                합니다.
              </li>
              <li>- 계약직의 경우, 퇴사시까지 임직원 할인 적용 차량을 2년간 의무 보유하셔야 합니다.</li>
              <li>
                - 퇴직 전에 임직원 할인 적용 차량을 구입한 당사 정년 퇴직자(명예사원증 보유자)라도 해당 차량을 2년간
                보유하지 않으면 임직원 할인을 받으실 수 없습니다.<br />(2년 內 전매한 경우는 1회에 한해 재 구매 불가)
              </li>
            </ul>
          </li>
          <li>본인/배우자/보인과 배우자/장애인과 본인 명의로 구입가능합니다.</li>
          <li>
            할인율 등의 자세한 사항은 근무하시는 회사의 담당부서 및 캐스퍼 전용 고객센터(080-000-0000)로 문의 바랍니다.
          </li>
        </ul>
      </div>
      <!-- // 안내사항 -->

      <!-- 팝업 -->
      <!-- 2021.04.08 (ver1.2) 팝업추가 -->
      <pop-auth-guide :visible="PopAuthGuide" @close="PopAuthGuide = false" />
      <pop-employee-auth :visible="PopEmployeeAuth" @close="PopEmployeeAuth = false" />
      <pop-id-num-secure :visible="PopIdNumSecure" @close="PopIdNumSecure = false" />
    </div>
  </div>
</template>

<script>
import MypageLnb from '~/components/page/mypage/index/MypageLnb'
import { VBtn, VInput } from '~/components/element'
import PopAuthGuide from '~/components/page/mypage/user/PopAuthGuide'
import PopEmployeeAuth from '~/components/page/mypage/user/PopEmployeeAuth'
import PopIdNumSecure from '~/components/page/mypage/user/PopIdNumSecure'
export default {
  head() {
    return {
      title: '마이페이지 > 직원 인증'
    }
  },
  components: {
    MypageLnb,
    VBtn,
    VInput,
    PopAuthGuide,
    PopEmployeeAuth,
    PopIdNumSecure
  },
  props: {
    type: {
      type: String,
      default: () => '1'
    }
  },
  data() {
    return {
      topBreadcrumb: [
        { linkName: '마이페이지', link: '/' },
        { linkName: '직원 인증', link: '/' }
      ],
      askForm: {
        titleName: ''
      },
      fileList: [
        { name: '재직증명서, 명예사원증, 임원우대증 중 택1', val: '', noti: '최근 3개월 내 발급된 재직증명서로 재등록 해주세요' },
        { name: '가족관계증명서', val: '홍길동 가족관계증명서.jpg' },
        { name: '가족관계증명서', val: '홍길동 가족관계증명서.jpg', complete: true }
      ],
      fileList2: [
        { name: '주민등록등본 or 가족관계증명서', val: '홍길동 가족관계증명서.jpg', complete: true },
        { name: '4대보험가입자 가입내역확인서', val: '' },
        { name: '근속DC 확인서', val: '근속DC 확인서.pdf' },
        { name: '개인사업자등록증', val: '개인사업자등록증.pdf' }
      ],
      authList: '',
      // 2021.04.08 (ver1.2) 팝업추가
      PopAuthGuide: false,
      PopEmployeeAuth: false,
      PopIdNumSecure: false
    }
  },
  mounted() {
    this.setLabel((idg) => {
      //console.dir(idg) // 자동 생성된 ID 배열
    })
  },
  methods: {
    changeFile(e, index) {
      var files = e.target.files || e.dataTransfer.files
      this.fileList[index].val = files[0].name
    },
    fileDelete(index) {
      document.querySelector(`.fileInput${index}`).value = ''
      this.fileList[index].val = ''
    },
    fileOpen(index) {
      document.querySelector(`.fileInput${index}`).click()
    }
  }
}
</script>
