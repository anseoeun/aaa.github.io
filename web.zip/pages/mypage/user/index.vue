<template>
  <div class="content mypage mypage-user">
    <v-pageheader
      :top-breadcrumb="topBreadcrumb"
      page-title="회원정보관리"
      page-infotext="회원님의 소중한 정보를 안전하게 관리하세요"
    />

    <mypage-lnb />

    <div class="mypage-wrap">
      <p class="user-notice">AX홈페이지는 현대닷컴 과 통합회원으로 사용되고 있습니다.<br />회원정보수정 및 관련 서비스를 현대닷컴에서 통합으로 진행됩니다.</p>
      <section class="information-detail">
        <div class="summary-info">
          <h1 class="title">기본정보</h1>
        </div>
        <div class="detail-info">
          <div class="info-grid-list">
            <ul>
              <li>
                <strong class="info-title">이름</strong>
                <div class="info-group">김현대</div>
              </li>
              <li>
                <strong class="info-title">휴대전화번호</strong>
                <div class="info-group">010-1234-5678</div>
              </li>
              <li>
                <strong class="info-title">이메일주소</strong>
                <div class="info-group">abcdefg@Hyundai.com</div>
              </li>
            </ul>
          </div>
        </div>
      </section>
      <div class="btn-wrap">
        <ul>
          <li><a href="javascript:void(0);" target="_blank" title="새창 열기" class="btn white md r">회원정보 수정</a></li>
          <li><a href="javascript:void(0);" target="_blank" title="새창 열기" class="btn white md r">비밀번호 변경</a></li>
          <li><a href="javascript:void(0);" target="_blank" title="새창 열기" class="btn gray line md r">회원탈퇴</a></li>
        </ul>
      </div>
      <p class="bullet-star t-gray">회원정보 수정, 비밀번호 변경 회원탈퇴는 현대닷컴 홈페이지로 이동하여 진행됩니다.</p>
    </div>
  </div>
</template>

<script>
import MypageLnb from '~/components/page/mypage/index/MypageLnb'
export default {
  head() {
    return {
      title: '마이페이지 > 회원정보관리',
    }
  },
  components: {
    MypageLnb,
  },
  data() {
    return {
      topBreadcrumb: [
        { linkName: '마이페이지', link: '/' },
        { linkName: '회원정보관리', link: '/' },
      ],
    }
  },
}
</script>
