<template>
  <div class="content mypage recommend">
    <v-pageheader
      :top-breadcrumb="topBreadcrumb"
      page-title="지인 추천 내역"
      page-infotext="지인 추천 내역을 확인하실 수 있습니다."
    />

    <mypage-lnb />

    <div class="mypage-wrap ">
      <div class="recommend-wrap">
        <div class="top-noti-info">
          <div class="left">
            <p class="title">지인 추천 혜택
                <span class="stxt">친구에게 AX를 소개하고 지인 추천 혜택을 나눠 가지세요</span>
            </p>
          </div>
        </div>
        <div class="recommend-benefit">
          <div class="point-benefit">
            <div class="box">
              <i class="icon-mem-point"></i>
              <p class="txt">추천인(나)</p>
              <p class="account">
                블루멤버스 포인트 <b class="bold">###P</b> 적립
              </p>
            </div>
            <div class="arr"></div>
            <div class="box">
              <i class="icon-mem-percent"></i>
              <p class="txt">추천받은 지인</p>
              <p class="account">
                <b class="bold">###,###원</b> 할인
              </p>
            </div>
          </div>
          <div class="exp-text">
            <b class="bold">지인 추천 혜택이란?</b>
            <p class="txt">
                AX를 구입하신 고객님께만 드리는 혜택으로 <br />
                나의 추천인 링크를 통해 <br />
                추천 받은 지인이 AX를 구입하면 <br />
                추천인(나)에게 블루멤버스 포인트 <b>##P 적립 혜택</b>을 <br />
                추천 받은 지인에게 <b>###.###원 할인 혜택</b>을 드립니다.
            </p>
          </div>
        </div>
        <div class="recommend-link">
          <div class="link-wrap">
            <b>나의 추천인 링크</b>
            <div class="link">
              <div class="input">
                <v-input ref="shareurl" v-model="linkVal"></v-input>
              </div>
              <v-btn class="btn md white r" type="button" @click="copyUrl">링크 복사</v-btn>
            </div>
          </div>
          <div class="point-wrap">
            <b>지금까지 받은 추천 혜택</b>
            <div class="point-box">
              <span class="txt">블루멤버스 포인트</span>
              <div class="point">
                <b>105,450</b>
                <span class="unit">p</span>
                적립
              </div>
            </div>
          </div>
        </div>
        <div class="recommend-link">
          <div class="link-wrap">
            <b>나의 추천인 링크</b>
            <div class="link">
              <div class="input">
                <v-input :disabled="true"></v-input>
              </div>
              <v-btn class="btn md white r" type="button" :disabled="true">링크 복사</v-btn>
            </div>
          </div>
          <div class="point-wrap">
            <b>지금까지 받은 추천 혜택</b>
            <div class="point-box">
              <span class="txt">블루멤버스 포인트</span>
              <div class="point">
                <b>105,450</b>
                <span class="unit">p</span>
                적립
              </div>
            </div>
          </div>
        </div>

        <div class="top-noti-info">
          <div class="left">
            <p class="title">추천 내역</p>
          </div>
        </div>
        <div class="list-board">
          <div class="list-header">
            <div class="date">계약일</div>
            <div class="title">추천 받은 지인</div>
            <div class="test-car">시승차량</div>
            <div class="reward-status">리워드 상태</div>
          </div>
          <div class="list-body">
            <template v-if="dataList.length > 0">
              <ul>
                <li v-for="(item, index) in dataList" :key="index">
                  <div class="desc">
                    <div class="date">{{ item.date }}</div>
                    <div class="title">{{ item.person }}</div>
                    <div class="test-car">{{ item.car }}</div>
                    <div class="reward-status">
                      <span class="flag">{{ item.status }}</span>
                    </div>
                  </div>
                </li>
              </ul>
              <v-pagination :total="100" />
            </template>
            <template v-else>
              <div class="list-null">
                <i class="icon-doc-none"></i>
                <p>추천 내역이 없습니다.</p>
              </div>
            </template>
          </div>
        </div>
        <!-- 안내사항 -->
        <div class="page-notice">
          <div class="title">안내사항</div>
          <ul class="bullet-list">
            <li>추천 혜택은 AX를 구입한 고객에게만 드리는 혜택으로 AX 구입 후 제작증 발급을 완료한 고객님게만 추천인 링크를 제공합니다.</li>
            <li>추천인의 리워드는 피추천인(추천 받은 지인)의 차량인수완료 후 2~3일 영업을 이내에 지급됩니다.</li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import MypageLnb from '~/components/page/mypage/index/MypageLnb'
export default {
  head() {
    return {
      title: '마이페이지 > 나의 활동 > 지인 추천 내역',
    }
  },
  components: {
    MypageLnb,
  },
  data() {
    return {
      topBreadcrumb: [
        { linkName: '마이페이지', link: '/' },
        { linkName: '나의 활동', link: '/' },
        { linkName: '지인 추천 내역', link: '/' },
      ],
      dataList: [
        { date: '2021.01.23', person: 'H0003', car:'계약진행중 ', status:'대기' },
        { date: '2021.01.23', person: 'H0003', car:'계약취소 ', status:'취소' },
      ],
      linkVal:'http://hyundai.com/referral'
    }
  },
  methods:{
    copyUrl() {
      this.$copyText(this.linkVal)
      alert('링크가 복사되었습니다')
    }
   }
}
</script>
