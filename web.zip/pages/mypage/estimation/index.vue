<template>
  <div class="content mypage">
    <v-pageheader
      :top-breadcrumb="topBreadcrumb"
      page-title="견적 내역"
      page-infotext="저장된 견적내역을 확인하고 비교할 수 있습니다."
    />
    <mypage-lnb />
    <div class="mypage-wrap estimate-list">
      <div class="top-noti-info">
        <v-checkbox v-model="allCheck" :one-check="true" :checked.sync="allCheck" @change="allCheckChange">전체선택</v-checkbox>
        <div class="btn-wrap right">
          <v-btn class="btn md gray line r">선택삭제</v-btn>
          <v-btn class="btn md white r" @click="compareCar">비교하기</v-btn>
          <div>{{ comparisonVisible }}</div>
        </div>
      </div>
      <div class="table-area">
        <table class="noline">
          <colgroup>
            <col width="140px" />
            <col width="415px" />
            <col width="120px" />
            <col width="138px" />
            <col width="" />
          </colgroup>
          <thead>
            <tr>
              <th scope="col">견적일시</th>
              <th scope="col">차량정보</th>
              <th scope="col">견적금액</th>
              <th scope="col">결제방법</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            <template v-if="estimateData.length > 0">
            <tr v-for="(estimate, index) in estimateData" :key="index">
              <td>
                <v-checkbox :one-check="true" :checked.sync="estimate.estimateCheck" class="estimate-date" @change="checkChange">{{ estimate.estimateDate }}</v-checkbox>
              </td>
              <td>
                <v-btn type="nlink" role="button">
                  <div class="estimate-info">
                    <ul class="flag-list">
                      <li v-for="(flag, flagIdx) in estimate.flagData" :key="flagIdx">{{ flag.flagName }}</li>
                    </ul>
                    <strong>{{ estimate.name }}</strong>
                    <ul class="option-list">
                      <li v-for="(option, optionIdx) in estimate.optionData" :key="optionIdx">{{ option.optionName }}</li>
                    </ul>
                  </div>
                  <div class="car-img"><v-img :src="estimate.carImg" :alt="estimate.name"></v-img></div>
                </v-btn>
              </td>
              <td class="t-right">
                {{ estimate.price }} 원
              </td>
              <td class="t-right" v-html="estimate.payment"></td>
              <td class="t-right">
                <v-btn type="nlink" to="/" class="btn blue md r">계약하기</v-btn>
              </td>
            </tr>
            </template>
            <!-- 결과없음 -->
            <tr v-else>
              <td colspan="5">
                <div class="estimate-no-result">
                  <strong>저장된 견적서가 없습니다.</strong>
                  <p>나만의 캐스퍼를 만들고 견적으로 가격까지 알아보세요!</p>
                  <v-btn class="btn blue md r" type="nlink" to="/">나만의 캐스퍼 만들기</v-btn>
                </div>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
      <v-pagination :total="100" />

      <!-- 안내사항 -->
      <div class="page-notice">
        <div class="title">안내사항</div>
        <ul class="bullet-list">
          <li>견적은 최대 3개월까지 보관됩니다.</li>
          <li>견적 비교는 최대 4개까지 가능합니다.</li>
        </ul>
      </div>
    </div>

  <!-- 202.04.13(ver1.2) :full-popup="true" compariso/index.vue의 팝업태그로 이동 -->
    <comparison
      :visible="comparisonVisible"
      class="full-popup"
      @close="comparisonVisible = false"
    ></comparison>
  </div>
</template>

<script>
import { mapGetters, mapMutations } from 'vuex'
import MypageLnb from '~/components/page/mypage/index/MypageLnb'
import VPagination from '~/components/element/VPagination'
import comparison from '~/pages/mypage/comparison'
export default {
  head() {
    return {
      title: '마이페이지 > 나의 활동 > 견적 내역',
    }
  },
  components: {
    MypageLnb,
    VPagination,
    comparison
  },
   data(){
    return{
      topBreadcrumb: [
        { linkName: '마이페이지', link: '/' },
        { linkName: '나의 활동', link: '/' },
        { linkName: '견적 내역', link: '/' },
      ],
      allCheck: false,
      checkedNum: 0,
      comparisonVisible:false,
      selcData: []
    }
  },
  computed: {
    ...mapGetters({
      estimateData: 'mypageModules/estimateData',
      selectedData: 'mypageModules/selectedData',
    }),
  },
  mounted() {
  },
  // 2021.03.12 <!-- 2021.03.12 (ver1.1) 추가 -->
  updated() {
    if (this.visible) {
      this.setCaption()
    }
  },
  methods: {
    ...mapMutations({
      setChecked: 'mypageModules/setChecked',
      setSelectedData: 'mypageModules/setSelectedData',
      delSelectedData: 'mypageModules/delSelectedData',
    }),
    allCheckChange(value) {
      this.estimateData.forEach((val, i) => {
        if(value === true) {
          this.setChecked({index:i, val:true})
          this.checkedNum = this.estimateData.length
        } else {
          this.setChecked({index:i, val:false})
        }
      })
    },
    checkChange() {
      this.checkedNum = 0
      this.selcData= []
      this.estimateData.forEach((val, i) => {
        if(val.estimateCheck === false) {
          this.checkedNum <= 0 ? 0 : this.checkedNum - 1
          this.selcData.splice(i+1, 1)
        } else {
          this.checkedNum += 1
          this.selcData.push(this.estimateData[i])
        }

        if(this.checkedNum <= 0) {
          this.allCheck = false
        } else if(this.checkedNum === this.estimateData.length-1){
            this.allCheck = true
        }
      })
      this.setSelectedData(this.selcData)
    },
    compareCar() {
      if(this.checkedNum < 2) {
        alert('비교를 위해 2개 이상 선택해주세요')
      } else if(this.checkedNum > 4) {
        alert('견적비교는 최대 4개까지 가능합니다.')
      } else {
        this.comparisonVisible = true
      }
    }
  },
}
</script>
