<template>
  <div class="content mypage mypage-review">
    <v-pageheader
      :top-breadcrumb="topBreadcrumb"
      page-title="구매 후기 수정"
      :page-infotext="`${name} 님, 현대 자동차 AX를 구매해 주셔서 감사합니다.<br>고객님이 작성해주신 구매후기는 다른 분들이 차량을 구매하는 데 큰도움이 됩니다.`"
    />

    <mypage-lnb />

    <div class="mypage-wrap">
      <div class="review-regist">
        <!-- 차정보 -->
        <div class="matching-box sm-size">
          <div class="box-wrap">
            <div class="box-tit">
                <div class="car-img">
                  <v-img :src="carPhoto.src" :alt="carPhoto.alt"></v-img>
                </div>
            </div>
            <div class="box-desc">
              <div class="car-info">
                <div class="tit">AX 센슈어스(가솔린 1.6T) Premium (자가용 스마트스트림 가솔린 1.6 터보</div>
                <div class="txt">계약일 : <span class="date">2021. 02. 01</span></div>
              </div>
            </div>
          </div>
        </div>
        <!-- 총만족도 -->
        <div class="matching-box sm-size">
          <div class="box-wrap">
            <div class="box-tit">
                <b>총만족도*</b>
            </div>
            <div class="box-desc">
              <div class="grade-wrap">
                <div class="grade">
                  <v-rate v-model="grade" class="grade-check"></v-rate>
                </div>
                <div v-if="grade > 0" class="grade-text">{{ gradeText[grade-1] }}</div>
                <div v-else class="grade-text t-blue">만족도를 선택해 주세요</div>
              </div>
            </div>
          </div>
        </div>
        <!-- 세부만족도 -->
        <div v-if="grade > 0" class="matching-box column sm-size">
          <div class="box-wrap">
            <div class="box-tit">
                <b>세부만족도*</b>
            </div>
            <div class="box-desc">
              <div class="satisfaction-wrap">
                <ul>
                  <li v-for="(item, index) in satisfaction" :key="index">
                      <span class="flag">{{ item.cate }}</span>
                      <v-radio v-model="item.value" :data="item.list" class="vertical-list" />
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <!-- 내용입력 -->
        <div class="matching-box column sm-size">
          <div class="box-wrap label-input">
            <div class="box-tit">
                <b><label>내용입력</label>*</b> <span class="s-txt">(0~2,000자)</span>
            </div>
            <div class="box-desc">
                <div class="textarea">
                  <v-input v-model="reviewText" type="textarea" :rows="12" placeholder="내용을 입력하여 주세요(최대 2,000자)" maxlength="2000" />
                </div>
            </div>
          </div>
        </div>
        <!-- 사진등록 -->
        <div class="matching-box column sm-size">
          <div class="box-wrap">
            <div class="box-tit">
                <b>사진등록</b> <span class="s-txt">(7장까지 가능)</span>
            </div>
            <div class="box-desc">
              <div class="file-upload">
                <!-- 2021.03.23 (ver1.1) movie클래스제거 -->
                <div ref="imgArea" class="upload-list">
                  <ul v-if="imgList.length > 0">
                    <li v-for="(item, index) in imgList" :key="index">
                      <div class="img">
                        <v-btn class="btn-file-delete" type="button" @click="fileDelete(index)"><span class="offscreen">파일삭제</span></v-btn>
                        <img :src="item" alt="첨부사진" />
                      </div>
                    </li>
                  </ul>
                </div>
                <div class="btn-upload label-input">
                    <input ref="imgFile" type="file" class="offscreen" @change="changeFile" />
                    <v-btn class="file-btn" type="button" @click="fileOpen"><label class="offscreen">파일찾기</label></v-btn>
                </div>
              </div>
              <ul class="bullet-list">
                <li>직접 촬영한 차량관련 jpg, gif, png 파일만 등록해주세요.</li>
                <li>저작권 문제가 있거나 불건전한 사진은 통보없이 삭제될 수 있습니다.</li>
                <li>영문이름의 파일만 가능하며, 업로드 가능 용량은 파일당 최대 10MB입니다.</li>
                <li>가로 사이즈가 000픽셀을 초과하는 경우 000픽셀로 자동 조정됩니다.</li>
              </ul>
            </div>
          </div>
        </div>

        <!-- 2021.03.23 (ver1.1) 동영상등록 삭제 -->

        <div class="btn-box t-center">
          <v-btn type="button" class="btn lg gray r">취소</v-btn>
          <!-- 2021.03.23 (ver1.1) 수정으로 텍스트변경 -->
          <v-btn type="button" class="btn lg blue r">수정</v-btn>
          <div class="right">
            <v-btn type="button" class="btn-delete">삭제</v-btn>
          </div>
        </div>

        <div class="page-notice">
          <div class="title">안내사항</div>
          <p class="bullet">
            아래 사항에 해당하는 경우 통보없이 게시글이 삭제 될 수 있습니다. <br />
            1) 차량과 무관한 내용   2)명예훼손성, 모욕성 게시글   3) 그 외 욕설, 비방글 등 본 게시판 목적에 부적절한 게시글
          </p>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import MypageLnb from '~/components/page/mypage/index/MypageLnb'
import { VBtn, VRate, VImg } from '~/components/element'
export default {
  name: 'Review',
  components: {
    MypageLnb,
    VBtn,
    VRate,
    VImg
  },
  data() {
    return {
      topBreadcrumb: [
        { linkName: '마이페이지', link: '/' },
        { linkName: '나의 활동내역', link: '/' },
        { linkName: '구매 후기 수정', link: '/' },
      ],
      name: '김현대',
      carPhoto: {
        src: require('~/assets/images/temp/temp-review-car.png'),
        alt: 'AX 센슈어스(가솔린 1.6T) Premium (자가용 스마트스트림 가솔린 1.6 터보',
      },
      grade: 3,
      gradeText: ['후회되요ㅜ.ㅜ', '아쉬워요..', '보통이예요', '만족해요', '최고예요!'],

      checkboxDataListVal: [],
      checkboxListData: [
        { value: 'check1', label: '체크박스1', text:'텍스트1' },
        { value: 'check2', label: '체크박스2', text:'텍스트2' },
        { value: 'check3', label: '체크박스3', text:'텍스트3' },
        { value: 'check4', label: '체크박스4', text:'텍스트4' },
      ],

      satisfaction: [
        {
          cate: '구매과정',
          value: 'chk2',
          list: [
            {value: 'chk1', label:'쉽고 편안했어요.'},
            {value: 'chk2', label:'무난하게 진행했어요.'},
            {value: 'chk3', label:'과정이 번거로워요.'}
          ]
        },
        {
          cate: '가성비',
          value: 'chk1',
          list: [
            {value: 'chk1', label:'가격대비 최고예요.'},
            {value: 'chk2', label:'제 값 그대로예요.'},
            {value: 'chk3', label:'가격보다 아쉬워요.'}
          ]
        },
        {
          cate: '디자인',
          value: 'chk3',
          list: [
            {value: 'chk1', label:'화면보다 멋져요.'},
            {value: 'chk2', label:'화면처럼 맘에 들어요.'},
            {value: 'chk3', label:'조금 아쉽지만 괜찮아요.'}
          ]
        },
        {
          cate: '승차감',
          value: 'chk3',
          list: [
            {value: 'chk1', label:'무척 좋아요.'},
            {value: 'chk2', label:'보통이에요.'},
            {value: 'chk3', label:'보조장치가 필요해요.'}
          ]
        }
      ],
      reviewText: '빠르고 친절한 응대 너무 감사드립니다!!ㅎㅎ 첫차라 걱정도 많았지만 친절하고 정확하게 안내해주시고 차도 안전하게 잘 인도해 주셨습니다~ 요즘같은 때에 차 타고 다니다 마스크 없으면 난감한 상황이 많이 발생하는데 그런 걱정할 일 없이 마스크도 많이 넣어주시고 너무 센스쟁이세요~!! 첫차인 만큼 관리하는 방법이나 팁도 많이 알려주셔서 앞으로는 걱정 없이 예쁘고 안전하게 운전할 일만 남은 것 같습니다ㅎㅎ 다시 한 번 더 감사드립니다! 올 한해도 대박나세요~!! (>_<)/',
      fileVal: '',
      movieThumbnail:require('~/assets/images/temp/temp_movie_thumb.png'),
      imgList: [
        require('~/assets/images/temp/temp-precontact-car-visual.png'),
        require('~/assets/images/temp/temp-precontact-car-visual2.png'),
        require('~/assets/images/temp/temp-payment-car-model.png'),
        require('~/assets/images/temp/temp-precontact-car-visual.png'),
        require('~/assets/images/temp/temp-precontact-car-visual2.png'),
        require('~/assets/images/temp/temp-payment-car-model.png'),
        require('~/assets/images/temp/temp-payment-car-model.png')
      ],
      movieList: [require('~/assets/images/temp/temp_movie_thumb.png')],
    }
  },
  mounted(){
    this.autoXScroll()
    this.setLabel((idg) => {
      // console.dir(idg) // 자동 생성된 ID 배열
    })
  },
  methods:{
    changeFile(e, type) {
      const file = type === 'movie' ? this.$refs.movieFile : this.$refs.imgFile
      const list = type === 'movie' ? this.movieList : this.imgList
      const overNum = type === 'movie' ? 3 : 7
      const overSize = type === 'movie' ? 1000000 : 10000
      const overTxt = type === 'movie' ? '용량초과 영상이 있습니다. 영상은 00MB미만의 xxx, xxx, xxx파일만 첨부하실 수 있습니다.'
                                       : '용량초과 이미지가 있습니다. 파일당 10MB미만의 jpg, gif, png파일만 첨부하실 수 있습니다.'
      let files = e.target.files || e.dataTransfer.files
      if(files.length === 0) return
      this.fileVal = files[0].name
      this.addPhotoFile(file, (src, size) => {
        let imgSrc = type === 'movie' ? this.movieThumbnail : src
        if(list.length >= overNum) {
            alert(`'파일은 ${overNum}개까지 등록가능합니다'`)
        }else{
          if(parseInt(this.formatSizeUnits(size)) > overSize) {
            alert(overTxt)
          }else{
            list.push(imgSrc)
            setTimeout(() => {
              this.autoXScroll()
            }, 100)
          }
        }
      })
    },
    fileDelete(index, type) {
      if(type === 'movie') this.movieList.splice(index, 1)
      else this.imgList.splice(index, 1)
    },
    fileOpen(type) {
       if(type === 'movie') this.$refs.movieFile.click()
       else this.$refs.imgFile.click()
    },
    addPhotoFile(obj, callback) {
      let src, size
      if (obj.files && obj.files[0]) {
        let reader = new FileReader()
        reader.readAsDataURL(obj.files[0])
        reader.onload = function (e) {
          size = obj.files[0].size
          src = e.target.result
          callback && callback(src, size)
        }
      }
    },
    formatSizeUnits(bytes) {
      if      (bytes>=1000000000) {bytes=(bytes/1000000000).toFixed(2)+' GB'}
      else if (bytes>=1000000)    {bytes=(bytes/1000000).toFixed(2)+' MB'}
      else if (bytes>=1000)       {bytes=(bytes/1000).toFixed(2)+' KB'}
      else if (bytes>1)           {bytes=bytes+' bytes'}
      else if (bytes==1)          {bytes=bytes+' byte'}
      else                        {bytes='0 byte'}
      return bytes
    },
    autoXScroll() {
      let imgBox = this.$refs.imgArea
      imgBox.scrollLeft = imgBox.scrollWidth
      this.dragScrolling(imgBox)
    },
    dragScrolling(box) {
      let isDown = false, startX, scrollLeft
      box.addEventListener('mousedown', (e) => {
        isDown = true
        startX = e.pageX - box.offsetLeft
        scrollLeft = box.scrollLeft
      })
      box.addEventListener('mouseleave', () => {
        isDown = false
      })
      box.addEventListener('mouseup', () => {
        isDown = false
      })
      box.addEventListener('mousemove', (e) => {
        if(!isDown) return
        e.preventDefault()
        const x = e.pageX - box.offsetLeft
        const walk = (x - startX) * 3
        box.scrollLeft = scrollLeft - walk
      })
    }
  },
}
</script>
