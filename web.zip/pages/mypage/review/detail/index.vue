<template>
  <div class="content mypage mypage-review">
    <v-pageheader
      :top-breadcrumb="topBreadcrumb"
      page-title="구매 후기 조회"
      :page-infotext="`${name} 님, 현대 자동차 AX를 구매해 주셔서 감사합니다.<br>고객님이 작성해주신 구매후기는 다른 분들이 차량을 구매하는 데 큰도움이 됩니다.`"
    />

    <mypage-lnb />

    <div class="mypage-wrap">
      <div class="review-regist">
        <!-- 차정보 -->
        <div class="matching-box sm-size">
          <div class="box-wrap">
            <div class="box-tit">
                <div class="car-img">
                  <v-img :src="carPhoto.src" :alt="carPhoto.alt"></v-img>
                </div>
            </div>
            <div class="box-desc">
              <div class="car-info">
                <div class="tit">AX 센슈어스(가솔린 1.6T) Premium (자가용 스마트스트림 가솔린 1.6 터보</div>
                <div class="txt">계약일 : <span class="date">2021. 02. 01</span></div>
              </div>
            </div>
          </div>
        </div>
        <!-- 만족도 -->
        <div class="matching-box column sm-size">
          <div class="box-wrap">
            <div class="box-tit">
                <b>만족도</b>
                <!-- 2021.03.23 (ver1.1) 날자추가 -->
                <div class="right">
                  <div class="date">2021.10.30</div>
                </div>
            </div>
            <div class="box-desc">
              <div class="grade-wrap view">
                <div class="grade">
                  <v-rate v-model="grade" class="grade-check sm-size view"></v-rate>
                </div>
                <div v-if="grade > 0" class="grade-text">{{ gradeText[grade-1] }}</div>
                <div v-else class="grade-text t-blue">만족도를 선택해 주세요</div>
              </div>
              <ul class="satisfaction-list">
                  <li v-for="(item, index) in satisfaction" :key="index">
                      <span class="flag">{{ item.cate }}</span>
                      <span class="value">{{ item.text }}</span>
                  </li>
              </ul>
            </div>
          </div>
        </div>

        <div class="matching-box column sm-size">
          <!-- 동영상 사진 -->
          <div class="upload-view-list-wrap">
            <v-carousel-new
              :data="fileList"
              :navigation="true"
              :items-to-show="4"
              :items-to-slide="1"
              class="upload-view-list"
            >
            <template slot-scope="props">
                <div class="item">
                  <!-- 2021.03.23 (ver1.1) :class="{'movie': props.item.type == 'movie'}" 제거 -->
                  <div class="img">
                    <v-img :src="props.item.src" :alt="props.item.alt"></v-img>
                  </div>
                </div>
            </template>
            </v-carousel-new>
          </div>
          <div class="review-text">
            {{ reviewText }}
          </div>
          <!-- 2021.03.23 (ver1.1) etc-menus 수정-->
          <div class="etc-menus">
            <span class="good">
              도움이 되었어요
              <span class="up">
                {{ goodNum }}
              </span>
            </span>
            <div class="right">
              <v-btn type="nlink" class="btn-more">동일사양 견적내기</v-btn>
            </div>
          </div>
        </div>


      <!-- 2021.03.23 (ver1.1) 삭제버튼 추가 -->
        <div class="btn-box t-center">
          <v-btn type="button" class="btn lg blue r">목록</v-btn>
          <div class="right">
            <v-btn type="button" class="btn-delete">삭제</v-btn>
          </div>
        </div>

        <div class="page-notice">
          <div class="title">안내사항</div>
          <p class="bullet">
            아래 사항에 해당하는 경우 통보없이 게시글이 삭제 될 수 있습니다. <br />
            1) 차량과 무관한 내용   2)명예훼손성, 모욕성 게시글   3) 그 외 욕설, 비방글 등 본 게시판 목적에 부적절한 게시글
          </p>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import MypageLnb from '~/components/page/mypage/index/MypageLnb'
import { VBtn, VRate, VImg, VCarouselNew } from '~/components/element'
export default {
  components: {
    MypageLnb,
    VBtn,
    VRate,
    VImg,
    VCarouselNew
  },
  data() {
    return {
      topBreadcrumb: [
        { linkName: '마이페이지', link: '/' },
        { linkName: '나의 활동내역', link: '/' },
        { linkName: '구매 후기 조회', link: '/' },
      ],
      name: '김현대',
      carPhoto: {
        src: require('~/assets/images/temp/temp-review-car.png'),
        alt: 'AX 센슈어스(가솔린 1.6T) Premium (자가용 스마트스트림 가솔린 1.6 터보',
      },
      grade: 3,
      gradeText: ['후회되요ㅜ.ㅜ', '아쉬워요..', '보통이예요', '만족해요', '최고예요!'],
      // 슬라이드
      fileList: [
        {
          src: require('~/assets/images/temp/temp-review-car.png'),
          alt: 'AX 센슈어스(가솔린 1.6T) Premium (자가용 스마트스트림 가솔린 1.6 터보',
        },
        {
          src: require('~/assets/images/temp/temp-review-car.png'),
          alt: 'AX 센슈어스(가솔린 1.6T) Premium (자가용 스마트스트림 가솔린 1.6 터보',
        },
        {
          src: require('~/assets/images/temp/temp-review-car.png'),
          alt: 'AX 센슈어스(가솔린 1.6T) Premium (자가용 스마트스트림 가솔린 1.6 터보',
        },
        {
          src: require('~/assets/images/temp/temp-review-car.png'),
          alt: 'AX 센슈어스(가솔린 1.6T) Premium (자가용 스마트스트림 가솔린 1.6 터보',
        }
      ],
      satisfaction: [
        {
          cate: '구매과정',
          text: '무난하게 진행했어요.',
        },
        {
          cate: '가성비',
          text: '제 값 그대로예요.',
        },
        {
          cate: '디자인',
          text: '조금 아쉽지만 괜찮아요.',
        },
        {
          cate: '승차감',
          text: '무척 좋아요.',
        }
      ],
      reviewText: '빠르고 친절한 응대 너무 감사드립니다!!ㅎㅎ 첫차라 걱정도 많았지만 친절하고 정확하게 안내해주시고 차도 안전하게 잘 인도해 주셨습니다~ 요즘같은 때에 차 타고 다니다 마스크 없으면 난감한 상황이 많이 발생하는데 그런 걱정할 일 없이 마스크도 많이 넣어주시고 너무 센스쟁이세요~!! 첫차인 만큼 관리하는 방법이나 팁도 많이 알려주셔서 앞으로는 걱정 없이 예쁘고 안전하게 운전할 일만 남은 것 같습니다ㅎㅎ         다시 한 번 더 감사드립니다! 올 한해도 대박나세요~!! (>_<)/',
      movieThumbnail:require('~/assets/images/temp/temp_movie_thumb.png'),
      imgList: [],
      movieList: [],
      goodNum:'5'
    }
  },
  methods:{

  },
}
</script>
