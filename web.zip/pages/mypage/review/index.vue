<template>
  <div class="content mypage mypage-review">
    <v-pageheader
      :top-breadcrumb="topBreadcrumb"
      page-title="구매 후기 내역"
      page-infotext="이용 중인 현대자동차 서비스를 마이페이지에서 확인하세요."
    />

    <mypage-lnb />

    <div class="mypage-wrap">
      <div class="top-noti-info">
        <div class="left">
          <div class="total">총 구매 차량 <span class="num">{{ buyReviewList.length }}</span> 대</div>
        </div>
        <div class="right inbl-wrap">
            <v-select
              v-model="selectListVal"
              :data="selectList"
              class="no-st"
            />
        </div>
      </div>
      <!-- list-board -->
      <div class="buying-review-list">
        <template v-if="buyReviewList.length > 0">
        <ul>
          <li v-for="(item, index) in buyReviewList" :key="index">
            <div class="img"><v-img :src="item.carImg.src" :alt="item.carImg.alt"></v-img></div>
            <div class="desc">
              <div class="title">{{ item.title }}</div>
              <div class="account">구매가격 : {{ item.price }}원</div>
              <div class="matching-text">
                <div class="tit">계약일</div>
                <div class="auto"><span class="date">{{ item.contractDate }}</span></div>
              </div>
              <div class="matching-text">
                <div class="tit">구매후기 작성(수정) 기간</div>
                <div class="auto"><span class="date">{{ item.modifyTerm }}</span></div>
              </div>
              <div class="btn-wrap">
                <v-btn v-if="!item.unexposed && item.writeEnd > 0 && item.writed == false" type="nlink" to="/" class="btn md white r"><span>구매후기 작성 (<span class="t-blue">가능 기간 {{ item.writeEnd }}일 남음</span>)</span></v-btn>
                <v-btn v-if="!item.unexposed && item.writeEnd <= 0 && item.writed == false" class="btn md white r" :disabled="true"><span>구매후기 작성 가능 기간이 종료되었습니다.</span></v-btn>
                <v-btn v-if="!item.unexposed && item.writeEnd > 0 && item.writed == true" type="nlink" to="/" class="btn md white r"><span>구매후기 수정</span></v-btn>
                <v-btn v-if="!item.unexposed && item.writeEnd <= 0 && item.writed == true" type="nlink" to="/" class="btn md white r"><span>구매후기 보기</span></v-btn>
                <!-- 2021.03.23 (ver1.1) 비노출 구매후기 아래 텍스트추가 -->
                <div v-if="item.unexposed">
                  <v-btn class="btn md white r" :disabled="true"><span>비노출 구매후기</span></v-btn>
                  <p class="bullet-star">작성하신 구매후기가 관리자에 의해 비노출 처리되었습니다.</p>
                </div>
              </div>
            </div>
          </li>
        </ul>
        </template>
         <template v-else>
            <div class="list-null">
              <i class="icon-doc-none"></i>
              <p>구매 내역이 없습니다.</p>
            </div>
         </template>
      </div>
      <div v-if="buyReviewList.length <= 0" class="btn-box t-right">
        <v-btn class="btn md white r" type="nlink">구매후기 보러가기</v-btn>
      </div>
      <v-pagination :total="100" />

      <!-- 안내사항 -->
      <div class="page-notice">
        <div class="title">안내사항</div>
        <ul class="bullet-list">
          <li>본 사이트에서 구매한 차량의 후기를 작성하실 수 있습니다.</li>
          <li>구매후기는 제작중 발급일로부터 30일 이내에만 작성, 수정하실 수 있습니다.</li>
          <li>제작중 발급일로부터 30일이 지난 경우 작성한 구매후기를 확인, 삭제하실 수 있습니다.</li>
          <li>구매후기 삭제 시 복구되지 않습니다.</li>
          <li>아래 사항에 해당하는 경우 통보 없이 게시글이 삭제될 수 있습니다.</li>
          <li>1) 차량과 무관한 내용     2) 명예훼손성, 모욕성 게시글     3) 그 외 욕설, 비방글 등 본 게시판 목적에 부적절한 게시글</li>
        </ul>
      </div>
      <!-- // 안내사항 -->
    </div>
  </div>
</template>

<script>
import MypageLnb from '~/components/page/mypage/index/MypageLnb'
import { VBtn } from '~/components/element'
export default {
  components: {
    MypageLnb,
    VBtn,
  },
  data() {
    return {
      topBreadcrumb: [
        { linkName: '마이페이지', link: '/' },
        { linkName: '나의 활동내역', link: '/' },
        { linkName: '구매 후기 내역', link: '/' },
      ],
      selectListVal: '',
      selectList: [
        { value: '', label: '전체' },
        { value: 'select1', label: '선택1' },
        { value: 'select2', label: '선택2' },
        { value: 'select3', label: '선택3' },
      ],
      isView: false,
      listSelected:'',
      buyReviewList: [
        {
          carImg: {
            src: require('~/assets/images/temp/temp-review-car.png'),
            alt: '쏘나타 센슈어스(가솔린 1.6T) Premium (자가용 스마트스트림 가솔린 1.6 터보)',
          },
          title:'쏘나타 센슈어스(가솔린 1.6T) Premium (자가용 스마트스트림 가솔린 1.6 터보)',
          price: '31,200,000',
          contractDate: '2021. 02. **',
          modifyTerm: '2021. 03. 01 ~ 2021. 03. 31',
          writed:false,
          writeEnd: 10,
          unexposed:false,
        },
        {
          carImg: {
            src: require('~/assets/images/temp/temp-review-car.png'),
            alt: '아반테 Modern (가솔린 1.6 A/T) 자가용 가솔린 1.6 A/T',
          },
          title:'쏘나타 센슈어스(가솔린 1.6T) Premium (자가용 스마트스트림 가솔린 1.6 터보)',
          price: '19,200,000',
          contractDate: '2021. 02. **',
          modifyTerm: '2021. 03. 01 ~ 2021. 03. 31',
          writed:false,
          writeEnd: 0,
          unexposed:false,
        },
        {
          carImg: {
            src: require('~/assets/images/temp/temp-review-car.png'),
            alt: '아반테 Modern (가솔린 1.6 A/T) 자가용 가솔린 1.6 A/T',
          },
          title:'쏘나타 센슈어스(가솔린 1.6T) Premium (자가용 스마트스트림 가솔린 1.6 터보)',
          price: '19,200,000',
          contractDate: '2021. 02. **',
          modifyTerm: '2021. 03. 01 ~ 2021. 03. 31',
          writed:true,
          writeEnd: 15,
          unexposed:false,
        },
        {
          carImg: {
            src: require('~/assets/images/temp/temp-review-car.png'),
            alt: '아반테 Modern (가솔린 1.6 A/T) 자가용 가솔린 1.6 A/T',
          },
          title:'쏘나타 센슈어스(가솔린 1.6T) Premium (자가용 스마트스트림 가솔린 1.6 터보)',
          price: '19,200,000',
          contractDate: '2021. 02. **',
          modifyTerm: '2021. 03. 01 ~ 2021. 03. 31',
          writed:true,
          writeEnd: 0,
          unexposed:false,
        },
        {
          carImg: {
            src: require('~/assets/images/temp/temp-review-car.png'),
            alt: '아반테 Modern (가솔린 1.6 A/T) 자가용 가솔린 1.6 A/T',
          },
          title:'쏘나타 센슈어스(가솔린 1.6T) Premium (자가용 스마트스트림 가솔린 1.6 터보)',
          price: '19,200,000',
          contractDate: '2021. 02. **',
          modifyTerm: '2021. 03. 01 ~ 2021. 03. 31',
          writed:true,
          writeEnd: 0,
          unexposed:true,
        },
      ],
    }
  },
  methods:{

  }
}
</script>
