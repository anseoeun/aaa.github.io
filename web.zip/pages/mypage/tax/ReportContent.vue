<template>
  <div class="content mypage report-content">
    <!-- 2021.03.24 (ver1.1) page-title의 차량텍스트 제거 -->
    <v-pageheader
      :top-breadcrumb="topBreadcrumb"
      page-title="면세신고 내역"
      page-infotext="이용 중인 현대자동차 서비스를 마이페이지에서 확인하세요."
    />
    <mypage-lnb />

    <div class="mypage-wrap">
      <!-- report-content-wrap -->
      <div class="report-content-wrap">
        <!-- 면세신고 작성 -->
        <div>
          <div class="top-noti-info">
            <div class="left">
              <p class="title">
                <!--  2021.03.24 (ver1.1) '진행상황' 텍스트 제거 -->
                면세신고
                <span class="stxt">면세신고 내역을 작성하시기 바랍니다.</span>
              </p>
            </div>
          </div>
          <!-- judge-desc -->
          <div class="matching-list judge-desc">
            <ul>
              <li>
                <div class="tit">계약번호</div>
                <div class="right f-row">
                    <b>AX123456748904</b>
                    <div class="right">
                      <div class="t-gray">마지막 업데이트 2021.02.01 13:00</div>
                    </div>
                </div>
              </li>
              <li>
                <div class="tit">면세신고서 접수/심사 결과</div>
                <div class="right f-row"><span class="flag">미접수</span></div>
              </li>
              <li>
                <div class="tit">전자서명 결과</div>
                <div class="right f-row">
                  <span class="flag">미인증</span>
                </div>
              </li>
            </ul>
          </div>
          <!-- // judge-desc -->
          <tax-free-form />
          <!-- 차량 면세신고 프로세스 안내 -->
          <div class="section">
            <p class="section-tit">차량 면세신고 프로세스 안내</p>
              <ol class="contract-step">
                <li>
                  <i class="icon-contract-step-1"></i>
                  <div class="txt">
                    <b class="main-txt">면세신고 접수/재접수</b>
                    <span class="sub-txt">면세신고서 작성<br />증빙서류 업로드</span>
                  </div>
                </li>
                <li>
                  <i class="icon-contract-step-2"></i>
                  <div class="txt">
                    <b class="main-txt">자격대상 심사/재심사</b>
                    <span class="sub-txt">증빙내역 적격 심사</span>
                  </div>
                </li>
                <li>
                  <i class="icon-contract-step-3"></i>
                  <div class="txt">
                    <b class="main-txt">전자서명</b>
                    <span class="sub-txt">심사승인 시<br />전자서명 메시지 전송</span>
                  </div>
                </li>
                <li>
                  <i class="icon-contract-step-4"></i>
                  <div class="txt">
                    <b class="main-txt">면세신고 완료</b>
                  </div>
                </li>
              </ol>
              <ul class="bullet-list">
                <li>심사진행전까지는 작성내역을 수정할 수 있습니다.</li>
                <li>면세신고 접수를 완료하시면, 작성내역과 증빙사항에 대해 자격 심사진행 결과를 메시지로 알려드립니다.</li>
                <li>승인 이후 전송된 본인 휴대폰(면세 구입자)의 카카오톡으로 전자서명을 완료하시면 면세신고가 완료됩니다.</li>
              </ul>
          </div>
          <!-- 하단 버튼 -->
          <div class="btn-box">
            <v-btn class="btn lg blue line r">임시저장</v-btn>
            <v-btn class="btn lg blue r">접수하기</v-btn>
          </div>
        </div>
        <!-- // 면세신고 작성 -->

        <!-- 면세신고 접수 -->
        <div>
          <div class="top-noti-info">
            <div class="left">
              <!-- 2021.03.24 (ver1.1) '접수'텍스트 제거 -->
              <p class="title">
                면세신고
              </p>
            </div>
          </div>
          <!-- judge-desc -->
          <div class="matching-list judge-desc center complete">
            <ul>
              <li>
                <div class="tit">계약번호</div>
                <div class="right f-row">
                    <b>AX123456748904</b>
                </div>
              </li>
            </ul>
          </div>
          <!-- // judge-desc -->
          <div class="completes-message">
            <i class="icon icon-complete-cehck"></i>
            면세신고내역이 접수되었습니다.
            <p class="stxt">심사진행 후 승인결과를 메시지로 안내해드립니다.</p>
          </div>
            <!-- 차량 면세신고 프로세스 안내 -->
            <div class="section">
              <p class="section-tit">차량 면세신고 프로세스 안내</p>
                <ol class="contract-step">
                  <li>
                    <i class="icon-contract-step-1"></i>
                    <div class="txt">
                      <b class="main-txt">면세신고 접수/재접수</b>
                      <span class="sub-txt">면세신고서 작성<br />증빙서류 업로드</span>
                    </div>
                  </li>
                  <li>
                    <i class="icon-contract-step-2"></i>
                    <div class="txt">
                      <b class="main-txt">자격대상 심사/재심사</b>
                      <span class="sub-txt">증빙내역 적격 심사</span>
                    </div>
                  </li>
                  <li>
                    <i class="icon-contract-step-3"></i>
                    <div class="txt">
                      <b class="main-txt">전자서명</b>
                      <span class="sub-txt">심사승인 시<br />전자서명 메시지 전송</span>
                    </div>
                  </li>
                  <li>
                    <i class="icon-contract-step-4"></i>
                    <div class="txt">
                      <b class="main-txt">면세신고 완료</b>
                    </div>
                  </li>
                </ol>
                <ul class="bullet-list">
                  <li>심사진행전까지는 작성내역을 수정할 수 있습니다.</li>
                  <li>면세신고 접수를 완료하시면, 작성내역과 증빙사항에 대해 자격 심사진행 결과를 메시지로 알려드립니다.</li>
                  <li>승인 이후 전송된 본인 휴대폰(면세 구입자)의 카카오톡으로 전자서명을 완료하시면 면세신고가 완료됩니다.</li>
                </ul>
            </div>
            <!-- 하단 버튼 -->
            <div class="btn-box">
              <v-btn class="btn lg blue r">확인</v-btn>
            </div>
        </div>
        <!-- // 면세신고 접수 -->

        <!-- 면세신고 상세 -->
        <div>
          <div class="top-noti-info">
            <div class="left">
              <p class="title">
                <!--  2021.03.24 (ver1.1) '진행상황' 텍스트 제거 -->
                면세 신고
                <span class="stxt">면세신고 내역을 수정할 수 있습니다.</span>
              </p>
            </div>
          </div>
          <div class="top-noti-info">
            <div class="left">
              <p class="title">
                면세 신고
                <span class="stxt">심사가 진행중일때는 서류수정이 불가합니다.</span>
              </p>
            </div>
          </div>
          <div class="top-noti-info">
            <div class="left">
              <p class="title">
                면세 신고
                <span class="stxt">전자서명을 진행해 주세요</span>
              </p>
            </div>
          </div>
          <div class="top-noti-info">
            <div class="left">
              <p class="title">
                면세 신고
                <span class="stxt">신고가 완료되었습니다.</span>
              </p>
            </div>
          </div>
          <!-- judge-desc -->
          <div class="matching-list judge-desc">
            <ul>
              <li>
                <div class="tit">계약번호</div>
                <div class="right f-row">
                    <b>AX123456748904</b>
                    <div class="right">
                      <div class="t-gray">승인거절일 2021.02.01 13:00</div>
                    </div>
                </div>
              </li>
              <li>
                <div class="tit">면세신고서 접수/심사 결과</div>
                <div class="right f-row"><span class="flag">심사진행중</span></div>
              </li>
              <li>
                <div class="tit">전자서명 결과</div>
                <div class="right f-row">
                  <span class="flag">미인증</span>
                  <!-- 2021.03.24 (ver1.1) btn-more로 클래스 변경 -->
                  <v-btn class="btn-more" @click="digitalSignMessagePop = true">전자서명 메시지 재전송</v-btn>
                    <div class="right">
                      <div class="t-gray">승인완료일 이후 24시간 내 전자서명바랍니다</div>
                    </div>
                </div>
              </li>
            </ul>
          </div>
          <!-- // judge-desc -->
          <div class="apply-write-area" style="height:400px;background:#f9f9f9">
            TBD, <br />
            면세신고서 작성영역,
            증빙서류첨부영역
          </div>
          <!-- 하단 버튼 -->
          <div class="btn-box">
            <v-btn class="btn lg blue r" type="button">수정하기</v-btn>
            <v-btn class="btn lg blue r" type="button">확인</v-btn>
          </div>
        </div>
        <!-- //면세신고 상세 -->
      </div>
    </div>

    <pop-temporary-save :visible="temporarySavePop" @close="temporarySavePop = false" />
    <digital-signMessage :visible="digitalSignMessagePop" @close="digitalSignMessagePop = false" />
  </div>
</template>

<script>
import MypageLnb from '~/components/page/mypage/index/MypageLnb'
import TaxFreeForm from '~/components/page/mypage/tax/TaxFreeForm'
import PopTemporarySave from '~/components/page/mypage/purchase-list/PopTemporarySave'
import DigitalSignMessage from '~/components/page/mypage/purchase/contract-detail/popover/DigitalSignMessage'
export default {
  head() {
    return {
      title: '마이페이지 > 나의계약 > 차량 면세신고 내역'
    }
  },
  components: {
    MypageLnb,
    TaxFreeForm,
    PopTemporarySave,
    DigitalSignMessage
  },
  data() {
    return {
      topBreadcrumb: [
        { linkName: '마이페이지', link: '/' },
        { linkName: '나의계약', link: '/' },
        { linkName: '차량 면세신고 내역', link: '/' }
      ],
      temporarySavePop : false,
      digitalSignMessagePop : false,
    }
  },
  mounted(){
    this.temporarySavePop = true
  },
  methods: {

  }
}
</script>
