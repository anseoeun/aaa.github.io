<template>
  <div class="content mypage mypage-purchase">
    <v-pageheader page-title="구매 내역" page-infotext="저장된 차량 구매내역을 확인하실 수 있습니다." />
    <mypage-lnb />
    <div class="mypage-wrap detail">
      <div class="step-info">
        <ol>
          <li v-for="(ms, idx) in mySteps" :key="idx" :class="{ active: step === `${idx + 1}` }">
            {{ `0${idx + 1}. ${ms}` }}
          </li>
        </ol>
      </div>
      <div class="order-info">
        <div class="contract-num">{{ contractNumber }}</div>
        <div class="state">{{ state }}</div>
        <div class="car-img"><v-img :src="carImg.src" :alt="carImg.alt"></v-img></div>
        <div class="info-grid-list">
          <ul>
            <li>
              <strong class="info-title">모델명</strong>
              <div class="info-group">{{ saleModelName }}</div>
            </li>
            <li>
              <strong class="info-title">계약완료일</strong>
              <div class="info-group">{{ contractDate }}</div>
            </li>
            <li>
              <strong class="info-title">외장색상</strong>
              <div class="info-group">{{ outColor }}</div>
            </li>
            <li>
              <strong class="info-title">선택품목</strong>
              <div class="info-group">{{ option }}</div>
            </li>
            <li>
              <strong class="info-title">계약금액</strong>
              <div class="info-group price">{{ carPrice }}원</div>
            </li>
            <li>
              <strong class="info-title">단계</strong>
              <div class="info-group result">{{ description }}</div>
            </li>
            <li class="t-blue">
              <strong class="info-title">예상출고일</strong>
              <div class="info-group">{{ date }}</div>
            </li>
            <li class="t-blue">
              <strong class="info-title">심사 실패사유</strong>
              <div class="info-group" v-html="fail"></div>
            </li>
            <li class="t-blue">
              <strong class="info-title">취소처리일</strong>
              <div class="info-group">{{ canceleDate }}</div>
            </li>
          </ul>
        </div>
      </div>

      <div style="width: 100%; height: 200px; background: #f6f3f2;">커스터마이징 PKG BN</div>

      <div class="btn-wrap">
        <!-- 계약 -->
        <ul v-if="stepBtn === 1">
          <li><v-btn class="btn white md r">사전계약용 견적내기</v-btn></li>
          <li><v-btn class="btn white md r">계약내역 작성 및 수정</v-btn></li>
          <li><v-btn class="btn white md r">전자서명 메시지 재전송</v-btn></li>
          <li><v-btn class="btn white md r">입금계좌 재전송</v-btn></li>
          <li><v-btn class="btn white md r">차량정보 조회 및 변경</v-btn></li>
          <li><v-btn class="btn white md r">환불계좌 입력</v-btn></li>
          <li><v-btn class="btn gray line md r">계약취소</v-btn></li>
        </ul>
        <!-- 차량준비 -->
        <ul v-if="stepBtn === 2">
          <li><v-btn class="btn gray line md r">계약취소</v-btn></li>
        </ul>
        <!-- 결제 -->
        <ul v-if="stepBtn === 3">
          <li><v-btn class="btn white md r">결제하기</v-btn></li>
          <li><v-btn class="btn white md r">남은금액 결제하기</v-btn></li>
          <li><v-btn class="btn white md r">증빙서류 심사</v-btn></li>
          <li><v-btn class="btn gray line md r">계약취소</v-btn></li>
          <li><v-btn class="btn gray line md r">취소문의</v-btn></li>
        </ul>
        <!-- 배달탁송 -->
        <ul v-if="stepBtn === 4">
          <li><v-btn class="btn white md r">차량인수 확정처리</v-btn></li>
          <li><v-btn class="btn white md r">선택형 서비스 구매</v-btn></li>
          <li><v-btn class="btn white md r">남은금액 결제하기</v-btn></li>
          <li><v-btn class="btn gray line md r">반품 및 환불 문의</v-btn></li>
        </ul>
        <!-- 배달탁송완료 -->
        <ul v-if="stepBtn === 5">
          <li><v-btn class="btn white md r" @click="popVisible.addressInfoPopup = true">자동차제작증 발급</v-btn></li>
          <li><v-btn class="btn white md r">구매후기 작성</v-btn></li>
          <li><v-btn class="btn white md r">선택형 서비스 구매</v-btn></li>
          <li><v-btn class="btn gray line md r">반품 및 환불 문의</v-btn></li>
        </ul>
      </div>

      <v-tab class="tab-default" :data="tabList" :contents="true">
        <template slot="contents">
          <div data-id="tab1">
            <!-- 계약정보 -->
            <div class="contract-info">
              <div>
                계약 내용 확인
              </div>
              <div class="btn-wrap">
                <v-btn class="btn">매매계약서</v-btn>
                <v-btn class="btn">계약사실확인서</v-btn>
              </div>
            </div>
            <!-- 자동차 제조공정 안내 -->
            <making-process />
            <!-- 계약상세 -->
            <contract-detail-estimate />
          </div>
          <div data-id="tab2">
            <!-- 결제정보 -->
            <contract-detail-payment />
          </div>
          <div data-id="tab3">
            <!-- 인수정보 -->
            <contract-detail-take-over />
          </div>
        </template>
      </v-tab>
    </div>
  </div>
</template>

<script>
import MypageLnb from '~/components/page/mypage/index/MypageLnb'
import MakingProcess from '~/components/page/mypage/purchase/contract-detail/MakingProcess'
import ContractDetailEstimate from '~/components/page/mypage/purchase/contract-detail/estimate/index.vue'
import ContractDetailPayment from '~/components/page/mypage/purchase/contract-detail/payment/index.vue'
import ContractDetailTakeOver from '~/components/page/mypage/purchase/contract-detail/takeOver/index.vue'
// import AddressInfoPopup from '~/components/page/mypage/purchase/contract-detail/popups/AddressInfoPopup'
export default {
  head() {
    return {
      title: '마이페이지 > 구매 내역'
    }
  },
  components: {
    MypageLnb,
    MakingProcess,
    ContractDetailEstimate,
    ContractDetailPayment,
    ContractDetailTakeOver,
    // AddressInfoPopup,
  },
  data() {
    return {
      mySteps: ['계약', '차량준비', '결제', '배달탁송', '배달탁송완료'],
      contractNumber: 'A3721CN000090',
      contractDate: '2021.02.01 15:47',
      state: '결제처리중',
      carImg: {
        src: require('~/assets/images/temp/temp-payment-car-model.png'),
        alt: 'AX 자가용 5인승 가솔린 1.6 2WD IVT Smart '
      },
      saleModelName: 'AX 자가용 5인승 가솔린 1.6 2WD IVT Smart',
      outColor: '그레이',
      option: '스마트스트림 가솔린 1.6 엔진 외 5개',
      carPrice: '21,480,000',
      step: '3',
      description: '결제처리중 입니다. 잠시만 기다려 주세요.',
      date: '2021년 6월 첫째주',
      fail: '공무원 할인 심사 실패<br />타겟조건 할인 심사 실패',
      canceleDate: '2021.03.01 15:47',
      stepBtn: 3,
      tabList: [
        { value: 'tab1', label: '계약정보' },
        { value: 'tab2', label: '결제정보' },
        { value: 'tab3', label: '인수정보' }
      ],
      popupVisible: {
        addressInfoPopup: false,
      },
    }
  },
  methods: {
    popupSync(e) {
      this.popupVisible = e
    }
  }
}
</script>
