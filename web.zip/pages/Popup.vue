<template>
  <div class="popup-list-index">
    <header>
      <h1>{{ headingTitle }}</h1>
    </header>
    <main>
      <div v-for="(pops, index) in wlist" :key="index" class="popup-list-category-box">
        <h2>{{ index + 1 + '. ' + pops.title }}</h2>
        <ul class="popup-view-list">
          <li v-for="(pop, sidx) in pops.sub" :key="sidx">
            <div v-if="pop.popup" class="popup-true-li">
              <template v-if="pop.type === 'obj'">
                <button
                  :id="pop.id"
                  class="btn md blue"
                  type="button"
                  @click="pop.popupVisible[Object.keys(pop.popupVisible)[0]] = true; bodyStopClose()"
                >
                  {{
                    index +
                    1 +
                    '-' +
                    (sidx + 1) +
                    '. ' +
                    pops.title +
                    ' - ' +
                    pop.menu +
                    ' (' +
                    pop.id +
                    ') / ' +
                    pop.link
                  }}
                </button>
                <component
                  :is="pop.id"
                  :visible.sync="pop.popupVisible"
                ></component>
              </template>
              <template v-else>
                <button
                  :id="pop.id"
                  class="btn md blue"
                  type="button"
                  @click="pop[Object.keys(pop)[Object.keys(pop).length - 1]] = true; bodyStop()"
                >
                  {{
                    index +
                    1 +
                    '-' +
                    (sidx + 1) +
                    '. ' +
                    pops.title +
                    ' - ' +
                    pop.menu +
                    ' (' +
                    pop.id +
                    ') / ' +
                    pop.link
                  }}
                </button>
                <component
                  :is="pop.id"
                  :[setname(pop)]="pop[Object.keys(pop)[Object.keys(pop).length - 1]]"
                  @close="pop[Object.keys(pop)[Object.keys(pop).length - 1]] = false; bodyClear()"
                ></component>
              </template>
            </div>
          </li>
        </ul>
      </div>
    </main>
  </div>
</template>

<script>
import weblist from '~/assets/publishing/shop-menu-web.js'
import $ from 'jquery'
export default {
  components: {
    //기타
    'PS-ETC_024': () => import('~/components/page/agreement/popup/'),
    'PS-ETC_025': () => import('~/components/page/agreement/popup/'),
    'PS-ETC_026': () => import('~/components/page/agreement/popup/'),
    'PS-ETC_027': () => import('~/components/page/agreement/popup/'),
    'PS-ETC_028': () => import('~/components/page/agreement/popup/'),
    'PS-ETC_029': () => import('~/components/page/agreement/popup/'),
    'PS-ETC_030': () => import('~/components/page/agreement/popup/'),
    'PS-ETC_031': () => import('~/components/page/agreement/popup/'),
    'PS-ETC_032': () => import('~/components/page/notice/PopNoticeShare'),

    //탐색
    'PS-DIS_022': () => import('~/components/page/vehicles/comparison/popup'),
    'PS-DIS_030': () => import('~/components/page/vehicles/making/popup'),
    'PS-DIS_033': () => import('~/components/page/vehicles/making/popup'),
    'PS-DIS_035': () => import('~/components/page/vehicles/making/popup'),
    'PS-DIS_036': () => import('~/components/page/vehicles/making/popup'),
    'PS-DIS_037': () => import('~/components/page/vehicles/making/popup'),
    'PS-DIS_038': () => import('~/components/page/vehicles/making/popup'),
    'PS-DIS_041': () => import('~/components/page/vehicles/making/popup/'),
    'PS-DIS_042': () => import('~/components/page/vehicles/making/popup/'),
    'PS-DIS_052': () => import('~/components/page/vehicles/popup/DeliverySelect'),
    'PS-DIS_062': () => import('~/components/page/review/Detail'),
    'PS-DIS_066': () => import('~/components/page/vehicles/coupon/popup/CouponDetail'),
    'PS-DIS_072': () => import('~/components/page/vehicles/making/popup/'),
    'PS-DIS_073': () => import('~/components/page/vehicles/comparison/popup/Comparison'),
    'PS-DIS_074': () => import('~/components/page/vehicles/comparison/popup/FrequentlyCoparison'),
    'PS-DIS_075': () => import('~/components/page/vehicles/comparison/popup/DefaultOptionInfo'),
    'PS-DIS_076': () => import('~/components/page/vehicles/comparison/popup/InsurePriceInfo'),
    'PS-DIS_077': () => import('~/components/page/vehicles/comparison/popup/SeftyEstimateInfo'),
    'PS-DIS_082': () => import('~/components/page/vehicles/test-driving/popup'),
    'PS-DIS_083': () => import('~/components/page/vehicles/test-driving/popup'),
    'PS-DIS_085': () => import('~/components/page/vehicles/test-driving/popup'),
    'PS-DIS_086': () => import('~/components/page/vehicles/popup/VehiclePop'),
    'PS-DIS_087': () => import('~/components/page/vehicles/making/popup'),
    'PS-DIS_089': () => import('~/components/page/vehicles/test-driving/popup/'),
    'PS-DIS_090': () => import('~/components/page/vehicles/test-driving/popup/'),
    'PS-DIS_093': () => import('~/components/page/vehicles/test-driving/popup/'),
    'PS-DIS_094': () => import('~/components/page/vehicles/test-driving/popup/'),
    'PS-DIS_097': () => import('~/components/page/review/PurchaseInfo'),
    'PS-MAC_008_2': () => import('~/components/page/review/Satisfaction'),

    // 견적
    'PS-EST_006': () => import('~/components/page/estimation/popup/CouponRegistration'),
    'PS-EST_014': () => import('~/components/page/estimation/popup/EstimateShare'),
    'PS-EST_019': () => import('~/components/page/estimation/popup/DuplicateDiscount'),
    'PS-EST_020': () => import('~/components/page/estimation/popup/BlueMembersPointGuide'),
    'PS-EST_021': () => import('~/components/page/estimation/popup/EmployeeDiscount'),
    'PS-EST_022': () => import('~/components/page/estimation/popup/DiscountConditions'),
    'PS-EST_023': () => import('~/components/page/estimation/popup/TaxFree'),
    'PS-EST_024': () => import('~/components/page/estimation/popup/SaveEstimation'),
    'PS-EST_026': () => import('~/components/page/estimation/popup/Configurator'),
    'PS-EST_027': () => import('~/components/page/estimation/popup/RepurchaseRestriction'),
    'PS-EST_028': () => import('~/components/page/estimation/popup/EmployeeDuplicateDiscount'),
    'PS-PAY_010_2': () => import('~/components/page/estimation/popup/'),
    'PS-EST_029': () => import('~/components/page/estimation/popup/MPoint'),
    'PS-EST_030': () => import('~/components/page/estimation/popup/BlueMembersPoint'),
    'PS-EST_031': () => import('~/components/page/estimation/popup/SendEmail'),

    // 고객지원
    'PS-CUS_044': () => import('~/components/page/support/VArs'),
    'PS-CUS_045': () => import('~/components/page/support/PArs'),
    'PS-CUS_046': () => import('~/components/page/support/RemoteConsultation'),
    'PS-CUS_090': () => import('~/components/page/support/qna/PopCarChoice'),

    // 사전계약
    'PS-CTT_070': () => import('~/pages/pre-contract/popup/'),

    // 계약
    'PS-CTT_018': () => import('~/components/page/contract/popup/AmountChange'),
    'PS-CTT_035': () => import('~/components/page/contract/popup/TermsBlueMembers'),
    'PS-CTT_058': () => import('~/components/page/contract/popup/TermsHyundaiCarClause'),
    'PS-CTT_062': () => import('~/components/page/contract/popup/IdentifyVerification'),
    'PS-CTT_065': () => import('~/components/page/contract/popup/Duty'),
    'PS-CTT_066': () => import('~/components/page/contract/popup/DutyCar'),
    'PS-CTT_067': () => import('~/components/page/contract/popup/AgreeTerms'),
    'PS-CTT_073': () => import('~/components/page/contract/popup/DiscountConditions'),
    'PS-CTT_075_1': () => import('~/components/page/contract/popup/'),
    'PS-CTT_075_2': () => import('~/components/page/contract/popup/'),
    'PS-CTT_075_3': () => import('~/components/page/contract/popup/'),
    'PS-CTT_076': () => import('~/components/page/contract/popup/TermsService'),
    'PS-CTT_077_1': () => import('~/components/page/contract/popup/'),
    'PS-CTT_077_2': () => import('~/components/page/contract/popup/'),
    'PS-CTT_077_3': () => import('~/components/page/contract/popup/'),
    'PS-CTT_078': () => import('~/components/page/contract/popup/MyCasperPopup'),
    'PS-CTT_081': () => import('~/components/page/contract/popup/AccountNumberSms'),
    'PS-CTT_082_1': () => import('~/components/page/contract/popup/'),
    'PS-CTT_082_2': () => import('~/components/page/contract/popup/'),
    'PS-CTT_082_3': () => import('~/components/page/contract/popup/'),
    'PS-CTT_083': () => import('~/components/page/support/faq/FaqPop'),
    'PS-CTT_085': () => import('~/components/page/contract/popup/RentalLongBenefit'),
    'PS-CTT_086': () => import('~/components/page/contract/popup/FlexibleWarrantyService'),
    'PS-CTT_087': () => import('~/components/page/contract/popup/ConditionChange'),
    'PS-CTT_092': () => import('~/components/page/contract/popup/SecurityWait'),
    'PS-CTT_094': () => import('~/components/page/contract/popup/AgreeDutyRetention'),
    'PS-CTT_097': () => import('~/components/page/contract/popup/AgreePersonalData'),
    'PS-CTT_098': () => import('~/components/page/contract/popup/AgreePurchase'),

    // 결제
    'PS-PAY_001': () => import('~/components/page/payment/popup/'),
    'PS-PAY_005': () => import('~/components/page/payment/popup/'),
    'PS-PAY_009': () => import('~/components/page/payment/popup/'),
    'PS-PAY_010': () => import('~/components/page/payment/popup/'),
    'PS-PAY_012': () => import('~/components/page/payment/popup/'),
    'PS-PAY_016': () => import('~/components/page/payment/popup/'),
    'PS-PAY_017': () => import('~/components/page/payment/popup/'),
    'PS-PAY_024': () => import('~/components/page/payment/popup/'),
    'PS-PAY_025': () => import('~/components/page/payment/popup/'),
    'PS-PAY_026': () => import('~/components/page/payment/popup/'),
    'PS-PAY_028': () => import('~/components/page/payment/popup/RegistrationProxyService'),
    'PS-PAY_030': () => import('~/components/page/payment/popup/'),
    'PS-PAY_032': () => import('~/components/page/payment/popup/InstallmentProductsDetail'),
    'PS-PAY_033': () => import('~/components/page/payment/popup/InstallmentProductsDetail'),
    'PS-PAY_034': () => import('~/components/page/payment/popup/InstallmentProductsDetail'),
    'PS-PAY_035': () => import('~/components/page/payment/popup/InstallmentProductsDetail'),
    'PS-PAY_037': () => import('~/components/page/payment/popup/'),
    'PS-PAY_038': () => import('~/components/page/payment/popup/'),
    'PS-PAY_039': () => import('~/components/page/payment/popup/'),
    'PS-PAY_040': () => import('~/components/page/payment/popup/'),
    'PS-PAY_041': () => import('~/components/page/payment/popup/'),
    'PS-PAY_042': () => import('~/components/page/payment/popup/'),
    'PS-PAY_052': () => import('~/components/page/payment/popup/'),
    'PS-PAY_053': () => import('~/components/page/support/faq/FaqPop'),
    'PS-PAY_054': () => import('~/components/page/payment/popup/'),
    'PS-PAY_054_1': () => import('~/components/page/payment/popup/'),
    'PS-PAY_055': () => import('~/components/page/payment/popup/'),
    'PS-PAY_058': () => import('~/components/page/payment/popup/'),
    'PS-ETC_010': () => import('~/components/page/payment/popup/'),
    'PS-PAY_021': () => import('~/components/page/payment/popup/'),

    //마이페이지
    'PS-MMB_006': () => import('~/components/page/mypage/user/PopWithdrawal'),
    'PS-MCT_019': () => import('~/components/page/mypage/purchase/contract-detail/popups/ContractCancelPopup'),
    'PS-MCT_020': () => import('~/components/page/mypage/purchase/contract-detail/popups/RefundReturnPopup'),
    'PS-MCT_029': () => import('~/components/page/mypage/purchase-list/OverviewEvidences'),
    'PS-MCT_033': () => import('~/components/page/mypage/purchase-list/PopTemporarySave'),
    'PS-MCT_039': () => import('~/components/page/mypage/purchase/contract-detail/popover/DigitalSignMessage'),
    'PS-MCT_041': () => import('~/components/page/mypage/purchase/contract-detail/popups/ContractInfoPopup'),
    'PS-MCT_042': () => import('~/components/page/mypage/purchase/contract-detail/popups/DownPaymentPopup'),
    'PS-MCT_043': () => import('~/components/page/mypage/purchase/contract-detail/popups/MyCasperPopup'),
    'PS-MCT_044': () => import('~/components/page/mypage/purchase/contract-detail/popups/DiscountChangePopup'),
    'PS-MCT_045': () => import('~/components/page/mypage/purchase/contract-detail/popups/DownPaymentRefundPopup'),
    'PS-MCT_052': () => import('~/components/page/mypage/purchase/contract-detail/popups/MessageRepeatPopup'),
    'PS-MCT_061': () => import('~/components/page/mypage/purchase/contract-detail/popups/ChoiceServicePopup'),
    'PS-MCT_062': () => import('~/components/page/mypage/purchase/contract-detail/popups/TakeOverConfirmPopup'),
    'PS-MCT_066': () => import('~/components/page/mypage/purchase/contract-detail/popups/AddressInfoPopup'),
    'PS-MCT_067': () => import('~/components/page/mypage/purchase/contract-detail/popups/FaxNumberPopup'),
    'PS-MCO_003': () => import('~/components/page/mypage/user/PopEmployeeAuth'),
    'PS-MCO_014': () => import('~/components/page/mypage/user/PopIdNumSecure'),
    'PS-MCO_015': () => import('~/components/page/mypage/user/PopAuthGuide'),
    'PS-MAC_008': () => import('~/components/page/mypage/review/Satisfaction'),
    'PS-DIS_066_2': () => import('~/components/page/mypage/coupon/CouponInfo')
  },
  data() {
    return {
      headingTitle: 'POPUP LIST (팝업 모음)',
      wlist: weblist
    }
  },
  methods: {
    setname(val) {
      return Object.keys(val)[Object.keys(val).length - 1]
    },
    bodyStop() {
      $('body').css({ 'width' : '100%', 'height' : '100vh', 'overflow' : 'hidden' })
    },
    bodyClear() {
      $('body').css({ 'width' : 'auto', 'height' : 'auto', 'overflow' : 'auto' })
    },
    bodyStopClose() {
      this.bodyStop()
      setTimeout(() => {
        $('.popup-close-button').on('click', () => {
          this.bodyClear()
        })
        $('.el-dialog__wrapper').on('click', () => {
          this.bodyClear()
        })
      }, 200)
    },
  }
}
</script>

<style lang="scss">
.popup-list-index {
  > header > h1 {
    padding: 20px;
  }
  .popup-list-category-box {
    padding: 0 20px;
    h2 {
      padding: 10px 0;
    }
    .popup-view-list {
      > li {
        .popup-true-li {
          padding: 20px;
          border-bottom: 1px solid #ddd;
          > button {
            display: block;
            width: 100%;
            text-align: left;
          }
        }
      }
    }
  }
}
</style>
