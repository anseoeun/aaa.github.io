<template>
  <!-- 2021.04.09 전체적인 디자인 수정 -->
  <div class="content contract">
    <v-pageheader
      :top-breadcrumb="topBreadcrumb"
      page-title="계약하기"
      page-infotext="차량을 계약하세요, 캐스퍼를 받기 위한 첫 단계입니다."
    />
    <div class="contract-step">
      <contract-step :index="step" />
      <time-gauge v-if="step !== '1'" mode="info-text" />
      <div class="purchase-info">
        <div class="car-img">
          <v-img :src="require('~/assets/images/temp/temp-payment-car-model.png')" alt="AX 스마트스트림 가솔린 1.1 터보 프리미엄 밀레니얼 A/T"></v-img>
        </div>
        <div class="text">
          <span>결제예정금액</span>
          <strong>16,800,000</strong> 원
        </div>
        <!-- 팝업연결 예정 -->
        <v-btn class="btn" @click="popVisible.myCasperPopup = true"><span class="offscreen">결제예정금액팝업보기</span></v-btn>
      </div>
    </div>
    <div class="page-step-wrap">
      <page-step1 v-if="step === '1'" />
      <page-step2 v-else-if="step === '2'" />
      <page-step3 v-else-if="step === '3'" />
      <!-- 2021.04.13 (ver1.6) 계약금 결제가 필요없는 계약일 경우 step === '4' 호출-->
      <page-step4 v-else-if="step === '4'" />
    </div>

    <!-- 팝업 -->
    <my-casper-popup
      :visible="popVisible.myCasperPopup"
      @close="popVisible.myCasperPopup = false"
    ></my-casper-popup>

  </div>
</template>

<script>
import ContractStep from '~/components/page/contract/step/ContractStep'
import PageStep1 from '~/components/page/contract/PageStep1'
import PageStep2 from '~/components/page/contract/PageStep2'
import PageStep3 from '~/components/page/contract/PageStep4'
import PageStep4 from '~/components/page/contract/PageStep6'
import TimeGauge from '~/components/page/contract/content/TimeGauge'
import MyCasperPopup from '~/components/page/contract/popup/MyCasperPopup'
export default {
  head() {
    return {
      title: '계약 > 계약하기'
    }
  },
  components: {
    PageStep1,
    PageStep2,
    PageStep3,
    PageStep4,
    ContractStep,
    TimeGauge,
    MyCasperPopup
  },
  props: {
    paramStep: {
      type: String,
      default: () => '0'
    }
  },
  data() {
    return {
      topBreadcrumb: [
        { linkName: '계약', link: '/' },
        { linkName: '계약하기', link: '/' }
      ],
      // 2021.03.23 (ver1.3) 추가
      initStep: '1',

      popVisible: {
        myCasperPopup: false
      },

    }
  },
  // 2021.03.23 (ver1.3) 추가
  computed: {
    step() {
      if (this.paramStep === '/' || this.paramStep === '0') {
        return this.initStep
      } else {
        return this.paramStep
      }
    }
  },
  mounted() {
    //화면 step 가져오기, publishing 전용 (개발 시, 삭제해 주세요)
    this.publicStep()
  },
  methods: {
    //화면 step 가져오기, publishing 전용 (개발 시, 삭제해 주세요)
    publicStep() {
      let myPath = this.$route.fullPath
      return (this.paramStep = myPath.charAt(myPath.length - 1))
    }
  }
}
</script>
