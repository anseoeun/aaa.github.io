<template>
  <div class="content support support-main">
    <div class="support-search">
      <v-pageheader
        :top-breadcrumb="topBreadcrumb"
        page-title="고객지원"
        page-infotext="차량구매 지원센터, 자주하는 질문 등 도움이 되는 정보를 한 눈에 확인해보세요."
      />
      <!-- 검색 -->
      <div class="search-wrap">
        <v-input
          v-model="search"
          class="search-input"
          :clearable="true"
          placeholder="궁금하신 단어를 입력해 주세요"
        >
          <v-btn slot="suffix" type="icon" icon-class="icon-search"></v-btn>
        </v-input>
      </div>
      <!-- 검색결과 -->
      <faq-result></faq-result>
    </div>
    <!-- 자주하는 질문 -->
    <div class="matching-box column">
      <div class="box-wrap">
        <div class="box-tit">
          <em>자주하는 질문</em>
          <v-btn class="btn-more">전체보기</v-btn>
        </div>
        <div class="box-desc">
          <div class="qna-list">
            <strong class="title">자주하는 질문 Top.5</strong>
            <ol class="qna-box">
              <li>
                <nuxt-link to="/" role="button">
                  <em>1</em>
                  <span>차량 계약 후 해지시 계약금은 환불 받을 수 있습니까?</span>
                </nuxt-link>
              </li>
              <li>
                <nuxt-link to="/" role="button">
                  <em>2</em>
                  <span>업무 시간 외 시간에도 계약이 가능한가요?</span>
                </nuxt-link>
              </li>
              <li>
                <nuxt-link to="/" role="button">
                  <em>3</em>
                  <span>업무 시간 외 시간에도 계약이 가능한가요?</span>
                </nuxt-link>
              </li>
              <li>
                <nuxt-link to="/" role="button">
                  <em>4</em>
                  <span>장애인 면세 공동명의로 차량 구입하려고 하는데 장애인을 외1인으로 해도 되나요?</span>
                </nuxt-link>
              </li>
              <li>
                <nuxt-link to="/" role="button">
                  <em>5</em>
                  <span>장애인 면세 공동명의로 차량 구입하려고 하는데 장애인을 외1인으로 해도 되나요?</span>
                </nuxt-link>
              </li>
            </ol>
          </div>
          <div class="category-list">
            <strong class="title">카테고리 보기</strong>
            <ul>
              <li class="purchase">
                <strong>차량구매</strong>
                <ul class="bullet-list">
                  <li><nuxt-link to="/">전체</nuxt-link></li>
                  <li><nuxt-link to="/">계약</nuxt-link></li>
                  <li><nuxt-link to="/">결제</nuxt-link></li>
                  <li><nuxt-link to="/">차량 배송 및 인수</nuxt-link></li>
                  <li><nuxt-link to="/">보험/등록</nuxt-link></li>
                  <li><nuxt-link to="/">중고차/폐차</nuxt-link></li>
                  <li><nuxt-link to="/">세금</nuxt-link></li>
                  <li><nuxt-link to="/">취소</nuxt-link></li>
                </ul>
              </li>
              <li class="bluemembers">
                <strong>블루멤버스</strong>
                <ul class="bullet-list">
                  <li><nuxt-link to="/">전체</nuxt-link></li>
                  <li><nuxt-link to="/">회원 및 혜택</nuxt-link></li>
                  <li><nuxt-link to="/">카드/포인트</nuxt-link></li>
                  <li><nuxt-link to="/">제휴/서비스</nuxt-link></li>
                </ul>
              </li>
              <li class="finance">
                <strong>자동차금융</strong>
                <ul class="bullet-list">
                  <li><nuxt-link to="/">전체</nuxt-link></li>
                  <li><nuxt-link to="/">할부</nuxt-link></li>
                  <li><nuxt-link to="/">리스</nuxt-link></li>
                  <li><nuxt-link to="/">렌트</nuxt-link></li>
                </ul>
              </li>
              <li class="digital">
                <strong>현대 디지털 키</strong>
                <ul class="bullet-list">
                  <li><nuxt-link to="/">전체</nuxt-link></li>
                  <li><nuxt-link to="/">설치/등록</nuxt-link></li>
                  <li><nuxt-link to="/">사용법</nuxt-link></li>
                  <li><nuxt-link to="/">일반</nuxt-link></li>
                </ul>
              </li>
              <li class="homepage">
                <strong>홈페이지</strong>
                <ul class="bullet-list">
                  <li><nuxt-link to="/">전체</nuxt-link></li>
                  <li><nuxt-link to="/">회원가입</nuxt-link></li>
                  <li><nuxt-link to="/">사이트이용안내</nuxt-link></li>
                </ul>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
    <!-- 상담 서비스 -->
    <div class="councel-service">
      <strong class="title">상담 서비스</strong>
      <ul class="content-inner">
        <li>
          <div class="tit">1:1 문의</div>
          <div class="councel-box">
            <div class="txt">1:1상담이 필요하신가요?</div>
            <div class="menu"><v-btn type="nlink" class="btn-more">나의 1:1 문의내역</v-btn></div>
          </div>
          <div class="btn-wrap"><v-btn type="nlink" class="btn btn md white r">1:1 문의하기</v-btn></div>
        </li>
        <li class="live">
          <div class="tit">라이브 채팅</div>
          <div class="councel-box">
            <div class="txt">채팅 상담이 필요하신가요?</div>
            <div class="sub-txt">월~금 09:00~18:00 <br />(12:00~13:00 점심시간)</div>
          </div>
          <div class="btn-wrap"><v-btn type="nlink" class="btn btn md white r">채팅상담원 연결</v-btn></div>
        </li>
        <li class="remote">
          <div class="tit">원격 상담</div>
          <div class="councel-box">
            <div class="txt">차량구매 사이트 이용중 직원이 <br />고객님과 같은 PC화면을 보면서 <br />도움을 드리는 서비스 입니다.</div>
          </div>
          <div class="btn-wrap"><v-btn type="nlink" class="btn btn md white r">원격상담 시작하기</v-btn></div>
        </li>
        <li class="ars">
          <div class="tit">ARS 상담</div>
          <div class="councel-box">
            <div class="txt">차량 구입/정비 서비스, 멤버십 등 문의<br /> <b>고객센터(대표) 080-600-6000</b></div>
            <div class="sub-txt">
              이용시간 안내
              <v-popover class="icon" trigger="hover" placement="bottom-start">
                <p>평일 08:30~19:00<br />토요일, 공휴일 09:00~17:00<br />일요일 09:00~16:00</p>
                <v-btn slot="reference"><i class="icon-help"></i></v-btn>
              </v-popover>
            </div>
          </div>
          <div class="btn-wrap">

            <!-- 향후오픈예정 -->
            <!-- <div class="menu">
              <v-btn type="button" class="btn-more" @click="popVisible.vars = true">보이는 ARS 이용방법</v-btn>
            </div> -->
            <div class="menu">
              <v-btn type="button" class="btn-more" @click="popVisible.pars = true">ARS 이용방법</v-btn>
            </div>
          </div>
        </li>
      </ul>
    </div>
    <p-ars :visible="popVisible.pars" @close="popVisible.pars = false"></p-ars>
    <v-ars :visible="popVisible.vars" @close="popVisible.vars = false"></v-ars>

    <!-- 구매가이드 -->
    <div class="matching-box purchase-guide">
      <div class="box-wrap">
        <div class="box-tit">
          구매가이드
        </div>
        <div class="box-desc">
          <div class="guide-list">
            <nuxt-link to="/" role="button">
              <strong class="title">구매절차가 궁금하세요?</strong>
              <ul class="bullet-list">
                <li>차량선택 및 견적</li>
                <li>계약</li>
                <li>결제</li>
                <li>차량배송 및 인수</li>
                <li>등록</li>
              </ul>
            </nuxt-link>
            <nuxt-link to="/" role="button">
              <strong>제도 및 규정에 관해 알고 싶으세요?</strong>
              <ul class="bullet-list">
                <li>블루멤버스</li>
                <li>바디 케어 서비스</li>
                <li>세금</li>
                <li>친환경 폐차</li>
                <li>저공해차 표지 발급</li>
                <li>고속도로 버스 전용 차로 통행 기준</li>
              </ul>
            </nuxt-link>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import FaqResult from '~/pages/support/faq/result'
import PArs from '~/components/page/support/PArs'
import VArs from '~/components/page/support/VArs'
export default {
  head() {
    return {
      title: '고객지원',
    }
  },
  components: {
    FaqResult,
    PArs,
    VArs
  },
  data() {
    return {
      topBreadcrumb: [
        { linkName: '고객지원', link: '/' },
      ],
      search: '',
      popVisible: {
        pars: false,
        vars: false
      },
    }
  },
}
</script>
