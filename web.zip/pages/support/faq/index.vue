<template>
  <div class="content support support-faq">
    <v-pageheader
      :top-breadcrumb="topBreadcrumb"
      page-title="자주하는 질문"
      page-infotext="자주하는 질문을 통해 궁금증을 해결해보세요."
    />

    <!-- 검색 -->
    <div class="search-wrap">
      <v-input
        v-model="search"
        class="search-input"
        :clearable="true"
        placeholder="궁금하신 단어를 입력해 주세요"
      >
        <v-btn slot="suffix" type="icon" icon-class="icon-search" @click="searchResult = true"></v-btn>
      </v-input>
    </div>

    <!-- 검색결과 -->
    <faq-result v-if="searchResult"></faq-result>

    <!-- 카테고리 -->
    <div class="faq-list-wrap">
      <div class="matching-box content-inner">
        <div class="box-wrap">
          <div class="box-tit">
              카테고리
          </div>
          <div class="box-desc">
             <faq-mid :faq-info="faqInfo" :mid-list="'default'" class="toggle-list" />
          </div>
        </div>
      </div>
    </div>

    <!-- 상담서비스 -->
    <div class="councel-service">
      <ul class="content-inner">
        <li>
          <div class="tit">1:1 문의</div>
          <div class="councel-box">
            <div class="txt">1:1상담이 필요하신가요?</div>
            <div class="menu"><v-btn type="nlink" class="btn-more">나의 1:1 문의내역</v-btn></div>
          </div>
          <div class="btn-wrap"><v-btn type="nlink" class="btn btn md white r">1:1 문의하기</v-btn></div>
        </li>
        <li>
          <div class="tit">라이브 채팅</div>
          <div class="councel-box">
            <div class="txt">채팅 상담이 필요하신가요?</div>
            <div class="sub-txt">월~금 09:00~18:00 <br />(12:00~13:00 점심시간)</div>
          </div>
          <div class="btn-wrap"><v-btn type="nlink" class="btn btn md white r">채팅상담원 연결</v-btn></div>
        </li>
        <li>
          <div class="tit">원격 상담</div>
          <div class="councel-box">
            <div class="txt">차량구매 사이트 이용중 직원이 <br />고객님과 같은 PC화면을 보면서 <br />도움을 드리는 서비스 입니다.</div>
          </div>
          <div class="btn-wrap"><v-btn type="nlink" class="btn btn md white r">원격상담 시작하기</v-btn></div>
        </li>
        <li>
          <div class="tit">ARS 상담</div>
          <div class="councel-box">
            <div class="txt">차량 구입/정비 서비스, 멤버십 등 문의<br /> <b>고객센터(대표) 080-600-6000</b></div>
            <div class="sub-txt">
              이용시간 안내
              <v-popover class="icon" trigger="hover" placement="bottom-start" width="100">
                <p>
                  이용시간 안내 내용
                </p>
                <v-btn slot="reference"><i class="icon-help"></i></v-btn>
              </v-popover>
            </div>
          </div>
          <div class="btn-wrap">
            <!-- 향후오픈예정 -->
            <!-- <div class="menu">
              <v-btn type="button" class="btn-more" @click="popVisible.vars = true">보이는 ARS 이용방법</v-btn>
            </div> -->
            <div class="menu">
              <v-btn type="button" class="btn-more" @click="popVisible.pars = true">누르는 ARS 이용방법</v-btn>
            </div>
          </div>
        </li>
      </ul>
    </div>
    <p-ars :visible="popVisible.pars" @close="popVisible.pars = false"></p-ars>
    <v-ars :visible="popVisible.vars" @close="popVisible.vars = false"></v-ars>
  </div>
</template>

<script>
import {VBtn, VInput} from '~/components/element'
import FaqMid from '~/components/page/support/faq/FaqMid'
import FaqResult from '~/pages/support/faq/result'
import PArs from '~/components/page/support/PArs'
import VArs from '~/components/page/support/VArs'
export default {
  head() {
    return {
      title: '고객지원 > 자주하는질문',
    }
  },
  components: {
    VBtn,
    VInput,
    FaqResult,
    FaqMid,
    PArs,
    VArs
  },
  data() {
    return {
      topBreadcrumb: [
        { linkName: ' 고객지원', link: '/' },
        { linkName: '자주하는 질문', link: '/' },
      ],
      search: '',
      searchResult: false,
      faqInfo: {
        mainTabYN: 'Y',
        mainTabList: [
          { value: 'tab1', label: '차량구매' },
          { value: 'tab2', label: '블루멤버스' },
          { value: 'tab3', label: '자동차 금융' },
          { value: 'tab4', label: '현대 디지털 키' },
          { value: 'tab5', label: '홈페이지' },
        ],
        subTabYN: 'Y',
        subTabList: [
          { value: 'sub1', label: '전체' },
          { value: 'sub2', label: '계약' },
          { value: 'sub3', label: '결제' },
          { value: 'sub4', label: '차량 배송 및 인수' },
          { value: 'sub5', label: '보험/등록' },
          { value: 'sub6', label: '중고차/폐차' },
          { value: 'sub7', label: '세금' },
          { value: 'sub8', label: '취소' },
        ],
        faqList: [],
      },
      popVisible:{
        pars:false,
        vars:false
      }
    }
  },
  created() {
    this.$nuxt.$on('tab-click', () => {
      this.searchResult = false
    })
  },
}
</script>
