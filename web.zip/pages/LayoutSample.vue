<template>
  <div style="text-align: center; padding-top: 50px;">
    <!-- pagination type1 -->
    <v-pagination :total="100" />

    <br />

    <!-- pagination type2 -->
    <v-page-more />

    <cookie-agreement />
  </div>
</template>

<script>
import VPageMore from '~/components/element/VPageMore'
import VPagination from '~/components/element/VPagination'
import CookieAgreement from '~/components/layout/CookieAgreement'
export default {
  components: {
    VPageMore,
    VPagination,
    CookieAgreement
  }
}
</script>
