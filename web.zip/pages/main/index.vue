<template>
  <div class="main">
    메인
  </div>
</template>

<script>
export default {
  head() {
    return {
      title: '메인',
    }
  },
  layout: 'main',
  components: {

  },
  data() {
    return {
    }
  }
}
</script>