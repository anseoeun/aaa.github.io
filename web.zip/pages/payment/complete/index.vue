<template>

  <!-- 2021.04.14 수정 -->
  <div class="content payment payment-complete">
    <v-pageheader
      :top-breadcrumb="topBreadcrumb"
      page-title="결제하기"
      page-infotext="차량 금액을 결제하세요. 캐스퍼를 조금 더 빨리 받으실 수 있습니다."
    >
    </v-pageheader>

    <div class="complete-info">
      <div class="title">결제 정보 입력이 완료되었습니다.</div>
      <p>증빙 서류 제출과 무통장입금 완료 후 할인 및 결제 승인 처리가 진행되고, 출고가 가능합니다.<br />필요한 증빙 서류는 아래에서 확인해 주세요.</p>
      <v-btn class="btn lg blue r" type="nlink" to="/">구매내역 상세보기</v-btn>
    </div>

    <!-- 기본사항 -->
    <div class="matching-box">
      <div class="box-wrap">
        <div class="box-tit">기본 사항</div>
        <div class="box-desc full">
          <div class="info-grid-list line">
            <ul>
              <li>
                <strong class="info-title">증빙서류</strong>
                <div class="info-group">
                  <ul class="desc-list">
                    <li>
                      <em>목록</em>
                      <v-btn class="btn-more last">증빙서류 제출하기</v-btn>
                    </li>
                    <li>주민등록등본</li>
                    <li>4대 보험 가입 확인서</li>
                  </ul>
                </div>
              </li>
              <li>
                <strong class="info-title">무통장입금 정보</strong>
                <div class="info-group">
                  <ul class="desc-list">
                    <li>
                      <em>계좌번호</em>
                      <div class="last">
                        <span class="bank-company">신한은행</span>
                        <span>900252282042</span>
                      </div>
                    </li>
                    <li>
                      <em>예금주</em>
                      <p class="last">홍길동_현대자동차</p>
                    </li>
                    <li>
                      <em>입금액</em>
                      <p class="price">2,000,000 원</p>
                    </li>
                  </ul>
                </div>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
    <!-- 인수정보 -->
    <div class="matching-box">
      <div class="box-wrap">
        <div class="box-tit">인수정보</div>
        <div class="box-desc full">
          <div class="info-grid-list">
            <ul>
              <li>
                <strong class="info-title">인수방법</strong>
                <div class="info-group">배달탁송</div>
              </li>
              <li>
                <strong class="info-title">표준서비스 물품</strong>
                <div class="info-group">선팅 무료시공</div>
              </li>
              <li>
                <strong class="info-title">차량등록방법</strong>
                <div class="info-group">온라인 다이렉트</div>
              </li>
              <li>
                <strong class="info-title">인수자</strong>
                <div class="info-group">홍길동</div>
              </li>
              <li>
                <strong class="info-title">인수자 연락처</strong>
                <div class="info-group">010-1234-5678</div>
              </li>
              <li>
                <strong class="info-title">인수지 주소</strong>
                <div class="info-group">(06627) 서울특별시 서초구 강남대로 331 (서초동) 111</div>
              </li>
              <li>
                <strong class="info-title">기타 요청사항</strong>
                <div class="info-group">기타 사항을 요청합니다.</div>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
    <!-- 결제금액정보 -->
    <div class="information-detail">
      <div class="summary-info">
        <!-- 2021.04.14 (ver) bold -->
        <strong class="title bold">결제금액 정보</strong>
        <div class="total-price">
          <span class="t-blue">할인 17.5%</span> 총 결제금액 <span class="price">13,677,430</span> 원
        </div>
        <v-btn
          class="btn-detail"
          type="icon"
          :icon-class="['icon-open', { active: isMoneyShow }]"
          @click="isMoneyShow = !isMoneyShow"
          ><span class="offscreen">상세보기</span></v-btn
        >
      </div>
      <div v-show="isMoneyShow" class="detail-info" :class="{ active: isMoneyShow }">
        <div class="info-grid-list">
          <ul>
            <li>
              <strong class="info-title">결제금액</strong>
              <div class="info-group">
                <ul class="desc-list">
                  <li>
                    <em>차량금액</em>
                    <span class="price">2,000,000 원</span>
                  </li>
                  <li>
                    <em>선지급금액(계약금)</em>
                    <p class="price t-blue">(-) 100,000 원</p>
                  </li>
                  <li>
                    <em>면세금액</em>
                    <p class="price t-blue">(-) 400,000 원</p>
                  </li>
                  <li>
                    <em>할인금액</em>
                    <p class="price t-blue">(-) 1,000,000 원</p>
                  </li>
                  <li>
                    <em>탁송료</em>
                    <p class="price">300,000 원</p>
                  </li>
                  <li>
                    <em>단기의무보험료</em>
                    <p class="price">2,000 원</p>
                  </li>
                  <li>
                    <em>할부인지대</em>
                    <p class="price">3,000 원</p>
                  </li>
                </ul>
              </div>
            </li>
            <li>
              <strong class="info-title bold">블루멤버스 적립포인트</strong>
              <div class="info-group"><span class="last t-blue">41,719 P</span></div>
            </li>
          </ul>
        </div>
      </div>
    </div>




    <!-- 할부내역 -->
    <div class="information-detail">
      <div class="summary-info">
        <strong class="title bold">할부내역</strong>
        <div class="total-price">
          <span class="t-blue">금리 3.7%</span> 월 납입금 <span class="price">87,000</span> 원
        </div>
        <v-btn
          class="btn-detail"
          type="icon"
          :icon-class="['icon-open', { active: isInstallmentShow }]"
          @click="isInstallmentShow = !isInstallmentShow"
          ><span class="offscreen">상세보기</span></v-btn
        >
      </div>
      <div v-show="isInstallmentShow" class="detail-info" :class="{ active: isInstallmentShow }">
        <!-- 2021.03.25 (ver1.1) 구조 수정 -->
        <div class="info-grid-list">
          <ul>
            <li>
              <strong class="info-title">할부 상세</strong>
              <div class="info-group">
                <ul class="desc-list">
                  <li>
                    <em>할부상품</em>
                    <span class="last">표준형</span>
                  </li>
                  <li>
                    <em>할부원금</em>
                    <ul>
                      <li><span class="price">1,000,000 원</span></li>
                      <li><span class="price">실 납입 할부금 1,000,000 원</span></li>
                    </ul>
                  </li>
                  <li>
                    <em>할부기간</em>
                    <span class="last">36개월</span>
                  </li>
                  <li>
                    <em>할부상환계획</em>
                    <span class="last"><v-btn class="btn-more last">조회하기</v-btn></span>
                  </li>
                </ul>
              </div>
            </li>
          </ul>
        </div>
      </div>
    </div>
    <!-- 결제내역 -->
    <div class="information-detail">
      <div class="summary-info">
        <strong class="title bold">결제내역</strong>
        <div class="total-price">입력한 결제금액 <span class="price">30,000,000</span> 원</div>
        <v-btn
          class="btn-detail"
          type="icon"
          :icon-class="['icon-open', { active: isPaymentShow }]"
          @click="isPaymentShow = !isPaymentShow"
          ><span class="offscreen">상세보기</span></v-btn
        >
      </div>
      <div v-show="isPaymentShow" class="detail-info" :class="{ active: isPaymentShow }">
        <div class="info-grid-list payment-check">
          <ul>
            <li>
              <strong class="info-title bold">포인트</strong>
              <div class="info-group">
                <ul class="desc-list">
                  <li>
                    <!-- 2021.03.25 (ver1.1) full 클래스 추가 -->
                    <!-- 2021.04.14 제거 -->
                    <em>블루멤버스 포인트</em>
                    <!-- 2021.03.25 (ver1.1) full 클래스 추가 -->
                    <ul>
                      <li>
                        <em>박창석</em>
                        <!-- 2021.03.25 (ver1.1) 컬러변경 -->
                        <p class="t-blue">사용완료</p>
                        <span class="price">100,000 원</span>
                      </li>
                      <li>
                        <em>이숙영</em>
                        <!-- 2021.03.25 (ver1.1) 컬러변경 -->
                        <p class="t-blue">사용완료</p>
                        <span class="price">100,000 원</span>
                      </li>
                    </ul>
                  </li>
                  <li>
                    <!-- 2021.03.25 (ver1.1) full 클래스 추가 -->
                    <em>M포인트</em>
                    <!-- 2021.03.25 (ver1.1) full 클래스 추가 -->
                    <ul>
                      <li>
                        <em>박창석</em>
                        <!-- 2021.03.25 (ver1.1) 컬러변경 -->
                        <p class="t-blue">사용완료</p>
                        <span class="price">100,000 원</span>
                      </li>
                      <li>
                        <em>이숙영</em>
                        <!-- 2021.03.25 (ver1.1) 컬러변경 -->
                        <p class="t-blue">사용완료</p>
                        <span class="price">100,000 원</span>
                      </li>
                    </ul>
                  </li>
                  <!-- 2021.03.25 (ver1.1) 추가 -->
                  <li>
                    <em class="t-black">블루멤버스 포인트 선사용</em>
                    <p class="t-blue">사용처리</p>
                    <span class="price">100,000 원</span>
                  </li>
                </ul>
              </div>
            </li>
            <li>
              <strong class="info-title bold">현금(무통장입금)</strong>
              <div class="info-group">
                <!-- 2021.03.25 (ver1.1) 구조 수정 -->
                <ul class="desc-list">
                  <li>
                    <em><span class="bank-company">신한은행</span> 900252282042 </em>
                    <p class="t-blue">입금대기중</p>
                    <span class="price">1,000,000 원</span>
                  </li>
                </ul>
              </div>
            </li>
            <li>
              <strong class="info-title bold">신용카드</strong>
              <div class="info-group">
                <ul class="desc-list">
                  <li>
                    <!-- 2021.03.25 (ver1.1) 구조 수정 -->
                    <em class="full"><span class="card-company">신한카드</span> 9042-****-****-**** </em>
                    <!-- 2021.03.25 (ver1.1) 구조 수정 -->
                    <ul class="full">
                      <li>
                        <em>3개월</em>
                        <p class="t-blue">승인완료</p>
                        <span class="price">1,000,000 원</span>
                      </li>
                    </ul>
                  </li>
                  <li>
                    <!-- 2021.03.25 (ver1.1) 구조 수정 -->
                    <em class="full"><span class="card-company">현대카드</span> 9042-****-****-**** </em>
                    <!-- 2021.03.25 (ver1.1) full 클래스 추가 -->
                    <ul class="full">
                      <li>
                        <em>일시불 / 캐시백 3%</em>
                        <p class="t-blue">승인완료</p>
                        <span class="price">1,000,000 원</span>
                      </li>
                      <li>
                        <em>세이브-오토</em>
                        <p class="t-blue">신청완료</p>
                        <span class="price">300,000 원</span>
                      </li>
                    </ul>
                  </li>
                </ul>
              </div>
            </li>
          </ul>
        </div>
      </div>
    </div>

  </div>
</template>

<script>
export default {
  head() {
    return {
      title: '결제 > 결제요청완료'
    }
  },
  components: {},
  data() {
    return {
      topBreadcrumb: [
        { linkName: '결제', link: '/' },
        { linkName: '결제요청완료', link: '/' }
      ],
      isMoneyShow: false,
      isInstallmentShow: false,
      isPaymentShow: false
    }
  }
}
</script>
