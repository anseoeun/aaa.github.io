<template>
  <div class="content payment">
    <v-pageheader
      :top-breadcrumb="topBreadcrumb"
      page-title="결제하기"
    >
      <div class="term">결제 기한이 {{ deadline }} 남았습니다</div>
      <div class="require-check">
        <strong class="title">꼭 확인해주세요</strong>
        <p>
          {{ deadlineTime }}까지<br />
          결제를 완료해 주세요.<br />
          기한 내 결제를 완료하지 않는 경우 차량 배정이 취소됩니다.
        </p>
      </div>
    </v-pageheader>
    <div class="purchase-wrap">
      <div class="purchase-info repayment">
        <installment-select type="repayment"
          @installmentProducts="popupVisible.installmentProducts = true"
          @installmentSearch="popupVisible.installmentSearch = true"
          @repaymentPlan="popupVisible.repaymentPlan = true"
         />
        <payment-method type="repayment"
          @popSaveAutoGuide="popupVisible.saveAutoGuide = true"
         />
      </div>
      <payment-tool
        @popRegistrationFee="popupVisible.feePop = true"
       />
    </div>

    <popup :visible.sync="popupVisible" @visibleSync="popupSync" />
  </div>
</template>

<script>
import InstallmentSelect from '~/components/page/payment/main/InstallmentSelect'
import PaymentMethod from '~/components/page/payment/main/PaymentMethod'
import PaymentTool from '~/components/page/payment/main/PaymentTool'
import Popup from '~/components/page/payment/popup'
export default {
  head() {
    return {
      title: '결제 > 결제하기',
    }
  },
  components: {
    InstallmentSelect,
    PaymentMethod,
    PaymentTool,
    Popup
  },
  data() {
    return{
      topBreadcrumb: [
        { linkName: '결제', link: '/' },
        { linkName: '결제하기', link: '/' },
      ],
      deadline: '1일 20시간 12분',
      deadlineTime:'2021. 01. 21 15:47',
      popupVisible: {
        installmentSearch: false,
        repaymentPlan: false,
        installmentProducts: false,
        saveAuto: false,
        saveAutoGuide: false,
      }
    }
  },
  methods: {
    popupSync(e) {
      this.popupVisible = e
    }
  }
}
</script>

