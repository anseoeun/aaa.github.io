<template>
  <div class="content payment">

    <!-- 2021.04.14 (ver1.3) 수정 -->
    <v-pageheader :top-breadcrumb="topBreadcrumb"
      page-title="결제하기"
      page-infotext="차량 금액을 결제하세요. 캐스퍼를 조금 더 빨리 받으실 수 있습니다."
    >
    </v-pageheader>

    <div class="payment-date">
      <div class="info-box">
        <p>기간 내 결제를 완료해 주세요.<br />완료하지 않는 경우 차량 배정이 취소됩니다.</p>
        <div class="gauge">
          <div class="gauge-info">
            <span class="text">결제 완료 기한</span>
            <div class="date"><span v-html="deadline"></span> 남음</div>
          </div>
        </div>
      </div>
    </div>

    <div class="purchase-wrap">
      <div class="purchase-info">
        <amount />
        <!-- 2021.03.17 (ver1.0) 수정 -->
        <take-over
          @tinting="popupVisible.tinting = true"
          @tintingCoupon="popupVisible.tintingCoupon = true"
          @brandKitCoupon="popupVisible.brandKitCoupon = true"
          @bluehands="popupVisible.bluehands = true"
          @postCode="popupVisible.postCode = true"
        />

        <sale />
        <point-use />

        <!-- 2021.03.31 (ver1.2) 추가 : 추후 디자인 변경 예정입니다 -->
        <!-- 2021.04.14 (ver1.3) 수정 -->
        <section class="information-detail">
        <div class="summary-info">
          <h1 class="title">직원 추가 혜택</h1>
        </div>
        <div class="detail-info employee">
          <div class="info-grid-list">
            <ul>
              <li>
                <el-radio v-model="radioEmployee" label="무이자할부"></el-radio>
              </li>
              <li>
                <el-radio v-model="radioEmployee" label="일시불 3% 할인"></el-radio>
              </li>
              <li>
                <el-radio v-model="radioEmployee" label="선택안함"></el-radio>
              </li>
            </ul>
            <span class="price"><strong class="ebold">100,000</strong> 원 할인 혜택</span>
          </div>
        </div>
        </section>

        <!-- 2021.03.17 (ver1.0) 할부정보 삭제 -->
        <!-- 2021.03.31 (ver1.2) 할부정보 사용 -->
        <!-- 2021.04.14 (ver1.3) 팝업 추가 -->
        <installment-select
          @installmentWaiting="popupVisible.installmentWaiting = true"
          @installmentProducts="popupVisible.installmentProducts = true"
          @installmentAgree="popupVisible.installmentAgree = true"
          @installmentSearch="popupVisible.installmentSearch = true"
          @repaymentPlan="popupVisible.repaymentPlan = true"
        />

        <!-- 2021.03.17 (ver1.0) 수정 -->
        <payment-method
          @installmentProducts="popupVisible.installmentProducts = true"
          @repaymentPlan="popupVisible.repaymentPlan = true"
          @saveAutoGuide="popupVisible.saveAutoGuide = true"
          @installmentIncreaseGuide="popupVisible.installmentIncreaseGuide = true"
          @privacy="popupVisible.privacy = true"
          @tempInsurance="popupVisible.tempInsurance = true"
          @installmentSearch="popupVisible.installmentSearch = true"
        />

        <!-- 2021.03.17 (ver1.0) 최종금액정보 삭제 -->
        <!-- <total-price /> -->
      </div>
      <payment-tool @popRegistrationFee="popupVisible.feePop = true" />
    </div>
    <popup :visible.sync="popupVisible" @visibleSync="popupSync" />
  </div>
</template>

<script>
import Amount from '~/components/page/payment/main/Amount'
import TakeOver from '~/components/page/payment/main/TakeOver'
import Sale from '~/components/page/payment/main/Sale'
import PointUse from '~/components/page/payment/main/PointUse'
import InstallmentSelect from '~/components/page/payment/main/InstallmentSelect'
import PaymentMethod from '~/components/page/payment/main/PaymentMethod'
// import TotalPrice from '~/components/page/payment/main/TotalPrice'
import PaymentTool from '~/components/page/payment/main/PaymentTool'
import Popup from '~/components/page/payment/popup'
export default {
  head() {
    return {
      title: '결제 > 결제하기'
    }
  },
  components: {
    Amount,
    TakeOver,
    Sale,
    PointUse,
    InstallmentSelect,
    PaymentMethod,
    // TotalPrice,
    PaymentTool,
    Popup,
  },
  data() {
    return {
      topBreadcrumb: [
        { linkName: '결제', link: '/' },
        { linkName: '결제하기', link: '/' }
      ],
      deadline: '1일 20시간 12분',
      popupVisible: {
        amountChange: false,
        tinting: false,
        tintingCoupon: false,
        brandKitCoupon: false,
        bluehands: false,
        installmentSearch: false,
        repaymentPlan: false,
        privacy: false,
        postCode: false,
        installmentProducts: false,
        paymentwait: false,
        feePop: false,
        infoAcquirement: false,
        infoFund: false,
        installmentIncrease: false,
        installmentIncreaseGuide: false,
        saveAuto: false,
        saveAutoGuide: false,
        creditSaveAuto: false,
        tempInsurance: false,

        // 2021.03.31 (ver1.2) 팝업추가
        installmentAgree: false,
        installmentWaiting: false,
      },
      radioEmployee: '',
    }
  },
  methods: {
    popupSync(e) {
      this.popupVisible = e
    }
  }
}
</script>
