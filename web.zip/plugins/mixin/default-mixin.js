import $ from 'jquery'
import 'imports-loader'
import 'jquery-mousewheel'
import 'malihu-custom-scrollbar-plugin'

export default {
  data() {
    return {
      idGroup: [],
      comparisionTopOffset: 100,
      myScrollWidth: 0,
    }
  },
  updated() {
    this.scrollCurrent()
  },
  methods: {
    // basic
    isMs() {
      let userAgent = window.navigator.userAgent
      let isEdge = userAgent.indexOf('Edge')
      let isIE = userAgent.indexOf('Trident')
      if (isEdge > -1 || isIE > -1) {
        return true
      }
    },

    //accessibility
    setLabel(idList) {
      let pageName = this.$route.name
      let myEl = $('.label-input')
      let group = this.idGroup
      if (myEl.length > 0) {
        for (let i = 0; i < myEl.length; i++) {
          let myLabel = myEl.eq(i).find('label')
          let myInput = myEl.eq(i).find('input, textarea')
          let myUid = myInput.attr('data-id')
          let myName = `${pageName}-${myUid}`
          myLabel.attr('for', myName)
          myInput.attr('id', myName)
          group.push(myName)
        }
      }
      idList && idList(this.idGroup)
    },
    setCaption() {
      let tbls = $('.table-area')
      tbls.find('caption').remove()
      for (let i = 0; i < tbls.length; i++) {
        let thg = []
        let ths = tbls.eq(i).find('th')
        ths.each(function () {
          thg.push($(this).text())
        })
        tbls.eq(i).prepend(`<caption>${thg}를 포함하는 표</caption>`)
      }
    },

    //interaction
    setGoTop() {
      $('body, html').stop().animate({ 'scrollTop': '0' }, 200)
    },
    setShowroom() {
      let showHeader = $('.showroom-header-wrap')
      let cHeader = $('#commonHeader')
      $(window).off('scroll').on('scroll', function () {
        let wst = $(window).scrollTop()
        if (wst > 70) {
          showHeader.removeClass('entry').addClass('fixed')
          showHeader.find('.logo').show()
        } else {
          showHeader.addClass('entry').removeClass('fixed')
          showHeader.find('.logo').hide()
          cHeader.show()
        }
      })
    },
    scrollCurrent() {
      let scEl = $('#scrollCurrent')
      let conEl = $('.content')
      if (scEl.length > 0) {
        let boxSize = scEl.parent().outerHeight()
        let iSize = scEl.outerHeight()
        let sideSize = scEl.prev().outerHeight()
        let cts
        if (conEl.hasClass('estimate')) {
          cts = 285
        } else if (conEl.hasClass('payment')) {
          cts = 505
        } else if (conEl.hasClass('contract')) {
          cts = 651
        } else {
          cts = 0
        }
        let _spf = {
          evt() {
            let position = $(window).scrollTop()
            if (position > cts && position < ((boxSize + cts) - iSize)) {
              scEl.removeClass('sticky').addClass('stop')
            } else if (position >= ((boxSize + cts) - iSize)) {
              scEl.removeClass('stop').addClass('sticky')
            } else if (position < cts) {
              scEl.removeClass(['stop', 'sticky'])
            }
          }
        }

        if (sideSize > iSize) {
          _spf.evt()
          $(window).off('scroll').on('scroll', function () { _spf.evt() })
        }
      }
    },
    comparisionModelEvent() {
      let myTop = this.comparisionTopOffset
      let area = $('.comparision')
      let comparBox = $('.comparision-model')
      let title = comparBox.find('.title')
      let modelBox = comparBox.find('.model-list')
      $('.el-dialog__body').off('scroll').on('scroll', function () {
        let position = $('.el-dialog__body').scrollTop()
        if (position > myTop) {
          $('.information-detail').eq(0).css('padding-top', '185px')
          area.addClass('fix-after')
          title.addClass('small')
          modelBox.addClass('small')
          comparBox.addClass('fixed')
        } else {
          $('.information-detail').eq(0).removeAttr('style')
          area.removeClass('fix-after')
          title.removeClass('small')
          modelBox.removeClass('small')
          comparBox.removeClass('fixed')
        }
      })
    },
    fixTop() {
      let fixObj = $('.fixtop')
      let fixObjTop = $('.fixtop').offset().top
      console.log(fixObj)
      $(window).off('scroll').on('scroll', function () {
        let wst = $(window).scrollTop()
        if (wst > fixObjTop) {
          fixObj.addClass('fix')
        } else {
          fixObj.removeClass('fix')
        }
      })
    },
    customScrollbar() {
      if ($('.vehicle-pop-list-wrap').length > 0) {
        setTimeout(() => {
          this.setScrollbar($('.vehicle-pop-list-wrap'), $('.vehicle-pop-list-wrap').height())
        }, 200)
      } else if ($('.contract-agree-list').length > 0) {
        setTimeout(() => {
          for (let i = 0; i < $('.agree-area').length; i++) {
            let my = $('.agree-area').eq(i)
            this.setScrollbar(my, '400px')
            my.css({ 'border-top' : '1px solid #ccc', 'border-bottom' : '1px solid #ccc' })
            my.find('.mCSB_scrollTools').css('right', '0')
            my.find('.body-contents').css({ 'padding-right' : '20px', 'border-top' : '0', 'border-bottom' : '0' })
          }
        }, 200)
      } else if (!$('.trim-option').length > 0 && !$('.full-popup').length > 0) {
        let area = $('.popup-body > div')
        let sh = $(window).height()
        let hh = 0
        let fh = 0
        let dhh = 0
        let dfh = 0
        if ($('.el-dialog__header').length > 0) { hh = $('.el-dialog__header').outerHeight() }
        if ($('.el-dialog__footer').length > 0) { fh = $('.el-dialog__footer').outerHeight() }
        if ($('.popup-header').length > 0) { dhh = $('.popup-header').outerHeight() }
        if ($('.popup-footer').length > 0) { dfh = $('.popup-footer').outerHeight() }
        let resultHeight = sh - (Math.round(((sh * 0.15) * 2) + 100 + hh + fh + dhh + dfh))
        setTimeout(() => {
          if (area.height() >= resultHeight) {
            this.setScrollbar(area, resultHeight)
          }
        }, 200)
      }
    },
    setScrollbar(area, resultHeight) {
      area.css('height', resultHeight)
      area.mCustomScrollbar({
        scrollButtons: { enable: false },
        theme: 'dark-thin',
        scrollbarPosition: 'outside',
      })
    },
    testDrivingSlideToggle(step, status) {
      let slider = $('.toggle-area' + step).find('.detail-info')
      slider.stop()
      if (status == 'open') {
        slider.slideDown()
      } else if (status == 'close') {
        slider.slideUp()
      }

      $('.btn-more').off('click').on('click', function () {
        if (slider.is(':hidden')) {
          slider.slideDown()
        } else {
          slider.slideUp()
        }
      })
    }
  },
}
