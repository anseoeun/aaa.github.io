// import { apiCommon } from '~/ajax'
const nullCheck = (list) => {
  let cnt = 0
  for (let i = 0; i < list.length; i++) {
    if (!list[i]) {
      break
    } else {
      cnt++
    }
  }
  return cnt === list.length ? true : false
}

const regString = (value) => {
  const pattern_eng_kor = /^[ㄱ-ㅎ|가-힣|a-z|A-Z|*]+$/
  if (!pattern_eng_kor.test(value)) {
    return true
  } else {
    return false
  }
}

const emailCheck = (value) => {
  // const pattern_email = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
  const pattern_email = /^[a-zA-Z0-9.!#$%&’*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/
  if (!pattern_email.test(value)) {
    return true
  }
}

const validateName = (rule, value, callback) => {
  const msg = '* 성명을 입력해 주십시오.'
  if (!value) {
    return callback(new Error(msg))
  }
}
const validateNameNew = (rule, value, callback) => {
  const msg = '* 성명을 입력해 주십시오.'
  let onlyStr = regString(value)
  if (!value) {
    return callback(new Error(msg))
  } else if (onlyStr) {
    return callback(new Error('* 한글, 영문 대소문자만 사용해 주십시오.'))
  }
}
const validateRelation = (rule, value, callback) => {
  const msg = '* 주계약자와의 관계를 선택해 주십시오.'
  if (!value) {
    return callback(new Error(msg))
  }
}
const validateSSN = (rule, value, callback) => {
  const msg = '* 주민등록번호를 입력해 주십시오.'
  let testbb = `${value[0]}${value[1]}`
  if (testbb.length === 0) {
    return callback(new Error(msg))
  }else if (isNaN(value[0]) || isNaN(value[1])) {
    return callback(new Error('* 숫자만 입력해주세요'))
  }else if (testbb.length !== 13) {
    return callback(new Error('* 13 자리 이상 입력해 주세요'))
  }
}
const validateSSNthroughAPI = (rule, value, callback) => {
  const msg = '* 주민등록번호를 입력해 주십시오.'
  let testbb = `${value[0]}${value[1]}`
  if (testbb.length === 0) {
    return callback(new Error(msg))
  }else if (isNaN(value[0]) || isNaN(value[1])) {
    return callback(new Error('* 숫자만 입력해주세요'))
  }else if (testbb.length !== 13) {
    return callback(new Error('* 13 자리 이상 입력해 주세요'))
  }

  // ----- API 로 성명 + 주민번호 유효성 체크한다.
  let certificate = value[2]
  if (certificate === 'N') {
    return callback(new Error('* 성명과 주민등록번호가 일치하지 않습니다'))
  } else if ( !certificate) {
    return callback(new Error(' '))
  }
}
const validateTel = (rule, value, callback) => {
  const msg = '* 휴대전화를 입력해 주십시오.'
  if (!value) {
    return callback(new Error(msg))
  }
}
const validateTelCertificate = (rule, value, callback) => {
  let certificateYn = value[1]
  let msg = '* 휴대전화를 입력해 주십시오.'
  if (certificateYn === 'N') {
    msg = '* 본인 확인을 완료해  주십시오.'
  }
  if (certificateYn === 'noMatch') {
    msg = '* 명의자 정보와 본인확인 정보가 맞지 않습니다..'
  }
  if (!value[0] || certificateYn === 'N' || certificateYn === 'noMatch') {
    return callback(new Error(msg))
  }
}
const validateEmail = (rule, value, callback) => {
  const msg = '* 이메일 주소를 입력해 주십시오.'
  let nullChk = nullCheck(value)
  if (nullChk === undefined) nullChk = true
  if (!nullChk) {
    return callback(new Error(msg))
  }
}
// const validateEmailNew = (rule, value, callback) => {
//   const msg = '* 이메일 주소를 입력해 주십시오.'
//   const testb = `${value[0]}@${value[1]}`
//   let isEmailCehck = emailCehck(testb)
//   console.log('유효성 이메일', testb)
//   console.log('유효성 이메일 isEmailCehck', isEmailCehck)

//   if (!value) {
//     return callback(new Error(msg))
//   } else if (value && isEmailCehck) {
//     return callback(new Error('* 잘못된 형식의 이메일 주소입니다.'))
//   }
// }

const validateEmailNew = async(rule, value, callback) => {
  // const msg = '* 이메일 주소를 입력해 주십시오.'
  const email = value.join('@')
  let regExp = /^[0-9a-zA-Z]([-_.]?[0-9a-zA-Z])*@[0-9a-zA-Z]([-_.]?[0-9a-zA-Z])*.[a-zA-Z]{2,3}$/i
  const checkYn = regExp.test(email)

  if (!checkYn) {
    return callback(new Error('* 잘못된 형식의 이메일 주소입니다.'))
  }
  //국판에서 이메일 체크하는 로직
  // const [res, err] = await apiCommon.postNotificationEmailValid({email})
  // if(err || res.data.result !== 'true' ) return callback(new Error('* 유효하지 않은 이메일 주소입니다.'))

}
const validateAddr = (rule, value, callback) => {
  const msg = '* 주소를 입력해 주십시오.'
  let nullChk = nullCheck(value)
  if (nullChk === undefined) nullChk = true
  if (!nullChk) {
    return callback(new Error(msg))
  }
  const regExp = /[']{2,}|[@#%$~]/g
  const checkYn = regExp.test(value)
  if (checkYn) {
    return callback(new Error('* 잘못된 형식의 주소입니다.'))
  }
}
const validateCheckbox = (rule, value, callback) => {
  const msg = '* 약관에 동의해 주십시오.'
  if (!value) {
    return callback(new Error(msg))
  }
}
const validateBlueMembersCheckbox = (rule, value, callback) => {
  const msg = '* 약관에 동의해 주십시오.'
  if (!value[0]) {
    return callback(new Error(msg))
  }
}
const validateSelectbox = (rule, value, callback) => {
  const msg = ' '
  if (!value) {
    return callback(new Error(msg))
  }
}
const validateGuaranteeSel = (rule, value, callback) => {
  const msg = '보증제도를 선택해주십시오.'
  if (!value) {
    return callback(new Error(msg))
  }
}

export default {
  regString,
  emailCheck,
  validateName,
  validateNameNew,
  validateRelation,
  validateSSN,
  validateSSNthroughAPI,
  validateTel,
  validateTelCertificate,
  validateEmail,
  validateEmailNew,
  validateAddr,
  validateCheckbox,
  validateSelectbox,
  validateGuaranteeSel,
  validateBlueMembersCheckbox
}
