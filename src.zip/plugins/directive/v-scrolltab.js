const tableCaption = {
  bind: (el, binding) => {
    let tabmenu =  document.querySelector('.tab-menu')
    let wrap = document.querySelector('.content')
    let tab = el.querySelectorAll('li')

    let tab_click = (idx) => {
      tab[idx].onclick = function(){
        let top = el.querySelector(`[data-id=tab${idx+1}]`).offsetTop
        wrap.scrollTop = top - tabmenu.clientHeight
      }
    }

    for(var i=0; i<tab.length; i++){
      tab_click(i)
    }
  }
}

export default tableCaption
