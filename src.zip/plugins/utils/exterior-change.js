class EXTERIOR_CHANGE {

  constructor(contentsBaseUrl, carCode) {
    this.contentsBaseUrl = contentsBaseUrl
    this.carCode = carCode
    this.exteriorChangeList = document.querySelectorAll('.exterior-change')
    this.exteriorChange = null
    for (let i = 0; i < this.exteriorChangeList.length; i++) {
      if (carCode === this.exteriorChangeList[i].id) {
        this.exteriorChange = this.exteriorChangeList[i]
        break
      }
    }
    this.MAX_PARETTLIST_SIZE = 9
    this.MAX_EXTERIOR_CHANGE_IMAGE_SIZE = 1
    // this.loadedVr360ImageCheckList = []
    // this.currentVr360ImageNumber = 1
    // this.isVr360Started = false
    this.currentParettButtonLocation = 0
    this.currentParettButtonTransformX = 0
    this.parettButtonListSize = 0
    this.selectedParettButtonIndex = 0
    this.selectedExteriorColor = ''
    this.exteriorColorText = ''
    this.clicked = false
    this.currPos = 0

    if (this.exteriorChange) {

      // this.initVr360(this.contentsBaseUrl)
      this.initExteriorChangeColor()
    }
  }

  // initVr360() {
  //   const vr360 = this.vr360
  //   const vrInfo = vr360.querySelector('.vr_info')
  //   const vrInfoButton = vrInfo.querySelector('.btn.btn-vr.ibtn')
  //   const vr360ControlButton = vr360.querySelector('.vr360_control_button')
  //   const vr360CarImageContainer = vr360.querySelector('.vr360_car_image_container')
  //   const vrCarImage = vr360CarImageContainer.querySelector('.vr_car_image')
  //   const CAR_IMAGE_INITIAL_ROTATION_COUNT = 10
  //   vr360ControlButton.style.display = 'none'
  //   vrInfoButton.addEventListener('click', (e) => {
  //     this.loadVr360Image(0)
  //     vrInfoButton.style.visibility = 'hidden'
  //     vr360ControlButton.style.display = 'block'
  //     vr360CarImageContainer.classList.add('hide')
  //     this.isVr360Started = true
  //     let intervalId = null
  //     const initCarAnimation = () => {
  //       if (this.currentVr360ImageNumber < CAR_IMAGE_INITIAL_ROTATION_COUNT) {
  //         this.currentVr360ImageNumber ++
  //         vrCarImage.style.opacity = '0.2'
  //         this.changeVr360CarImage()
  //         vrCarImage.style.opacity = '1'
  //       } else {
  //         clearInterval(intervalId)
  //       }
  //     }
  //     intervalId = setInterval(initCarAnimation, 40)
  //     this.focusVr360CarImageContainer()
  //   },false)
  //
  //   vr360CarImageContainer.addEventListener('keydown', (e) => {
  //     if (this.isVr360Started) {
  //       if (e.key === 'ArrowLeft' || e.key === 'Left') {
  //         this.moveVr360(1)
  //       } else if (e.key === 'ArrowRight' || e.key === 'Right') {
  //         this.moveVr360(-1)
  //       }
  //     }
  //   }, false)
  //
  //   vr360CarImageContainer.addEventListener('click', (e) => {
  //     this.focusVr360CarImageContainer()
  //   }, false)
  //
  //   const leftButton = vr360ControlButton.querySelector('.el-carousel__arrow.el-carousel__arrow--left')
  //   leftButton.addEventListener('click', (e) => {
  //     this.focusVr360CarImageContainer()
  //     this.moveVr360(1)
  //   }, false)
  //   const rightbutton = vr360ControlButton.querySelector('.el-carousel__arrow.el-carousel__arrow--right')
  //   rightbutton.addEventListener('click', (e) => {
  //     this.focusVr360CarImageContainer()
  //     this.moveVr360(-1)
  //   }, false)
  //
  //   this.changeVr360CarImage()
  //
  //   vr360CarImageContainer.addEventListener('mousedown', (e) => {
  //     this.vr360Ready(e)
  //   }, false)
  //   vr360CarImageContainer.addEventListener('touchstart', (e) => {
  //     this.vr360Ready(e)
  //   }, false)
  //
  //   window.addEventListener('mouseup', (e) => {
  //     this.vr360Finish(e)
  //   }, false)
  //   window.addEventListener('touchend', (e) => {
  //     this.vr360Finish(e)
  //   }, false)
  //   this.preload(this.contentsBaseUrl)
  // }

  // loadVr360Image(indexOfParett) {
  //   const vr360 = this.vr360
  //   if (!this.loadedVr360ImageCheckList[indexOfParett]) {
  //     const vrCarPreload = vr360.querySelector('.vr_car_preload')
  //     const vrCarPreloadImageContainer = vrCarPreload.querySelector('.vr_car_preload_image_container')
  //     const vrCarPreloadImages = vrCarPreloadImageContainer.querySelectorAll('img')
  //     for (
  //       let i = indexOfParett * this.MAX_EXTERIOR_CHANGE_IMAGE_SIZE;
  //       i < indexOfParett * this.MAX_EXTERIOR_CHANGE_IMAGE_SIZE + this.MAX_EXTERIOR_CHANGE_IMAGE_SIZE;
  //       i++
  //     ) {
  //       vrCarPreloadImages[i].setAttribute('src', vrCarPreloadImages[i].getAttribute('data-src'))
  //     }
  //     this.loadedVr360ImageCheckList[indexOfParett] = true
  //   }
  // }
  //
  // vr360Ready(e) {
  //   e.preventDefault()
  //   this.currPos = e.pageX
  //   this.clicked = true
  //   window.addEventListener(
  //     'mousemove',
  //     (e) => {
  //       this.vr360Rotate(e)
  //     },
  //     false
  //   )
  //   window.addEventListener(
  //     'touchmove',
  //     (e) => {
  //       this.vr360Rotate(e)
  //     },
  //     false
  //   )
  //   return false
  // }
  //
  // vr360Rotate(e) {
  //   if (this.isVr360Started && this.clicked) {
  //     const pageX = e.pageX
  //     const MIN_VR360_MOVE_DISTANCE = 6
  //     if (Math.abs(this.currPos - pageX) >= MIN_VR360_MOVE_DISTANCE) {
  //       if (this.currPos - pageX > 0) {
  //         this.currentVr360ImageNumber++
  //         if (this.currentVr360ImageNumber > this.MAX_EXTERIOR_CHANGE_IMAGE_SIZE) {
  //           this.currentVr360ImageNumber = 1
  //         }
  //       } else {
  //         this.currentVr360ImageNumber--
  //         if (this.currentVr360ImageNumber < 1) {
  //           this.currentVr360ImageNumber = this.MAX_EXTERIOR_CHANGE_IMAGE_SIZE
  //         }
  //       }
  //     }
  //     this.currPos = e.pageX
  //     this.changeVr360CarImage()
  //   }
  // }
  //
  // vr360Finish(e) {
  //   this.clicked = false
  // }

  // focusVr360CarImageContainer() {
  //   const vr360 = this.vr360
  //   vr360.querySelector('.exterior_image_change_container').focus()
  // }

  // moveVr360(distance) {
  //   this.currentVr360ImageNumber += distance
  //   if (this.currentVr360ImageNumber > this.MAX_EXTERIOR_CHANGE_IMAGE_SIZE) {
  //     this.currentVr360ImageNumber = 1
  //   } else if (this.currentVr360ImageNumber < 1) {
  //     this.currentVr360ImageNumber = this.MAX_EXTERIOR_CHANGE_IMAGE_SIZE
  //   }
  //   this.changeVr360CarImage()
  // }

  changeExteriorCarImage() {
    const exteriorChange = this.exteriorChange
    const exteriorChangeCar = exteriorChange.querySelector('.exterior_image_change_container')
    const exteriorChangeCarImage = exteriorChangeCar.querySelector('img')
    let imageName = '/img-exterior.png'
    let carImageColor = ''

    // 차량상세용 외장칼라
    const viewerController = exteriorChange.querySelector('.viewer-controller')
    if (viewerController) {
      const parettList = exteriorChange.querySelector('.parett-list')
      const parettButtons = parettList.querySelectorAll('button')
      carImageColor = parettButtons[this.selectedParettButtonIndex].id
    }

    const imageUrl =
      this.contentsBaseUrl + '/contents/vr360/' + this.carCode + '/exterior/' + carImageColor + imageName
    exteriorChangeCarImage.src = imageUrl
  }

  // preload() {
  //   this.preloadVr360Image()
  // }

  // preloadVr360Image() {
  //   const vr360 = this.vr360
  //   const vrCarPreload = vr360.querySelector('.vr_car_preload')
  //   vrCarPreload.style.display = 'none'
  //   let carImageColorButtons = []
  //   // 차량상세용 외장칼라
  //   const parettList = vr360.querySelector('.parett-list')
  //
  //   // 견적용 외장칼라
  //   const outColorWrap = document.querySelector('.outcolor-wrap')
  //
  //   if (parettList) {
  //     carImageColorButtons = parettList.querySelectorAll('ul > li > button')
  //   } else if (outColorWrap) {
  //     carImageColorButtons = outColorWrap.querySelectorAll('button')
  //   } else {
  //     return
  //   }
  //
  //   let imageDivHtml = '<div class="vr_car_preload_image_container">'
  //
  //   for (let i = 0; i < carImageColorButtons.length; i++) {
  //     try {
  //       for (let j = 1; j <= this.MAX_EXTERIOR_CHANGE_IMAGE_SIZE; j++) {
  //         let imageNumber = ''
  //         let imageUrl =
  //           this.contentsBaseUrl + '/contents/vr360/' + this.carCode + '/exterior/' + carImageColorButtons[i].id
  //
  //         if (j < 10) {
  //           imageNumber = '/00' + j
  //         } else {
  //           imageNumber = '/0' + j
  //         }
  //         imageUrl = imageUrl + imageNumber + '.png'
  //         imageDivHtml += `<img class="vr_car_preload_image" data-src="${imageUrl}" alt="" />`
  //       }
  //     } catch (e) {
  //       // do nothing
  //     }
  //   }
  //   imageDivHtml += '</div>'
  //   vrCarPreload.innerHTML = imageDivHtml
  // }

  initExteriorChangeColor() {
    const exteriorChange = this.exteriorChange
    // 차량상세 용 외장칼라
    const viewerController = exteriorChange.querySelector('.viewer-controller')

    if (viewerController) {
      this.exteriorColorText = exteriorChange.querySelector('.categorization').querySelector('small > span')
      const parettList = exteriorChange.querySelector('.parett-list')
      const parettButtonList = parettList.querySelectorAll('ul li')
      const parettButtons = parettList.querySelectorAll('ul li button')
      for (let i = 0; i < parettButtons.length; i++) {
        const exteriorColorChipUrl = `url('${this.contentsBaseUrl}/contents/vr360/${this.carCode}/exterior/${parettButtons[i].id}/colorchip-exterior.png')`
        parettButtons[i].style.backgroundImage = exteriorColorChipUrl
      }
      this.selectedExteriorColor = parettButtonList[0].querySelector('span').textContent
      this.exteriorColorText.textContent = this.selectedExteriorColor
      const moveButtons = parettList.querySelector('.ctrl')
      const nextButton = moveButtons.querySelector('.next')
      const prevButton = moveButtons.querySelector('.prev')
      this.parettButtonListSize = parettButtonList.length

      const parettButtonWidth = parettButtonList[1].offsetWidth
      console.log('parettButtonWidth : ' + parettButtonWidth)
      if (this.parettButtonListSize > this.MAX_PARETTLIST_SIZE) {
        nextButton.addEventListener(
          'click',
          (e) => {
            this.moveParettButtonList(parettButtonWidth * -1)
            this.controlParettMoveButton(nextButton, prevButton, 1)
          },
          false
        )
        prevButton.addEventListener(
          'click',
          (e) => {
            this.moveParettButtonList(parettButtonWidth)
            this.controlParettMoveButton(nextButton, prevButton, -1)
          },
          false
        )
        this.controlParettMoveButton(nextButton, prevButton, 0)
      } else {
        moveButtons.style.display = 'none'
      }
      for (let i = 0; i < parettButtonList.length; i++) {
        parettButtonList[i].addEventListener(
          'click',
          (e) => {
            this.changeCarExteriorColorChip(i)
          },
          false
        )
      }
    }
    this.changeCarExteriorColorChip(this.currentParettButtonLocation)
  }

  moveParettButtonList(transformX) {
    const exteriorChange = this.exteriorChange
    this.currentParettButtonTransformX += transformX
    const parettButtonList = exteriorChange.querySelector('.parett-list').querySelector('ul')
    parettButtonList.style.transform = 'translateX(' + this.currentParettButtonTransformX + 'px)'
  }

  controlParettMoveButton(nextButton, prevButton, distance) {
    this.currentParettButtonLocation += distance
    if (this.currentParettButtonLocation > 0) {
      prevButton.style.visibility = 'visible'
    } else {
      prevButton.style.visibility = 'hidden'
    }
    if (this.parettButtonListSize - this.currentParettButtonLocation > this.MAX_PARETTLIST_SIZE) {
      nextButton.style.visibility = 'visible'
    } else {
      nextButton.style.visibility = 'hidden'
    }
  }

  changeCarExteriorColorChip(n) {
    const exteriorChange = this.exteriorChange
    if (exteriorChange) {
      // this.loadVr360Image(n)
      // // 차량상세 용 외장칼라
      const viewerController = exteriorChange.querySelector('.viewer-controller')
      if (viewerController) {
        const parettList = exteriorChange.querySelector('.parett-list')
        const parettButtonList = parettList.querySelectorAll('ul > li')
        parettButtonList[this.selectedParettButtonIndex].classList.remove('check')
        this.selectedExteriorColor = parettButtonList[n].querySelector('span').textContent
        this.exteriorColorText.textContent = this.selectedExteriorColor
        parettButtonList[n].classList.add('check')
      }
      this.selectedParettButtonIndex = n
      this.changeExteriorCarImage()
      // this.focusVr360CarImageContainer()
    }
  }
}

export default EXTERIOR_CHANGE
