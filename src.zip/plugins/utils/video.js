class VIDEO {
  constructor() {
    this.videoWraps = document.querySelectorAll('.video-wrap')
    this.subtitleButtonList = new Array()
    this.subtitleContentList = new Array()
    this.videoClickButtonList = new Array()
    this.videoObjectMap = new Map()
    this.playVideoIndex = null

    if (this.videoWraps) {
      this.makeVideoWrap()
      this.initVideo()
    }

    this.videoTabs = document.querySelectorAll('.video-tab')
    this.videoTabObjectMap = new Map()
    if (this.videoTabs) {
      this.makeVideoTab()
    }
  }

  makeVideoWrap() {
    for (let i = 0; i < this.videoWraps.length; i++) {
      const subtitleButton = this.videoWraps[i].querySelector('.subtitle')
      this.subtitleButtonList.push(subtitleButton)
      this.subtitleContentList.push(this.videoWraps[i].querySelector('.subtitle-con'))
      if (subtitleButton) {
        this.closeAccordionVideoSubtitle(i)
        subtitleButton.addEventListener(
            'click',
            (e) => {
              this.accordionVideoSubtitle(i)
            },
            false
        )
      }
    }
  }

  accordionVideoSubtitle(indexOfVideoWrap) {
    const subtitle = this.subtitleContentList[indexOfVideoWrap]
    if (subtitle) {
      subtitle.getAttribute('class').includes('active')
      ? subtitle.classList.remove('active')
      : subtitle.classList.add('active')
    }
  }

  closeAccordionVideoSubtitle(indexOfVideoWrap) {
    const subtitle = this.subtitleContentList[indexOfVideoWrap]
    if (subtitle) {
      subtitle.classList.remove('active')
    }
  }

  initVideo() {
    for (let i = 0; i < this.videoWraps.length; i++) {
      const videoDiv = this.videoWraps[i].querySelector('.video')
      if (videoDiv) {
        const videoClickButton = videoDiv.querySelector('button')
        this.videoClickButtonList.push(videoClickButton)
        if (videoClickButton) {
          const video = videoDiv.querySelector('video')
          const videoObj = {
            videoDiv: videoDiv,
            videoClickButton: videoClickButton,
            video: video,
            source: video.querySelector('source')
          }
          this.videoObjectMap.set(i, videoObj)
          video.removeAttribute('controls')
          videoClickButton.addEventListener(
              'click',
              (e) => {
                this.videoClickHandler(i)
              },
              false
          )
        }
      }
    }
  }

  videoClickHandler(indexOfVideo) {
    const videoObj = this.videoObjectMap.get(indexOfVideo),
          button = videoObj.videoDiv.querySelector('button')
    button.classList.add('hide')
    videoObj.videoDiv.parentElement.classList.add('active')
    videoObj.source.setAttribute('src', videoObj.source.getAttribute('data-src'))
    videoObj.video.setAttribute('controls', 'true')
    videoObj.video.load()
    videoObj.video.play()

    this.playVideoIndex = indexOfVideo
  }

  disableVideo() {
    const videoObj = this.videoObjectMap.get(this.playVideoIndex)
    
    console.log('disable', videoObj)
    const button = videoObj.videoDiv.querySelector('button')
    videoObj.video.load()
    button.classList.remove('hide')
    videoObj.videoDiv.parentElement.classList.remove('active')
    button.addEventListener(
      'click',
      (e) => {
        this.videoClickHandler(this.playVideoIndex)
      }
    )
  }

  makeVideoTab() {
    for (let i = 0; i < this.videoTabs.length; i++) {
      const videoTab = this.videoTabs[i]
      const tabMenu = videoTab.querySelector('.tab-menu')
      const buttons = tabMenu.querySelectorAll('button')
      const tabContents = videoTab.querySelector('.tabContents')
      const videos = tabContents.querySelectorAll('div[data-id]')
      const videoList = new Array()
      for (let j = 0; j < videos.length; j++) {
        videoList.push(videos[j].querySelector('video'))
      }
      const videoTabObject = {
        tabMenu: tabMenu,
        buttons: buttons,
        tabContents: tabContents,
        videos: videos,
        videoWraps: tabContents.querySelectorAll('.video-wrap'),
        videoList: videoList
      }

      this.videoTabObjectMap.set(i, videoTabObject)

      for (let k = 0; k < buttons.length; k++) {
        if (k === 0) {
          this.changeVideoContent(i, k)
        }

       buttons[k].addEventListener(
            'click',
            (e) => {
              this.changeVideoContent(i, k)
            },
            false
        )
      }
    }
  }

  changeVideoContent(indexOfVideoTab, indexOfVideoContent) {
    const videoTabObj = this.videoTabObjectMap.get(indexOfVideoTab)

    // if (typeof videoLoadingYnList[indexOfVideoTab][indexOfVideoContent] === 'undefined') {
    //   const youtubePreviewImage = videos[indexOfVideoContent].querySelector('img')
    //   if (youtubePreviewImage) {
    //     const youtubeId = youtubePreviewImage.getAttribute('data-src')
    //     const youtubeIframeHtml = `<iframe width="100%" height="600" src="https://www.youtube.com/embed/${youtubeId}" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture allowfullscreen="allowfullscreen">`
    //     videoWraps[indexOfVideoContent].querySelector('.video').innerHTML = youtubeIframeHtml
    //   }
    //   videoLoadingYnList[indexOfVideoTab][indexOfVideoContent] = 'Y'
    // }
    for (let i = 0; i < videoTabObj.buttons.length; i++) {
      videoTabObj.buttons[i].classList.remove('active')
      videoTabObj.videos[i].classList.remove('show')
      const video = videoTabObj.videoList[i]
      if (video !== null && video.play) {
        video.pause()
      }
      if (i === indexOfVideoContent) {
        videoTabObj.buttons[i].classList.add('active')
        videoTabObj.videos[i].classList.add('show')
      }
    }
    for (let i = 0; i < videoTabObj.videoWraps.length; i++) {
      this.closeAccordionVideoSubtitle(i)
    }
  }

  removeEventListeners() {
    this.subtitleButtonList.forEach((subtitleButton, i) => {
      if (subtitleButton) {
        subtitleButton.removeEventListener(
            'click',
            (e) => {
              this.accordionVideoSubtitle(i)
            },
            false
        )
      }
    })

    this.videoClickButtonList.forEach((videoClickButton, i) => {
      if (videoClickButton) {
        videoClickButton.removeEventListener(
            'click',
            (e) => {
              this.videoClickHandler(i)
            },
            false
        )
      }
    })

    this.videoTabObjectMap.forEach((videoTabObj, i) => {
      for (let j = 0; j < videoTabObj.buttons.length; j++) {
        videoTabObj.buttons[j].removeEventListener(
            'click',
            (e) => {
              this.changeVideoContent(i, j)
            },
            false
        )
      }
    })
  }
}

export default VIDEO
