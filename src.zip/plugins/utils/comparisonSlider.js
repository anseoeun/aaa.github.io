class COMPARISONSLIDER {
  constructor() {
    this.imageControlWraps = document.querySelectorAll('.image_control-wrap')
    this.maskClipList = new Array()
    this.maskClipImageList = new Array()
    this.wholeList = new Array()
    this.compareImageWidthList = []
    this.sliderImageWidthList = []
    this.imageControlWrapsButtonList = new Array()
    this.sliderClickStateList = new Array()
    this.sliderLocationList = new Array()
    this.sliderInitLocationList = new Array()

    if (this.imageControlWraps.length > 0) {
      this.makeComparisonSlider()
    }
  }

  makeComparisonSlider() {
    for (let i = 0; i < this.imageControlWraps.length; i++) {
      if (this.imageControlWraps[i]) {
        const maskClip = this.imageControlWraps[i].querySelector('.mask-clip')
        this.maskClipList.push(maskClip)
        const maskClipImage = maskClip.querySelector('img')
        this.maskClipImageList.push(maskClipImage)
        const whole = this.imageControlWraps[i].querySelector('.whole')
        this.wholeList.push(whole)
        this.imageControlWrapsButtonList.push(this.imageControlWraps[i].querySelector('button'))
        this.sliderClickStateList.push(false)

        if (maskClipImage.complete) {
          this.compareImageWidthList[i] = maskClipImage.offsetWidth
          this.compareImageLoaded(i)
        } else {
          maskClipImage.addEventListener(
              'load',
              (e) => {
                this.compareImageWidthList[i] = maskClipImage.offsetWidth
                this.compareImageLoaded(i)
              },
              false
          )
        }
      }
    }
  }

  compareImageLoaded(indexOfImageControlWraps) {
    const whole = this.wholeList[indexOfImageControlWraps]
    const maskClip = this.maskClipList[indexOfImageControlWraps]
    whole.style.overflow = 'hidden'
    maskClip.style.overflow = 'hidden'
    this.compareImage(indexOfImageControlWraps)
  }

  compareImage(indexOfImageControlWraps) {
    // eslint-disable-next-line
    this.sliderClickStateList[indexOfImageControlWraps] = false
    const image = this.maskClipList[indexOfImageControlWraps]
    const initImageWidth = image.offsetWidth
    const slider = this.imageControlWrapsButtonList[indexOfImageControlWraps]

    // eslint-disable-next-line no-useless-escape
    this.sliderLocationList[indexOfImageControlWraps] = Number(slider.style.left.replace(/[^\d\.]/g, ''))
    this.sliderInitLocationList[indexOfImageControlWraps] = this.sliderLocationList[indexOfImageControlWraps]
    const sliderLeftLocation = initImageWidth * (this.sliderLocationList[indexOfImageControlWraps] / 100)
    const initSliderLeftLocation = sliderLeftLocation + slider.offsetWidth / 2

    image.style.width = (initSliderLeftLocation / initImageWidth) * 100 + '%'

    slider.addEventListener('mousedown', (e) => this.slideReady(e, indexOfImageControlWraps), false)
    window.addEventListener('mouseup', (e) => this.slideFinish(e, indexOfImageControlWraps), false)
    slider.addEventListener('touchstart', (e) => this.slideReady(e, indexOfImageControlWraps), false)
    window.addEventListener('touchstop', (e) => this.slideFinish(e, indexOfImageControlWraps), false)
  }

  slideReady(e, indexOfImageControlWraps) {
    e.preventDefault()
    this.sliderClickStateList[indexOfImageControlWraps] = true
    window.addEventListener('mousemove', (e) => this.slideMove(e, indexOfImageControlWraps), false)
    window.addEventListener('touchmove', (e) => this.slideMove(e, indexOfImageControlWraps), false)
    return false
  }

  slideMove(e, indexOfImageControlWraps) {
    let pos
    let leftSlideMoveLimitLocation = 0
    if (!this.sliderClickStateList[indexOfImageControlWraps]) {
      return false
    }
    const slider = this.imageControlWrapsButtonList[indexOfImageControlWraps]
    const isLeftMoveFix = slider.classList.contains('left-move-fix')

    if (isLeftMoveFix) {
      leftSlideMoveLimitLocation =
          this.compareImageWidthList[indexOfImageControlWraps] * (this.sliderInitLocationList[indexOfImageControlWraps] / 100) + slider.offsetWidth / 2
    }
    pos = this.getCursorPos(e, indexOfImageControlWraps)
    if (pos < leftSlideMoveLimitLocation) pos = leftSlideMoveLimitLocation
    if (pos > this.compareImageWidthList[indexOfImageControlWraps]) pos = this.compareImageWidthList[indexOfImageControlWraps]
    this.slide(pos, indexOfImageControlWraps)
  }

  slideFinish(e, indexOfImageControlWraps) {
    this.sliderClickStateList[indexOfImageControlWraps] = false
  }

  slide(pos, indexOfImageControlWraps) {
    const slider = this.imageControlWrapsButtonList[indexOfImageControlWraps]
    const image = this.maskClipList[indexOfImageControlWraps]
    const sliderHalfWidth = slider.offsetWidth / 2
    image.style.width = (pos / this.compareImageWidthList[indexOfImageControlWraps]) * 100 + '%'
    this.sliderLocationList[indexOfImageControlWraps] = ((pos - sliderHalfWidth) / this.compareImageWidthList[indexOfImageControlWraps]) * 100
    slider.style.left = this.sliderLocationList[indexOfImageControlWraps] + '%'
  }

  getCursorPos(e, indexOfImageControlWraps) {
    let cursorPos
    e = e || window.event
    const maskClipImage = this.maskClipImageList[indexOfImageControlWraps]
    const imageClientRect = maskClipImage.getBoundingClientRect()
    if (e.type === 'mousemove') {
      cursorPos = e.pageX - imageClientRect.left
    } else if (e.type === 'touchmove') {
      cursorPos = e.touches[0].clientX - imageClientRect.left
    }
    cursorPos = cursorPos - window.pageXOffset
    return cursorPos
  }

  resizeComparisonSlider() {
    for (let i = 0; i < this.compareImageWidthList.length; i++) {
      const maskClipImage = this.maskClipImageList[i]
      const sliderImage = this.imageControlWrapsButtonList[i]
      this.compareImageWidthList[i] = maskClipImage.offsetWidth
      this.sliderImageWidthList[i] = sliderImage.offsetWidth
    }
  }

  removeEventListeners() {

    this.maskClipImageList.forEach((maskClipImage, i) => {
      maskClipImage.removeEventListener(
          'load',
          (e) => {
            this.compareImageWidthList[i] = maskClipImage.offsetWidth
            this.compareImageLoaded(i)
          },
          false
      )
    })

    this.imageControlWrapsButtonList.forEach((imageControlWrapsButton, i) => {
      imageControlWrapsButton.removeEventListener('mousedown', (e) => this.slideReady(e, i), false)
      imageControlWrapsButton.removeEventListener('touchstart', (e) => this.slideReady(e, i), false)
      window.removeEventListener('mouseup', (e) => this.slideFinish(e, i), false)
      window.removeEventListener('touchstop', (e) => this.slideFinish(e, i), false)
      window.removeEventListener('mousemove', (e) => this.slideMove(e, i), false)
      window.removeEventListener('touchmove', (e) => this.slideMove(e, i), false)
    })
  }
}

export default COMPARISONSLIDER
