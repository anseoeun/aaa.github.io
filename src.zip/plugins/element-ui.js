import Vue from 'vue'
// import VueDateFns from 'vue-date-fns'
import Element from 'element-ui'
import locale from 'element-ui/lib/locale/lang/ko'

import * as components from '../components/element'

export default () => {
  Vue.use(Element, { locale })
  // Vue.use(VueDateFns, 'YYYY-MM-DD')
  Object.entries(components).forEach(([name, component]) => {
    Vue.component(name, component)
  })
}
