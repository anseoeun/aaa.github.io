/**
 * Directly import polyfills from core-js
 */

import 'core-js/fn/object/entries'
import 'core-js/fn/object/assign'
import 'core-js/fn/array/includes'
import 'core-js/fn/array/find'
import 'core-js/fn/array/from'
import 'core-js/es6/promise'
import 'core-js/es6/symbol'
