import applist from './shop-menu-app.js'
import appcomponents from './guide-components-app.js'
import appdirectives from './guide-directives-app.js'
import jsmixin from './guide-js-mixin-app.js'
import scssmixin from './guide-scss-mixin-app.js'

export default [applist, appcomponents, appdirectives, jsmixin, scssmixin]
