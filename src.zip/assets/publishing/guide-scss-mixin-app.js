const _scssMixinWeb = [
  { name: '$link', contents: 'javascript:void(0);' },
  {
    name: '@mixin reset',
    contents: '태그 초기화',
    ex: `
  @import reset(): 기본 값
  @import reset(li): 목록 초기화
  `,
  },
]

export default _scssMixinWeb
