const _componentsListWeb = [
  {
    name: 'VBtn',
    contents: `
    <v-btn>테스트1</v-btn>
    <v-btn>테스트2</v-btn>
  `,
  },
  {
    name: 'VBox',
    contents: `
    <v-box>테스트1</v-box>
    <v-box>테스트2</v-box>
  `,
  },
]

export default _componentsListWeb
