const _directivesListWeb = [
  { name: 'v-label', contents: '입력 폼 레이블 for, id 자동 추가' },
  { name: 'v-caption', contents: '테이블 캡션 자동 추가' },
]

export default _directivesListWeb
