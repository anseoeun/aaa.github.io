const _jsMixinWeb = [
  {
    name: 'setSubject',
    contents: '페이지 타이틀 출력',
    example: `
  data() {
    return {
      pageTitle: 'Casper',
    }
  },
  `,
  notice: ''
  },
  {
    name: 'setGoTop',
    contents: '페이지 상단으로 이동',
    example: `
  <v-btn @click="setGoTop"></v-btn>
  `,
  notice: ''
  },
]

export default _jsMixinWeb
