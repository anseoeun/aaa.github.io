const _plugins = [
  { name: 'hard-source-webpack-plugin', contents: '모듈 캐싱 가이드' },
  { name: 'node-sass', contents: 'scss 읽기' },
  { name: 'sass-loader', contents: 'scss 컴파일러' },
  { name: '@nuxtjs/style-resources', contents: 'nuxt에서 global scss 설정' },
  { name: 'autoprefixer', contents: '스타일 크로스 브라우징' },
  { name: 'eslint', contents: 'JS 분석도구' },
  { name: 'eslint-loader', contents: 'eslint 자동화' },
  { name: 'nuxt-babel', contents: 'JS 크로스 브라우징' },
  { name: 'hooper', contents: 'UI 슬라이드' },
  { name: 'jquery', contents: 'UI Interaction용 Jquery' },
  { name: 'vuedraggable', contents: '마우스 드래그 이벤트' },
]

const _folder = [
  {
    depth1: '~/assets',
    depth2: [
      {
        name: '/publishing',
        contents: '퍼블리싱 화면 목록 및 개발 가이드에 사용된 js',
      },
      {
        name: '/style',
        depth3: [
          { name: '/share', contents: '전역 공유 mixin' },
          { name: '/page', contents: 'page contents 스타일' },
        ],
      },
      { name: '/fonts', contents: '웹폰트' },
      { name: '/images', contents: '이미지' },
      { name: '/js', contents: 'head() mixin에서 호출하는 js 플러그인' },
    ],
  },
  {
    depth1: '~/components',
    depth2: [
      {
        name: '/publishing',
        contents: '퍼블리싱 화면 목록 및 개발 가이드에 사용된 js',
      },
    ],
  },
  {
    depth1: '~/layouts',
    depth2: [
      {
        name: '/publishing',
        contents: '퍼블리싱 화면 목록 및 개발 가이드에 사용된 js',
      },
    ],
  },
  {
    depth1: '~/pages',
    depth2: [
      {
        name: '/publishing',
        contents: '퍼블리싱 화면 목록 및 개발 가이드에 사용된 js',
      },
    ],
  },
]

const _gHtml = [
  {
    title: '지원되지 않는 속성',
    contents: ['align', 'bgcolor', 'border', 'color', 'hspace', 'vspace'],
  },
  {
    title: '지원되지 않는 요소',
    contents: [
      '<acronym>',
      '<applet>',
      '<basefont>',
      '<big>',
      '<center>',
      '<dir>',
      '<font>',
      '<frame>',
      '<frameset>',
      '<noframe>',
      '<strike>',
      '<tt>',
    ],
  },
  {
    title: 'HTML 공통 가이드',
    contents: [
      '들여쓰기는 VS Code의 Spaces: 2로 사용한다. (탭과 공백을 혼용하지 않는다.)',
      '빈 링크 표현 규칙 : <a href="javascript:void(0);">링크</a>',
      'heading 표현 규칙 1 : heading 요소를 포함하는 컨테이너는 <section>을 사용한다.',
      'heading 표현 규칙 2 : <main> 요소 하위 구조로 표현된 <section> 요소에 heading은 <h1>으로만 표현한다.',
      'table 표현 규칙 : <th> 요소에는 scope 속성을 표현한다.',
      '사전적 정의 요소 외에는 <dl> 요소를 사용하지 않는다.',
      '<a>를 제외한 inline 요소 하위에 block 요소를 두지 않는다.',
      '<a>, <button> 요소 외의 요소에 @click 이벤트를 지양한다. (잘못된 예: <li @click="eventFunction()">이벤트</li>)',
      '<label>의 for 값을 맞추기 위한 폼 요소의 id를 제외하고, id 속성을 사용하지 않는다.',
      '요소에 제공 속성이 필요할 경우 data- 속성을 사용한다. (예: <li data-index="0">첫번째 슬라이드</li>)',
      '참고 : http://www.w3bai.com/ko/html/html5_syntax.html',
    ],
  },
  {
    title: 'Entity Code',
    contents: [
      '공백 : &nbsp;',
      '© : &copy;',
      '· : &middot;',
      '& : &amp;',
      '< : &lt;',
      '> : &gt;',
      '₩ : &#8361;',
    ],
  },
  {
    title: 'Nuxt 공통 가이드',
    contents: [
      '화면 아이디를 가지는 화면 출력용 vue 파일의 Name은 화면ID로 한다.',
      '화면 출력용 vue 파일의 head()에는 SEO를 반영할 수 있는 properties를 제공한다.',
      'vue 파일 내부에 import 되는 파일들의 변수는 파스칼 표기법을 사용한다. (예: PascalCase)',
      'vue 파일 컴포넌트 import는 파스칼 표기법을 준수하며 적용 시에는 스네이크 표기법을 사용한다. (예: <publishing-index></publishing-index>)',
      'methods의 함수명은 getter, setter, boolean에 따라 get, set, is를 접두어로 사용한다.',
      'methods의 함수명이 get, set, is 외일 경우에도 show, hide, on, off, live 등의 접두어를 사용할 수 있다.',
      //'데이터 이미지 표현의 기본 규칙 : <img :src="require(~/assets/images/img.jpg)" alt="" />',
      'style 호출 시, scope를 사용하지 않는다.',
      '참고: https://ko.nuxtjs.org/examples',
    ],
  },
  {
    title: '주석처리',
    contents: ['<!-- 2021.01.01 (ver1.1) -->', '// 2021.01.01 (ver1.1)'],
  },
  {
    title: '유효성 검사',
    contents: ['https://validator.w3.org/'],
  },
]

const _gStyle = [
  {
    title: 'SCSS 공통 가이드',
    contents: [
      '들여쓰기는 VS Code의 Spaces: 2로 사용한다. (탭과 공백을 혼용하지 않는다.)',
      '문자열을 제외한 모든 속성과 값은 소문자로 표현한다.',
      '요소의 id 속성 값을 스타일 선택자로 사용하지 않는다.',
      '속성의 값이 0일 경우, 단위를 생략한다. (예: height: 0;)',
      '속성의 값에서 선행이 0일 경우, 0을 생략한다. (예: opacity: .8;)',
      '마지막 속성의 값 표기 후에도 세미콜론을 표기한다.',
    ],
  },
  {
    title: '주석처리(숫자와 영문만 사용)',
    contents: ['/* 2021.01.01 add animation */'],
  },
  {
    title: '유효성 검사',
    contents: ['https://jigsaw.w3.org/css-validator/'],
  },
]

const _gSeo = [
  {
    title: `
    title: 화면설계서 Page Path (페이지별 적용)
    `,
    contents: `
    head() {
      return {
        title: '마이페이지 > 나의 견적 내역 > 최근 본 차량',
      }
    }
    `,
  },
  {
    title: `
    description: meta 영역 제공 (레이아웃에 제공)

    - 일반
    meta keywords: 대표적인 키워드 지정,
    meta description: 페이지 내용 요약,
    meta author: 웹사이트 소유자,

    - 오픈 그래프
    og:type: 웹사이트,
    og:title: 페이지 제목,
    og:description: 페이지 설명,
    og:image: 요약 이미지,
    og:url: 웹사이트 주소,
    `,
    contents: `
    head() {
      return {
        meta: [
          {
            hid: 'keywords',
            name: 'keywords',
            content: ''
          },
          {
            hid: 'description',
            name: 'description',
            content: ''
          },
          {
            hid: 'author',
            name: 'author',
            content: ''
          },
          {
            property: 'og:type',
            content: ''
          },
          {
            property: 'og:title',
            content: ''
          },
          {
            property: 'og:description',
            content: ''
          },
          {
            property: 'og:image',
            content: ''
          },
          {
            property: 'og:url',
            content: ''
          },
        ],
      }
    }
    `,
  },
  {
    title: `
    url 최적화

    의미를 알 수 없는 축약된 화면 ID 보다는 개발 폴더구조 사용,
    개발 Components 이름 사용
    `,
    contents: `
    구매가이드 > 구매절차 > 선택형 보증제도

    (X) ~/PS-CUS_029
    (O) ~/purchase-guide/purchase-procedure/step4-detail-selective-guarantees
    `,
  },
  {
    title: `
    image 최적화

    image 폴더 구성,
    대체 텍스트 활용
    `,
    contents: `
    <img :src="require(~/assets/images/img.jpg)" alt="" />
    `,
  },
  {
    title: `
    제목 태그

    <section>으로 구조화 하여 <h1>으로 제목 제공
    `,
    contents: `
    <main>
      <h1>페이지 제목</h1>
      <section>
        <h1>depth1 박스 제목</h1>
        <section>
          <h1>depth2 첫번째 박스 제목</h1>
        </section>
        <section>
          <h1>depth2 두번째 박스 제목</h1>
        </section>
      </section>
    </main>
    `,
  },
]

const _gAcc = [
  {
    title: '대체 텍스트',
    contents: [
      '이미지 대체 텍스트는 alt 값으로 제공',
      '의미 없는 이미지는 Background 처리',
      '그래픽 문자는 동일한 내용으로 대체 텍스트 제공',
      '이미지 버튼은 기능을 명확히 이해할 수 있는 대체 텍스트 제공',
      '상세: https://accessibility.naver.com/acc/guide_01',
    ],
  },
  {
    title: '자막 제공',
    contents: [
      '영상을 제공하는 경우 음성정보를 빠짐없이 전달',
      '상세: https://accessibility.naver.com/acc/guide_02',
    ],
  },
  {
    title: '콘텐츠 구분',
    contents: [
      '색으로만 구분하지 않고 색의 의미를 텍스트로 제공',
      '그래프 제공 시 모양, 무늬, 패턴 등으로 색이 의미하고 있는 내용을 추가 제공',
      '선택 표시를 색으로 구분할 경우 구분선 등으로 추가 표시',
      '상세: https://accessibility.naver.com/acc/guide_03',
    ],
  },
  {
    title: '명도 대비',
    contents: [
      '텍스트와 배경 색의 명도 대비가 4.5:1 이상이 되도록 제공',
      '상세: https://accessibility.naver.com/acc/guide_04',
    ],
  },
  {
    title: '초점 이동',
    contents: [
      '페이지의 좌측 상단에서 우측 하단으로 일관성있게 이동',
      '모달창 오픈 시, 모달창의 닫기버튼으로 이동',
      '상세: https://accessibility.naver.com/acc/guide_05',
    ],
  },
  {
    title: '조작 가능',
    contents: [
      '웹 페이지의 모든 컨트롤은 대각선 방향의 길이를 6mm 이상으로 제공',
      '링크, 사용자 입력 등 Padding 1px 이상 제공',
      '상세: https://accessibility.naver.com/acc/guide_06',
    ],
  },
  {
    title: '재생 조절 가능',
    contents: [
      '자동 재생 미디어 사용하지 않아야 함',
      '자동 재생 슬라이더 사용 시, 정지 기능 제공',
      '상세: https://accessibility.naver.com/acc/guide_07',
    ],
  },
  {
    title: '사용자 요구에 따른 실행',
    contents: [
      '자동 팝업 사용하지 않아야 함',
      '선택 폼, 입력 폼 등에서 이동 또는 완료 버튼 등을 제공하여 사용자 요구에 실행',
      '상세: https://accessibility.naver.com/acc/guide_08',
    ],
  },
  {
    title: '오류 정정',
    contents: [
      'alert이나 본문 내에 오류 메세지 표시',
      '상세: https://accessibility.naver.com/acc/guide_09',
    ],
  },
]

export default [_plugins, _folder, _gHtml, _gStyle, _gSeo, _gAcc]
