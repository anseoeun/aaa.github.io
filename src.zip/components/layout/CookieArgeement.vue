<template>
  <div class="alert">
    <div class="alert-dimmed" @click="alertClose"></div>
    <div class="alert-area">
      <button type="button" class="alert-close" @click="alertClose">안내창 닫기</button>
      <p>
        웹 사이트 이용 시 더 알맞은 정보와 경험을 제공하고자 쿠키 정보를 사용합니다. 본 사이트를 계속 이용하는 것은 이에 동의함을 의미합니다.<br />
        더 자세한 정보는 개인정보 처리방침과 이용약관을 확인해 주세요.
      </p>
    </div>
  </div>
</template>

<script>
  export default {
    data() {
      return {
        alertVisible: false
      }
    },
    methods: {
      alertClose() {
        this.$emit('close', this.alertVisible)
      },
    }
  }
</script>