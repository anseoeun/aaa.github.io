<template>
  <v-popup :visible="popVisible.precontrctPop" @close="popVisible.precontrctPop = false">
    <template slot="header">
      <div class="title">사전계약 신청확인</div>
    </template>
    <template slot="body">
      <p class="precontract-check-text">
        이미 신청한 사전계약건이 있습니다. <br />
        계약번호 <span class="contract-num t-blue">202106470997</span>
      </p>
    </template>
    <template slot="footer">
      <div class="btn-group">
        <v-btn type="nlink" to="/" class="btn" @click="popVisible.precontrctPop = false">나의 계약 확인 하기</v-btn>
      </div>
    </template>
  </v-popup>
</template>
<script>
export default {
  props: {
    popVisible: {
      type: Object,
      defualt: {},
      required: true
    }
  }
}
</script>
