<template>
  <div class="matching-box border-line">
    <div class="box-wrap">
      <div class="box-tit">
        결제 수단
      </div>
      <div class="box-desc">
        <el-form ref="form" :model="form" :rules="rules">
          <v-tab v-scrolltab class="tab-line" :data="tabList" :contents="true" :init="true">
            <template slot="contents">
              <div data-id="tab1">
                <div class="form-grid-list line">
                  <ul>
                    <li>
                      <strong class="form-label">카드번호</strong>
                      <div class="form-group">
                        <el-form-item prop="cardNumber" class="inbl-wrap">
                          <div v-label class="label-input">
                            <label class="offscreen">카드번호</label>
                            <v-input
                              v-model="form.cardNumber"
                              type="number"
                              maxlength=""
                              placeholder="‘-’ 없이 숫자만 입력"
                            />
                          </div>
                        </el-form-item>
                      </div>
                    </li>
                    <li>
                      <strong class="form-label">카드유효기간</strong>
                      <div class="form-group">
                        <el-form-item prop="datelimitMonth" class="inbl-wrap">
                          <div v-label class="label-input">
                            <label class="offscreen">월 유효기간</label>
                            <!-- 성공 correct -->
                            <div class="check-input correct">
                              <v-input
                                v-model="form.datelimitMonth"
                                type="number"
                                maxlength="2"
                                placeholder="MM"
                              />
                            </div>
                          </div>
                          <div v-label class="label-input">
                            <label class="offscreen">년도 유효기간</label>
                            <!-- 실패 wrong -->
                            <div class="check-input wrong">
                              <v-input
                                v-model="form.datelimitYear"
                                type="number"
                                maxlength="2"
                                placeholder="YY"
                              />
                            </div>
                          </div>
                        </el-form-item>
                      </div>
                    </li>
                  </ul>
                </div>
              </div>
              <div data-id="tab2">
                <div class="form-grid-list line">
                  <ul>
                    <li>
                      <strong class="form-label">입금은행</strong>
                      <div class="form-group">
                        <v-select v-model="form.bankSelected" :data="bankList" placeholder="은행 선택" class="up" />
                        <span v-if="form.bankSelected !== ''" class="guide-txt">예금주: {{ bankSelected }}</span>
                      </div>
                    </li>
                  </ul>
                </div>
              </div>
            </template>
          </v-tab>
        </el-form>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      tabList: [
        { value: 'tab1', label: '신용카드' },
        { value: 'tab2', label: '무통장입금' }
      ],
      form: {
        cardNumber: '',
        datelimit: ['', ''],
        depositor: '',
        bankSelected: '',
      },
      bankList: [
        {
          label: '은행 선택',
          value: ''
        },
        {
          label: '국민은행',
          value: '현대자동차(123456-12-1234)'
        },
        {
          label: '우리은행',
          value: '현대자동차(1234-12-12345)'
        }
      ]
    }
  },
  computed: {
    rules() {
      return {
        cardNumber: [
          {
            required: true,
            message: '* 카드번호를 입력해 주세요',
            trigger: ['blur', 'change']
          }
        ],
        datelimitMonth: [
          {
            required: true,
            message: '* 유효기간을 입력해 주세요',
            trigger: ['blur', 'change']
          }
        ],
      }
    }
  }
}
</script>
