<template>
  <div class="">
    <!-- 판매조건변경안내 -->
    <amount-change :pop-visible="visible" />
    <!-- 썬팅 장착점 조회 -->
    <!-- <tinting :pop-visible="visible" /> -->
    <!-- 썬팅 무료 시공 -->
    <tinting-coupon :pop-visible="visible" />
    <!-- 브랜드 KIT -->
    <!-- <brandKit-coupon :pop-visible="visible" /> -->
    <!-- 등록대행 서비스 -->
    <!-- <registration-proxy-service :pop-visible="visible" /> -->
    <!-- 블루핸즈 -->
    <!-- <bluehands :pop-visible="visible" /> -->
    <!-- 할부상품 선택 -->
    <!-- <installment-products :pop-visible="visible" /> -->
    <!-- 우편번호 -->
    <!-- <post-code :pop-visible="visible" /> -->
    <!-- 내할부한도조회 -->
    <!-- <installment-search :pop-visible="visible" /> -->
    <!-- 상환계획 조회 -->
    <!-- <repayment-plan :pop-visible="visible" /> -->
    <!-- 개인정보 제3자 제공 동의 -->
    <privacy :pop-visible="visible" />
    <!-- 취득세 안내  -->
    <!-- <info-acquirement :pop-visible="visible" /> -->
    <!-- 공채 안내 -->
    <!-- <info-fund :pop-visible="visible" /> -->
    <!-- 카드한도상향 신청 -->
    <installment-increase :pop-visible="visible" />
    <!-- 신용카드사별 한도상향 안내 -->
    <!-- <installment-increase-guide :pop-visible="visible" /> -->
    <!-- 세이브-오토 신청 -->
    <save-auto :pop-visible="visible" />
    <!-- 카드한도상향 및 세이브-오토 신청 -->
    <credit-save-auto :pop-visible="visible" />
    <!-- 현대카드 세이브-오토 -->
    <!-- <save-auto-guide :pop-visible="visible" /> -->
    <!-- 차량등록비용 확인 -->
    <!-- <registration-fee :pop-visible="visible" /> -->
    <!-- 할부상품안내(표준형,잔가보장형,거치형,유예형) -->
    <!-- <installment-products-detail :pop-visible="visible" /> -->
    <!-- 결제요청안내 -->
    <!-- <payment-wait :pop-visible="visible" /> -->
    <!-- 단기의무보험안내 -->
    <!-- <temp-insurance :pop-visible="visible" /> -->
    <!-- 한도조회대기 -->
    <!-- <installment-waiting :pop-visible="visible" /> -->
    <!-- 개인정보제3자제공동의 -->
    <!-- <installment-agree :pop-visible="visible" /> -->
  </div>
</template>

<script>
import AmountChange from '~/components/page/payment/popup/AmountChange'
// import Tinting from '~/components/page/payment/popup/Tinting'
import TintingCoupon from '~/components/page/payment/popup/TintingCoupon'
// import BrandKitCoupon from '~/components/page/payment/popup/BrandKitCoupon'
// import RegistrationProxyService from '~/components/page/payment/popup/RegistrationProxyService'
// import Bluehands from '~/components/page/payment/popup/Bluehands'
// import InstallmentSearch from '~/components/page/payment/popup/InstallmentSearch'
// import RepaymentPlan from '~/components/page/payment/popup/RepaymentPlan'
// import PostCode from '~/components/common/PostCode'
// import InstallmentProducts from '~/components/page/payment/popup/InstallmentProducts'
import Privacy from '~/components/page/payment/popup/Privacy'
// import SaveAutoGuide from '~/components/page/payment/popup/SaveAutoGuide'
// import InfoAcquirement from '~/components/page/payment/popup/InfoAcquirement'
// import InfoFund from '~/components/page/payment/popup/InfoFund'
import InstallmentIncrease from '~/components/page/payment/popup/InstallmentIncrease'
// import InstallmentIncreaseGuide from '~/components/page/payment/popup/InstallmentIncreaseGuide'
import SaveAuto from '~/components/page/payment/popup/SaveAuto'
import CreditSaveAuto from '~/components/page/payment/popup/CreditSaveAuto'
// import RegistrationFee from '~/components/page/payment/popup/RegistrationFee'
// import InstallmentProductsDetail from '~/components/page/payment/popup/InstallmentProductsDetail'
// import PaymentWait from '~/components/page/payment/popup/PaymentWait'
// import TempInsurance from '~/components/page/payment/popup/TempInsurance'
// import InstallmentWaiting from '~/components/page/payment/popup/InstallmentWaiting'
// import InstallmentAgree from '~/components/page/payment/popup/InstallmentAgree'

export default {
  components: {
    AmountChange,
    // Tinting,
    TintingCoupon,
    // BrandKitCoupon,
    // RegistrationProxyService,
    // Bluehands,
    // InstallmentSearch,
    // RepaymentPlan,
    // PostCode,
    // InstallmentProducts,
    Privacy,
    // SaveAutoGuide,
    // InfoAcquirement,
    // InfoFund,
    InstallmentIncrease,
    // InstallmentIncreaseGuide,
    SaveAuto,
    CreditSaveAuto,
    // RegistrationFee,
    // InstallmentProductsDetail,
    // PaymentWait,
    // TempInsurance,
    // InstallmentWaiting,
    // InstallmentAgree
  },
  props: {
    visible: {
      type: Object,
      defualt: {},
      required: true
    }
  },
  data() {
    return {}
  },
  methods: {
    parentsSync(e) {
      this.visible = e
      this.$emit('visibleSync', this.visible)
    }
  }
}
</script>
