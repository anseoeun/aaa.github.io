<template>
  <v-popup
    :visible="popVisible.amountChange"
    :footer="['confirm']"
    @confirm="popVisible.amountChange = false"
    @close="popVisible.amountChange = false"
  >
    <template slot="header">
      <div class="title">판매조건 변경 안내</div>
      <p class="header-description">
        계약 진행 시 선택하신 할인 정보가 변경되었습니다.<br />결제하시기 전 아래 변경 사항을 확인해 주세요.
      </p>
    </template>
    <template slot="body">
      <div class="gray-box">
        <p class="contents-head">변경 사항</p>
        <ul class="plan-info">
          <li>
            <p class="title">타겟조건할인명1</p>
            <p class="description">혜택 종료</p>
          </li>
          <li>
            <p class="title">타겟조건할인명2</p>
            <p class="description">혜택 종료</p>
          </li>
          <li>
            <p class="title">금리인하상품1</p>
            <p class="description t-blue">금액 변동</p>
          </li>
        </ul>
      </div>
    </template>
  </v-popup>
</template>

<script>
import { VPopup } from '~/components/element'
export default {
  components: {
    VPopup
  },
  props: {
    popVisible: {
      type: Object,
      defualt: {},
      required: true
    }
  }
}
</script>
