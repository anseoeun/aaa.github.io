<template>
  <v-popup
    :visible="visible"
    :footer="['close']"
    @close="
      $emit('close')
      popVisible = false
    "
    @confirm="
      $emit('close')
      popVisible = false
    "
  >
    <template slot="header">
      <div class="title">기본품목안내</div>
    </template>
    <template slot="body">
      <ul class="body-contents">
        <li class="bullet">
          보유 품목은 정보는 각 제조업체의 카탈로그 및 홈페이지에 공개된 자료를 바탕으로 작성 되었습니다.
        </li>
        <li class="bullet">
          각 사마다 분류 기준이 다르므로 비교적 쉬운 품목 비교를 위해 파워트레인 안전, 지능 안전, 외관, 내장, 시트,
          편의, 멀티미디어 8가지 형식으로 재 분류 표기 하였습니다.
        </li>
        <li class="bullet">
          상기 내용은 고객님의 차량 구입 의사 결정에 도움을 드리고자 제공하는 서비스로 법적인 효력이 없으며, 실제 구입
          시 가격 및 조건에 따라 차이가 있을 수 있습니다.
        </li>
        <li class="bullet">
          수시로 최신정보를 갱신하고 있으나 정보 수집으로 간혹 업데이트가 늦어지는 경우가 발생할 수 있습니다.
        </li>
        <li class="bullet">
          품목은 카탈로그등에서 수집된 정보로 최대한 표현하였으나 일부 카탈로그에는 품목 표시가 없는 부분이 있으니,
          상세한 내용은 해당 제조사에 필히 문의 하시길 바랍니다.
        </li>
      </ul>
    </template>
  </v-popup>
</template>

<script>
import { VPopup } from '~/components/element'
export default {
  components: {
    VPopup
  },
  props: {
    visible: {
      type: Boolean,
      default: false
    }
  }
}
</script>