<template>
  <div class="matching-box">
    <div class="box-wrap">
      <div class="box-tit">구매 절차<br />안내</div>
      <div class="box-desc">
        <div class="matching-list line-type">
          <ul>
            <li>
              <div class="tit">
                <b>Step 1.<br />견적내기</b>
              </div>
              <div class="txt auto">[내차만들기] 메뉴에서 구매하고자 하는 차의 구입 비용을 계산해봅시다.</div>
            </li>
            <li>
              <div class="tit">
                <b>Step 2.<br />계약</b>
              </div>
              <div class="txt auto">
                [마이페이지] 에서 견적서를 바탕으로 계약서를 작성하고 기한 내에 계약금 납부와 전자서명을 합니다.
                <br />(재고 차량의 경우 계약금을 납부하지 않아도 계약이 가능합니다.)
              </div>
            </li>
            <li>
              <div class="tit">
                <b>Step 3.<br />차량준비</b>
              </div>
              <div class="txt auto">
                계약한 차량의 준비가 완료될 때까지 기다립니다. 차량의 준비 기간은 생산/재고 상황에 따라 짧게는 2~3일,
                길게는 몇 달 까지 소요될 수 있습니다.
              </div>
            </li>
            <li>
              <div class="tit">
                <b>Step 4.<br />차량 대금 결제</b>
              </div>
              <div class="txt auto">
                대금 결제 요청 알림톡을 받으시면 [마이페이지]에서 기한 내에 차량 대금을 결제합니다. 증빙서류가 필요한
                경우 고객센터에서 추가 서류를 요청드릴 수 있으며 대금 결제가 완료되면 차량의 배송이 시작 됩니다.
              </div>
            </li>
            <li>
              <div class="tit">
                <b>Step 5.<br />차량 배송 및 인수</b>
              </div>
              <div class="txt auto">
                요청하신 곳으로 차량이 배송되면 차량 확인 후 인수합니다. 차량 인수 후 [마이페이지]에서 인수확정을 하면
                제작증이 발급됩니다.
              </div>
            </li>
            <li>
              <div class="tit">
                <b>Step 6.<br />차량등록</b>
              </div>
              <div class="txt auto">보험 가입 후 차량을 등록 합니다.
                <div class="more-link">
                  <v-btn type="nlink" to="/" class="btn-more">구매가이드 자세히 보기</v-btn>
                </div>
              </div>
            </li>
            <li>
              <div class="tit"><b>유의사항</b></div>
              <div class="txt auto">
                주어진 시간 내 계약 또는 결제를 완료하지 않으면 자동 취소될 수 있습니다. 각 단계별 안내에 따라 시간 내
                완료하시기 바랍니다.
              </div>
            </li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  components: {},
  data() {
    return {}
  }
}
</script>
