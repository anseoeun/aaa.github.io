<template>
  <div class="matching-box border-line">
    <div class="box-wrap">
      <div class="box-tit">접수정보</div>
      <div class="box-desc">
        <div class="match-box">
          <div class="title">판촉차 구매 유의 사항</div>
          <div class="desc">
            <ol>
              <li>
                1. 판촉차의 상태는 개인에 따라 다르게 느껴질 수 있는 부분이므로 고객님께서 출고센터로 직접 방문하셔서
                차량 상태 확인 후 인수하셔야 합니다.
              </li>
              <li>
                2. 차량 상태가 고객님께서 생각하신 것과 다른 경우 차량 인수를 거부할 수 있으며, 인수 거부시 고객센터
                (080-500-6000) 으로 전화 주시면 취소 처리 해드리겠습니다.
              </li>
            </ol>
          </div>
        </div>
        <div class="match-box">
          <div class="title">차량 상세 정보</div>
          <div class="desc info-grid-list">
            <ul>
              <li>
                <strong class="info-title">할인사유</strong>
                <div class="info-group">등록 환입 | 엔진,변속기,ECM 교환</div>
              </li>
              <li>
                <strong class="info-title">주행거리</strong>
                <div class="info-group">500 km</div>
              </li>
              <li>
                <strong class="info-title">차량상태</strong>
                <div class="info-group">
                  <ul class="desc-list">
                    <li>본네트 교환</li>
                    <li>앞펜더 : 우 교환</li>
                    <li>실내/시트 오염</li>
                  </ul>
                </div>
              </li>
            </ul>
          </div>
        </div>
        <div class="match-box">
          <div class="title">차량 실사진</div>
          <div class="desc">
            <div class="slider-list">
              <!-- <v-carousel
                :options="options2"
                :data="slideList"
                :btmarrow="true"
              >

                  <template slot-scope="props">
                    <nuxt-link to="/" role="button">
                      <div class="car-img">
                        <v-img :src="props.item.carImg.src" :alt="props.item.carImg.alt"></v-img>
                      </div>
                      <ul class="flag-list">
                        <li>{{ props.item.flagData }}</li>
                      </ul>
                      <strong class="name">{{ props.item.name }}</strong>
                      <ul class="detail">
                        <li class="fullname" v-html="props.item.fullName"></li>
                        <li class="out-color">{{ props.item.outColor }}</li>
                        <li class="in-color">{{ props.item.inColor }}</li>
                        <li v-if="props.item.option" class="option">
                          <span>옵션 {{ props.item.optionList.length }} 개</span>
                          <div class="option-list">
                            <i class="icon-plus"></i>
                            <div class="cont">
                              <p v-for="(optionType, idex) in props.item.optionList" :key="idex">{{ optionType.optionName }}</p>
                            </div>
                          </div>
                        </li>
                        <li v-else class="option">옵션없음</li>
                      </ul>
                      <ul class="price">
                        <li class="discount-price"><span>할인금액 <em>{{ props.item.discountPrice }}</em> 원</span></li>
                        <li class="total-price"><strong>{{ props.item.totalPrice }}</strong> 원</li>
                      </ul>
                    </nuxt-link>
                  </template>
              </v-carousel> -->
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  components: {},
  data() {
    return {
      carImg: {
        src: require('~/assets/images/temp/temp-payment-car-model.png'),
        alt: 'AX 스마트스트림 가솔린 1.1 터보 프리미엄 밀레니얼 A/T'
      },

      options2: {
        perPage: 3,
        perMove: 2,
        fixedWidth: '12rem', //너비고정시
        autoplay: true,
        type: 'loop',
      },
      slideList: [
        {
          flagData: '3월 생산할인차',
          carImg: {
            src: require('~/assets/images/temp/temp-payment-car-model.png'),
            alt: '베뉴 자가용 LPG 1.6<br />Modern A/T',
          },
          name: '베뉴',
          fullName: '베뉴 자가용 LPG 1.6<br />Modern A/T',
          outColor: '미드나잇블랙',
          inColor: '블랙모노톤(블랙시트)',
          option: true,
          optionList: [
            { optionName: '옵션명옵션명이 길경우 길게 길게' },
            { optionName: '옵션명명이 들어갑니다 1줄초과시 말줄임' },
            { optionName: '옵션명3' },
            { optionName: '옵션명4' },
            { optionName: '옵션명5' },
          ],

          discountPrice: '100,000',
          totalPrice: '23,220,000',
        },
        {
          flagData: '전시차',
          carImg: {
            src: require('~/assets/images/temp/temp-payment-car-model.png'),
            alt: '베뉴 자가용 LPG 1.6<br />Modern A/T',
          },
          name: '그랜저',
          fullName: '그랜저 자가용 LPG 1.6<br />Modern A/T',
          outColor: '미드나잇블랙',
          inColor: '블랙모노톤(블랙시트)',
          option: false,
          discountPrice: '100,000',
          totalPrice: '23,220,000',
        },
        {
          flagData: '판촉차',
          carImg: {
            src: require('~/assets/images/temp/temp-payment-car-model.png'),
            alt: '베뉴 자가용 LPG 1.6<br />Modern A/T',
          },
          name: '그랜저',
          fullName: '그랜저 자가용 LPG 1.6<br />Modern A/T',
          outColor: '미드나잇블랙',
          inColor: '블랙모노톤(블랙시트)',
          option: true,
          optionList: [
            { optionName: '옵션명옵션명이 길경우 길게 길게' },
            { optionName: '옵션명명이 들어갑니다 1줄초과시 말줄임' },
          ],
          discountPrice: '100,000',
          totalPrice: '23,220,000',
        },
        {
          flagData: '전시차',
          carImg: {
            src: require('~/assets/images/temp/temp-payment-car-model.png'),
            alt: '베뉴 자가용 LPG 1.6<br />Modern A/T',
          },
          name: '그랜저',
          fullName: '그랜저 자가용 LPG 1.6<br />Modern A/T',
          outColor: '미드나잇블랙',
          inColor: '블랙모노톤(블랙시트)',
          option: false,
          discountPrice: '100,000',
          totalPrice: '23,220,000',
        },
        {
          flagData: '3월 생산할인차',
          carImg: {
            src: require('~/assets/images/temp/temp-payment-car-model.png'),
            alt: '베뉴 자가용 LPG 1.6<br />Modern A/T',
          },
          name: '베뉴',
          fullName: '베뉴 자가용 LPG 1.6<br />Modern A/T',
          outColor: '미드나잇블랙',
          inColor: '블랙모노톤(블랙시트)',
          option: true,
          optionList: [
            { optionName: '옵션명' },
          ],
          discountPrice: '100,000',
          totalPrice: '23,220,000',
        },
        {
          flagData: '판촉차',
          carImg: {
            src: require('~/assets/images/temp/temp-payment-car-model.png'),
            alt: '베뉴 자가용 LPG 1.6<br />Modern A/T',
          },
          name: '그랜저',
          fullName: '그랜저 자가용 LPG 1.6<br />Modern A/T',
          outColor: '미드나잇블랙',
          inColor: '블랙모노톤(블랙시트)',
          option: true,
          optionList: [
            { optionName: '옵션명옵션명이 길경우 길게 길게' },
            { optionName: '옵션명명이 들어갑니다 1줄초과시 말줄임' },
          ],
          discountPrice: '100,000',
          totalPrice: '23,220,000',
        },
      ],
    }
  }
}
</script>
