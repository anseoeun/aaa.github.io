<template>
  <div class="matching-box">
    <div class="box-wrap">
      <div class="box-tit">배달탁송<br />안내</div>
      <div class="box-desc">
        <div class="matching-list line-type">
          <ul>
            <li>
              <div class="tit">
                <b>배달탁송<br />안내</b>
              </div>
              <div class="txt auto">
                <ul class="bullet-list">
                  <li>
                    결제 완료 후 탁송 기간은 일반적으로 3~5일(주말,공휴일 제외) 소요되나 상황에 따라 달라질 수 있습니다.
                  </li>
                  <li>
                    H Gennine Accessories, N Performance 파츠 추가 차량은 장착기간으로 인해 추가 시일이 소요될 수
                    있습니다.
                  </li>
                  <li>탁송이 시작되면 마이페이지에서 탁송조회를 할 수 있습니다.</li>
                </ul>
              </div>
            </li>
            <li>
              <div class="tit">
                <b>차량인수<br />안내</b>
              </div>
              <div class="txt auto">
                <ul class="list">
                  <li><b>인수현장</b></li>
                  <li class="number">1. 신분증을 보여주고 차량을 인수합니다.</li>
                  <li class="number">2. 차량의 내/외관을 확인합니다.</li>
                  <li class="number">
                    3. 주행거리,인수날짜,지급품,연료량이 인수중에 기재된 정보와 동일한지 확인합니다.
                  </li>
                  <li class="number">
                    4. 이상이 업다면 차량인수증에 서명하고 차량을 인수합니다. 만약 차량에 이상이 발견된다면 인수를
                    거부할 수있습니다.
                  </li>
                  <li><b>사이트에서</b></li>
                  <li class="number">
                    5. 마이페이지에서 인수확정 버튼을 클릭하시면 영수증,제작증이 발급됩니다. (개인 사업자 및 법인의 경우
                    세금계산서가 발급 됩니다.)
                  </li>
                </ul>
              </div>
            </li>
            <li>
              <div class="tit"><b>유의사항</b></div>
              <div class="txt auto">
                인수 확정 후에는 단순 변심에 의한 반품 요청시 왕복 탁송료를 부과하셔야 합니다.
              </div>
            </li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  components: {},
  data() {
    return {}
  }
}
</script>
