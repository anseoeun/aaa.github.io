<template>
  <div class="matching-box border-line">
    <div class="box-wrap">
      <div class="box-tit">상세 스펙</div>
      <div class="box-desc">
        <div class="match-box">
          <div class="title">모델</div>
          <div class="desc">아반떼 자가용 LPG 1.6 Modern A/T 모던그레이 인테리어 선루프</div>
        </div>
        <div class="match-box">
          <div class="title">색상</div>
          <div class="desc info-grid-list">
            <ul>
              <li>
                <strong class="info-title">외장색상</strong>
                <div class="info-group">
                  <div class="color-info">
                    <div class="color-sample" :style="`background-image:url(${outColor.src})`"></div>
                    <div class="color-txt">{{ outColor.txt }}</div>
                  </div>
                </div>
              </li>
              <li>
                <strong class="info-title">내장색상</strong>
                <div class="info-group">
                  <div class="color-info">
                    <div class="color-sample" :style="`background-image:url(${inColor.src})`"></div>
                    <div class="color-txt">{{ inColor.txt }}</div>
                  </div>
                </div>
              </li>
            </ul>
          </div>
        </div>
        <div class="match-box">
          <div class="title">선택옵션</div>
          <div class="desc info-grid-list">
            <ul>
              <li>
                <strong class="info-title">옵션</strong>
                <div class="info-group">
                  <ul class="desc-list">
                    <li v-for="(item, index) in optionData" :key="index">
                      <em>{{ item.name }}</em>
                    </li>
                  </ul>
                </div>
              </li>
              <li>
                <div class="info-title">
                  <v-img :src="require('~/assets/images/temp/logo-hgenuine.png')" alt="H Genuine Accessories"></v-img>
                </div>
                <div class="info-group">
                  <ul class="desc-list">
                    <li v-for="(item, index) in accessoriesData" :key="index">
                      <em>{{ item.name }}</em>
                    </li>
                  </ul>
                </div>
              </li>
              <li>
                <div class="info-title">
                  <v-img :src="require('~/assets/images/temp/logo-performance.png')" alt="N performance"></v-img>
                </div>
                <div class="info-group">
                  <ul class="desc-list">
                    <li v-for="(item, index) in nperformanceData" :key="index">
                      <em>{{ item.name }}</em>
                    </li>
                  </ul>
                </div>
              </li>
            </ul>
          </div>
        </div>
        <div class="match-box">
          <div class="title">성능</div>
          <div class="desc info-grid-list">
            <ul>
              <li v-for="(item, index) in performanceList" :key="index">
                <strong class="info-title">{{ item.tit }}</strong>
                <div class="info-group">{{ item.value }}</div>
              </li>
            </ul>
          </div>
        </div>
        <div class="match-box">
          <div class="title">연비</div>
          <div class="desc info-grid-list">
            <ul>
              <li v-for="(item, index) in efficiencyList" :key="index">
                <strong class="info-title">{{ item.tit }}</strong>
                <div class="info-group">{{ item.value }}</div>
              </li>
            </ul>
          </div>
        </div>
        <div class="match-box">
          <div class="title">제원</div>
          <div class="desc info-grid-list">
            <ul>
              <li v-for="(item, index) in specificationList" :key="index">
                <strong class="info-title">{{ item.tit }}</strong>
                <div class="info-group">{{ item.value }}</div>
              </li>
            </ul>
          </div>
        </div>
        <div class="match-box">
          <div class="title">기본 포함 품목</div>
          <div class="desc info-grid-list">
            <ul>
              <li v-for="(item, index) in baseList" :key="index">{{ item }}</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  components: {},
  data() {
    return {
      inColor: { txt: '메테오 블루', src: require('~/assets/images/temp/temp-color-4.png') },
      outColor: { txt: '쉬머링 실버', src: require('~/assets/images/temp/temp-color-1.png') },
      optionData: [{ name: '현대스마트센스' }],
      accessoriesData: [{ name: '펫 패키지Ⅰ(강아지얼굴)-모노민트' }, { name: '펫 패키지Ⅲ(소형)-모노옐로우' }],
      nperformanceData: [{ name: '[N퍼포먼스 파츠] 인테리어 패키지' }],
      performanceList: [
        { tit: '엔진명', value: '가솔린 1.0 터보 엔진' },
        { tit: '연료명', value: '가솔린' },
        { tit: '변속기', value: '6단 수동 변속기' },
        { tit: '구동방식', value: '2WD (전륜구동)' },
        { tit: '최고출력', value: '123 ps / 6300 rpm' },
        { tit: '최고토크', value: '15.7 kg.m / 4500 rpm' },
        { tit: '배기량', value: '15.7 kg.m / 4500 rpm' },
        { tit: '연료탱크', value: '47L' }
      ],
      efficiencyList: [
        { tit: '연비등급', value: '1등급' },
        { tit: '복합연비', value: '21.1 km/ℓ' },
        { tit: '시내연비', value: '21.1 km/ℓ' },
        { tit: '고속연비', value: '21.1 km/ℓ' }
      ],
      specificationList: [
        { tit: '전장', value: '4,650 mm' },
        { tit: '전폭', value: '1,825 mm' },
        { tit: '축간거리', value: '1,420 mm' },
        { tit: '윤거 전', value: '2,720 mm' },
        { tit: '윤거 후', value: '1,585 mm' },
        { tit: '타이어', value: '1,599 mm' },
        { tit: '공차중량', value: '1,330 kg' }
      ],
      baseList: ['품목명', '품목명', '품목명']
    }
  }
}
</script>
