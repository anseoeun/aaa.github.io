<template>
  <v-popup
    :visible="popVisible.friendRecommend"
    :footer="['confirm']"
    @close="popVisible.friendRecommend = false"
    @confirm="popVisible.friendRecommend = false"
  >

    <template slot="header">
      <div class="title">지인 추천 할인 안내</div>
    </template>
    <template slot="body">
      <p class="text-main">지인 추천으로 <em>150,000</em>원 할인됩니다.</p>
      <p class="text-main">이제 나만의 캐스퍼를 만들어보세요!</p>
    </template>
  </v-popup>
</template>

<script>
import { VPopup } from '~/components/element'
export default {
  components: {
    VPopup
  },
  props: {
    popVisible: {
      type: Object,
      defualt: {},
      required: true
    }
  },
}
</script>