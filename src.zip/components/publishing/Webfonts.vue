<template>
  <section class="fonts-example">
    <div class="content">
      <h1>계약하기</h1>
      <p>계약자 정보를 입력하여 주세요.</p>
    </div>
    <div class="content">
      <strong class="bold">꼭 확인해주세요</strong>
      <p>
        2021. 01. 21 15:47 까지<br />계약금 결제 및 전자서명을 완료하지 않으면
        계약은 자동 취소되오니,<br />반드시 모두 완료해주세요.
      </p>
    </div>
    <div class="content">
      <h2>선택한 차량</h2>
      <p>
        코나 가솔린 1.6 터보 Modern 2WD 오토 - 라바 오렌지 / 모던그레이
        17인치알로이휠 &amp; 타이어Ⅰ외 5
      </p>
      <em>생산주문차량</em>
      <p>
        생산 주문 차량은 고객님이 원하시는 차량의 재고가 소진되어 주문 생산하는
        상품입니다.<br />생산 완료 시까지 일정 기간이 소요되며, 생산 완료 이후
        결제를 진행 하시기 바랍니다.
      </p>
      <a href="javascript:void(0);">공지사항 참조 ></a>
    </div>
    <div class="content">
      <h3 class="bold">옵션<span>(선택품목)</span></h3>
      <p>H Genuine Accessories</p>
      <p>2WD 험로주행모드(머드/샌드/스노우)</p>
    </div>
    <div class="content">
      <ul class="bullet">
        <li>
          본인 명의의 카카오톡 계정이 있는 스마트폰 소지자에 한해 온라인 계약이
          가능합니다. 오프라인 구매를 원하시면 가까운 지점/대리점을 방문해주시기
          바랍니다.
        </li>
        <li>
          본 사이트에서 <span>노후차 개별소비세 감면</span>은 적용되지 않으므로,
          대상자는 지점 또는 울산 사내판매과를 이용해주시기 바랍니다.
        </li>
        <li>
          면세 신청은 명의자 중 주계약자만 가능합니다. 면세 희망자는 고객 정보를
          주계약자로 신청해 주십시오.
        </li>
        <li>
          계약금이 필요한 차량인 경우, 기한 내
          <span>계약내역 작성, 계약금 결제, 전자서명</span>을 완료하지 않으면,
          작성중인 계약내역은 자동 파기됩니다.
        </li>
      </ul>
    </div>
  </section>
</template>
