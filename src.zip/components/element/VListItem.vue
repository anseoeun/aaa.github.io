<template>
  <div
    :class="`list-item ${itemType} ${isActive ? 'active' : ''} ${disabled ? 'disabled' : ''}`"
    :data-id="dataId"
    :data-seq="dataSeq"
  >
    <button v-if="!disabled" class="list-title" @click="onItemClick(dataId, dataSeq)">
      <slot v-if="$slots.title" name="title"></slot>
      <div v-else class="title">
        <label v-if="label !== null">{{ label }}</label>
        <slot v-else name="label"></slot>
      </div>
    </button>

    <div v-else class="list-title">
      <slot v-if="$slots.title" name="title"></slot>
      <div v-else class="title">
        <label v-if="label !== null">{{ label }}</label>
        <slot v-else name="label"></slot>
      </div>
    </div>

    <slot name="fixed" class="list-fix"></slot>

    <slot v-if="$slots.contents && isActive" name="contents"></slot>
    <div v-else-if="!(!contents && disabled) && isActive" class="conts">
      <slot></slot>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    dataId: {
      type: String,
      default: ''
    },
    dataSeq: {
      type: String,
      default: ''
    },
    label: {
      type: String,
      default: null
    },
    itemType: {
      type: String,
      default: ''
    },
    disabled: {
      type: Boolean,
      default: false
    },
    contents: {
      type: Boolean,
      default: true
    }
  },
  computed: {
    isActive() {
      return this.$parent.selected.includes(this.dataId)
    }
  },
  created() {
    this.$nuxt.$on('tab-change', () => {
      this.$el.classList.remove('active')
    })
  },
  methods: {
    onItemClick(dataId, dataSeq) {
      // eslint-disable-next-line no-useless-call
      this.$parent.$emit.apply(this.$parent, ['item-click', dataId])
      this.$emit('toggle', dataId, dataSeq)
    }
  }
}
</script>

