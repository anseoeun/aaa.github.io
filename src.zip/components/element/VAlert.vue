<template>
  <div class="alert">
    <div class="alert-dimmed" @click="alertClose"></div>
    <div class="alert-area">
      <button type="button" class="alert-close" @click="alertClose">안내창 닫기</button>
      <slot name="message"></slot>
    </div>
  </div>
</template>

<script>
  export default {
    data() {
      return {
        alertVisible: false
      }
    },
    methods: {
      alertClose() {
        this.$emit('close', this.alertVisible)
      },
    }
  }
</script>