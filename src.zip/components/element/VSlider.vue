<template>
  <div :class="`slider-group ${markType}`">
    <el-slider
      v-model="selected"
      :range="range"
      :step="step"
      :min="min"
      :max="max"
      :marks="marks"
      :format-tooltip="formatTooltipFn"
      :disabled="disabled"
      :show-stops="showStops"
      :show-input="showInput"
      :show-input-controls="false"
      :input-size="inputSize"
      :show-tooltip="showTooltip"
      @input="onInput"
      @change="onChange"
    />
    <!--
    <div v-if="markList.length" class="slider-marks">
      <div
        v-for="(item, index) in markList"
        :key="index"
        :ref="`markText${index}`"
        :style="getPosStyle(item.position, index)"
        class="mark-text"
      >
        {{ item.mark }}
      </div>
    </div>
    -->
    <div v-if="showInput" class="show-input-text">
      <slot name="inputText"></slot>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    // eslint-disable-next-line
    value: [Number, Array],
    range: {
      type: Boolean,
      default: false
    },
    disabled: {
      type: Boolean,
      default: false
    },
    min: {
      type: Number,
      default: 0
    },
    max: {
      type: Number,
      default: 100
    },
    step: {
      type: Number,
      default: 1
    },
    showStops: {
      type: Boolean,
      default: false
    },
    marks: {
      type: Object,
      default: () => {}
    },
    markType: {
      type: String,
      default: ''
    },
    showInput: {
      type: Boolean,
      default: false
    },
    inputSize: {
      type: String,
      default: 'large'
    },
    formatTooltip: {
      type: Function,
      default: () => false
    },
    showTooltip: {
      type: Boolean,
      default: false
    }
  },

  data() {
    return {
      selected: null
    }
  },

  computed: {
    markList() {
      if (!this.marks) {
        return []
      }
      const marksKeys = Object.keys(this.marks)
      return marksKeys
        .map(parseFloat)
        .sort((a, b) => a - b)
        .filter((point) => point <= this.max && point >= this.min)
        .map((point) => ({
          point,
          position: ((point - this.min) * 100) / (this.max - this.min),
          mark: this.marks[point]
        }))
    }
  },

  watch: {
    value(newValue, oldValue) {
      if (this.range) {
        const diffList = newValue.filter((val, index) => val !== oldValue[index])
        if (diffList.length) {
          this.selected = [...newValue]
        }
      } else if (newValue !== oldValue) {
        this.selected = newValue
      }
    }
  },

  created() {
    if (!this.range) {
      this.selected = this.value ? this.value : 0
    } else {
      this.selected = this.value ? [...this.value] : []
    }
  },

  methods: {
    getPosStyle(position, index) {
      const dom = this.$refs[`markText${index}`]
      let marginLeft = 0
      if (dom) {
        if (this.markType === 'inside') {
          if (index === 0) {
            marginLeft = 0
          } else if (index === this.markList.length - 1) {
            marginLeft = dom[0].offsetWidth
          }
        } else if (this.markType === 'center') {
          marginLeft = parseInt(dom[0].offsetWidth / 2)
        }
      }
      return { left: `${position}%`, 'margin-left': `-${marginLeft}px` }
    },

    formatTooltipFn(value) {
      const customValue = this.formatTooltip(value)
      if (customValue) {
        return customValue
      }
      const val = value ? String(value) : ''
      return val.replace(/\B(?=(\d{3})+(?!\d))/g, ',')
    },

    onInput(value) {
      this.$emit('input', value)
      this.$emit('change', value)
    },

    onChange(value) {
      this.$emit('clickChange', value)
    }
  }
}
</script>
