<template>
  <span class="tag" :class="tagType">
    <span><slot></slot></span>
    <i v-if="closed" @click="onClose"></i>
  </span>
</template>

<script>
export default {
  props: {
    tagType: {
      type: String,
      default: ''
    },
    closed: {
      type: Boolean,
      default: false
    }
  },

  methods: {
    onClose() {
      this.$emit('close')
    }
  }
}
</script>
