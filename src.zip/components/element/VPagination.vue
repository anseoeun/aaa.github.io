<template>
  <div class="pagination">
    <!-- <v-btn class="btn-prevall" :class="curPage > 1 ? 'ative' : ''" @click="goFirst">
      <span class="ir">처음</span>
    </v-btn> -->
    <v-btn class="btn-prev" :class="curPage > 1 ? 'ative' : ''" @click="goPrev">
      <span class="ir">이전</span>
    </v-btn>
    <el-pagination
      :layout="layout"
      :total="total && parseInt(total)"
      :page-size="parseInt(size)"
      :current-page.sync="curPage"
      :pager-count="pagerCount"
      @current-change="onPageChange"
    />
    <v-btn class="btn-next" :class="curPage < lastPage ? 'ative' : ''" @click="goNext">
      <span class="ir">다음</span>
    </v-btn>
    <!-- <v-btn
      v-if="total"
      class="btn-nextall"
      :class="curPage < lastPage ? 'ative' : ''"
      @click="goLast"
    >
      <span class="ir">마지막</span>
    </v-btn> -->
  </div>
</template>

<script>
import { VBtn } from '~/components/element'
export default {
  components: {
    VBtn
  },
  props: {
    layout: {
      type: String,
      default: 'pager'
    },
    page: {
      type: [Number, String],
      default: 1
    },
    pagerCount: {
      type: [Number, String],
      default: 5
    },
    size: {
      type: [Number, String],
      default: 5
    },
    total: {
      type: [Number, String],
      default: null
    }
  },
  data: function() {
    return {
      curPage: parseInt(this.page)
    }
  },
  computed: {
    lastPage() {
      return Math.floor((parseInt(this.total) - 1) / parseInt(this.size) + 1)
    }
  },
  watch: {
    /*
      동적으로 컨트롤러 할수있도록 조치 2020-03-19
    */
    page(val) {
      this.curPage = val
    }
  },
  methods: {
    onPageChange(page) {
      this.curPage = page
      this.$emit('update:page', page)
      this.$emit('page-change', page)
    },
    // goFirst() {
    //   this.onPageChange(1)
    // },
    goPrev() {
      if (this.curPage > 1) {
        this.onPageChange(this.curPage - 1)
      }
    },
    goNext() {
      if (this.curPage < this.lastPage) {
        this.onPageChange(this.curPage + 1)
      }
    },
    // goLast() {
    //   this.onPageChange(this.lastPage)
    // }
  }
}
</script>
