const asyncHandler = require('../../utils/asyncHandler')
const Https = require('../../utils/https')

// API-E-구매서비스-042 (전자서명 재전송 - 면세반출)
// API-E-구매서비스-057 (전자서명 재전송 - 계약정보)
module.exports = asyncHandler(async (req, res, next) => {
  const $https = Https({ service: 'purchase', version: 'v1', req })

  const response = await $https.post(req.path, { params: { ...req.query } }, req.body)
  res.json(response.data)
})
