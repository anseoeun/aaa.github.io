const asyncHandler = require('../../utils/asyncHandler')
const Https = require('../../utils/https')

// API-H-구매가이드서비스-009 (등록,취득세 및 공채금액 조회)
module.exports = asyncHandler(async (req, res, next) => {
  const $https = Https({ service: 'purchase-guide', version: 'v1', req })
  const response = await $https.get(req.path, { params: { ...req.query } })
  // res.json(response.data)
  console.log(response.data)
  const dummyResponse = {
    data: {
      acquisitionTax: 0,
      taxFreeFee: 0,
      govBondPayment: 200000,
      govBondDiscountPrice: 100000
    },
    rspStatus: {
      rspCode: '0000',
      rspMessage: '성공',
      uri: 'http://localhost:8095/v1/purchase-guide/registration/fees/ADJS4RAN3/P/J/1/25000000/1800/10/N?'
    }
  }
  return res.json(dummyResponse)
})
