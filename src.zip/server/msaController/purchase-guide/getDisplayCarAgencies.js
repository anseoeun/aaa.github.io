const asyncHandler = require('../../utils/asyncHandler')
const Https = require('../../utils/https')

// API-H-구매가이드서비스-004 (트림별 전시차량 보유 영업점 조회)
module.exports = asyncHandler(async (req, res, next) => {
  const $https = Https({ service: 'purchase-guide', version: 'v1', req })
  const response = await $https.get(req.path, { params: { ...req.query } })
  console.log(response.data)
  if (response.data === null || response.data.data === null || response.data.data.total === 0) {
    console.log(response.data)
    const dummyResponse = {
      data: {
        total: 79,
        list: [
          {
            agencyTypeCode: '1',
            agencyCode: 'S23',
            agencyName: '삼천포 지점',
            agencyAddress: '경상남도 사천시 주공로 104 ()(52548)',
            modelBasicInfo: '아반떼 가솔린 1.6 Style 폴라화이트',
            agencyTel: '055-832-0044'
          },
          {
            agencyTypeCode: '1',
            agencyCode: 'I28',
            agencyName: '천안북부 지점',
            agencyAddress: '충청남도 천안시 서북구 두정중7길 2-3 (현대빌딩2층 현대자동차 천안북부지점) (31101)',
            modelBasicInfo: '아반떼 가솔린 1.6 Style 폴라화이트',
            agencyTel: '041-573-3100'
          },
          {
            agencyTypeCode: '1',
            agencyCode: 'N52',
            agencyName: '포항청림 지점',
            agencyAddress: '경상북도 포항시 남구 동해안로 6067 .(37899)',
            modelBasicInfo: '아반떼 가솔린 1.6 Style 폴라화이트',
            agencyTel: '054-292-5202'
          },
          {
            agencyTypeCode: '1',
            agencyCode: 'E56',
            agencyName: '문 산 지점',
            agencyAddress: '경기도 파주시 문산읍 봉미로 53 .(10821)',
            modelBasicInfo: '아반떼 가솔린 1.6 Style 폴라화이트',
            agencyTel: '031-953-0011'
          },
          {
            agencyTypeCode: '1',
            agencyCode: 'I13',
            agencyName: '논 산 지점',
            agencyAddress: '충청남도 논산시 중앙로 279 .(32983)',
            modelBasicInfo: '아반떼 가솔린 1.6 Style 폴라화이트',
            agencyTel: '041-732-2794'
          },
          {
            agencyTypeCode: '1',
            agencyCode: 'E58',
            agencyName: '성남동부 지점',
            agencyAddress: '경기도 성남시 수정구 산성대로 223 (신흥동) 아이에스빌딩 1층  현대자동차 (13345)',
            modelBasicInfo: '아반떼 가솔린 1.6 Style 폴라화이트',
            agencyTel: '031-741-2220'
          },
          {
            agencyTypeCode: '1',
            agencyCode: 'S38',
            agencyName: '사 천 지점',
            agencyAddress: '경상남도 사천시 사천읍 옥산로 89 현대자동차(주) 사천지점 (52517)',
            modelBasicInfo: '아반떼 가솔린 1.6 Style 폴라화이트',
            agencyTel: '055-852-4301'
          },
          {
            agencyTypeCode: '1',
            agencyCode: 'S55',
            agencyName: '옥 포 지점',
            agencyAddress: '경상남도 거제시 옥포대첩로 12 .(53228)',
            modelBasicInfo: '아반떼 가솔린 1.6 Style 폴라화이트',
            agencyTel: '055-687-7944'
          },
          {
            agencyTypeCode: '1',
            agencyCode: 'L58',
            agencyName: '순천동부 지점',
            agencyAddress: '전라남도 순천시 충효로 91 현대자동차 (구:연향동 1437-1) (57991)',
            modelBasicInfo: '아반떼 가솔린 1.6 Style 폴라화이트',
            agencyTel: '061-745-5400'
          },
          {
            agencyTypeCode: '1',
            agencyCode: 'X35',
            agencyName: '문 래 지점',
            agencyAddress: '서울특별시 영등포구 영등포로 84 2층(07291)',
            modelBasicInfo: '아반떼 가솔린 1.6 Style 폴라화이트',
            agencyTel: '02-2635-6431'
          }
        ],
        pageNum: 1,
        pageSize: 10,
        size: 10,
        startRow: 1,
        endRow: 10,
        pages: 12,
        prePage: 0,
        nextPage: 2,
        isFirstPage: true,
        isLastPage: false,
        hasPreviousPage: false,
        hasNextPage: true,
        navigatePages: 8,
        navigatepageNums: [1, 2, 3, 4, 5, 6, 7, 8],
        navigateFirstPage: 1,
        navigateLastPage: 8,
        firstPage: 1,
        lastPage: 8
      },
      rspStatus: {
        rspCode: '0000',
        rspMessage: '성공',
        uri:
          'http://localhost:8095/v1/registration/display-car/agencies?saleModelCode=ADJS4RAT3&exteriorColorCode=WAW&trimCode=A&searchFilter=1&pageNo=1&pageSize=10'
      }
    }
    return res.json(dummyResponse)
  }
  res.json(response.data)
})
