const express = require('express')
const bodyParser = require('body-parser')
const app = express()
const msaController = require('./msaController')
const bffController = require('./bffController')

app.use(bodyParser.json())

app.use('/api', msaController)
app.use('/api', bffController)

app.listen(8000, () => console.log('Example app listening on port 8000!'))
