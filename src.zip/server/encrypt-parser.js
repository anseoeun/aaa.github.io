module.exports = (req, res, next) => {
  let body = []

  req.on('data', (chunk) => {
    body.push(chunk)
  })

  req.on('end', () => {
    body = Buffer.concat(body).toString()
    body = body.split('&').reduce((body, pair) => {
      if (!pair) return body
      const frg = pair.split('=')
      body[frg[0]] = frg[1]
      return body
    }, {})
    req.body = body
    next()
  })
}