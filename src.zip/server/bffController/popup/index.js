const { Router } = require('express')
const router = Router()
const multer = require('multer')
//https://github.com/expressjs/multer/blob/master/doc/README-ko.md
const upload = multer()

const postContractCancelfileUpload = require('./postContractCancelfileUpload')

// API-H-BFF-001(계약취소 파일업로드)
router.post('/contractCancelfileUpload', upload.single('file'), postContractCancelfileUpload)

module.exports = router
