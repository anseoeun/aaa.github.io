const asyncHandler = require('../../utils/asyncHandler')
const Https = require('../../utils/https')

// API-E-이벤트서비스-001 (판촉차 이벤트 리스트 조회)
async function getAttList(req, $httpsEvent) {
  try {
    const response = await $httpsEvent.get('/promotion-car', { params: { ...req.body } })
    return response
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}

module.exports = asyncHandler(async (req, res, next) => {
  const $httpsEvent = Https({ service: 'event', version: 'v1', req })
  // const $httpsCust = Https({ service: 'customer-info', version: 'v1', req })

  const [response1] = await Promise.all([getAttList(req, $httpsEvent)])

  const responses = {
    screenId: '나중에바꿀ID',
    api_e_event_001: response1.data
  }

  res.json(responses)
})
