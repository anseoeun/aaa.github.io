const asyncHandler = require('../../utils/asyncHandler')
const Https = require('../../utils/https')

// API-E-이벤트서비스-010 (판촉차 응모하기)
// API-E-이벤트서비스-011 (판촉차 응모차량 신청번호 조회)
async function postAttEntryUpdate(req, $https) {
  try {
    const response = await $https.post('/promotion-car/entry?', req.body)

    const response1 = await $https.get('/promotion-car/request-number', { params: { ...req.body } })
    return { api_e_event_010: response, api_e_event_011: response1 }
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}

module.exports = asyncHandler(async (req, res, next) => {
  const $https = Https({ service: 'event', version: 'v1', req })
  const [response1] = await Promise.all([postAttEntryUpdate(req, $https)])

  const responses = {
    screenId: '나중에바꿀ID',
    api_e_event_010: response1.api_e_event_010.data,
    api_e_event_011: response1.api_e_event_011.data
  }

  res.json(responses)
})
