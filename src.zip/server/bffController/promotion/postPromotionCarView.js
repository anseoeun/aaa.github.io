const asyncHandler = require('../../utils/asyncHandler')
const Https = require('../../utils/https')

// API-E-이벤트서비스-005 (판촉차 차량 상세 조회)
async function getPromotionCarView(req, $httpsEvent) {
  try {
    const response = await $httpsEvent.get('/promotion-car/car/info', { params: { ...req.body } })

    return response
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}

// API-E-이벤트서비스-006 (판촉차 신청 고객수 조회)
async function getAttAppCustCount(req, $httpsEvent) {
  try {
    const response = await $httpsEvent.get('/promotion-car/request/count', { params: { ...req.body } })
    return response
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}

// API-E-이벤트서비스-007 (판촉차 조회고객수 조회)
async function getAttCarViewCount(req, $httpsEvent) {
  try {
    const response = await $httpsEvent.get('/promotion-car/inquiry/count', { params: { ...req.body } })
    return response
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}

// API-E-이벤트서비스-008 (판촉차 별 재고위치(출고센터) 조회)
async function getStockList(req, $httpsEvent) {
  try {
    const response = await $httpsEvent.get('/promotion-car/delivery-center', { params: { ...req.body } })
    return response
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}

// API-E-이벤트서비스-009 (판촉차 응모 가능여부 조회)
async function getAttEntryYn(req, $httpsEvent) {
  try {
    const response = await $httpsEvent.get('/promotion-car/entry/possible-yn', { params: { ...req.body } })
    return response
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}

// API-H-상품서비스-059 (견적정보에 대한 코드명칭을 조회하는 API)
async function getProduct(listData, $httpsProduct) {
  try {
    const req = {
      carCode: '',
      saleModelCode: listData.data.saleModelCode,
      optionMixCode: listData.data.optionMixGoodsNo ? listData.data.optionMixGoodsNo : '',
      exteriorColorCode: listData.data.exteriorColorCode ? listData.data.exteriorColorCode : '',
      interiorColorCode: listData.data.interiorColorCode ? listData.data.interiorColorCode : '',
      realityInteriorColorCode: listData.data.realityInteriorColorCode ? listData.data.realityInteriorColorCode : '',
      tuixMixCode: listData.data.tuixOptionCode ? listData.data.tuixOptionCode : '',
      saleTypeCode: ''
    }

    const response = await $httpsProduct.get('/estimation-info-name', { params: { ...req } })
    return response
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}

// API-H-상품서비스-079 (차량 트림 제원 정보 조회)
async function getCarTrimSpeInfo(listData, $httpsEvent) {
  try {
    const response = await $httpsEvent.get(`/car/trim-variousfactor/${listData.data.saleModelCode}`)
    return response
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}

// API-E-이벤트서비스-011 (판촉차 응모차량 신청번호 조회)
async function getAttEntryNoList(req, $httpsEvent) {
  try {
    const response = await $httpsEvent.get('/promotion-car/request-number', { params: { ...req.body } })
    return response
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}

// API-E-이벤트서비스-012 (판촉차 이벤트 당첨자 발표일시 정보 조회)
async function getAttEventDate(req, $httpsEvent) {
  try {
    const response = await $httpsEvent.get('/promotion-car/announcement-date', { params: { ...req.body } })
    return response
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}

// API-E-이벤트서비스-014 (할인사유 및 판촉차 정보 조회)
async function getDisCountAttList(req, $httpsEvent) {
  try {
    const response = await $httpsEvent.get('/promotion-car/info', { params: { ...req.body } })
    return response
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}

// API-E-이벤트서비스-022 (판촉차 인기태그 여부 조회)
async function getAttTagYn(req, $httpsEvent) {
  try {
    const response = await $httpsEvent.get('/promotion-car/popularity-tag', { params: { ...req.body } })
    return response
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}

module.exports = asyncHandler(async (req, res, next) => {
  const $httpsEvent = Https({ service: 'event', version: 'v1', req })
  const $httpsProduct = Https({ service: 'product', version: 'v1', req })

  const [
    response1,
    response2,
    response3,
    response4,
    response5,
    response6,
    response7,
    response8,
    response9
  ] = await Promise.all([
    getPromotionCarView(req, $httpsEvent),
    getAttAppCustCount(req, $httpsEvent),
    getAttCarViewCount(req, $httpsEvent),
    getStockList(req, $httpsEvent),
    getAttEntryYn(req, $httpsEvent),
    getAttEntryNoList(req, $httpsEvent),
    getAttEventDate(req, $httpsEvent),
    getDisCountAttList(req, $httpsEvent),
    getAttTagYn(req, $httpsEvent)
  ])

  const [response10, response11] = await Promise.all([
    getProduct(response1.data, $httpsProduct),
    getCarTrimSpeInfo(response1.data, $httpsProduct)
  ])

  const responses = {
    screenId: '나중에바꿀ID',
    api_e_event_005: response1.data,
    api_e_event_006: response2.data,
    api_e_event_007: response3.data,
    api_e_event_008: response4.data,
    api_e_event_009: response5.data,
    api_e_event_011: response6.data,
    api_e_event_012: response7.data,
    api_e_event_014: response8.data,
    api_e_event_022: response9.data,
    api_h_product_059: response10.data,
    api_h_product_079: response11.data
  }

  res.json(responses)
})
