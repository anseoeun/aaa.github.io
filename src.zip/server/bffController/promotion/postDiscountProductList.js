const asyncHandler = require('../../utils/asyncHandler')
const Https = require('../../utils/https')

// API-E-상품서비스-006 (할인재고차량 조건검색 리스트 정보 조회)
async function getDiscountProductList(req, $https) {
  try {
    const response = await $https.get('/discount-car/search/cars', { params: { ...req.body } })

    return response.data
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}

// API-H-제휴서비스-005 (탁송료 및 출고센터 조회)
async function getAreaConsignmentList(list, req, $httpsDelAll, $https) {
  try {
    const _list = { ...list }
    _list.query = {
      saleModelCode: list.saleModelCode ? list.saleModelCode : '',
      deliveryAreaCode: req.body.deliveryAreaCode ? req.body.deliveryAreaCode : '',
      deliveryLocalAreaCode: req.body.deliveryLocalAreaCode ? req.body.deliveryLocalAreaCode : '',
      optionCode: list.optionMixCode ? list.optionMixCode : '',
      deliveryCenterCode: list.deliveryCenterCode ? list.deliveryCenterCode : ''
    }
    const response = await $httpsDelAll.get('/consignment-price', { params: { ..._list.query } })
    const response2 = await getEstimationInfoName(list, $https)
    return { api_e_product_006: list, api_h_alliance_002: response.data, api_h_custinfo_059: response2.data }
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}

// API-H-상품서비스-059 (견적정보에 대한 코드명칭을 조회하는 API)
async function getEstimationInfoName(req, $httpsEvent) {
  try {
    const _req = { ...req }
    _req.query = {
      carCode: req.carCode ? req.carCode : '',
      saleModelCode: req.saleModelCode ? req.saleModelCode : '',
      optionMixCode: req.optionMixCode ? req.optionMixCode : '',
      exteriorColorCode: req.exteriorColorCode ? req.exteriorColorCode : '',
      interiorColorCode: req.interiorColorCode ? req.interiorColorCode : '',
      tuixMixCode: req.tuixMixCode ? req.tuixMixCode : '',
      saleTypeCode: req.saleTypeCode ? req.saleTypeCode : '',
      realityInteriorColorCode: req.realityInteriorColorCode ? req.realityInteriorColorCode : ''
    }

    const response = await $httpsEvent.get('/estimation-info-name', { params: { ..._req.query } })
    return response
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}

function fnIterator(param) {
  var obj = {
    items: [],
    get getItems() {
      return this.items
    },
    set setItems(arr) {
      this.items = arr
    },
    *[Symbol.iterator]() {
      for (const item of this.items) {
        yield item
      }
    }
  }
  if (param) {
    obj.setItems = param
  }
  return obj
}

module.exports = asyncHandler(async (req, res, next) => {
  const $https = Https({ service: 'product', version: 'v1', req })
  const $httpsDelAll = Https({ service: 'delivery^alliance', version: 'v1', req })

  const response1 = await getDiscountProductList(req, $https)
  let api_h_alliance_002 = [],
    api_e_product_list_006 = []

  if (response1.data) {
    let api_e_product_006 = fnIterator(response1.data.discountsearchcars)
    for (let list of api_e_product_006.getItems) {
      api_h_alliance_002.push(getAreaConsignmentList(list, req, $httpsDelAll, $https))
    }
    const response2 = await Promise.all(api_h_alliance_002)
    for (let list of response2) {
      if (list.api_h_alliance_002 && list.api_h_custinfo_059) {
        api_e_product_list_006.push({
          api_e_product_006: list.api_e_product_006,
          api_h_custinfo_list_059: list.api_h_custinfo_059,
          api_h_alliance_list_002: list.api_h_alliance_002.data,
          totalCount: response1.data.totalCount
        })
      }
    }
  }

  const responses = {
    screenId: '나중에바꿀ID',
    api_e_product_006: api_e_product_list_006
  }

  res.json(responses)
})
