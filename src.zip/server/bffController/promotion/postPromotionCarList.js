const asyncHandler = require('../../utils/asyncHandler')
const Https = require('../../utils/https')

// API-E-이벤트서비스-004 (판촉차 검색 정보 조회)
async function getAttCarModelList(req, $https) {
  try {
    const response = await $https.get('/promotion-car/search', { params: { ...req.body } })
    return response
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}

// API-H-상품서비스-059 (견적정보에 대한 코드명칭을 조회하는 API)
async function getEstimationInfoName(list, req, $httpsProduct) {
  const _req = { ...req }
  _req.body = {
    carCode: '',
    saleModelCode: list.saleModelCode ? list.saleModelCode : '',
    exteriorColorCode: list.exteriorColorCode ? list.exteriorColorCode : '',
    interiorColorCode: list.interiorColorCode ? list.interiorColorCode : '',
    realityInteriorColorCode: list.realityInteriorColorCode ? list.realityInteriorColorCode : '',
    tuixMixCode: list.tuixOptionCode ? list.tuixOptionCode : '',
    optionMixCode: list.optionMixGoodsNo ? list.optionMixGoodsNo : '',
    saleTypeCode: ''
  }
  let response = await $httpsProduct.get('/estimation-info-name', { params: { ..._req.body } })

  return { api_e_event_004: list, api_h_prod_059: response }
}

function fnIterator(param) {
  var obj = {
    items: [],
    get getItems() {
      return this.items
    },
    set setItems(arr) {
      this.items = arr
    },
    *[Symbol.iterator]() {
      for (const item of this.items) {
        yield item
      }
    }
  }
  if (param) {
    obj.setItems = param
  }
  return obj
}

module.exports = asyncHandler(async (req, res, next) => {
  const $https = Https({ service: 'event', version: 'v1', req })
  const $httpsProduct = Https({ service: 'product', version: 'v1', req })

  const response = await getAttCarModelList(req, $https)

  let api_e_event_list_004 = [],
    api_e_event_list = []

  if (response.data) {
    let api_e_event_004 = fnIterator(response.data.data.list)

    for (let list of api_e_event_004.getItems) {
      api_e_event_list_004.push(getEstimationInfoName(list, req, $httpsProduct))
    }
    const response2 = await Promise.all(api_e_event_list_004)

    for (let list of response2) {
      if (list.api_e_event_004 && list.api_h_prod_059) {
        api_e_event_list.push({
          api_e_event_004: list.api_e_event_004,
          api_h_prod_059: list.api_h_prod_059.data
        })
      }
    }
  }

  const responses = {
    screenId: '나중에바꿀ID',
    api_e_event_list: api_e_event_list,
    totalCount: response.data.data.total || '0'
  }

  res.json(responses)
})
