const asyncHandler = require('../../utils/asyncHandler')
const Https = require('../../utils/https')

// API-E-이벤트서비스-003 (판촉차 차종구분별 모델리스트 조회)
async function postAttModelList(req, $httpsEvent) {
  try {
    const response1 = await $httpsEvent.get('/promotion-car/type/cars', { params: { ...req.body } })

    return response1
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}

// API-H-고객지원서비스-014 (출고센터 조회)
async function getRelCenterList(req, $httpsCustomer) {
  try {
    const response1 = await $httpsCustomer.get('/delivery-center')

    return { api_h_cust_014: response1 }
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}

module.exports = asyncHandler(async (req, res, next) => {
  const $httpsEvent = Https({ service: 'event', version: 'v1', req })
  const $httpsCustomer = Https({ service: 'purchase-guide^customer-support', version: 'v1', req })

  const [response, response1] = await Promise.all([
    postAttModelList(req, $httpsEvent),
    getRelCenterList(req, $httpsCustomer)
  ])
  const responses = {
    screenId: '나중에바꿀ID',
    api_e_event_003: response.data,
    api_h_cust_014: response1.api_h_cust_014.data
  }
  res.json(responses)
})
