const asyncHandler = require('../../utils/asyncHandler')
const Https = require('../../utils/https')

// API-E-상품서비스-003 (할인차량 엔진리스트)
async function getDiscountEngineList(req, $https) {
  try {
    const _req = { ...req }
    _req.query = {
      carTypeCode: req.body.carTypeCode,
      carCode: req.body.carCode,
      criterionYearMonth: req.body.criterionYearMonth,
      displayCarYn: req.body.displayCarYn
    }
    const response = await $https.get('/discount-car/engins', { params: { ..._req.query } })
    return response
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}

// API-E-상품서비스-004 (할인차량 미션리스트 정보 조회)
async function getDiscountMissionList(req, $https) {
  try {
    const _req = { ...req }
    _req.query = {
      carCode: req.body.carCode,
      criterionYearMonth: req.body.criterionYearMonth,
      displayCarYn: req.body.displayCarYn,
      carTypeCode: req.body.carTypeCode
    }

    const response = await $https.get('/discount-car/missions', { params: { ..._req.query } })

    return response
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}

//API-E-상품서비스-005 (할인차량 외장컬러 리스트 정보 조회)
async function getDiscountExteriorList(req, $https) {
  try {
    const _req = { ...req }
    _req.query = {
      carCode: req.body.carCode,
      carYear: req.body.criterionYearMonth ? req.body.criterionYearMonth.substr(0, 4) : '',
      displayCarYn: req.body.displayCarYn,
      carTypeCode: req.body.carTypeCode
    }

    const response = await $https.get('/discount-car/exterior-color', { params: { ..._req.query } })

    return response
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}

// API-E-상품서비스-038 (할인차량 트림리스트 조회)
async function getDiscountTrimList(req, $https) {
  try {
    const _req = { ...req }
    _req.query = {
      carCode: req.body.carCode,
      carTypeCode: req.body.carTypeCode,
      criterionYearMonth: req.body.criterionYearMonth,
      displayCarYn: req.body.displayCarYn
    }

    const response = await $https.get('/discount-car/trims', { params: { ..._req.query } })

    return response
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}

module.exports = asyncHandler(async (req, res, next) => {
  const $https = Https({ service: 'product', version: 'v1', req })
  const [response1, response2, response3, response4] = await Promise.all([
    getDiscountEngineList(req, $https),
    getDiscountMissionList(req, $https),
    getDiscountExteriorList(req, $https),
    getDiscountTrimList(req, $https)
  ])

  const responses = {
    screenId: '나중에바꿀ID',
    api_e_discount_003: response1.data,
    api_e_discount_004: response2.data,
    api_e_discount_005: response3.data,
    api_e_discount_038: response4.data
  }

  res.json(responses)
})
