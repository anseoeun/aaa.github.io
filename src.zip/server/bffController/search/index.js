const { Router } = require('express')
const router = Router()

const getSearch = require('./getSearch')
const getBestKeyword = require('./getBestKeyword')
const getAutoKeyword = require('./getAutoKeyword')

// EP_IF_통합검색_003
router.get('/search/search', getSearch)
// EP_IF_통합검색_001 인기검색어
router.get('/search/sla/sla_trans', getBestKeyword)
// EP_IF_통합검색_002 자동완성
router.get('/search/ark/ark_trans', getAutoKeyword)
module.exports = router
