const { Router } = require('express')
const router = Router()

const postDeliveryCarView = require('./postDeliveryCarView')

// API-P-BFF-015(즉시출고 차량 상세 조회)
router.post('/postDeliveryCarView', postDeliveryCarView)

module.exports = router
