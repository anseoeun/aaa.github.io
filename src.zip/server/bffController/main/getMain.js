const asyncHandler = require('../../utils/asyncHandler')
const Https = require('../../utils/https')
//
const allHttp = {} // $https  객체들을 관리합니다

//-------------------------------------------------------------------------
//-------------------------------------------------------------------------
/*   MSA API 용 https 객체를 취득합니다.
     - 한번 만 취득하도록합니다
*/
function findApiHttps(req, allHttp, httpId, httpVer) {
  const axiosObj = Https({ service: httpId, version: httpVer, req: req })
  allHttp[httpId] = axiosObj
  return allHttp[httpId]
}
/*  
  설정값을 해석해서 API를 호출합니다
  인자 : isShowLog : 디버그용 로그를 콘솔에 표시할지 여부
 */
async function call_api(req, myConfig, isShowLog) {
  //

  if (myConfig == undefined) {
    await {
      then: (resolve) => {
        resolve('dummy')
      }
    }
    return
  }

  //

  // path_param 값 존재시 조립합니다
  if (myConfig.pathParam !== undefined && myConfig.pathParam != null) {
    myConfig.url = myConfig.url + '/' + myConfig.pathParam //   url을 조립합니다
  } //
  //-- https 객체를 구합니다
  let $https = findApiHttps(req, allHttp, ...myConfig.httpsId) // 통신객체 체크 및 생성
  //-- api 를 호출하고 리턴값을 저장합니다
  try {
    if (isShowLog) {
      console.log('[server>bff>main>call_api ] API 호출 전, myConfig >> ' + global.JSON.stringify(myConfig, null, 2))
    }

    const response = await $https.request(myConfig) // 기본 자료를 읽어 들입니다.
    /*  혹시, 추가 상세자료를 위한 API호출이 필요하면, 수행합니다.
     */
    if (myConfig.childApi) {
      //
      let list = response.data.data // 부모자료 추출( 이 경우, 항상 배열 구조여야함)
      let childConfig_list = myConfig.childApi // 자식호출 구조 - 배열
      //
      for (const idx in list) {
        // 부모자료 배열에 근거하여 각각의 상세자료를 호출합니다
        const respItem = list[idx] // 부모자료 한건 추출
        //
        for (const idx1 in childConfig_list) {
          //
          const childConfig = childConfig_list[idx1] // 자식호출용 설정값을 취득합니다
          //----- 통신용 axios 객체를 취득합니다 -----
          $https = findApiHttps(req, allHttp, ...childConfig.httpsId) // 통신객체 체크 및 생성
          //----- 자식 호출용, 인자를 조립합니다 -----
          if (childConfig.pathParamId) {
            //-- url path 에 인자값 첨부시.
            const pathParam = respItem[childConfig.pathParamId] // 인자를 부모호출 결과값에서 추출함
            childConfig.url = childConfig.urlPrefix + '/' + pathParam // 자식용 url을 조립합니다
          } else if (childConfig.paramsId) {
            //-- url path 에 인자값 첨부시.

            //네임 스페이스 맞추는 작업
            let [paramName, paramData] = childConfig.paramsId.split('^')
            paramName = paramName ? paramName : childConfig.paramsId
            paramData = paramData ? paramData : childConfig.paramsId

            const paramsVal = respItem[paramData] // 인자를 부모호출 결과값에서 추출함
            if (childConfig.params === undefined || childConfig.params == null) {
              childConfig.params = {}
            }
            childConfig.params[paramName] = paramsVal // 인자를 부모호출 결과값에서 추출함
          }
          //
          let childName = 'childData'
          if (childConfig.name) {
            childName = childConfig.name
          }
          //------- 자식 API 를 호출합니다 -------
          try {
            const childResponse = await $https.request(childConfig) // 상세API 호출하기

            //--- 결과 살정하기 ---
            if (childResponse && childResponse.data && childResponse.data.data) {
              respItem[childName] = childResponse.data.data // 각 부모 항목에 상세자료를 추가합니다
            } else {
              respItem[childName] = {}
            }
          } catch (err) {
            respItem[childName] = {
              message: err.message,
              config: err.config
            }
          }
        } // -- end of for loop --
      }
    }
    /*
     */
    return response.data
    //
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}


async function call_child_api (req, childApi, carCode) { // 차종라인업 용 child api 
  const response = {}
  let childConfig_list = childApi // 자식호출 구조 - 배열

  const childConfig = childConfig_list[0] // 자식호출용 설정값을 취득합니다

  $https = findApiHttps(req, allHttp, ...childConfig.httpsId) // 통신객체 체크 및 생성
  const pathParam = carCode // pathParamId
  childConfig.url = childConfig.urlPrefix + '/' + pathParam // 자식용 url을 조립합니다

  let childName = 'childData'
  if (childConfig.name) {
    childName = childConfig.name
  }

    //------- 자식 API 를 호출합니다 -------
  try {
    const childResponse = await $https.request(childConfig) // 상세 API 호출하기
      
    //--- 결과 설정하기 ---
    if (childResponse && childResponse.data && childResponse.data.data) {
      response[childName] = childResponse.data.data // 부모 항목에 상세자료를 추가합니다
    } else {
      response[childName] = {}
    }
  } catch (err) {
    response[childName] = {
      message: err.message,
      config: err.config
    }
  }

  return response[childName]
}
/* ----- 설정 객체 목록을 조립합니다 -----
    1.  httpsId: ['common','v1'],  // https 생성문자열
    2.  url: '/banners',// 호출경로
    3.  method:'get',   // 호출방법
    4.  pathParam: '',  // url_인자
    5.  pathParamId: '' // 자식일 경우 부모 결과값 목록에서 취득합니다
    *.  urlPrefix : ''  // pathParam 이 존재하는 URL 정보입니다.
    6.  params: {},     // 인자값
    7.  paramsId: ''    // 자식일 경우 부모 결과값 목록에서 취득합니다
    8.  data: {},       // post용 body
    9.  headers:{}      //
    9.  child > name:{}  // 자식일 경우 부모 결과값 목록에 표시하는 프로퍼티명
*/
function makeAllConfig(req) {
  const params = req.query
  let allConfig = {}

  allConfig = {
    dummy: {},
    banners: {
      httpsId: ['common', 'v1'], // 1-배너리스트조회
      url: '/banners',
      params: { siteTypeCode: 'E' }
    },
    employeeInfo: {
      httpsId: ['domestic', ''], // 2-임직원 회원정보
      url: '/sale/Eco',
      params: { actionName: 'ListCnttWork', cmd: 'R004' },
      data: { EENO: params.eeno, BIR_YYMMDD: params.birthDate }
    },
    contracts: {
      httpsId: ['purchase', 'v1'], // 3-개인화-계약목록(상세포함)
      url: '/contract/my-contract/info' // E-구매-076 -- 나의계약 진행정보
    },
    contract_detail: {
      httpsId: ['purchase', 'v1'], // 3-개인화-계약-계약상세
      url: '/contract/contract-info/', // E-구매-076 -- 나의계약 진행정보
      pathParam: 'A3719DN000140' //  'contractNumber' // url_인자
    },
    contract_process: {
      httpsId: ['purchase', 'v1'], // 3-개인화-계약-진행단계(Process)
      url: '/process', // E-구매-076 -- 나의계약 진행정보
      paramsId: 'contractNumber'
    },
    benefits: {
      // GET, API-H-고객지원서비스-006, 이달의 구매혜택 리스트
      httpsId: ['customer-support', 'v1'],
      url: '/common/benefit/cars',
      params: { imageSectionCode: '02' }
    },
    salesTop3: {
      // API-E-구매서비스-090 (임직원 TOP3)
      httpsId: ['purchase', 'v1'],
      url: '/contract/employee-top3'
    },
    homePageTop3: {
      // GET, API-H-고객정보서비스-011, 연령대별 판매TOP3차량리스트
      httpsId: ['personalization', 'v1'],
      url: '/recommendation/top3-cars',
      params: { imageSectionCode: '02', ageType: '0' } // 02: 차량이미지45도 ageType: 0은 전체
    },
    // ------- 차량 목록 ------
    typePurposeCars: {
      httpsId: ['product', 'v1'],
      url: '/car/type/purpose', // GET, API-H-상품서비스-004, 차종,용도별 차량리스트
      params: { carTypeCode: '', carPurposeCode: '', imageSectionCode: '01', siteTypeCode: 'E', menuTypeCode: '' },
      childApi: [
        {
          // GET, API-H-상품서비스-022, 차량별 차량상세조회
          name: 'detail',
          httpsId: ['product', 'v1'],
          urlPrefix: '/car',
          pathParamId: 'carCode',
          // paramsId: 'saleModelCode', // 부모결과값의 배열객체에서 값을 꺼냅니다.
          params: { customerNumber: params.customerNumber, imageSectionCode: '01' } // ((무관한듯)) FIXME : 실데이터연결필요(customerNumber, 로그인 ID)
        }
      ]
    },
    currBestCars: {
      // GET, API-E-상품서비스-002, 실시간 베스트 리스트(할인재고차량,전시차량)
      httpsId: ['product', 'v1'],
      url: '/discount-car/best'
    },
    eventCars: {
      // GET, API-E-이벤트서비스-001, 판촉차 이벤트 리스트
      httpsId: ['event', 'v1'],
      url: '/promotion-car',
      params: { customerNumber: params.customerNumber } // FIXME : 실데이터연결필요
    },
    faqTop5: {
      // GET, API-H-고객지원서비스-001, 자주하는질문 TOP5 리스트 조회
      httpsId: ['customer-support', 'v1'],
      url: '/faq/top5',
      params: { systemTypeCode: 'H' } // TODO : 'H", 'E' 설정확인필요
    },
    promotionCurCar: {
      httpsId: ['event', 'v1'],
      url: '/promotion-car/current/cars', // GET, API-E-이벤트서비스-023 (판촉차 이달의 구매 혜택 조회)
      childApi: [
        {
          // API-E-이벤트서비스-004 (판촉차 검색 정보 조회) 페이징처리가 되어있으므로 임시로 사이즈 1000으로 고정셋팅(1000건을 넘을수가없음)
          name: 'promotionDetail',
          httpsId: ['event', 'v1'],
          url: '/promotion-car/search',
          paramsId: 'salePromotionEventNumber^promotionEventNo',
          params: {
            deliveryCenterCode: '',
            discountAmount: '',
            orderType: '',
            repnCarCode: '',
            pageNo: 1,
            pageSize: 1000
          }
        }
      ]
    }
  }
  // }
  //
  return allConfig
}
// ---------------------------------------------------------------------------------------------------
//  일반 함수들
// ---------------------------------------------------------------------------------------------------
// ------ 사용안함 ------   -> 사용 중 
async function fnGetPurposeCars(req, carTypeCode, imageSectionCode) {
  const allConfig = {
    // ------- (차량 라인업)차량 목록:API-H-상품서비스-002, 차종별 차량 리스트 조회 ------
    // 홈페이지에서 불러오는 api와 동일하게 맞춤 
    getPurposeCars: {
      httpsId: ['product', 'v1'],
      url: '/car/type/cars',
      params: {
        // carTypeCode: carTypeCode,
        // carPurposeCode: 'J',
        imageSectionCode: imageSectionCode,
        siteTypeCode: 'E',
        menuTypeCode: 'G'
      },
    }
  }
  const [res] = await Promise.all([
    call_api(req, allConfig.getPurposeCars, false) // true : show_log, false : no_log
  ])
  
  return res
}

// ---------------------------------------------------------------------------------------------------
// -- 메인 화면의 하단부 데이터를 호출합니다
async function fnGetMainCarsInfo(req, res, next) {
  const allConfig = {
    // ------- (로그인)차량 목록:API-H-상품서비스-066, 관심차량별 차종 리스트 ------> API-H-상품서비스-002
    getPurposeCars: { // -> 사용 안 하는 듯 
      httpsId: ['product', 'v1'],
      url: '/car/type/cars',
      params: {
        // carTypeCode: '', // 공란:모든타입차
        // carPurposeCode: 'J',
        imageSectionCode: '01', // imageSectionCode:01:정면이미지
        siteTypeCode: 'E',
        menuTypeCode: 'G'
      },
      childApi: [
        {
          // GET, API-H-상품서비스-022, 차량별 차량상세조회
          name: 'detail',
          httpsId: ['product', 'v1'],
          urlPrefix: '/car',
          pathParamId: 'carCode',
          params: { imageSectionCode: '02' } // ((무관한듯)) FIXME : 실데이터연결필요(customerNumber, 로그인 ID)
        }
      ]
    },
    currBestCars: {
      // GET, API-E-상품서비스-002, 실시간 베스트 리스트(할인재고차량,전시차량)
      httpsId: ['product', 'v1'],
      url: '/discount-car/best'
    }
  }
  const [
    best_cars
  ] = await Promise.all([
    call_api(req, allConfig.currBestCars, false) // true : show_log, false : no_log
  ])

  const response = {
    best_cars
  }

  res.json(response)
}
// ---------------------------------------------------------------------------------------------------
async function fnGetContractDetail(req, res, next) {
  const response = await readContractDetail(req, req.query.contractNumber, req.query.customerManagementNumber)

  res.json(response)
}
// ---------------------------------------------------------------------------------------------------
async function readContractDetail(req, contractNumber, customerManagementNumber) {
  const allConfig = {
    contract_detail: {
      httpsId: ['purchase', 'v1'], // 3-개인화-계약목록(상세포함)
      url: '/contract/contract-info/', // E-구매-009 -- 나의계약 진행정보
      pathParam: contractNumber // 'A3719DN000140' //  'contractNumber' // url_인자
    },
    check_virtual_account: {
      httpsId: ['purchase', 'v1'], // API-E-구매서비스-085 (현금입금대기중 건수조회) 
      url: '/contract/countercheck/virtual-account/state', // E-구매-009 -- 나의계약 진행정보
      params: {
        saleContractNumber: contractNumber, // saleContractNumber
        customerManagemontNumber: customerManagementNumber // 고객관리번호 (스펠링 차이에 유의하시오)
      }
    },
    //----- 계약상세로 가기위한 동의 정보를 추출합니다 ------
    agreement_info: {
      httpsId: ['purchase', 'v1'], // 3-개인화-계약-진행단계(Process)
      url: '/contract/agreement-info', // API-E-구매서비스-030 (동의 정보 조회)
      params: {
        contractNumber: contractNumber, //
        needPapersNumber: 'AGR00007', // 필요서류번호
        papersFormAttributeNumber: 'AGR000070100001', // 서류폼속성번호
        formAttributeTypeSerialNumber: '1' // 폼속성항목일련번호
      }
    }
  }

  const [contract_detail, agreement_info] = await Promise.all([
    call_api(req, allConfig.contract_detail, false), // false:no_log
    call_api(req, allConfig.agreement_info, false) // false:no_log
  ])
  //--- 현금입금 계좌 여부 확인하기 --
  const [check_virtual_account] = await Promise.all([
    call_api(req, allConfig.check_virtual_account, false) // false:no_log
  ])

  const response = {
    contract_detail,
    check_virtual_account,
    agreement_info
  }

  return response
}
// ---------------------------------------------------------------------------------------------------
//  module Export 들
// ---------------------------------------------------------------------------------------------------
module.exports = {
  getMain: asyncHandler(async (req, res, next) => {
    const allConfig = makeAllConfig(req)
    const [
      dummy,
      banners, // API-H-공통서비스-003
      employeeInfo,
      contracts,
      benefits,
      salesTop3,
      homePageTop3,
      promotionCurCar
    ] = await Promise.all([
      call_api(req),
      call_api(req, allConfig.banners),
      call_api(req, allConfig.employeeInfo),
      call_api(req, allConfig.contracts),
      call_api(req, allConfig.benefits),
      call_api(req, allConfig.salesTop3),
      call_api(req, allConfig.homePageTop3),
      call_api(req, allConfig.promotionCurCar) //판촉차 리스트
    ])

    // ---------------------------------------------------------
    // ------------- 초기에 읽음, 계약상세 1 건 ------------------
    // ---------------------------------------------------------
    let contract_detail = {}

    if (contracts && contracts.data && contracts.data.length > 0) {
      const response = await readContractDetail(
        req,
        contracts.data[0].contractNumber,
        req.query.customerManagementNumber
      )
      contract_detail = response
    }

    // ---------------------------------------------------------
    // ----------- 관심 차종 라인업 (초기에 읽음) -------------
    // ---------------------------------------------------------
    const tabList = ['P', 'R', 'S', 'E', 'N', 'G']
    const carLineUp = {} // 차종별 배열들

    for (const carType of tabList) {
      carLineUp[carType] = [] // 타입별 배열 초기화
    }
    const childApi = [
      {
        // GET, API-H-상품서비스-022, 차량별 차량상세조회
        name: 'detail',
        httpsId: ['product', 'v1'],
        urlPrefix: '/car',
        pathParamId: 'carCode',
        params: { imageSectionCode: '02' } 
      }
    ]

    const allPurposeCars = await fnGetPurposeCars(req, '', '01')
    if (allPurposeCars && allPurposeCars.data) {
      for (const item of allPurposeCars.data) {
        for(let i = 0; i < item.list.length; i++){ // list 만큼 돌면서 childApi 각각 붙이기 
          const[value] = await Promise.all ([
            call_child_api(req, childApi, item.list[i].carCode) // 차종 라인업을 위해 만든 child api 
          ])
          item.list[i].detail = value // 기존 객체에 추가 
          carLineUp[item.list[i].carTypeCode].push(item.list[i]) // 타입별로 배열에 누적합니다.
        }
      }
    }

    const response = {
      screenId: 'UI_M_일반_메인_C1200',
      dummy,
      banners,
      employeeInfo, // 임직원회원정보
      contract_detail, // 개인화 (최초에 1 건 읽음)
      contracts, // 개인화
      benefits, // 개인화
      salesTop3,
      homePageTop3,
      typePurposeCars: carLineUp,
      promotionCurCar //판촉차 리스트
    }

    res.json(response)
  }), //--- end of getMain ---
  //------- 차량 목록/할인차베스트목록 보를 호출합니다 -------
  getMainCarsInfo: fnGetMainCarsInfo,
  //------- 계약 한건에 대한 상세정보를 호출합니다 -------
  getContractDetail: fnGetContractDetail,
  getPurposeCars: () => { } // NOT_USED
}
