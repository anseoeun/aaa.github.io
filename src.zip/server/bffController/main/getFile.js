const asyncHandler = require('../../utils/asyncHandler')
const Https = require('../../utils/https')

//--- 바이너리 모드로 파일을 다운로드 받습니다
const getFileDownload =  async (req, res, next) => {
  const $https = Https({ service: 'common', version: 'v1', req })
  //
  const myConfig = {
    url: req.path, 
    method:'get',
    responseType: 'arraybuffer',
    headers: { 'user-agent': req.headers['user-agent'] } // 브라우저의 userAGent 정보를 강제로 설정해서 보냅니다
  }
  try {
    const recv_res = await $https.request( myConfig)
    //-- 헤더복사 --
    for(const key1 in recv_res.headers ){
      res.set( key1, recv_res.headers[key1])
    }

    if( !recv_res.headers['content-length'] || '0' === recv_res.headers['content-length'] || !recv_res.data){
      console.log('[getFileDownload] send 404 .......')

      return null
    }
    console.log('getNotice.js ---- getFileDownload------')
    return recv_res.data
    //
  } catch (err) {
    console.log('[call_api] -outer error-')
    return { }
  }
}
//------------------------------------------------------------
module.exports = {
  getFileDownload: asyncHandler(async (req, res, next) => {
    const res_data = await getFileDownload(req, res, next) 
    /*
       바이너리 데이터를 전송합니다
    */
    if( res_data){
      res.send( res_data )
    } else {
      res.status(404).end() // 404 시스템 메시지 보이기
    }
  })
}