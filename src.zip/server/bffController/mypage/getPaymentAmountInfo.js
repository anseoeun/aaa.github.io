const asyncHandler = require('../../utils/asyncHandler')
const Https = require('../../utils/https')

// 계약금액
async function getPaymentAmountInfo(req, $httpsMsaPayment, $httpsMsaPurchase, $httpsMsaProduct) {
  const { saleContractNo } = req.query

  try {
    // API-E-결제서비스-003 (차량대금 결제정보 조회)
    const api_e_payment_003 = await $httpsMsaPayment.get('/payment-amount/info', {
      params: {
        saleContractNo
      }
    })

    // API-E-구매서비스-009 계약정보 조회
    const api_e_purchase_009 = await $httpsMsaPurchase.get('/contract/contract-info/' + saleContractNo)

    let {
      carCode,
      saleModelCode,
      optionMixCode,
      exteriorColorCode,
      interiorColorCode,
      tuixOptionCode,
      saleTypeCode,
      realityInteriorColorCode
    } = api_e_purchase_009.data.data

    const params = {
      carCode: !carCode ? '' : carCode,
      saleModelCode: !saleModelCode ? '' : saleModelCode,
      optionMixCode: !optionMixCode ? '' : optionMixCode,
      exteriorColorCode: !exteriorColorCode ? '' : exteriorColorCode,
      interiorColorCode: !interiorColorCode ? '' : interiorColorCode,
      tuixMixCode: !tuixOptionCode ? '' : tuixOptionCode,
      saleTypeCode: !saleTypeCode ? '' : saleTypeCode,
      realityInteriorColorCode: !realityInteriorColorCode ? '' : realityInteriorColorCode
    }

    // API-H-상품서비스-059 (견적정보에 대한 코드명칭을 조회하는 API)
    const api_e_product_059 = await $httpsMsaProduct.get('/estimation-info-name', {
      params
    })

    const result = {
      api_e_payment_003: api_e_payment_003.data,
      api_e_purchase_009: api_e_purchase_009.data,
      api_e_product_059: api_e_product_059.data
    }

    return result
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}

module.exports = asyncHandler(async (req, res, next) => {
  const $httpsMsaPayment = Https({ service: 'payment', version: 'v1', req })
  const $httpsMsaPurchase = Https({ service: 'purchase', version: 'v1', req })
  const $httpsMsaProduct = Https({ service: 'product', version: 'v1', req })

  const [response1] = await Promise.all([
    getPaymentAmountInfo(req, $httpsMsaPayment, $httpsMsaPurchase, $httpsMsaProduct)
  ])

  const response = {
    screenId: 'UI_M_마이_결제_C6100A',
    data: response1
  }

  res.json(response)
})
