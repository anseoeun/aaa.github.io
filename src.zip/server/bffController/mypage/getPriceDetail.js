const asyncHandler = require('../../utils/asyncHandler')
const Https = require('../../utils/https')

// 계약금액
async function getPriceDetail(req, $httpsMsaPayment, $httpsMsaPurchase) {
  const { saleContractNo } = req.query

  try {
    // API-E-구매서비스-009 계약정보 조회
    const api_e_purchase_009 = await $httpsMsaPurchase.get('/contract/contract-info/' + saleContractNo)

    let {
      saleModelCode,
      optionMixCode,
      exteriorColorCode,
      interiorColorCode,
      tuixOptionCode,
      taxationTypeCode
    } = api_e_purchase_009.data.data

    const params = {
      contractNumber : saleContractNo ,
      saleModelCode: !saleModelCode ? '' : saleModelCode,
      optionMixCode: !optionMixCode ? '' : optionMixCode,
      exteriorColorCode: !exteriorColorCode ? '' : exteriorColorCode,
      interiorColorCode: !interiorColorCode ? '' : interiorColorCode,
      tuixOptionCode: !tuixOptionCode ? '' : tuixOptionCode,
      taxType: !taxationTypeCode ? '' : taxationTypeCode
    }


    // API-E-결제서비스-044 (차량가격상세조회)
    const api_e_payment_044 = await $httpsMsaPayment.get('/detail-cost', {
      params
    })

    const result = {
      api_e_purchase_009: api_e_purchase_009.data,
      api_e_payment_044: api_e_payment_044.data
    }

    return result
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}

module.exports = asyncHandler(async (req, res, next) => {
  const $httpsMsaPayment = Https({ service: 'payment', version: 'v1', req })
  const $httpsMsaPurchase = Https({ service: 'purchase', version: 'v1', req })

  const [response1] = await Promise.all([
    getPriceDetail(req, $httpsMsaPayment, $httpsMsaPurchase)
  ])

  const response = {
    screenId: 'UI_M_마이_결제_C6100A',
    data: response1
  }

  res.json(response)
})
