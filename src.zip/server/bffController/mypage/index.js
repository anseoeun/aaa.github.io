const { Router } = require('express')
const router = Router()

const postMain = require('./postMain')
const getPaymentAmountInfo = require('./getPaymentAmountInfo')
const getPriceDetail = require('./getPriceDetail')

// API-H-BFF-001(마이페이지-메인 화면 조회)
router.post('/main', postMain)
// 결제 정보 탭 - 결제 금액정보 조회(결제처리)
router.get('/purchase/contract-detail', getPaymentAmountInfo)
// 결제 정보 탭 - 결제 금액정보 조회(결제대기)
router.get('/purchase/contract-detail/priceDetail', getPriceDetail)

module.exports = router
