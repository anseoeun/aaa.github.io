const asyncHandler = require('../../utils/asyncHandler')
const Https = require('../../utils/https')

// EP_IF_카젠시_011 지역별 취득세공채정보
module.exports = asyncHandler(async (req, res, next) => {
  const $https = Https({ service: 'cargency', req })
  const response = await $https.get('/hdcarsvc.aspx', {
    params: { ...req.query }
  })

  const { rspCode, rspMessage, dataList } = response.data
  res.json({
    data: dataList,
    rspStatus: {
      rspCode: rspCode || '1000',
      rspMessage: rspMessage || 'I/F Server Error',
      uri: req.path
    }
  })
})
