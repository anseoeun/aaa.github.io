const asyncHandler = require('../../utils/asyncHandler')
const Https = require('../../utils/https')

// API-E-구매서비스-001 (계약가능 정보 조회) - 기능 미구현
async function getContractPossibleInfo(req, $httpsMsaPurchase) {
  try {
    const _req = req
    _req.query = {
      saleModelCode: req.body.saleModelCode,
      customerNumber: req.body.customerNumber,
      productionCarNumber: req.body.productionCarNumber
    }

    const response = await $httpsMsaPurchase.get('/contract/possible/info', {
      params: { ..._req.query }
    })

    return response.data
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}
// API-E-구매서비스-002 (차량현황 조회) - 기능 미구현
async function getContractCarStatus(req, $httpsMsaPurchase) {
  try {
    const _req = req
    _req.query = {
      contractCarTypeCode: req.body.contractCarTypeCode,
      deliveryCenterCode: req.body.deliveryCenterCode,
      saleModelCode: req.body.saleModelCode,
      optionMixCode: req.body.optionMixCode,
      exteriorColorCode: req.body.exteriorColorCode,
      interiorColorCode: req.body.interiorColorCode,
      deliveryLocalAreaCode: req.body.deliveryLocalAreaCode
    }

    const response = await $httpsMsaPurchase.get('/contract/car/status', {
      params: { ..._req.query }
    })

    return response.data
  } catch (err) {
    return {
      message: req,
      config: err.config
    }
  }
}
// API-E-구매서비스-012 (명의자 정보 조회) - 기능 미구현
async function getContractNomineeInfo(req, $httpsMsaPurchase) {
  try {
    const _req = req
    _req.query = {
      contractNumber: req.body.contractNumber,
      electronicSignatureTypeCode: req.body.electronicSignatureTypeCode
    }

    const response = await $httpsMsaPurchase.get('/contract/nominee/info', {
      params: { ..._req.query }
    })

    return response.data
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}
// API-E-구매서비스-039 (계약시작 및 완료 한도시간 저장) - 기능 미구현
async function postContractStartLimitime(req, $httpsMsaPurchase) {
  try {
    const response = await $httpsMsaPurchase.post('/contract/start/limit-time')

    return response.data
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}

module.exports = asyncHandler(async (req, res, next) => {
  const $httpsMsaPurchase = Https({ service: 'purchase', version: 'v1', req })
  const [response1, response2, response3, response4] = await Promise.all([
    getContractPossibleInfo(req, $httpsMsaPurchase),
    getContractCarStatus(req, $httpsMsaPurchase),
    getContractNomineeInfo(req, $httpsMsaPurchase),
    postContractStartLimitime(req, $httpsMsaPurchase)
  ])

  const response = {
    screenId: 'UI_M_계약_계약직전_P1',
    api_e_purchase_001: response1,
    api_e_purchase_002: response2,
    api_e_purchase_012: response3,
    api_e_purchase_039: response4
  }

  res.json(response)
})
