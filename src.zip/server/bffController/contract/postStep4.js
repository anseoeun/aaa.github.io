const asyncHandler = require('../../utils/asyncHandler')
const Https = require('../../utils/https')

// API-H-상품서비스-059 (견적정보에 대한 코드명칭을 조회하는 API)
async function getEstimationInfoName(req, $httpsMsaProduct) {
  try {
    const _req = req
    _req.query = {
      carCode: req.body.carCode,
      saleModelCode: req.body.saleModelCode,
      optionMixCode: req.body.optionMixCode,
      exteriorColorCode: req.body.exteriorColorCode,
      interiorColorCode: req.body.interiorColorCode,
      tuixMixCode: req.body.tuixMixCode,
      saleTypeCode: req.body.saleTypeCode
    }

    const response = await $httpsMsaProduct.get('/estimation-info-name', {
      params: { ..._req.query }
    })

    return response.data
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}
// API-H-공통서비스-005 (이용약관조회)
async function getTerms(req, $httpsMsaCommon) {
  try {
    const response = await $httpsMsaCommon.get('/terms/' + req.body.termsClassCd)

    return response.data
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}
// API-E-구매서비스-009 계약정보 조회
async function getContractContractinfo(req, $httpsMsaPurchase) {
  try {
    const response = await $httpsMsaPurchase.get('/contract/contract-info/' + req.body.contractNumber)

    return response.data
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}
// API-E-구매서비스-012 (명의자 정보 조회) - 기능 미구현
async function getContractNomineeInfo(req, $httpsMsaPurchase) {
  try {
    const _req = req
    _req.query = {
      contractNumber: req.body.contractNumber,
      electronicSignatureTypeCode: req.body.electronicSignatureTypeCode
    }

    const response = await $httpsMsaPurchase.get('/contract/nam/info', {
      params: { ..._req.query }
    })

    return response.data
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}
// API-E-구매서비스-030 (동의 정보 조회)
async function getContractAgreementInfo(req, $httpsMsaPurchase) {
  try {
    const _req = req
    _req.query = {
      contractNumber: req.body.contractNumber
    }

    const response = await $httpsMsaPurchase.get('/contract/agreement-info', {
      params: { ..._req.query }
    })

    return response.data
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}

module.exports = asyncHandler(async (req, res, next) => {
  const $httpsMsaCommon = Https({ service: 'common', version: 'v1', req })
  const $httpsMsaProduct = Https({ service: 'product', version: 'v1', req })
  const $httpsMsaPurchase = Https({ service: 'purchase', version: 'v1', req })

  const [response1, response2, response3, response4, response5] = await Promise.all([
    getEstimationInfoName(req, $httpsMsaProduct),
    getTerms(req, $httpsMsaCommon),
    getContractContractinfo(req, $httpsMsaPurchase),
    getContractNomineeInfo(req, $httpsMsaPurchase),
    getContractAgreementInfo(req, $httpsMsaPurchase)
  ])

  const response = {
    screenId: 'UI_M_계약_S4_C7100A',
    api_h_product_059: response1,
    api_h_common_005: response2,
    api_e_purchase_009: response3,
    api_e_purchase_012: response4,
    api_e_purchase_030: response5
  }

  res.json(response)
})
