const { Router } = require('express')
const router = Router()

// 경쟁차비교
router.use('/comparison', require('./comparison'))
// 견적
router.use('/estimate', require('./estimate'))
// 통합검색
router.use('/search', require('./search'))
// 시승예약
router.use('/test-driving', require('./test-driving'))
// 기타 I/F
router.use('/etc', require('./etc'))
// 주소
router.use('/juso', require('./juso'))
// 국내판매
router.use('/domestic', require('./domestic'))
// 오픈시승
router.use('/open', require('./open'))

// 임직원 차량구매 initialize data bff
router.use('/bff/init', require('./initialize'))
// 차량상세 bff
router.use('/bff/vehicles', require('./vehicles'))
// 계약 bff
router.use('/bff/contract', require('./contract'))
// 결제 bff
router.use('/bff/payment', require('./payment'))
// 마이페이지 bff
router.use('/bff/mypage', require('./mypage'))
// 공지사항 bff
router.use('/bff/notice', require('./notice'))
// 조건차판촉차 bff
router.use('/bff/promotion', require('./promotion'))
// 즉시출고 bff
router.use('/bff/delivery', require('./delivery'))
// 팝업관련 기타 bff
router.use('/bff/popup', require('./popup'))
// 메인화면용 자료 조회
router.use('/bff/main', require('./main'))

module.exports = router
