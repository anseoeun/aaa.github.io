const asyncHandler = require('../../utils/asyncHandler')
const Https = require('../../utils/https')

// EP_IF_카젠시_007(유지비용 차량리스트)
module.exports = asyncHandler(async (req, res, next) => {
  const $https = Https({ service: 'cargency', req })
  // console.log('cost req', req.query)
  const response = await $https.get('/hdcarsvc.aspx?pagecode=cmp7', {
    params: { ...req.query }
  })
  // console.log('cost response', response.data)
  const { rspCode, rspMessage, dataList } = response.data
  res.json({
    data: dataList,
    rspStatus: {
      rspCode: rspCode || '1000',
      rspMessage: rspMessage || 'I/F Server Error',
      uri: req.path
    }
  })
})
