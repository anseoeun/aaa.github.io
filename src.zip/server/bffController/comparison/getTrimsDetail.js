const asyncHandler = require('../../utils/asyncHandler')
const Https = require('../../utils/https')

// EP_IF_카젠시_005(트림별 상세제원)
module.exports = asyncHandler(async (req, res, next) => {
  const $https = Https({ service: 'cargency', req })
  const response = await $https.get('/hdcarsvc.aspx?pagecode=cmp5', {
    params: { ...req.query }
  })
  const { rspCode, rspMessage, dataList } = response.data
  res.json({
    data: dataList,
    rspStatus: {
      rspCode: rspCode || '1000',
      rspMessage: rspMessage || '조회 된 결과가 없습니다.',
      uri: req.path
    }
  })
})
