const asyncHandler = require('../../utils/asyncHandler')
const Https = require('../../utils/https')

// EP_IF_카젠시_004(차량별 엔진/세부등급 리스트)
module.exports = asyncHandler(async (req, res, next) => {
  const $https = Https({ service: 'cargency', req })
  const response = await $https.get('/hdcarsvc.aspx?pagecode=cmp4', {
    params: { ...req.query }
  })
  const { rspCode, rspMessage, juyotrim } = response.data
  res.json({
    data: juyotrim,
    rspStatus: {
      rspCode: rspCode || '1000',
      rspMessage: rspMessage || 'I/F Server Error',
      uri: req.path
    }
  })
})
