const { Router } = require('express')
const router = Router()

const getInit = require('./getInit')

// 차량상세 Init data
router.get('/model', getInit)

module.exports = router
