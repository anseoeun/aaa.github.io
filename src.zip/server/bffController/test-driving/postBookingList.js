const asyncHandler = require('../../utils/asyncHandler')
const Https = require('../../utils/https')

// EP_IF_오픈시승_012_시승예약내역
module.exports = asyncHandler(async (req, res, next) => {
  const $https = Https({ service: 'drive', req })
  const response = await $https.post('/v10/rest/bookingList.do', req.body)
  const { infoResponse } = response.data
  res.json({
    data: response.data,
    rspStatus: {
      rspCode: infoResponse.rsp_CD ? (infoResponse.rsp_CD === '200' ? '0000' : infoResponse.rsp_CD) : '1000',
      rspMessage: infoResponse.rsp_MESSAGE || 'I/F Server Error',
      uri: req.path
    }
  })
})
