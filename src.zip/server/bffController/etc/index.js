const { Router } = require('express')
const router = Router()

const getJuso = require('./getJuso')
const getPos = require('./getPos')
const postEco = require('./postEco')

// 주소검색
router.get('/juso', getJuso)

// 좌표검색
router.get('/pos', getPos)

// 제작번호 조회
router.post('/postEco', postEco)


module.exports = router
