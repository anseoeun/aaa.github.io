const asyncHandler = require('../../utils/asyncHandler')
const Https = require('../../utils/https')

// 계약번호 찾기
module.exports = asyncHandler(async (req, res, next) => {
  const $https = Https({ service: 'custom', req })
  const response = await $https.post('/sale/Eco?actionName=ListCnttWork&cmd=R003', req.body)
  console.log('response >> ', response)
  res.json(response.data)
})
