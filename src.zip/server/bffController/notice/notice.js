const asyncHandler = require('../../utils/asyncHandler')
const Https = require('../../utils/https')

//API-E-고객지원서비스-007 (공지사항 리스트 정보 조회)
async function postNoticeList(req, $httpsMsaCustomersupport) {
  try {
    const _req = req
    _req.query = {
      pageNo: req.body.pageNo,
      pageSize: req.body.pageSize
    }
    const response = await $httpsMsaCustomersupport.get('/notices', { params: { ..._req.query } })

    return response.data
  } catch (err) {
    return {
      message: err.message,
      config: err.config
    }
  }
}

module.exports = asyncHandler(async (req, res, next) => {
  const $httpsMsaCustomersupport = Https({ service: 'customer-support', version: 'v1', req })

  const [response1] = await Promise.all([postNoticeList(req, $httpsMsaCustomersupport)])

  const response = {
    screenId: '나중에만들id',
    api_e_custInfo_007: response1
  }

  res.json(response)
})
