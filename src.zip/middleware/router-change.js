export default (context) => {
  const { store, route, redirect, app } = context
  const name = route.name || ''
  const fullPath = route.fullPath || ''
  const sessionId = store.state.sessionId
  const noneCheckMenu = [
    'vehicles-spec-dictionary', // 사양백과
    'vehicles-estimation-model-estimateShare', // 견적 상세 보기
    'agreement', // 이용약관 페이지
    'nice-open', // Nice인증화면 오픈
    'nice-process', // Nice인증
    'sso-login', // SSO Login
    'sso-complete' // SSO Login 인증완료
  ]
  if (name === 'login') {
    if (sessionId && sessionId !== 'INIT') {
      return redirect('/')
    }
  } else if (name === 'login-contractually-operated') {
    if (sessionId && sessionId !== 'INIT') {
      return redirect('/')
    } else if (!sessionId) {
      return redirect('/login')
    }
  } else {
    if ((!sessionId || sessionId === 'INIT') && !noneCheckMenu.includes(name)) {
      return redirect('/login')
    }
  }

  // 웹로그 데이터 셋팅
  if (!process.server) {
    // console.log('웹로그 ::: router-change ' + fullPath.substring(0,14))
    if(fullPath.substring(0,14) === '/contract/step'){
      app.$utils.setWeblog(fullPath, fullPath)  
    } else app.$utils.setWeblog(name, fullPath)
  }

  store.commit('SET_SELECTED_MENU', null)
  // url 저장
  store.commit('SET_URL', fullPath)
  // 본인인증정보 초기화
  store.commit('commonModules/CERT_STATE', false)
  store.commit('commonModules/CERT_USER_INFO', {})
}
