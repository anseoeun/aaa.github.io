<template>
  <div class="content samplePage">
    <h3>기본</h3>
      <v-radio v-model="radioCheck" :data="optsList1" :disabled="true" />

    <h3>기본 커스텀</h3>
      <v-radio v-model="radioCheck2" :custom-label="true" :data="optsList1">
        <template slot-scope="props">{{ props.item.label }} {{ props.item.color }}</template>
      </v-radio>

    <h3>다른 네임(id값등)을 value로 사용</h3>
      <v-radio
        v-model="optsList2Checked"
        :data="optsList2"
        :custom-label="true"
        value-key="id"
        label-key="label"
      >
      <template slot-scope="props">{{ props.item.label }} {{ props.item.color }}</template>
    </v-radio>

    <h3>커스텀 라벨</h3>
      <v-radio v-model="deliveryAdress" :one-check="true" label="1">커스텀 라디오1</v-radio>
      <v-radio v-model="deliveryAdress" :one-check="true" label="2">커스텀 라디오2</v-radio>
      <v-radio v-model="deliveryAdress" :one-check="true" label="3" :disabled="true">커스텀 라디오3</v-radio>

    <br />
    <br />
    <h2>버튼형</h2>
      <v-radio
        v-model="specificSelected"
        class="radio-button num2"
        type="button"
        :data="specificList" />
      <br />
      <v-radio
        v-model="engineSelected"
        class="radio-button num3"
        type="button"
        :data="engineList"
          />
    <br />
    <br />
    <h2>디자인형 (block)</h2>
    <v-radio v-model="radioCheck" :data="optsList1" class="block" />
    <h2>디자인형 (half)</h2>
    <v-radio v-model="radioCheck" :data="optsList1" class="half" />
  </div>
</template>

<script>
import { VRadio } from '~/components/element'
export default {
  layout: 'sub',
  components: {
    VRadio,
  },
  data() {
    return {
      // 라디오
      deliveryAdress:null,
      radioCheck: false,
      radioCheck2: false,
      optsList1: [
        { value: 'check1', label: '라디오1', color:'쉬머' },
        { value: 'check2', label: '라디오2', color:'아머' },
        { value: 'check3', label: '라디오3', color:'아머' },
        { value: 'check4', label: '라디오4', color:'아머' },
      ],
      optsList2Checked: '',
      optsList2: [
        {
          id: 'id1',
          label: '기본',
        },
        {
          id: 'id2',
          label: '라디오1',
        },
        {
          id: 'id3',
          label: '라디오2',
        },
      ],
      specificSelected: false,
      specificList: [
        {
          value: 'specific1',
          label: '기본'
        },
        {
          value: 'specific2',
          label: '디자인 플러스'
        }
      ],
      engineSelected:  false,
      engineList: [
        {
          value: 'engine1',
          label: '가솔린 2.5'
        },
        {
          value: 'engine2',
          label: '가솔린 2.5 터보'
        },
        {
          value: 'engine3',
          label: '디젤 2.2'
        }
      ],
    }
  },
  methods: {

  },
}
</script>
