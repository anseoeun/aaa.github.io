<template>
  <div class="content samplePage">
    <h2>타임 게이지</h2>
       <v-progress-bar
        total-width="100"
        current-width="100"
        start-time="20210203163000"
        end-time="20210215183000"
        @remainTime="remain"
      />


    <h2>일반 게이지</h2>
      <v-progress-bar
        type="percent"
        total-width="100"
        current-per="26"
      />
  </div>
</template>

<script>
import { VProgressBar } from '~/components/element'
export default {
  layout: 'sub',
  components: {
    VProgressBar
  },
  data() {
    return {

    }
  },
  methods: {
    remain(value) {
      this.endDate = value.end
      this.remainDate = value.remain
      const time = value.time
      const cntArr = ['작성해주세요!', '서둘러주세요!', '제출해주세요!']

      if (time === 120 || time === 60 || time === 30) {
        this.isPopover = true
        if (time === 120) this.popoverCnt = cntArr[0]
        if (time === 60) this.popoverCnt = cntArr[1]
        if (time === 30) this.popoverCnt = cntArr[2]
      } else {
        this.isPopover = false
      }
    }
  }
}
</script>
