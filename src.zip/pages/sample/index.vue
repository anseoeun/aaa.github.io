<template>
  <div class="sample-division">
    <section>
      <h1>Auto ID (v-label)</h1>
      <div v-label="ids[0]">
        <strong>1. directive value 있을 시</strong>
        <label>텍스트 입력폼 1</label>
        <v-input v-model="test[0]"></v-input>
      </div>
      <div v-label>
        <strong>2. directive value 없을 시</strong>
        <label>텍스트 입력폼 2</label>
        <v-input v-model="test[1]"></v-input>
      </div>
      <div v-label>
        <strong>3. directive value 없을 시 - 다단계 구조</strong>
        <p>
          <label>텍스트 입력폼 3</label>
        </p>
        <div>
          <v-input v-model="test[2]"></v-input>
        </div>
      </div>
      <div v-label>
        <strong>4. directive value 없을 시 - textarea</strong>
        <p>
          <label>텍스트 입력폼 4</label>
        </p>
        <div>
          <v-input v-model="test[3]" type="textarea" :rows="4"></v-input>
        </div>
      </div>
    </section>
    <section>
      <h1>Auto Table Caption (v-caption)</h1>
      <div>
        <strong>1. th가 존재할 시</strong>
        <table v-caption>
          <thead>
            <tr>
              <th scope="col">제목 1</th>
              <th scope="col">제목 2</th>
              <th scope="col">제목 3</th>
              <th scope="col">제목 4</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>내용 1</td>
              <td>내용 2</td>
              <td>내용 3</td>
              <td>내용 4</td>
            </tr>
          </tbody>
        </table>
      </div>
      <div>
        <strong>2. th가 없을 시</strong>
        <table v-caption>
          <tbody>
            <tr>
              <td>제목 없는 내용 1</td>
              <td>제목 없는 내용 2</td>
              <td>제목 없는 내용 3</td>
              <td>제목 없는 내용 4</td>
            </tr>
          </tbody>
        </table>
      </div>
      <div>
        <strong>3. directive value 있을 시</strong>
        <table v-caption="tcap">
          <tbody>
            <tr>
              <td>제목 없는 내용 1</td>
              <td>제목 없는 내용 2</td>
              <td>제목 없는 내용 3</td>
              <td>제목 없는 내용 4</td>
            </tr>
          </tbody>
        </table>
      </div>
    </section>
  </div>
</template>

<script>
export default {
  data() {
    return {
      pageTitle: 'Sample page',
      test: ['', '', '', ''],
      ids: ['mytest'],
      tcap: '테스트 표'
    }
  }
}
</script>

<style lang="scss">
.sample-division {
  padding: 0 rem(40);
  section {
    padding: rem(20) 0;
    border-top: 1px solid #ddd;
    > h1 {
      @include bold;
    }
    > div {
      padding-top: rem(20);
      > table {
        width: 100%;
        th,
        td {
          padding: rem(10);
          border: 1px solid #ccc;
        }
        th {
          background: #eee;
        }
      }
      > strong {
        display: block;
        @include bold;
      }
    }
  }
}
</style>
