<template>
  <div class="content samplePage">
    <v-pageheader
      page-title="캐스퍼 사전계약"
      page-infotext="사양 선택 시뮬레이션을 통해<br />차량금액을 확인 후 신청 가능합니다. "
    >
      <div class="term">사전계약기간 : 2021.01.31 ~ 2021. 03.30</div>
    </v-pageheader>
  </div>
</template>

<script>
export default {
  layout:'sub',
  components: {},
  data() {
    return {
      isAgree: false,
      isAgree2: false,
    }
  },
}
</script>
