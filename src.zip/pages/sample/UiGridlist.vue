<template>
  <div class="content samplePage" style="padding: 0;">
    <h2 style="padding-left: 2%;">info-grid-list</h2>
    <div class="info-grid-list">
      <ul>
        <li>
          <strong class="info-title">계약번호</strong>
          <div class="info-group t-blue">202106470997</div>
        </li>
        <li>
          <strong class="info-title">예상금액</strong>
          <div class="info-group">18,000,000 ~ 20,000,000원 내외</div>
        </li>
        <li>
          <strong class="info-title">엔진/트림</strong>
          <div class="info-group">
            <ul class="desc-list">
              <li>가솔린 2.5 5인승 2WD</li>
              <li>Premium Choice</li>
            </ul>
          </div>
        </li>
      </ul>
    </div>

    <br /><br />

    <h2 style="padding-left: 2%;">info-grid-list line</h2>
    <div class="info-grid-list line">
      <ul>
        <li>
          <strong class="info-title">계약번호</strong>
          <div class="info-group t-blue">202106470997</div>
        </li>
        <li>
          <strong class="info-title">예상금액</strong>
          <div class="info-group">18,000,000 ~ 20,000,000원 내외</div>
        </li>
        <li>
          <strong class="info-title">엔진/트림</strong>
          <div class="info-group">
            <ul class="desc-list">
              <li>가솔린 2.5 5인승 2WD</li>
              <li>Premium Choice</li>
            </ul>
          </div>
        </li>
      </ul>
    </div>

    <br /><br />

    <h2 style="padding-left: 2%;">info-grid-list line bold</h2>
    <div class="info-grid-list line bold">
      <ul>
        <li>
          <strong class="info-title">계약번호</strong>
          <div class="info-group t-blue">202106470997</div>
        </li>
        <li>
          <strong class="info-title">예상금액</strong>
          <div class="info-group">18,000,000 ~ 20,000,000원 내외</div>
        </li>
        <li>
          <strong class="info-title">엔진/트림</strong>
          <div class="info-group">
            <ul class="desc-list">
              <li>가솔린 2.5 5인승 2WD</li>
              <li>Premium Choice</li>
            </ul>
          </div>
        </li>
      </ul>
    </div>

    <br />
    <br />
    <h2 style="padding: 0 2%;">matching-box > match-box > info-grid-list</h2>
    <div class="matching-box border-line">
      <div class="box-wrap">
        <div class="box-tit">상세 스펙</div>
        <div class="box-desc">
          <div class="match-box">
            <div class="title">모델</div>
            <div class="desc">아반떼 자가용 LPG 1.6 Modern A/T 모던그레이 인테리어 선루프</div>
          </div>
          <div class="match-box">
            <div class="title">성능</div>
            <div class="desc info-grid-list">
              <ul>
                <li>
                  <strong class="info-title">엔진명</strong>
                  <div class="info-group">가솔린 1.0 터보 엔진</div>
                </li>
                <li>
                  <strong class="info-title">연료명</strong>
                  <div class="info-group">가솔린</div>
                </li>
                <li>
                  <strong class="info-title">변속기</strong>
                  <div class="info-group">6단 수동 변속기</div>
                </li>
                <li>
                  <strong class="info-title">구동방식</strong>
                  <div class="info-group">2WD (전륜구동)</div>
                </li>
                <li>
                  <strong class="info-title">최고출력</strong>
                  <div class="info-group">123 ps / 6300 rpm</div>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>

    <br />
    <br />
    <h2 style="padding: 0 2%;">matching-box > match-box > info-grid-list line</h2>
    <div class="matching-box border-line">
      <div class="box-wrap">
        <div class="box-tit">결제정보</div>
        <div class="box-desc">
          <div class="info-grid-list line">
            <ul>
              <li>
                <div class="info-title">계약금액</div>
                <div class="info-group">100,000 원</div>
              </li>
              <li>
                <div class="info-title">계약금액</div>
                <div class="info-group">100,000 원</div>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  layout:'sub',
  components: {},
  data() {
    return {
    }
  },
}
</script>
