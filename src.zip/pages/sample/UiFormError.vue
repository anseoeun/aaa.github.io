<template>
  <div class="content samplePage">
    <el-form ref="askForm" :model="askForm" :rules="rules" label-position="top">
      <h2>Input</h2>
        <el-form-item label="" required prop="titleName">
          <v-input v-model="askForm.titleName" />
        </el-form-item>

      <h2>Textarea</h2>
        <el-form-item label="" prop="counsel" required>
          <v-input v-model="askForm.counsel" type="textarea" :rows="5" placeholder="상담내용을 입력하여 주세요(최대 2,000자)" maxlength="2000" />
        </el-form-item>

      <h2>Select</h2>
        <el-form-item label="" prop="bigOPtionValue">
          <v-select
            v-model="askForm.bigOPtionValue"
            :data="askForm.bigOPtion"
            placeholder="Select"
          />
        </el-form-item>

      <h2>Checkbox</h2>
        <el-form-item prop="check">
          <v-checkbox v-model="askForm.check" :data="askForm.checkboxListData" />
        </el-form-item>
      <h2>Checkbox (단독)</h2>
        <el-form-item prop="oneCheck">
          <v-checkbox v-model="askForm.oneCheck" :custom-label="true" :data="askForm.checkboxData"></v-checkbox>
        </el-form-item>

    </el-form>
  </div>
</template>

<script>
// import { VInput, VSelect } from '~/components/element'
export default {
  layout: 'sub',
  components: {
    // VInput,
    // VSelect,
  },
  data() {
    return {
      askForm: {
        oneCheck: [],
        check: [],
        titleName: '',
        textareaVal: null,
        bigOPtionValue: '',
        bigOPtion: [
          {
            value: '',
            label: '대분류 선택'
          },
          {
            value: 'Option1',
            label: '차량구매'
          },
          {
            value: 'Option2',
            label: '블루멤버스'
          },
          {
            value: 'Option3',
            label: '임직원 구매 제도'
          }
        ],
        checkboxData: [{ value: 'check1', label: '체크박스1'}],
        checkboxListData: [
          { value: 'check1', label: '체크박스1'},
          { value: 'check2', label: '체크박스2'},
          { value: 'check3', label: '체크박스3'},
          { value: 'check4', label: '체크박스4'},
        ],
      },


    }
  },
  computed: {
    rules() {
      return {
        check: [
          { type: 'array', required: true, message: '체크해주세요', trigger: 'change' }
        ],
        oneCheck: [
          { type: 'array', required: true, message: '체크해주세요', trigger: 'change' }
        ],
        counsel: [
          {
            required: true,
            message: '내용을 입력해 주세요.',
            trigger: ['blur', 'change']
          }
        ],
        bigOPtionValue: [{ required: true, message: '대분류를 선택해 주세요.', trigger: 'change' }],
        titleName: [
          {
            required: true,
            message: '제목을 입력하세요.',
            trigger: ['blur', 'change']
          }
        ],
      }
    },
  },
  methods: {

  },
}
</script>
