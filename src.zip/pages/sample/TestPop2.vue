<template>

  <v-popup
    :visible="popVisible.visible"
    @close="
      $emit('close')
    "
  >
    <template slot="header">
      <div class="title">타이틀1</div>
      <p class="header-description">타이틀설명111111111111111111</p>
    </template>
    <template slot="body">
      팝업내용1
      <p class="bullet">팝업용 bullet : 26px, regular, #666</p>
      <p class="bullet-star">팝업용 bullet : 26px, regular, #666</p>
    </template>
    <template slot="footer">
      <div class="btn-group round">
        <v-btn class="btn" b-size="btn-md">확인</v-btn>
      </div>
    </template>
  </v-popup>
</template>

<script>
import { VPopup } from '~/components/element'
export default {
  components: {
    VPopup
  },
  props: {
    popVisible: {
      type: Object,
      defualt: {},
      required: true
    },
  },

}
</script>

