<template>
  <div class="content samplePage icon-sample">
    <div class="box">
      <strong>로고</strong>
      <ul>
        <li>
          <p>@include logoBlack</p>
          <div class="logo-sample1"></div>
        </li>
      </ul>
    </div>
    <div class="box">
      <strong>아이콘</strong>
      <ul>
        <li>
          <p>@include icoHelp</p>
          <p>icon-help</p>
          <div class="icon-help"></div>
        </li>
        <li>
          <p>@include icoInfo</p>
          <p>icon-info</p>
          <div class="icon-info"></div>
        </li>
        <li>
          <p>@include icoTogArr</p>
          <p>icon-tog-arr</p>
          <div class="icon-tog-arr"></div>
          <div class="icon-tog-arr on"></div>
          <div class="icon-tog-arr off-gray"></div>
          <div class="icon-tog-arr on off-gray"></div>
        </li>
        <li>
          <p>@include icoTogArr</p>
          <p>icon-tog-arr sm-size</p>
          <div class="icon-tog-arr sm-size"></div>
          <div class="icon-tog-arr sm-size on"></div>
          <div class="icon-tog-arr sm-size off-gray"></div>
          <div class="icon-tog-arr sm-size on off-gray"></div>
        </li>
        <li>
          <p>@include icoToggleArr</p>
          <p>icon-toggle-arr</p>
          <div class="icon-toggle-arr"></div>
          <div class="icon-toggle-arr on"></div>
          <div class="icon-toggle-arr off-gray"></div>
          <div class="icon-toggle-arr on off-gray"></div>
        </li>
      </ul>
    </div>
  </div>
</template>

<script>
export default {
  layout: 'sub',
}
</script>

 <style lang="scss" scoped>
  /* 삭제 예정 */
  .icon-sample {padding: 0 rem(15); padding: rem(30) 0; }
  .icon-sample .box + .box { margin-top: rem(30); }
  .icon-sample .box strong { display: block; margin-bottom: rem(10); }
  .icon-sample .box ul { display:flex;flex-direction:row;align-items:stretch;border-left: 1px solid #ccc;flex-wrap: wrap;}
  .icon-sample .box ul li { width: 25%; padding: rem(15); text-align: center; border: 1px solid #ccc; border-left: 0; background: #eee; }
  .icon-sample .box ul li p { margin-bottom: rem(10); font-size:rem(20)}

</style>