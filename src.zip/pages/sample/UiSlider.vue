<template>
  <div class="content samplePage">
    <v-carousel :options="options" :content="true" class="slider-default">
      <template slot="content">
        <splide-slide>
          <div style="height: 200px; background: red"></div>
        </splide-slide>
        <splide-slide>
          <div style="height: 200px; background: green"></div>
        </splide-slide>
        <splide-slide>
          <div style="height: 200px; background: black"></div>
        </splide-slide>
        <splide-slide>
          <div style="height: 200px; background: black"></div>
        </splide-slide>
      </template>
    </v-carousel>

    <div class="slider-list">
      <v-carousel
        :options="options2"
        :data="slideList"
        :btmarrow="true"
      >
      <!-- :btmarrow="true" -->
          <template slot-scope="props">
            <nuxt-link to="/" role="button">
              <div class="car-img">
                <v-img :src="props.item.carImg.src" :alt="props.item.carImg.alt"></v-img>
              </div>
              <ul class="flag-list">
                <li>{{ props.item.flagData }}</li>
              </ul>
              <strong class="name">{{ props.item.name }}</strong>
              <ul class="detail">
                <li class="fullname" v-html="props.item.fullName"></li>
                <li class="out-color">{{ props.item.outColor }}</li>
                <li class="in-color">{{ props.item.inColor }}</li>
                <li v-if="props.item.option" class="option">
                  <span>옵션 {{ props.item.optionList.length }} 개</span>
                  <div class="option-list">
                    <i class="icon-plus"></i>
                    <div class="cont">
                      <p v-for="(optionType, idex) in props.item.optionList" :key="idex">{{ optionType.optionName }}</p>
                    </div>
                  </div>
                </li>
                <li v-else class="option">옵션없음</li>
              </ul>
              <ul class="price">
                <li class="discount-price"><span>할인금액 <em>{{ props.item.discountPrice }}</em> 원</span></li>
                <li class="total-price"><strong>{{ props.item.totalPrice }}</strong> 원</li>
              </ul>
            </nuxt-link>
          </template>
      </v-carousel>
    </div>
  </div>
</template>

<script>
import { VCarousel} from '~/components/element'
export default {
  layout: 'sub',
  name: 'UiSlider',
  components: {
    VCarousel,
  },
  data() {
    return {
      options: {
        // rewind: true, // 맨끝에서 처음으로 다시 돌아가기
        // width: 800,
        perPage: 1,
        perMove: 1,
        // pagination: false,
        // arrows: false,
      },
      options2: {
        perPage: 3,
        perMove: 2,
        fixedWidth: '12rem', //너비고정시
        autoplay: true,
        type: 'loop',
      },
      slideList: [
        {
          flagData: '3월 생산할인차',
          carImg: {
            src: require('~/assets/images/temp/temp-payment-car-model.png'),
            alt: '베뉴 자가용 LPG 1.6<br />Modern A/T',
          },
          name: '베뉴',
          fullName: '베뉴 자가용 LPG 1.6<br />Modern A/T',
          outColor: '미드나잇블랙',
          inColor: '블랙모노톤(블랙시트)',
          option: true,
          optionList: [
            { optionName: '옵션명옵션명이 길경우 길게 길게' },
            { optionName: '옵션명명이 들어갑니다 1줄초과시 말줄임' },
            { optionName: '옵션명3' },
            { optionName: '옵션명4' },
            { optionName: '옵션명5' },
          ],

          discountPrice: '100,000',
          totalPrice: '23,220,000',
        },
        {
          flagData: '전시차',
          carImg: {
            src: require('~/assets/images/temp/temp-payment-car-model.png'),
            alt: '베뉴 자가용 LPG 1.6<br />Modern A/T',
          },
          name: '그랜저',
          fullName: '그랜저 자가용 LPG 1.6<br />Modern A/T',
          outColor: '미드나잇블랙',
          inColor: '블랙모노톤(블랙시트)',
          option: false,
          discountPrice: '100,000',
          totalPrice: '23,220,000',
        },
        {
          flagData: '판촉차',
          carImg: {
            src: require('~/assets/images/temp/temp-payment-car-model.png'),
            alt: '베뉴 자가용 LPG 1.6<br />Modern A/T',
          },
          name: '그랜저',
          fullName: '그랜저 자가용 LPG 1.6<br />Modern A/T',
          outColor: '미드나잇블랙',
          inColor: '블랙모노톤(블랙시트)',
          option: true,
          optionList: [
            { optionName: '옵션명옵션명이 길경우 길게 길게' },
            { optionName: '옵션명명이 들어갑니다 1줄초과시 말줄임' },
          ],
          discountPrice: '100,000',
          totalPrice: '23,220,000',
        },
        {
          flagData: '전시차',
          carImg: {
            src: require('~/assets/images/temp/temp-payment-car-model.png'),
            alt: '베뉴 자가용 LPG 1.6<br />Modern A/T',
          },
          name: '그랜저',
          fullName: '그랜저 자가용 LPG 1.6<br />Modern A/T',
          outColor: '미드나잇블랙',
          inColor: '블랙모노톤(블랙시트)',
          option: false,
          discountPrice: '100,000',
          totalPrice: '23,220,000',
        },
        {
          flagData: '3월 생산할인차',
          carImg: {
            src: require('~/assets/images/temp/temp-payment-car-model.png'),
            alt: '베뉴 자가용 LPG 1.6<br />Modern A/T',
          },
          name: '베뉴',
          fullName: '베뉴 자가용 LPG 1.6<br />Modern A/T',
          outColor: '미드나잇블랙',
          inColor: '블랙모노톤(블랙시트)',
          option: true,
          optionList: [
            { optionName: '옵션명' },
          ],
          discountPrice: '100,000',
          totalPrice: '23,220,000',
        },
        {
          flagData: '판촉차',
          carImg: {
            src: require('~/assets/images/temp/temp-payment-car-model.png'),
            alt: '베뉴 자가용 LPG 1.6<br />Modern A/T',
          },
          name: '그랜저',
          fullName: '그랜저 자가용 LPG 1.6<br />Modern A/T',
          outColor: '미드나잇블랙',
          inColor: '블랙모노톤(블랙시트)',
          option: true,
          optionList: [
            { optionName: '옵션명옵션명이 길경우 길게 길게' },
            { optionName: '옵션명명이 들어갑니다 1줄초과시 말줄임' },
          ],
          discountPrice: '100,000',
          totalPrice: '23,220,000',
        },
      ],
    }
  },
}
</script>
