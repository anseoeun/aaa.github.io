<template>
  <div class="content samplePage">
    <h2>matching-box</h2>
    <div class="matching-box">
      <div class="box-wrap">
        <div class="box-tit">결제정보</div>
        <div class="box-desc">
          <div class="info-grid-list line">
            <ul>
              <li>
                <div class="info-title">계약금액</div>
                <div class="info-group">100,000 원</div>
              </li>
              <li>
                <div class="info-title">계약금액</div>
                <div class="info-group">100,000 원</div>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
    <br /><br />
  </div>
</template>

<script>
export default {
  layout:'sub',
  components: {},
  data() {
    return {
    }
  },
}
</script>
