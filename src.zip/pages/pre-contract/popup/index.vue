<template>
  <div class="">
    <precontract-check :pop-visible="visible" />
  </div>
</template>

<script>
import PrecontractCheck from '~/components/page/pre-contract/popup/PrecontractCheck'

export default {
  components: {
    PrecontractCheck,
  },
  props: {
    visible: {
      type: Object,
      defualt: {},
      required: true
    }
  },
  data() {
    return {}
  },
  methods: {
    parentsSync(e) {
      this.visible = e
      this.$emit('visibleSync', this.visible)
    }
  }
}
</script>
