<template>
  <div id="axAppPublishing">
    <header>
      <h1>
        {{ headingTitle }}
        <button type="button" class="list-all-view" @click="dataReset">전체보기</button>
      </h1>
      <nav>
        <ul>
          <li
            v-for="(item, index) in linkList"
            :key="item"
            :class="{ on: currentTab === index }"
          >
            <button type="button" @click="currentTab = index; setGoTop()">
              {{ item }}
            </button>
          </li>
        </ul>
      </nav>
    </header>
    <main>
      <div class="publishing-area">
        <h1>
          <strong>{{ linkList[currentTab] }}</strong>
          <div class="statistics" v-html="setStatistics(menuList)"></div>
        </h1>
        <div v-if="currentTab === 0">
          <table class="list-header-table">
            <thead>
              <tr>
                <th v-for="(ths, idx) in thList" :key="ths.name" :class="{ 'sort-th': idx === 1 || idx > 3 && idx < 9 }">
                  <template v-if="idx === 1 || idx > 3 && idx < 9">
                    <button type="button" @click="setSort(idx, $event)">{{ ths.name }} ▼</button>
                    <div v-show="ths.isSortClass">
                      <ul>
                        <template v-if="idx === 1">
                          <li v-for="(item, sidx) in getCategory" :key="sidx">
                            <button type="button" @click="filterCategory(sidx, $event)">{{ item }}</button>
                          </li>
                        </template>
                        <template v-if="idx === 4">
                          <li v-for="(item, sidx) in getStart" :key="sidx">
                            <button type="button" @click="filterSet(sidx, $event, 'start')">{{ item }}</button>
                          </li>
                        </template>
                        <template v-else-if="idx === 5">
                          <li v-for="(item, sidx) in getEnd" :key="sidx">
                            <button type="button" @click="filterSet(sidx, $event, 'end')">{{ item }}</button>
                          </li>
                        </template>
                        <template v-else-if="idx === 6">
                          <li v-for="(item, sidx) in getModify" :key="sidx">
                            <button type="button" @click="filterSet(sidx, $event, 'modify')">{{ item }}</button>
                          </li>
                        </template>
                        <template v-else-if="idx === 7">
                          <li v-for="(item, sidx) in getVersion" :key="sidx">
                            <button type="button" @click="filterSet(sidx, $event, 'version')">{{ item }}</button>
                          </li>
                        </template>
                        <template v-else-if="idx === 8">
                          <li v-for="(item, sidx) in getDeveloper" :key="sidx">
                            <button type="button" @click="filterSet(sidx, $event, 'developer')">{{ item }}</button>
                          </li>
                        </template>
                      </ul>
                    </div>
                  </template>
                  <template v-else>
                      {{ ths.name }}
                  </template>
                </th>
              </tr>
            </thead>
          </table>
          <div class="data-list">
            <table
              v-for="(mli, idx) in menuList"
              :key="mli.title"
              class="list-body-table"
            >
              <tbody>
                <tr class="title-line">
                  <td :colspan="tdLength + 1">
                    {{ idx + 1 + '. ' + mli.title }}
                  </td>
                </tr>
                <tr
                  v-for="(st, sidx) in mli.sub"
                  :key="st.idx"
                  :class="{ complete: Number(st.version) > 0, working: Number(st.version) > 0 && Number(st.version) < 1, modify: st.modify !== '' }"
                >
                  <td>{{ idx + 1 + '-' + (sidx + 1) }}</td>
                  <td>{{ st.menu }}</td>
                  <td>{{ st.id }}</td>
                  <td v-if="st.popup">
                    <NuxtLink :to="'/popup#' + st.id" target="_blank">
                      * popup : <br />
                      {{ st.link }}
                    </NuxtLink>
                  </td>
                  <td v-else>
                    <template v-if="st.steps">
                      <NuxtLink :to="st.link + '#' + st.steps" target="_blank">
                        {{ st.link }}
                      </NuxtLink>
                    </template>
                    <template v-else>
                      <NuxtLink :to="st.link" target="_blank">
                        {{ st.link }}
                      </NuxtLink>
                    </template>
                  </td>
                  <td>{{ st.start }}</td>
                  <td>{{ st.end }}</td>
                  <td>{{ st.modify }}</td>
                  <td>{{ st.version }}</td>
                  <td>{{ st.developer }}</td>
                  <td>{{ st.notice }}</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
        <div v-if="currentTab === 1">
          <div class="box-list">
            <table v-for="(item, idx) in compList" :key="idx">
              <colgroup>
                <col style="width: 20%" />
                <col style="width: auto" />
              </colgroup>
              <thead>
                <tr class="header-tr">
                  <th colspan="2">{{ item.name }}</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>Example</td>
                  <td>
                    <pre>{{ item.contents }}</pre>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
        <div v-if="currentTab === 2">
          <div class="box-list">
            <table>
              <colgroup>
                <col style="width: 20%" />
                <col style="width: auto" />
              </colgroup>
              <thead>
                <tr class="header-tr">
                  <th>Name</th>
                  <th>Contents</th>
                </tr>
              </thead>
              <tbody>
                <tr v-for="(item, idx) in dirList" :key="idx">
                  <td>{{ item.name }}</td>
                  <td>{{ item.contents }}</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
        <div v-if="currentTab === 3">
          <div class="box-list">
            <table>
              <colgroup>
                <col style="width: 10%" />
                <col style="width: 20%" />
                <col style="width: auto" />
                <col style="width: 20%" />
              </colgroup>
              <thead>
                <tr class="header-tr">
                  <th>Name</th>
                  <th>Contents</th>
                  <th>Example</th>
                  <th>Notice</th>
                </tr>
              </thead>
              <tbody>
                <tr v-for="(item, idx) in jsList" :key="idx">
                  <td>{{ item.name }}</td>
                  <td>{{ item.contents }}</td>
                  <td>
                    <pre>{{ item.example }}</pre>
                  </td>
                  <td>{{ item.notice }}</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
        <div v-if="currentTab === 4">
          <div class="box-list">
            <table>
              <colgroup>
                <col style="width: 20%" />
                <col style="width: 40%" />
                <col style="width: auto" />
              </colgroup>
              <thead>
                <tr class="header-tr">
                  <th>Name</th>
                  <th>Contents</th>
                  <th>Example</th>
                </tr>
              </thead>
              <tbody>
                <tr v-for="(item, idx) in cssList" :key="idx">
                  <td>{{ item.name }}</td>
                  <td>{{ item.contents }}</td>
                  <td>
                    <pre>{{ item.ex }}</pre>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
        <div v-if="currentTab === 5">
          <div class="box-list">
            <div class="section-box">
              <h2>1. 웹폰트 출력확인</h2>
              <div v-for="sty in gFontStyle" :key="sty" class="fonts">
                <strong>{{ sty }}</strong>
                <ul>
                  <li v-for="pxs in gFontSize" :key="pxs">
                    <span>{{ pxs }}</span>
                    <p>를, 삵, 밟, 굶, 뤨, 휈</p>
                  </li>
                </ul>
              </div>
              <webfonts />
            </div>
          </div>
        </div>
        <div v-if="currentTab === 6">
          <div class="box-list">
            <div class="section-box">
              <h2>1. OS &amp; Browser 대응범위 </h2>
              <table>
                <colgroup>
                  <col style="width: 10%" />
                  <col style="width: 20%" />
                  <col style="width: 20%" />
                  <col style="width: auto" />
                </colgroup>
                <thead>
                  <tr class="header-tr">
                    <th></th>
                    <th>OS</th>
                    <th>Version</th>
                    <th>Browser</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td rowspan="2">Desktop</td>
                    <td>Windows</td>
                    <td>7</td>
                    <td>Chrome, IE11, Edge, Whale Browser, Firefox</td>
                  </tr>
                  <tr>
                    <td>macOS</td>
                    <td>High Sierra (10.13)</td>
                    <td>Safari, Chrome, Firefox</td>
                  </tr>
                </tbody>
              </table>
            </div>
            <div class="section-box">
              <h2>2. 퍼블리싱 Plugins</h2>
              <table>
                <colgroup>
                  <col style="width: 20%" />
                  <col style="width: auto" />
                </colgroup>
                <tbody>
                  <tr v-for="(gpl, idx) in gPlug" :key="idx">
                    <td>{{ gpl.name }}</td>
                    <td>{{ gpl.contents }}</td>
                  </tr>
                </tbody>
              </table>
            </div>
            <div class="section-box">
              <h2>3. 퍼블리싱 폴더구조</h2>
              <ul class="folders">
                <li v-for="(d1, idx) in gf" :key="idx">
                  <strong>{{ d1.depth1 }}</strong>
                  <ul>
                    <li v-for="(d2, sidx) in d1.depth2" :key="sidx">
                      <template v-if="d2.depth3">
                        <strong>{{ d2.name }}</strong>
                        <ul>
                          <li v-for="(d3, tidx) in d2.depth3" :key="tidx">
                            <strong>{{ d3.name }}</strong>
                            <span>{{ d3.contents }}</span>
                          </li>
                        </ul>
                      </template>
                      <template v-else>
                        <strong>{{ d2.name }}</strong>
                        <span>{{ d2.contents }}</span>
                      </template>
                    </li>
                  </ul>
                </li>
              </ul>
            </div>
            <div class="section-box">
              <h2>4. HTML &amp; Nuxt</h2>
              <table v-for="(gc, idx) in ghtml" :key="idx">
                <thead>
                  <tr class="header-tr">
                    <th>{{ gc.title }}</th>
                  </tr>
                </thead>
                <tbody>
                  <tr v-for="(gcs, gi) in gc.contents" :key="gi">
                    <td>{{ gcs }}</td>
                  </tr>
                </tbody>
              </table>
            </div>
            <div class="section-box">
              <h2>5. SCSS</h2>
              <table v-for="(gc, idx) in gcss" :key="idx">
                <thead>
                  <tr class="header-tr">
                    <th>{{ gc.title }}</th>
                  </tr>
                </thead>
                <tbody>
                  <tr v-for="(gcs, gi) in gc.contents" :key="gi">
                    <td>{{ gcs }}</td>
                  </tr>
                </tbody>
              </table>
            </div>
            <div class="section-box">
              <h2>6. SEO</h2>
              <table>
                <colgroup>
                  <col style="width: 25%" />
                  <col style="width: auto" />
                </colgroup>
                <thead>
                  <tr class="header-tr">
                    <th>항목</th>
                    <th>사용 예</th>
                  </tr>
                </thead>
                <tbody>
                  <tr v-for="(seo, iseo) in gSeo" :key="iseo">
                    <td><pre>{{ seo.title }}</pre></td>
                    <td><pre>{{ seo.contents }}</pre></td>
                  </tr>
                </tbody>
              </table>
            </div>
            <div class="section-box">
              <h2>7. APP 접근성</h2>
              <table>
                <colgroup>
                  <col style="width: 15%;" />
                  <col style="width: auto;" />
                </colgroup>
                <tbody>
                  <tr v-for="(acc, ia) in gAcc" :key="ia" class="header-tr">
                    <th>{{ acc.title }}</th>
                    <td>
                      <ul class="intd">
                        <li v-for="(act, iac) in acc.contents" :key="iac">
                          {{ act }}
                        </li>
                      </ul>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </main>
    <footer>
      <address>copyright &copy; publishing team</address>
    </footer>
  </div>
</template>

<script>
import webfonts from '~/components/publishing/Webfonts'
import pub from '~/assets/publishing/index.js'
import gcw from '~/assets/publishing/guide-contents-app.js'
export default {
  name: 'PublishingIndex',
  layout: 'guide',
  components: {
    webfonts
  },
  data() {
    return {
      headingTitle: 'AX APP PUBLISHING',
      linkList: [
        'PAGES',
        'COMPONENTS',
        'DIRECTIVES',
        'JS MIXINS',
        'SCSS MIXINS',
        'UI SAMPLES',
        'GUIDANCE',
      ],
      thList: [
        { name: 'No.', isSortClass: false },
        { name: '화면명', isSortClass: false },
        { name: '화면ID', isSortClass: false },
        { name: 'PATH', isSortClass: false },
        { name: '시작일', isSortClass: false },
        { name: '종료일', isSortClass: false },
        { name: '수정일', isSortClass: false },
        { name: 'Ver.', isSortClass: false },
        { name: '담당자', isSortClass: false },
        { name: '비고', isSortClass: false },
      ],
      currentTab: 0,
      listNum: 0,
      menuList: pub[0],
      compList: pub[1],
      dirList: pub[2],
      jsList: pub[3],
      cssList: pub[4],
      gPlug: gcw[0],
      gf: gcw[1],
      ghtml: gcw[2],
      gcss: gcw[3],
      gSeo: gcw[4],
      gAcc: gcw[5],
      gFontSize: [
        '9px',
        '10px',
        '11px',
        '12px',
        '13px',
        '14px',
        '15px',
        '16px',
        '17px',
        '18px',
        '19px',
        '20px',
        '21px',
        '22px',
        '23px',
        '24px',
      ],
      gFontStyle: ['HyundaiSansHeadKRLight', 'HyundaiSansHeadKRRegular'],
      tdLength: Object.keys(pub[0][0].sub[0]).length,
      orgList: [],
    }
  },
  computed: {
    getCategory() {
      let datalist = []
      let ml = this.orgList
      for(let i = 0; i < ml.length; i++) {
        datalist.push(ml[i].title)
      }
      return datalist
    },
    getStart() {
      let datalist = []
      this.getMyKeys('start', datalist)
      datalist = [...new Set(datalist)]
      this.sortNumber(datalist)
      return datalist
    },
    getEnd() {
      let datalist = []
      this.getMyKeys('end', datalist)
      datalist = [...new Set(datalist)]
      this.sortNumber(datalist)
      return datalist
    },
    getModify() {
      let datalist = []
      this.getMyKeys('modify', datalist)
      return [...new Set(datalist)]
    },
    getVersion() {
      let datalist = []
      this.getMyKeys('version', datalist)
      datalist = [...new Set(datalist)]
      datalist.sort((a, b) => { return a - b })
      return datalist
    },
    getDeveloper() {
      let datalist = []
      this.getMyKeys('developer', datalist)
      return [...new Set(datalist)]
    },
  },
  mounted() {
    this.setOrgList()
  },
  methods: {
    setStatistics(ml) {
      let subea = 0
      let complete = 0
      let status = 0
      for (let i = 0; i < ml.length; i++) {
        const sm = ml[i].sub
        subea = subea + sm.length
        sm.forEach((obj) => {
          if (obj.end !== '') {
            complete++
          }
        })
      }
      status = ((complete / subea) * 100).toPrecision(3)
      return `<span>합계: ${subea}</span><span>완료: ${complete}</span><span>진행률: ${status}%</span>`
    },
    setSort(idx, event) {
      let isClass = this.thList[idx].isSortClass
      let isIdx = [1, 4, 5, 6, 7, 8]
      if (!isClass) {
        for (let i = 0; i < isIdx.length; i++) {
          if (isIdx[i] === idx) {
            this.thList[isIdx[i]].isSortClass = true
          } else {
            this.thList[isIdx[i]].isSortClass = false
          }
        }
      } else {
        this.thList[idx].isSortClass = false
      }
    },
    spaceDel(arrLi, keyName) {
      if (keyName !== '' && keyName !== undefined) {
        arrLi.push(keyName)
      }
    },
    getMyKeys(keyName, datalist) {
      let mli = this.orgList
      for(let i = 0; i < mli.length; i++) {
        let subs = mli[i].sub
        for (let n = 0; n < subs.length; n++) {
          this.spaceDel(datalist, subs[n][keyName])
        }
      }
    },
    setOrgList() {
      let menus = this.menuList
      for(let i = 0; i < menus.length; i++) {
        this.orgList.push(this.menuList[i])
      }
    },
    filterCategory(sidx, event) {
      this.menuList = [this.orgList[sidx]]
    },
    dataReset() {
      this.menuList = this.orgList
      for (let i = 0; i < this.thList.length; i++) {
        this.thList[i].isSortClass = false
      }
    },
    filterSet(sidx, event, keyName) {
      let set = []
      let sub = {
        search(data, array) {
          for (let i = 0; i < data.length; i++) {
            if (data[i][keyName] === event.target.textContent) {
              array.push(data[i])
            }
          }
        }
      }
      for (let i = 0; i < this.orgList.length; i++) {
        sub.search(this.orgList[i].sub, set)
      }
      this.menuList = [{
        title: event.target.textContent,
        sub: set
      }]
    },
    sortNumber(arr) {
      for (let i = 0; i < arr.length; i++) {
        arr[i] = Number(`${arr[i]}`.replace(/-/gi, ''))
      }
      arr.sort((a, b) => { return a - b })
      for (let i = 0; i < arr.length; i++) {
        arr[i] = `${arr[i]}`.replace(/(.{4})/,'$1-').replace(/(.{7})/,'$1-')
      }
    },
  },
}
</script>
