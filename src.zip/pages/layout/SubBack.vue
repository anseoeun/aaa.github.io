<template>
  <div class="content-wrap">
    <div class="content">
      <h1>Back button style sample page</h1>
      <v-page-more @click="dataMoreCall"></v-page-more>
      <el-button type="text" @click="alertVisible = true">쿠키사용동의</el-button>
      <cookie-argeement v-if="alertVisible" @close="alertClosed"></cookie-argeement>
    </div>
  </div>
</template>

<script>
import CookieArgeement from '~/components/layout/CookieArgeement'
export default {
  layout: 'sub',
  components: {
    CookieArgeement,
  },
  data() {
    return {
      pageTitle: 'Title', //페이지 제목 출력
      headerBtns: { //header 버튼 출력
        home: true,
        list: true,
      },
      alertVisible: false,
    }
  },
  methods: {
    dataMoreCall() {
    },
    alertClosed() {
      this.alertVisible = false
    }
  }
}
</script>
