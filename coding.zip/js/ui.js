

$(function(){
	let wrapperH = $('.wrapper').height();
	console.log(wrapperH);
	$('.wrapper').height(wrapperH);


	$('.gnb-menu-wrap .menu').on('click', function(){
		if($('.gnb-menu-wrap').hasClass('expand')){
			$('.gnb-menu-wrap').removeClass('expand');
			$('.gnb-menu-wrap').addClass('contract');
		}else{
			$('.gnb-menu-wrap').addClass('expand');
			$('.gnb-menu-wrap').removeClass('contract');
		}
	})
});
