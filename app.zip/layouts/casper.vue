<template>
  <article class="wrap">
  <header class="header">
    <div class="header-area csper-header">
      <div class="csper-step">
        <ol>
          <li><v-btn class="btn-step on"><span>1.나만의 캐스퍼 만들기</span></v-btn></li>
          <li><v-btn class="btn-step"><span>2.견적</span></v-btn></li>
          <li><v-btn class="btn-step"><span>3.계약</span></v-btn></li>
        </ol>
      </div>
      <div class="btn-right-area">
        <button class="close">Close</button>
      </div>
    </div>
  </header>
    <main class="container">
      <Nuxt />
    </main>
  </article>
</template>

<script>
export default {
  head() {
    return {
      meta: [
        {
          hid: 'keywords',
          name: 'keywords',
          content: ''
        },
        {
          hid: 'description',
          name: 'description',
          content: ''
        },
        {
          hid: 'author',
          name: 'author',
          content: ''
        },
        {
          property: 'og:type',
          content: ''
        },
        {
          property: 'og:title',
          content: ''
        },
        {
          property: 'og:description',
          content: ''
        },
        {
          property: 'og:image',
          content: ''
        },
        {
          property: 'og:url',
          content: ''
        },
      ],
    }
  },
}
</script>

<style lang="scss">
@import '~/assets/style/shop.scss';
</style>
