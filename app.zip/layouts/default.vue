<template>
  <article class="wrap">
    <header-comp />
    <main class="container">
      <Nuxt />
    </main>
    <div class="floating-menu">
      <float :type="floatType" />
    </div>
    <footer-comp />
  </article>
</template>

<script>
import Header from '~/components/layout/Header'
import Footer from '~/components/layout/Footer'
import Float from '~/components/layout/Float'
export default {
  head() {
    return {
      meta: [
        {
          hid: 'keywords',
          name: 'keywords',
          content: ''
        },
        {
          hid: 'description',
          name: 'description',
          content: ''
        },
        {
          hid: 'author',
          name: 'author',
          content: ''
        },
        {
          property: 'og:type',
          content: ''
        },
        {
          property: 'og:title',
          content: ''
        },
        {
          property: 'og:description',
          content: ''
        },
        {
          property: 'og:image',
          content: ''
        },
        {
          property: 'og:url',
          content: ''
        },
      ],
    }
  },
  components: {
    HeaderComp: Header,
    FooterComp: Footer,
    Float,
  },
  data() {
    return {
      floatType: 'none',
    }
  },
  mounted() {
    //퍼블리싱 전용, 개발 시 삭제
    this.floatShow()
  },
  methods: {
    //퍼블리싱 전용함수, 개발 시 삭제
    floatShow() {
      let path = this.$route.fullPath
      if (path.indexOf('LayoutSample') > -1) {
        this.floatType = 'vehicle'
      }
    }
  },
}
</script>

<style lang="scss">
@import '~/assets/style/shop.scss';
</style>
