const scrollTab = {
  bind: (el, binding) => {
    let tabmenu =  document.querySelector('.tab-menu')
    let wrap = document.querySelector('.content')
    let tab = el.querySelectorAll('li')

    let tab_click = (idx) => {
      tab[idx].onclick = function(){
        console.log(binding.value)
        let tab = el.querySelector(`[data-id=tab${idx+1}]`)
        let top = tab.offsetTop
        wrap.scrollTop = top - tabmenu.clientHeight
        if(binding.value === 'cardetail'){
          if(tab.querySelector(`.box-desc`).style.display === 'none') {
            tab.querySelector(`.box-tit`).click()
          }
        }
      }
    }

    for(var i=0; i<tab.length; i++){
      tab_click(i)
    }
  }
}

export default scrollTab
