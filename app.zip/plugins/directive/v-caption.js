const tableCaption = {
  bind: (el, binding) => {
    let value = binding.value
    let thg = []
    let myCap = document.createElement('caption')
    let ths = el.querySelectorAll('th')
    let firstTd = el.querySelector('td')
    if (value) {
      myCap.innerHTML = `${value}`
    } else {
      if (ths.length > 0) {
        ths.forEach((my, i) => {
          let myContent = my.textContent || my.innerText
          thg.push(myContent)
        })
        myCap.innerHTML = `${thg}를 포함하는 표`
      } else {
        let myContent = firstTd.textContent || firstTd.innerText
        myCap.innerHTML = `${myContent} 등을 포함하는 표`
      }
    }
    el.prepend(myCap)
  }
}

export default tableCaption
