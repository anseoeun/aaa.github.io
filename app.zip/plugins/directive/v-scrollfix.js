const tableCaption = {
  bind: (el, binding) => {
    let fix = el.querySelector('.topfix')
    el.addEventListener('scroll', () =>{
        if(el.scrollTop > 0){
            fix.classList.add('fix')
        }else{
            fix.classList.remove('fix')
        }
    })
  }
}

export default tableCaption
