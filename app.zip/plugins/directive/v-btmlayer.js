const btmlayer = {
  bind: (el, binding, vnode) => {
    let btn = el.querySelector('.btn')
    let subbtn = el.querySelector('.layer-close')
    let btnTxt = el.querySelector('.offscreen')
    let hide = el.querySelector('.hide')
    btn.addEventListener('click', () => {
      let classes = btn.className.split(' ')
      if(classes.indexOf('on') <= 0){
        btn.classList.add('on')
        hide.style.display = 'block'
        btnTxt.textContent = '닫기'
      }else{
        btn.classList.remove('on')
        hide.style.display = 'none'
        btnTxt.textContent = '열기'
      }
    })
    if(subbtn !== null){
      subbtn.addEventListener('click', () => {
        btn.classList.remove('on')
        hide.style.display = 'none'
        btnTxt.textContent = '열기'
      })
    }
  }
}

export default btmlayer
