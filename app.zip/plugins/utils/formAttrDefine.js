export const FORM_ATTR = {
    AGREMENT_GUIDE : {
        needPapersNumber : 'AGR00007' ,
        papersFormAttributeNumber : 'AGR000070100001',
        formAttributeTypeSerialNumber : '1',
    },
    AGREMENT_NEW_CAR_ADVANCE :{  //신차사전계약후, 실제 계약 계약직전팝업 동의
        needPapersNumber : 'AGR00019' ,
        papersFormAttributeNumber : 'AGR000190100001',
        formAttributeTypeSerialNumber : '1'
    }
}