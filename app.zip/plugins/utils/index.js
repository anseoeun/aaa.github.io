import Vue from 'vue'
import Data from './data'
import VR360 from './vr360'
import CAROUSEL from './carousel'
import MultiCarousel from './multiCarousel'
import VIDEO from './video'
import TABMENU from './tabmenu'
import SMARTSENSE from './smartsense'
import COMPARISONSLIDER from './comparisonSlider'
import EXTERIOR_CHANGE from './exterior-change'
import moment from 'moment'
import he from 'he'

let _isMoving = false
class Utils {
  constructor({ store, route, app }) {
    this.$store = store
    this.$route = route
    this.$router = app.router
    this.$https = app.$https
    this.$moment = app.$moment
    this.$isDomesticSaleServerOK = !app.$moment().isBetween('2020-10-02 08:00:00', '2020-10-05 04:00:00')
    Vue.prototype.$EventBus = new Vue({
      methods: {
        getState() {
          return _isMoving
        },

        handleState(reqState) {
          _isMoving = reqState
        }
      }
    })
  }

  data(name) {
    return Data[name]
  }

  async getLocation() {
    const isIE11 = !!window.MSInputMethodContext && !!document.documentMode // check browser ie 11
    const location = (options = {}) => {
      options = isIE11 ? { enableHighAccuracy: false, ...options } : options

      if (navigator.geolocation) {
        return new Promise((resolve, reject) => {
          navigator.geolocation.getCurrentPosition(resolve, reject, options)
        })
      } else {
        alert('GPS를 지원하지 않습니다')
      }
    }
    try {
      const { coords } = await location()
      const { latitude, longitude } = coords
      return [{ latitude, longitude }, null]
    } catch (error) {
      // Handle error
      console.log(error)
      return [null, error]
    }
  }


  getTransHtml(text) {
    return text.replace(/&lt;/g, '<').replace(/&gt;/g, '>')
  }

  unEscapeHtml(text) {
    return he.unescape(text)
  }

  arrayDiv(arr, n) {
    const len = arr.length
    const cnt = Math.floor(len / n) + (Math.floor(len % n) > 0 ? 1 : 0)
    const tmp = []
    for (let i = 0; i < cnt; i++) {
      tmp.push(arr.splice(0, n))
    }
    return tmp
  }

  isCapsLock(e) {
    let keyCode = e.keyCode
    let shiftKey = e.shiftKey
    return (keyCode >= 65 && keyCode <= 90 && !shiftKey) || (keyCode >= 97 && keyCode <= 122 && shiftKey)
  }

  vr360(contentsBaseUrl, carCode) {
    return VR360.create(contentsBaseUrl, carCode)
  }

  carousel() {
    return new CAROUSEL()
  }

  multiCarousel(video) {
    return new MultiCarousel(video)
  }

  video() {
    return new VIDEO()
  }

  tabmenu(carousel) {
    return new TABMENU(carousel)
  }

  smartsense() {
    return new SMARTSENSE()
  }

  comparisonSlider() {
    return new COMPARISONSLIDER()
  }

  exteriorChange(contentsBaseUrl, carCode) {
    return new EXTERIOR_CHANGE(contentsBaseUrl, carCode)
  }

  noticesConvert(list) {
    return list.map((obj) => {
      // 알림 확인 여부
      const isConfirm = obj.customerIntegrationNoticeConfirmationDate !== null
      // 시간 표시 텍스트
      let timeText = ''
      if (isConfirm) {
        // 현재 시간
        const nowTime = this.$moment()
        // 알림 시간
        const configTime = this.$moment(obj.customerIntegrationNoticeConfirmationDate)
        // 24시간 지났는지 여부
        const isOneDay = parseInt(this.$moment.duration(nowTime.diff(configTime)).asHours()) > 23
        timeText = isOneDay
          ? configTime.format('YYYY-MM-DD') // 24시간 이후인 경우 날짜만 표시
          : configTime.fromNow() // relative time ( **시간 전)
      }
      return {
        ...obj,
        isConfirm,
        timeText
      }
    })
  }

  async getPDF(pdfTitle, dom) {
    const html2canvas = require('html2canvas')
    const jsPDF = require('jspdf')

    const selector = dom || 'body'
    window.html2canvas = html2canvas
    let pdf = new jsPDF('p', 'mm', 'a4')
    let canvas = pdf.canvas
    const pageWidth = 210 //캔버스 너비 mm
    const pageHeight = 295 //캔버스 높이 mm
    canvas.width = pageWidth
    let ele = document.querySelector(selector)
    let width = ele.offsetWidth // 셀렉트한 요소의 px 너비
    let height = ele.offsetHeight // 셀렉트한 요소의 px 높이
    let imgHeight = (pageWidth * height) / width // 이미지 높이값 px to mm 변환

    if (!ele) {
      console.warn(selector + ' is not exist.')
      return false
    }
    try {
      const resCanvas = await html2canvas(ele)
      let position = 0
      const imgData = resCanvas.toDataURL('image/jpeg')
      pdf.addImage(imgData, 'jpeg', 0, position, pageWidth, imgHeight, undefined, 'slow')
      //Paging 처리
      let heightLeft = imgHeight //페이징 처리를 위해 남은 페이지 높이 세팅.
      heightLeft -= pageHeight
      while (heightLeft >= 0) {
        position = heightLeft - imgHeight
        pdf.addPage()
        pdf.addImage(imgData, 'jpeg', 0, position, pageWidth, imgHeight)
        heightLeft -= pageHeight
      }
      pdf.save(`${pdfTitle.toLowerCase()}.pdf`)
      return 'SUCCESS'
    } catch (e) {
      console.log(e)
      return 'FAIL'
    }
  }

  onlyNumber(e) {
    if (e.target.maxLength > 0 && e.target.value.length > e.target.maxLength) return (e.returnValue = false)
    const allowedKeyCodes = [8, 9, 35, 36, 37, 39, 46, 144]
    if (
      allowedKeyCodes.includes(e.keyCode) ||
      (e.keyCode >= 48 && e.keyCode <= 57) ||
      (e.keyCode >= 96 && e.keyCode <= 105)
    ) {
      return (e.returnValue = true)
    } else {
      return (e.returnValue = false)
    }
  }

  // 문자열 날짜 데이터를 특정포맷으로 변환
  dateFormat(tValue, tFormat) {
    let retDate = '-'

    if (tValue) {
      let oFormat = ''
      if (tValue.length === 10) oFormat = 'YYYYMMDDhh'
      else if (tValue.length === 12) oFormat = 'YYYYMMDDhhmm'
      else if (tValue.length === 14) oFormat = 'YYYYMMDDhhmmss'
      else oFormat = 'YYYYMMDD'

      if (!tFormat) {
        tFormat = 'YYYY-MM-DD'
      }

      const momentDate = moment(tValue, oFormat)

      // 날짜형식이 맞으면 해당 Format으로 적용
      if (momentDate.isValid()) retDate = moment(momentDate).format(tFormat)
    }

    // console.log('# retDate : ', retDate)

    return retDate
  }

  cellphoneNumberFormat(numberStr) {
    let numberStrSize = numberStr.length
    let resStr = null

    if (numberStrSize < 10) {
      resStr = '잘못된 형식입니다.'
    } else {
      let tempSize = numberStrSize - 4
      let firstNum = numberStr.substring(0, 3)
      let centerNum = numberStr.substring(3, tempSize)
      let lastNum = numberStr.substring(tempSize, numberStrSize)

      if (numberStrSize === 10 || numberStrSize === 11) {
        resStr = firstNum + '-' + centerNum + '-' + lastNum
      } else if (numberStrSize === 12 || numberStrSize === 13) {
        resStr = numberStr
      }
    }
    return resStr
  }

  setWeblog(name, fullPath) {
    if (!window._dl) {
      window._dl = {}
    }
    let routeName = name || this.$route.name
    const routeFullPath = fullPath || this.$route.fullPath
    if (routeName == 'login' && routeFullPath.indexOf('login') == -1) {
      routeName = 'index'
    }

    let isModel = false
    let routeFullPathArray = routeFullPath
    let carName = ''
    
    if (routeName.indexOf('vehicles-model') > -1) {
      routeFullPathArray = routeFullPath.split('/')
      if (routeFullPathArray.length > 2) {
        carName = routeFullPathArray[2]
        isModel = true
      } else {
        isModel = false
      }
    }

    // let page_name_test =  isModel ? ['HOME', routeName, carName] : ['HOME', routeName]
    // console.log('계약 >> ' + page_name_test)
    const isLogin = this.$store.state.sessionId
    const { shaId, age, gender } = this.$store.state.userInfo
    window._dl = {
      site_name: 'Hyundai KR',
      page_name: isModel ? ['HOME', routeName, carName] : ['HOME', routeName],
      page_type: this.$router.app && this.$router.app.$mq ? (this.$router.app.$mq === 'desktop' ? 'pc' : this.$router.app.$mq) : 'pc', // pc/tablet/mobile
      page_url: routeFullPath,
      login_status: isLogin ? 'login' : 'annonymous', // login/annonymous
      user_number: isLogin ? shaId : '',
      user_age: isLogin ? age : '',
      user_gender: isLogin ? gender : ''
    }
  }

  //이번주가 몇주차인지 계산해주는 로직
  weekNumberByMonth(dateFormat) {
    const inputDate = new Date(dateFormat)
    let year = inputDate.getFullYear()
    let month = inputDate.getMonth() + 1
    const weekNumberByThurFnc = (paramDate) => {
      const year = paramDate.getFullYear()
      const month = paramDate.getMonth()
      const date = paramDate.getDate()
      const firstDate = new Date(year, month, 1)
      const lastDate = new Date(year, month + 1, 0)
      const firstDayOfWeek = firstDate.getDay() === 0 ? 7 : firstDate.getDay()
      const lastDayOfweek = lastDate.getDay()
      const lastDay = lastDate.getDate()
      const firstWeekCheck = firstDayOfWeek === 5 || firstDayOfWeek === 6 || firstDayOfWeek === 7
      const lastWeekCheck = lastDayOfweek === 1 || lastDayOfweek === 2 || lastDayOfweek === 3
      const lastWeekNo = Math.ceil((firstDayOfWeek - 1 + lastDay) / 7)
      let weekNo = Math.ceil((firstDayOfWeek - 1 + date) / 7)
      if (weekNo === 1 && firstWeekCheck) weekNo = 'prev'
      else if (weekNo === lastWeekNo && lastWeekCheck) weekNo = 'next'
      else if (firstWeekCheck) weekNo = weekNo - 1
      return weekNo
    }

    let weekNo = weekNumberByThurFnc(inputDate)
    if (weekNo === 'prev') {
      const afterDate = new Date(year, month - 1, 0)
      year = month === 1 ? year - 1 : year
      month = month === 1 ? 12 : month - 1
      weekNo = weekNumberByThurFnc(afterDate)
    }
    if (weekNo === 'next') {
      year = month === 12 ? year + 1 : year
      month = month === 12 ? 1 : month + 1
      weekNo = 1
    }
    return weekNo
  }
}

export default (context, inject) => {
  const utils = new Utils(context)
  inject('utils', utils)
}
