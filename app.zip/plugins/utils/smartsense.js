class SMARTSENSE {
  constructor() {
    this.smartsenseListButtonWidth = 0
    this.smartsenseListButtonMarginLeft = 0
    this.loadedSmartSenseVideoCheckList = []
    this.MAX_SMARTSENSELIST_SIZE = 6
    this.smartView = document.querySelector('.smart-view')
    // eslint-disable-next-line no-unused-vars
    this.smartsenseButtonListSize = 0
    this.currentSmartSenseButtonLocation = 0
    this.currentSmartSenseListTransformX = 0
    this.selectedSmartSenseButtonIndex = 0
    this.smartsenseListCtrl = null
    this.smartsenseUnorderdList = null
    this.smartsenseList = null
    this.smartsenseListButtons = null
    this.moveButtons = null
    this.nextButton = null
    this.prevButton = null
    this.smartsenseSystemDescripts = null
    this.smartsenseMovieViewer = null
    this.smartsenseMovieViewerSections = null
    this.smartsenseFirstMovieViewerPlayButton = null
    this.smartsenseFirstVideo = null
    this.smartsenseFirstSource = null
    this.smartsenseVideoList = new Array()
    this.smartsenseVideoSourceList = new Array()

    if (this.smartView) {
      this.smartsenseListCtrl = this.smartView.querySelector('.smartsense-list-ctrl')
      this.smartsenseUnorderdList = this.smartsenseListCtrl.querySelector('ul')
      this.moveButtons = this.smartsenseListCtrl.querySelector('.ctrl')
      this.nextButton = this.moveButtons.querySelector('.next')
      this.prevButton = this.moveButtons.querySelector('.prev')
      this.smartsenseList = this.smartsenseListCtrl.querySelector('ul')
      this.smartsenseListButtons = this.smartsenseList.querySelectorAll('li')
      this.smartsenseMovieViewer = this.smartView.querySelector('.movie-viewer')
      this.smartsenseMovieViewerSections = this.smartsenseMovieViewer.querySelectorAll('.mv-section')
      for (let i = 0; i < this.smartsenseMovieViewerSections.length; i++) {
        const smartsenseVideo = this.smartsenseMovieViewerSections[i].querySelector('video')
        this.smartsenseVideoList.push(smartsenseVideo)
        this.smartsenseVideoSourceList.push(smartsenseVideo.querySelector('source'))
      }
      this.smartsenseSystemDescripts = this.smartView.querySelectorAll('.system-descript')
      this.smartsenseFirstMovieViewerPlayButton = this.smartsenseMovieViewerSections[0].querySelector('button')
      this.smartsenseFirstVideo = this.smartsenseMovieViewerSections[0].querySelector('video')
      if (this.smartsenseFirstMovieViewerPlayButton) {
        this.smartsenseFirstSource = this.smartsenseFirstVideo.querySelector('source')
      }

      this.makeSmartsenseView()
    }
  }

  resizeSmartsenseView() {
    const smartsenseListButtonStyles = window.getComputedStyle(
        this.smartsenseListButtons[1] // 첫번째 엘리먼트에는 margin 값이 빠져있어서 두번째 값으로 기준을 잡음
    )
    this.smartsenseListButtonWidth = Number(
        smartsenseListButtonStyles
            .getPropertyValue('width')
            // eslint-disable-next-line no-useless-escape
            .replace(/[^\d\.]/g, '')
    )
    this.smartsenseListButtonMarginLeft = Number(
        smartsenseListButtonStyles
            .getPropertyValue('margin-left')
            // eslint-disable-next-line no-useless-escape
            .replace(/[^\d\.]/g, '')
    )
  }

  makeSmartsenseView() {
    this.resizeSmartsenseView()
    this.smartsenseButtonListSize = this.smartsenseListButtons.length

    if (this.smartsenseListButtons.length > this.MAX_SMARTSENSELIST_SIZE) {
      this.nextButton.addEventListener(
          'click',
          (e) => {
            this.moveSmartsenseList(this.smartsenseListButtonWidth + this.smartsenseListButtonMarginLeft)
            this.controlSmartSenseMoveButton(this.nextButton, this.prevButton, -1)
          },
          false
      )
      this.prevButton.addEventListener(
          'click',
          (e) => {
            this.moveSmartsenseList((this.smartsenseListButtonWidth + this.smartsenseListButtonMarginLeft) * -1)
            this.controlSmartSenseMoveButton(this.nextButton, this.prevButton, 1)
          },
          false
      )
      this.controlSmartSenseMoveButton(this.nextButton, this.prevButton, 0)
    } else {
      this.moveButtons.style.display = 'none'
    }
    for (let i = 0; i < this.smartsenseListButtons.length; i++) {
      this.smartsenseListButtons[i].addEventListener(
          'click',
          (e) => {
            this.onSmartsenseListButton(i)
          },
          false
      )
    }

    if (this.smartsenseFirstMovieViewerPlayButton) {
      this.smartsenseFirstMovieViewerPlayButton.addEventListener(
          'click',
          (e) => {
            this.smartsenseFirstMovieViewerPlayHandler()
          },
          false
      )
    }
    this.smartsenseMovieViewerSections[this.selectedSmartSenseButtonIndex].style.display = 'block'
    this.smartsenseSystemDescripts[this.selectedSmartSenseButtonIndex].classList.add('active')
  }

  smartsenseFirstMovieViewerPlayHandler() {
    this.smartsenseFirstMovieViewerPlayButton.classList.add('hide')
    this.smartsenseFirstSource.setAttribute('src', this.smartsenseFirstSource.getAttribute('data-src'))
    this.smartsenseFirstVideo.setAttribute('controls', 'true')
    this.smartsenseFirstVideo.load()
    this.smartsenseFirstVideo.play()
  }
  moveSmartsenseList(transformX) {
    this.currentSmartSenseListTransformX += transformX
    this.smartsenseUnorderdList.style.transform = 'translateX(' + this.currentSmartSenseListTransformX + 'px)'
  }

  controlSmartSenseMoveButton(nextButton, prevButton, distance) {
    this.currentSmartSenseButtonLocation += distance
    if (window.innerWidth < 768) {
      this.MAX_SMARTSENSELIST_SIZE = 4
    }       
    if (this.smartsenseButtonListSize - this.currentSmartSenseButtonLocation <= this.MAX_SMARTSENSELIST_SIZE) {
      prevButton.style.visibility = 'hidden'
    } else {
      prevButton.style.visibility = 'visible'
    }
    if (this.currentSmartSenseButtonLocation <= 0) {
      nextButton.style.visibility = 'hidden'
    } else {
      nextButton.style.visibility = 'visible'
    }
  }

  onSmartsenseListButton(n) {
    if (!this.smartsenseFirstMovieViewerPlayButton.classList.contains('hide')) {
      this.smartsenseFirstMovieViewerPlayButton.classList.add('hide')
      this.smartsenseFirstVideo.setAttribute('controls', 'true')
    }

    this.smartsenseListButtons[this.selectedSmartSenseButtonIndex].classList.remove('on')
    this.smartsenseListButtons[n].classList.add('on')
    this.smartsenseMovieViewerSections[this.selectedSmartSenseButtonIndex].style.display = 'none'
    this.smartsenseMovieViewerSections[n].style.display = 'block'
    const beforeSmartsenseVideo = this.smartsenseMovieViewerSections[this.selectedSmartSenseButtonIndex].querySelector('video')
    if (beforeSmartsenseVideo.play) {
      beforeSmartsenseVideo.pause()
    }
    const currentSmartsenseVideo = this.smartsenseVideoList[n]
    if (!this.loadedSmartSenseVideoCheckList[n]) {
      // eslint-disable-next-line no-undef
      const smartsenseVideoSource = this.smartsenseVideoSourceList[n]
      smartsenseVideoSource.setAttribute('src', smartsenseVideoSource.getAttribute('data-src'))
      currentSmartsenseVideo.load()
      this.loadedSmartSenseVideoCheckList[n] = true
    }
    currentSmartsenseVideo.play()
    this.smartsenseSystemDescripts[this.selectedSmartSenseButtonIndex].classList.remove('active')
    this.smartsenseSystemDescripts[n].classList.add('active')

    this.selectedSmartSenseButtonIndex = n
  }

  removeEventListeners() {
    if (this.smartView) {
      if (this.smartsenseListButtons.length > this.MAX_SMARTSENSELIST_SIZE) {
        this.nextButton.removeEventListener(
            'click',
            (e) => {
              this.moveSmartsenseList(this.smartsenseListButtonWidth + this.smartsenseListButtonMarginLeft)
              this.controlSmartSenseMoveButton(this.nextButton, this.prevButton, -1)
            },
            false
        )
        this.prevButton.removeEventListener(
            'click',
            (e) => {
              this.moveSmartsenseList((this.smartsenseListButtonWidth + this.smartsenseListButtonMarginLeft) * -1)
              this.controlSmartSenseMoveButton(this.nextButton, this.prevButton, 1)
            },
            false
        )
      }
      for (let i = 0; i < this.smartsenseListButtons.length; i++) {
        this.smartsenseListButtons[i].removeEventListener(
            'click',
            (e) => {
              this.onSmartsenseListButton(i)
            },
            false
        )
      }
      if (this.smartsenseFirstMovieViewerPlayButton) {
        this.smartsenseFirstMovieViewerPlayButton.removeEventListener(
            'click',
            (e) => {
              this.smartsenseFirstMovieViewerPlayHandler()
            },
            false
        )
      }
    }
  }
}

export default SMARTSENSE
