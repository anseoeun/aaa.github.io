import { mapActions } from 'vuex'
import { apiProduct, apiEstimation } from '~/ajax'

/**
 * 외부 페이지 이동
 */

const checkWindow = (uri = '', name = '', options = '', closeCallback = null) => {
  const win = window.open(uri, name, options)
  const interval = window.setInterval(() => {
    try {
      if (win == null || win.closed) {
        window.clearInterval(interval)
        closeCallback && closeCallback(win)
      }
    }
    catch (e) {
      console.log(e)
    }
  }, 1000)
  return win
}

export default {
  methods: {
    ...mapActions({
      getGenesisEstimationUrl: 'myPageModules/GET_ESTIMATION_URL'
    }),
    async toGenesis(carCode = '') {
      this.$nuxt.$loading.start('견적 진행중 입니다.')

      const params = {
        carCode,
        siteTypeCode :'E'
      }
      const startDate = this.$moment(new Date()).format('YYYY-MM-DD HH:mm:ss')
      const encryptCustomerNumber = this.$store.state.userInfo.customerNumber && await apiEstimation.getEncodeCustomerNumber({ msg: this.$store.state.userInfo.customerNumber })
      const getCarData  = carCode && await apiProduct.getCarKeyVisualWidthParam(params)
      const carData = Array.isArray(getCarData) ? getCarData[0].data : null

      if(!carData || !carData.carEngName || !carData.carCode){
        this.$alert('차량 정보를 읽어오지 못했습니다. 잠시후에 다시 실행해주세요.', '', {
          confirmButtonText: '확인'
        })
        this.$nuxt.$loading.finish()
        return
      } else if(!encryptCustomerNumber || !encryptCustomerNumber[0] || encryptCustomerNumber[0].rspStatus){
        this.$alert('사용자 정보를 읽어오지 못했습니다. 잠시후에 후 다시 실행해주세요.', '', {
          confirmButtonText: '확인'
        })
        this.$nuxt.$loading.finish()
        return
      }
      window._satellite.track('get_a_quote', {vehicle_code: carData.carCode, vehicle_name: carData.carName})

      const carTypeName = (carData.carCode === 'JX01' || carData.carCode === 'JK01') ? 'suv' : 'sedan'
      const url = `${process.env.ESTIMATE_GENESIS_LINK}/kr/ko/models/luxury-${carTypeName}-genesis/${carData.carEngName}/e2e/bto.html?userId=${encryptCustomerNumber[0].replace(/\+/gi, '_')}&repnCarnCd=${carData.carCode}`
      checkWindow(url, 'genesis estimation', `left=200, top=100, width=${window.outerWidth*2/3}, height=${window.outerHeight*5/6}, resizable=yes, scrollbars=yes`, async () => {
        const { estimationUrl } = await this.getGenesisEstimationUrl({
          customerNumber: this.$store.state.userInfo.customerNumber,
          carCode: carData.carCode,
          startDate,
          endDate : this.$moment(new Date()).format('YYYY-MM-DD HH:mm:ss')
        })

        this.$nuxt.$loading.finish()
        if(estimationUrl){
          this.$router.push({
            path: '/vehicles/estimation/model/estimateGenesis',
            query: {
              estimationUrl
            }
          })
        } else {
          this.$alert('견적 진행을 취소하였습니다.', '', {
            confirmButtonText: '확인'
          })
        }
      })
    }
  }
}
