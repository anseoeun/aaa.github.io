class VR360 {

  static instance = null
  // removeEventListener가 적용이 안됨
  // 견적에서 모델 변경할 때마다 vr360 인스턴스가 계속 생성되서 
  // addEventListener가 중첩으로 발생됨
  // eventQueue에 이벤트 등록 후 삭제(익명함수X)
  static create(contentsBaseUrl, carCode) {
    if(VR360.instance instanceof VR360) {
      VR360.instance.removeEventListeners()
      VR360.instance.vr360 = null
      VR360.instance = null
      VR360.instance = new VR360(contentsBaseUrl, carCode)
      // 360도 버튼(원형) 버튼 활성화 
      VR360.instance.reset(carCode)
    } else {
      VR360.instance = new VR360(contentsBaseUrl, carCode)
    }
    return VR360.instance
  }

  constructor(contentsBaseUrl, carCode) {
    this.contentsBaseUrl = contentsBaseUrl
    this.carCode = carCode
    this.vr360List = document.querySelectorAll('.vr360')
    this.vr360 = null

    if ((carCode === 'DN04' || carCode === 'AD07') && this.vr360List.length > 0) {
      this.vr360 = this.vr360List[0]
    } else {
      for (let i = 0; i < this.vr360List.length; i++) {
        if (carCode === this.vr360List[i].id) {
          this.vr360 = this.vr360List[i]
          break
        }
      }
    }

    // this.vr360 = vr360Html //document.querySelector('.vr360')
    this.MAX_PARETTLIST_SIZE = 9
    this.MAX_VR360_IMAGE_SIZE = 60
    this.loadedVr360ImageCheckList = []
    this.currentVr360ImageNumber = 1
    this.isVr360Started = false
    this.currentPalletButtonLocation = 0
    this.currentPalletButtonTransformX = 0
    this.palletButtonListSize = 0
    this.selectedPalletButtonIndex = 0
    this.selectedExteriorColor = ''
    this.exteriorColorText = ''
    this.clicked = false
    this.keydown = false
    this.currPos = 0
    this.CAR_IMAGE_INITIAL_ROTATION_COUNT = 10
    this.vrInfoButton = null
    this.vr360ControlButton = null
    this.leftButton = null
    this.rightButton = null
    this.vr360CarImageContainer = null
    this.vrCarImage = null
    this.vr360CarImage = null
    this.viewerController = null
    this.palletList = null
    this.palletButtonUnorderedList = null
    this.palletButtonList = null
    this.palletButtons = null
    this.vrCarPreload = null
    this.outColorWrap = null
    this.outColorList = null
    this.outColorButtons = null
    this.moveButtons = null
    this.nextButton = null
    this.prevButton = null
    this.palletButtonWidth = null
    this.eventQueue = []

    if (this.vr360) {
      this.vrInfo = this.vr360.querySelector('.vr_info')
      this.vrInfoButton = this.vrInfo.querySelector('.btn.btn-vr.ibtn')
      this.vr360ControlButton = this.vr360.querySelector('.vr360_control_button')
      this.leftButton = this.vr360ControlButton.querySelector('.el-carousel__arrow.el-carousel__arrow--left')
      this.rightButton = this.vr360ControlButton.querySelector('.el-carousel__arrow.el-carousel__arrow--right')
      this.vr360CarImageContainer = this.vr360.querySelector('.vr360_car_image_container')
      this.vrCarImage = this.vr360CarImageContainer.querySelector('.vr_car_image')
      this.vr360CarImage = this.vr360CarImageContainer.querySelector('img')
      this.viewerController = this.vr360.querySelector('.viewer-controller')
      this.palletList = this.vr360.querySelector('.parett-list')
      if (this.palletList) {
        this.palletButtonUnorderedList = this.palletList.querySelector('ul')
        this.palletButtonList = this.palletList.querySelectorAll('ul > li')
        this.palletButtonWidth = this.palletButtonList[1].offsetWidth
        this.palletButtons = this.palletList.querySelectorAll('ul li button')
        this.moveButtons = this.palletList.querySelector('.ctrl')
        this.nextButton = this.moveButtons.querySelector('.next')
        this.prevButton = this.moveButtons.querySelector('.prev')
      }
      this.vrCarPreload = this.vr360.querySelector('.vr_car_preload')
      this.outColorWrap = document.querySelector('.outcolor-wrap')
      if (this.outColorWrap) { //견적용
        this.outColorList = this.outColorWrap.querySelector('.outcolor-list')
        this.outColorButtons = this.outColorList.querySelectorAll('button')
      }
      this.initVr360(this.contentsBaseUrl)
      this.initVr360ExteriorColor()
    }
  }

  initVr360() {
    this.vr360ControlButton.style.display = 'none'

    this.enrollEvent(this.vrInfoButton, 'click',  (e) => {
      window._satellite.track('360VR_interaction', {})
      this.vr360LoadImageHandler(e)
    })

    this.enrollEvent(this.vr360CarImageContainer, 'keydown', this.vr360KeydownHandler.bind(this))

    this.enrollEvent(this.vr360CarImageContainer, 'click', this.focusVr360CarImageContainer.bind(this))
    
    this.enrollEvent(this.leftButton, 'click', (e)=>{
      this.focusVr360CarImageContainer()
      this.moveVr360(1)
    })

    this.enrollEvent(this.rightButton, 'click', (e)=>{
      this.focusVr360CarImageContainer()
      this.moveVr360(-1)
    })

    this.changeVr360CarImage()

    this.enrollEvent(this.vr360CarImageContainer, 'mousedown', this.vr360Ready.bind(this))
    this.enrollEvent(this.vr360CarImageContainer, 'touchstart', this.vr360Ready.bind(this))

    this.enrollEvent(window, 'mouseup', this.vr360Finish.bind(this))
    this.enrollEvent(window, 'touchend', this.vr360Finish.bind(this))
    
    this.preload(this.contentsBaseUrl)
  }

  reset(carCode) {
    this.carCode = carCode // 이미지 차량 코드 변경
    this.currentVr360ImageNumber = 1 // vr360 이미지 처음 위치로 고정
    
    // [견적] 차량 모델 변경 됬을 때 vr360 버튼 재활성화
    if(this.vrInfoButton){
      this.vrInfoButton.style.visibility = 'visible'
    }
    if(this.vr360CarImageContainer) {
      this.vr360CarImageContainer.classList.remove('hide')
    }

    // 클릭(터치), 키이벤트(좌우) flag 값 초기화
    this.isVr360Started = false
    this.clicked = false
    this.keydown = false

    this.changeVr360CarImage()
  }

  vr360LoadImageHandler(e) {

    this.loadVr360Image(0)
    this.vrInfoButton.style.visibility = 'hidden'
    this.vr360ControlButton.style.display = 'block'
    this.vr360CarImageContainer.classList.add('hide')
    this.isVr360Started = true
    let intervalId = null
    const initCarAnimation = () => {
      if (this.currentVr360ImageNumber < this.CAR_IMAGE_INITIAL_ROTATION_COUNT) {
        this.currentVr360ImageNumber ++
        this.vrCarImage.style.opacity = '0.2'
        this.changeVr360CarImage()
        this.vrCarImage.style.opacity = '1'
      } else {
        clearInterval(intervalId)
      }
    }
    intervalId = setInterval(initCarAnimation, 40)
    this.focusVr360CarImageContainer()
  }

  vr360KeydownHandler(e) {
    this.keydown = true
    if (this.isVr360Started && this.keydown) {
      if (e.key === 'ArrowLeft' || e.key === 'Left') {
        this.moveVr360(1)
      } else if (e.key === 'ArrowRight' || e.key === 'Right') {
        this.moveVr360(-1)
      }
    }
  }

  loadVr360Image(indexOfPallet) {
    if (!this.loadedVr360ImageCheckList[indexOfPallet]) {
      const vrCarPreloadImageContainer = this.vrCarPreload.querySelector('.vr_car_preload_image_container')
      const vrCarPreloadImages = vrCarPreloadImageContainer.querySelectorAll('img')
      for (
        let i = indexOfPallet * this.MAX_VR360_IMAGE_SIZE;
        i < indexOfPallet * this.MAX_VR360_IMAGE_SIZE + this.MAX_VR360_IMAGE_SIZE;
        i++
        ) {
        vrCarPreloadImages[i].setAttribute('src', vrCarPreloadImages[i].getAttribute('data-src'))
      }
      this.loadedVr360ImageCheckList[indexOfPallet] = true
    }
  }

  enrollEvent(target, event, callback) {
    const eventDom = {
      'target' : target,
      'event' : event,
      'callback' : callback
    }
    this.eventQueue.push(eventDom)
    eventDom.target.addEventListener(
      eventDom.event,
      eventDom.callback,
      false
    )
  }

  vr360Ready(e) {
    e.preventDefault()
    this.currPos = e.pageX
    this.clicked = true
    this.enrollEvent(window, 'mousemove', this.vr360Rotate.bind(this))
    this.enrollEvent(window, 'touchmove',this.vr360Rotate.bind(this))

    return false
  }

  vr360Rotate(e) {
    if (this.isVr360Started && this.clicked) {
      let MIN_VR360_MOVE_DISTANCE = 6
      let pageX = 0
      if (e.type === 'mousemove') {
        pageX = e.pageX
      } else if (e.type === 'touchmove') {
        pageX = e.touches[0].clientX
        MIN_VR360_MOVE_DISTANCE = 2
      }

      if (Math.abs(this.currPos - pageX) >= MIN_VR360_MOVE_DISTANCE) {
        if (this.currPos - pageX > 0) {
          this.currentVr360ImageNumber++
          if (this.currentVr360ImageNumber > this.MAX_VR360_IMAGE_SIZE) {
            this.currentVr360ImageNumber = 1
          }
        } else {
          this.currentVr360ImageNumber--
          if (this.currentVr360ImageNumber < 1) {
            this.currentVr360ImageNumber = this.MAX_VR360_IMAGE_SIZE
          }
        }
      }
      if (e.type === 'mousemove') {
        this.currPos = e.pageX
      } else if (e.type === 'touchmove') {
        this.currPos = e.touches[0].clientX
      }
      this.changeVr360CarImage()
    }
  }

  vr360Finish(e) {
    this.clicked = false
  }

  focusVr360CarImageContainer() {
    this.vr360CarImageContainer.focus()
  }

  moveVr360(distance) {
    this.currentVr360ImageNumber += distance
    if (this.currentVr360ImageNumber > this.MAX_VR360_IMAGE_SIZE) {
      this.currentVr360ImageNumber = 1
    } else if (this.currentVr360ImageNumber < 1) {
      this.currentVr360ImageNumber = this.MAX_VR360_IMAGE_SIZE
    }
    this.changeVr360CarImage()
  }

  changeVr360CarImage() {
    let imageNumber = ''
    let carImageColor = ''

    // 차량상세용 외장칼라
    if (this.viewerController) {
      carImageColor = this.palletButtons[this.selectedPalletButtonIndex].id
    }

    // 견적용 외장칼라
    if (this.outColorWrap) {
      carImageColor = this.outColorButtons[this.selectedPalletButtonIndex].id
    }

    if (this.currentVr360ImageNumber < 10) {
      imageNumber = '/00' + this.currentVr360ImageNumber
    } else {
      imageNumber = '/0' + this.currentVr360ImageNumber
    }
    /*
    const imageUrl =
      this.contentsBaseUrl + '/contents/vr360/' + this.carCode + '/exterior/' + carImageColor + imageNumber + '.png'
    */
    const imageUrl = `/contents/vr360/${this.carCode}/exterior/${carImageColor}${imageNumber}.png`
    this.vr360CarImage.src = imageUrl
  }

  preload() {
    this.preloadVr360Image()
  }

  preloadVr360Image() {
    this.vrCarPreload.style.display = 'none'
    let carImageColorButtons = []

    if (this.palletList) {
      carImageColorButtons = this.palletButtons
    } else if (this.outColorWrap) {
      carImageColorButtons = this.outColorButtons
    } else {
      return
    }

    let imageDivHtml = '<div class="vr_car_preload_image_container">'

    for (let i = 0; i < carImageColorButtons.length; i++) {
      try {
        for (let j = 1; j <= this.MAX_VR360_IMAGE_SIZE; j++) {
          let imageNumber = ''
          let imageUrl =
              this.contentsBaseUrl + '/contents/vr360/' + this.carCode + '/exterior/' + carImageColorButtons[i].id

          if (j < 10) {
            imageNumber = '/00' + j
          } else {
            imageNumber = '/0' + j
          }
          imageUrl = imageUrl + imageNumber + '.png'
          imageDivHtml += `<img class="vr_car_preload_image" data-src="${imageUrl}" alt="" />`
        }
      } catch (e) {
        // do nothing
      }
    }
    imageDivHtml += '</div>'
    this.vrCarPreload.innerHTML = imageDivHtml
  }

  initVr360ExteriorColor() {
    // 차량상세 용 외장칼라
    if (this.viewerController) {
      this.exteriorColorText = this.vr360.querySelector('.categorization').querySelector('small > span')
      for (let i = 0; i < this.palletButtons.length; i++) {
        const exteriorColorChipUrl = `url('${this.contentsBaseUrl}/contents/vr360/${this.carCode}/exterior/${this.palletButtons[i].id}/colorchip-exterior.png')`
        this.palletButtons[i].style.backgroundImage = exteriorColorChipUrl
      }
      this.selectedExteriorColor = this.palletButtonList[0].querySelector('span').textContent
      this.exteriorColorText.textContent = this.selectedExteriorColor
      this.palletButtonListSize = this.palletButtonList.length

      if (window.innerWidth < 768) {
        this.MAX_PARETTLIST_SIZE = 6
        this.MAX_VR360_IMAGE_SIZE = 44
      }      

      if (this.palletButtonListSize > this.MAX_PARETTLIST_SIZE) {
        this.nextButton.addEventListener(
            'click',
            (e) => {
              this.movePalletButtonList(this.palletButtonWidth * -1)
              this.controlPalletMoveButton(this.nextButton, this.prevButton, 1)
            },
            false
        )
        this.prevButton.addEventListener(
            'click',
            (e) => {
              this.movePalletButtonList(this.palletButtonWidth)
              this.controlPalletMoveButton(this.nextButton, this.prevButton, -1)
            },
            false
        )
        this.controlPalletMoveButton(this.nextButton, this.prevButton, 0)
      } else {
        this.moveButtons.style.display = 'none'
      }
      for (let i = 0; i < this.palletButtonList.length; i++) {
        this.palletButtonList[i].addEventListener(
            'click',
            (e) => {
              this.changeVr360CarColorChip(i)
            },
            false
        )
      }
    }
  }

  movePalletButtonList(transformX) {
    this.currentPalletButtonTransformX += transformX
    this.palletButtonUnorderedList.style.transform = 'translateX(' + this.currentPalletButtonTransformX + 'px)'
  }

  controlPalletMoveButton(nextButton, prevButton, distance) {
    this.currentPalletButtonLocation += distance
    if (this.currentPalletButtonLocation > 0) {
      prevButton.style.visibility = 'visible'
    } else {
      prevButton.style.visibility = 'hidden'
    }
    if (this.palletButtonListSize - this.currentPalletButtonLocation > this.MAX_PARETTLIST_SIZE) {
      nextButton.style.visibility = 'visible'
    } else {
      nextButton.style.visibility = 'hidden'
    }
  }

  changeVr360CarColorChip(n) {
    this.loadVr360Image(n)
    // 차량상세 용 외장칼라
    if (this.viewerController) {
      this.palletButtonList[this.selectedPalletButtonIndex].classList.remove('check')
      this.selectedExteriorColor = this.palletButtonList[n].querySelector('span').textContent
      this.exteriorColorText.textContent = this.selectedExteriorColor
      this.palletButtonList[n].classList.add('check')
    }
    this.selectedPalletButtonIndex = n
    this.changeVr360CarImage()
    this.focusVr360CarImageContainer()
  }

  removeEventListeners() {

    if(Array.isArray(this.eventQueue)) {
      this.eventQueue.forEach((eventDom)=>{
        eventDom.target.removeEventListener(
          eventDom.event,
          eventDom.callback,
          false
        )
      })
    }

    if (this.palletButtonListSize > this.MAX_PARETTLIST_SIZE) {
      this.nextButton.removeEventListener(
          'click',
          (e) => {
            this.movePalletButtonList(this.palletButtonWidth * -1)
            this.controlPalletMoveButton(this.nextButton, this.prevButton, 1)
          },
          false
      )
      this.prevButton.removeEventListener(
          'click',
          (e) => {
            this.movePalletButtonList(this.palletButtonWidth)
            this.controlPalletMoveButton(this.nextButton, this.prevButton, -1)
          },
          false
      )
    }
    if(this.palletButtonList) {
      for (let i = 0; i < this.palletButtonList.length; i++) {
        this.palletButtonList[i].removeEventListener(
            'click',
            (e) => {
              this.changeVr360CarColorChip(i)
            },
            false
        )
      }
    }
  }
}

export default VR360
