class TABMENU {
  constructor(carousel) {
    this.carousel = carousel
    this.exteriorWraps = document.querySelectorAll('.exterior-wrap.menu-tab')
    this.tabMenuList = new Array()
    this.tabContentsList = new Array()
    this.tabMenuListList = new Array()
    this.hiddenTabButtonList = new Array()
    this.tabButtonsList = new Array()
    this.hiddenTabButtonOpenList = new Array()
    this.hiddenTabButtonSpanList = new Array()
    this.tooltipPopupWraps = document.querySelectorAll('.exterior-wrap')
    this.tooltipPopupListList = new Array()
    this.tooltipListList = new Array()
    this.tooltipPopupCloseButtonList = new Array()

    if (this.exteriorWraps.length > 0) {
      this.makeTabMenu()
    }

    if (this.tooltipPopupWraps.length > 0) {
      this.makeTooltipPopup()
    }
  }

  makeTabMenu() {
    for (let i = 0; i < this.exteriorWraps.length; i++) {
      if (this.exteriorWraps[i]) {
        const exteriorWrap = this.exteriorWraps[i]
        const tabMenu = exteriorWrap.querySelector('.tab-menu')
        this.tabMenuList.push(tabMenu)
        const tabContents = exteriorWrap.querySelector('.tabContents').querySelectorAll('div[data-id]')
        this.tabContentsList.push(tabContents)
        const tabList = tabMenu.querySelector('ul')
        this.tabMenuListList.push(tabList)
        const tabButtons = tabList.querySelectorAll('button')
        this.tabButtonsList.push(tabButtons)
        const hiddenTab = tabMenu.querySelector('.hidden-tab')
        const hiddenTabButton = hiddenTab.querySelector('button')
        this.hiddenTabButtonList.push(hiddenTabButton)
        const hiddenTabButtonSpan = hiddenTab.querySelector('span')
        this.hiddenTabButtonSpanList.push(hiddenTabButtonSpan)
        this.hiddenTabButtonOpenList[i] = false

        for (let j = 0; j < tabButtons.length; j++) {
          tabButtons[j].addEventListener(
              'click',
              (e) => {
                this.tabButtonsClickHandler(i, j)
              },
              false
          )
        }
        this.hiddenTabButtonList[i].addEventListener(
            'click',
            (e) => {
              this.clickHiddenTabButton(i)
            },
            false
        )
      }
    }
  }

  tabButtonsClickHandler(indexOfExteriorWraps, indexOfTabButton) {
    const tabButtons = this.tabButtonsList[indexOfExteriorWraps]
    const tabContents = this.tabContentsList[indexOfExteriorWraps]
    const hiddenTabButtonSpan = this.hiddenTabButtonSpanList[indexOfExteriorWraps]
    for (let k = 0; k < tabButtons.length; k++) {
      tabButtons[k].classList.remove('active')
      tabContents[k].classList.remove('show')
      if (indexOfTabButton === k) {
        tabButtons[k].classList.add('active')
        tabContents[k].classList.add('show')
        hiddenTabButtonSpan.innerHTML = tabButtons[k].querySelector('span').innerText
        if (window.innerWidth < 768) {
          this.clickHiddenTabButton(indexOfExteriorWraps)
        }
      }
    }
  }

  clickHiddenTabButton(indexOfExteriorWraps) {
    if (!this.hiddenTabButtonOpenList[indexOfExteriorWraps]) {
      this.tabMenuListList[indexOfExteriorWraps].style.display = 'block'
    } else {
      this.tabMenuListList[indexOfExteriorWraps].style.display = 'none'
    }
    this.hiddenTabButtonOpenList[indexOfExteriorWraps] = !this.hiddenTabButtonOpenList[indexOfExteriorWraps]
    this.carousel.resizeCarouselButtonHeight()
  }

  makeTooltipPopup() {
    for (let i = 0; i < this.tooltipPopupWraps.length; i++) {
      const tooltipPopupList = this.tooltipPopupWraps[i].querySelectorAll('.exterior-img .exterior-pointer .exterior-popup')
      this.tooltipPopupListList.push(tooltipPopupList)
      if (tooltipPopupList) {
        const tooltipList = this.tooltipPopupWraps[i].querySelectorAll('.exterior-img .exterior-pointer span button')
        this.tooltipListList.push(tooltipList)
        for (let j = 0; j < tooltipList.length; j++) {
          if (tooltipList[j]) {
            tooltipList[j].addEventListener(
                'click',
                (e) => {
                  this.showTooltipPopup(i, j)
                },
                false
            )
          }
          if (tooltipPopupList[j]) {
            const tooltipPopupCloseButton = tooltipPopupList[j].querySelector('.btn-popup-close')
            this.tooltipPopupCloseButtonList.push(tooltipPopupList[j])
            this.tooltipPopupCloseButtonList.push(tooltipPopupCloseButton)
            for(const closeButton of this.tooltipPopupCloseButtonList){
              closeButton.addEventListener(
                  'click',
                  (e) => {
                    const buttonClass = closeButton.attributes.class.value
                    if (
                        buttonClass.includes('exterior-popup')
                        && buttonClass !== e.target.classList.value
                      ) return false
                    
                    this.hideTooltipPopup(i, j)
                  },
                  false
              )
            }
          }
        }
      }
    }
  }

  showTooltipPopup(indexOfTooltipWrap, indexOfTooltipPopup) {
    const tooltipPopup = this.tooltipPopupListList[indexOfTooltipWrap][indexOfTooltipPopup]
    const tooltipPopupCarousel = tooltipPopup.querySelector('.full-carousel')
    tooltipPopup.classList.add('on')
    if (tooltipPopupCarousel) {
      this.carousel.resizeCarouselButtonHeight()
    }
  }

  hideTooltipPopup(indexOfTooltipWrap, indexOfTooltipPopup) {
    const tooltipPopup = this.tooltipPopupListList[indexOfTooltipWrap][indexOfTooltipPopup]
    tooltipPopup.classList.remove('on')
  }

  resizeTabMenuButton() {
    for (let i = 0; i < this.exteriorWraps.length; i++) {
      if (this.exteriorWraps[i]) {
        if (window.innerWidth < 768) {
          this.tabMenuListList[i].style.display = 'none'
        } else {
          this.tabMenuListList[i].style.display = ''
        }
      }
    }
  }

  removeEventListeners() {
    for (let i = 0; i < this.exteriorWraps.length; i++) {
      for (let j = 0; j < this.tabButtonsList[i].length; j++) {
        this.tabButtonsList[i][j].removeEventListener(
            'click',
            (e) => {
              this.tabButtonsClickHandler(i, j)
            },
            false
        )
      }

      this.hiddenTabButtonList[i].removeEventListener(
          'click',
          (e) => {
            this.clickHiddenTabButton(i)
          },
          false
      )
    }

    this.tooltipListList.forEach((tooltipList, i) => {
      for (let j = 0; j < tooltipList.length; j++) {
        if (tooltipList[j]) {
          tooltipList[j].removeEventListener(
              'click',
              (e) => {
                this.showTooltipPopup(i, j)
              },
              false
          )
        }
        if (this.tooltipPopupListList[i][j]) {
          this.tooltipPopupCloseButtonList[j].removeEventListener(
              'click',
              (e) => {
                this.hideTooltipPopup(i, j)
              },
              false
          )
        }
      }
    })
  }
}

export default TABMENU
