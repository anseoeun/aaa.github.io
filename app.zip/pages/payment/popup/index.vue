<template>
  <div class="">
    <!-- MS-PAY_001 판매조건변경안내 -->
    <amount-change :pop-visible="visible" />

    <!-- MS-PAY_016 카드한도상향신청 -->
    <installment-increase :pop-visible="visible" />

    <!-- MS-PAY_017 카드한도상향신청 -->
    <save-auto :pop-visible="visible" />

    <!-- MS-PAY_025 썬팅무료시공 -->
    <tinting-coupon :pop-visible="visible" />

    <!-- MS-PAY_038 개인정보제3자제공동의 -->
    <privacy :pop-visible="visible" />

    <!-- MS-PAY_040 카드한도상향및세이브-오토신청 -->
    <credit-save-auto :pop-visible="visible" />
  </div>
</template>

<script>
import AmountChange from '~/components/page/payment/popup/AmountChange'
import InstallmentIncrease from '~/components/page/payment/popup/InstallmentIncrease'
import SaveAuto from '~/components/page/payment/popup/SaveAuto'
import TintingCoupon from '~/components/page/payment/popup/TintingCoupon'
import Privacy from '~/components/page/payment/popup/Privacy'
import CreditSaveAuto from '~/components/page/payment/popup/CreditSaveAuto'

export default {
  components: {
    AmountChange,
    InstallmentIncrease,
    SaveAuto,
    TintingCoupon,
    Privacy,
    CreditSaveAuto
  },
  props: {
    visible: {
      type: Object,
      defualt: {},
      required: true
    }
  },
  data() {
    return {}
  },
  methods: {
    parentsSync(e) {
      this.visible = e
      this.$emit('visibleSync', this.visible)
    }
  }
}
</script>
