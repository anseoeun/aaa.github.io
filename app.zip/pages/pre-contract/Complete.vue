<template>
  <div class="content-wrap">
    <div class="content precontract precontract-complete">
      <v-pageheader page-title="캐스퍼 사전계약이<br />완료되었습니다."> </v-pageheader>
      <v-pageheader
        page-title="캐스퍼 사전계약이<br />접수되었습니다."
        page-infotext="캐스퍼 사전계약 완료를 위해 입금을 서둘러 주세요."
      >
      </v-pageheader>

      <div class="matching-box border-line">
        <div class="box-wrap">
          <div class="box-tit">
            접수정보
          </div>
          <div class="box-desc">
            <div class="info-grid-list line bold-all">
              <ul>
                <li>
                  <strong class="info-title">계약번호</strong>
                  <div class="info-group t-blue">202106470997</div>
                </li>
                <li>
                  <strong class="info-title">예상금액</strong>
                  <div class="info-group">18,000,000 ~ 20,000,000원 내외</div>
                </li>
                <li>
                  <strong class="info-title">엔진/트림</strong>
                  <div class="info-group">AX00000O0 가솔린 2.5 5인승 2WD / Premium Choice</div>
                </li>
                <li>
                  <strong class="info-title">외장색상</strong>
                  <div class="info-group">메테오 블루</div>
                </li>
                <li>
                  <strong class="info-title">내장색상</strong>
                  <div class="info-group">쉬머링 실버</div>
                </li>
                <li>
                  <strong class="info-title">탁송지역</strong>
                  <div class="info-group">인천 / 인천광역시</div>
                </li>
                <li>
                  <strong class="info-title">선택옵션</strong>
                  <div class="info-group">
                    <ul class="opt-list">
                      <li v-for="(item, index) in optList" :key="index">{{ item.opt }}</li>
                    </ul>
                  </div>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
      <!-- 신용카드 -->
      <div class="matching-box border-line">
        <div class="box-wrap">
          <div class="box-tit">
            결제정보
          </div>
          <div class="box-desc">
            <div class="info-grid-list line bold">
              <ul>
                <li>
                  <strong class="info-title">결제수단</strong>
                  <div class="info-group">신용카드</div>
                </li>
                <li>
                  <strong class="info-title">결제카드</strong>
                  <div class="info-group">현대카드(4668-****-****-*****)</div>
                </li>
                <li>
                  <strong class="info-title">결제일시</strong>
                  <div class="info-group">2021-01-04 오후 17:03:25</div>
                </li>
                <li>
                  <strong class="info-title">결제금액</strong>
                  <div class="info-group t-blue"><span class="bold">100,000</span>원</div>
                </li>
              </ul>
            </div>
          </div>
          <div class="box-desc">
            <div class="info-grid-list line bold">
              <ul>
                <li>
                  <strong class="info-title">결제수단</strong>
                  <div class="info-group">무통장입금</div>
                </li>
                <li>
                  <strong class="info-title">입금계좌</strong>
                  <div class="info-group">KB국민은행 03545898851<br />(예금주 : 현대자동차)</div>
                </li>
                <li>
                  <strong class="info-title">계약금액</strong>
                  <div class="info-group t-blue"><span class="bold">100,000</span>원</div>
                </li>
                <li>
                  <strong class="info-title">입금기한</strong>
                  <div class="info-group f-col">
                    <span class="t-blue bold">2021년 01월 29일 까지</span>
                    <p class="stxt">(미 입금 시 계약이 자동 취소됩니다.)</p>
                  </div>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>

      <!-- 유의사항 -->
      <div class="matching-box border-line">
        <div class="box-wrap">
          <div class="box-des notice-list">
            <ul class="bullet-list">
              <li>사전계약 차량은 추후 등록하신 주계약자 휴대전화 번호로 공식계약 일정을 공지합니다.</li>
              <li>공식계약 마감일 이내에 계약으로 전환해주세요.</li>
              <li>공식계약 일정 내 계약하지 않는 경우 자동으로 사전계약이 취소됩니다.</li>
              <li>추후 판매개시 및 공식계약 진행 시 차량 모델.옵션을 변경할 수 있습니다.</li>
              <li>자세한 사전계약내역 확인 및 계약 진행사항은 마이페이지에서 확인 가능합니다.</li>
            </ul>
          </div>
        </div>
      </div>

    </div>
    <div class="fixed-btm-area">
      <div class="fixed-btn">
        <v-btn type="nlink" to="/" class="btn skyblue line">홈으로</v-btn>
        <v-btn type="nlink" to="/" class="btn blue">마이페이지</v-btn>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  head() {
    return {
      title: '사전계약 > 완료'
    }
  },
  layout: 'none',
  data() {
    return {
      pageTitle: '접수완료',
      optList: [
        { opt: '현대스마트센스' },
        { opt: '펫 패키지Ⅰ(강아지얼굴,소형)-모노민트' },
        { opt: '펫 패키지Ⅲ(소형)-모노옐로우' },
        { opt: '[N퍼포먼스 파츠] 인테리어 패키지' }
      ]
    }
  }
}
</script>
