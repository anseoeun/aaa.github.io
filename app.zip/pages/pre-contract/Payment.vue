<template>
  <div class="content-wrap">
    <div class="content precontract precontract-payment">
      <payment-form />
    </div>
    <div class="fixed-btm-area">
      <div class="fixed-btn">
        <v-btn type="nlink" to="/" class="btn blue">결제하기</v-btn>
      </div>
    </div>
  </div>
</template>

<script>
import PaymentForm from '~/components/page/pre-contract/PaymentForm'
export default {
  head() {
    return {
      title: '사전계약 > 결제',
    }
  },
  layout: 'sub',
  components: {
    PaymentForm,
  },
  data() {
    return {
      pageTitle: '결제하기',
    }
  }
}
</script>
