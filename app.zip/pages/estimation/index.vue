<template>
  <div class="content-wrap">
    <div class="content estimate">
      <v-pageheader page-title="차량을 계약하세요<br />캐스퍼를 받기 위한 첫 단계입니다."></v-pageheader>

      <div class="">
        <vehicle-options />
        <take-over />
          <!-- <sale-point />
          <payment /> -->
        <registration-cost />

      </div>

      <div class="estimate-description border-line">
        <div class="info-grid-list">
          <ul>
            <li>
              <strong class="info-title">견적일</strong>
              <div class="info-group">2021년 1월 25일</div>
            </li>
            <li>
              <strong class="info-title">견적 번호</strong>
              <p class="info-group">U00000040282</p>
            </li>
          </ul>
        </div>
        <div class="match-box">
          <div class="title">유의사항</div>
          <div class="desc">
            <ul class="bullet-list">
              <li>본 견적서는 고객님의 차량 구입에 도움을 드리고자 작성된 것으로 계약을 원하실 경우 계약하기 선택 후 계약을 완료하셔야 합니다.</li>
              <li>본 견적서의 예상 출고일 및 견적 금액은 계약 시점에 따라 달라질 수 있습니다.</li>
            </ul>
          </div>
        </div>
        <div class="btn-wrap full">
          <v-btn class="btn white md r" @click="popShare = true">견적 공유</v-btn>
          <v-btn class="btn white md r">PDF 다운로드</v-btn>
        </div>
      </div>

      <div class="banner-wrap">배너영역</div>


    </div>




    <!-- <notice-info />
    <similar-recommend />

    <vehicle-best /> -->


    <div class="fixed-btm-area">
      <div v-btmlayer class="btm-layer">
        <div class="tog-btn">
          <v-btn class="btn"><span class="offscreen">열기</span></v-btn>
        </div>
        <div class="layer-content">
          <div class="estimate-account hide">
            <strong class="main-title">견적요약</strong>
            <div class="info-box">

              <div class="info-grid-list">
                <ul>
                  <li>
                    <div class="info-title">
                      <strong>총 차량 구입금액</strong>
                    </div>
                    <div class="info-group">
                      <ul class="desc-list">
                        <li>
                          <strong class="info-title">차량금액</strong>
                          <div class="info-group">
                            <span class="price">33,300,000 원</span>
                          </div>
                        </li>
                        <li>
                          <strong class="info-title">탁송료</strong>
                          <div class="info-group">
                            <span class="price">270,000 원</span>
                          </div>
                        </li>
                        <li>
                          <!-- <div class="info-title full">
                            <strong>할인/포인트</strong>
                            <v-btn
                              class="btn btn-detail"
                              type="icon"
                              :icon-class="['icon-toggle-arr sm-size gray', { on: isPointShow }]"
                              @click="isPointShow = !isPointShow"
                              ><span class="offscreen">상세보기</span></v-btn
                            >
                            <span class="price t-blue">(-) 1,800,000 원</span>
                          </div> -->
                          <!-- <div class="info-group full">
                            <ul v-show="isPointShow" class="desc-list">
                              <li v-for="(point, index) in pointData" :key="index">
                                <em>{{ point.pointName }}</em>
                                <span class="price">(-) {{ point.pointPrice }} 원</span>
                              </li>
                            </ul>
                          </div> -->
                        </li>
                        <li>
                          <strong class="info-title">세액 감면 혜택</strong>
                          <div class="info-group">
                            <span class="price">33,300,000 원</span>
                          </div>
                        </li>
                      </ul>
                    </div>
                  </li>
                  <li>
                    <strong class="info-title">임시운행 의무보험료</strong>
                    <div class="info-group"><span class="price">2,300 원</span></div>
                  </li>
                  <li>
                    <strong class="info-title">할부인지대</strong>
                    <div class="info-group"><span class="price">2,300 원</span></div>
                  </li>
                  <li class="total-price">
                    <strong class="info-title bold">총 견적 합계</strong>
                    <div class="info-group"><strong class="price bold">33,300,000</strong> 원</div>
                  </li>
                  <li>
                    <!-- <div class="info-title full">
                      <strong>할부원금</strong>
                      <v-btn
                        class="btn btn-detail"
                        type="icon"
                        :icon-class="['icon-open-arrow', { active: isDetailShow }]"
                        @click="isDetailShow = !isDetailShow"
                        ><span class="offscreen">상세보기</span></v-btn
                      >
                      <span class="price">(-) 1,800,000 원</span>
                    </div> -->
                    <!-- <div v-show="isDetailShow" class="info-group full">
                      <ul class="desc-list">
                        <li>
                          <strong class="info-title">월 납입금 A (48개월)</strong>
                          <div class="info-group">
                            <span class="price">100,000 원</span>
                          </div>
                        </li>
                        <li>
                          <strong class="info-title">월 납입금 B (36개월)</strong>
                          <div class="info-group">
                            <span class="price">50,000 원</span>
                          </div>
                        </li>
                      </ul>
                    </div> -->
                  </li>
                  <li>
                    <strong class="info-title bold">출고 전 납입총액</strong>
                    <div class="info-group"><span class="price bold">2,300 원</span></div>
                  </li>
                  <li>
                    <strong class="info-title">등록비용 (별도 납부)</strong>
                    <div class="info-group"><span class="price">2,300 원</span></div>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div>총 결제금액

          </div>
          <div class="hide">숨김영역</div>
        </div>
      </div>
      <div class="fixed-btn">
        <v-btn type="nlink" to="/" class="btn skyblue">견적저장</v-btn>
        <v-btn type="nlink" to="/" class="btn blue">계약하기</v-btn>
      </div>
    </div>





    <!-- 팝업 -->
    <!-- <estimate-share :visible="popShare" @close="popShare = false" /> -->
  </div>
</template>

<script>
import VehicleOptions from '~/components/page/estimation/VehicleOptions'
import TakeOver from '~/components/page/estimation/TakeOver'
// import SalePoint from '~/components/page/estimation/SalePoint'
// import TaxRegistration from '~/components/page/estimation/TaxRegistration'
// import Payment from '~/components/page/estimation/Payment'
import RegistrationCost from '~/components/page/estimation/RegistrationCost'
// import NoticeInfo from '~/components/page/estimation/NoticeInfo'
// import EstimateTool from '~/components/page/estimation/EstimateTool'
// import SimilarRecommend from '~/components/page/estimation/SimilarRecommend'
// import EstimateShare from '~/components/page/estimation/popup/EstimateShare'
// import VehicleBest from '~/components/page/estimation/VehicleBest'

export default {
  head() {
    return {
      title: '견적 > 견적내기'
    }
  },
  layout: 'sub',
  components: {
    VehicleOptions,
    TakeOver,
    // SalePoint,
    // TaxRegistration,
    // Payment,
    RegistrationCost,
    // NoticeInfo,
    // EstimateTool,
    // SimilarRecommend,
    // EstimateShare,
    // VehicleBest
  },
  data() {
    return {
      pageTitle: '견적내기',
      // popShare: false
    }
  }
}
</script>