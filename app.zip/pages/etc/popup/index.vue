<template>
  <div class="">
    <!-- MS-ETC_022 앱푸시수신동의 -->
    <pop-push-alarm :pop-visible="visible" />
  </div>
</template>

<script>
import PopPushAlarm from '~/components/page/etc/PopPushAlarm'

export default {
  components: {
    PopPushAlarm
  },
  props: {
    visible: {
      type: Object,
      defualt: {},
      required: true
    }
  },
  data() {
    return {}
  },
  methods: {
    parentsSync(e) {
      this.visible = e
      this.$emit('visibleSync', this.visible)
    }
  }
}
</script>
