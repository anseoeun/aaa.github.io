<template>
  <v-popup
    :visible="visible"
    :full-popup="true"
    class="vehicle-popup full-popup"
    @close="
      $emit('close')
    "
  >
    <template slot="header">
      <div class="title">지도보기</div>
    </template>
    <template slot="body">
      <div class="pop-map-view">
        <div class="map" style="background:#f9f9f9;">지도영역</div>
        <div class="btn-wrap">
          <v-btn class="btn md white">화면 내 지도에서 재검색</v-btn>
        </div>
        <!-- map-info -->
        <div class="map-info">
          <div class="info-wrap">
            <div class="title"><span class="seq">1</span> <b class="bold">서초 전시장</b></div>
              <div class="address">
                서울 영등포구 국제금융로 20 (여의도동 24-1) 율촌빌딩 1층
              </div>
              <div class="txt">032-816-4900</div>
              <div class="txt">전시차 5대</div>
              <div class="flag-list"><span class="flag">캐스퍼 전용</span>
                <span class="flag">상담가능</span>
                <span class="flag">시승가능</span>
              </div>
          </div>
          <div class="info-btn">
            <v-btn class="btn btn-gray">닫기</v-btn>
            <v-btn class="btn btn-blue">전시장 안내</v-btn>
          </div>
        </div>
        <!-- // map-info -->
      </div>
    </template>
  </v-popup>
</template>

<script>
import { VPopup } from '~/components/element'
export default {
  components: {
    VPopup,
  },
  props: {
    visible: {
      type: Boolean,
      default: false
    },
  },
  data() {
    return {
      carList: [
        {date:'2021.01.29 12:34',
          data:[
            {
              carImg: {
                src: require('~/assets/images/temp/temp-payment-car-model.png'),
                alt: 'AX 스마트스트림 가솔린 1.1 터보 프리미엄 밀레니얼 A/T',
              },
              name : 'AX 스마트스트림 가솔린 1.1 터보 프리미엄 밀레니얼 A/T',
              opt1 : '미드나잇 블랙 / 베이지',
              opt2 : '옵션2개',
              price : '33,000,000',
            }
          ]
        },
        {date:'2021.01.28 12:34',
          data:[
            {
              soldout: true,
              carImg: {
                src: require('~/assets/images/temp/temp-payment-car-model.png'),
                alt: 'AX 스마트스트림 가솔린 1.1 터보 프리미엄 밀레니얼 A/T',
              },
              name : 'AX 스마트스트림 가솔린 1.1 터보 프리미엄 밀레니얼 A/T',
              opt1 : '미드나잇 블랙 / 베이지',
              opt2 : '옵션업음',
              price : '33,000,000',
            },
            {
              carImg: {
                src: require('~/assets/images/temp/temp-payment-car-model.png'),
                alt: 'AX 스마트스트림 가솔린 1.1 터보 프리미엄 밀레니얼 A/T',
              },
              name : 'AX 스마트스트림 가솔린 1.1 터보 프리미엄 밀레니얼 A/T',
              opt1 : '미드나잇 블랙 / 베이지',
              opt2 : '옵션2개',
              price : '33,000,000',
              txt: '견적'
            }
          ]
        },
        {date:'2021.01.27 12:34',
          data:[
            {
              carImg: {
                src: require('~/assets/images/temp/temp-payment-car-model.png'),
                alt: 'AX 스마트스트림 가솔린 1.1 터보 프리미엄 밀레니얼 A/T',
              },
              name : 'AX 스마트스트림 가솔린 1.1 터보 프리미엄 밀레니얼 A/T',
              opt1 : '미드나잇 블랙 / 베이지',
              opt2 : '옵션2개',
              price : '33,000,000',
            },
            {
              carImg: {
                src: require('~/assets/images/temp/temp-payment-car-model.png'),
                alt: 'AX 스마트스트림 가솔린 1.1 터보 프리미엄 밀레니얼 A/T',
              },
              name : 'AX 스마트스트림 가솔린 1.1 터보 프리미엄 밀레니얼 A/T',
              opt1 : '미드나잇 블랙 / 베이지',
              opt2 : '옵션2개',
              price : '33,000,000',
            }
          ]
        }
      ]
    }
  }
}
</script>

