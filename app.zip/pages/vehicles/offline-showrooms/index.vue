<template>
  <div class="content-wrap">
    <div class="content vehicles offline-showroom">
      <v-pageheader
        page-title="전시장을 방문하여<br>직접 캐스퍼를 만나세요!"
      />
      <div class="offline-showroom-wrap">
        <div class="my-position">
          <p class="tit"><i class="icon-mapidx"></i> 내 위치
            <v-btn class="btn-link" @click="popupVisible.address = true">위치수정</v-btn>
          </p>
          <p class="txt">서울특별시 강남구 강남대로 464</p>
        </div>
        <div class="map-list border-line">
          <div class="total">검색결과 2건
            <v-btn class="btn-link" @click="popupVisible.mapview = true">지도보기</v-btn>
          </div>
          <ul class="list">
            <li v-for="(item, index) in dataList" :key="index">
              <v-btn class="pos-info">
                <div class="title">
                  <span class="seq">{{ item.seq }}</span>
                  <b class="bold">{{ item.name }}</b>
                  <span class="distence">{{ item.distence }}km</span>
                </div>
                <div class="address">
                  {{ item.address }}
                </div>
                <div class="date">운영기간 :  {{ item.date }}</div>
                <div class="txt">전시차 {{ item.carnum }}대</div>
                <div v-if="item.flag.length > 0" class="flag-list">
                  <span v-for="(flag, idx) in item.flag" :key="idx" class="flag">{{ flag }}</span>
                </div>
              </v-btn>
            </li>
          </ul>
        </div>
      </div>
      <!-- 위치수정팝업 -->
      <!-- <popup :visible.sync="popupVisible" /> -->
      <!-- 지도보기 -->
      <map-view :visible="popupVisible.mapview" @close="popupVisible.mapview = false" />
    </div>
  </div>
</template>

<script>
// import Popup from '~/components/page/vehicles/test-driving/popup'
import MapView from '~/pages/vehicles/offline-showrooms/popup/MapView'
export default {
  head() {
    return {
      title: '체험 > 전시장안내',
    }
  },
  layout: 'sub',
  components: {
    // Popup
    MapView
  },
  data() {
    return {
      pageTitle: '전시장 안내',
      dataChecked : {
          seq: 1,
          name: '서초 전시장',
          address: '서울특별시 서초구 반포대로 54 (서초동, 문창빌딩) 1층',
          date: '2021. 1. 3 ~ 2021. 12. 1',
          carnum: '5',
          distence: '12',
          flag: ['팝업 전시', ' 상담 가능', ' 시승 가능'],
        },
      dataList: [
        {
          seq: 1,
          name: '서초 전시장',
          address: '서울특별시 서초구 반포대로 54 (서초동, 문창빌딩) 1층',
          date: '2021. 1. 3 ~ 2021. 12. 1',
          carnum: '5',
          distence: '12',
          flag: ['팝업 전시', ' 상담 가능', ' 시승 가능'],
        },{
          seq: 2,
          name: '구로 전시장',
          address: '서울특별시 구로 반포대로 54 (서초동, 문창빌딩) 1층',
          date: '2021. 1. 3 ~ 2021. 12. 1',
          carnum: '5',
          distence: '12',
          flag: ['팝업 전시', ' 상담 가능', ' 시승 가능'],
        },{
          seq: 3,
          name: '강동 전시장',
          address: '서울특별시 강동 반포대로 54 (서초동, 문창빌딩) 1층',
          date: '2021. 1. 3 ~ 2021. 12. 1',
          carnum: '5',
          distence: '12',
          flag: ['팝업 전시', ' 상담 가능', ' 시승 가능'],
        },
      ],
      popupVisible: {
        address: false,
        mapview: false,
      }
    }
  },
}
</script>
