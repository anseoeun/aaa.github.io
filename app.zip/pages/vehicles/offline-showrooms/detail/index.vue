<template>
  <div class="content-wrap">
    <div class="content vehicles offline-showroom">
      <!-- offline-showroom-wrap -->
      <div class="offline-showroom-detail-wrap">
        <div class="offline-showroom-detail">
          <div class="title">
            <b>스튜디오 하남</b>
            <span class="flag-wrap">
              <span class="flag">팝업 전시</span>
              <span class="flag">상담 가능</span>
              <span class="flag">시승 가능</span>
            </span>
          </div>
          <!-- detail-desc -->
          <div class="detail-desc">
            <div class="info-grid-list bold-all">
              <ul>
                <li>
                  <strong class="info-title">주소</strong>
                  <div class="info-group">
                      경기도 하남시 미사대로 750번지 스타필드 하남 2층
                  </div>
                </li>
                <li>
                  <strong class="info-title">운영 기간</strong>
                  <div class="info-group">2021. 03. 02 ~ 2021. 12. 31</div>
                </li>
                <li>
                  <strong class="info-title">운영 시간</strong>
                  <div class="info-group">10:00 ~ 22:00 연중무휴</div>
                </li>
                <li>
                  <strong class="info-title">전화번호</strong>
                  <div class="info-group">02-1111-2222</div>
                </li>
              </ul>
            </div>
            <p class="text">
              10대의 자동차를 자유롭게 관람하고 시승하실 수 있습니다.
              시승은 사전 예약 필요, 시승 후 2층에서 사용할 수 있는
              폴바셋 커피 쿠폰 제공
            </p>
          </div>
          <div class="driving-apply border-line">
            <p class="text">시승서비스 이용을 원하시는 고객님께서는<br />시승신청을 통해 예약 후 방문해주세요.</p>
            <v-btn type="nlink" to="/" class="btn md blue full">시승 신청</v-btn>
          </div>
          <!-- // detail-desc -->
          <div class="showrooms-visual">
            <div v-if="slideList.length > 0" class="slider-list">
              <v-carousel :options="options" :data="slideList" :btmarrow="true">
                <template slot-scope="props">
                  <div class="car-img">
                    <v-img :src="props.item.carImg.src" :alt="props.item.carImg.alt"></v-img>
                  </div>
                </template>
              </v-carousel>
            </div>
            <div v-else class="no-slider">
              <p>이미지 준비 중입니다</p>
            </div>
          </div>
          <div class="showrooms-car">
            <div class="title">전시중인 차</div>
            <ul>
              <li v-for="(item, index) in carList" :key="index">
                <v-btn type="nlink" to="/" class="car">
                  <div class="desc">
                    <p class="tit">{{ item.name }}</p>
                      <ul>
                        <li>
                          <div class="tit">외장색상 : </div>
                          <div class="txt">{{ item.outColor }}</div>
                        </li>
                        <li>
                          <div class="tit">내장색상 : </div>
                          <div class="txt">{{ item.inColor }}</div>
                        </li>
                      </ul>
                  </div>
                  <div class="img">
                    <v-img :src="item.carImg.src" :alt="item.carImg.alt"></v-img>
                  </div>
                </v-btn>
              </li>
            </ul>
            <p class="bullet-star">전시장의 상황에 따라 전시 중인 차는 사전 예고없이 변경될 수 있습니다.</p>
          </div>
        </div>
        <!-- offline-showroom-detail -->
        <div class="map-view">
          <div class="title">
            전시장 위치 안내
          </div>
          <div class="map" style="background:#f9f9f9">지도영역</div>
        </div>
        <div class="btn-wrap">
          <v-btn type="nlink" to="/" class="btn md blue line full">목록</v-btn>
        </div>
      </div>
      <!-- // offline-showroom-wrap -->
    </div>
  </div>
</template>

<script>
export default {
  head() {
    return {
      title: '체험 > 전시장안내',
    }
  },
  layout: 'sub',
  components: {
  },
  data() {
    return {
      pageTitle: '전시장 안내',
      carImg: {
        src: require('~/assets/images/temp/temp-review-car.png'),
        alt: 'AX 스마트스트림 가솔린 1.1 터보 프리미엄 밀레니얼 A/T',
      },
      carList :[
        {
          carImg: {
            src: require('~/assets/images/temp/temp-review-car.png'),
            alt: 'AX 스마트스트림 가솔린 1.1 터보 프리미엄 밀레니얼 A/T',
          },
          name :'AX 스마트스트림 가솔린 1.1 Turbo 프리미엄 밀레니얼 A/T',
          outColor :' 미드나잇 블랙',
          inColor :' 베이지'
        },
        {
          carImg: {
            src: require('~/assets/images/temp/temp-review-car.png'),
            alt: 'AX 스마트스트림 가솔린 1.1 터보 프리미엄 밀레니얼 A/T',
          },
          name :'AX 스마트스트림 가솔린 1.1 Turbo 프리미엄 밀레니얼 A/T',
          outColor :' 미드나잇 블랙',
          inColor :' 베이지'
        }
      ],
      options: {
        perPage: 1,
        perMove: 1,
        arrows: false,
      },
      slideList: [
        {
          carImg: {
            src: require('~/assets/images/temp/temp-showroom.jpg'),
            alt: '전시장1'
          }
        },
        {
          carImg: {
            src: require('~/assets/images/temp/temp-showroom.jpg'),
            alt: '전시장2'
          }
        },
        {
          carImg: {
            src: require('~/assets/images/temp/temp-showroom.jpg'),
            alt: '전시장3'
          }
        }
      ],
    }
  },
}
</script>
