<template>
  <div class="">
    <!-- MS-DIS_041 지인할인추천안내 -->
    <friend-recommend :pop-visible="visible" />

    <!-- MS-DIS_069 세부만족도 -->
    <satisfaction :pop-visible="visible" :full-popup="true" class="full-popup" />

    <!-- MS-DIS_083~085 시승신청약관레이어들  -->
    <agreement-use :pop-visible="visible" />

    <!-- MS-DIS_099 구매상세정보  -->
    <purchase-info :pop-visible="visible" :full-popup="true" class="full-popup" />
  </div>
</template>

<script>
import FriendRecommend from '~/components/page/vehicles/popup/FriendRecommend'
import Satisfaction from '~/components/page/review/Satisfaction'
import AgreementUse from '~/components/page/vehicles/test-driving/popup/AgreementUse'
import PurchaseInfo from '~/components/page/review/PurchaseInfo'

export default {
  components: {
    FriendRecommend,
    Satisfaction,
    AgreementUse,
    PurchaseInfo
  },
  props: {
    visible: {
      type: Object,
      defualt: {},
      required: true
    }
  },
  data() {
    return {}
  },
  methods: {
    parentsSync(e) {
      this.visible = e
      this.$emit('visibleSync', this.visible)
    }
  }
}
</script>
