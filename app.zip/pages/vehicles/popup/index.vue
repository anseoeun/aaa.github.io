<template>
  <div class="">
    <!-- MS-DIS_030 색상추천정보 -->
    <recommend-color :pop-visible="visible" />

    <!-- MS-DIS_033 옵션추천정보 -->
    <recommend-option :pop-visible="visible" />

    <!-- MS-DIS_035 색상에따른트림변경안내 -->
    <trimChange-info :pop-visible="visible" />

    <!-- MS-DIS_036 색상에따른옵션추가안내 -->
    <option-change-info :pop-visible="visible" />

    <!-- MS-DIS_037 옵션에따른옵션/파즈추가안내 -->
    <parts-add-info :pop-visible="visible" />

    <!-- MS-DIS_038 옵션에따른옵션/파즈추가안내 -->
    <parts-dell-info :pop-visible="visible" />

    <!-- MS-DIS_041 지인할인추천안내 -->
    <friend-recommend :pop-visible="visible" />

    <!-- MS-DIS_069 세부만족도 -->
    <satisfaction :pop-visible="visible" />

    <!-- MS-DIS_083~085 시승신청약관레이어들 -->
    <agreement-use :pop-visible="visible" />

    <!-- MS-DIS_087 위치수정 -->
    <address-pop :pop-visible="visible" />

    <!-- MS-DIS_097 차량조합추천 -->
    <recommend-combination :pop-visible="visible" />

    <!-- MS-DIS_099 구매상세정보 -->
    <purchase-info :pop-visible="visible" />
  </div>
</template>

<script>
import RecommendColor from '~/components/page/vehicles/making/popup/RecommendColor'
import RecommendOption from '~/components/page/vehicles/making/popup/RecommendOption'
import TrimChangeInfo from '~/components/page/vehicles/making/popup/TrimChangeInfo'
import OptionChangeInfo from '~/components/page/vehicles/making/popup/OptionChangeInfo'
import PartsAddInfo from '~/components/page/vehicles/making/popup/PartsAddInfo'
import PartsDellInfo from '~/components/page/vehicles/making/popup/PartsDellInfo'
import FriendRecommend from '~/components/page/vehicles/popup/FriendRecommend'
import Satisfaction from '~/components/page/review/Satisfaction'
import AgreementUse from '~/components/page/vehicles/test-driving/popup/AgreementUse'
import AddressPop from '~/components/page/vehicles/test-driving/popup/Address'
import RecommendCombination from '~/components/page/vehicles/making/popup/RecommendCombination'
import PurchaseInfo from '~/components/page/review/PurchaseInfo'

export default {
  components: {
    RecommendColor,
    RecommendOption,
    TrimChangeInfo,
    OptionChangeInfo,
    PartsAddInfo,
    PartsDellInfo,
    FriendRecommend,
    Satisfaction,
    AgreementUse,
    AddressPop,
    RecommendCombination,
    PurchaseInfo
  },
  props: {
    visible: {
      type: Object,
      defualt: {},
      required: true
    }
  },
  data() {
    return {}
  },
  methods: {
    parentsSync(e) {
      this.visible = e
      this.$emit('visibleSync', this.visible)
    }
  }
}
</script>
