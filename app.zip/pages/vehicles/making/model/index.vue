<template>
  <div class="content-wrap">
    <div v-scrollfix class="content making-container">
      <div ref="visual" class="car-visual topfix">
        <div class="visual">
          <div class="visual-img"><v-img :src="visualBg.init" :alt="visualBg.alt"></v-img></div>
          <v-btn class="btn-expand" @click="visualExpand"><span class="offscreen">확대</span></v-btn>
          <v-btn class="btn-contract" @click="visualContract"><span class="offscreen">축소</span></v-btn>
        </div>
      </div>
      <div ref="caropt" class="car-option">
        <v-btn class="recommend" @click="popupVisible.recommendCombination = true">
          <p class="txt">
            잠깐! 선택이 어려우신가요? <br />
            나만의 캐스퍼를 추천해 드립니다.
          </p>
          <span class="img"></span>
        </v-btn>
        <!-- 트림 -->
        <trim
          @trimComparePop="popupVisible.compareSelect = true"
          @detailPop="popupVisible.detail = true"
         />
        <!-- 외장색상 -->
        <exterior-detail :pos.sync="position.outColorTop"
          @trimChangeInfoPop="popupVisible.trimChangeInfo = true"
          @optionChangeInfoPop="popupVisible.optionChangeInfo = true"
          @recommendColorPop="popupVisible.recommendColor = true"
         />
        <!-- 내장색상 -->
        <interior-detail :pos.sync="position.inColorTop" />
        <!-- 옵션 -->
        <option-detail :pos.sync="position.optionTop"
          @bagicPop="popupVisible.specGuide = true"
          @packagePop="popupVisible.packageGuide = true"
          @recommendOptionPop="popupVisible.recommendOption = true"
          @partsAddInfoPop="popupVisible.partsAddInfo = true"
          @partsDellInfoPop="popupVisible.partsDellInfo = true"
         />
        <!-- 요약 -->
        <opt-summary v-if="summaryShow" @close="summaryToggle" />
        <div class="fixed-price-wrap">
          <v-btn type="link" href="javascript:void(0);" :class="['fixed-price', {on:summaryShow}]" @click="summaryToggle">
            <div class="f-row total">
              <div class="left">총 차량 가격</div>
              <div class="right">
                <span class="account"> <b>13,890,000</b> 원 </span>
              </div>
            </div>
            <div class="f-row installment">
              <div class="left">초장기 할부(60개월) 시</div>
              <div class="right">
                <span class="account">월 <b>208,000</b> 원 </span>
              </div>
            </div>
          </v-btn>
        </div>
        <v-btn type="nlink" to="/" class="next-step">
            <span>2단계. 견적내기</span>
        </v-btn>

      </div>
      <!-- 팝업 -->
      <popup :visible.sync="popupVisible" />
    </div>
  </div>
</template>

<script>
import Trim from './Trim'
import ExteriorDetail from './ExteriorDetail'
import InteriorDetail from './InteriorDetail'
import OptionDetail from './OptionDetail'
import OptSummary from '~/components/page/vehicles/making/popup/Summary'
import Popup from '~/components/page/vehicles/making/popup'
export default {
  head() {
    return {
      title: '탐색 > 내 차 만들기',
      bodyAttrs: {
        style: 'overflow-y:hidden'
      }
    }
  },
  // layout: 'casper',
  layout: 'casper',
  components: {
    Trim,
    ExteriorDetail,
    InteriorDetail,
    OptionDetail,
    OptSummary,
    Popup
  },
  data() {
    return {
      headerH: 60,
      isExpend: false,
      optWidth: 0,
      configurationShow: false,
      summaryShow: false,
      visualStatus: 'init',
      visualBg: {
        init: require('~/assets/images/mycar/bg-casper-body.jpg'),
        alt: 'AX 스마트스트림 가솔린 1.1 터보 프리미엄 밀레니얼 A/T',
      },
      carImg: {
        src: require('~/assets/images/temp/temp-payment-car-model.png'),
        alt: 'AX 스마트스트림 가솔린 1.1 터보 프리미엄 밀레니얼 A/T'
      },
      bodyTypeVal: '',
      bodyType: [
        { value: 'suv', label: 'SUV' },
        { value: 'suvban', label: 'SUV 밴' }
      ],
      scrollSize: '',
      scrollIs: false,
      scrollBottom: false,
      //spredBtn
      spredBtnIs: false,
      spredBtn: 'btn-day',
      position: {
        outColorTop: 0,
        inColorTop: 0,
        optionTop: {
          option1Top: 0,
          option2Top: 0,
          option3Top: 0,
        }
      },
      //popup
      popupVisible: {
        friendRecommend: false,
        // packageGuide: false,
        detail: false,
        // specGuide: false,
        compareSelect: false,
        // trimChangeInfo: false,
        // optionChangeInfo: false,
        // partsAddInfo: false,
        // partsDellInfo: false,
        // recommendColor: false,
        // recommendOption: false,
        // recommendCombination: false,
      }
    }
  },
  computed: {

  },
  mounted() {
    this.popupVisible.friendRecommend = true //지인추천할인안내
  },
  methods: {
    summaryToggle() {
      this.summaryShow = !this.summaryShow
      if(this.summaryShow == false) {
        this.scrollBottom = false
        // this.setStyle()
      }
    },
    visualExpand() {
      this.$refs.visual.classList.add('expand')
    },
    visualContract() {
      this.$refs.visual.classList.remove('expand')
    }
  }
}
</script>