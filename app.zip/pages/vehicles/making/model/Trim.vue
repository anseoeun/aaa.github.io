<template>
  <div class="option-box border-line">
    <div class="box-header">
      <b class="tit">트림</b>
    </div>
    <div class="box-body">
      <v-radio
        v-model="trimListVal"
        class="radio-blue-round-button lg-size t-bewteen"
        type="button"
        :custom-label="true"
        :data="trimList"
      >
        <template slot-scope="props"
          ><span class="left"><span class="txt">{{ props.item.label }}</span>
            <v-btn type="icon" icon-class="icon-info" @click.stop="$emit('detailPop')"></v-btn>
          </span>
          <span class="right">{{ props.item.price }}원</span></template
        >
      </v-radio>
      <div class="opt-more">
        <v-btn type="button" class="more" @click="$emit('trimComparePop')">트림을 비교하면서 보고 싶으세요?</v-btn>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      trimListVal: '',
      trimList: [
        { value: 'trim1', label: '스마트', price: '12,100,000' },
        { value: 'trim2', label: '모던', price: '13,600,000' },
        { value: 'trim3', label: '인스퍼레이션', price: '15,700,000' }
      ],
    }
  },
}
</script>
