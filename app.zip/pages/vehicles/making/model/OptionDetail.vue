<template>
  <div class="etc-option">
    <!-- option -->
    <div ref="option1" class="option-box">
      <v-btn class="btn-option-open" @click="optExpend('option1')"></v-btn>
      <v-btn class="btn-option-close" @click="optContract('option1')"></v-btn>
      <div class="box-header">
        <b class="tit">옵션</b>
      </div>
      <div class="box-body">
        <!-- 2021-04-02 (ver1.1) 링크이동 -->
        <div class="opt-more">
          <v-btn type="button" class="more" @click="$emit('recommendOptionPop')">다른 분들은 어떤 옵션 조합을 선호할까요?</v-btn>
        </div>
        <div class="car-option-list">
          <ul>
            <li v-for="(item, index) in optionList" :key="index">
              <a
                href="javascript:void(0)"
                role="button"
                type="button"
                class="opt-bx"
                :class="[{ on: optionListVal.includes(item.value) }, {dim : true}]"
                @click="optionCheck(item, optionListVal);$emit('partsAddInfoPop')"
              >
                <div class="tit">
                  <span>{{ item.tit }}</span>
                </div>
                <div class="img">
                  <!-- 2021-04-02 (ver1.1) 코딩수정 -->
                  <v-btn class="btn-icon" @click.stop="item.package !== undefined ? $emit('packagePop') : $emit('bagicPop')">
                    <i class="icon-info"></i>
                  </v-btn>
                  <v-img :src="item.img" :alt="item.tit"></v-img>
                </div>
                <div class="price">+ {{ item.price }} 원</div>
              </a>
            </li>
          </ul>
        </div>
      </div>
    </div>
    <!-- H Genuine Accessories -->
    <div ref="option2" class="option-box">
      <v-btn class="btn-option-open" @click="optExpend('option2')"></v-btn>
      <v-btn class="btn-option-close" @click="optContract('option2')"></v-btn>
      <div class="box-header">
        <b class="tit">H Genuine<br />Accessories</b>
      </div>
      <div class="box-body">
        <div class="car-option-list">
          <ul>
            <li v-for="(item, index) in optionList" :key="index">
              <a
                href="javascript:void(0)"
                role="button"
                type="button"
                class="opt-bx"
                :class="{ on: optionListVal2.includes(item.value) }"
                @click="optionCheck(item, optionListVal2);$emit('partsDellInfoPop')"
              >
                <div class="tit">
                  <span>{{ item.tit }}</span>
                </div>
                <div class="img">
                  <!-- 2021-04-02 (ver1.1) 코딩수정 -->
                  <v-btn class="btn-icon" @click.stop="item.package !== undefined ? $emit('packagePop') : $emit('bagicPop')">
                    <i class="icon-info"></i>
                  </v-btn>
                  <v-img :src="item.img" :alt="item.tit"></v-img>
                </div>
                <div class="price">+ {{ item.price }} 원</div>
              </a>
            </li>
          </ul>
        </div>
      </div>
    </div>
    <!-- N Performance -->
    <div ref="option3" class="option-box">
      <v-btn class="btn-option-open" @click="optExpend('option3')"></v-btn>
      <v-btn class="btn-option-close" @click="optContract('option3')"></v-btn>
      <div class="box-header">
        <b class="tit">N Performance</b>
      </div>
      <div class="box-body">
        <div class="car-option-list">
          <ul>
            <li v-for="(item, index) in optionList" :key="index">
              <a
                href="javascript:void(0)"
                role="button"
                type="button"
                class="opt-bx"
                :class="{ on: optionListVal3.includes(item.value) }"
                @click="optionCheck(item, optionListVal3)"
              >
                <div class="tit">
                  <span>{{ item.tit }}</span>
                </div>
                <div class="img">
                  <!-- 2021-04-02 (ver1.1) 코딩수정 -->
                  <v-btn class="btn-icon" @click.stop="item.package !== undefined ? $emit('packagePop') : $emit('bagicPop')">
                    <i class="icon-info"></i>
                  </v-btn>
                  <v-img :src="item.img" :alt="item.tit"></v-img>
                </div>
                <div class="price">+ {{ item.price }} 원</div>
              </a>
            </li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  components: {

  },
  props:{
    pos: {
      type: Object,
      default: () => {},
    },
    headerHeight: {
      type: Number,
      default: 0,
    },
  },
  data() {
    return {
      position : {},
      optionListVal: [],
      optionListVal2: [],
      optionListVal3: [],
      optionList: [
        {
          value: 'option1',
          tit: '현대 스마트 센스 I',
          img: require('~/assets/images/temp/temp-car-option.png'),
          exp: '설명 설명 설명',
          price: '1,350,000'
        },
        {
          value: 'option2',
          tit: '네비게이션 패키지',
          img: require('~/assets/images/temp/temp-car-option.png'),
          exp: '설명 설명 설명',
          price: '1,350,000',
          package: true
        },
        {
          value: 'option3',
          tit: '에센셜 플러스',
          img: require('~/assets/images/temp/temp-car-option.png'),
          exp: '설명 설명 설명',
          price: '1,350,000'
        },
        {
          value: 'option4',
          tit: '현대 스마트 센스 I',
          img: require('~/assets/images/temp/temp-car-option.png'),
          exp: '설명 설명 설명',
          price: '1,350,000'
        },
        {
          value: 'option5',
          tit: '네비게이션 패키지',
          img: require('~/assets/images/temp/temp-car-option.png'),
          exp: '설명 설명 설명',
          price: '1,350,000',
          package: true
        },
        {
          value: 'option6',
          tit: '에센셜 플러스',
          img: require('~/assets/images/temp/temp-car-option.png'),
          exp: '설명 설명 설명',
          price: '1,350,000'
        }
      ],
    }
  },
  computed: {

  },
  mounted(){
    this.$nextTick(() => {
      this.setPos()
    })
  },
  methods: {
    setPos() {
      let rectCollection1 = this.$refs.option1.offsetTop
      let rectCollection2 = this.$refs.option2.offsetTop
      let rectCollection3 = this.$refs.option3.offsetTop
      this.position.option1Top = rectCollection1
      this.position.option2Top = rectCollection2
      this.position.option3Top = rectCollection3
      this.$emit('update:pos', this.position)
    },
    optionCheck(item, val) {
      if (val.indexOf(item.value) > -1) {
        let i = val.indexOf(item.value)
        val.splice(i, 1)
      } else {
        val.push(item.value)
      }
    },
    optExpend(type) {
      this.$emit('expend', true, type, this.setPos)
    },
    optContract(type) {
      this.$emit('contract', false, type, this.setPos)
    },
  }

}
</script>
