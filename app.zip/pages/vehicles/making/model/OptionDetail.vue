<template>
  <div class="etc-option border-line">
    <!-- option -->
    <div class="option-box border-line">
      <div class="box-header">
        <b class="tit">옵션</b>
      </div>
      <div class="box-body">
        <div class="opt-more">
          <v-btn type="button" class="more" @click="$emit('recommendOptionPop')">다른 분들은 어떤 옵션 조합을 선호할까요?</v-btn>
        </div>
        <div class="car-option-list">
          <ul>
            <li v-for="(item, index) in optionList" :key="index">
              <a
                href="javascript:void(0)"
                role="button"
                type="button"
                class="opt-bx"
                :class="[{ on: optionListVal.includes(item.value) }, {dim : true}]"
                @click="optionCheck(item, optionListVal);$emit('partsAddInfoPop')"
              >
                <div class="img">
                  <v-img :src="item.img" :alt="item.tit"></v-img>
                </div>
                <div class="desc">
                  <div class="tit">
                    <span>{{ item.tit }}</span>
                    <div class="right">
                      <v-btn class="btn-icon" @click.stop="item.package !== undefined ? $emit('packagePop') : $emit('bagicPop')">
                        <i class="icon-info"></i>
                      </v-btn>
                    </div>
                  </div>
                  <div class="price"><b>+ {{ item.price }}</b> 원</div>
                </div>
              </a>
            </li>
          </ul>
        </div>
      </div>
    </div>
    <!-- H Genuine Accessories -->
    <div class="option-box border-line">
      <div class="box-header">
        <b class="tit">H Genuine<br />Accessories</b>
      </div>
      <div class="box-body">
        <div class="car-option-list">
          <ul>
            <li v-for="(item, index) in optionList" :key="index">
              <a
                href="javascript:void(0)"
                role="button"
                type="button"
                class="opt-bx"
                :class="[{ on: optionListVal2.includes(item.value) }, {dim : true}]"
                @click="optionCheck(item, optionListVal2);$emit('partsAddInfoPop')"
              >
                <div class="img">
                  <v-img :src="item.img" :alt="item.tit"></v-img>
                </div>
                <div class="desc">
                  <div class="tit">
                    <span>{{ item.tit }}</span>
                    <div class="right">
                      <v-btn class="btn-icon" @click.stop="item.package !== undefined ? $emit('packagePop') : $emit('bagicPop')">
                        <i class="icon-info"></i>
                      </v-btn>
                    </div>
                  </div>
                  <div class="price"><b>+ {{ item.price }}</b> 원</div>
                </div>
              </a>
            </li>
          </ul>
        </div>
      </div>
    </div>
    <!-- N Performance -->
    <div class="option-box border-line">
      <div class="box-header">
        <b class="tit">N Performance</b>
      </div>
      <div class="box-body">
        <div class="car-option-list">
          <ul>
            <li v-for="(item, index) in optionList" :key="index">
              <a
                href="javascript:void(0)"
                role="button"
                type="button"
                class="opt-bx"
                :class="[{ on: optionListVal3.includes(item.value) }, {dim : true}]"
                @click="optionCheck(item, optionListVal3);$emit('partsAddInfoPop')"
              >
                <div class="img">
                  <v-img :src="item.img" :alt="item.tit"></v-img>
                </div>
                <div class="desc">
                  <div class="tit">
                    <span>{{ item.tit }}</span>
                    <div class="right">
                      <v-btn class="btn-icon" @click.stop="item.package !== undefined ? $emit('packagePop') : $emit('bagicPop')">
                        <i class="icon-info"></i>
                      </v-btn>
                    </div>
                  </div>
                  <div class="price"><b>+ {{ item.price }}</b> 원</div>
                </div>
              </a>
            </li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  components: {

  },
  props:{
    pos: {
      type: Object,
      default: () => {},
    },
    headerHeight: {
      type: Number,
      default: 0,
    },
  },
  data() {
    return {
      position : {},
      optionListVal: [],
      optionListVal2: [],
      optionListVal3: [],
      optionList: [
        {
          value: 'option1',
          tit: '현대 스마트 센스 I',
          img: require('~/assets/images/temp/temp-car-option.png'),
          exp: '설명 설명 설명',
          price: '1,350,000'
        },
        {
          value: 'option2',
          tit: '네비게이션 패키지',
          img: require('~/assets/images/temp/temp-car-option.png'),
          exp: '설명 설명 설명',
          price: '1,350,000',
          package: true
        },
        {
          value: 'option3',
          tit: '에센셜 플러스',
          img: require('~/assets/images/temp/temp-car-option.png'),
          exp: '설명 설명 설명',
          price: '1,350,000'
        },
        {
          value: 'option4',
          tit: '현대 스마트 센스 I',
          img: require('~/assets/images/temp/temp-car-option.png'),
          exp: '설명 설명 설명',
          price: '1,350,000'
        },
        {
          value: 'option5',
          tit: '네비게이션 패키지',
          img: require('~/assets/images/temp/temp-car-option.png'),
          exp: '설명 설명 설명',
          price: '1,350,000',
          package: true
        },
        {
          value: 'option6',
          tit: '에센셜 플러스',
          img: require('~/assets/images/temp/temp-car-option.png'),
          exp: '설명 설명 설명',
          price: '1,350,000'
        }
      ],
    }
  },
  computed: {

  },
  methods: {
    optionCheck(item, val) {
      if (val.indexOf(item.value) > -1) {
        let i = val.indexOf(item.value)
        val.splice(i, 1)
      } else {
        val.push(item.value)
      }
    },

  }

}
</script>
