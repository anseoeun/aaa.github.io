<template>
<!-- 내장색상 -->
<div class="option-box border-line">
    <div class="box-header">
        <b class="tit">내장색상</b>
    </div>
    <div class="box-body">
        <div class="optprice">
          <div class="left">
              <span class="name">블랙(NNB) + 칼라 포인트</span>
          </div>
          <div class="right"><span class="price"><b>+ 300,000</b> 원</span></div>
        </div>
        <v-radio v-model="inColorVal" :custom-label="true" :data="inColorList" class="in-color-List">
          <template slot-scope="props">
            <i slot="reference" class="in-color" :style="`background-image:url(${props.item.img})`"></i>
          </template>
        </v-radio>
    </div>
</div>
</template>

<script>
export default {
  components: {

  },
  props:{
    pos: {
      type: Number,
      default: 0,
    },
    headerHeight: {
      type: Number,
      default: 0,
    },
  },
  data() {
    return {
      inColorVal: '',
      inColorList: [
        {index:1, value: 'color1', exp:'회색회색회색회색', price: '0', img: require('~/assets/images/temp/temp-payment-car-model1.png')},
        {index:2, value: 'color2', exp: '블랙 모노', price: '50,000', img: require('~/assets/images/temp/temp-payment-car-model2.png')},
        {index:3, value: 'color3', exp: '톰보이 카키 매트', price: '10,000', img: require('~/assets/images/temp/temp-payment-car-model3.png')},
      ],
    }
  },

}
</script>
