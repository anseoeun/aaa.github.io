<template>
<!-- 외장색상 -->
<div ref="outcolor" class="option-box">
    <div class="box-header">
        <b class="tit">외장색상</b>
    </div>
    <div class="box-body">
        <!-- 2021-04-02 (ver1.1) 위치이동 및 태그추가 -->
        <div class="optprice">
          <div class="left">
              <span class="name">소울 트로닉 오렌지 펄</span>
          </div>
          <div class="right"><span class="price"><b>+ 0</b> 원</span></div>
        </div>
        <v-radio v-model="outColorVal" :custom-label="true" :data="outColorList" class="out-color-List">
            <template slot-scope="props">
            <v-popover trigger="hover" :placement="props.item.index % 5 == 0 || props.item.index % 6 == 0 ? 'top-end' : 'top-start'" style-type="popover-round">
                <p>
                {{ props.item.exp }}
                </p>
                <!-- 2021-04-02 (ver1.1) 이미지 src로 변경 -->
                <i v-if="props.item.type === 'shiny'" slot="reference" class="out-color shiny" :style="`background-image:url(${props.item.src})`"
                  @click="$emit('trimChangeInfoPop')"
                ></i>
                <i v-if="props.item.type === 'matte'" slot="reference" class="out-color matte" :style="`background-image:url(${props.item.src})`"
                  @click="$emit('optionChangeInfoPop')"
                ></i>
            </v-popover>
            </template>
        </v-radio>
        <!-- 2021-04-02 (ver1.1) 링크이동 -->
        <div class="opt-more">
          <v-btn type="button" class="more" @click="$emit('recommendColorPop')">가장 인기있는 색상을 알고 싶으세요?</v-btn>
        </div>
    </div>
 </div>
</template>

<script>
export default {
  components: {

  },
  props:{
    pos: {
      type: Number,
      default: 0,
    },
    headerHeight: {
      type: Number,
      default: 0,
    },
  },
  data() {
    return {
      outColorVal: '',
      outColorList: [
        {index:1, value: 'color1', type: 'shiny', exp:'회색', price: '0', src: require('~/assets/images/temp/temp-color-shiny-1.png')},
        {index:2, value: 'color2', type: 'shiny', exp: '그레이', price: '50,000', src: require('~/assets/images/temp/temp-color-shiny-2.png')},
        {index:3, value: 'color3', type: 'shiny', exp: '블랙', price: '10,000', src: require('~/assets/images/temp/temp-color-shiny-3.png')},
        {index:4, value: 'color4', type: 'shiny', exp: '하늘색', price: '0', src: require('~/assets/images/temp/temp-color-shiny-4.png')},
        {index:5, value: 'color5', type: 'shiny', exp: '소울 트로닉 오렌지 펄', src: require('~/assets/images/temp/temp-color-shiny-1.png')},
        {index:6, value: 'color6', type: 'shiny', exp: '블루', price: '10,000', src: require('~/assets/images/temp/temp-color-shiny-2.png')},
        {index:7, value: 'color7', type: 'matte', exp: '그레이 그레이', price: '40,000', src: require('~/assets/images/temp/temp-color-matt-1.png')},
        {index:8, value: 'color8', type: 'matte', exp: '톰보이 카키 매트', price: '70,000', src: require('~/assets/images/temp/temp-color-matt-2.png')},
      ],
    }
  },
  computed: {

  },
  mounted(){
    this.$nextTick(() => {
      let rectCollection = this.$refs.outcolor.offsetTop
      this.$emit('update:pos', rectCollection)
    })
  },
  methods: {

  }

}
</script>
