<template>
  <div class="content-wrap">
    <div v-scrollfix class="content vehicles model">
      <div class="car-model-wrap">
        <!-- comparision-model -->
        <div class="comparision-model-wrap topfix">
          <div class="comparision-model">
            <div class="model-wrap">
              <div class="model-list">
                <ul>
                  <template v-for="idx in 2">
                      <li v-if="idx <= descData.length" :key="idx">
                        <div class="desc">
                            <!-- <v-btn v-if="idx > 1" class="delete"><span class="offscreen">삭제</span></v-btn> -->
                            <div class="logo small-hide">{{ descData[idx - 1].logoTxt }}</div>
                            <div class="car-name">{{ descData[idx - 1].name }}</div>
                            <div class="car-img small-hide">
                              <v-img :src="descData[idx - 1].carImg.img" :alt="descData[idx - 1].carImg.alt"></v-img>
                            </div>
                            <div class="select small-hide">
                                <v-select
                                  v-model="descData[idx - 1].enginValue"
                                  :data="descData[idx - 1].enginList"
                                  placeholder="Select"
                                />
                                <v-select
                                  v-model="descData[idx - 1].trimValue"
                                  :data="descData[idx - 1].trimList"
                                  placeholder="Select"
                                />
                            </div>
                            <div class="total-price small-hide">
                              <div v-if="parseInt(descData[0].price) !== parseInt(descData[idx - 1].price)" class="margin small-hide">
                                <span v-if="parseInt(descData[0].price) > parseInt(descData[idx - 1].price)" class="down">{{ descData[0].price - descData[idx - 1].price | comma }} 원</span>
                                <span v-if="parseInt(descData[0].price) < parseInt(descData[idx - 1].price)" class="up">{{ descData[idx - 1].price - descData[0].price | comma }} 원</span>
                              </div>
                              <div class="account">
                                <div class="tit">총 구입 비용</div>
                                <div class="price"><b>{{ descData[idx - 1].price | comma }}</b> <span class="unit">원</span></div>
                              </div>
                            </div>
                            <ul class="matching-list small-hide">
                              <li>
                                <div class="tit">차량가격</div>
                                <div class="txt auto">{{ descData[idx - 1].carPrice }} 원</div>
                              </li>
                              <li>
                                <div class="tit">유지비용(3년)</div>
                                <div class="txt auto">{{ descData[idx - 1].supportPrice }} 원</div>
                              </li>
                            </ul>
                            <div class="small-hide">
                              <button v-if="descData[idx - 1].fixed" type="button" class="btn md blue">내차 만들기</button>
                              <button v-else type="button" class="btn md white">변경하기</button>
                            </div>
                            <div class="normal-hide">
                              <button v-if="descData[idx - 1].fixed" type="button" class="btn-more">내차 만들기</button>
                              <button v-else type="button" class="btn-more">변경하기</button>
                            </div>
                        </div>
                      </li>
                      <li v-else :key="idx">
                        <v-btn class="car-select">
                          <p class="top-txt">캐스퍼와 비교할<br />차량을 선택해 주세요</p>
                          <i class="plus"></i>
                          <p class="btm-txt small-hide">가장 낮은 가격 기준이<br />기본으로 선택되고 아래에서<br />각 차량별 변경 가능합니다.</p>
                        </v-btn>
                      </li>
                  </template>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <!-- // comparision-model -->
        <div class="comparison-wrap border-line">
            <div v-for="(item, index) in dataListLabel" :key="index" class="item-box">
              <strong class="title">{{ item }}</strong>
              <ul class="item-list">
                <template v-for="idx in 2">
                  <li v-if="idx <= dataList.length" :key="idx" class="item">
                    <div class="text dot" :class="{'nodata': dataList[idx - 1][Object.keys(dataList[idx - 1])[index]] == '' ||dataList[idx - 1][Object.keys(dataList[idx - 1])[index]] == '-'}">
                      {{ dataList[idx - 1][Object.keys(dataList[idx - 1])[index]] }}
                      <div v-if="Object.keys(dataList[idx - 1])[index] === 'displacement' && parseInt(dataList[0].displacement) !== parseInt(dataList[idx - 1].displacement)" class="right margin">
                        <span v-if="getNumber(dataList[0].displacement) > getNumber(dataList[idx - 1].displacement)" class="down">
                          {{ getNumber(dataList[0].displacement) - getNumber(dataList[idx - 1].displacement) }} <span class="unit">cc</span>
                        </span>
                        <span v-if="getNumber(dataList[0].displacement) < getNumber(dataList[idx - 1].displacement)" class="up">
                          {{ getNumber(dataList[idx - 1].displacement) - getNumber(dataList[0].displacement) }} <span class="unit">cc</span>
                        </span>
                      </div>
                    </div>
                  </li>
                  <li v-else :key="idx"></li>
                </template>
              </ul>
            </div>
        </div>

        <result />
      </div>
      <!-- 유의사항 -->
      <div class="notice-wrap border-line">
        <ul class="bullet-noti-list">
          <li>자동차 이미지는 참조용으로 구입 시점과 제조사 수시 변경으로 판매차량과 다를 수 있으니 해당 모델 판매점에 확인바랍니다.</li>
          <li>상기 내용은 고객님의 차량 구입 의사 결정에 도움을 드리고자 제공하는 서비스로 법적인 효력이 없으며, 실제 구입 시 가격 및 조건에 따라 차이가 있을 수 있습니다.</li>
          <li>상기 차량별 비교 정보는 각 제조업체의 카탈로그 및 홈페이지에 공개된 자료를 바탕으로 작성 되었습니다.</li>
          <li>수시로 최신정보를 갱신하고 있으나 간혹 업데이트가 늦어지는 경우가 발생할 수 있습니다.</li>
        </ul>
      </div>
      <!-- // 유의사항 -->

      <!-- 차량비교 팝업 -->
      <!-- <comparison-pop :visible="comparisonPop" @close="comparisonPop = false" @popFrequentlyCoparison="frequentlyCoparisonPop = true" /> -->

      <!-- footer -->
      <footer-comp />
    </div>
  </div>
</template>

<script>
import Footer from '~/components/layout/Footer'
import Result from './result'
export default {
  head() {
    return {
      title: '모델 > 모델비교',
    }
  },
  layout: 'sub',
  components: {
    FooterComp: Footer,
    Result,
  },
  filters:{
    comma(val){
      return String(val).replace(/\B(?=(\d{3})+(?!\d))/g, ',')
    }
  },
  data() {
    return {
      pageTitle: '', //페이지 제목 출력
      headerBtns: { //header 버튼 출력
        home: true,
      },
      topBreadcrumb: [
        { linkName: '모델', link: '/' },
        { linkName: '모델비교', link: '/' },
      ],
      descData: [
        {
          logoTxt:'캐스퍼',
          carImg:{
            img:  require('~/assets/images/temp/temp-car1.png'),
            alt: 'AX 스마트스트림 가솔린 1.1 터보 프리미엄 밀레니얼 A/T'
          },
          name:'캐스퍼',
          enginValue: '',
          enginList: [
            {value:'engin1', label:'엔진1'},
            {value:'engin2', label:'엔진2'},
            {value:'engin3', label:'엔진3'}
          ],
          trimValue: '',
          trimList: [
            {value:'trim1', label:'트림1'},
            {value:'trim2', label:'트림2'},
            {value:'trim3', label:'트림3'}
          ],
          price: '31800000',
          carPrice: '23,085,000',
          supportPrice: '19,858,734',
          fixed: true
        },
        {
          logoTxt:'제네시스',
          carImg:{
            img:  require('~/assets/images/temp/temp-payment-car-model.png'),
            alt: 'AX 스마트스트림 가솔린 1.1 터보 프리미엄 밀레니얼 A/T'
          },
          name:'G70',
          enginValue: '',
          enginList: [
            {value:'engin1', label:'엔진1'},
            {value:'engin2', label:'엔진2'},
            {value:'engin3', label:'엔진3'}
          ],
          trimValue: '',
          trimList: [
            {value:'trim1', label:'트림1'},
            {value:'trim2', label:'트림2'},
            {value:'trim3', label:'트림3'}
          ],
          price: '47085543 ',
          carPrice: '23,085,000',
          supportPrice: '19,858,734',
          fixed: false
        }
      ],
      // comparisonPop: false,
      frequentlyCoparisonPop: false,

      dataListLabel: ['복합연비', '배기량', '전장', '전폭', '전고'],
      dataList: [
        {
          combinedFuel: '15km/ℓ',
          displacement: '1598 CC',
          fullLength :'4,650 mm',
          fullWidth :'1,825 mm',
          fullHeight :'1,420 mm',
        },
        {
          combinedFuel: '12km/ℓ',
          displacement: '1400 CC',
          fullLength :'4,650 mm',
          fullWidth :'1,825 mm',
          fullHeight :'1,420 mm',
        },
      ]
    }
  },
  methods: {
    getNumber(value){
      return parseInt(value.replace(/[^0-9]/g,''))
    }
  }
}
</script>