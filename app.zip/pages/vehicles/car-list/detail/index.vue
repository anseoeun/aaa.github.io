<template>
  <div class="content-wrap">
    <div ref="content" class="content vehicles car-list-detail">
      <div class="car-desc">
        <div class="vr-360">
          <div class="car-img">
            <v-img :src="require('~/assets/images/temp/vr360.png')" alt="캐스퍼 스마트 스트림 가솔린 1.1 터보 프리미엄 밀레니얼 A/T"></v-img>
          </div>
          <v-btn class="btn-3d" @click="popConfig = true"><span class="offscreen">3D configurator 보기</span></v-btn>
        </div>
        <p class="text-sub">※ 차량이미지는 고객님의 이해를 돕기 위한 3D 이미지로 실제와 차이가 있을 수 있습니다.</p>
        <car-summary @viewMap="viewMap" />
      </div>
      <!-- 상세 -->
      <div class="car-detail">

        <v-tab v-scrolltab="'cardetail'" class="tab-sub scroll-tab" :data="tabList" :contents="true">
          <template slot="contents">
            <div data-id="tab1">
              <!-- 판촉차 상세 설명 -->
              <promotion />
            </div>
            <div data-id="tab2">
              <!-- 상세 스펙 -->
              <spec />
            </div>
            <div data-id="tab3">
              <!-- 구매절차 및 유의사항 -->
              <registration-info />
            </div>
            <div data-id="tab4">
              <!-- 배달탁송및인수절차안내 -->
              <delivery />
            </div>
            <div data-id="tab5">
              <!-- 직접인수방법안내 -->
              <take-out-info />
            </div>
          </template>
        </v-tab>

      </div>
      <!-- 유사차량 추천영역 -->
      <recommendation />
    </div>
    <div class="fixed-btm-area">
      <div v-btmlayer class="btm-layer">
        <div class="tog-btn">
          <v-btn class="btn"><span class="offscreen">열기</span></v-btn>
        </div>
        <div class="layer-content">
          <div class="vehicles-account hide">
            <div class="info-box">
              <div class="info-grid-list bold-all">
                <ul>
                  <li>
                    <strong class="info-title">차량금액</strong>
                    <div class="info-group">
                      <span class="price">
                        <strong>17,830,000</strong> 원
                      </span>
                    </div>
                  </li>
                  <li>
                    <strong class="info-title t-blue">기본할인</strong>
                    <div class="info-group">
                      <span class="price t-blue">
                        <strong class="t-blue">- 1,000,000</strong> 원
                      </span>
                    </div>
                  </li>
                  <li class="discount">
                    <strong class="info-title t-blue">할인금액</strong>
                    <div class="info-group">
                      <span class="price t-blue">
                        <strong class="t-blue">- 1,000,000</strong> 원
                      </span>
                    </div>
                    <div class="discount-list">
                      <ul>
                        <li>기본할인 <span class="price">- 300,000 원</span></li>
                        <li>기획전할인 <span class="price">- 500,000 원</span></li>
                      </ul>
                    </div>
                  </li>
                  <li>
                    <div class="info-title">
                      <strong>탁송료</strong>
                      <!-- 팝업연결 예정 -->
                      <v-btn class="btn white sm" @click="deliverySelectPop = true">변경</v-btn>
                    </div>
                    <div class="info-group">
                      <span class="text-info">서울시 기준</span>
                      <span class="price"><strong class="text-head">270,000</strong> 원</span>
                    </div>
                  </li>
                  <li>
                    <div class="info-title">
                      <strong>직접인수</strong>
                      <v-popover trigger="click" placement="bottom-start">
                        <p>전시 차량은 전시장으로 직접 방문하셔서 차량 상태 확인 후 인수하셔야 합니다.</p>
                        <v-btn slot="reference"><i class="icon-help"></i></v-btn>
                      </v-popover>
                    </div>
                  </li>
                  <li class="total-price">
                    <strong class="info-title">판매금액</strong>
                    <div class="info-group">
                      <span class="price t-black">
                        <strong>17,830,000</strong> 원
                      </span>
                    </div>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="fixed-btn">
        <v-btn type="nlink" to="/" class="btn blue">견적내기</v-btn>
      </div>
    </div>

    <delivery-select :visible="deliverySelectPop" @close="deliverySelectPop = false" />
  </div>
</template>

<script>
import CarSummary from '~/components/page/vehicles/car-list/detail/Summary'
import Promotion from '~/components/page/vehicles/car-list/detail/Promotion'
import Spec from '~/components/page/vehicles/car-list/detail/Spec'
import RegistrationInfo from '~/components/page/vehicles/car-list/detail/RegistrationInfo'
import Delivery from '~/components/page/vehicles/car-list/detail/Delivery'
import TakeOutInfo from '~/components/page/vehicles/car-list/detail/TakeOutInfo'
import Recommendation from '~/components/page/vehicles/car-list/detail/Recommendation'
import DeliverySelect from '~/components/page/vehicles/popup/DeliverySelect'
export default {
  head() {
    return {
      title: '탐색 > 상세'
    }
  },
  layout: 'sub',
  components: {
    CarSummary,
    Promotion,
    Spec,
    RegistrationInfo,
    Delivery,
    TakeOutInfo,
    Recommendation,
    DeliverySelect
  },
  data() {
    return {
      headerBtns:{
        home: true,
      },
      tabStatus: 'tab1',
      tabList: [
        { value: 'tab1', label: '판촉차 상세설명' },
        { value: 'tab2', label: '상세 스펙' },
        { value: 'tab3', label: '구매절차 및 유의사항' },
        { value: 'tab4', label: '배달탁송 및 인수 절차안내' },
        { value: 'tab5', label: '직접 인수 방법안내' }
      ],
      deliverySelectPop: false,
    }
  },
  methods: {
    viewMap(){
      let content = this.$refs.content
      let margin = document.querySelector('.header-area').clientHeight
      let btn = document.querySelector('.tab-menu').querySelector('li:last-child')
      btn.click()
     setTimeout(() => {
      let map = document.querySelector('.map-area')
      content.scrollTop = map.offsetTop - margin
     }, 300)
    }
  }
}
</script>
