<template>

  <v-popup
    :footer="['cancel','nonAgree', 'confirm']"
    :visible="popVisible.visible3"
    :full-popup="true"
    class="full-popup no-header"
    @close="
      $emit('close')
    "
  >

    <template slot="body">
      <div class="body-title">
        <div class="section-title">스마트</div>
        <p class="header-description">스마트 트림의 자세한 정보입니다.</p>
      </div>
      컨텐츠 <br />
      컨텐츠 <br />
      컨텐츠 <br />
      컨텐츠 <br />
      컨텐츠 <br />
      컨텐츠 <br />
      컨텐츠 <br />
      컨텐츠 <br />
      컨텐츠 <br />
      컨텐츠 <br />
      컨텐츠 <br />
      컨텐츠 <br />
      컨텐츠 <br />
      컨텐츠 <br />
      컨텐츠 <br />
      컨텐츠 <br />
      컨텐츠 <br />
      컨텐츠 <br />
      컨텐츠 <br />
      컨텐츠 <br />
      컨텐츠 <br />
      컨텐츠 <br />
      컨텐츠 <br />
      컨텐츠 <br />
      컨텐츠 <br />
      컨텐츠 <br />
      컨텐츠 <br />
      컨텐츠 <br />
      컨텐츠 <br />
      컨텐츠 <br />
      컨텐츠 <br />
      컨텐츠 <br />
      컨텐츠 <br />
      컨텐츠 <br />
      컨텐츠 <br />
    </template>
    <template slot="footer">

    </template>
  </v-popup>
</template>

<script>
import { VPopup } from '~/components/element'
export default {
  components: {
    VPopup
  },
  props: {
    popVisible: {
      type: Object,
      defualt: {},
      required: true
    },
  },

}
</script>

