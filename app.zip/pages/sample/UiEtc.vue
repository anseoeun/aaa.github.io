<template>
  <div class="content samplePage">
    <h2>border-line</h2>
    <div class="border-line"></div>
  </div>
</template>

<script>
export default {
  layout:'sub',
  components: {},
  data() {
    return {
    }
  },
}
</script>
