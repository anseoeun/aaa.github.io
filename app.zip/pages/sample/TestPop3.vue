<template>

  <v-popup
    :footer="['cancel','nonAgree', 'confirm']"
    :visible="popVisible.visible2"
    :full-popup="true"
    class="full-popup"
    @close="
      $emit('close')
    "
  >
    <template slot="header">
      <div class="title">타이틀1</div>
    </template>
    <template slot="body">
      팝업내용1
      <p class="bullet">팝업용 bullet : 26px, regular, #666</p>
      <p class="bullet-star">팝업용 bullet : 26px, regular, #666</p>

      <div class="border-line">
        위보더라인 컨텐츠 <br />
        위보더라인 컨텐츠 <br />
        위보더라인 컨텐츠 <br />
        위보더라인 컨텐츠 <br />
      </div>
      <div class="border-line-btm">
        아래보더라인 컨텐츠 <br />
        아래보더라인 컨텐츠 <br />
        아래보더라인 컨텐츠 <br />
        아래보더라인 컨텐츠 <br />
      </div>
    </template>
    <template slot="footer">
      <div class="btn-group round">
        <v-btn class="btn">확인</v-btn>
      </div>
      <div class="btn-group popup-footer-btn">
        <v-btn class="btn btn-gray">확인</v-btn>
        <v-btn class="btn">확인</v-btn>
      </div>
    </template>
  </v-popup>
</template>

<script>
import { VPopup } from '~/components/element'
export default {
  components: {
    VPopup
  },
  props: {
    popVisible: {
      type: Object,
      defualt: {},
      required: true
    },
  },

}
</script>

