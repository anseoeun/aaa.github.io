<template>
  <div class="content samplePage">
    <h2>matching-box</h2>
    <div class="matching-box">
      <div class="box-wrap">
        <div class="box-tit">결제정보</div>
        <div class="box-desc">
          <div class="info-grid-list line">
            <ul>
              <li>
                <div class="info-title">계약금액</div>
                <div class="info-group">100,000 원</div>
              </li>
              <li>
                <div class="info-title">계약금액</div>
                <div class="info-group">100,000 원</div>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
    <br />
    <h2>match-box</h2>
    <div class="match-box">
      <div class="title">배달탁송 안내</div>
      <div class="desc">
        결제 안료 후 탁송 기간은 일반적으로 3~5일 (주말, 공휴일 제외) 소요되나 상황에 따라 달라질 수 있습니다. H Genuine Accessories, N Performance 파츠 추가 차량은 장착 기간으로 인해 추가 시일이 소요될 수 있습니다.
        <p class="bullet">인해 추가 시일이 소요될 수 있습니다.</p>
      </div>
    </div>
    <br />
    <h2>match-tog-box</h2>
    <div class="match-tog-box">
      <div class="match-box">
        <v-btn class="title" @click="setAct(0)">
          성능
          <i :class="['icon-tog-arr off-gray', { on: isAct(0) }]"></i>
        </v-btn>
        <div v-if="isAct(0)" class="desc info-grid-list">
          성능 컨텐츠 <br />
          성능 컨텐츠 <br />
          성능 컨텐츠 <br />
          성능 컨텐츠 <br />
          성능 컨텐츠 <br />
        </div>
      </div>
      <div class="match-box">
        <v-btn class="title" @click="setAct(1)">
          연비
          <i :class="['icon-tog-arr', { on: isAct(1) }]"></i>
        </v-btn>
        <div v-if="isAct(1)" class="desc info-grid-list">
          연비 컨텐츠 <br />
          연비 컨텐츠 <br />
          연비 컨텐츠 <br />
          연비 컨텐츠 <br />
          연비 컨텐츠 <br />
        </div>
      </div>
    </div>

    <br />
    <h2>info-detail</h2>
    <section class="info-detail border-line" :class="{ open: isOptionsShow }">
      <v-btn class="summary-info" :class="{ active: isOptionsShow }" @click="isOptionsShow = !isOptionsShow">
        <h1 class="title">경제성/환경</h1>
        <i class="icon-toggle-arr" :class="{'on':isOptionsShow}"></i>
        <i class="icon-toggle-arr black" :class="{'on':isOptionsShow}"></i>
        <i class="icon-toggle-arr off-gray" :class="{'on':isOptionsShow}"></i>
      </v-btn>
      <div v-show="isOptionsShow" class="detail-info">
          컨텐츠컨텐츠 <br />
          컨텐츠컨텐츠 <br />
          컨텐츠컨텐츠 <br />
      </div>
    </section>
    <br /><br />
  </div>
</template>

<script>
export default {
  layout:'sub',
  components: {},
  data() {
    return {
      isOptionsShow: false,
      listSelected: [false, false],
    }
  },
    methods: {
    setAct(index) {
      if (this.listSelected[index] === false) {
        this.$set(this.listSelected, index, true)
      } else {
        this.$set(this.listSelected, index, false)
      }
    },
    isAct(index) {
      return this.listSelected[index] === true
    },
  },
}
</script>
