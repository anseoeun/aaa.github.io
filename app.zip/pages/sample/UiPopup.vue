<template>
  <div class="content samplePage">
    <h2>팝업 (Boolean 타입, 닫기버튼없는타입)</h2>
    <v-btn class="btn md blue" type="button" @click="popVisible = true"
      >팝업오픈</v-btn
    >
    <h2>팝업 (Object 타입)</h2>
    <v-btn class="btn md blue" type="button" @click="popupVisible.visible = true"
      >팝업오픈</v-btn
    >
    <h2>팝업 (Full 타입)</h2>
    <v-btn class="btn md blue" type="button" @click="popupVisible.visible2 = true"
      >팝업오픈</v-btn
    >
    <h2>팝업 (Full 타입 -헤더 없는타입)</h2>
    <v-btn class="btn md blue" type="button" @click="popupVisible.visible3 = true"
      >팝업오픈</v-btn
    >

    <test-pop :visible="popVisible" :is-close="false" @close="popVisible = false"></test-pop>
    <test-pop2 :pop-visible="popupVisible" @close="popupVisible.visible = false"></test-pop2>
    <test-pop3 :pop-visible="popupVisible" @close="popupVisible.visible2 = false"></test-pop3>
    <test-pop4 :pop-visible="popupVisible" @close="popupVisible.visible3 = false"></test-pop4>

  </div>
</template>

<script>
import TestPop from './TestPop'
import TestPop2 from './TestPop2'
import TestPop3 from './TestPop3'
import TestPop4 from './TestPop4'
export default {
  layout:'sub',
  components: {
    TestPop,
    TestPop2,
    TestPop3,
    TestPop4,
  },
  data() {
    return {
      popVisible: false,
      popupVisible: {
        visible: false,
        visible2: false,
        visible3: false
      }
    }
  },
}
</script>
