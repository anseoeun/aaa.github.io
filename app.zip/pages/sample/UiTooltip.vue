<template>
  <div class="samplePage">
    <h2>기본 (bottom-start)</h2>
          <v-popover trigger="click" placement="bottom-start">
      <!--
        placement="bottom-start"
        placement="top-start"
        placement="bottom"
        placement="right"
       -->
      <p>
        M포인트는 M계열 카드로 어디서든 쓰면 쓸수록 더 쌓아주는 포인트로 다양한 영역에서 사용할 수 있습니다.
      </p>
      <v-btn slot="reference"><i class="icon-help"></i></v-btn>
    </v-popover>
  </div>
</template>

<script>
import { VPopover } from '~/components/element'
export default {
  layout: 'sub',
  components: {
    VPopover
  },
  data() {
    return {

    }
  },
}
</script>
