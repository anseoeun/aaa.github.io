<template>
  <div class="content samplePage">
    <h2>단독형</h2>
      <v-checkbox :one-check="true" :checked.sync="checkboxDataVal">단독체크박스</v-checkbox>
      <v-checkbox :one-check="true" :checked.sync="checkboxDataVal" :disabled="true">단독체크박스</v-checkbox>

    <h2>리스트형</h2>
      <v-checkbox v-model="checkboxDataListVal" :data="checkboxListData" />

    <h2>커스텀 리스트형</h2>
      <v-checkbox v-model="checkboxDataListVal" :custom-label="true" :data="checkboxListData">
        <template slot-scope="props">{{ props.item.label }} {{ props.item.text }}</template>
      </v-checkbox>

    <h2>전체체크 : 리스트형으로 사용시</h2>
      <v-checkbox v-model="checkboxDataVal2" :data="checkboxListData2" all-chk-name="전체체크" />

    <h2>전체체크 : 단독 + 리스트형으로 사용시</h2>
      <v-checkbox :one-check="true" :checked.sync="allCheck" @change="allCheckChange">전체체크</v-checkbox>
      <v-checkbox v-model="checkboxDataVal1" :data="checkboxListData1" @change="checkChange" />

    <br />
    <br />
    <h2>디자인형 (block)</h2>
      <v-checkbox v-model="checkboxDataListVal" :data="checkboxListData" class="block" />
    <h2>디자인형 (half)</h2>
      <v-checkbox v-model="checkboxDataListVal" :data="checkboxListData" class="half" />
    <h2>디자인형 (sm-size)</h2>
      <v-checkbox :one-check="true" :checked.sync="checkboxDataVal" class="sm-size">단독체크박스</v-checkbox>
  </div>
</template>

<script>
import { VCheckbox } from '~/components/element'
export default {
  layout: 'sub',
  components: {
    VCheckbox,
  },
  data() {
    return {
      // 체크박스
      checkboxDataVal: false,
      checkboxDataListVal: [],
      checkboxListData: [
        { value: 'check1', label: '체크박스1', text:'텍스트1' },
        { value: 'check2', label: '체크박스2', text:'텍스트2' },
        { value: 'check3', label: '체크박스3', text:'텍스트3' },
        { value: 'check4', label: '체크박스4', text:'텍스트4' },
      ],
      //전체체크
      allCheck: false,
      checkboxDataVal1: [],
      checkboxListData1: [
        { value: 'check1', label: '체크박스1', text:'텍스트1' },
        { value: 'check2', label: '체크박스2', text:'텍스트2' },
        { value: 'check3', label: '체크박스3', text:'텍스트3' },
        { value: 'check4', label: '체크박스4', text:'텍스트4' },
      ],
      checkboxDataVal2: [],
      checkboxListData2: [
        { value: 'check1', label: '체크박스1', text:'텍스트1' },
        { value: 'check2', label: '체크박스2', text:'텍스트2' },
        { value: 'check3', label: '체크박스3', text:'텍스트3' },
        { value: 'check4', label: '체크박스4', text:'텍스트4' },
      ],
    }
  },
  methods: {
    allCheckChange() {
    if(this.allCheck){
        let val = []
        this.checkboxListData1.forEach((value, index) => {
            val.push(value.value)
        })
        this.allCheck = true
        this.checkboxDataVal1 = val
      }else{
       this.allCheck = false
       this.checkboxDataVal1 = ['']
      }
    },
    checkChange() {
       if(this.checkboxListData1.length !== this.checkboxDataVal1.length) {
           this.allCheck = false
       }else{
           this.allCheck = true
       }
    }
  },
}
</script>
