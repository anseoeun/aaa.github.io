<template>
  <div class="content-wrap">
    <div class="content samplePage">
      <h2>버튼 타입</h2>
      <p class="text-main" style="margin-bottom:10px">버튼태그</p>
      <v-btn class="btn md black">button 버튼</v-btn>
      <v-btn class="btn md white">button 버튼</v-btn>
      <v-btn class="btn md blue line">button 버튼</v-btn>
      <br /><br />
      <p class="text-main" style="margin-bottom:10px">넉스트버튼 : type="nlink"</p>
      <v-btn class="btn lg blue" type="nlink" to="/"
        >넉스트 버튼</v-btn
      >
      <br /><br />
      <p class="text-main" style="margin-bottom:10px">a태그버튼(외부링크) : type="link"</p>
      <v-btn
        class="btn lg gray"
        type="link"
        href="https://kr.vuejs.org/v2/guide/class-and-style.html"
        >a태그 버튼(외부링크)</v-btn
      >
      <br /><br />
      <h2>버튼 사이즈 - lg, md, sm / full</h2>
      <v-btn class="btn lg black">btn lg black</v-btn>
      <v-btn class="btn md white full">btn md white full</v-btn>
      <v-btn class="btn md white">btn md white</v-btn>
      <v-btn class="btn sm blue">btn sm blue</v-btn>
      <br /><br />
      <h2>버튼 컬러</h2>
      <v-btn class="btn md black">btn md black</v-btn>
      <v-btn class="btn md blue">btn md blue</v-btn>
      <v-btn class="btn md skyblue">btn md skyblue</v-btn>
      <v-btn class="btn md gray">btn md blue</v-btn>
      <v-btn class="btn md white">btn md white</v-btn>
      <v-btn class="btn md blue line">btn md blue line</v-btn>
      <v-btn class="btn md gray line">btn md gray line</v-btn>
      <br /><br />
      <h2>예제</h2>
      <v-btn class="btn lg blue">바로 구매하기</v-btn>
      <v-btn class="btn lg blue line">상세 견적내기</v-btn>
      <br /><br />
      <p class="text-main" style="margin-bottom:10px">* line에 버튼 두개일때 class="btn-wrap"</p>
      <div class="btn-wrap">
        <v-btn class="btn md blue">동의</v-btn>
        <v-btn class="btn md white">동의안함</v-btn>
      </div>
      <br />
      <p class="text-main" style="margin-bottom:10px">* line에 버튼 두개일때(100%) class="btn-wrap full"</p>
      <div class="btn-wrap full">
        <v-btn class="btn lg gray">초기화</v-btn>
        <v-btn class="btn lg blue">적용</v-btn>
      </div>
      <br />
      <h2>더보기 스타일</h2>
      <v-btn class="btn-more" type="nlink">더보기</v-btn>
      <h2>아이콘 버튼</h2>
       <v-btn type="icon" icon-class="icon-info"></v-btn>
      <h2>링크 버튼</h2>
      <v-btn class="btn-link" type="nlink">확인하기</v-btn>
      <h2>focus시밑줄될예정인 버튼</h2>
      <v-btn class="btn-normal" type="nlink">버튼</v-btn>
      <br />
      <br />
      <br />
    </div>
    <div class="fixed-btm-area">
      <div class="fixed-btn">
        <v-btn class="btn skyblue line">홈으로</v-btn>
        <v-btn class="btn blue">마이페이지</v-btn>
      </div>
    </div>
  </div>
</template>

<script>
import { VBtn} from '~/components/element'
export default {
  layout: 'sub',
  components: {
    VBtn,
  },
  data() {
    return {

    }
  },
}
</script>
