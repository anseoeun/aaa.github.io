<template>
  <div class="content samplePage">
    <div class="text-main">@include sectionTitle($color) / class="section-title" / 52px</div>
    <br />
    <div class="section-title thin">고객님, 안녕하세요 : thin</div>
    <div class="section-title">고객님, 안녕하세요</div>
    <div class="section-title bold">고객님, 안녕하세요 : bold</div>

    <br />

    <div class="text-main" style="border-top:1px solid #eee;padding-top: 1rem;">@include headTitle($color) / class="head-title" / 44px</div>
    <br />
    <div class="head-title thin">차량 선택 및 견적 : thin</div>
    <div class="head-title">차량 선택 및 견적</div>
    <div class="head-title bold">차량 선택 및 견적 : bold</div>

    <br />

    <div class="text-main" style="border-top:1px solid #eee;padding-top: 1rem;">@include mainTitle($color) / class="main-title" / 40px</div>
    <br />
    <div class="main-title thin">자주하는 질문 : thin</div>
    <div class="main-title">자주하는 질문</div>
    <div class="main-title bold">자주하는 질문 : bold</div>

    <br />

    <div class="text-main" style="border-top:1px solid #eee;padding-top: 1rem;">@include textHead($color) / class="text-head" / 32px</div>
    <br />
    <div class="text-head thin">상환방법 : thin</div>
    <div class="text-head">상환방법</div>
    <div class="text-head bold">상환방법 : bold</div>

    <br />

    <div class="text-main" style="border-top:1px solid #eee;padding-top: 1rem;">@include textMain($color) / class="text-main" / 28px (default)</div>
    <br />
    <div class="text-main thin">할부한도를 조회해 주세요. : thin</div>
    <div class="text-main">할부한도를 조회해 주세요.</div>
    <div class="text-main bold">할부한도를 조회해 주세요. : bold</div>

    <br />

    <div class="text-main" style="border-top:1px solid #eee;padding-top: 1rem;">@include textSub($color) / class="text-sub" / 26px</div>
    <br />
    <div class="text-sub thin">장애인 고객 및 가족분들을 위한 차량 선택 및 견적 가이드 : thin</div>
    <div class="text-sub">장애인 고객 및 가족분들을 위한 차량 선택 및 견적 가이드</div>
    <div class="text-sub bold">장애인 고객 및 가족분들을 위한 차량 선택 및 견적 가이드 : bold</div>

    <br /><br />
    <div style="border-top:1px solid #999"></div>
    <br />

    <h2>bullet : 24px, light, #666</h2>
    <p class="bullet">면세구분 선택에 따라 개별소비세 과세/면세가 계산되어 차량 총 견적 금액에 적용됩니다.</p>
    <br />
    <ul class="bullet-list">
      <li>사전계약 차량은 추후 등록하신 주계약자 휴대전화번호로 공식 계약 일정을 공지합니다.</li>
      <li>공식계약 마감일 이내에 계약으로 전환해주세요.</li>
      <li>공식계약 일정 내 계약하지 않는 경우 자동으로 사전계약이 취소됩니다.</li>
      <li>추후 판매개시 및 공식계약 진행 시 차량 모델/옵션을 변경할 수 있습니다.</li>
      <li>자세한 사전계약내역 확인 및 계약 진행사항은 마이페이지에서 확인 가능합니다.</li>
    </ul>

    <br />

    <h2>bullet-star : 24px, light, #666</h2>
    <p class="bullet-star">아래 사항을 반드시 확인해 주세요.</p>
    <br />
    <ul class="bullet-star-list">
      <li>모델, 색상, 옵션 등 차량 정보를 변경할 수 있습니다. [차량정보 변경] 버튼을 클릭하고 나만의 캐스퍼 만들기로 이동하여 다른 사양으로 변경해 보세요</li>
      <li>차량정보 변경은 결제 전까지 언제든 가능합니다. 단, 변경하시는 품목에 따라 차량 가격이 달라질 수 있습니다.</li>
    </ul>

    <h2>bullet-noti : 24px, light, #666</h2>
    <p class="bullet-noti">아래 사항을 반드시 확인해 주세요.</p>
    <br />
    <ul class="bullet-noti-list">
      <li>모델, 색상, 옵션 등 차량 정보를 변경할 수 있습니다. [차량정보 변경] 버튼을 클릭하고 나만의 캐스퍼 만들기로 이동하여 다른 사양으로 변경해 보세요</li>
      <li>차량정보 변경은 결제 전까지 언제든 가능합니다. 단, 변경하시는 품목에 따라 차량 가격이 달라질 수 있습니다.</li>
    </ul>

  </div>
</template>

<script>
export default {
  layout:'sub',
  components: {},
  data() {
    return {
      isAgree: false,
      isAgree2: false,
    }
  },
}
</script>
