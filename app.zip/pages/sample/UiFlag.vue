<template>
  <div style="width: 1200px; margin: 0 auto; padding: 30px 0">

    <h2 class="bold">* Default</h2><br />
    <p style="margin-bottom:2px;">list : flag-list</p>
    <ul class="flag-list">
      <li>전자서명 요청</li>
      <li>계약금 입금 요청</li>
      <li>1:1 문의 답변</li>
      <li>계약 해지 안내</li>
      <li>전자서명 미완료 안내</li>
      <li>시승예약</li>
    </ul>
    <br />
    <p style="margin-bottom:2px;">single : flag</p>
    <span class="flag">전자서명 요청</span>


    <br /><br /><br />

    <h2 class="bold">* Color : 4color</h2><br />

    <p style="margin-bottom:2px;">list : flag-list</p>
    <ul class="flag-list">
      <li class="bl">class="bl"</li>
      <li class="rd">class="rd"</li>
      <li class="gr">class="gr"</li>
      <li class="br">class="br"</li>
    </ul>
    <br />

    <p style="margin-bottom:2px;">single : flag</p>
    <span class="flag bl">class="bl"</span>
    <br /><br />
    <span class="flag rd">class="rd"</span>
    <br /><br />
    <span class="flag gr">class="gr"</span>
    <br /><br />
    <span class="flag br">class="br"</span>

    <br /><br /><br /><br /><br />

    <h2 class="bold">목록/상세</h2><br />
    <ul class="flag-list">
      <li class="gr">기획전</li>
      <li class="gr">기획전(리퍼)</li>
      <li class="br">동일사양</li>
      <li class="bl">특별주문차</li>
      <li class="bl">사전계약</li>
    </ul>
    <br /><br />

    <h2 class="bold">견적</h2><br />
    <ul class="flag-list">
      <li class="rd">할부금융</li>
      <li class="rd">현금/신용카드</li>
      <li class="rd">캐스퍼전용카드</li>
    </ul>

    <br /><br />

    <h2 class="bold">시승신청</h2><br />
    <ul class="flag-list">
      <li class="gr">캐스퍼 전용</li>
    </ul>

    <br /><br />

    <h2 class="bold">전시장 안내</h2><br />
    <ul class="flag-list">
      <li class="gr">전용전시장</li>
      <li class="rd">팝업전시</li>
      <li class="gr">상담가능</li>
      <li class="gr">시승가능</li>
      <li class="br">셀프체험</li>
    </ul>

  </div>
</template>
<script>
export default {
  data() {
    return {
    }
  },
}
</script>

<style lang="scss">
@import '~/assets/style/shop.scss';
</style>
