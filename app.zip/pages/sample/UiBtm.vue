<template>
  <div class="content-wrap">
    <div class="content samplePage">



    </div>
    <div class="fixed-btm-area">
      <div v-btmlayer class="btm-layer">
        <div class="tog-btn">
          <v-btn class="btn"><span class="offscreen">열기</span></v-btn>
        </div>
        <div class="layer-content">
          <div>
            위 보이는 컨텐츠 <br />
            위 보이는 컨텐츠 <br />
          </div>
          <div class="hide">
            숨김 컨텐츠 <br />
            숨김 컨텐츠 <br />
            숨김 컨텐츠 <br />
            숨김 컨텐츠 <br />
            숨김 컨텐츠 <br />
          </div>
          <div>
            아래 보이는 컨텐츠 <br />
            아래 보이는 컨텐츠 <br />
          </div>
        </div>
      </div>
      <div class="fixed-btn">
        <v-btn type="nlink" to="/" class="btn blue">사전계약하기</v-btn>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  layout:'sub',
  components: {},
  data() {
    return {
    }
  },
}
</script>
