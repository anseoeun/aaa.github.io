<template>
  <div class="content samplePage">
    <v-btn type="nlink" to="./UiButton" class="btn md white r">UiButton (버튼)</v-btn>
    <br /><br />
    <v-btn type="nlink" to="./UiSlider" class="btn md white r">UiSlider (슬라이더)</v-btn>
    <br /><br />
    <v-btn type="nlink" to="./UiPage" class="btn md white r">UiPage (페이징)</v-btn>
    <br /><br />
    <v-btn type="nlink" to="./UiForm" class="btn md white r">UiForm (폼)</v-btn>
    <br /><br />
    <v-btn type="nlink" to="./UiFormError" class="btn md white r">UiFormError (폼에러)</v-btn>
    <br /><br />
    <v-btn type="nlink" to="./UiCheckbox" class="btn md white r">UiCheckbox (체크박스)</v-btn>
    <br /><br />
    <v-btn type="nlink" to="./UiCheckbox" class="btn md white r">UiRadio (라디오)</v-btn>
    <br /><br />
    <v-btn type="nlink" to="./UiProgressbar" class="btn md white r">UiGage (프로그레스바)</v-btn>
    <br /><br />
    <v-btn type="nlink" to="./UiTab" class="btn md white r">UiTab (탭)</v-btn>
    <br /><br />
    <v-btn type="nlink" to="./UiPopup" class="btn md white r">UiPopup (팝업)</v-btn>
    <br /><br />
    <v-btn type="nlink" to="./UiTooltip" class="btn md white r">UiTooltip (툴팁)</v-btn>


  </div>
</template>

<script>
import { VBtn} from '~/components/element'
export default {
  layout: 'sub',
  components: {
    VBtn,
  },
  data() {
    return {

    }
  },
}
</script>
