<template>
  <div class="content samplePage">

  </div>
</template>

<script>
export default {
  layout:'sub',
  components: {},
  data() {
    return {
    }
  },
}
</script>
