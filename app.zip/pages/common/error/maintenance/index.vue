<template>
  <div class="content-wrap">
    <div class="content error">
      <section class="maintenance-wrap">
        <div class="logo-hyundai"><span class="offscreen">hyundai casper</span></div>

        <!-- 시스템 점검 안내 type -->
        <h1>시스템 점검 안내</h1>
        <div class="text-main">
          보다 나은 서비스 제공을 위한 시스템 점검 작업으로 페이지 접근이 일시 중단됩니다. 이용 고객님들께 불편을 끼쳐
          드려서 죄송합니다.
        </div>
        <div class="text-main">최대한 빠른 시간 내에 서비스가 정상화 될 수 있도록 노력하겠습니다.</div>

        <!-- 홈페이지 서비스 일시 중단 안내 type -->
        <h1>홈페이지 서비스<br />일시 중단 안내</h1>
        <div class="text-main">많은 관심과 사랑을 보내주시는 고객 여러분께 진심으로 감사드립니다.</div>
        <div class="text-main">
          시스템 성능 개선을 위한 작업으로 홈페이지 서비스가 일시 중단되오니 이용에 참고 부탁드립니다.
        </div>
        <ul class="bullet-list">
          <li>
            <span>중단일시</span>
            <em>2021. 03. 27(토) 09:00~12:00</em>
          </li>
          <li>
            <span>대상서비스</span>
            <em>고객센터 서비스</em>
          </li>
        </ul>
        <div class="text-main">
          서비스 이용에 불편을 드린 점 양해 부탁드립니다.<br />더욱 편리한 서비스를 제공할 수 있도록 노력하겠습니다.
          감사합니다.
        </div>
      </section>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      pageTitle: 'Casper'
    }
  }
}
</script>
