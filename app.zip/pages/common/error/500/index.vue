<template>
  <div class="content-wrap">
    <div class="content error">
      <div class="error-wrap">
        <i class="icon-setup"></i>
        <div class="section-title">서버 에러가<br />발생하였습니다.</div>
        <div class="text-main">
          서버 내부 사정으로 오류가 발생하여<br />접속이 불가능합니다. 잠시 후 다시 이용해주세요.<br />서비스 이용에
          불편을 드려 죄송합니다.
        </div>
        <div class="btn-wrap">
          <v-btn class="btn lg blue" type="nlink" to="/">홈으로</v-btn>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      pageTitle: 'Casper'
    }
  }
}
</script>
