<template>
  <div class="content-wrap">
    <div class="content error">
      <div class="error-wrap">
        <i class="icon-error"></i>
        <div class="section-title">요청하신 페이지를<br />찾을 수 없습니다.</div>
        <div class="text-main">주소를 잘못 입력했거나<br />페이지가 이동했을 수 있습니다.</div>
        <div class="btn-wrap">
          <v-btn class="btn lg blue" type="nlink" to="/">홈으로</v-btn>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      pageTitle: 'Casper'
    }
  }
}
</script>
