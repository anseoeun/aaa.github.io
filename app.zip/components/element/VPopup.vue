 <template>
  <el-dialog
    v-if="isOpen"
    :visible.sync="isOpen"
    :width="popupWidth"
    :modal="isDim"
    :modal-append-to-body="dimBody"
    :append-to-body="appendToBody"
    :lock-scroll="parentsScroll"
    :show-close="false"
    :close-on-click-modal="dimClick"
    :custom-class="`popup-container ${popupType} ${customClass} ${popupTextAlign}`"
    :fullscreen="fullPopup"
    :top="popupMarginTop"
    :aria-hidden="ariaHidden"
    tabindex="0"
    @close="onClose"
  >
    <slot name="multiPopup"></slot>
    <button v-if="isClose" class="popup-close-button" @click="onClose">
      <span class="sr-only">창닫기</span>
    </button>
    <!-- Header -->
    <div v-if="$slots.header" class="popup-header">
      <slot name="header"></slot>
    </div>

    <!-- Body -->
    <div class="popup-body">
      <div v-if="contentsType === 'message'">
        {{ contentsText }}
        <slot name="body"></slot>
      </div>
      <slot v-else-if="contentsType === 'contents-slot'" name="body"></slot>
      <slot v-else name="body"></slot>
    </div>

    <div v-if="$slots.footer || footer.length !== 0" class="popup-footer">
      <slot name="footer"></slot>
      <div v-if="footer.length" class="btn-group" :class="{ 'popup-footer-btn': slotCheckFooter }">
        <v-btn
          v-for="(value, index) in footer"
          :key="index"
          :data-id="value"
          class="btn"
          :class="[value === 'cancel' ? 'btn-gray' : ''
            || value === 'nonAgree' ? 'btn-gray' : ''
          ]"
          b-size="btn-md"
          @click="onClickBtn(value)"
        >{{ footerBtn[value] }}</v-btn>
      </div>
    </div>
  </el-dialog>
</template>

<script>
import VBtn from './VBtn'

export default {
  components: {
    VBtn
  },
  props: {
    visible: {
      type: Boolean,
      default: false
    },
    fullPopup: {
      type: Boolean,
      default: false,
      required: false
    },
    customClass: {
      type: String,
      default: '',
      required: false
    },
    dimClick: {
      type: Boolean,
      default: true,
      required: false
    },
    dimBody: {
      type: Boolean,
      default: true,
      required: false
    },
    appendToBody: {
      type: Boolean,
      default: true,
      required: false
    },
    width: {
      type: String,
      default: '600px'
    },
    parentsScroll: {
      type: Boolean,
      default: true,
      required: false
    },
    isClose: {
      type: Boolean,
      default: true,
      required: false
    },
    closeSize: {
      type: String,
      default: '30px',
      required: false
    },
    isDim: {
      type: Boolean,
      default: true,
      required: false
    },
    contentsType: {
      type: String,
      default: 'message',
      required: false
    },
    contentsText: {
      type: String,
      default: '',
      required: false
    },
    footer: {
      type: Array,
      default: () => []
    },
    popupType: {
      type: String,
      default: 'basic'
    },
    popupTextAlign: {
      type: String,
      default: 'center'
    },
    top: {
      type: String,
      default: '15vh'
    },
  },
  data() {
    return {
      isOpen: false,
      ariaHidden: true,
      footerBtn: {
        confirm: '확인',
        cancel: '취소',
        close: '닫기',
        agree: '동의',
        nonAgree: '미동의',
        choiceEnd: '선택 완료',
        change: '변경',
      },
      message: false,
      slotCheckFooter: false,
      tempWidth: '',
      popupWidth: '',
      tempMarginTop: '',
      popupMarginTop: '',
      temp: null,
      popupHeight: 0,
      tempMq: null,
      headerH: 0,
      footerH: 0,
    }
  },
  watch: {
    visible(newVisible, oldVisible) {
      this.isOpen = newVisible
      if (newVisible) {
        this.slotChecked()
      }
      this.popupWidth = this.tempWidth
      this.popupMarginTop = this.tempMarginTop
    }
  },
  created() {
    this.tempWidth = this.width
    this.tempMarginTop = this.top
  },
  updated() {
    // if (this.isOpen) {
    //   if(this.fullPopup) this.setHeight()
    // }
  },
  mounted(){

  },
  methods: {
    // handleHeight() {
    //   const popupWrapper = this.$el
    //   const popupContainer = popupWrapper.getElementsByClassName('popup-container')[0]
    //   let popupHeights = [popupContainer.offsetHeight]
    //   let count = 0

    //   if (!popupContainer) {
    //     return
    //   }
    //   if (this.intervalCheck) {
    //     clearInterval(this.intervalCheck)
    //     this.intervalCheck = null
    //   }

    //   this.intervalCheck = setInterval(() => {
    //     const prev = popupHeights.pop()
    //     const curr = popupContainer.offsetHeight
    //     popupHeights.push(curr)
    //     count++

    //     if (prev !== curr) {
    //       this.popupHeight = curr
    //       this.setPosition()
    //       clearInterval(this.intervalCheck)
    //     }

    //     if (count >= 300) {
    //       this.setPosition()
    //       clearInterval(this.intervalCheck)
    //     }
    //   }, 10)
    // },

    onClickBtn(value) {
      this.$emit(value)
      if (value !== 'close') {
        setTimeout(()=> {this.onClose()} , 500)
      }
    },
    onClose() {
      this.$emit('close')
    },
    slotChecked() {
      if (this.$slots.footer) {
        this.slotCheckFooter = true
      } else {
        this.slotCheckFooter = false
      }
    }
  }
}
</script>
