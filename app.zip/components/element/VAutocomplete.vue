<template>
  <div class="v-search">
    <form>
      <fieldset>
        <legend>통합검색</legend>
        <div class="search input-wrap">
          <input
            v-model="keyword"
            type="text"
            title="통합 검색어 입력"
            value="kona"
            placeholder="검색어를 입력해주세요."
          />

          <!-- 자동 검색 결과 -->
          <div class="auto_search">
            <ul>
              <li>
                <a href="#"><span>kona</span></a>
              </li>
              <li>
                <a href="#"><span>kona</span></a>
              </li>
              <li>
                <a href="#"><span>kona</span></a>
              </li>
              <li>
                <a href="#"><span>kona</span></a>
              </li>
            </ul>
          </div>
          <!-- //자동 검색 결과 -->

          <!-- 최근검색 -->
          <div class="recent-search on" style="display:block">
            <ul>
              <li>
                <dl>
                  <dt>최근 검색어</dt>
                  <dd>
                    <a href="#">엔진
                      <button type="button" class="btn_del">
                        <span class="sr-only">검색어 삭제</span>
                      </button></a>
                  </dd>
                  <dd>
                    <a href="#">엔진
                      <button type="button" class="btn_del">
                        <span class="sr-only">검색어 삭제</span>
                      </button></a>
                  </dd>
                  <dd>
                    <a href="#">주행 보조
                      <button type="button" class="btn_del">
                        <span class="sr-only">검색어 삭제</span>
                      </button></a>
                  </dd>
                </dl>
                <button type="button" class="btn_historyDel">
                  <span>검색기록 삭제</span>
                </button>
              </li>
              <li>
                <dl>
                  <dt>인기있는 추천 사양 TOP10</dt>
                  <dd>
                    <a href="#">1위. <span>스티어링 휠</span></a>
                  </dd>
                  <dd>
                    <a href="#">2위. <span>고속도로 주행보조</span></a>
                  </dd>
                  <dd>
                    <a href="#">3위. <span>급제동 경보시스템</span></a>
                  </dd>
                  <dd>
                    <a href="#">4위. <span>스마트 크루즈 컨트롤</span></a>
                  </dd>
                  <dd>
                    <a href="#">5위. <span>스티어링 휠</span></a>
                  </dd>
                  <dd>
                    <a href="#">6위. <span>스티어링 휠</span></a>
                  </dd>
                  <dd>
                    <a href="#">7위. <span>속도로 주행보조</span></a>
                  </dd>
                  <dd>
                    <a href="#">8위. <span>급제동 경보시스템</span></a>
                  </dd>
                  <dd>
                    <a href="#">9위. <span>스마트 크루즈 컨트롤</span></a>
                  </dd>
                  <dd>
                    <a href="#">10위. <span>스티어링 휠</span></a>
                  </dd>
                </dl>
              </li>
            </ul>
          </div>
          <!-- //최근검색 -->
          <button type="button" class="btn_del">
            <span class="sr-only">검색어 삭제</span>
          </button>
          <button type="button" class="btn_search">
            <span class="sr-only">검색하기</span>
          </button>
        </div>
      </fieldset>
    </form>
  </div>
  <!-- //검색레이어 -->
</template>

<script>
export default {
  data() {
    return {
      keyword: ''
    }
  }
}
</script>
