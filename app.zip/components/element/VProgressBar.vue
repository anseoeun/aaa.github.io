<template>
  <div v-if="type === 'percent'" class="progress percent" :style="{ width: totalWidth + '%' }">
    <div class="currentProgress" :style="{ width: currentPer + '%' }">
      <slot></slot>
    </div>
  </div>
  <div v-else class="progress" :style="{ width: totalWidth + '%' }">
    <div class="currentProgress" :style="{ width: widthPercent + '%' }">
      <slot></slot>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    type: {
      type: String,
      default: '',
    },
    totalWidth: {
      type: String,
      default: '0',
      require: true
    },
    currentWidth: {
      type: String,
      default: '100',
      require: true
    },
    currentPer: {
      type: String,
      default: '0',
    },
    height: {
      type: String,
      default: '0',
      require: true
    },
    endTime: {
      type: String,
      default: ''
    },
    startTime: {
      type: String,
      default: ''
    }
  },
  data() {
    return {
      widthPercent: this.currentWidth,
      emitTime: '',
      baseTime: 0,
      minute: 0,
      contractStartDate: '',
      contractEndDate: ''
    }
  },
  computed: {},
  watch: {
    emitTime(value, oldValue) {
      const data = {
        /*
        start: 계약시작(0년 0월 0일 0시 0분)
        end: 계약종료(0년 0월 0일 0시 0분)
        remain: 남은계약시간(0일 0시 0분)
        time: 남은시간(분단위)

        */
        start: this.contractStartDate,
        end: this.contractEndDate,
        remain: this.emitTime,
        time: this.baseTime - this.minute
      }
      this.$emit('remainTime', data)
    }
  },
  created() {
    this.timeInterval()
  },
  mounted() {
    this.contractStartDate = this.dateChange(this.startTime)
    this.contractEndDate = this.dateChange(this.endTime)
  },
  methods: {
    setProgress: () => {},
    dateChange: (date) => {
      const endYY = date.substring(0, 4)
      const endMM = date.substring(4, 6)
      const endDD = date.substring(6, 8)
      const endHour = date.substring(8, 10)
      const endMin = date.substring(10, 12)
      const endDate = `${endYY}년 ${endMM}월 ${endDD}일 ${endHour}시 ${endMin}분`
      return endDate
    },
    makeDate: (date) => {
      const endYY = date.substring(0, 4)
      const endMM = Number(date.substring(4, 6)) - 1
      const endDD = date.substring(6, 8)
      const endHour = date.substring(8, 10)
      const endMin = date.substring(10, 12)
      return new Date(endYY, endMM, endDD, endHour, endMin)
    },
    diffDate: (start, end) => {
      const startMs = start.getTime()
      const endMs = end.getTime()
      const diffMs = endMs - startMs
      const gapMin = diffMs / 1000 / 60

      return gapMin
    },
    minToTime: (minute) => {
      const nMinute = Number(minute)
      const day = Math.floor(nMinute / 1440)
      const hour = Math.floor((nMinute - 1440 * day) / 60)
      const min = nMinute - 1440 * day - 60 * hour
      const arr = [day, hour, min]
      const arr2 = ['일 ', '시간 ', '분']
      let time = ''
      for (let i = 0; i < arr.length; i++) {
        if (arr[i] !== 0) time += arr[i] + arr2[i]
      }
      return time
    },
    widthCalc(total, change) {
      this.widthPercent = (change / total) * 100
      return this.widthPercent
    },
    emitData(diff, min) {
      const diffTime = diff - min
      const rt = this.minToTime(diffTime)
      this.emitTime = rt
      this.widthCalc(this.baseTime, diffTime)
    },
    timeInterval() {
      const vm = this
      const sd = vm.makeDate(vm.startTime)
      const ed = vm.makeDate(vm.endTime)
      const diff = vm.diffDate(sd, ed) // 기준시간 3시간(180분) 또는 72시간(4)
      const min = vm.minute
      vm.baseTime = diff
      vm.emitData(diff, min)
      setInterval(function() {
        vm.minute += 1
        const min2 = vm.minute
        vm.emitData(diff, min2)
      }, 60000)
    }
  }
}
</script>