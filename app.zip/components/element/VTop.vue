<template>
  <div>
    <a
      href="javascript:void(0);"
      role="button"
      class="btn-scroll-top"
      @click="setGoTop"
    >
      <span>페이지 위로</span>
    </a>
  </div>
</template>

