<template>
  <div class="content samplePage">
    <el-tooltip
      :class="'item'"
      :effect="effect"
      :content="content"
      :placement="placement"
    >
    <!--  effect="light" -->
      <slot></slot>
    </el-tooltip>
  </div>
</template>

<script>
export default {
  layout: 'sub',
  name: 'VTooltip',
  props: {
    effect: {
      type: String,
      default: 'light',
    },
    content: {
      type: String,
      default: '',
    },
    placement: {
      type: String,
      default: '',
    },
  },

  data() {
    return {}
  },
}
</script>
