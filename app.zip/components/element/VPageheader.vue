<template>
  <section class="visual-wrap">
    <!-- TODO - breadcrumb 컴포넌트 정리 필요! -->
    <div v-if="topBreadcrumb.length > 0" class="top-breadcrumb">
      <ul>
        <li>
          <n-link :to="'/'">홈</n-link>
        </li>
        <li v-for="(data, index) in topBreadcrumb" :key="index" class="sub">
          <n-link :to="data.link">{{ data.linkName }}</n-link>
        </li>
      </ul>
    </div>
    <!-- <div class="visual-head-wrap" :style="getBackgroundImage"> -->
    <div class="visual-head-wrap" :class="pageClass">
      <div class="visual-title">
        <h1 v-html="pageTitle"></h1>
        <p v-if="isNan(pageInfotext)" class="text-info" v-html="pageInfotext"></p>
      </div>
      <slot></slot>
    </div>
  </section>
</template>

<script>
export default {
  props: {
    pageCarType: {
      type: String,
      default: ''
    },
    pageTitle: {
      type: String,
      default: ''
    },
    pageInfotext: {
      type: String,
      default: ''
    },
    pageClass: {
      type: String,
      default: ''
    },
    noBreadcrumb: {
      type: Boolean,
      default: true,
    },
    topBreadcrumb: {
      type: Array,
      default: () => []
    }
  },

  computed: {
    getCarTypeTitle() {
      let title = this.pageCarType
      if (title === 'SEDAN') {
        title = '승용'
      } else if (title === 'ECO') {
        title = '친환경'
      } else if (title ==='model') {
        title = '모델비교'
      }
      return title
    },

    getBackgroundImage() {
      let rtn = ''
      if (/[a-zA-z]/.test(this.pageCarType)) rtn = { 'background-image': `url('/static/images/lineUp/key-visual/employee/GUI_${this.pageCarType}_LineUp_PC.png')` }
      return rtn
    }
  },

  methods: {
    isNan(val) {
      return val != undefined && val != null && val != '' ? true : false
    }
  }
}
</script>
