<template>
  <div class="carousel">
    <no-ssr>
      <splide
        ref="primary"
        :options="setOption"
        :btmarrow="btmarrow"
        :class="{'btm-arrow' : btmarrow}"
        @splide:mounted="initClientOnlyComp"
      >
        <template v-if="content">
          <slot ref="content" name="content"></slot>
        </template>
        <!-- list -->
        <template v-else>
          <splide-slide v-for="(item, index) in list" :key="index">
            <slot :item="item"></slot>
          </splide-slide>
        </template>
      </splide>
    </no-ssr>
  </div>
</template>

<script>
export default {
    props: {
    slliderName: {
      type: String,
      default: '',
    },
    btmarrow: {
      type: Boolean,
      default: false,
    },
    data: {
      type: Array,
      default: () => [],
    },
    options: {
      type: Object,
      default: () => {},
    },
    content: {
      type: Boolean,
      default: false,
    },
  },

  data() {
    return {
      pagingNumber: 1,
    }
  },
  computed: {
    list() {
      return this.data.map((item) => ({ ...item }))
    },
    pagingSize() {
      return 31 * this.list.length
    },
    setOption() {
      return Object.assign({
        arrows : this.options.perPage <  this.getDataLength(),
        pagination : this.options.perPage <  this.getDataLength(),
        drag : this.options.perPage <  this.getDataLength()
      }, this.options)
    }
  },
  mounted() {
    // this.initClientOnlyComp()
  },
  methods: {
    initClientOnlyComp(count = 10) {
      this.$nextTick(() => {
        if (this.btmarrow) {
          this.$refs.primary.$el.firstChild.firstChild.style.left = -this.pagingSize / 2 + 'px'
          this.$refs.primary.$el.firstChild.lastChild.style.right = -this.pagingSize / 2 + 'px'
        } else if (count > 0) {
          this.initClientOnlyComp(count - 1)
        }
      })
    },
    getDataLength() {
      if(this.content){
        let num = 0
        for (var key in this.$slots.content) {
          this.$slots.content[key].tag !== undefined ? num += 1 : ''
        }
        return num
      }else{
        return this.data.length
      }
    }
  },
}
</script>
