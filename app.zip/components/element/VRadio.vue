<template>
  <el-radio v-if="oneCheck" v-model="checked" :label="label" :disabled="disabled" @input="onChange" @change="onChange"><slot></slot></el-radio>
  <div v-else :class="`radio ${radioType}`">
    <el-radio-group v-if="type === 'button'" v-model="selected" :disabled="disabled" @change="onChange">
      <el-radio-button
        v-for="(item, index) in data"
        :key="index"
        :label="item[valueKey]"
        :disabled="item.disabled"
      >
        <slot v-if="customLabel" :item="item"></slot>
        <span v-else>{{ item[labelKey] }}</span>
      </el-radio-button>
    </el-radio-group>

    <el-radio-group v-else v-model="selected" :disabled="disabled">
      <el-radio
        v-for="(item, index) in data"
        :key="index"
        :label="item[valueKey]"
        :disabled="item.disabled"
        @change="onChange"
      >
        <slot v-if="customLabel" :item="item"></slot>
        <span v-else>{{ item[labelKey] }}</span>
      </el-radio>
    </el-radio-group>
  </div>
</template>

<script>
export default {
  props: {
    value: {
      type: [String, Boolean, Number],
      default: ''
    },
    valueKey: {
      type: String,
      default: 'value'
    },
    type: {
      type: String,
      default: ''
    },
    label: {
      type:[String, Number],
      default:''
    },
    labelKey: {
      type: String,
      default: 'label'
    },
    oneCheck: {
      type: Boolean,
      default: false
    },
    disabled: {
      type: Boolean,
      default: false
    },
    customLabel: {
      type: Boolean,
      default: false
    },
    radioType: {
      type: String,
      default: ''
    },
    data: {
      type: Array,
      default: () => []
    }
  },

  data() {
    return {
      selected: '',
      checked: ''
    }
  },

  watch: {
    value(newValue, oldValue) {
      if(this.oneCheck){
        this.checked = newValue
      }else{
        if (newValue !== oldValue) {
          this.selected = newValue
        }
      }
    }
  },

  created() {
    if(this.oneCheck){
      this.checked = this.value
    }else{
      this.selected = this.value === '' ? this.data[0][this.valueKey] : this.value
      if (this.selected !== '') {
        this.onChange(this.selected)
      }
    }
  },

  methods: {
    onChange(value) {
      this.$emit('input', value)
      this.$emit('change', value)
    }
  }
}
</script>
