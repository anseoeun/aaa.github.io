<template>
  <el-rate
    :value="value"
    @input="onInput"
  >
  </el-rate>
</template>

<script>
export default {
  props: {
    value: {
      type: Number,
      default: 0
    },
  },
  data() {
    return {
      val: this.value
    }
  },
  mounted(){
    console.log(this.value)
  },
  methods: {
    onInput(value) {
      this.$emit('input', value)
    },
  }
}
</script>