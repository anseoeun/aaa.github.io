<template>
  <el-carousel indicator-position="outside">
    <el-carousel-item v-for="(item, index) in data" :key="index">
      <div class="image">
        <img :src="item.imgUrl" />
      </div>
      <div class="cont">
        <h3>{{ item.id }}</h3>
        <p>{{ item.text }}</p>
        <el-button @click="onLink(item.id)">
          자세히 보기
        </el-button>
      </div>
    </el-carousel-item>
  </el-carousel>
</template>

<script>
export default {
  props: {
    data: {
      type: Array,
      default: () => []
    }
  },

  methods: {
    onLink(model) {
      this.$emit('link', model)
    }
  }
}
</script>
