<template>
  <v-popup
    :visible="visible"
    @close="
      $emit('close')
      popVisible = false
    "
  >
    <template slot="header">
      <div class="title">공유하기</div>
    </template>
    <template slot="body">
      <div class="sns-link">
        <ul>
          <li v-for="(item, index) in snsList" :key="index">
            <a href="javascript:void(0);" target="_blank" title="새창 열기">
              <i :class="`ico-${item}`"></i>
              <span class="offscreen">{{ item }} 공유하기</span>
            </a>
          </li>
        </ul>
      </div>
    </template>
  </v-popup>
</template>

<script>
import { VPopup } from '~/components/element'
export default {
  components: {
    VPopup
  },
  props: {
    visible: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      snsList: ['facebook', 'kakaotalk', 'naver', 'band', 'url']
    }
  }
}
</script>