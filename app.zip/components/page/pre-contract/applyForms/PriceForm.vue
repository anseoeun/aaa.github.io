<template>
  <div class="price-form-wrap">
    <div class="apply-box border-line">
      <div class="title">
        <div class="left">차량 가격
          <p class="ptxt">사양을 모두 선택해주세요</p>
        </div>
        <div class="right">
          <div class="price-result"><span class="price">18,000,000 ~ 20,000,000</span><span class="unit">원</span></div>
        </div>
      </div>
      <div class="con-box">
          <ul class="bullet-list t-gray">
            <li>상기 가격은 개별소비세 반영 기준이며, 상세가격은 모델 소개에서  확인하실 수 있습니다.</li>
            <li>상기 가격은 선택품목이 포함된 가격입니다.</li>
            <li>사전계약 시 선택하신 트림 및 선택품목은 판매개시 이후 계약 확정 시 변경 가능합니다.</li>
          </ul>
      </div>
    </div>
  </div>
</template>

<script>
export default {
}
</script>
