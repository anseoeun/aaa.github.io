<template>
  <div class="multiple-select">
    <button
      type="button"
      class="multi-select-button"
      :class="{ 'is-active': openMultiSelector }"
      @click="toggleMultiSelector()"
    >
      <span>{{ selectChangeName }}</span>
    </button>
    <div class="drop-list" :class="{ 'is-open': openMultiSelector }">
      <v-checkbox v-model="multiSelect" class="drop-checkbox" :data="multiSelectList" @change="itemCheck()" />
    </div>
    <div class="option-list">
      <ul>
        <li v-for="(label, index) in multiSelect" :key="index">
          <span>{{ label }}</span>
          <button type="button" class="btn btn-blitClose" @click="thisItemDelete(index)">
            <span class="sr-only">옵션 삭제하기</span>
          </button>
        </li>
      </ul>
    </div>
  </div>
</template>

<script>
import { VCheckbox } from '~/components/element'
export default {
  components: {
    VCheckbox
  },
  data() {
    return {
      openMultiSelector: false,
      selectChangeName: '선택',
      multiSelect: [],
      multiSelectList: [
        {
          value: '인조가죽시트',
          label: '인조가죽시트'
        },
        {
          value: '15인치 알로이 휠',
          label: '15인치 알로이 휠'
        },
        {
          value: '15인치 알로이 휠 & 타이어 & 리어디스크 옵션 포함',
          label: '15인치 알로이 휠 & 타이어 & 리어디스크 옵션 포함'
        },
        {
          value: 'IVT',
          label: 'IVT'
        },
        {
          value: '디스플레이 오디오 패키지',
          label: '디스플레이 오디오 패키지'
        },
        {
          value: '디스플레이 오디오 패키지',
          label: '디스플레이 오디오 패키지'
        }
      ]
    }
  },
  methods: {
    itemCheck() {
      if (this.multiSelect.length > 0) {
        this.selectChangeName = '총 ' + this.multiSelect.length + '개 선택'
      } else {
        this.selectChangeName = '선택'
      }
    },
    thisItemDelete(i) {
      this.multiSelect.splice(i, 1)
    },
    toggleMultiSelector() {
      this.openMultiSelector = !this.openMultiSelector
    }
  }
}
</script>
