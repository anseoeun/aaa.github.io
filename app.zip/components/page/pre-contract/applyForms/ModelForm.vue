<template>
  <div class="model-form-wrap">
    <div class="apply-box border-line">
      <div class="title">
        사전계약 차종을 선택하세요.
        <p class="ptxt">선택한 엔진에 따라 차종을 확인하실 수 있습니다.</p>
      </div>
      <div class="con-box">
        <v-radio
          v-model="engineSelected"
          class="radio-button num3"
          type="button"
          :data="engineList"
          @change="enginSelected"
           />
        <!-- trim-tog-list -->
        <ul class="trim-tog-list">
          <li>
            <div class="tit">
              <b>Prestige</b>
              <div class="right">
                <v-btn type="icon" :icon-class="['icon-tog-arr sm-size', { on: isAct(0) }]" @click="setAct(0)"><span class="offscreen">Prestige 보기</span></v-btn>
              </div>
            </div>
            <div v-if="isAct(0)" class="desc">
              <v-radio
                v-model="trimeSelected"
                class="radio-button"
                type="button"
                :disabled="engineSelected == '' ? true : false"
                :data="trimeList" />
            </div>
          </li>
          <li>
            <div class="tit">
              <b>Premium</b>
              <div class="right">
                <v-btn type="icon" :icon-class="['icon-tog-arr sm-size', { on: isAct(1) }]" @click="setAct(1)"><span class="offscreen">Premium 보기</span></v-btn>
              </div>
            </div>
            <div v-if="isAct(1)" class="desc">
              <v-radio
                v-model="trimeSelected"
                class="radio-button"
                type="button"
                :disabled="engineSelected == '' ? true : false"
                :data="trimeList2" />
            </div>
          </li>
          <li>
            <div class="tit">
              <b>Premium Choice</b>
              <div class="right">
                <v-btn type="icon" :icon-class="['icon-tog-arr sm-size', { on: isAct(2) }]" @click="setAct(2)"><span class="offscreen">Premium Choice 보기</span></v-btn>
              </div>
            </div>
            <div v-if="isAct(2)" class="desc">
              <v-radio
                v-model="trimeSelected"
                class="radio-button"
                type="button"
                :disabled="engineSelected == '' ? true : false"
                :data="trimeList3" />
            </div>
          </li>
        </ul>
        <!-- // trim-tog-list -->
      </div>
    </div>
    <div class="apply-box border-line">
      <div class="title">사양급을 선택하세요.</div>
      <div class="con-box">
          <v-radio
            v-model="specificSelected"
            :disabled="trimeSelected == '' ? true : false"
            class="radio-button num2"
            type="button"
            :data="specificList" />
      </div>
      <div class="title">선택품목을 선택하세요.
        <p class="ptxt">선택 품목은 중복선택이 가능합니다.</p>
      </div>
      <div class="con-box">
          <v-radio
            v-model="optionSelected"
            class="radio-button num2"
            type="button"
            :disabled="specificSelected == '' ? true : false"
            :data="optionList" />
      </div>
      <div class="title">외장색상을 선택하세요.</div>
      <div class="con-box">
          <v-radio
            v-model="outColorSelected"
            class="radio-button num2"
            type="button"
            :custom-label="true"
            :disabled="optionSelected == '' ? true : false"
            :data="outColorList">
              <template slot-scope="props"><div class="car-color" :style="`background-image:url(${props.item.src})`"></div> {{ props.item.label }}</template>
            </v-radio>
      </div>
      <div class="title">내장색상을 선택하세요.</div>
      <div class="con-box">
          <v-radio
            v-model="inColorSelected"
            class="radio-button num2"
            type="button"
            :custom-label="true"
            :disabled="optionSelected == '' ? true : false"
            :data="inColorList">
              <template slot-scope="props"><div class="car-color" :style="`background-image:url(${props.item.src})`"></div> {{ props.item.label }}</template>
            </v-radio>
      </div>
    </div>

  </div>
</template>

<script>
export default {
  data() {
    return {
      checkOption: '',
      optionItemsGroup: [],
      engineSelected:  false,
      engineList: [
        {
          value: 'engine1',
          label: '가솔린 2.5'
        },
        {
          value: 'engine2',
          label: '가솔린 2.5 터보'
        },
        {
          value: 'engine3',
          label: '디젤 2.2'
        }
      ],
      listSelected: [false, false, false],
      trimeSelected: false,
      trimeList: [
        {
          value: 'prestige1',
          label: '캐스퍼 가솔린 2.5 2WD 5인승 오토 F/L'
        },
        {
          value: 'prestige2',
          label: '캐스퍼 가솔린 2.5 2WD 7인승 오토 F/L'
        },
        {
          value: 'prestige3',
          label: '캐스퍼 가솔린 2.5 4WD 5인승 오토 F/L'
        },
        {
          value: 'prestige4',
          label: '캐스퍼 가솔린 2.5 4WD 7인승 오토 F/L'
        }
      ],
     trimeList2: [
        {
          value: 'premium1',
          label: '캐스퍼 가솔린 2.5 2WD 5인승 오토 F/L'
        },
        {
          value: 'premium2',
          label: '캐스퍼 가솔린 2.5 2WD 7인승 오토 F/L'
        },
        {
          value: 'premium3',
          label: '캐스퍼 가솔린 2.5 4WD 5인승 오토 F/L'
        },
        {
          value: 'premium4',
          label: '캐스퍼 가솔린 2.5 4WD 7인승 오토 F/L'
        }
      ],
     trimeList3: [
        {
          value: 'premiumChoice1',
          label: '캐스퍼 가솔린 2.5 2WD 5인승 오토 F/L'
        },
        {
          value: 'premiumChoice2',
          label: '캐스퍼 가솔린 2.5 2WD 7인승 오토 F/L'
        },
        {
          value: 'premiumChoice3',
          label: '캐스퍼 가솔린 2.5 4WD 5인승 오토 F/L'
        },
        {
          value: 'premiumChoice4',
          label: '캐스퍼 가솔린 2.5 4WD 7인승 오토 F/L'
        }
      ],
      specificSelected: false,
      specificList: [
        {
          value: 'specific1',
          label: '기본'
        },
        {
          value: 'specific2',
          label: '디자인 플러스'
        }
      ],
      optionSelected: false,
      optionList: [
        {
          value: 'option1',
          label: '빌트인 캠(보조배터리 포함)'
        },
        {
          value: 'option2',
          label: '현대 스마트 센스'
        },
        {
          value: 'option3',
          label: '컴포트'
        },
        {
          value: 'option4',
          label: '선루프'
        }
      ],
      outColorSelected: false,
      outColorList: [
        {
          value: 'outColor1',
          label: '쉬머링 실버',
          src: require('~/assets/images/temp/temp-color-1.png'),
        },
        {
          value: 'outColor2',
          label: '화이트 크림',
          src: require('~/assets/images/temp/temp-color-2.png'),
        }
      ],
      inColorSelected: false,
      inColorList: [
        {
          value: 'inColor1',
          label: '스톤그레이',
          src: require('~/assets/images/temp/temp-color-3.png'),
        },
        {
          value: 'inColor2',
          label: '화이트 크림 ',
          src: require('~/assets/images/temp/temp-color-4.png'),
        }
      ]
    }
  },
  methods: {
    setAct(index) {
      if (this.listSelected[index] === false) {
        this.$set(this.listSelected, index, true)
      } else {
        this.$set(this.listSelected, index, false)
      }
    },
    isAct(index) {
      return this.listSelected[index] === true
    },
    enginSelected() {
      if(this.engineSelected !== false){
          this.$set(this.listSelected, 0, true)
      }
    }
  }
}
</script>
