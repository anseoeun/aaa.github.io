<template>
  <div class="apply-form-wrap">
    <form action="">
      <fieldset>
        <model-form />
        <delivery-form />
        <price-form />
        <part-price-form />
      </fieldset>
    </form>
  </div>
</template>


<script>
import ModelForm from './applyForms/ModelForm'
import DeliveryForm from './applyForms/DeliveryForm'
import PriceForm from './applyForms/PriceForm'
import PartPriceForm from './applyForms/PartPriceForm'

export default {
  components: {
    ModelForm,
    DeliveryForm,
    PriceForm,
    PartPriceForm,
  },
}
</script>
