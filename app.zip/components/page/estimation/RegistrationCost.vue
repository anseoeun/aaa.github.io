<template>
  <div class="matching-box border-line">
    <div class="box-wrap take-over">
      <v-btn class="box-tit main-title" @click="isOptionsShow = !isOptionsShow">
        등록비
        <span class="total-price"
          >(별도납부) <em class="price"><strong>82,600</strong> 원</em></span
        >
        <i :class="['icon-toggle-arr off-gray', { on: isOptionsShow }]"></i>
      </v-btn>
      <div v-show="isOptionsShow" class="box-desc">
        <div class="info-grid-list">
          <ul>
            <li>
              <div class="info-title">
                <strong class="ct">면세구분</strong>
                <v-btn class="btn-info" type="icon" icon-class="icon-info" @click="popTaxFree = true"
                  ><span class="offscreen">면세구분안내팝업보기</span></v-btn
                >
              </div>
              <div class="info-group">
                <v-select v-model="taxSelect" :data="taxSelectList" placeholder="선택하세요" />
                <v-checkbox v-model="taxCheck" :data="taxCheckList" />
              </div>
            </li>
            <li>
              <div class="info-title">
                <strong>취득세</strong>
                <v-btn class="btn-info" type="icon" icon-class="icon-info" @click="popVisible.infoAcquirement = true"
                  ><span class="offscreen">취득세안내팝업보기</span></v-btn
                >
              </div>
              <div class="info-group">
                <span class="price">100,000 원</span>
              </div>
            </li>
            <li>
              <div class="info-title ct">
                <strong>공채</strong>
                <v-btn class="btn-info" type="icon" icon-class="icon-info" @click="popVisible.infoFund = true"
                  ><span class="offscreen">공채안내팝업보기</span></v-btn
                >
              </div>
              <div class="info-group">
                <span class="price">100,000 원</span>
              </div>
            </li>
            <li>
              <strong class="info-title">증지대(수입인지)</strong>
              <div class="info-group">
                <span class="price">100,000 원</span>
              </div>
            </li>
            <li>
              <strong class="info-title">차량번호판</strong>
              <div class="info-group">
                <span class="price">100,000 원</span>
              </div>
            </li>
            <li>
              <strong class="info-title">등록 대행 수수료</strong>
              <div class="info-group">
                <span class="price">100,000 원</span>
              </div>
            </li>
          </ul>
          <!-- pc와 비교해보기 -->
          <ul class="bullet-star-list">
            <li>등록비는 견적금액에 포함되지 않습니다.</li>
            <li>공채 할인금액은 지자체별 할인율이 매일 변동됨에 따라 실제와 다소 차이가 있을 수 있습니다.</li>
            <li>차량번호판과 등록대행수수료는 지역별로 차이가 있으므로 단순 참고만 하시기 바랍니다.</li>
          </ul>
        </div>
      </div>

    </div>
    <!-- 팝업 -->
    <!-- <info-acquirement :pop-visible="popVisible" @close="popVisible.infoAcquirement = false" />
    <info-fund :pop-visible="popVisible" @close="popVisible.infoFund = false" />
    <tax-free :visible="popTaxFree" @close="popTaxFree = false" /> -->
  </div>
</template>

<script>
// import InfoAcquirement from '~/components/page/payment/popup/InfoAcquirement'
// import InfoFund from '~/components/page/payment/popup/InfoFund'
// import TaxFree from '~/components/page/estimation/popup/TaxFree'
export default {
  components: {
    // InfoAcquirement,
    // InfoFund,
    // TaxFree
  },
  data() {
    return {
      isOptionsShow: false,
      costSelcet: '',
      costSelcetList: [{ value: '01', label: '일반인' }],
      costRadio: '',
      costRadioList: [
        { value: '01', label: '할인' },
        { value: '02', label: '매입' }
      ],
      popVisible: {
        infoAcquirement: false,
        infoFund: false
      },
      popTaxFree: false,
      taxCheck: '',
      taxCheckList: [
        { value: 'check1', label: '다자녀(19세 미만 3인 이상)' }
      ],
      taxSelect: 'city0',
      taxSelectList: [{ value: 'city0', label: '일반인' }]
    }
  }
}
</script>
