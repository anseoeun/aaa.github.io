<template>
  <div class="matching-box">
    <div class="box-wrap vehicle-options">
      <v-btn class="box-tit main-title" @click="isOptionsShow = !isOptionsShow">
        선택차량
        <span class="total-price"
          >차량 금액 <em class="price"><strong>33,300,000</strong> 원</em></span
        >
        <i :class="['icon-toggle-arr off-gray', { on: isOptionsShow }]"></i>
      </v-btn>
      <div v-show="isOptionsShow" class="box-desc">
        <div class="car-desc">
          <div class="car-img"><v-img :src="carImg.src" :alt="name"></v-img></div>
          <span class="flag gr">기획전</span>
          <strong class="name">{{ name }}</strong>
          <div class="option">{{ inColor.txt }} / {{ outColor.txt }} / 옵션 {{ optionData.length }}개 <v-btn class="btn-link">변경</v-btn></div>
          <v-btn class="btn-detail" @click="isDetailShow = !isDetailShow">
            자세히 보기
            <i :class="['icon-toggle-arr sm-size gray', { on: isDetailShow }]"></i>
          </v-btn>
        </div>
        <div v-show="isDetailShow" class="car-detail">
          <div class="match-box">
            <div class="title bold">모델</div>
            <div class="desc info-grid-list bold">
              <ul>
                <li class="model">
                  <strong class="info-title">{{ name }}</strong>
                  <div class="info-group"><span class="price bold">29,000,000 원</span></div>
                </li>
                <li>
                  <strong class="info-title">내장 : {{ inColor.txt }}</strong>
                  <div class="info-group"><span class="price">{{ inColor.price }} 원</span></div>
                </li>
                <li>
                  <strong class="info-title">외장 : {{ outColor.txt }}</strong>
                  <div class="info-group"><span class="price">{{ outColor.price }} 원</span></div>
                </li>
              </ul>
            </div>
          </div>
          <div class="match-box">
            <div class="title">
              <span class="bold">옵션</span>
              <v-btn class="btn-more last">기본포함 품목보기</v-btn>
            </div>
            <div class="desc info-grid-list">
              <ul>
                <li v-for="(item, index) in optionData" :key="index">
                  <strong class="info-title">{{ item.name }}</strong>
                  <div class="info-group">
                    <span class="price">{{ item.price }} 원</span>
                  </div>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  components: {},
  data() {
    return {
      isOptionsShow: false,
      isDetailShow: false,
      name: 'AX 자가용 5인승 가솔린 1.6 2WD IVT Smart',
      carImg: {
        src: require('~/assets/images/temp/temp-payment-car-model.png'),
      },
      inColor: { txt: '폴라화이트', price: '0' },
      outColor: { txt: '블랙모노톤', price: '0' },
      optionData: [
        { name: '시트패키지', price: '100,000' },
        { name: '현대스마트센스', price: '100,000' },
        { name: '네비게이션', price: '100,000' },
        { name: '펫페키지 II', price: '100,000' }
      ],
    }
  }
}
</script>
