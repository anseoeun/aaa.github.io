<template>
  <div class="matching-box border-line">
    <div class="box-wrap take-over">
      <v-btn class="box-tit main-title" @click="isOptionsShow = !isOptionsShow">
        인수정보
        <span v-if="takeOverType === '1'" class="total-price"
          >탁송료 <em class="price"><strong>270,000</strong> 원</em></span
        >
        <span v-if="takeOverType === '2'" class="direct">직접인수</span>
        <i :class="['icon-toggle-arr off-gray', { on: isOptionsShow }]"></i>
      </v-btn>
      <div v-show="isOptionsShow" class="box-desc">
        <div v-if="takeOverType === '1'" class="info-grid-list">
          <ul>
            <li>
              <div class="info-title ct">
                탁송지역
                <v-popover trigger="click" placement="bottom-start">
                  <p>
                    고객님이 요청하신 장소로 차량을<br />배달해드리며, 생산된 공장에서부터의<br />차량운반비용이 탁송료로
                    부과됩니다.
                  </p>
                  <v-btn slot="reference"><i class="icon-help"></i></v-btn>
                </v-popover>
              </div>
              <div class="info-group">
                <v-select v-model="locationSelectValue" :data="locationSelect" placeholder="시/도"> </v-select>
                <v-select v-model="locationSelectValue" :data="locationSelect" placeholder="시/군/구"> </v-select>
              </div>
            </li>
            <li>
              <strong class="info-title">예상출고일</strong>
              <div class="info-group ct">
                <p>3월 2주차</p>
                <v-popover trigger="hover" placement="bottom-start">
                  <p>
                    현 시점 계약완료 기준으로 재고 및<br />생산계획 기반 산출된 예상출고일이며,<br />당사 사정에 의하여
                    변경될 수 있으니<br />단순 참고만 하시기 바랍니다.
                  </p>
                  <v-btn slot="reference"><i class="icon-help"></i></v-btn>
                </v-popover>
              </div>
            </li>
          </ul>
        </div>
        <div v-if="takeOverType === '2'" class="info-grid-list">
          <ul>
            <li>
              <div class="info-title">
                인수지
                <v-popover trigger="hover" placement="bottom-start">
                  <p>전시차량은 온라인 구매 후 전시지점에<br />직접 방문 인수하셔야 합니다.</p>
                  <v-btn slot="reference"><i class="icon-help"></i></v-btn>
                </v-popover>
              </div>
              <div class="info-group">
                <span class="text-head">강남논현지점</span>
                <p class="full ct">(서울시 강남구 테헤란로 22길 12)</p>
              </div>
            </li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  components: {},
  data() {
    return {
      isOptionsShow: false,
      takeOverType: '1',
      locationSelect: [
        {
          name: '1',
          value: '서울시'
        },
        {
          name: '2',
          value: '경기도'
        },
        {
          name: '3',
          value: '인천광역시'
        }
      ],
      locationSelectValue: ''
    }
  }
}
</script>
