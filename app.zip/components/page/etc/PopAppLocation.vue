<template>
  <v-popup :visible="visible" :is-close="false">
    <template slot="header">
      <div class="title">위치기반 서비스 약관동의 안내</div>
    </template>
    <template slot="body">
      <div class="app-popup">
        <div class="text-sub">
          캐스퍼 앱 위치 기반 서비스를 이용하려면<br />현재 위치 정보 사용 및 위치 기반 서비스 이용약관에 대한 동의가
          필요합니다.
        </div>
        <div class="notice">
          <i class="icon-info"></i>
          <div class="text-info">동의하지 않는 경우, 위치기반 서비스 이용에 제한이 있습니다.</div>
        </div>
      </div>
    </template>
    <template slot="footer">
      <div class="btn-group">
        <v-btn class="btn btn-md btn-gray" b-size="btn-md" b-color="btn-gray">동의안함</v-btn>
        <v-btn class="btn btn-md" b-size="btn-md">동의</v-btn>
      </div>
    </template>
  </v-popup>
</template>

<script>
import { VPopup } from '~/components/element'
export default {
  components: {
    VPopup
  },
  props: {
    visible: {
      type: Boolean,
      default: false
    }
  }
}
</script>