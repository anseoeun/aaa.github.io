<template>
  <div>
    <!-- default -->
    <v-popup :visible="popVisible.pushAlarm" :is-close="false">
      <template slot="header">
        <div class="title">푸시 알림 수신동의</div>
      </template>
      <template slot="body">
        <div class="app-popup">
          <div class="text-sub">
            특별한 혜택, 이벤트 소식, 새로운 소식을<br />회원님께만 알려드립니다.<br />푸시 알람을 받아보시겠습니까?
          </div>
          <div class="notice">
            <i class="icon-info"></i>
            <div class="text-info">마이페이지 &gt; 설정 &gt; 알림 수신 설정에서 변경 가능</div>
          </div>
        </div>
      </template>
      <template slot="footer">
        <div class="btn-group">
          <v-btn class="btn btn-md btn-gray" b-size="btn-md" b-color="btn-gray">거부</v-btn>
          <v-btn class="btn btn-md" b-size="btn-md">동의</v-btn>
        </div>
      </template>
    </v-popup>

    <!-- '거부'를 선택시 -->
    <v-popup :visible="popVisible.pushReject" :footer="['confirm']" :is-close="false">
      <template slot="header">
        <div class="title">푸시 알림 수신거부 완료</div>
      </template>
      <template slot="body">
        <div class="app-popup">
          <div class="text-sub"><span>2021년 10월 19일</span><br />푸시 수신 거부 처리가 완료되었습니다.</div>
          <div class="notice">
            <i class="icon-info"></i>
            <div class="text-info">마이페이지 &gt; 설정 &gt; 알림 수신 설정에서 변경 가능</div>
          </div>
        </div>
      </template>
    </v-popup>

    <!-- '동의'를 선택시 -->
    <v-popup :visible="popVisible.pushAgree" :footer="['confirm']" :is-close="false">
      <template slot="header">
        <div class="title">푸시 알림 수신동의 완료</div>
      </template>
      <template slot="body">
        <div class="app-popup">
          <div class="text-sub"><span>2021년 10월 19일</span><br />푸시 수신 동의 처리가 완료되었습니다.</div>
          <div class="notice">
            <i class="icon-info"></i>
            <div class="text-info">마이페이지 &gt; 설정 &gt; 알림 수신 설정에서 변경 가능</div>
          </div>
        </div>
      </template>
    </v-popup>
  </div>
</template>

<script>
import { VPopup } from '~/components/element'
export default {
  components: {
    VPopup
  },
  props: {
    popVisible: {
      type: Object,
      defualt: {},
      required: true
    }
  }
}
</script>