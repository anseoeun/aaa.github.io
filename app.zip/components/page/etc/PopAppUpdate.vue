<template>
  <v-popup :visible="visible" :footer="['cancel', 'confirm']" :is-close="false">
    <template slot="header">
      <div class="title">업데이트 알림</div>
    </template>
    <template slot="body">
      <div class="app-popup">
        <div class="text-sub">새 버전의 앱이 등록되었습니다.<br />지금 업데이트하시겠습니까?</div>
      </div>
    </template>
  </v-popup>
</template>

<script>
import { VPopup } from '~/components/element'
export default {
  components: {
    VPopup
  },
  props: {
    visible: {
      type: Boolean,
      default: false
    }
  }
}
</script>