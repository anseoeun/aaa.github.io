<template>
  <v-popup :visible="visible" :footer="['confirm']" :is-close="false">
    <template slot="header">
      <div class="title">앱 접근권한 안내</div>
      <p class="header-description">캐스퍼 서비스 이용을 위해 다음 권한들을 사용합니다.</p>
    </template>
    <template slot="body">
      <div class="app-popup">
        <ul class="access-list">
          <li>
            <div>기기 및 앱 기록 <em class="t-blue">(필수)</em></div>
            <span>앱 버전 확인 및 사용성 개선</span>
          </li>
          <li>
            <div>사진 / 파일 <em>(선택)</em></div>
            <span>앱 버전 확인 및 사용성 개선</span>
          </li>
          <li>
            <div>카메라 <em>(선택)</em></div>
            <span>계약 시 각종 증빙서류 제출 사용후기 등록 등</span>
          </li>
          <li>
            <div>주소록 <em>(선택)</em></div>
            <span>SNS 공유</span>
          </li>
          <li>
            <div>위치 <em>(선택)</em></div>
            <span>주변 전시장 안내</span>
          </li>
        </ul>
        <div class="notice">
          <i class="icon-info"></i>
          <div class="text-info">
            선택적 접근 권한은 기능을 사용하실 때 허용 요청을 드리며, 허용하지 않으셔도 해당 기능 외의 서비스 이용은
            가능합니다.
          </div>
        </div>
      </div>
    </template>
  </v-popup>
</template>

<script>
import { VPopup } from '~/components/element'
export default {
  components: {
    VPopup
  },
  props: {
    visible: {
      type: Boolean,
      default: false
    }
  }
}
</script>