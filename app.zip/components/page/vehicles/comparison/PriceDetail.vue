<template>
  <section class="info-detail border-line" :class="{ open: isOptionsShow }">
    <v-btn class="summary-info" :class="{ active: isOptionsShow }" @click="isOptionsShow = !isOptionsShow">
      <h1 class="title">구입비용</h1>
      <i class="icon-toggle-arr off-gray" :class="{'on':isOptionsShow}"></i>
    </v-btn>
    <div v-show="isOptionsShow" class="detail-info">
      <div class="comparison-wrap">
          <div v-for="(item, index) in registDataLabel" :key="index" class="item-box">
            <strong class="title">{{ item }}
              <v-btn v-if="item === '취득세'" type="icon" icon-class="icon-info" @click="popVisible.infoAcquirement = true"></v-btn>
              <v-btn v-if="item === '공채금액(할인)'" type="icon" icon-class="icon-info" @click="popVisible.infoFund = true"></v-btn>
            </strong>
            <ul class="item-list">
              <template v-for="idx in 2">
              <li v-if="idx <= registList.length" :key="idx" class="item">
                <template v-if="Object.keys(registList[idx - 1])[index] === 'condition'">
                  <div>
                    <v-select
                      v-model="registList[idx - 1].condition.conditionVal"
                      :data="registList[idx - 1].condition.list"
                      :disabled="idx - 1 != 0 ? true : false"
                      placeholder="등록조건선택"
                    />
                  </div>
                  <div class="mg t-right">
                    <v-checkbox
                      :one-check="true"
                      :checked.sync="registList[idx - 1].condition.multichildVal"
                      :disabled="idx - 1 != 0 ? true : false"
                      class="sm-size"
                      >다자녀 감면</v-checkbox>
                  </div>
                </template>
                <template v-else-if="Object.keys(registList[idx - 1])[index] === 'area'">
                  <div>
                    <v-select
                      v-model="registList[idx - 1].area.areaVal"
                      :data="registList[idx - 1].area.areaList"
                      :disabled="idx - 1 != 0 ? true : false"
                      placeholder="등록지역선택"
                    />
                    <v-select
                      v-model="registList[idx - 1].area.area2Val"
                      :data="registList[idx - 1].area.area2List"
                      :disabled="idx - 1 != 0 ? true : false"
                      placeholder="등록지역상세선택"
                    />
                  </div>
                </template>
                <template v-else-if="Object.keys(registList[idx - 1])[index] === 'subsidyPrice'">
                    <div class="text"><b class="bold">{{ registList[idx - 1].subsidyPrice.price | comma }}원</b></div>
                    <div class="check-wrap">
                      <v-checkbox
                        :one-check="true"
                        :checked.sync="registList[idx - 1].subsidyPrice.treasury"
                        class="sm-size"
                        >국고 보조금</v-checkbox
                      >
                        <div class="check-text">
                          <div class="tit">승용 초소형 전기 자동차</div>
                          <div class="price">- {{ registList[idx - 1].subsidyPrice.treasuryPrice | comma }}</div>
                        </div>
                      <v-checkbox
                        :one-check="true"
                        :checked.sync="registList[idx - 1].subsidyPrice.municipality"
                        class="sm-size"
                        >지자체별 친환경 보조금</v-checkbox
                      >
                        <div class="check-text">
                          <div class="price">- {{ registList[idx - 1].subsidyPrice.municipalityPrice | comma }}</div>
                        </div>
                    </div>
                </template>
                <template v-else>
                  <div class="text"><b class="bold">{{ registList[idx - 1][Object.keys(registList[idx - 1])[index]] | comma }}원</b>
                    <div v-if="Object.keys(registList[idx - 1])[index] === 'registPrice' && parseInt(registList[0].registPrice) !== parseInt(registList[idx - 1].registPrice)" class="right margin">
                      <span v-if="parseInt(registList[0].registPrice) > parseInt(registList[idx - 1].registPrice)" class="down">
                        {{ registList[0].registPrice - registList[idx - 1].registPrice | comma }} 원
                      </span>
                      <span v-if="parseInt(registList[0].registPrice) < parseInt(registList[idx - 1].registPrice)" class="up">
                        {{ registList[idx - 1].registPrice - registList[0].registPrice | comma }} 원
                      </span>
                    </div>
                  </div>
                </template>
              </li>
              <li v-else :key="idx"></li>
              </template>
            </ul>
          </div>
      </div>
   </div>

    <!-- 취득세 안내  -->
    <!-- <info-acquirement :pop-visible="popVisible" /> -->
    <!-- 공채 안내 -->
    <!-- <info-fund :pop-visible="popVisible" /> -->
  </section>
</template>

<script>
// import InfoAcquirement from '~/components/page/payment/popup/InfoAcquirement'
// import InfoFund from '~/components/page/payment/popup/InfoFund'
export default {
  components: {
    // InfoAcquirement,
    // InfoFund
  },
  filters: {
    comma(val) {
      return String(val).replace(/\B(?=(\d{3})+(?!\d))/g, ',')
    }
  },
  data() {
    return {
      isOptionsShow: false,
      registDataLabel: ['등록비', '등록조건', '취득세', '등록지역', '공채금액(할인)', '친환경 보조금'],
      subsidyDataLabel: ['친환경차 보조금', '승용 및 초소형 전기차', '지자체별 친환경차 보조금'],
      registList :[
        {
          registPrice:'2669986',
          condition : {
            conditionVal: '3',
            list: [
              { value: '1', label: '일반인' },
              { value: '2', label: '장애 1-3급' },
              { value: '3', label: '시각장애 4급' }
            ],
            multichildVal: false,
          },
          tax: '2,500,000',
          area: {
            areaVal: '2',
            areaList: [
              { value: '1', label: '서울' },
              { value: '2', label: '경기' },
              { value: '3', label: '대구' }
            ],
            area2Val: '2',
            area2List: [
              { value: '1', label: '경기 안양시' },
              { value: '2', label: '경기 광명시' },
              { value: '3', label: '인천' }
            ],
          },
          sale: '47,924',
          subsidyPrice: {
            price: '0',
            treasury: false,
            municipality: false,
            treasuryPrice:'45471',
            municipalityPrice:'1034471'
          },
        },
        {
          registPrice:'2869986',
          condition : {
            conditionVal: '3',
            list: [
              { value: '1', label: '일반인' },
              { value: '2', label: '장애 1-3급' },
              { value: '3', label: '시각장애 4급' }
            ],
            multichildVal: false,
          },
          tax: '2,500,000',
          area: {
            areaVal: '2',
            areaList: [
              { value: '1', label: '서울' },
              { value: '2', label: '경기' },
              { value: '3', label: '대구' }
            ],
            area2Val: '2',
            area2List: [
              { value: '1', label: '경기 안양시' },
              { value: '2', label: '경기 광명시' },
              { value: '3', label: '인천' }
            ],
          },
          sale: '47,924',
          subsidyPrice: {
            price: '0',
            treasury: false,
            municipality: false,
            treasuryPrice:'45471',
            municipalityPrice:'1034471'
          },
        }
      ],
      popVisible: {
        infoAcquirement: false,
        infoFund: false
      }
    }
  },
  mounted(){

  },
  methods: {}
}
</script>
