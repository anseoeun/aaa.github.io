<template>
  <v-popup
    :visible="visible"
    :full-popup="true"
    class="full-popup"
    @close="
      $emit('close')
      popVisible = false
    "
  >
    <template slot="header">
      <div class="title">비교 차량 선택</div>
    </template>
    <template slot="body">
        <div class="compare-car-form">
          <div class="car-img">
            <!-- 2021.04.06(ver1.2) null이미지 추가 -->
            <template v-if="carImg.src !== undefined || carImg.src !== ''">
              <v-img :src="carImg.src" :alt="carImg.alt"></v-img>
              <b class="name">펠리세이드</b>
              <div class="prcie">35,720,000 원</div>
            </template>
            <template v-else>
              <v-img :src="carImg.null" alt="차량이미지 없음"></v-img>
            </template>
          </div>
          <div class="form-grid-list">
            <ul>
              <li>
                <strong class="form-label bold">차량검색</strong>
                <div class="form-group">
                  <div class="search-input-wrap label-input">
                    <label><span class="offscreen">차량검색 입력</span></label>
                    <div class="input-autocomplete">
                      <v-btn v-if="carVal !== ''" class="delete" @click="carVal = ''"></v-btn>
                      <v-input v-model="carVal" placeholder="직접 검색하여 차량을 선택해 보세요"></v-input>
                      <ul v-if="carVal.length > 0" class="layer">
                        <li><v-btn type="link" href="javascriopt:void(0);">페리세이드</v-btn></li>
                        <li><v-btn type="link" href="javascriopt:void(0);">페리세이드 하이브리드</v-btn></li>
                        <li><v-btn type="link" href="javascriopt:void(0);">펠리세이드 N Line</v-btn></li>
                      </ul>
                    </div>
                    <v-btn class="btn btn md white r">검색</v-btn>
                  </div>
                </div>
              </li>
              <li>
                <strong class="form-label bold">제조사</strong>
                <div class="form-group inbl-wrap">
                      <v-select v-model="manufacturerVal" :data="manufacturer" style="width:320px;" />
                </div>
              </li>
              <li>
                <strong class="form-label bold">차량선택</strong>
                <div class="form-group inbl-wrap">
                      <v-select v-model="carSelcVal" :data="carSelc" style="width:320px" />
                </div>
              </li>
            </ul>
          </div>
          <div class="btn-box">
            <v-btn class="btn btn md white r">선택하기</v-btn>
          </div>
        </div>

        <div class="compare-car-list">
          <p class="tit">자주 비교되는 차량
              <v-btn class="btn-info" type="icon" icon-class="icon-info" @click="$emit('popFrequentlyCoparison')">
                <span class="offscreen">공채안내팝업보기</span>
              </v-btn>
          </p>
          <ul>
            <li v-for="(item, index) in carList" :key="index">
              <div class="img">
                <v-img :src="item.carImg.src" :alt="item.carImg.alt"></v-img>
              </div>
              <b class="name">{{ item.name }}</b>
              <div class="prcie">{{ item.price }} 원</div>
            </li>
          </ul>
          <v-pagination :total="100" />
        </div>
    </template>
  </v-popup>
</template>

<script>
import { VPopup, VPagination } from '~/components/element'
export default {
  components: {
    VPopup,
    VPagination,
  },
  props: {
    visible: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      carVal: '',
      manufacturerVal: '',
      manufacturer: [
        {value:'1', label:'현대'},
        {value:'2', label:'기아'}
      ],
      carSelcVal: '',
      carSelc: [
        {value:'1', label:'펠리세이드'},
        {value:'2', label:'펠리세이드2'}
      ],
      carImg: {
        src: require('~/assets/images/temp/temp-payment-car-model.png'),
        null: require('~/assets/images/mycar/car-null.png'),
        alt: '펠리세이드',
      },
      carList: [
        {
          carImg: {
            src: require('~/assets/images/temp/temp-payment-car-model.png'),
            alt: '펠리세이드',
          },
          name:'VENUE',
          price:'35,720,000',
        },
        {
          carImg: {
            src: require('~/assets/images/temp/temp-payment-car-model.png'),
            alt: '펠리세이드',
          },
          name:'G70',
          price:'35,720,000',
        },
        {
          carImg: {
            src: require('~/assets/images/temp/temp-payment-car-model.png'),
            alt: '펠리세이드',
          },
          name:'캐스퍼',
          price:'35,720,000',
        }
      ]
    }
  },
}
</script>