<template>
  <v-popup
    :visible="popVisible.compareSelect"
    class="full-popup no-header trim-compare"
    @close="popVisible.compareSelect = false"
  >
    <template slot="body">
      <div class="body-title">
        <div class="section-title">트림 비교 보기</div>
        <p class="header-description">트림을 비교하며 보실 수 있습니다.</p>
      </div>
      <!-- trim-option -->
      <div ref="wrapper" class="trim-option" :class="{fix:wrapperFixed}">
        <!-- option-header -->
        <div class="option-header">
          <div ref="fixHeader" class="option-box">
            <div class="desc">
              <ul>
                <li v-for="(item, index) in dataLabel" :key="index">
                  <b class="tit">{{ item.name }}</b>
                  <div class="btn-wrap">
                    <v-btn class="btn md blue full" type="button">선택하기</v-btn>
                  </div>
                </li>
              </ul>
            </div>
          </div>
        </div>
        <!-- // option-header -->
        <!-- option-body -->
        <div class="option-body">
          <div v-for="(item, index) in dataOptList" :key="index" class="option-box">
            <div class="title">
              <b>{{ item.title }}</b>
            </div>
            <div class="desc">
              <ul>
                <li v-for="(opt, idx) in item.list" :key="idx">
                    <p v-if="opt.name !== ''" class="name">{{ opt.name }}</p>
                    <p class="sub">
                      <i v-if="opt.noOpt" class="icon"></i>
                      <span v-if="opt.sub !== ''" class="sub-txt">({{ opt.sub }})</span>
                    </p>
                </li>
              </ul>
            </div>
          </div>
        </div>
        <!-- // option-body -->
      </div>
      <!-- // trim-option -->
    </template>
  </v-popup>
</template>

<script>
// import { VBtn } from '~/components/element'
export default {
  components: {
    // VBtn,
  },

  props: {
    popVisible: {
      type: Object,
      defualt: {},
      required: true
    }
  },
  data() {
    return {
      dataLabel :[
        {
          name: '스마트',
          price: '12,890,000',
        },
        {
          name: '모던',
          price: '13,700,000',
        },
        {
          name: '인스퍼레이션',
          price: '15,200,000',
        },
      ],
      dataOptListLabel: ['엔진', '현대스마트센스','에어백', '휠&타이어', '시트', '열선시트' ],
      dataOptList: [
        {
          title:'엔진',
          list:[
            {name:'카파개선 1.0 엔진', sub:'카파개선 1.0 터보 엔진 선택가능'},
            {name:'카파개선 1.0 엔진', sub:'카파개선 1.0 터보 엔진 선택가능'},
            {name:'카파개선 1.0 엔진', sub:'카파개선 1.0 터보 엔진 선택가능'}
          ],
        },
        {
          title:'현대스마트센스',
          list:[
            {name:'', sub:'', noOpt: true},
            {name:'', sub:'현대 스마트센스I 선택가능', noOpt: true},
            {name:'현대 스마트센스I', sub:''}
          ],
        },
        {
          title:'에어백',
          list:[
            {name:'6에어백', sub:''},
            {name:'6에어백', sub:''},
            {name:'6에어백', sub:''}
          ],
        },
        {
          title:'휠&타이어',
          list:[
            {name:'15인치 스타일드 스틸휠', sub:''},
            {name:'15인치 스타일드 스틸휠', sub:'17인치 알로이휠 선택가능'},
            {name:'17인치 알로이휠', sub:''}
          ],
        },
        {
          title:'시트',
          list:[
            {name:'직물시트', sub:''},
            {name:'인조가죽 시트', sub:''},
            {name:'인조가죽 시트', sub:''}
          ],
        },
        {
          title:'열선시트',
          list:[
            {name:'', sub:'', noOpt: true},
            {name:'앞좌석 열선 시트', sub:''},
            {name:'앞좌석 열선 시트', sub:''},
          ],
        },
        {
          title:'통풍시트',
          list:[
            {name:'', sub:'', noOpt: true},
            {name:'운전석 통풍 시트', sub:''  },
            {name:'운전석 통풍 시트', sub:''},
          ],
        },
        {
          title:'폴딩시트',
          list:[
            {name:'뒷좌석 5:5 분할 폴딩 시트', sub:''},
            {name:'뒷좌석 5:5 분할 폴딩 시트', sub:''},
            {name:'운전석/동승석 풀 폴딩  ', sub:''},
          ],
        },
        {
          title:'헤드램프',
          list:[
            {name:'', sub:'프로젝션 헤드램프 선택가능', noOpt: true},
            {name:'', sub:'프로젝션 헤드램프 선택가능', noOpt: true},
            {name:'프로젝션 헤드램프', sub:''},
          ],
        },
        {
          title:'하이패스',
          list:[
            {name:'', sub:'', noOpt: true},
            {name:'', sub:'하이패스 시스템 선택가능', noOpt: true},
            {name:'하이패스 시스템', sub:''},
          ],
        },
        {
          title:'에어컨',
          list:[
            {name:'매뉴얼 에어컨', sub:''},
            {name:'매뉴얼 에어컨', sub:'풀오토 에어컨 선택가능'},
            {name:'매뉴얼 에어컨', sub:''},
          ],
        },
        {
          title:'버튼시동 & 스마트키',
          list:[
            {name:'', sub:'시스템 선택가능', noOpt: true},
            {name:'', sub:'시스템 선택가능', noOpt: true},
            {name:'버튼시동 & 스마트키 시스템', sub:''},
          ],
        },
        {
          title:'선루프',
          list:[
            {name:'', sub:'선택가능'},
            {name:'', sub:'선택가능'},
            {name:'', sub:'선택가능'},
          ],
        },
        {
          title:'내비게이션',
          list:[
            {name:'', sub:'8인치 와이드 내비게이션 선택가능', noOpt: true},
            {name:'', sub:'8인치 와이드 내비게이션 선택가능', noOpt: true},
            {name:'8인치 와이드 내비게이션', sub:''},
          ],
        },
        {
          title:'후방카메라',
          list:[
            {name:'', sub:'후방카메라 선택가능', noOpt: true},
            {name:'', sub:'후방카메라 선택가능', noOpt: true},
            {name:'후방카메라', sub:''},
          ],
        },
      ],
      wrapperFixed: false
    }
  },
  methods: {

  },
}
</script>
