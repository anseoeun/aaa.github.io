<template>
  <v-popup
    :visible="popVisible.recommendColor"
    class="full-popup"
    :full-popup="true"
    @close="popVisible.recommendColor = false"
  >
    <template slot="header">
      <div class="title offscreen">BEST 인기 색상</div>
    </template>
    <template slot="body">
      <div class="body-title">
        <div class="section-title">BEST 인기 색상</div>
        <p class="header-description">선호도가 높은 색상을 참고하여 내 차를 만들어보세요!</p>
      </div>
      <div class="recommend-color-wrap">
        <v-tab class="tab-default" :data="tabList" :contents="true">
          <template slot="contents">
            <div data-id="tab1">
              <div class="recommend-color-list">
                <p>
                  캐스퍼 구매자 중 42%가<br /><strong class="t-blue">러브 유얼셀프 그린 펄</strong>을 선택하셨습니다.
                </p>
                <ul>
                  <li>
                    <div class="car-img" :style="`background-image:url(${car1.src})`"></div>
                    <div class="recommend-color-info">
                      <span style="left: 100%" class="per-text"><strong>42</strong> %</span>
                      <p class="color-name">러브 유얼셀프 그린 펄</p>

                      <!-- 1위는 :current-per="100"(256rem) -> 2,3위는 1위 기준으로 비율대로 -->
                      <v-progress-bar current-per="100" current-color="#56853a" type="percent" total-width="100" />
                    </div>
                    <v-btn class="btn-normal" type="button">선택</v-btn>
                  </li>
                  <li>
                    <div class="car-img" :style="`background-image:url(${car2.src})`"></div>
                    <div class="recommend-color-info">
                      <span :style="{ left: car2.currentPer + '%' }" class="per-text"><strong>30</strong> %</span>
                      <p class="color-name">인텐스 블루펄</p>

                      <!-- 42%(1위)가 256rem -> 30%는 183rem -> 256rem의 71%가 183rem -->
                      <v-progress-bar
                        :current-per="car2.currentPer"
                        current-color="#202860"
                        type="percent"
                        total-width="100"
                      />
                    </div>
                    <v-btn class="btn-normal" type="button">선택</v-btn>
                  </li>
                  <li>
                    <div class="car-img" :style="`background-image:url(${car3.src})`"></div>
                    <div class="recommend-color-info">
                      <span :style="{ left: car3.currentPer + '%' }" class="per-text"><strong>12</strong> %</span>
                      <p class="color-name">타이랑 그레이 메탈릭</p>

                      <!-- 42%(1위)가 256rem -> 12%는 74rem -> 256rem의 29%가 74rem -->
                      <v-progress-bar
                        :current-per="car3.currentPer"
                        current-color="#4a4a4a"
                        type="percent"
                        total-width="100"
                      />
                    </div>
                    <v-btn class="btn-normal" type="button">선택</v-btn>
                  </li>
                </ul>
              </div>
            </div>
            <div data-id="tab2">20대 - Tab1과 같음</div>
            <div data-id="tab3">30대 - Tab1과 같음</div>
            <div data-id="tab4">40대 - Tab1과 같음</div>
            <div data-id="tab5">50대 이상 - Tab1과 같음</div>
          </template>
        </v-tab>
        <p class="bullet-star">
          홈페이지의 사진과 설명은 참고용이며 실체 차량에 탑재되는 기능과 설명은 상이할 수 있습니다.
        </p>
      </div>
    </template>
  </v-popup>
</template>

<script>
import { VTab } from '~/components/element'
import VProgressBar from '~/components/element/VProgressBar'
export default {
  components: {
    VTab,
    VProgressBar
  },
  props: {
    popVisible: {
      type: Object,
      defualt: {},
      required: true
    }
  },
  data() {
    return {
      tabList: [
        { value: 'tab1', label: '전체' },
        { value: 'tab2', label: '20대' },
        { value: 'tab3', label: '30대' },
        { value: 'tab4', label: '40대' },
        { value: 'tab5', label: '50대 이상' }
      ],
      car1: { src: require('~/assets/images/temp/temp-vehicles-car.png') },
      car2: { src: require('~/assets/images/temp/temp-vehicles-car.png'), currentPer: '71' },
      car3: { src: require('~/assets/images/temp/temp-vehicles-car.png'), currentPer: '29' }
    }
  }
}
</script>
