<template>
  <v-popup
    :visible="popVisible.detail"
    :full-popup="true"
    class="full-popup"
    @close="popVisible.detail = false"
  >
    <template slot="body">
      <div class="body-title">
        <div class="section-title">스마트</div>
        <p class="header-description">스마트 트림의 자세한 정보입니다.</p>
      </div>
      <div class="specification-wrap">
        <!-- 품목 -->
        <div class="section">
          <div class="basic border-line">
            <strong class="title">기본품목</strong>
            <ul class="tog-list">
              <li v-for="(item, index) in basicList" :key="index" :class="{on: basicListShow == index}">
                <v-btn class="list-tit" @click="setActive('basicListShow', index)">
                  <b>{{ item.name }}</b>
                  <i :class="['icon-tog-arr on-blue', { on: basicListShow == index }]"></i>
                </v-btn>
                <div v-if="basicListShow == index" class="conts">
                  <ul>
                    <li v-for="(opt, idx) in item.option" :key="idx">
                        <i class="icon-info"></i> <v-btn>{{ opt.name }}</v-btn>
                    </li>
                  </ul>
                </div>
              </li>
            </ul>
          </div>
          <!-- selection -->
          <div class="selection border-line">
            <strong class="title">선택품목</strong>
            <ul class="tog-list">
              <li v-for="(item, index) in selectionList" :key="index" :class="{on: selectionListShow == index}">
                <v-btn class="list-tit" @click="setActive('selectionListShow', index)">
                  <b>{{ item.name }}</b>
                  <i :class="['icon-tog-arr gray-off', { on: selectionListShow == index }]"></i>
                </v-btn>
                <div v-if="selectionListShow == index" class="conts">
                  <ul>
                    <li v-for="(opt, idx) in item.option" :key="idx">
                       <i class="icon-info"></i> <v-btn>{{ opt.name }}</v-btn>
                    </li>
                  </ul>
                </div>
              </li>
            </ul>
          </div>
          <!-- // selection -->
        </div>
      </div>
    </template>
  </v-popup>
</template>

<script>
import { VPopup } from '~/components/element'
export default {
  components: {
    VPopup,
  },
  props: {
    popVisible: {
      type: Object,
      defualt: {},
      required: true
    }
  },
  data() {
    return {
      basicListShow: -1,
      selectionListShow: -1,
      basicList: [
        {name: '파워트레인/성능', option: [
          { name: '카파개선 1.0 엔진', link: '/' },
          { name: '4단 자동변속기' },
          { name: '풋파킹 브레이크' }
        ]},
        {name: '안전', option: [
          { name: '카파개선 1.0 엔진', link: '/' },
          { name: '4단 자동변속기' },
          { name: '풋파킹 브레이크' }
        ]},
        {name: '외관', option: [
          { name: '카파개선 1.0 엔진', link: '/' },
          { name: '4단 자동변속기' },
          { name: '풋파킹 브레이크' }
        ]},
        {name: '시트', option: [
          { name: '카파개선 1.0 엔진', link: '/' },
          { name: '4단 자동변속기' },
          { name: '풋파킹 브레이크' }
        ]},
        {name: '편의', option: [
          { name: '카파개선 1.0 엔진', link: '/' },
          { name: '4단 자동변속기' },
          { name: '풋파킹 브레이크' }
        ]},
        {name: '멀티미디어', option: [
          { name: '카파개선 1.0 엔진', link: '/' },
          { name: '4단 자동변속기' },
          { name: '풋파킹 브레이크' }
        ]}
      ],
      selectionList: [
        {name: '옵션', option: [
          { name: '17인치 알로이휠&타이어', link: '/', price:'800,000'},
          { name: '4단 자동변속기', price:'200,000' },
          { name: '풋파킹 브레이크', price:'900,000' }
        ]},
        {name: '옵션2', option: [
          { name: '17인치 알로이휠&타이어', link: '/', price:'800,000'},
          { name: '4단 자동변속기', price:'200,000' },
          { name: '풋파킹 브레이크', price:'900,000' }
        ]}
      ],
      photoList: [
        {
          src: require('~/assets/images/temp/temp-car-option2.png'),
          alt: '구매후기사진'
        },
        {
          src: require('~/assets/images/temp/temp-car-option.png'),
          alt: '구매후기사진'
        },
        {
          src: require('~/assets/images/temp/temp-car-option2.png'),
          alt: '구매후기사진'
        }
      ],
    }
  },
  methods: {
    //하나만열리는 타입
    setActive(show, index){
      if(this[show] == index){
        this[show] = -1
      }else{
        this[show] = index
      }
    },
  }
}
</script>