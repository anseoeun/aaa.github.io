<template>
  <v-popup
    :visible="popVisible.trimChangeInfo"
    class="full-popup"
    :full-popup="true"
    @close="popVisible.trimChangeInfo = false"
  >
    <template slot="header">
      <div class="title offscreen">색상에 따른 트림변경 안내</div>
    </template>
    <template slot="body">
      <div class="body-title border-line-btm">
        <div class="text-head">
          <strong>{{ changeColorName }}</strong> 색상은<br /><strong>{{ changeTrimName }}</strong
          >에서만 선택 가능 합니다.
        </div>
        <p class="header-description">트림 변경 시 기존 선택한 내역이 초기화 됩니다.</p>
      </div>
      <div class="pop-trim-wrap">
        <div class="trim-info border-line-btm">
          <div class="contents-title">트림정보</div>
          <div class="body-contents">
            <div v-for="(item, index) in changeTrimInfo" :key="index">
              <div class="trim-box">
                <p class="name">{{ item.beforeSaleTrimName }}</p>
                <p class="price">
                  <strong>{{ item.beforeCarPrice | amount }}</strong> 원
                </p>
              </div>
              <div class="trim-box after">
                <p class="name">{{ item.changeSaleTrimName }}</p>
                <p class="price">
                  <strong>{{ item.changeCarPrice | amount }}</strong> 원
                </p>

                <!-- 가격인하 시 down class 추가 -->
                <p class="amount">
                  <strong>{{ item.changeCarPriceAmount | amount }}</strong> 원
                </p>
              </div>
            </div>
          </div>
        </div>

        <div class="trim-change-list border-line-btm">
          <div class="contents-title">변경 시 선택 해제되는 품목</div>
          <div class="body-contents">
            <ul>
              <!-- 삭제 시 delete class 추가 -->
              <li v-for="(item, index) in changeOptionInfo" :key="index" :class="item.class">
                <div class="prd-img">
                  <v-img :src="item.optionPrdImg" :alt="item.optionPrdName"></v-img>
                </div>

                <div class="prd-info">
                  <div class="prd-name">{{ item.optionPrdName }}</div>
                  <div class="prd-price">
                    <span>{{ item.optionPrdPrice | amount }}</span> 원
                  </div>
                </div>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </template>
    <template slot="footer">
      <div class="btn-group popup-footer-btn">
        <v-btn class="btn btn-gray" b-color="btn-gray" @click="popVisible.trimChangeInfo = false">취소</v-btn>
        <v-btn class="btn">변경하기</v-btn>
      </div>
    </template>
  </v-popup>
</template>

<script>
import { VBtn } from '~/components/element'
export default {
  components: {
    VBtn
  },

  props: {
    popVisible: {
      type: Object,
      defualt: {},
      required: true
    }
  },

  data() {
    return {
      changeColorName: '녹턴그레이',
      changeTrimName: 'Premium 트림',
      changeTrimInfo: [
        {
          beforeSaleTrimName: 'Smart',
          beforeCarPrice: '19,903,685',
          changeSaleTrimName: 'Premium',
          changeCarPrice: '17,903,685',
          changeCarPriceAmount: '2,000,000'
        }
      ],
      changeOptionInfo: [
        {
          class: 'delete',
          optionPrdImg: require('~/assets/images/temp/temp-car-option2.png'),
          optionPrdName: '통풍시트',
          optionPrdPrice: '2,000,000'
        }
      ]
    }
  }
}
</script>
