<template>
  <v-popup
    :width="'776px'"
    :visible="popVisible.partsAddInfo"
    :append-to-body="false"
    @close="popVisible.partsAddInfo = false"
  >
    <template slot="header">
      <div class="title light">
        <strong>{{ changeOptionName1 }}</strong
        >은(는) <strong>{{ changeOptionName2 }} 추가</strong> 후 선택 가능합니다.
      </div>
    </template>
    <template slot="body">
      <div class="pop-trim-wrap">
        <div class="trim-chang-list">
          <div class="contents-head">추가되는 품목</div>
          <div class="body-contents">
            <ul>
              <!-- 삭제 시 delete class 추가 -->
              <li v-for="(item, index) in changeOptionInfo" :key="index" :class="item.class">
                <div class="prd-img">
                  <v-img :src="item.optionPrdImg" :alt="item.optionPrdName"></v-img>
                </div>

                <div class="prd-info">
                  <div class="prd-name">{{ item.optionPrdName }}</div>
                  <div class="prd-price">
                    <span>{{ item.optionPrdPrice | amount }}</span> 원
                  </div>
                </div>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </template>
    <template slot="footer">
      <v-btn class="btn btn-lg btn-gray" b-size="btn-lg" b-color="btn-gray">취소</v-btn>
      <v-btn class="btn btn-lg" b-size="btn-lg">추가하기</v-btn>
    </template>
  </v-popup>
</template>

<script>
import { VBtn } from '~/components/element'
export default {
  components: {
    VBtn
  },

  props: {
    popVisible: {
      type: Object,
      defualt: {},
      required: true
    }
  },

  data() {
    return {
      changeOptionName1: '옵션명1',
      changeOptionName2: '옵션명2',
      changeOptionInfo: [
        {
          class: '',
          optionPrdImg: require('~/assets/images/temp/temp-car-option2.png'),
          optionPrdName: '옵션명2',
          optionPrdPrice: '+ 250,000'
        },
        {
          class: '',
          optionPrdImg: require('~/assets/images/temp/temp-car-option2.png'),
          optionPrdName: '하이패스 시스템',
          optionPrdPrice: '+ 250,000'
        }
      ]
    }
  }
}
</script>
