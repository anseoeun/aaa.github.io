<template>
  <v-popup
    :visible="popVisible.recommendOption"
    class="full-popup"
    :full-popup="true"
    @close="popVisible.recommendOption = false"
  >
    <template slot="header">
      <div class="title offscreen">BEST 옵션 조합</div>
    </template>
    <template slot="body">
      <div class="body-title">
        <div class="section-title">BEST 옵션 조합</div>
        <p class="header-description">인기있는 옵션조합으로 옵션을 빠르고 간편하게 선택해 보세요.</p>
      </div>
      <ul class="recommend-option-list">
        <li v-for="(item, index) in rankList" :key="index">
          <div class="ranking">
            <strong>{{ item.rank }}위</strong>
            <v-btn class="btn sm blue" type="button">선택하기</v-btn>
          </div>
          <div class="option-type">
            <ul>
              <li v-for="(data, idx) in item.optionList" :key="idx">
                <span>{{ data.name }}</span>
                <em>{{ data.price }} 원</em>
              </li>
            </ul>
            <div class="total">
              <span>총금액</span>
              <em
                ><strong>{{ item.total }}</strong> 원</em
              >
            </div>
          </div>
        </li>
      </ul>
      <!-- <ul class="recommend-option-list">
        <li>
          <div class="ranking">1위</div>
          <div class="option-type">
            <ul>
              <li>
                <span>선루프</span>
                <em>600,000 원</em>
              </li>
              <li>
                <span>스타일 패키지Ⅰ</span>
                <em>1,000,000 원</em>
              </li>
              <li>
                <span>터보패키지Ⅰ</span>
                <em>1,000,000 원</em>
              </li>
            </ul>
            <div class="total">총 <strong>2,300,000</strong>원</div>
          </div>
          <v-btn class="btn md blue line r" type="button">선택하기</v-btn>
        </li>
        <li>
          <div class="ranking">2위</div>
          <div class="option-type">
            <div class="total">총 <strong>0</strong>원</div>
          </div>
          <v-btn class="btn md blue line r" type="button">선택하기</v-btn>
        </li>
        <li>
          <div class="ranking">3위</div>
          <div class="option-type">
            <ul>
              <li>
                <span>선루프</span>
                <em>600,000 원</em>
              </li>
              <li>
                <span>스타일 패키지Ⅰ</span>
                <em>1,000,000 원</em>
              </li>
              <li>
                <span>하이패스</span>
                <em>1,000,000 원</em>
              </li>
              <li>
                <span>시트 패키지</span>
                <em>2,300,000 원</em>
              </li>
            </ul>
            <div class="total">총 <strong>2,300,000</strong>원</div>
          </div>
          <v-btn class="btn md blue line r" type="button">선택하기</v-btn>
        </li>
      </ul> -->
    </template>
  </v-popup>
</template>

<script>
import { VBtn } from '~/components/element'
export default {
  components: {
    VBtn
  },

  props: {
    popVisible: {
      type: Object,
      defualt: {},
      required: true
    }
  },
  data() {
    return {
      rankList: [
        {
          rank: '1',
          optionList: [
            { name: '선루프', price: '600,000' },
            { name: '17인치 알로이휠 & 타이어', price: '1,000,000' },
            { name: '터보패키지 I', price: '2,300,000' }
          ],
          total: '3,900,000'
        },
        {
          rank: '2',
          optionList: [{ name: '-', price: '0' }],
          total: '0'
        },
        {
          rank: '3',
          optionList: [
            { name: '에센셜 패키지', price: '800,000' },
            { name: '선루프', price: '600,000' },
            { name: '스타일패키지 I', price: '1,000,000' },
            { name: '터보패키지 I', price: '2,300,000' },
            { name: '하이패스', price: '200,000' }
          ],
          total: '3,900,000'
        }
      ]
    }
  }
}
</script>
