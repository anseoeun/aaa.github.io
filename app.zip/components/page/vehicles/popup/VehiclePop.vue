<template>
  <v-popup
    :visible="visible"
    :full-popup="true"
    class="vehicle-popup full-popup"
    @close="
      $emit('close')
    "
  >
    <template slot="header">
      <div class="title">최근 본 차 (5)</div>
    </template>
    <template slot="body">
      <div class="vehicle-pop-list-wrap">
        <ul class="vehicle-pop-list">
          <li v-for="(item, index) in carList" :key="index">
            <div class="top"><span class="date">{{ item.date }}</span></div>
              <ul class="car-list">
                <li v-for="(data, idx) in item.data" :key="idx">
                    <div class="car-info" :class="{soldout: data.soldout}">
                      <v-btn v-if="data.soldout" class="del"><span class="offscreen">삭제</span></v-btn>
                      <div class="img">
                         <v-btn type="nlink" to="/"><v-img :src="data.carImg.src" :alt="data.carImg.alt"></v-img>
                            <div v-if="data.txt !== undefined" class="layer-txt">{{ data.txt }}</div>
                         </v-btn>
                      </div>
                      <div class="desc">
                        <v-btn type="nlink" to="/" role="button">
                          <p class="tit">{{ data.name }}</p>
                          <p class="opt">{{ data.opt1 }}</p>
                          <p class="opt">{{ data.opt2 }}</p>
                          <div class="account">
                            {{ data.price }} 원
                          </div>
                        </v-btn>
                      </div>
                    </div>
                </li>
              </ul>
          </li>
        </ul>
      </div>
    </template>
  </v-popup>
</template>

<script>
import { VPopup } from '~/components/element'
export default {
  components: {
    VPopup,
  },
  props: {
    visible: {
      type: Boolean,
      default: false
    },
  },
  data() {
    return {
      carList: [
        {date:'2021.01.29 12:34',
          data:[
            {
              carImg: {
                src: require('~/assets/images/temp/temp-payment-car-model.png'),
                alt: 'AX 스마트스트림 가솔린 1.1 터보 프리미엄 밀레니얼 A/T',
              },
              name : 'AX 스마트스트림 가솔린 1.1 터보 프리미엄 밀레니얼 A/T',
              opt1 : '미드나잇 블랙 / 베이지',
              opt2 : '옵션2개',
              price : '33,000,000',
            }
          ]
        },
        {date:'2021.01.28 12:34',
          data:[
            {
              soldout: true,
              carImg: {
                src: require('~/assets/images/temp/temp-payment-car-model.png'),
                alt: 'AX 스마트스트림 가솔린 1.1 터보 프리미엄 밀레니얼 A/T',
              },
              name : 'AX 스마트스트림 가솔린 1.1 터보 프리미엄 밀레니얼 A/T',
              opt1 : '미드나잇 블랙 / 베이지',
              opt2 : '옵션업음',
              price : '33,000,000',
            },
            {
              carImg: {
                src: require('~/assets/images/temp/temp-payment-car-model.png'),
                alt: 'AX 스마트스트림 가솔린 1.1 터보 프리미엄 밀레니얼 A/T',
              },
              name : 'AX 스마트스트림 가솔린 1.1 터보 프리미엄 밀레니얼 A/T',
              opt1 : '미드나잇 블랙 / 베이지',
              opt2 : '옵션2개',
              price : '33,000,000',
              txt: '견적'
            }
          ]
        },
        {date:'2021.01.27 12:34',
          data:[
            {
              carImg: {
                src: require('~/assets/images/temp/temp-payment-car-model.png'),
                alt: 'AX 스마트스트림 가솔린 1.1 터보 프리미엄 밀레니얼 A/T',
              },
              name : 'AX 스마트스트림 가솔린 1.1 터보 프리미엄 밀레니얼 A/T',
              opt1 : '미드나잇 블랙 / 베이지',
              opt2 : '옵션2개',
              price : '33,000,000',
            },
            {
              carImg: {
                src: require('~/assets/images/temp/temp-payment-car-model.png'),
                alt: 'AX 스마트스트림 가솔린 1.1 터보 프리미엄 밀레니얼 A/T',
              },
              name : 'AX 스마트스트림 가솔린 1.1 터보 프리미엄 밀레니얼 A/T',
              opt1 : '미드나잇 블랙 / 베이지',
              opt2 : '옵션2개',
              price : '33,000,000',
            }
          ]
        }
      ]
    }
  }
}
</script>

