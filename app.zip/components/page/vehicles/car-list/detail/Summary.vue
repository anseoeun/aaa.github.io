<template>
  <section class="purchase-tool">
    <ul class="flag-list">
      <li v-for="(flag, index) in flagData" :key="index">{{ flag.flagName }}</li>
    </ul>
    <h1 class="title">캐스퍼 스마트 스트림 가솔린 1.1 터보 프리미엄 밀레니얼 A/T</h1>

    <div class="info-grid-list bold wide">
      <ul>
        <li>
          <strong class="info-title">외장색상</strong>
          <div class="info-group">소울 트로닉 오렌지 펄</div>
        </li>
        <li>
          <strong class="info-title">내장색상</strong>
          <div class="info-group">다크 그레이(YGN) +  칼라포인트</div>
        </li>
        <li>
          <strong class="info-title">옵션</strong>
          <div class="info-group">썬루프/컴포트 패키지 II/네비게이션 선택품목 명/선택품목명/선택품목명 전체 노출</div>
        </li>
      </ul>
    </div>

    <!-- 일반재고차 -->
    <div v-if="carType === '1'" class="info-grid-list bold wide">
      <ul>
        <li>
          <strong class="info-title">출고센터</strong>
          <div class="info-group">울산 출고 센터</div>
        </li>
        <li>
          <div class="info-title">
            <strong>탁송료</strong>
            <v-popover trigger="click" placement="bottom-start">
              <p>탁송료는 차량이 생산된공장에서 차량이 위치한 출고센터까지의 탁송료와 차량이위치했던 출고센터에서의 고객님이 요청하신 지역까지의 탁송료가 부과됩니다.</p>
              <v-btn slot="reference"><i class="icon-help"></i></v-btn>
            </v-popover>
          </div>
          <div class="info-group">
            <span>서울시 기준</span>
            <!-- 팝업연결 예정 -->
            <v-btn class="btn-link text-main">변경</v-btn>
            <span class="price"><strong class="text-head">270,000</strong> 원</span>
          </div>
        </li>
      </ul>
    </div>

    <!-- 생산월할인차 -->
    <div v-if="carType === '2'" class="info-grid-list bold wide">
      <ul>
        <li>
          <strong class="info-title">출고센터</strong>
          <div class="info-group">울산 출고 센터</div>
        </li>
        <li>
          <strong class="info-title">생산월</strong>
          <div class="info-group">2020년 8월</div>
        </li>
        <li>
          <div class="info-title">
            <strong>탁송료</strong>
            <v-popover trigger="click" placement="bottom-start">
              <p>탁송료는 차량이 생산된공장에서 차량이 위치한 출고센터까지의 탁송료와 차량이위치했던 출고센터에서의 고객님이 요청하신 지역까지의 탁송료가 부과됩니다.</p>
              <v-btn slot="reference"><i class="icon-help"></i></v-btn>
            </v-popover>
          </div>
          <div class="info-group">
            <span>서울시 기준</span>
            <!-- 팝업연결 예정 -->
            <v-btn class="btn-link text-main">변경</v-btn>
            <span class="price"><strong class="text-head">270,000</strong> 원</span>
          </div>
        </li>
      </ul>
    </div>

    <!-- 전시차 -->
    <div v-if="carType === '3'" class="info-grid-list bold wide">
      <ul>
        <li>
          <strong class="info-title">전시지점</strong>
          <div class="info-group">역삼지점 <v-btn class="btn-link" @click="$emit('viewMap')">지도보기</v-btn></div>
        </li>
        <li>
          <strong class="info-title">생산월</strong>
          <div class="info-group">2020년 8월</div>
        </li>
        <li>
          <div class="info-title">
            <strong>직접인수</strong>
            <v-popover trigger="click" placement="bottom-start">
              <p>전시 차량은 전시장으로 직접 방문하셔서 차량 상태 확인 후 인수하셔야 합니다.</p>
              <v-btn slot="reference"><i class="icon-help"></i></v-btn>
            </v-popover>
          </div>
        </li>
      </ul>
      <p class="text-main">※ 전시지점을 확인해 주세요 (직접 인수)</p>
    </div>

    <!-- 판촉차 : 출고센터 보유 차량 -->
    <div v-if="carType === '4'" class="info-grid-list bold wide">
      <ul>
        <li>
          <strong class="info-title">전시지점</strong>
          <div class="info-group">역삼지점 <v-btn class="btn-link" @click="$emit('viewMap')">지도보기</v-btn></div>
        </li>
        <li>
          <strong class="info-title">생산일</strong>
          <div class="info-group">2021.08.01</div>
        </li>
        <li>
          <strong class="info-title">주행거리</strong>
          <div class="info-group">500km</div>
        </li>
        <li>
          <div class="info-title">
            <strong>탁송료</strong>
            <v-popover trigger="click" placement="bottom-start">
              <p>탁송료는 차량이 생산된공장에서 차량이 위치한 출고센터까지의 탁송료와 차량이위치했던 출고센터에서의 고객님이 요청하신 지역까지의 탁송료가 부과됩니다.</p>
              <v-btn slot="reference"><i class="icon-help"></i></v-btn>
            </v-popover>
          </div>
          <div class="info-group">
            <span>서울시 기준</span>
            <!-- 팝업연결 예정 -->
            <v-btn class="btn-link text-main">변경</v-btn>
            <span class="price"><strong class="text-head">270,000</strong> 원</span>
          </div>
        </li>
      </ul>
      <p class="text-main">※ 전시지점을 확인해 주세요 (직접 인수)</p>
    </div>

    <!-- 판촉차 : 지점 보유 차량 -->
    <div v-if="carType === '5'" class="info-grid-list bold wide">
      <ul>
        <li>
          <strong class="info-title">전시지점</strong>
          <div class="info-group">역삼지점 <v-btn class="btn-link" @click="$emit('viewMap')">지도보기</v-btn></div>
        </li>
        <li>
          <strong class="info-title">생산일</strong>
          <div class="info-group">2021.08.01</div>
        </li>
        <li>
          <strong class="info-title">주행거리</strong>
          <div class="info-group">500km</div>
        </li>
        <li>
          <div class="info-title">
            <strong>직접인수</strong>
            <v-popover trigger="click" placement="bottom-start">
              <p>전시 차량은 전시장으로 직접 방문하셔서 차량 상태 확인 후 인수하셔야 합니다.</p>
              <v-btn slot="reference"><i class="icon-help"></i></v-btn>
            </v-popover>
          </div>
        </li>
      </ul>
      <p class="text-main">※ 판촉차 상세 설명을 꼭 확인해주세요.</p>
      <p class="text-main">※ 전시지점을 확인해 주세요 (직접 인수)</p>
    </div>

    <!-- <delivery-select :visible="deliverySelectPop" @close="deliverySelectPop = false" /> -->
  </section>
</template>

<script>
// import DeliverySelect from '~/components/page/vehicles/popup/DeliverySelect'
export default {
  components: {
    // DeliverySelect
  },
  data() {
    return {
      deliverySelectPop: false,
      isOptionsShow: false,
      isDetailShow: false,
      flagData: [{ flagName: '기획전' }],
      carType: '5',
    }
  }
}
</script>
