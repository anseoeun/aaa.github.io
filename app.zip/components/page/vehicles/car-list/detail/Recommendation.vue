<template>
  <div class="similar-recommend-list recommend-car-list">
    <div class="slide-list">
     <p class="title">이런 차량은 어떠세요?</p>
      <v-carousel
        :options="options"
        :data="slideList"
        :btmarrow="true"
      >
        <!-- :btmarrow="true" -->
        <template slot-scope="props">
          <nuxt-link to="/" role="button">
            <div class="car-img">
              <v-img :src="props.item.carImg.src" :alt="props.item.carImg.alt"></v-img>
            </div>
            <ul class="detail">
              <li class="fullname" v-html="props.item.fullName"></li>
              <li class="out-color">외장 : {{ props.item.outColor }}</li>
              <li class="in-color">내장 : {{ props.item.inColor }}</li>
              <li class="option">
                <v-popover trigger="click" placement="bottom-start" width="170">
                  <p v-for="(opt, index) in props.item.option" :key="index" class="t-black">{{ opt }}</p>
                  <v-btn slot="reference">
                    <span v-if="props.item.option.length <= 0">옵션없음</span>
                    <span v-else>옵션 {{ props.item.option.length }}개</span>
                    <i class="icon-opt-tog"></i>
                  </v-btn>
                </v-popover>
              </li>
            </ul>
            <ul class="price">
              <li class="total-price"><strong>{{ props.item.totalPrice }}</strong> 원</li>
            </ul>
          </nuxt-link>
        </template>
      </v-carousel>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      // 슬라이드
      options: {
        perPage: 2,
        perMove: 2,
        pagination: false,
        arrows: false,
        autoWidth: true,
      },
      slideList: [
        {
          carImg: {
            src: require('~/assets/images/temp/temp-payment-car-model.png'),
            alt: '베뉴 자가용 LPG 1.6 Modern A/T',
          },
          fullName: '베뉴 자가용 LPG 1.6<br />Modern A/T',
          outColor: '미드나잇 블랙',
          inColor: '블랙모노톤',
          option: [
            '옵션명 옵션명 옵션명',
            '옵션명 옵션명 옵션명',
            '옵션명 옵션명 옵션명',
            '옵션명 옵션명',
          ],
          totalPrice: '23,220,000',
        },
        {
          carImg: {
            src: require('~/assets/images/temp/temp-car1.png'),
            alt: '베뉴 자가용 LPG 1.6 Modern A/T',
          },
          fullName: '그랜저 자가용 LPG 1.6<br />Modern A/T',
          outColor: '미드나잇 블랙',
          inColor: '블랙모노톤',
          option: [
            '옵션명 옵션명 옵션명',
            '옵션명 옵션명',
          ],
          totalPrice: '23,220,000',
        },
        {
          carImg: {
            src: require('~/assets/images/temp/temp-review-car.png'),
            alt: '베뉴 자가용 LPG 1.6 Modern A/T',
          },
          fullName: '그랜저 자가용 LPG 1.6<br />Modern A/T',
          outColor: '미드나잇 블랙',
          inColor: '블랙모노톤',
          option: [
            '옵션명 옵션명 옵션명',
          ],
          totalPrice: '23,220,000',
        },
        {
          carImg: {
            src: require('~/assets/images/temp/temp-payment-car-model.png'),
            alt: '베뉴 자가용 LPG 1.6 Modern A/T',
          },
          fullName: '베뉴 자가용 LPG 1.6<br />Modern A/T',
          outColor: '미드나잇 블랙',
          inColor: '블랙모노톤',
          option: [],
          totalPrice: '23,220,000',
        },
        {
          carImg: {
            src: require('~/assets/images/temp/temp-payment-car-model.png'),
            alt: '베뉴 자가용 LPG 1.6 Modern A/T',
          },
          fullName: '그랜저 자가용 LPG 1.6<br />Modern A/T',
          outColor: '미드나잇 블랙',
          inColor: '블랙모노톤',
          option: [
            '옵션명 옵션명 옵션명',
            '옵션명 옵션명 옵션명',
            '옵션명 옵션명',
          ],
          totalPrice: '23,220,000',
        },
        {
          carImg: {
            src: require('~/assets/images/temp/temp-payment-car-model.png'),
            alt: '베뉴 자가용 LPG 1.6 Modern A/T',
          },
          fullName: '그랜저 자가용 LPG 1.6<br />Modern A/T',
          outColor: '미드나잇 블랙',
          inColor: '블랙모노톤',
          option: [
            '옵션명 옵션명 옵션명',
            '옵션명 옵션명 옵션명',
            '옵션명 옵션명 옵션명',
            '옵션명 옵션명',
          ],
          totalPrice: '23,220,000',
        },
        {
          carImg: {
            src: require('~/assets/images/temp/temp-payment-car-model.png'),
            alt: '베뉴 자가용 LPG 1.6 Modern A/T',
          },
          fullName: '베뉴 자가용 LPG 1.6<br />Modern A/T',
          outColor: '미드나잇 블랙',
          inColor: '블랙모노톤',
          option: [ ],
          totalPrice: '23,220,000',
        },
        {
          carImg: {
            src: require('~/assets/images/temp/temp-payment-car-model.png'),
            alt: '베뉴 자가용 LPG 1.6 Modern A/T',
          },
          fullName: '그랜저 자가용 LPG 1.6<br />Modern A/T',
          outColor: '미드나잇 블랙',
          inColor: '블랙모노톤',
          option: [
            '옵션명 옵션명 옵션명',
            '옵션명 옵션명 옵션명',
            '옵션명 옵션명 옵션명',
            '옵션명 옵션명',
          ],
          totalPrice: '23,220,000',
        },
        {
          carImg: {
            src: require('~/assets/images/temp/temp-payment-car-model.png'),
            alt: '베뉴 자가용 LPG 1.6 Modern A/T',
          },
          fullName: '그랜저 자가용 LPG 1.6<br />Modern A/T',
          outColor: '미드나잇 블랙',
          inColor: '블랙모노톤',
          option: [
            '옵션명 옵션명 옵션명',
            '옵션명 옵션명 옵션명',
            '옵션명 옵션명 옵션명',
            '옵션명 옵션명',
          ],
          totalPrice: '23,220,000',
        },
      ],
    }
  },
}
</script>
