<template>
  <div class="matching-box">
    <div class="box-wrap">
      <v-btn class="box-tit main-title"
       @click="isOptionsShow = !isOptionsShow"
      >
        직접 인수 방법 안내
        <i :class="['icon-toggle-arr black', { on: isOptionsShow }]"></i>
      </v-btn>
      <div v-show="isOptionsShow" class="box-desc">
        <div class="match-box">
          <div class="title">직접 인수 방법</div>
          <div class="desc">전시 차량은 고객님께서 전시장으로 직접 방문하셔서 차량 상태 확인 후 인수 하셔야 합니다.</div>
        </div>
        <div class="match-box">
          <div class="title">전시지점</div>
          <div class="desc info-grid-list">
            <ul>
              <li>
                <strong class="info-title">지점명</strong>
                <div class="info-group">강남 논현 지점</div>
              </li>
              <li>
                <strong class="info-title">주소</strong>
                <div class="info-group">서울특별시 서초구 강남대로</div>
              </li>
              <li>
                <strong class="info-title">전화</strong>
                <div class="info-group">02-542-1114</div>
              </li>
              <li>
                <strong class="info-title">근무시간</strong>
                <div class="info-group">평일 09:00 ~ 22:00</div>
              </li>
            </ul>
            <p class="bullet-star text-main t-gray">방문예약(통화)후 방문해주세요.</p>
          </div>
        </div>
        <!-- 지도 -->
        <div class="map-area">
          <div class="map-view" style="background:#eee;">지도영역</div>
          <v-btn class="btn-more">지도상세보기</v-btn>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  components: {},
  data() {
    return {
      isOptionsShow: false
    }
  }
}
</script>
