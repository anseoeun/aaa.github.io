<template>
  <div class="matching-box">
    <div class="box-wrap">
      <v-btn class="box-tit main-title"
       @click="isOptionsShow = !isOptionsShow"
      >
        구매 절차 안내
        <i :class="['icon-toggle-arr black', { on: isOptionsShow }]"></i>
      </v-btn>
      <div v-show="isOptionsShow" class="box-desc">
        <ol>
          <li>
            <div class="match-box">
              <div class="title">Step 1. 견적내기</div>
              <div class="desc">내차 만들기 메뉴에서 구매하고자 하는 차의 구입 비용을 계산해 봅니다.</div>
            </div>
          </li>
          <li>
            <div class="match-box">
              <div class="title">Step 2. 계약</div>
              <div class="desc">마이페이지 에서 견적서를 바탕으로 계약서를 작성하고 기한내에 계약금 납부와 전자서명을 합니다. (재고 차량의 경우 계약금을 납부하지 않아도 계약이 가능합니다.)</div>
            </div>
          </li>
          <li>
            <div class="match-box">
              <div class="title">Step 3. 차량 준비</div>
              <div class="desc">계약한 차량의 준비가 완료될 때까지 기다립니다. 차량의 준비 기간은 생산/재고 상황에 따라 짧게는 2~3일, 길게는 몇 달 까지 소요될 수 있습니다.</div>
            </div>
          </li>
          <li>
            <div class="match-box">
              <div class="title">Step 4. 차량 대금 결제</div>
              <div class="desc">대금 결제 요청 알림톡을 받으시면 마이페이지에서 개한 내에 차량 대금을 결제합니다.증빙서류가 필요할 경우 고객센터에 서 추가 서류를 요청 드릴 수 있으며 대금 결제가 완료되면 차량의 배송이 시작 됩니다.</div>
            </div>
          </li>
          <li>
            <div class="match-box">
              <div class="title">Step 5. 차량 배송 및 인수</div>
              <div class="desc">요청하신 곳으로 차량이 배송되면 차량 확인 후 인수합니다. 차량 인수 후 마이페이지 에서 인수확정을 하면 제작증이 발급됩니다.</div>
            </div>
          </li>
          <li>
            <div class="match-box">
              <div class="title">Step 6. 차량등록</div>
              <div class="desc">보험 가입 후 차량을 등록 합니다.</div>
            </div>
          </li>
        </ol>
        <v-btn class="btn-more" type="nlink" to="/">구매가이드 자세히 보기</v-btn>
        <div class="match-box">
          <div class="title">유의사항</div>
          <div class="desc">
            <p class="bullet text-main">주어진 시간 내 계약 또는 결제를 완료하지 않으면 자동 취소 될 수 있습니다. 각 단계별  안내에 따라 시간내에 완료하시기 바랍니다.</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  components: {},
  data() {
    return {
      isOptionsShow: false,
    }
  }
}
</script>
