<template>
  <v-popup :visible="popVisible.address" class="full-popup" :full-popup="true" @close="popVisible.address = false">
    <template slot="header">
      <div class="title">위치 수정</div>
    </template>
    <template slot="body">
      <div class="notice">
        <p class="contents-head t-center">아래에서 원하시는 지역을 선택하시면 위치정보가 재설정됩니다.</p>
      </div>
      <div v-label class="post-code-search label-input">
        <label><span class="offscreen">검색입력</span></label>
        <v-input v-model="postCode" class="post-code-input">
          <v-btn slot="suffix" type="icon" icon-class="icon-search"></v-btn>
        </v-input>
      </div>
      <p class="bullet">주소명(도로명, 건물번호)을 입력해주세요.<br />예) 현행로12, 양재동231</p>
      <div class="post-code-result">
        <p class="text-main">검색결과 {{ total }} 건</p>
        <div v-if="addrList.length > 0" class="addr-result-list">
          <ul>
            <li v-for="(addr, index) in addrList" :key="index">
              <strong>{{ addr.code }}</strong>
              <v-btn type="nlink" href="javascriopt:void(0);">{{ addr.address1 }}<br />{{ addr.address2 }}</v-btn>
            </li>
          </ul>
          <v-pagination :total="100" />
        </div>
        <!-- 결과없음 -->
        <div v-else class="addr-no-result">검색결과가 없습니다.</div>
      </div>
    </template>
  </v-popup>
</template>
<script>
import { VBtn, VInput, VPopup, VPagination } from '~/components/element'
export default {
  components: {
    VPopup,
    VBtn,
    VInput,
    VPagination
  },
  props: {
    popVisible: {
      type: Object,
      defualt: {},
      required: true
    }
  },
  data() {
    return {
      postCode: '',
      addrList: [
        { code: '06711', address1: '서울특별시 서초구 남부순환로317길', address2: '(서초동, 서초동 코아아파트)' },
        { code: '06711', address1: '서울특별시 서초구 남부순환로317길', address2: '(서초동, 서초동 코아아파트)' },
        { code: '06711', address1: '서울특별시 서초구 남부순환로317길', address2: '(서초동, 서초동 코아아파트)' },
        { code: '06711', address1: '서울특별시 서초구 남부순환로317길', address2: '(서초동, 서초동 코아아파트)' },
        { code: '06711', address1: '서울특별시 서초구 남부순환로317길', address2: '(서초동, 서초동 코아아파트)' },
        { code: '06711', address1: '서울특별시 서초구 남부순환로317길', address2: '(서초동, 서초동 코아아파트)' }
      ]
    }
  },
  computed: {
    total() {
      return this.addrList.length
    }
  }
}
</script>
