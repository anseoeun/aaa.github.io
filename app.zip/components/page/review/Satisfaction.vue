<template>
  <v-popup :visible="popVisible.satisfaction" @close="popVisible.satisfaction = false">
    <template slot="header">
      <div class="title">만족도 상세내역</div>
    </template>
    <template slot="body">
      <div class="pop-satisfaction-detail">
        <div class="main-title">총 만족도 <span class="text-main">( 287명 )</span></div>
        <ul class="review-regist">
          <li v-for="(item, index) in reviewGradeList" :key="index" :class="'grade-wrap view'">
            <div class="grade-wrap">
              <div class="grade-text">{{ item.gradeText[item.grade - 1] }}</div>
              <div class="grade">
                <v-rate v-model="item.grade" class="grade-check sm-size view"></v-rate>
              </div>
            </div>
            <div class="review-average">
              <v-progress-bar :current-per="item.currentPer" type="percent" total-width="100" />
              <span>{{ item.currentPer }}%</span>
            </div>
          </li>
        </ul>
        <div class="border-line">
          <ul class="satisfaction-wrap">
            <li v-for="(item, index) in satisfaction" :key="index">
              <div class="text-head">{{ item.cate }}</div>
              <ul class="vertical-list">
                <li v-for="(data, idx) in item.data" :key="idx">
                  <span :class="data.class">{{ data.title }}</span>
                  <!-- <em> {{ data.per }}%</em> -->
                  <div class="review-detail-average">
                    <v-progress-bar :current-per="data.currentPer" type="percent" total-width="100" />
                    <span :class="data.class">{{ data.currentPer }}%</span>
                  </div>
                </li>
              </ul>
            </li>
          </ul>
        </div>
      </div>
    </template>
    <template slot="footer">
      <div class="btn-group round">
        <v-btn class="btn btn-lg" b-size="btn-lg">확인</v-btn>
      </div>
    </template>
  </v-popup>
</template>

<script>
import { VRate } from '~/components/element'
import VProgressBar from '~/components/element/VProgressBar'
export default {
  components: {
    VRate,
    VProgressBar
  },
  props: {
    popVisible: {
      type: Object,
      defualt: {},
      required: true
    }
  },
  data() {
    return {
      reviewGradeList: [
        {
          grade: 5,
          gradeText: ['후회되요ㅜ.ㅜ', '아쉬워요..', '보통이예요', '만족해요', '최고예요!'],
          currentPer: '90'
        },
        {
          grade: 4,
          gradeText: ['후회되요ㅜ.ㅜ', '아쉬워요..', '보통이예요', '만족해요', '최고예요!'],
          currentPer: '7'
        },
        {
          grade: 3,
          gradeText: ['후회되요ㅜ.ㅜ', '아쉬워요..', '보통이예요', '만족해요', '최고예요!'],
          currentPer: '20'
        },
        {
          grade: 2,
          gradeText: ['후회되요ㅜ.ㅜ', '아쉬워요..', '보통이예요', '만족해요', '최고예요!'],
          currentPer: '1'
        },
        { grade: 1, gradeText: ['후회되요ㅜ.ㅜ', '아쉬워요..', '보통이예요', '만족해요', '최고예요!'], currentPer: '0' }
      ],
      satisfaction: [
        {
          cate: '구매과정',
          data: [
            { title: '쉽고 편안했어요.', currentPer: '10' },
            { title: '무난하게 진행했어요.', currentPer: '85', class: 'active' },
            { title: '과정이 번거로워요.', currentPer: '5' }
          ]
        },
        {
          cate: '가성비',
          data: [
            { title: '가격대비 최고예요.', currentPer: '10' },
            { title: '제 값 그대로예요.', currentPer: '85', class: 'active' },
            { title: '가격보다 아쉬워요.', currentPer: '5' }
          ]
        },
        {
          cate: '디자인',
          data: [
            { title: '화면보다 멋져요.', currentPer: '10' },
            { title: '화면처럼 맘에 들어요.', currentPer: '85', class: 'active' },
            { title: '조금 아쉽지만 괜찮아요.', currentPer: '5' }
          ]
        },
        {
          cate: '승차감',
          data: [
            { title: '무척 좋아요.', currentPer: '10' },
            { title: '보통이예요.', currentPer: '85', class: 'active' },
            { title: '보조장치가 필요해요.', currentPer: '5' }
          ]
        }
      ]
    }
  }
}
</script>
