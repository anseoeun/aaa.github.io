<template>
  <header class="header">
    <div class="header-area type-sub">
      <div class="btn-left-area">
        <button class="back">Back</button>
      </div>
      <h1>{{ heading }}</h1>
      <div class="btn-right-area">
        <button v-show="btns.home" class="home">Home</button>
        <button v-show="btns.list" class="list">List</button>
      </div>
    </div>
  </header>
</template>

<script>
export default {
  data() {
    return {
      heading: null,
      btns: {
        home: false,
        list: false
      }
    }
  },
  created() {
    this.$nuxt.$on('subject', (title) => {
      this.heading = title
    })
    this.$nuxt.$on('home', (boolean) => {
      this.btns.home = boolean
    })
    this.$nuxt.$on('list', (boolean) => {
      this.btns.list = boolean
    })
  },
}
</script>
