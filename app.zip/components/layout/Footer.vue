<template>
  <footer>
    <section class="notice-area">
      <h1>공지</h1>
      <ul>
        <li v-for="noti in notice" :key="noti.title">
          <nuxt-link :to="noti.link">{{ noti.title }}</nuxt-link>
        </li>
      </ul>
    </section>
    <div class="footer-area">
      <p>계약/출고 관련 문의 <a :href="`tel:${tellNumber}`">{{ tellNumber }}</a>
      </p>
      <ul class="btn-area">
        <li v-for="quick in quickLinks" :key="quick.title">
          <nuxt-link :to="quick.link" class="btn sm white r">{{ quick.title }}</nuxt-link>
        </li>
      </ul>
      <ul class="footer-info">
        <li v-for="regi in registration" :key="regi.title">
          {{ regi.title + '&nbsp;' + regi.number }}
        </li>
      </ul>
      <ul class="footer-info">
        <li>
          대표이사 김현대
          <nuxt-link to="/" class="line-link">사업자등록번호확인</nuxt-link>
        </li>
        <li>
          대표전화 <a :href="`tel:${tellNumber}`">{{ tellNumber }}</a>
        </li>
      </ul>
      <ul class="footer-info">
        <li>주소 {{ address }}</li>
        <li>호스팅서비스제공 {{ hosting }}</li>
      </ul>
      <p class="copyright">
        Copyright &copy; hyundai motor company. All rights reserved.
      </p>
      <ul class="footer-link">
        <li v-for="foot in footMenu" :key="foot.title">
          <nuxt-link :to="foot.link">{{ foot.title }}</nuxt-link>
        </li>
      </ul>
    </div>
  </footer>
</template>

<script>
export default {
  name: 'Footer',
  data() {
    return {
      notice: [
        { title: '독자기술 기반 수소연료전지 발전 시스템 본격', link: '/' },
      ],
      tellNumber: '02-3488-0200',
      quickLinks: [
        { title: '자주하는 질문', link: '/' },
        { title: '1:1문의하기', link: '/' },
      ],
      registration: [
        { title: '사업자등록번호', number: '101-81-09147' },
        { title: '통신판매업신고번호', number: '2002-01546' },
      ],
      address: '서울시 서초구 현릉로 12',
      hosting: '업체명',
      footMenu: [
        { title: '이용약관', link: '/' },
        { title: '개인정보보호방침', link: '/' },
        { title: '회사소개', link: '/' },
      ],
    }
  }
}
</script>

