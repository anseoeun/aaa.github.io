<template>
  <header class="header">
    <div class="header-area type-full">
      <h1>{{ heading }}</h1>
      <div class="btn-right-area">
        <button class="close">Close</button>
      </div>
    </div>
  </header>
</template>

<script>
export default {
  name: 'HeaderBack',
  data() {
    return {
      heading: null,
    }
  },
  created() {
    this.$nuxt.$on('subject', (title) => {
      this.heading = title
    })
  },
}
</script>
