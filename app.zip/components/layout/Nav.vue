<template>
  <nav>
    <h1 class="nav-title"><span class="offscreen">CASPER</span></h1>
    <section v-for="menu in gnbMenu" :key="menu.name">
      <h1>{{ menu.name }}</h1>
      <ul>
        <li v-for="sub in menu.subMenu" :key="sub.name">
          <nuxt-link :to="sub.to">{{ sub.name }}</nuxt-link>
        </li>
      </ul>
    </section>
    <ul class="side-menu">
      <li v-for="side in sideMenu" :key="side.name">
        <nuxt-link :to="side.to">{{ side.name }}</nuxt-link>
      </li>
    </ul>
    <button class="nav-close" @click="onClose()">메뉴닫기</button>
  </nav>
</template>

<script>
export default {
  name: 'Nav',
  props: {
    isOpen: {
      type: Boolean,
      default: false
    },
    isClose: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      gnbMenu: [
        {
          name: '소개',
          to: 'javascript:void(0)',
          subMenu: [
            { name: '하이라이트', to: '/' },
            { name: '디지털 쇼룸', to: '/' },
            { name: '갤러리', to: '/' },
            { name: '제원/가격', to: '/' },
            { name: '모델비교', to: '/' }
          ]
        },
        {
          name: '체험',
          to: '/',
          subMenu: [
            { name: '시승신청', to: '/' },
            { name: '전시장 안내', to: '/' }
          ]
        },
        {
          name: '구매',
          to: '/',
          subMenu: [{ name: '나만의 캐스퍼 만들기', to: '/' }]
        },
        {
          name: '혜택',
          to: '/',
          subMenu: [
            { name: '쿠폰', to: '/' },
            { name: '이벤트', to: '/' },
            { name: '제휴카드', to: '/' }
          ]
        },
        { name: '후기', to: '/', subMenu: [{ name: '구매후기', to: '/' }] },
      ],
      sideMenu: [
        { name: '구매가이드', to: '/' },
        { name: '고객지원', to: '/' }
      ]
    }
  },
  methods: {
    onClose() {
      this.$emit('close', [this.isOpen, this.isClose])
    }
  }
}
</script>
