<template>
  <div>
    <ul class="floating-list">
      <li v-if="type == 'vehicle'">
        <v-btn role="button" class="btn-floating-vehicle no-hover" @click="popVehicleVisible = true">
          <span class="vehicle-list"
            ><em>최근 본 차량(</em><strong class="number">12</strong
            ><em>) 바로가기</em></span
          >
        </v-btn>
      </li>
      <li v-if="type == 'faq'">
        <nuxt-link to="/" role="button" class="btn-floating-faq">
          <span>FAQ 바로가기</span>
        </nuxt-link>
      </li>
      <li>
        <nuxt-link to="/" role="button" class="btn-floating-chat">
          <span>실시간 톡상담 서비스입니다.</span>
        </nuxt-link>
      </li>
      <li><v-top /></li>
    </ul>
    <vehicle-pop :visible="popVehicleVisible" @close="popVehicleVisible = false"></vehicle-pop>
  </div>
</template>

<script>
import VTop from '~/components/element/VTop'
import VehiclePop from '~/components/page/vehicles/popup/VehiclePop'
export default {
  components: {
    VTop,
    VehiclePop
  },
  props: {
    type: {
      type: String,
      default: '',
    },
  },
  data(){
    return {
      popVehicleVisible: false
    }
  }
}
</script>
