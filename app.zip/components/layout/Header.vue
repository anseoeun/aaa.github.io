<template>
  <header class="header">
    <div class="header-area">
      <div class="btn-left-area">
        <button class="all-menu" @click="isOpen = true">전체메뉴</button>
      </div>
      <h1>{{ heading }}</h1>
      <div class="btn-right-area">
        <button class="my-page">마이페이지</button>
        <!-- <button class="alarm" :class="{ on: isAlarm }">알림</button> -->
      </div>
    </div>
    <aside-nav :class="classChange()" @close="onNavClose" />
  </header>
</template>

<script>
import Nav from '~/components/layout/Nav'
export default {
  name: 'Header',
  components: {
    AsideNav: Nav
  },
  data() {
    return {
      isOpen: false,
      isClose: false,
      //isAlarm: true,
      heading: null,
    }
  },
  created() {
    this.$nuxt.$on('subject', (title) => {
      this.heading = title
    })
  },
  methods: {
    onNavClose() {
      this.isOpen = false
      this.isClose = true
    },
    classChange() {
      if (this.isOpen) {
        return 'active'
      } else if (this.isClose) {
        return 'close'
      }
    }
  },
}
</script>
