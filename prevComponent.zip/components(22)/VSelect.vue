<template>
  <el-select
    :value="selected"
    :class="`${selectType}`"
    :placeholder="placeholder"
    :disabled="disabled"
    :popper-append-to-body="false"
    @input="onInput"
  >
    <el-option
      v-for="item in list"
      :key="item.value"
      :label="item[labelKey]"
      :value="item[valueKey]"
    >
      <slot :item="item"></slot>
    </el-option>
  </el-select>
</template>

<script>
export default {
  name: 'VSelect',
  props: {
    value: {
      type: String,
      default: ''
    },
    valueKey: {
      type: String,
      default: 'value'
    },
    labelKey: {
      type: String,
      default: 'label'
    },
    placeholder: {
      type: String,
      default: '선택하세요'
    },
    data: {
      type: Array,
      default: () => []
    },
    disabled: {
      type: Boolean,
      default: false
    },
    firstSelect: {
      type: Boolean,
      default: false
    },
    selectType: {
      type: String,
      default: ''
    }
  },
  data() {
    return {
      selected: ''
    }
  },

  computed: {
    list() {
      return this.data.length ? this.data.map((obj) => ({ ...obj })) : [{ [this.valueKey]: '', [this.labelKey]: '' }]
    }
  },

  watch: {
    value(newValue, oldValue) {
      if (newValue !== oldValue) {
        this.selected = newValue
        this.$emit('change', newValue)
      }
    },

    data(newList, oldList) {
      let isDiff = newList.length !== oldList.length
      if (!isDiff) {
        newList.forEach(({ value, label }, index) => {
          if (oldList[index].value !== value || oldList[index].label) {
            isDiff = true
          }
        })
      }

      if (isDiff) {
        if (!newList.length) {
          this.selected = ''
          this.$emit('input', '')
        } else {
          this.selected = this.value === '' && this.firstSelect ? newList[0][this.valueKey] : this.value
          this.$emit('input', this.selected)
        }
      }
    }
  },

  created() {
    this.selected = this.value === '' && this.firstSelect ? this.list[0][this.valueKey] : this.value
    if (this.selected !== '') {
      this.$emit('change', this.selected)
    }
  },

  methods: {
    onInput(value) {
      this.$emit('input', value)
    },

    onChange(value) {
      this.$emit('change', value)
    }
  }
}
</script>
