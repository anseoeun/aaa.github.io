<template>
  <div class="radio-group">
    <label class="inp-chk" v-for="(item, index) in data" :key="index" >
      <input type="radio"
        :name="item.name"
        :value="item.value"
        v-model="item.checked"
        :checked="item.checked"
        @change="handleChange"
      >
      <span class="ic"></span>
      <span class="t">{{item.label}}</span>
    </label>
  </div>
</template>

<script>
export default {
  name: 'VRadio',
  props: {
    data: {
      type: Array,
      default: () => [],
    },
  },
  data() {
    return {}
  },
  methods: {
    handleChange(e) {
      this.$emit('change', e)
    },
  }

}
</script>