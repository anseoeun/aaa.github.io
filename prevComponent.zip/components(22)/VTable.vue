<template>
 <div>
   {{name}}
 </div>

</template>

<script>
export default {
  props: ["name"],

  data() {
    return {}
  },

  methods: {
    handleClick(e) {
      if (this.type === 'submit') {
        e.preventDefault()
      }
      this.$emit('click', e)
    }
  }
}
</script>