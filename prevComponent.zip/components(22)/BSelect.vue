<template>
<div>
    <select :name="name" :value="value" @change="handleChange" v-model="selected">
      <option value="" disabled selected style="vdisplay:none !important;background:#fff !important" v-if="!selected">Select your option</option>
      <option v-for="(item, index) in data" :key="index" :value="item.value">{{item.label}}</option>
    </select>
</div>

</template>

<script>
export default {
  name: 'VSelectNormal',
  props: {
    name:{
      type:String,
      default:''
    },
    value:{
      type:String,
      default:''
    },
    data: {
      type: Array,
      default: () => [],
    },
  },
  data() {
    return {
      selected:''
    }
  },
  methods: {
    handleChange(e) {
      console.log(this.selected)
      this.$emit('change', this.selected)
    },
  },
  mounted(){
    this.value !== '' ? this.selected = this.value : ''
  }

}
</script>
