<template>
<div
  v-if="isOpen"
  :width="popWidth"
  :dim="isDim"
  :showClose="showClose"
  :dimClose="dimClose"
  class="layerpopup"
>
    <div class="dim" v-if="isDim" @click="onCloseDim"></div>
    <div class="pop-wrap" :style="'width:'+popWidth+'px'">
        <div class="popup">
            <v-btn v-if="showClose" class="close"  @click="onClose">닫기</v-btn>
            <div v-if="$slots.header" class="pop-header">
              <slot name="header" />
            </div>
            <div class="pop-body">
              <slot name="contents" />
            </div>
        </div>
    </div>
</div>
</template>

<script>
export default {
  name: 'VPopup',
  head() {
    return {
      bodyAttrs: {
        style: this.isOpen ? 'overflow:hidden' : ''
      }
    }
  },
  props: {
    isOpen:{
      type:Boolean,
      default:false
    },
    popWidth:{
      type:Number,
      default:300
    },
    isDim:{
      type:Boolean,
      default:true
    },
    showClose:{
      type:Boolean,
      default:true
    },
    dimClose:{
      type:Boolean,
      default:true
    },
  },
  data() {
    return {

    }
  },

  methods: {
    onClose() {
      this.$emit('close')
    },
    onCloseDim(dimClose) {
      if(this.dimClose) this.$emit('close')
    },
  }
}
</script>