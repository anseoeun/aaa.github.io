<template>
  <nuxt-link
    v-if="type === 'nlink'"
    class="btn"
    :to="to"
    :target="target"
  >
   <slot></slot>
  </nuxt-link>

  <a
    v-else-if="type === 'link'"
    class="btn"
    :href="href"
    :target="target"
  >
   <slot></slot>
  </a>

  <button
    v-else
    class="btn"
    :type="type"
    :disabled="disabled"
    @click="handleClick"
  >
    <slot></slot>
  </button>

</template>

<script>
export default {
  name: 'VBtn',
  props: {
    to: {
      type: String,
      default: ''
    },
    href: {
      type: String,
      default: '/'
    },
    target: {
      type: String,
      default: '_blank'
    },
    type: {
      type: String,
      default: 'button'
    },
    disabled: {
      type: Boolean,
      default: false
    },
    data: {
      type: Array,
      default: () => []
    },
  },

  data() {
    return {}
  },

  methods: {
    handleClick(e) {
      if (this.type === 'submit') {
        e.preventDefault()
      }
      this.$emit('click', e)
    }
  }
}
</script>