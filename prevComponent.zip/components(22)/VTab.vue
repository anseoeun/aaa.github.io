<template>
  <div class="tab-wrap">
    <div class="tab-menu">
      <!-- Tab -->
      <ul>
        <li v-for="(item, index) in data" :key="index"
          :class="{ on: tabIdx === index }"
        >
          <button
            type="button"
            @click="changeTab(index)"
          >
            {{ item.label}}
          </button>
        </li>
      </ul>
    </div>
    <!-- Tab Contents -->
    <!-- <template v-if="contents"> -->
      <slot name="contents" :tabIdx="tabIdx"></slot>
    <!-- </template> -->
  </div>
</template>
<script>
export default {
  props: {
    data: {
      type: Array,
      default: () => [],
    },
  },

  data() {
    return {
      tabIdx: 0,
    }
  },

  methods: {
    changeTab(idx){
      this.tabIdx = idx;
    },
  },
}
</script>