<template>
  <el-input-number
    v-model="num"
    :min="1"
    :max="10"
    @change="handleChange"
  ></el-input-number>
</template>

<script>
export default {
  props: {
    vModel: {
      type: [Number, String],
      default: ''
    },
    min: {
      type: [Number, String],
      default: 1
    },
    max: {
      type: [Number, String],
      default: 10
    },
  },

  data() {
    return {
      num: 1
    };
  },
  methods: {
    handleChange(value) {
      this.$emit('change', value)
      console.log(value)
    }
  }
}
</script>
