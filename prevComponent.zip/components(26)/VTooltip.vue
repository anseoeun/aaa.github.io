<template>
  <el-tooltip
    :class="'item'"
    :effect="effect"
    :content="content"
    :placement="placement"
  >
      <slot />
    </el-tooltip>

</template>

<script>

export default {
  name: 'VTooltip',
  props: {
    effect: {
      type: String,
      default: 'dark'
    },
    content: {
      type: String,
      default: ''
    },
    placement: {
      type: String,
      default: ''
    },
  },

  data() {
    return { }
  },
}
</script>
