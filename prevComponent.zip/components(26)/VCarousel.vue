<template>
  <el-carousel
    :class="'slider'"
    :autoplay="autoplay"
    :interval="interval"
    :trigger="trigger"
    :arrow="arrow"
    :indicator-position="indicatorPosition"
  >
    <!-- data list item -->
    <div v-if="!customItem">
      <el-carousel-item v-for="(item, index) in list" :key="index">
        <slot :item="item"></slot>
      </el-carousel-item>
    </div>

    <!-- custom element item -->
    <div v-else>
      <slot></slot>
    </div>
  </el-carousel>

</template>

<script>

export default {
  name: 'VCarousel',
  props: {
    data: {
      type: Array,
      default: () => []
    },
    height: {
      type: String,
      default: ''
    },
    autoplay: {
      type: Boolean,
      default: false
    },
    interval: {
      type: Number,
      default: 3000
    },
    trigger: {
      type: String,
      default: 'click'
    },
    arrow: {
      type: String,
      default: ''
    },
    indicatorPosition: {
      type: String,
      default: 'outside'
    },

    customItem: {
      type: Boolean,
      default: false
    }
  },

  data() {
    return { }
  },
  computed: {
    list() {
      return this.data.map((item) => ({ ...item }))
    }
  },
}
</script>
