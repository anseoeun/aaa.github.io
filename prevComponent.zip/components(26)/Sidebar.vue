<template>
  <div>
    sidebar
  </div>
</template>

<script>
export default {}
</script>