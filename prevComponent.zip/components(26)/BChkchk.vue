<template>
  <div>
    <input
      type="checkbox"
      v-on:change="handleChange"
    >
  </div>
</template>

<script>
export default {
  name: 'VChkchk',
  model: {
    event: 'change'
  },
  props: {
    checked:{
      type:Boolean,
      default:false
    },
  },
  methods: {
    handleChange($event) {
      this.$emit('change', $event.target.checked)
    },
  }
}
</script>