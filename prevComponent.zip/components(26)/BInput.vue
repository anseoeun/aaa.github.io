<template>
  <div>
    <input
      type="text"
      :placeholder="placeholder"
      v-on:change="handleChange"
      v-on:keyup="handleKeyup"
    >
  </div>
</template>

<script>
export default {
  name: 'VInput',
  model: {
    event: 'change'
  },
  props: {
    placeholder:String,
    default:''
  },
  methods: {
    handleChange($event) {
      this.$emit('change', $event.target.value)
    },
    handleKeyup($event) {
      this.$emit('keyup', $event.target.value)
    },
  }
}
</script>