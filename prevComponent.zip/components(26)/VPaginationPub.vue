<template>
  <div class="pagenation">
    <v-btn i-name="btn-prevall">
      <span class="ir">처음</span>
    </v-btn>
    <v-btn i-name="btn-prev">
      <span class="ir">이전</span>
    </v-btn>

    <div class="page-index text-b1">
      <n-link to="" class="on">
        <span>1</span>
      </n-link>
      <n-link to="">
        <span>2</span>
      </n-link>
      <n-link to="">
        <span>3</span>
      </n-link>
      <n-link to="">
        <span>4</span>
      </n-link>
      <n-link to="">
        <span>5</span>
      </n-link>
      <n-link to="">
        <span>6</span>
      </n-link>
      <n-link to="">
        <span>7</span>
      </n-link>
      <n-link to="">
        <span>8</span>
      </n-link>
      <n-link to="">
        <span>9</span>
      </n-link>
      <n-link to="">
        <span>10</span>
      </n-link>
    </div>

    <v-btn i-name="btn-next" :class="'ative'">
      <span class="ir">다음</span>
    </v-btn>
    <v-btn i-name="btn-nextall" :class="'ative'">
      <span class="ir">마지막</span>
    </v-btn>
  </div>
</template>
