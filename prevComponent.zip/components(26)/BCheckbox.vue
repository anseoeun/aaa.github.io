<template>
<!-- group type , all check -->
  <div v-if="checkGroup"
    class="checkbox-group"
  >
    <label v-if="allCheck" class="inp-chk all-chk">
      <input type="checkbox" :checked="isAllcheck" @change="allCheckToggle">
      <span class="ic"></span>
      <span class="t"><slot /></span>
    </label>
    <label class="inp-chk" v-for="(item, index) in data" :key="index">
      <input type="checkbox"
        v-model="item.value"
        :name="item.name"
        :value="item.value"
        :checked="item.value"
        @change="inpCheck(index)"
      >
      <span class="ic"></span>
      <span class="t">{{item.label}}</span>
    </label>
  </div>
  <!-- one type -->
  <label v-else
    :class="['inp-chk', disabled ? 'disabled': '']"
  >
      <input type="checkbox"
        :name="name"
        :checked="value"
        :disabled="disabled"
        @change="handleChange"
      >
      <span class="ic"></span>
      <span class="t"><slot /></span>
	</label>
</template>

<script>
export default {
  name: 'VCheckbox',
  model: {
    event: 'change'
  },
  props: {
    type:{
      type:String,
      default:''
    },
    name:{
      type:String,
      default:''
    },
    checkGroup:{
      type:Boolean,
      default:false
    },
    value:{
      type:Boolean,
      default:false
    },
    allCheck:{
      type:Boolean,
      default:false
    },
    disabled:{
      type:Boolean,
      default:false
    },
    data: {
      type: Array,
      default: () => [],
    },
  },
  data() {
    return {
      isAllcheck:false,
    }
  },
  methods: {
    handleChange($event) {
      this.$emit('change', $event.target.value)
    },
    allCheckToggle(){
        this.isAllcheck ? this.isAllcheck = false : this.isAllcheck = true
        this.data.forEach((value, index, array) => {
            value.value = this.isAllcheck
        });
    },
    inpCheck(index){
        let checked = 0
        this.data.forEach((value, index, array) => {
            value.value ? checked = ++checked : ''
        });
        checked === this.data.length ? this.isAllcheck = true : this.isAllcheck = false
    },

  }

}
</script>