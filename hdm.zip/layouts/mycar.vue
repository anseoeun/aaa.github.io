<template>
  <div class="wrap">
    <a href="javascript:void(0);" class="skip-nav" role="button"
      >본문 바로가기</a
    >
    <header>
      <my-car-header />
    </header>
    <div class="container">
      <div class="contents">
        <Nuxt />
      </div>
    </div>
  </div>
</template>

<script>
import MyCarHeader from '~/components/layout/MyCarHeader'
export default {
  head() {
    return {
      meta: [
        {
          hid: 'keywords',
          name: 'keywords',
          content: ''
        },
        {
          hid: 'description',
          name: 'description',
          content: ''
        },
        {
          hid: 'author',
          name: 'author',
          content: ''
        },
        {
          property: 'og:type',
          content: ''
        },
        {
          property: 'og:title',
          content: ''
        },
        {
          property: 'og:description',
          content: ''
        },
        {
          property: 'og:image',
          content: ''
        },
        {
          property: 'og:url',
          content: ''
        },
      ],
    }
  },
  components: {
    MyCarHeader,
  },
}
</script>

<style lang="scss">
@import '~/assets/style/shop.scss';
</style>
