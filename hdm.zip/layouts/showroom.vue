<template>
  <div class="wrap">
    <a href="javascript:void(0);" class="skip-nav" role="button"
      >본문 바로가기</a
    >
    <header>
      <header-comp id="commonHeader" />
      <show-room-header />
    </header>
    <div class="container">
      <div class="contents">
        <Nuxt />
      </div>
    </div>
    <footer>
      <footer-comp />
    </footer>
    <div class="floating-menu">
      <float />
    </div>
  </div>
</template>

<script>
import Header from '~/components/layout/Header'
import ShowRoomHeader from '~/components/layout/ShowRoomHeader'
import Footer from '~/components/layout/Footer'
import Float from '~/components/layout/Float'

export default {
  head() {
    return {
      meta: [
        {
          hid: 'keywords',
          name: 'keywords',
          content: ''
        },
        {
          hid: 'description',
          name: 'description',
          content: ''
        },
        {
          hid: 'author',
          name: 'author',
          content: ''
        },
        {
          property: 'og:type',
          content: ''
        },
        {
          property: 'og:title',
          content: ''
        },
        {
          property: 'og:description',
          content: ''
        },
        {
          property: 'og:image',
          content: ''
        },
        {
          property: 'og:url',
          content: ''
        },
      ],
    }
  },
  components: {
    HeaderComp: Header,
    FooterComp: Footer,
    ShowRoomHeader,
    Float,
  },
  mounted() {
    this.setShowroom()
  }
}
</script>

<style lang="scss">
@import '~/assets/style/shop.scss';
</style>
