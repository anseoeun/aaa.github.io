<template>
  <v-popup
    popup-type="v2"
    :visible="popShow.downPayRefundPop"
    class="fieldset-popup"
    @close="popShow.downPayRefundPop = false"
  >
    <h3 slot="header">{{popupTitle}} 환불</h3>
    <template slot="body">
      <div class="refund-bank-account-pop">
        <div class="popup-header">
          <h3>환불계좌 입력</h3>
        </div>
        <div class="popup-information">
          현금 결제 환불 금액을 수령하실 계좌를 입력해주세요.
          <br />주 계약자 본인명의의 계좌만 등록 가능합니다.
        </div>
        <form>
          <div class="popup-content">
            <ul class="list-information">
              <li>
                <div class="title">예금주</div>
                <div class="content">{{ mainContractorName }}</div>
              </li>
              <li>
                <div class="title">은행명</div>
                <div class="content">
                  <el-select v-if="bankList !== null" v-model="bank" placeholder="은행 선택">
                    <el-option
                      v-for="item in bankList"
                      :key="item.value"
                      :label="item.label"
                      :value="item.value"
                    ></el-option>
                  </el-select>
                </div>
              </li>
              <li>
                <div class="title">계좌번호</div>
                <div class="content">
                  <span class="back-form-item">
                    <v-input v-model="guja" name="banknumber" type="text" class="back-form-item" />
                  </span>
                  <span class="sub-text">'-'없이 숫자만 입력해 주세요.</span>
                </div>
              </li>
            </ul>
          </div>
          <div style="margin-top:20px;" class="btn-group center">
            <v-btn b-size="btn-md" b-color="btn-gray" @click="popShow.downPayRefundPop = false">취소</v-btn>
            <v-btn b-size="btn-md" b-color="btn" @click="reqRefundProc()">저장</v-btn>
          </div>
        </form>
        <div style="text-align:left;margin-top:10px;" class="popup-information">
          *계좌 등록 완료 후에는 수정이 불가능하오니, 신중히 입력해주세요.
          <br />*환불 처리는 영업일 기준 최대 7일까지 소요될 수 있습니다.
        </div>
      </div>
    </template>
  </v-popup>
</template>


<script>
import lIsEmpty from 'lodash/isEmpty'
import { VInput, VBtn, VPopup } from '~/components/element'
import { mapGetters, mapActions } from 'vuex'
export default {
  components: {
    VInput,
    VBtn,
    VPopup
  },
  props: {
    popShow: {
      type: Object,
      default: () => [],
      required: true
    },
    saleContractNo: {  //paramForPayment035   (계약금취소)
      type: String,
      default: ''
    },
    mainContractorName: {
      type: String,
      default: ''
    },
    paramForPayment022List: {  // 차량대금 환불 처리시   
      type: Array,
      default: () => [],
      required: false   //계약금 환불 팝업에서는 존재하지 않을수 있다.
    }
  },
  data() {
    return {
      // popShow2: {
      //   commonAlertPop: false
      // },
      bankList: [{ label: '', value: '' }],
      bank: '',
      guja: '',
      apiEPayment035ReqParm: {
        saleCnttNo: '',
        bank: '',
        guja: '',
        procDivs: ''
      },
      apiEPayment022ReqParm: {
        saleCnttNo: '',
        stlNos: 0,
        stlMeanNo: '',
        addStlRqSn: '',
        addStlTrtmSn: '',
        bank: '',
        guja: '',
        amount: '',
        procDivs: ''
      },
      error : null
    }
  },
  computed: {
    ...mapGetters({
      getCommonCodes: 'commonCodes',
      getCancellationDownPayment: 'paymentModules/getCancellationDownPayment', // API-E-결제서비스-035 (계약금 취소)
      getRefundCashRslt : 'paymentModules/getRefundCashRslt',  //API-E-결제서비스-022 (현금 환불대기/환불처리/입금취소)
    }),
    popupTitle() {
      let title = ''
      if(this.saleContractNo) title = '계약금'
      if(this.paramForPayment022List.length > 0){
          title += `${title.length>0? ' / ':''}차량대금`
      } 
      return title
    }
  },
  watch: {
    getCommonCodes(newVal) {
      if (!lIsEmpty(newVal.P037)) {
        this.bankList = newVal.P037
      }
    }
  },
  created() {
    this.$store.dispatch('loadCommonCodes', { systemTypeCode: 'E', codeTypeCode: 'P037' }) // 은행명
  },
  methods: {
    /**
     * 계약금 환불    API-E-결제서비스-035 
       차량대금 환불  API-E-결제서비스-022
     */
    ...mapActions({
      cancellationDownPayment: 'paymentModules/GET_CANCELLATION_DOWN_PAYMENT',
      reqRefundCash: 'paymentModules/GET_REFUND_CASH',   // API-E-결제서비스-022 (현금 환불대기/환불처리/입금취소)
    }),
    async reqRefundProc() {
      this.error = null
      this.$nuxt.$loading.start()
      //계약금 취소처리 (단건)
      if(this.saleContractNo){
        //console.log('계약금 취소처리 :>> ', this.saleContractNo)
        await this.reqRefundProc035()
      } 
      // 차량대금 취소처리 (다건)
      for (const param of this.paramForPayment022List) {
        //console.log('차량대금 취소처리 :>> ', param)
        await this.reqRefundProc022(param)
      }
      
      this.$nuxt.$loading.finish()
      if(this.error){
        this.$alert(this.error)
      } 
      else this.fnCloseAlertPop()
    },
    async reqRefundProc035() { 
      const vm = this
      this.apiEPayment035ReqParm.saleCnttNo = this.saleContractNo
      this.apiEPayment035ReqParm.bank = this.bank
      this.apiEPayment035ReqParm.guja = this.guja
      this.apiEPayment035ReqParm.procDivs = 'RP' // 환불처리
      await this.cancellationDownPayment({ query : this.apiEPayment035ReqParm
      , customErr: (err)=> {
        //console.log('API-E-결제서비스-035 (계약금 취소) err :>> ', err)
        vm.setErrorMessage(err, '035 custom')
      }
      }) //API-E-결제서비스-035 (계약금 취소)
      if(!(this.getCancellationDownPayment?.data?.errCd === '0')){  //실패한경우
          await this.setErrorMessage(this.getCancellationDownPayment , '035 result') 
      } 
    },
    async reqRefundProc022( param ) {
      
      const vm = this
      this.apiEPayment022ReqParm = {...param}
      this.apiEPayment022ReqParm.bank = this.bank
      this.apiEPayment022ReqParm.guja = this.guja
      this.apiEPayment022ReqParm.procDivs = 'RP' // 환불처리
      await this.reqRefundCash({ query : this.apiEPayment022ReqParm
      , customErr: (err)=> {
        //console.log('결제서비스-022 (현금 환불대기/환불처리/입금취소) err :>> ', err)
        vm.setErrorMessage(err, '022 custom')
      }
      })   // API-E-결제서비스-022 (현금 환불대기/환불처리/입금취소)
      if(!(this.getRefundCashRslt?.data?.errCd === '0')){  //실패한경우
        await this.setErrorMessage(this.getRefundCashRslt , '022 result') 
      } 
    },
    /** 계약금, 차량구매대금 등 복수개 순차처리시 에러가 여러번 출력되는 것을 방지하는 처리 (첫 에러 메세지만 표시함) 20.11.16 */
    setErrorMessage(errObj, no) {
      if(!this.error){ 
        this.error = (errObj.rspStatus.rspCode === '0000') ?  errObj?.data?.errMsg : errObj?.rspStatus?.rspMessage
        console.log('setError Message :>> ', no , this.error)
      } 
    },
    fnCloseAlertPop() {
      //this.popShow2.commonAlertPop = false
      this.popShow.downPayRefundPop = false
    }
  }
}
</script>
