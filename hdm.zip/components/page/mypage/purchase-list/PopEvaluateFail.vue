<template>
  <v-popup
    :visible="visible"
    :width="'550px'"
    @close="
      $emit('close')
      popVisible = false
    "
    @confirm="
      $emit('close')
      popVisible = false
    "
  >

    <template slot="header">
      <div class="title">간편 심사 실패</div>
    </template>
    <template slot="body">
      <p class="contents-head t-center">무서류 간편 심사를 실패했습니다.</p>
      <p class="text-main gray">
        재시도 하시거나, 직접 파일을 업로드하여 서류를 제출 바랍니다.<br />
        (업로드 파일이 있는 경우 모두 삭제)
      </p>
    </template>
    <template slot="footer">
      <div class="btn-group">
        <v-btn class="btn btn-lg" b-size="btn-lg">무서류 간편 심사 재시도</v-btn>
        <v-btn class="btn btn-lg" b-size="btn-lg">파일 업로드 심사</v-btn>
      </div>
    </template>
  </v-popup>
</template>

<script>
import { VPopup } from '~/components/element'
export default {
  components: {
    VPopup
  },
  props: {
    visible: {
      type: Boolean, 
      default: false
    },
  },
}
</script>