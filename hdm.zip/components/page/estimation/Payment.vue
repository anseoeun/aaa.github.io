<template>
  <section class="information-detail">
    <div class="summary-info">
      <h1 class="title">결제 수단</h1>
      <p class="summary-text">(견적금액+단기의무보험료)</p>
      <div class="total-price">
        결제예정금액 <span class="price">30,472,300</span> 원
      </div>
    </div>
    <div class="detail-info payment">
      <v-tab class="tab-default line" :data="tabList" :contents="true">
        <template slot="contents">
          <div data-id="tab1" class="info-grid-list">
            <ul>
              <li>
                <div class="info-title full">
                  <strong>출고 전 납입총액</strong>
                  <span class="price bold">10,472,300 원</span>
                </div>
                <div class="info-group full">
                  <ul class="desc-list">
                    <li>
                      <em>계약금</em>
                      <span class="price">100,000 원</span>
                    </li>
                    <li>
                      <em>인도금</em>
                      <span class="price">100,000 원</span>
                    </li>
                    <li>
                      <em>단기의무보험료</em>
                      <span class="price">100,000 원</span>
                    </li>
                  </ul>
                </div>
              </li>
            </ul>
          </div>
          <div data-id="tab2" class="info-grid-list">
            <ul>
              <li>
                <div class="info-title full">
                  <strong>할부상품</strong>
                  <em class="product bold">표준형</em>
                  <!-- 팝업 -->
                  <v-btn class="btn-more" @click="popSaleInfo = true">할부조건 변경</v-btn>
                </div>
              </li>
              <li>
                <div class="info-title full">
                  <strong>월 납입금액</strong>
                  <span class="price bold">월 289,959 원</span>
                </div>
                <div class="info-group full">
                  <ul class="desc-list">
                    <li>
                      <em>할부원금</em>
                      <span class="price">2,000,000 원</span>
                    </li>
                    <li>
                      <em>할부기간</em>
                      <span class="last">36개월</span>
                    </li>
                    <li>
                      <em>금리</em>
                      <span class="last">4.5%</span>
                    </li>
                  </ul>
                </div>
              </li>
              <li>
                <div class="info-title full">
                  <strong>출고 전 납입총액</strong>
                  <span class="price bold">10,472,300 원</span>
                </div>
                <div class="info-group full">
                  <ul class="desc-list">
                    <li>
                      <em>계약금</em>
                      <span class="price">100,000 원</span>
                    </li>
                    <li>
                      <em>인도금</em>
                      <span class="price">100,000 원</span>
                    </li>
                    <li>
                      <em>단기의무보험료</em>
                      <span class="price">100,000 원</span>
                    </li>
                    <li>
                      <em>할부인지대</em>
                      <span class="price">100,000 원</span>
                    </li>
                  </ul>
                </div>
              </li>
            </ul>
            <p class="bullet">할부 한도 조회를 통해 나의 정확한 할부 이용 가능 금액을 알아보세요.<v-btn class="btn-more">내 할부한도 조회</v-btn></p>
          </div>
        </template>
      </v-tab>
    </div>
  </section>
</template>

<script>
export default {
  components: {
  },
  data() {
    return {
      isOptionsShow: false,
      tabList: [
        { value: 'tab1', label: '일시불 (현금/신용카드)' },
        { value: 'tab2', label: '할부 월 100,000 원 ~' },
      ],
    }
  },
}
</script>