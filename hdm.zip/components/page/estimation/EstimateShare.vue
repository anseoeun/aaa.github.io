<template>
  <div class="estimate-share">
    <div class="purchase-wrap">
      <div class="estimate-description">
        <div class="car-img">
          <v-img :src="carImg.src" :alt="carImg.alt"></v-img>
          <v-btn class="btn-3d" type="icon" icon-class="icon-3d" @click="popConfig = true"><span class="offscreen">3D configurator 보기</span></v-btn>
        </div>
        <div class="info-grid-list">
          <ul>
            <li>
              <strong class="info-title">견적 번호</strong>
              <p class="info-group full">U00000040282</p>
            </li>
            <li>
              <strong class="info-title">견적 기준일</strong>
              <p class="info-group full">2021년 1월 25일</p>
            </li>
            <li class="total-price">
              <strong class="info-title"><span class="bold">홍길동</span> 님의</strong>
              <div class="info-group full">
                <p class="t-blue">총 차량 금액 <strong class="price">37,000,000</strong> 원</p>
              </div>
            </li>
          </ul>
          <p class="bullet">견적기준일 이후 재 견적 시 가격 및 정책 등의 변경에 의하여 같은 조건의 차량에 대한 견적이 일치하지 않을 수 있습니다.</p>
        </div>
        <div class="btn-wrap">
          <v-btn class="btn lg blue line r">이 차로 새 견적내기</v-btn>
          <v-btn class="btn lg blue r">계약하기</v-btn>
        </div>
      </div>
      <!-- 견적사항 -->
      <section class="information-detail">
        <div class="summary-info">
          <h1 class="title">견적사항</h1>
        </div>
        <div class="detail-info">
          <div class="info-grid-list">
            <ul>
              <li>
                <strong class="info-title">모델</strong>
                <div class="info-group">
                  <p>AX 스마트스트림 가솔린 1.1 터보 프리미엄 밀레니얼 A/T</p>
                  <span class="price">33,000,000 원</span>
                </div>
              </li>
              <li>
                <strong class="info-title">외장 색상</strong>
                <div class="info-group">
                  <ul class="color-list">
                    <li>
                      <div class="color">
                        <div class="color-sample" :style="`background-color:${outColor.color}`"></div>
                        <div class="color-txt">{{ outColor.txt }}</div>
                      </div>
                    </li>
                  </ul>
                  <span class="price">0 원</span>
                </div>
              </li>
              <li>
                <strong class="info-title">내장 색상</strong>
                <div class="info-group">
                  <ul class="color-list">
                    <li>
                      <div class="color">
                        <div class="color-sample" :style="`background-color:${inColor.color}`"></div>
                        <div class="color-txt">{{ inColor.txt }}</div>
                      </div>
                    </li>
                  </ul>
                </div>
              </li>
              <li>
                <strong class="info-title">옵션</strong>
                <div class="info-group">
                  <ul class="desc-list">
                    <li v-for="(option, index) in optionData" :key="index">
                      <em>{{ option.name }}</em>
                      <ul>
                        <li v-for="(subopt, idx) in option.subOption" :key="idx">
                          {{ subopt.name }} <span class="price">{{ subopt.price }} 원</span>
                        </li>
                      </ul>
                    </li>
                  </ul>
                </div>
              </li>
              <li>
                <strong class="info-title">탁송료</strong>
                <div class="info-group">
                  <p>배달탁송 / 서울시 ( 3월 2주차 출고예정 )</p>
                  <v-popover trigger="hover" placement="bottom-start">
                    <p>현 시점 계약완료 기준으로 재고 및<br />생산계획 기반 산출된 예상출고일이며,<br />당사 사정에 의하여 변경될 수 있으니<br />단순 참고만 하시기 바랍니다.</p>
                    <v-btn slot="reference"><i class="icon-help"></i></v-btn>
                  </v-popover>
                  <span class="price">0 원</span>
                </div>
              </li>
              <li>
                <strong class="info-title">할인/포인트</strong>
                <div class="info-group">
                  <ul class="desc-list">
                    <li v-for="(discountRate, index) in discountData" :key="index">
                      <em>{{ discountRate.discountName }}</em>
                      <span class="price">{{ discountRate.discountPrice }} 원</span>
                    </li>
                  </ul>
                </div>
              </li>
              <li>
                <strong class="info-title">면세조건</strong>
                <div class="info-group">
                  <ul class="desc-list">
                    <li>
                      <em><span class="flag">경차</span>일반인 (다자녀)</em>
                    </li>
                    <li>
                      <em>세액 감면 혜택</em>
                      <span class="price">(-) 100,000 원</span>
                    </li>
                  </ul>
                </div>
              </li>
            </ul>
          </div>
          <div class="info-grid-list">
            <ul>
              <li>
                <strong class="info-title bold full">블루멤버스</strong>
                <div class="info-group full">
                  <ul class="desc-list">
                    <li>
                      <em>적립 예정 포인트</em>
                      <p>차량 구매 1회차</p>
                      <span class="last">5,000 P</span>
                    </li>
                  </ul>
                </div>
              </li>
            </ul>
          </div>
        </div>
      </section>
      <!-- 일시불 -->
      <!-- 구입예상비용 : 일시불 -->
      <section class="information-detail">
        <div class="summary-info">
          <h1 class="title">구입 예상 비용</h1>
        </div>
        <div class="detail-info">
          <div class="info-grid-list line">
            <ul>
              <li>
                <strong class="info-title">결제 수단</strong>
                <div class="info-group">
                  <p>일시불 <span class="sub-text">(현금/신용카드)</span></p>
                </div>
              </li>
              <li>
                <strong class="info-title">출고 전 납입 총액</strong>
                <div class="info-group">
                  <span class="price">85,300 원</span>
                  <ul class="desc-list">
                    <li>
                      <em>계약금</em>
                      <span class="price">100,000 원</span>
                    </li>
                    <li>
                      <em>인도금</em>
                      <span class="price">100,000 원</span>
                    </li>
                    <li>
                      <em>단기의무보험료</em>
                      <span class="price">100,000 원</span>
                    </li>
                  </ul>
                </div>
              </li>
              <li>
                <strong class="info-title">등록비 <span class="sub-text">(별도, 참고용)</span></strong>
                <div class="info-group">
                  <span class="price">85,300 원</span>
                  <ul class="desc-list">
                    <li>
                      <em>취득세</em>
                      <span class="price">0 원</span>
                    </li>
                    <li>
                      <em>공채 <span class="sub-text">(서울/할인 기준)</span></em>
                      <span class="price">0 원</span>
                    </li>
                    <li>
                      <em>종지대 <span class="sub-text">(수입인지)</span></em>
                      <span class="price">0 원</span>
                    </li>
                    <li>
                      <em>차량번호판</em>
                      <span class="price">0 원</span>
                    </li>
                    <li>
                      <em>등록대행 수수료</em>
                      <span class="price">0 원</span>
                    </li>
                  </ul>
                </div>
              </li>
            </ul>
          </div>
        </div>
      </section>
      <!-- 총금액 : 일시불 -->
      <div class="purchase-total-price">
        <ul>
          <li class="t-blue">
            총 차량 견적 금액
            <strong class="price">38,000,000</strong> 원
          </li>
          <li>
            출고 전 납입총액
            <strong class="price">38,000,000</strong> 원
            <p class="sub-text">단기의무 보험교 포함</p>
          </li>
        </ul>
      </div>
      <!-- 할부 -->
      <!-- 구입예상비용 : 할부 -->
      <section class="information-detail">
        <div class="summary-info">
          <h1 class="title">구입 예상 비용</h1>
        </div>
        <div class="detail-info">
          <div class="info-grid-list line">
            <ul>
              <li>
                <strong class="info-title">결제 수단</strong>
                <div class="info-group">
                  <p>할부 (임직원 무이자 + 표준형)</p>
                </div>
              </li>
              <li>
                <strong class="info-title">월 납입금액</strong>
                <div class="info-group">
                  <ul class="desc-list">
                    <li>
                      <em>A. 표준형</em>
                      <span class="price">월 150,000 원</span>
                      <ul class="desc-sub-list">
                        <li>
                          <em>할부원금</em>
                          <span class="price">1,000,000 원</span>
                        </li>
                        <li>
                          <em>할부기간</em>
                          <span class="last">36 개월</span>
                        </li>
                        <li>
                          <em>금리</em>
                          <span class="last">4.5 %</span>
                        </li>
                      </ul>
                    </li>
                    <li>
                      <em>B. 무이자</em>
                      <span class="price">월 240,000 원</span>
                      <ul class="desc-sub-list">
                        <li>
                          <em>할부원금</em>
                          <span class="price">1,000,000 원</span>
                        </li>
                        <li>
                          <em>할부기간</em>
                          <span class="last">36 개월</span>
                        </li>
                        <li>
                          <em>금리</em>
                          <span class="last">4.5 %</span>
                        </li>
                      </ul>
                    </li>
                  </ul>
                </div>
              </li>
              <li>
                <strong class="info-title">등록비 <span class="sub-text">(별도, 참고용)</span></strong>
                <div class="info-group">
                  <span class="price">85,300 원</span>
                  <ul class="desc-list">
                    <li>
                      <em>취득세</em>
                      <span class="price">0 원</span>
                    </li>
                    <li>
                      <em>공채 <span class="sub-text">(서울/할인 기준)</span></em>
                      <span class="price">0 원</span>
                    </li>
                    <li>
                      <em>종지대 <span class="sub-text">(수입인지)</span></em>
                      <span class="price">0 원</span>
                    </li>
                    <li>
                      <em>차량번호판</em>
                      <span class="price">0 원</span>
                    </li>
                    <li>
                      <em>등록대행 수수료</em>
                      <span class="price">0 원</span>
                    </li>
                  </ul>
                </div>
              </li>
            </ul>
          </div>
        </div>
      </section>
      <!-- 총금액 : 할부 -->
      <div class="purchase-total-price">
        <ul>
          <li class="t-blue">
            총 차량 견적 금액
            <strong class="price">38,000,000</strong> 원
          </li>
          <li>
            출고 전 납입총액
            <strong class="price">38,000,000</strong> 원
            <p class="sub-text">단기의무 보험교 포함</p>
          </li>
          <li>
            월 납입금액
            <strong class="price">340,000</strong> 원
          </li>
        </ul>
      </div>
    </div>
    <div class="banner-wrap">배너영역</div>
    <div class="link-list">
      <ul>
        <li><nuxt-link to="/" target="_blank" title="새창 열기">시승신청</nuxt-link></li>
        <li><nuxt-link to="/" target="_blank" title="새창 열기">카달로그 다운로드</nuxt-link></li>
        <li><nuxt-link to="/" target="_blank" title="새창 열기">중고차 시세 조회</nuxt-link></li>
        <li><nuxt-link to="/" target="_blank" title="새창 열기">자동차 보험료 계산</nuxt-link></li>
        <li><nuxt-link to="/" target="_blank" title="새창 열기">할부 한도 조회</nuxt-link></li>
      </ul>
    </div>
    <notice-info />
  </div>
</template>

<script>
import NoticeInfo from '~/components/page/estimation/NoticeInfo'
export default {
  components: {
    NoticeInfo,
  },
  data() {
    return {
      carImg: {
        src: require('~/assets/images/temp/temp-payment-car-model.png'),
        alt: 'AX 스마트스트림 가솔린 1.1 터보 프리미엄 밀레니얼 A/T',
      },
      priceMin: '18,000,000',
      priceMax: '20,000,000',
      inColor: { txt:'메테오 블루', color:'#023a76' },
      outColor: { txt:'쉬머링 실버', color:'#93989e' },
      optList: [
        { opt: '현대스마트센스' },
        { opt: '펫 패키지Ⅰ(강아지얼굴,소형)-모노민트' },
        { opt: '펫 패키지Ⅲ(소형)-모노옐로우' },
        { opt: '[N퍼포먼스 파츠] 인테리어 패키지' },
      ],
      optionData: [
        { name: '옵션', subOption: [
          { name: '옵션명', price: '100,000'}, { name: '옵션명', price: '100,000'}
        ]},
        { name:'H Genuine Accessorie', subOption: [
          { name: '옵션명', price: '100,000'}, { name: '옵션명', price: '100,000'}, { name: '옵션명', price: '100,000'}
        ]},
        { name: 'N Performance', subOption: [
          { name: '옵션명', price: '100,000'}
        ]},
      ],
      discountData: [
        { discountName: '직원할인', discountPrice: '100,000' },
        { discountName: '기본할인', discountPrice: '100,000' },
        { discountName: '생산월할인', discountPrice: '100,000' },
        { discountName: '특별재고할인', discountPrice: '100,000' },
        { discountName: '전시할인', discountPrice: '100,000' },
        { discountName: '판촉할인', discountPrice: '100,000' },
        { discountName: '조건할인명', discountPrice: '100,000' },
        { discountName: '생산월할인', discountPrice: '100,000' },
        { discountName: '지인추천할인', discountPrice: '100,000' },
        { discountName: '생산월할인', discountPrice: '100,000' },
        { discountName: '특별재고할인', discountPrice: '100,000' },
      ],
    }
  },
}
</script>