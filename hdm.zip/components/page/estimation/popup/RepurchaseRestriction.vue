<template>
  <v-popup
    :visible="visible"
    :width="'550px'"
    :footer="['cancel','confirm']"
    @close="
      $emit('close')
      popVisible = false
    "
  >

    <template slot="header">
      <div class="title">직원할인 재구매 제한 안내</div>
      <p class="header-description"><span>홍길동</span> 님은 최근 2년 내에 직원할인 구매 이력이 있습니다.<br />직원할인을 적용한 견적을 받으시겠습니까?</p>
    </template>
    <template slot="body">
      <div class="body-contents">
        <ul class="info-list">
          <li>
            <span>재구매 가능일</span>
            <em><strong>2022년 02월 28일</strong> (결제일 기준)</em>
          </li>
        </ul>
      </div>
    </template>
  </v-popup>
</template>

<script>
import { VPopup } from '~/components/element'
export default {
  components: {
    VPopup
  },
  props: {
    visible: {
      type: Boolean,
      default: false
    },
  },
}
</script>