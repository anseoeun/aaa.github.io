<template>
  <v-popup
    :visible="visible"
    :width="'776px'"
    :footer="['confirm']"
    @close="
      $emit('close')
      popVisible = false
    "
    @confirm="
      $emit('close')
      popVisible = false
    "
  >

    <template slot="header">
      <div class="title">블루멤버스 포인트 적립 예정 안내</div>
    </template>
    <template slot="body">
      <p class="bullet">블루멤버스 포인트는 현대자동차 구매 고객을 대상으로 가맹점에서 물품 구매 또는 서비스 이용 시 블루멤버스 카드 또는 블루멤버스 제휴 카드를 통해 포인트를 적립하고 사용할 수 있는 서비스입니다.</p>
      <p class="contents-head">현대차종 적립안내</p>
      <ul class="bullet-list">
        <li>대상 : 승용, RV, 소형상용(포터, 스타렉스) 차량을 구매한 개인/법인 회원</li>
        <li>기준 : 차량 구매가 구매 횟수에 따라 점율(0.7% ~ 3%)로 포인트를 적립</li>
      </ul>
      <div class="table-area">
        <table>
          <colgroup>
            <col width="75px" />
            <col width="auto" />
            <col width="75px" />
            <col width="75px" />
            <col width="75px" />
            <col width="75px" />
            <col width="75px" />
            <col width="75px" />
          </colgroup>
          <thead>
            <tr>
              <th scope="col" colspan="2">구분</th>
              <th scope="col" colspan="7">구매횟수별 포인트 지급기준(%)</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <th scope="row" rowspan="4">개인회원</th>
              <th scope="row" rowspan="2">일반회원<br />(개인/개인사업자)</th>
              <td scope="col">첫구매</td>
              <td scope="col">2회차</td>
              <td scope="col">3회차</td>
              <td scope="col">4회차</td>
              <td scope="col">5회차</td>
              <td scope="col">6회차</td>
            </tr>
            <tr>
              <td>0.7</td>
              <td>1.1</td>
              <td>1.5</td>
              <td>2.0</td>
              <td>2.5</td>
              <td>3.0</td>
            </tr>
            <tr>
              <th scope="row">개인택시</th>
              <td colspan="6">신규/재구매 0.7% 동일</td>
            </tr>
            <tr>
              <th scope="row">렌트/리스<br />이용개인</th>
              <td colspan="6">신규/재구매 0.3% 동일</td>
            </tr>
            <tr>
              <th scope="row">법인회원</th>
              <th scope="row">일반 법인<br />렌트/리스사<br />렌트/리스<br />이용개인</th>
              <td colspan="6">신규/재구매 0.3% 동일</td>
            </tr>
          </tbody>
        </table>
        <small>(1포인트 = 1원)</small>
      </div>
    </template>
  </v-popup>
</template>

<script>
import { VPopup } from '~/components/element'
export default {
  components: {
    VPopup
  },
  props: {
    visible: {
      type: Boolean,
      default: false
    },
  },
  updated() {
    if (this.visible) {
      this.setCaption()
    }
  },
}
</script>