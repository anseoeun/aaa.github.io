<template>
  <v-popup
    :visible="visible"
    :width="'1000px'"
    :footer="['confirm']"
    @close="
      $emit('close')
      popVisible = false
    "
    @confirm="
      $emit('close')
      popVisible = false
    "
  >

    <template slot="header">
      <div class="title">면세 안내</div>
    </template>
    <template slot="body">
      <div style="width: 100%; height: 600px; background-color: #f6f3f2;">기획/디자인TBD</div>
    </template>
  </v-popup>
</template>

<script>
import { VPopup } from '~/components/element'
export default {
  components: {
    VPopup
  },
  props: {
    visible: {
      type: Boolean,
      default: false
    },
  },
}
</script>