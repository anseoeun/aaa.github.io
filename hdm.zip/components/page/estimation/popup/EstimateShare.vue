<template>
  <v-popup
    :visible="visible"
    :width="'550px'"
    @close="
      $emit('close')
      popVisible = false
    "
  >

    <template slot="header">
      <div class="title">견적 공유</div>
      <p class="header-description">견적이 URL로 생성되었습니다.<br />아래 URL을 공유하시면 견적을 다시 확인하실 수 있습니다.<br /><span>(30일간 유효)</span></p>
    </template>
    <template slot="body">
      <div class="form-grid">
        <div class="label-input">
          <label class="offscreen">URL 입력폼</label>
          <v-input v-model="urlForm" class="form-group" />
        </div>
      </div>
    </template>
    <template slot="footer">
      <div class="btn-group">
        <v-btn class="btn" b-size="btn-md">URL 복사</v-btn>
        <v-btn class="btn btn-lg" b-size="btn-lg">카카오톡 공유</v-btn>
        <v-btn class="btn btn-lg" b-size="btn-lg">페이스북 공유</v-btn>
      </div>
    </template>
  </v-popup>
</template>

<script>
import { VPopup } from '~/components/element'
export default {
  components: {
    VPopup
  },
  props: {
    visible: {
      type: Boolean,
      default: false
    },
  },
  data() {
    return {
      urlForm: 'https://www.hyundai.com/KSDLFKWEGVL',
    }
  },
  updated() {
    if (this.visible) {
      this.setLabel((idg) => {
      })
    }
  }
}
</script>