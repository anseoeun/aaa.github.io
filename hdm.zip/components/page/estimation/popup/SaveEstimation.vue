<template>
  <v-popup
    :visible="visible"
    :width="'550px'"
    @close="
      $emit('close')
      popVisible = false
    "
  >

    <template slot="header">
      <div class="title">견적 저장 완료</div>
    </template>
    <template slot="body">
      <p class="text-main">
        견적서가 저장되었습니다.<br />
        마이페이지 &gt; 나의 견적내역에서 확인하실 수 있습니다.
      </p>
    </template>
    <template slot="footer">
      <div class="btn-group">
        <v-btn class="btn btn-gray btn-lg" b-size="btn-lg" b-color="btn-gray">나의 견적내역 바로가기</v-btn>
        <v-btn class="btn" b-size="btn-md">홈으로</v-btn>
      </div>
    </template>
  </v-popup>
</template>

<script>
import { VPopup } from '~/components/element'
export default {
  components: {
    VPopup
  },
  props: {
    visible: {
      type: Boolean,
      default: false
    },
  },
}
</script>