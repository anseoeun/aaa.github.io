<template>
  <div class="visual">
    <v-pageheader
      page-title="AX 사전계약"
      page-infotext="사양 선택 시뮬레이션을 통해 차량금액을 확인 후 신청 가능합니다. "
    />
    <div class="btn-box">
      <v-btn type="button" class="btn lg blue r" @click="handleClick">AX 사전계약하기</v-btn>
    </div>
    <div class="visual-car"></div>
  </div>
</template>


<script>
export default {
 methods:{
    handleClick(e) {
      this.$emit('click', false)
    },
 }
}
</script>
