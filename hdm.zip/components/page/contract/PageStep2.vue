<template>
  <div class="page-step">
    <div class="purchase-wrap">
      <div class="purchase-info">
        <section class="contract-description">
          <div class="title">
            <h1>계약 기본정보</h1>
            <p class="sub-title">박창석 님이 이번에 차량을 구매하실 때 받을 수 있는 근속연수 할인율은 26%입니다.</p>
          </div>
          <div class="gauge">
            <div class="gauge-info">
              <p class="txt">근속연수 할인 26%</p>
            </div>
            <div class="gauge-content">
              <v-progress-bar
                type="percent"
                total-width="850"
                current-per="26"
                height="10"
              />
            </div>
          </div>
          <v-checkbox :one-check="true" :checked.sync="checkboxBenefit">이번 계약에서 혜택 받기</v-checkbox>
          <ul class="bullet-list">
            <li>근속연수 할인율은 당월 기준으로 적용된 사항입니다.</li>
            <li>실제 차량 구매 시의 할인 금액은 ‘5단계 차량정보금액’ 에서 확인하실 수 있습니다.</li>
          </ul>
        </section>
        <!-- 명의자 정보 -->
        <section class="information-detail">
          <div class="summary-info">
            <h1 class="title">명의자 정보</h1>
            <v-btn class="btn-detail" type="icon" :icon-class="['icon-open', { active:isActive(1)} ]" @click="setActive(1)"><span class="offscreen">상세보기</span></v-btn>
          </div>
          <div v-if="isActive(1)" class="detail-info">
            <el-form ref="identifyForm" :model="ruleForm" :rules="rules">
              <!-- 명의자 1 -->
              <div class="form-grid-list">
                <ul>
                  <li>
                    <strong class="form-label bold">명의자 1</strong>
                    <div class="form-group ct">
                      <div class="radio">
                        <el-radio v-model="ppri" label="1">주계약자로 설정</el-radio>
                      </div>
                    </div>
                  </li>
                  <li>
                    <strong class="form-label">성명</strong>
                    <div class="form-group ct">김현대</div>
                  </li>
                  <li>
                    <strong class="form-label">주민등록번호</strong>
                    <div v-if="ruleForm.security" class="form-group ct social-number">
                      <p>800218 - 1******</p>
                      <v-btn class="btn-more">본인 확인</v-btn>
                      <div class="el-form-item__error">* 본인확인이 완료되었습니다.</div>
                    </div>
                    <div v-else class="form-group">
                      <el-form-item prop="ruleForm.security2" class="inbl-wrap">
                        <div class="label-input">
                          <label class="offscreen">주민등록 앞자리</label>
                          <v-input v-model="ruleForm.security1" maxlength="6" :disabled="true" />
                        </div>
                        <div class="dash-line"></div>
                        <div class="label-input">
                          <label class="offscreen">주민등록 뒷자리</label>
                          <v-input v-model="ruleForm.security2" type="number" maxlength="7" placeholder="7자리" />
                        </div>
                        <v-btn class="btn-more">본인 확인</v-btn>
                      </el-form-item>
                    </div>
                  </li>
                  <li>
                    <div class="form-label">휴대전화</div>
                    <div class="form-group">
                      <el-form-item prop="phoneNumber" class="inbl-wrap">
                        <div class="label-input">
                          <label class="offscreen">휴대전화</label>
                          <v-input v-model="ruleForm.phoneNumber" type="number" placeholder="-없이 입력하세요." />
                        </div>
                      </el-form-item>
                    </div>
                  </li>
                  <li>
                    <div class="form-label">이메일</div>
                    <div class="form-group">
                      <el-form-item prop="email" class="inbl-wrap">
                        <div class="label-input">
                          <label class="offscreen">이메일 주소</label>
                          <v-input v-model="ruleForm.emailAddress" type="text" placeholder="이메일 주소" />
                        </div>
                        <span class="at">@</span>
                        <div class="label-input">
                          <label class="offscreen">이메일 제공자</label>
                          <v-input
                            v-model="ruleForm.emailProvider"
                            type="text"
                            :disabled="ruleForm.mailSelected == '' ? false : true"
                            :value="ruleForm.mailSelected == '직접입력' ? '' : ruleForm.mailSelected"
                          />
                        </div>
                        <div class="select">
                          <v-select v-model="ruleForm.mailSelected" :data="ruleForm.mailList" placeholder="선택" />
                        </div>
                        </el-form-item>
                    </div>
                  </li>
                  <li>
                    <div class="form-label">주소</div>
                    <div class="form-group">
                      <el-form-item prop="address" class="full">
                        <div class="label-input inbl-wrap">
                          <label class="offscreen">우편번호</label>
                          <v-input v-model="ruleForm.address" type="text" disabled="disabled" />
                          <v-btn class="btn-more">우편번호</v-btn>
                          <v-checkbox :one-check="true" :checked.sync="addrCopyCheck" class="right">주계약자 주소와 동일</v-checkbox>
                        </div>
                        <div class="label-input">
                          <label class="offscreen">기본주소</label>
                          <v-input v-model="ruleForm.address2" type="text" />
                        </div>
                        <div class="label-input">
                          <label class="offscreen">상세주소</label>
                          <v-input v-model="ruleForm.address3" type="text" />
                        </div>
                      </el-form-item>
                      <p class="bullet-star">주민등록 상 주소로 입력해 주세요.<br />(주민등록 상 주소와 상이할 경우 차량 등록이 불가할 수 있습니다.)</p>
                      <p class="bullet-star">면세 적용 시 공동명의자 간 주소가 동일해야 합니다.</p>
                    </div>
                  </li>
                  <li>
                    <div class="form-label">사업자번호</div>
                    <div class="form-group">
                      <div class="label-input inbl-wrap">
                        <label class="offscreen">사업자번호</label>
                        <v-input v-model="ruleForm.companyNumber" type="text" />
                      </div>
                    </div>
                  </li>
                  <li>
                    <div class="form-label">상호명</div>
                    <div class="form-group">
                      <div class="label-input inbl-wrap">
                        <label class="offscreen">상호명</label>
                        <v-input v-model="ruleForm.companyName" type="text" />
                      </div>
                    </div>
                  </li>
                  <li>
                    <div class="form-label">업태</div>
                    <div class="form-group">
                      <div class="label-input inbl-wrap">
                        <label class="offscreen">업태</label>
                        <v-input v-model="ruleForm.business" type="text" />
                      </div>
                    </div>
                  </li>
                  <li>
                    <div class="form-label">종목</div>
                    <div class="form-group">
                      <div class="label-input inbl-wrap">
                        <label class="offscreen">종목</label>
                        <v-input v-model="ruleForm.event" type="text" />
                      </div>
                    </div>
                  </li>
                </ul>
              </div>
              <!-- 명의자 2 -->
              <div class="form-grid-list">
                <v-btn class="btn-delete" type="icon" icon-class="icon-delete"><span class="offscreen">삭제</span></v-btn>
                <ul>
                  <li>
                    <strong class="form-label bold">명의자 2</strong>
                    <div class="form-group ct">
                      <div class="radio">
                        <el-radio v-model="ppri" label="2">주계약자로 설정</el-radio>
                      </div>
                    </div>
                  </li>
                  <li>
                    <strong class="form-label">성명</strong>
                    <div class="form-group ct">김현대</div>
                  </li>
                  <li>
                    <strong class="form-label">주민등록번호</strong>
                    <div v-if="ruleForm.security" class="form-group ct social-number">
                      <p>800218 - 1******</p>
                      <v-btn class="btn-more">본인 확인</v-btn>
                      <div class="el-form-item__error">* 본인확인이 완료되었습니다.</div>
                    </div>
                    <div v-else class="form-group">
                      <el-form-item prop="ruleForm.security2" class="inbl-wrap">
                        <div class="label-input">
                          <label class="offscreen">주민등록 앞자리</label>
                          <v-input v-model="ruleForm.security1" maxlength="6" :disabled="true" />
                        </div>
                        <div class="dash-line"></div>
                        <div class="label-input">
                          <label class="offscreen">주민등록 뒷자리</label>
                          <v-input v-model="ruleForm.security2" type="number" maxlength="7" placeholder="7자리" />
                        </div>
                        <v-btn class="btn-more">본인 확인</v-btn>
                      </el-form-item>
                    </div>
                  </li>
                  <li>
                    <div class="form-label">휴대전화</div>
                    <div class="form-group">
                      <el-form-item prop="phoneNumber" class="inbl-wrap">
                        <div class="label-input">
                          <label class="offscreen">휴대전화</label>
                          <v-input v-model="ruleForm.phoneNumber" type="number" placeholder="-없이 입력하세요." />
                        </div>
                      </el-form-item>
                    </div>
                  </li>
                  <li>
                    <div class="form-label">이메일</div>
                    <div class="form-group">
                      <el-form-item prop="email" class="inbl-wrap">
                        <div class="label-input">
                          <label class="offscreen">이메일 주소</label>
                          <v-input v-model="ruleForm.emailAddress" type="text" placeholder="이메일 주소" />
                        </div>
                        <span class="at">@</span>
                        <div class="label-input">
                          <label class="offscreen">이메일 제공자</label>
                          <v-input
                            v-model="ruleForm.emailProvider"
                            type="text"
                            :disabled="ruleForm.mailSelected == '' ? false : true"
                            :value="ruleForm.mailSelected == '직접입력' ? '' : ruleForm.mailSelected"
                          />
                        </div>
                        <div class="select">
                          <v-select v-model="ruleForm.mailSelected" :data="ruleForm.mailList" placeholder="선택" />
                        </div>
                        </el-form-item>
                    </div>
                  </li>
                  <li>
                    <div class="form-label">주소</div>
                    <div class="form-group">
                      <el-form-item prop="address" class="full">
                        <div class="label-input inbl-wrap">
                          <label class="offscreen">우편번호</label>
                          <v-input v-model="ruleForm.address" type="text" disabled="disabled" />
                          <v-btn class="btn-more">우편번호</v-btn>
                          <v-checkbox :one-check="true" :checked.sync="addrCopyCheck" class="right">주계약자 주소와 동일</v-checkbox>
                        </div>
                        <div class="label-input">
                          <label class="offscreen">기본주소</label>
                          <v-input v-model="ruleForm.address2" type="text" />
                        </div>
                        <div class="label-input">
                          <label class="offscreen">상세주소</label>
                          <v-input v-model="ruleForm.address3" type="text" />
                        </div>
                      </el-form-item>
                      <p class="bullet-star">주민등록 상 주소로 입력해 주세요.<br />(주민등록 상 주소와 상이할 경우 차량 등록이 불가할 수 있습니다.)</p>
                      <p class="bullet-star">면세 적용 시 공동명의자 간 주소가 동일해야 합니다.</p>
                    </div>
                  </li>
                  <li>
                    <div class="form-label">사업자번호</div>
                    <div class="form-group">
                      <div class="label-input inbl-wrap">
                        <label class="offscreen">사업자번호</label>
                        <v-input v-model="ruleForm.companyNumber" type="text" />
                      </div>
                    </div>
                  </li>
                  <li>
                    <div class="form-label">상호명</div>
                    <div class="form-group">
                      <div class="label-input inbl-wrap">
                        <label class="offscreen">상호명</label>
                        <v-input v-model="ruleForm.companyName" type="text" />
                      </div>
                    </div>
                  </li>
                  <li>
                    <div class="form-label">업태</div>
                    <div class="form-group">
                      <div class="label-input inbl-wrap">
                        <label class="offscreen">업태</label>
                        <v-input v-model="ruleForm.business" type="text" />
                      </div>
                    </div>
                  </li>
                  <li>
                    <div class="form-label">종목</div>
                    <div class="form-group">
                      <div class="label-input inbl-wrap">
                        <label class="offscreen">종목</label>
                        <v-input v-model="ruleForm.event" type="text" />
                      </div>
                    </div>
                  </li>
                </ul>
              </div>
            </el-form>
            <div class="btn-wrap">
              <v-btn class="btn md white r">명의자 추가</v-btn>
            </div>
            <div class="agree-check">
              <v-checkbox v-model="choiceYn" :data="choiceYnData" />
            </div>
          </div>
        </section>
        <!-- 면세여부 -->
        <section class="information-detail">
          <div class="summary-info">
            <div class="title">
              <h1>면세여부</h1>
              <!-- <v-btn class="btn-info" type="icon" icon-class="icon-info" @click="$emit('popSaveAutoGuide')"><span class="offscreen">안내팝업보기</span></v-btn> -->
              <v-btn class="btn-info" type="icon" icon-class="icon-info"><span class="offscreen">안내팝업보기</span></v-btn>
            </div>
            <v-btn class="btn-detail" type="icon" :icon-class="['icon-open', { active:isActive(2)} ]" @click="setActive(2)"><span class="offscreen">상세보기</span></v-btn>
          </div>
          <div v-if="isActive(2)" class="detail-info">
            <el-form ref="taxExemptOption" :model="taxExemptOption" :rules="rules" label-position="top">
              <div class="form-grid-list">
                <ul>
                  <li>
                    <div class="form-label">
                      <v-checkbox :one-check="true" :checked.sync="taxExemptOption.applied">면세 대상 선택</v-checkbox>
                    </div>
                    <div class="form-group ct">
                      <ul class="desc-list">
                        <li>주계약자 : 김현대</li>
                        <li>
                          <el-form-item prop="selectedType">
                            <v-select
                              v-model="taxExemptOption.selectedType"
                              :data="taxExemptOption.resHandicapList"
                              class="lg"
                            />
                          </el-form-item>
                        </li>
                        <li><p class="bullet-star">대상자는 면세 적용되며, 추후 증빙서류 안내 및 인증절차가 있습니다.</p></li>
                      </ul>
                    </div>
                  </li>
                </ul>
              </div>
            </el-form>
          </div>
        </section>
        <!-- 보증제도 -->
        <section class="information-detail">
          <div class="summary-info">
            <h1 class="title">보증제도</h1>
            <v-btn class="btn-detail" type="icon" :icon-class="['icon-open', { active:isActive(3)} ]" @click="setActive(3)"><span class="offscreen">상세보기</span></v-btn>
          </div>
          <div v-if="isActive(3)" class="detail-info">
            <el-form ref="form" :model="form" :rules="rules">
              <div class="form-grid-list">
                <ul>
                  <li>
                    <strong class="form-label">보증제도</strong>
                    <div class="form-group">
                      <el-form-item prop="guaranteeSel">
                        <v-select
                          v-model="form.guaranteeSel"
                          :data="form.commonCodes"
                          class="lg"
                        />
                      </el-form-item>
                    </div>
                  </li>
                </ul>
              </div>
            </el-form>
          </div>
        </section>
        <!-- 카마스터 -->
        <section class="information-detail">
          <div class="summary-info">
            <h1 class="title">카마스터</h1>
            <v-btn class="btn-detail" type="icon" :icon-class="['icon-open', { active:isActive(4)} ]" @click="setActive(4)"><span class="offscreen">상세보기</span></v-btn>
          </div>
          <div v-if="isActive(4)" class="detail-info car-master">
            <div class="master-recommend">
              <!-- 선택전 -->
              <p v-if="carMaster.carMasterRecommend" class="text">카마스터를 추천해주세요</p>
              <!-- 선택후 -->
              <div v-else class="recommend-box">
                <strong>카마스터</strong>
                <div>김현대 (010-1234-5678)</div>
              </div>
            </div>
            <div class="master-search">
              <el-radio v-model="carMaster.carMasterSearch" label="1">이름으로 찾기</el-radio>
              <el-radio v-model="carMaster.carMasterSearch" label="2">지점/대리점으로 찾기</el-radio>
              <div class="master-input">
                <div v-if="carMaster.carMasterSearch === '1'" class="label-input inbl-wrap">
                  <label class="offscreen">이름으로 찾기</label>
                  <v-input v-model="carMaster.carMasterName" placeholder="이름을 입력해주세요." />
                  <v-btn class="btn-more">검색</v-btn>
                </div>
                <div v-if="carMaster.carMasterSearch === '2'" class="label-input inbl-wrap">
                  <label class="offscreen">지점/대리점으로 찾기</label>
                  <v-input v-model="carMaster.carMasterAgent" placeholder="지점 또는 대리점명을 입력해 주세요." />
                  <v-btn class="btn-more">검색</v-btn>
                </div>
              </div>
              <div class="master-filter">
                <v-radio v-model="carMasterCheck" :custom-label="true" :data="carMasterSearchList">
                  <template slot-scope="props">{{ props.item.label }} ({{ props.item.count }})</template>
                </v-radio>
              </div>
            </div>
            <div class="location-map">
              <!-- 첫진입 -->
              <p v-if="carMaster.mapRecommend === '1'" class="text">카마스터를 추천해주세요.</p>
              <!-- 검색결과 있을 경우 -->
              <div v-else-if="carMaster.mapRecommend === '2'" class="map-view">
                <div style="background:#f9f9f9" class="map-area">
                  지도영역
                </div>
                <div class="master-list">
                  <ul v-if="carMasterList.length > 0">
                    <li v-for="(master, index) in carMasterList" :key="index">
                      <div class="master-img">
                        <v-img :src="master.photo.src" :alt="master.photo.alt"></v-img>
                      </div>
                      <div class="master-info">
                        <strong class="name">{{ master.master }}</strong>
                        <span>{{ master.place }}</span>
                        <p>{{ master.email }}</p>
                        <p>{{ master.phone }}</p>
                      </div>
                      <v-btn class="btn-more">선택</v-btn>
                    </li>
                  </ul>
                </div>

              </div>
              <!-- 검색결과 없을 경우 -->
              <p v-else-if="carMaster.mapRecommend === '3'" class="no-result">검색결과가 없습니다.</p>
            </div>
          </div>
        </section>
      </div>
      <contract-tool />
    </div>
    <div class="btn-wrap">
      <v-btn class="btn lg gray r">이전</v-btn>
      <v-btn class="btn lg blue r">다음</v-btn>
    </div>
  </div>
</template>

<script>
import VProgressBar from '~/components/element/VProgressBar'
import contractTool from '~/components/page/contract/contractTool'
export default {
  components: {
    VProgressBar,
    contractTool,
  },
  data() {
    return {
      isOptionsShow: false,
      checkboxBenefit: false,
      ppri: '1',
      ruleForm: {
        security: true,
        security1: '',
        security2: '',
        phoneNumber: '',
        emailAddress: '',
        emailProvider: '',
        mailSelected: '',
        mailList: [
          {
            label: '직접 입력',
            value: ''
          },
          {
            label: 'gmail.com',
            value: 'gmail.com'
          },
          {
            label: 'naver.com',
            value: 'naver.com'
          },
          {
            label: 'daum.net',
            value: 'daum.net'
          }
        ],
        address: '',
        address2: '',
        address3: '',
        companyNumber: '',
        companyName: '',
        business: '',
        event: '',
      },
      addrCopyCheck: false,
      choiceYn: '',
      choiceYnData: [
        { value: 'check1', label: '본인은 귀사가 상기 목적으로 본인의 개인정보를 수집·이용하는 것에 동의합니다.' },
        { value: 'check2', label: '본인은 귀사가 상기 목적으로 상기 보유·이용 기간 동안 본인의 고유식별정보(주민등록번호, 운전면허번호, 여권번호, 외국인등록번호)를 수집·이용하는 것에 동의합니다.' },
      ],
      taxExemptOption: {
        applied : false,
        selectedType: '',
        resHandicapList: [
          {
            value: '',
            label: '장애 등급 및 관련 내용 선택'
          },
          {
            value: 'Option1',
            label: 'hadicap1'
          },
          {
            value: 'Option2',
            label: 'hadicap2'
          },
          {
            value: 'Option3',
            label: 'hadicap3'
          }
        ],
      },
      form: {
        guaranteeSel: '',
        commonCodes: [
          {
            value: '',
            label: '보증제도 선택'
          },
          {
            label: '기본형 (3년/6만㎞)',
            value: '1'
          },
          {
            label: '마일리지형 (2년/8만㎞)',
            value: '2'
          },
          {
            label: '기간연장형 (4년/4만㎞)',
            value: '3'
          },
        ],
      },
      carMaster: {
        carMasterRecommend: false,
        carMasterSearch: '1',
        carMasterName: '',
        carMasterrAgent: '',
        mapRecommend: '2',
      },
      carMasterCheck: '',
      carMasterSearchList: [
        { value: 'check1', label: '전체', count:'3' },
        { value: 'check2', label: '지점', count:'1' },
        { value: 'check3', label: '대리점', count:'1' },
      ],
      carMasterList: [
        {
          photo: {
            src: require('~/assets/images/temp/temp-car-master-img.jpg'),
            alt: '김현대',
          },
          master: '김현대',
          place: '서초지점',
          email: 'hyundai.kim@hyundai.com',
          phone: '010-1234-5678'
        },
        {
          photo: {
            src: require('~/assets/images/temp/temp-car-master-img.jpg'),
            alt: '김현대',
          },
          master: '김현대',
          place: '동대문역대리점',
          email: 'hyundai.kim@hyundai.com',
          phone: '010-1234-5678'
        },
        {
          photo: {
            src: require('~/assets/images/temp/temp-car-master-img.jpg'),
            alt: '김현대',
          },
          master: '김현대',
          place: '서초지점',
          email: 'hyundai.kim@hyundai.com',
          phone: '010-1234-5678'
        },
        {
          photo: {
            src: require('~/assets/images/temp/temp-car-master-img.jpg'),
            alt: '김현대',
          },
          master: '김현대',
          place: '동대문역대리점',
          email: 'hyundai.kim@hyundai.com',
          phone: '010-1234-5678'
        },
        {
          photo: {
            src: require('~/assets/images/temp/temp-car-master-img.jpg'),
            alt: '김현대',
          },
          master: '김현대',
          place: '동대문역대리점',
          email: 'hyundai.kim@hyundai.com',
          phone: '010-1234-5678'
        },
      ],
    }
  },
  computed: {
    rules() {
      return {
        security2: [
          {
            required: true,
            message: '* 주민등록번호를 입력해 주세요',
            trigger: 'blur',
          },
        ],
        phoneNumber: [
          {
            required: true,
            message: '* 휴대전화를 입력해 주세요',
            trigger: 'blur',
          },
        ],
        email: [
          {
            required: true,
            message: '* 이메일을 입력해 주세요.',
            trigger: 'blur',
          },
        ],
        address: [
          {
            required: true,
            message: '* 주소를 입력해 주세요.',
            trigger: 'blur',
          }
        ],
        selectedType: [
          {
            required: true,
            message: '* 장애등급을 선택해 주세요.',
            trigger: 'change'
          }
        ],
      }
    },
  },
  mounted() {
    console.log(this.type)
    this.setLabel((idg) => {
      // console.dir(idg) // 자동 생성된 ID 배열
    })
  },
  methods: {
    setActive(index){
      if(this.isOptionsShow == index){
        this.isOptionsShow = 0
      }else{
        this.isOptionsShow = index
      }
    },
    isActive(index){
      return this.isOptionsShow == index
    }
  }
}
</script>
