<template>
  <div class="gauge">
    <div class="gauge-info">
      <p class="txt">계약금 결제 및 전자서명 완료 기한</p>
      <div class="date">{{ endDate }} 까지</div>
    </div>
    <div class="gauge-content">
      <v-progress-bar
        total-width="400"
        current-width="100"
        height="10"
        start-time="20210203163000"
        end-time="20210215183000"
        @remainTime="remain"
      />

      <span class="gauge-time">{{ remainDate }} 남았음</span>
    </div>
  </div>
</template>
<script>
// import moment from 'moment'
import VProgressBar from '~/components/element/VProgressBar'
export default {
  components: {
    VProgressBar
  },
  props: {
    type: {
      type: String,
      default: ''
    },
    scrollTop: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      isPopover: false,
      endDate: '',
      remainDate: '',
      popoverCnt: ''
    }
  },
  methods: {
    remain(value) {
      this.endDate = value.end
      this.remainDate = value.remain
      const time = value.time
      const cntArr = ['작성해주세요!', '서둘러주세요!', '제출해주세요!']

      if (time === 120 || time === 60 || time === 30) {
        this.isPopover = true
        if (time === 120) this.popoverCnt = cntArr[0]
        if (time === 60) this.popoverCnt = cntArr[1]
        if (time === 30) this.popoverCnt = cntArr[2]
      } else {
        this.isPopover = false
      }
    }
  }
}
</script>
