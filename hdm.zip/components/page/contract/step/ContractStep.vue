<template>
  <div>
    <ol class="contract-step">
      <li :class="{ active: index === '1' }">
        <i class="icon-contract-step-1"></i>
        <div class="txt">개인정보 수집 · 이용,<br />제공 동의</div>
      </li>
      <li :class="{ active: index === '2' }">
        <i class="icon-contract-step-2"></i>
        <div class="txt">계약기본정보</div>
      </li>
      <li :class="{ active: index === '3' }">
        <i class="icon-contract-step-3"></i>
        <div class="txt">서비스 가입 · 신청<br />및 동의</div>
      </li>
      <li :class="{ active: index === '4' }">
        <i class="icon-contract-step-4"></i>
        <div class="txt">계약금 결제</div>
      </li>
      <li :class="{ active: index === '5' }">
        <i class="icon-contract-step-5"></i>
        <div class="txt">차량금액정보</div>
      </li>
      <li :class="{ active: index === '5' }">
        <i class="icon-contract-step-5"></i>
        <div class="txt">전자서명 및<br />계약 완료</div>
      </li>
    </ol>
  </div>
</template>
<script>
export default {
  props: {
    index: {
      type: String,
      default: ''
    }
  },
  data() {
    return {}
  }
}
</script>
