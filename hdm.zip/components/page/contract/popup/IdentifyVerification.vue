<template>
  <v-popup
    :visible="visible"
    :width="'550px'"
    @close="
      $emit('close')
      popVisible = false
    "
  >
    <template slot="header">
      <div class="title">본인 확인</div>
      <p class="header-description">아래 인증 수단 중 하나를 선택하고, 본인확인 절차를 인증해 주세요.</p>
    </template>
    <template slot="body">
    </template>
    <template slot="footer">
      <v-btn class="btn" b-size="btn-md">본인확인</v-btn>
    </template>
  </v-popup>
</template>

<script>
import { VPopup } from '~/components/element'
export default {
  components: {
    VPopup
  },
  props: {
    visible: {
      type: Boolean,
      default: false
    }
  },
}
</script>