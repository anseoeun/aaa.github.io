<template>
  <v-popup
    :visible="visible"
    :footer="['confirm']"
    :width="'550px'"
    @close="
      $emit('close')
      popVisible = false
    "
    @confirm="
      $emit('close')
      popVisible = false
    "
  >
    <template slot="header">
      <div class="title">판매조건 변경 안내</div>
      <p class="header-description">
        판매조건 변경으로 인하여 변동된 할인금액 및 상품이 있습니다.<br />계약 진행하기 전에 변경된 조건을 확인해 주세요.
      </p>
    </template>
    <template slot="body">
      <div class="body-contents">
        <p class="contents-head">변경 사항</p>
        <ul class="plan-info">
          <li>
            <p class="title">특별조건할인명1</p>
            <p class="description t-brown">혜택 종료</p>
          </li>
          <li>
            <p class="title">특별조건할인명2</p>
            <p class="description t-brown">혜택 종료</p>
          </li>
          <li>
            <p class="title">금리할인상품명</p>
            <p class="description t-blue">금액 변동</p>
          </li>
          <li>
            <p class="title">쿠폰명</p>
            <p class="description t-brown">기간 만료</p>
          </li>
        </ul>
      </div>
    </template>
  </v-popup>
</template>

<script>
import { VPopup } from '~/components/element'
export default {
  components: {
    VPopup
  },
  props: {
    visible: {
      type: Boolean,
      default: false
    }
  },
}
</script>