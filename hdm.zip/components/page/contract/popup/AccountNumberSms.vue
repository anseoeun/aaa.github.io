<template>
  <v-popup
    :visible="visible"
    :width="'550px'"
    @close="
      $emit('close')
      popVisible = false
    "
  >
    <template slot="header">
      <div class="title">입금계좌번호 SMS 전송</div>
    </template>
    <template slot="body">
      <el-form ref="form" :model="phoneForm" :rules="rules">
        <el-form-item prop="phoneNumber">
          <div class="form-grid button">
            <div class="label-input">
              <label class="offscreen">휴대전화번호 입력폼</label>
              <v-input v-model="phoneForm.phoneNumber" type="number" class="form-group" />
              <v-btn class="btn btn md white r">SMS 전송</v-btn>
            </div>
          </div>
        </el-form-item>
      </el-form>
    </template>
  </v-popup>
</template>

<script>
import { VBtn, VInput, VPopup } from '~/components/element'
export default {
  components: {
    VPopup,
    VBtn,
    VInput
  },
  props: {
    visible: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      phoneForm: {
        phoneNumber: '01051518787',
      }
    }
  },
  computed: {
    rules() {
      return {
        phoneNumber: [
          {
            required: true,
            message: '* 휴대전화를 입력해 주세요',
            trigger: 'blur',
          },
        ],
      }
    },
  },
}
</script>