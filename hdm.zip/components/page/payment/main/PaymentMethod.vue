<template>
  <section class="information-detail">
    <!-- 결제, 다시결제 -->
    <div v-if="type != 'addition'" class="summary-info">
      <h1 class="title">결제방법</h1>
      <div class="total-price">
        결제 예정 금액 <span class="price">20,711,832</span> 원
      </div>
      <v-btn class="btn-detail" type="icon" :icon-class="['icon-open', { active: isOptionsShow} ]" @click="isOptionsShow = !isOptionsShow"><span class="offscreen">상세보기</span></v-btn>
    </div>
    <!-- 추가결제 -->
    <div v-else class="summary-info">
      <h1 class="title">추가 결제</h1>
      <div class="total-price">
        추가 결제 금액 <span class="price">200,000</span> 원
      </div>
      <p class="bullet-star">추가 결제 사유 : 포인트 사용승인 거절</p>
    </div>
    <div v-show="isOptionsShow" class="detail-info" :class="{ active: isOptionsShow }">
      <el-form ref="form" :rules="rules">
        <v-tab class="tab-default payment-method" :data="tabList" :contents="true">
          <template slot="contents">
            <!-- 탭 : 신용카드 -->
            <div data-id="tab1">
              <div class="public-card bluemembers">
                <strong class="title">Hyundai BLUEmembers Platinum Plus카드</strong>
                <p>쓸 때마다 M포인트 적립<br />M포인트 적립금액의 30% 블루멤버스포인트 추가 적립</p>
                <v-btn class="btn-more" type="link">신청하기</v-btn>
              </div>
              <!-- 신용카드 1 -->
              <section class="payment-wrap">
                <h1>신용카드</h1>
                <v-btn class="btn-delete" type="icon" icon-class="icon-delete"><span class="offscreen">삭제</span></v-btn>
                <div class="form-grid-list">
                  <ul>
                    <li>
                      <strong class="form-label bold">결제예정금액</strong>
                      <div class="form-group inbl-wrap">
                        <p v-if="creditPrice" class="total-price ct">20,711,832 원</p>
                        <div v-else class="label-input">
                          <label class="offscreen">결제예정금액 입력</label>
                          <v-input v-model="creditPaymentPrice" type="text" />
                        </div>
                        <v-radio v-model="creditRadio" :data="creditRadioData" />
                      </div>
                    </li>
                    <li>
                      <div class="form-label full">
                        <strong class="bold">카드정보</strong>
                        <v-btn class="btn-more" type="nlink" to="/">신용카드 한드 일시상향 안내</v-btn>
                      </div>
                      <div class="form-group full">
                        <ul class="desc-list">
                          <li>
                            <em>소유주</em>
                            <v-select v-model="creditOwn" :data="creditOwnData" />
                          </li>
                          <li>
                            <em>카드번호<span class="card-company">현대카드</span></em>
                            <div class="inbl-wrap card-number">
                              <el-form-item prop="cardNumber">
                                <div class="label-input">
                                  <label class="offscreen">첫번째 카드번호</label>
                                  <v-input v-model="cardNumber[0]" type="number" maxlength="4" />
                                </div>
                                <div class="label-input">
                                  <label class="offscreen">두 번째 카드번호</label>
                                  <v-input v-model="cardNumber[1]" type="number" maxlength="4" />
                                </div>
                                <div class="label-input">
                                  <label class="offscreen">세번째 카드번호</label>
                                  <v-input v-model="cardNumber[2]" type="number" maxlength="4" />
                                </div>
                                <div class="label-input">
                                  <label class="offscreen">네번째 카드번호</label>
                                  <v-input v-model="cardNumber[3]" type="number" maxlength="4" />
                                </div>
                                <span class="result">
                                  <i class="icon-check"></i>
                                  <i class="icon-x"></i>
                                </span>
                              </el-form-item>
                            </div>
                          </li>
                          <li>
                            <em>카드유효기간</em>
                            <div class="form-group">
                              <el-form-item prop="datelimit" class="inbl-wrap card-limit">
                                <div class="label-input">
                                  <label class="offscreen">년도 유효기간</label>
                                  <v-input v-model="datelimit[1]" type="number" maxlength="2" placeholder="MM" />
                                </div>
                                <div class="label-input">
                                  <label class="offscreen">월 유효기간</label>
                                  <v-input v-model="datelimit[2]" type="number" maxlength="2" placeholder="YY" />
                                </div>
                                <span class="result">
                                  <i class="icon-check"></i>
                                  <i class="icon-x"></i>
                                </span>
                              </el-form-item>
                            </div>
                          </li>
                          <li>
                            <em>할부기간</em>
                            <div class="form-group">
                              <v-select v-model="creditSelect" :data="creditSelectData" />
                              <v-popover trigger="hover" placement="bottom-start">
                                <p>할부 가능여부 및 이율은 각 신용카드사 정책 및 카드종류에 따라 다를 수 있으므로 사전에 해당 카드사에 확인하고 선택하시기 바랍니다.</p>
                                <v-btn slot="reference"><i class="icon-help"></i></v-btn>
                              </v-popover>
                            </div>
                          </li>
                          <li class="my-hyundaicard">
                            <v-btn class="btn-more" type="link" to="/" target="_blank" title="새창 열기">나의 현대카드 혜택 알아보기</v-btn>
                          </li>
                        </ul>
                      </div>
                    </li>
                    <li>
                      <strong class="form-label bold">제휴혜택</strong>
                      <div class="form-group full">
                        <ul class="desc-list">
                          <li>
                            <em>혜택 선택</em>
                            <v-radio v-model="costRadio" :data="costRadioList" />
                          </li>
                        </ul>
                      </div>
                    </li>
                    <li>
                      <strong class="form-label bold">M포인트</strong>
                      <div class="form-group full">
                        <ul class="desc-list mpoint">
                          <li>
                            <em>포인트 금액</em>
                            <div class="inbl-wrap">
                              <div class="label-input">
                                <label class="offscreen">포인트 금액</label>
                                <v-input v-model="mPoint" type="text" />
                              </div>
                              <v-checkbox :one-check="true" :checked.sync="pointCheck">전액 사용</v-checkbox>
                            </div>
                            <v-btn class="btn-more">사용하기</v-btn>
                            <div class="point-info">사용 가능 <strong>000,000</strong>P / <span>보유 <strong>000,000</strong>P</span></div>
                          </li>
                        </ul>
                      </div>
                    </li>
                    <li>
                      <div class="form-label full">
                        <strong class="bold">혜택신청</strong>
                        <v-btn class="btn-more">혜택 신청하기</v-btn>
                      </div>
                      <div class="form-group full">
                        <ul class="desc-list">
                          <li><v-checkbox :one-check="true" :checked.sync="requestCheck">카드 한도 상향 신청</v-checkbox></li>
                          <li class="save-auto">
                            <v-checkbox :one-check="true" :checked.sync="saveCheck">세이브-오토 30만</v-checkbox>
                            <v-btn class="btn-info" type="icon" icon-class="icon-info" @click="$emit('popSaveAutoGuide')"><span class="offscreen">안내팝업보기</span></v-btn>
                            <v-select v-model="saveSelect" :data="saveSelectData" disabled />
                          </li>
                        </ul>
                      </div>
                    </li>
                  </ul>
                </div>
              </section>
              <!-- // 신용카드 1 -->

              <!-- 신용카드 2 위치 -->
              <!-- // 신용카드 2 위치 -->

              <div class="btn-wrap">
                <v-btn class="btn md white r">신용카드 추가</v-btn>
              </div>
              <div v-if="type === 'payment'" class="info-list">
                <p class="bullet-star">아래 사항을 반드시 확인해 주세요.</p>
                <v-checkbox v-model="creditCheck" :data="creditCheckData" />
              </div>
            </div>
            <!-- 탭 : 무통장입금 -->
            <div data-id="tab2">
              <div class="public-card bluemembers">
                <strong class="title">Hyundai BLUEmembers Platinum Plus카드</strong>
                <p>쓸 때마다 M포인트 적립<br />M포인트 적립금액의 30% 블루멤버스포인트 추가 적립</p>
                <v-btn class="btn-more" type="link">신청하기</v-btn>
              </div>
              <section class="payment-wrap">
                <h1>무통장 입금</h1>
                <div class="form-grid-list">
                  <ul>
                    <li>
                      <strong class="form-label bold">결제예정금액</strong>
                      <p class="form-group ct">20,711,832 원</p>
                    </li>
                    <li>
                      <strong class="form-label bold">입금정보</strong>
                      <div class="form-group full">
                        <ul class="desc-list">
                          <li>
                            <em>입금자</em>
                            <v-select v-model="deposit" :data="depositData" />
                          </li>
                          <li>
                            <em>입금은행</em>
                            <v-select v-model="depositBank" :data="depositBankData" placeholder="은행선택" />
                            <p class="form-text ct">예금주 : 홍길동_현대차(900252282011)</p>
                          </li>
                        </ul>
                      </div>
                    </li>
                  </ul>
                </div>
              </section>
              <div v-if="type === 'payment'" class="info-list">
                <p class="bullet-star">아래 사항을 반드시 확인해 주세요.</p>
                <v-checkbox v-model="depositCheck" :data="depositCheckData" />
              </div>
            </div>

            <!-- 탭 : 무통장입금 + 신용카드 -->
            <div data-id="tab3">
              <div class="public-card bluemembers">
                <strong class="title">Hyundai BLUEmembers Platinum Plus카드</strong>
                <p>쓸 때마다 M포인트 적립<br />M포인트 적립금액의 30% 블루멤버스포인트 추가 적립</p>
                <v-btn class="btn-more" type="link">신청하기</v-btn>
              </div>
              <!-- 무통장입금 -->
              <section class="payment-wrap">
                <h1>무통장 입금</h1>
                <div class="form-grid-list">
                  <ul>
                    <li>
                      <strong class="form-label bold">결제예정금액</strong>
                      <div class="form-group inbl-wrap">
                        <p v-if="bankPrice" class="total-price ct">20,711,832 원</p>
                        <div v-else class="label-input">
                          <label class="offscreen">결제예정금액 입력</label>
                          <v-input v-model="bankPaymentPrice" type="text" />
                        </div>
                        <div class="radio"><el-radio v-model="creditDepositRadio" label="1">단기의무보험 포함</el-radio></div>
                      </div>
                    </li>
                    <li>
                      <strong class="form-label bold">입금정보</strong>
                      <div class="form-group full">
                        <ul class="desc-list">
                          <li>
                            <em>입금자</em>
                            <v-select v-model="deposit" :data="depositData" />
                          </li>
                          <li>
                            <em>입금은행</em>
                            <v-select v-model="depositBank" :data="depositBankData" placeholder="은행선택" />
                            <p class="form-text ct">예금주 : 홍길동_현대차(900252282011)</p>
                          </li>
                        </ul>
                      </div>
                    </li>
                  </ul>
                </div>
              </section>
              <!-- 신용카드 1 -->
              <section class="payment-wrap">
                <h1>신용카드</h1>
                <v-btn class="btn-delete" type="icon" icon-class="icon-delete"><span class="offscreen">삭제</span></v-btn>
                <div class="form-grid-list">
                  <ul>
                    <li>
                      <strong class="form-label bold">결제예정금액</strong>
                      <div class="form-group inbl-wrap">
                        <p v-if="creditPrice" class="total-price ct">20,711,832 원</p>
                        <div v-else class="label-input">
                          <label class="offscreen">결제예정금액 입력</label>
                          <v-input v-model="creditPaymentPrice" type="text" />
                        </div>
                        <div class="radio"><el-radio v-model="creditDepositRadio" label="2">단기의무보험 포함</el-radio></div>
                      </div>
                    </li>
                    <li>
                      <div class="form-label full">
                        <strong class="bold">카드정보</strong>
                        <v-btn class="btn-more" type="nlink" to="/">신용카드 한드 일시상향 안내</v-btn>
                      </div>
                      <div class="form-group full">
                        <ul class="desc-list">
                          <li>
                            <em>소유주</em>
                            <v-select v-model="creditOwn" :data="creditOwnData" />
                          </li>
                          <li>
                            <em>카드번호<span class="card-company">현대카드</span></em>
                            <div class="inbl-wrap card-number">
                              <el-form-item prop="cardNumber">
                                <div class="label-input">
                                  <label class="offscreen">첫번째 카드번호</label>
                                  <v-input v-model="cardNumber[0]" type="number" maxlength="4" />
                                </div>
                                <div class="label-input">
                                  <label class="offscreen">두 번째 카드번호</label>
                                  <v-input v-model="cardNumber[1]" type="number" maxlength="4" />
                                </div>
                                <div class="label-input">
                                  <label class="offscreen">세번째 카드번호</label>
                                  <v-input v-model="cardNumber[2]" type="number" maxlength="4" />
                                </div>
                                <div class="label-input">
                                  <label class="offscreen">네번째 카드번호</label>
                                  <v-input v-model="cardNumber[3]" type="number" maxlength="4" />
                                </div>
                                <span class="result">
                                  <i class="icon-check"></i>
                                  <i class="icon-x"></i>
                                </span>
                              </el-form-item>
                            </div>
                          </li>
                          <li>
                            <em>카드유효기간</em>
                            <div class="form-group">
                              <el-form-item prop="datelimit" class="inbl-wrap card-limit">
                                <div class="label-input">
                                  <label class="offscreen">년도 유효기간</label>
                                  <v-input v-model="datelimit[1]" type="number" maxlength="2" placeholder="MM" />
                                </div>
                                <div class="label-input">
                                  <label class="offscreen">월 유효기간</label>
                                  <v-input v-model="datelimit[2]" type="number" maxlength="2" placeholder="YY" />
                                </div>
                                <span class="result">
                                  <i class="icon-check"></i>
                                  <i class="icon-x"></i>
                                </span>
                              </el-form-item>
                            </div>
                          </li>
                          <li>
                            <em>할부기간</em>
                            <div class="form-group">
                              <v-select v-model="creditSelect" :data="creditSelectData" />
                              <v-popover trigger="hover" placement="bottom-start">
                                <p>할부 가능여부 및 이율은 각 신용카드사 정책 및 카드종류에 따라 다를 수 있으므로 사전에 해당 카드사에 확인하고 선택하시기 바랍니다.</p>
                                <v-btn slot="reference"><i class="icon-help"></i></v-btn>
                              </v-popover>
                            </div>
                          </li>
                          <li class="my-hyundaicard">
                            <v-btn class="btn-more" type="link" to="/" target="_blank" title="새창 열기">나의 현대카드 혜택 알아보기</v-btn>
                          </li>
                        </ul>
                      </div>
                    </li>
                    <li>
                      <strong class="form-label bold">제휴혜택</strong>
                      <div class="form-group full">
                        <ul class="desc-list">
                          <li>
                            <em>혜택 선택</em>
                            <v-radio v-model="costRadio" :data="costRadioList" />
                          </li>
                        </ul>
                      </div>
                    </li>
                    <li>
                      <strong class="form-label bold">M포인트</strong>
                      <div class="form-group full">
                        <ul class="desc-list mpoint">
                          <li>
                            <em>포인트 금액</em>
                            <div class="inbl-wrap">
                              <div class="label-input">
                                <label class="offscreen">포인트 금액</label>
                                <v-input v-model="mPoint" type="text" />
                              </div>
                              <v-checkbox :one-check="true" :checked.sync="pointCheck">전액 사용</v-checkbox>
                            </div>
                            <v-btn class="btn-more">사용하기</v-btn>
                            <div class="point-info">사용 가능 <strong>000,000</strong>P / <span>보유 <strong>000,000</strong>P</span></div>
                          </li>
                        </ul>
                      </div>
                    </li>
                    <li>
                      <div class="form-label full">
                        <strong class="bold">혜택신청</strong>
                        <v-btn class="btn-more">혜택 신청하기</v-btn>
                      </div>
                      <div class="form-group full">
                        <ul class="desc-list">
                          <li><v-checkbox :one-check="true" :checked.sync="requestCheck">카드 한도 상향 신청</v-checkbox></li>
                          <li class="save-auto">
                            <v-checkbox :one-check="true" :checked.sync="saveCheck">세이브-오토 30만</v-checkbox>
                            <v-btn class="btn-info" type="icon" icon-class="icon-info" @click="$emit('popSaveAutoGuide')"><span class="offscreen">안내팝업보기</span></v-btn>
                            <v-select v-model="saveSelect" :data="saveSelectData" disabled />
                          </li>
                        </ul>
                      </div>
                    </li>
                  </ul>
                </div>
              </section>
              <!-- // 신용카드 1 -->

              <!-- 신용카드 2 위치 -->
              <!-- // 신용카드 2 위치 -->

              <div class="btn-wrap">
                <v-btn class="btn md white r">신용카드 추가</v-btn>
              </div>
              <div v-if="type === 'payment'" class="info-list">
                <p class="bullet-star">아래 사항을 반드시 확인해 주세요.</p>
                <v-checkbox v-model="creditCheck" :data="creditCheckData" />
              </div>
            </div>
          </template>
        </v-tab>
      </el-form>
      <!-- 다시 결제하기 -->
      <div v-if="type === 'repayment'" class="payment-total-price">
        <div class="info-grid-list">
          <ul>
            <li>
              <strong class="info-title">미결제금액</strong>
              <div class="info-group">
                <span class="price">10,160,800 원</span>
              </div>
            </li>
            <li>
              <strong class="info-title">결제금액</strong>
              <div class="info-group">
                <span class="price">8,000,000 원</span>
              </div>
            </li>
            <li>
              <strong class="info-title">입력한 결제금액</strong>
              <div class="info-group">
                <span class="price">10,100,000 원</span>
              </div>
            </li>
            <li class="total-price">
              <strong class="info-title">미입력금액</strong>
              <div class="info-group">
                <span class="price">60,800</span> 원
              </div>
            </li>
          </ul>
          <p class="bullet">미입력 금액이 있습니다. 남은 결제금액을 입력해주세요. 결제 금액 전체 입력 완료되어야만 결제 진행이 가능합니다.</p>
        </div>
      </div>
      <!-- 추가 결제하기 -->
      <div v-if="type === 'addition'" class="payment-total-price">
        <div class="info-grid-list">
          <ul>
            <li>
              <strong class="info-title ct">최종결제금액</strong>
              <div class="info-group">
                <span class="price">200,000</span> 원
              </div>
            </li>
            <li>
              <strong class="info-title ct">입력한 결제금액</strong>
              <div class="info-group">
                <span class="price">200,000</span> 원
              </div>
            </li>
            <li class="total-price">
              <strong class="info-title ct">미입력금액</strong>
              <div class="info-group">
                <span class="price">0</span> 원
              </div>
            </li>
          </ul>
          <p class="bullet">미입력 금액이 있습니다. 남은 결제금액을 입력해주세요. 결제 금액 전체 입력 완료되어야만 결제 진행이 가능합니다.</p>
        </div>
      </div>
    </div>
  </section>
</template>

<script>
export default {
  components: {
  },
  props : {
    type: {
      type: String,
      default: '',
    },
  },
  data() {
    return {
      isOptionsShow: false,
      tabList: [
        { value: 'tab1', label: '신용카드' },
        { value: 'tab2', label: '무통장 입금' },
        { value: 'tab3', label: '무통장 입금 + 신용카드' },
      ],
      creditPrice: true,
      creditPaymentPrice: '',
      bankPrice: false,
      bankPaymentPrice: '',
      creditRadio: 'creditradio1',
      creditRadioData: [
        { value: 'creditradio1', label: '단기의무보험 포함' },
      ],
      creditDepositRadio: '',
      cardNumber: ['', '', '', ''],
      datelimit: ['', ''],
      creditOwn: 'own1',
      creditOwnData: [
        { value: 'own1', label: '박창석' },
        { value: 'own2', label: '홍길동' },
      ],
      creditSelect: 'date1',
      creditSelectData: [
        { value: 'date1', label: '일시불' },
        { value: 'date2', label: '3개월' },
      ],
      costRadio: '',
      costRadioList: [
        { value: '01', label: '캐시백' },
        { value: '02', label: '포인트 적립' }
      ],
      mPoint: '',
      pointCheck: false,
      requestCheck: false,
      saveCheck: false,
      saveSelect: 'save1',
      saveSelectData: [
        { value: 'save1', label: '30만' },
      ],
      creditCheck: '',
      creditCheckData: [
        { value: 'check1', label: '상기 입력하신 할인/포인트/할부/결제수단 등 결제정보는 결제완료 후 변경이 불가합니다.' },
        { value: 'check2', label: '차량결제 관련 신용카드 헤택은 당사와 무관하므로 각 카드사에 적용 기준을 확인하고 입력하시기 바랍니다.' },
        { value: 'check3', label: '신용카드 결제 시 단기의무보험료는 차량 가액 결제와 분할되어 별도 승인 처리됩니다.' },
        { value: 'check4', label: '결제요청 후 출고처리가 진행되며 출고처리 후에 취소하는 경우에는 왕복탁송료가 발생합니다.' },
      ],
      deposit: 'deposit1',
      depositData: [
        { value: 'deposit1', label: '박창석' },
        { value: 'deposit2', label: '홍길동' },
      ],
      depositBank: '',
      depositBankData: [
        { value: 'bank1', label: '우리은행' },
        { value: 'bank2', label: '국민은행' },
      ],
      depositCheck: '',
      depositCheckData: [
        { value: 'check1', label: '상기 입력하신 할인/포인트/할부/결제수단 등 결제정보는 결제완료 후 변경이 불가합니다.' },
        { value: 'check4', label: '결제요청 후 출고처리가 진행되며 출고처리 후에 취소하는 경우에는 왕복탁송료가 발생합니다.' },
      ],
    }
  },
  computed: {
    rules() {
      return {
        cardNumber: [
          {
            required: true,
            message: '* 카드번호를 입력해 주세요',
            trigger: 'blur',
          },
        ],
        datelimit: [
          {
            required: true,
            message: '* 유효기간을 입력해 주세요',
            trigger: 'blur',
          },
        ],
      }
    },
  },
  mounted() {
    this.setLabel((idg) => {
      // console.dir(idg) // 자동 생성된 ID 배열
    })
  },
}
</script>
