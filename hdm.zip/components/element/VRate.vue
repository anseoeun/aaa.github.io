<template>
    <el-rate
      v-model="value"
      @change="handleEvent"
      >
      <!-- :colors="colors" -->
    </el-rate>
</template>

<script>
export default {
  props: {
    value: {
      type: Number,
      default: 0
    },
    data: {
      type: Array,
      default: () => []
    }
  },
  data() {
    return {
      val: this.value
    }
  },
  watch: {
    value(newValue, oldValue) {
      console.log(newValue, oldValue)
      if (newValue !== oldValue) {
        this.value = newValue
        this.$emit('change', newValue)
      }
    },
  },
  mounted(){
    console.log(this.value)
  },
  methods: {
    handleEvent(e) {
      // console.log('com change')
      // this.value = this.val
      // this.$emit('change', this.val)
    },
  }
}
</script>
