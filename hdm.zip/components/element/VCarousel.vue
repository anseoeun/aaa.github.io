<template>
  <!-- 캐로셀 -->
  <el-carousel
    v-if="version <= 1"
    ref="carouselRef"
    v-touch:swipe.stop.prevent="swipeHandler('carouselRef')"
    :height="height"
    :autoplay="autoplay"
    :interval="interval"
    :trigger="trigger"
    :arrow="customItem == false && list.length <=1 ? 'never' : arrow"
    :indicator-position="customItem == false && list.length <=1 ? 'none' : indicatorPosition"
    :initial-index="currItemIndex"
    @change="onChange"
  >
    <!-- data list item -->
    <div v-if="!customItem">
      <el-carousel-item v-for="(item, index) in list" :key="index">
        <slot :item="item"></slot>
      </el-carousel-item>
    </div>

    <!-- custom element item -->
    <div v-else>
      <slot></slot>
    </div>
  </el-carousel>

  <!-- 캐로셀 <ver 2.0> -->
  <el-carousel
    v-else-if="version === 2"
    ref="carousel"
    v-touch:swipe.stop.prevent="swipeHandler('carousel')"
    :height="height === 'none' ? null : computedHeight"
    :autoplay="autoplay"
    :interval="interval"
    :trigger="trigger"
    :arrow="arrow"
    :initial-index="currIndex"
    :indicator-position="getIndicatorPosition"
    :type="type"
    :class="[
      { 'el-carousel--thumbnail': isThumbnail },
      { 'el-carousel--inner-slide': isInnerSlider },
      { 'el-carousel--solo': listGroup.length === 1 && listGroup[0].length },
      { 'el-carousel--hide-l-arrow': isLeftSide },
      { 'el-carousel--hide-r-arrow': isRightSide }
    ]"
    @change="onChange"
  >
    <template v-if="!customItem">
      <div class="el-carousel__layer">
        <el-carousel-item v-for="(groupItem, groupIndex) in listGroup" :key="groupItem.id">
          <ul
            :class="['el-carousel__groups', { 'el-carousel__groups--wrap': isListGroup }, { 'el-carousel--thumbnail__groups' : isThumbnail }]"
          >
            <li
              v-for="(item, index) in groupItem"
              :key="item.id"
              :class="['el-carousel__unit', { 'el-carousel--thumbnail__unit' : isThumbnail }]"
            >
              <slot
                name="item"
                :item="item"
                :index="index"
                :groupIndex="groupIndex"
                :setLazyResize="(idx) => lazyResize(idx)"
                :setResize="() => onResize"
                :currIndex="currIndex"
              ></slot>
            </li>
          </ul>
        </el-carousel-item>

        <div v-if="isThumbnail" class="board el-carousel__board">
          <div class="board__back" :style="thumnailBoardStyle">
            <div class="board__counter">
              <span>{{ currIndex + 1 }}</span>
              {{ ` / ${list.length}` }}
            </div>
          </div>
        </div>
      </div>

      <!-- 썸네일 모듈 -->
      <div v-if="isThumbnail" class="thumnail el-carousel__thumnail" :style="thumnailStyle">
        <button
          v-for="index in 2"
          :key="`t-arr-${index}`"
          :class="['thumnail__arrow', index === 1 ? 'thumnail__arrow--left' : 'thumnail__arrow--right']"
          @click.prevent.stop="onClickTriggerBtn({ dir: index === 1 ? 'LEFT' : 'RIGHT' })"
        ></button>
        <ul class="thumnail__list">
          <li
            v-for="(item, index) in thumbnailData"
            :key="`thumb-i-${index}`"
            class="thumnail__item"
            :style="thumnailItemStyle"
            @click.prevent.stop="onClickTriggerBtn({ index })"
          >
            <picture :class="['thumnail__pic', { 'is-active': index === currIndex }]">
              <!-- <source srcset="" media="(min-width: 760px)"> -->
              <img :src="item.imgUrl" alt />
            </picture>
          </li>
        </ul>
      </div>
    </template>

    <!-- 내부 슬라이드 형태 -->
    <template v-else-if="customItem && isInnerSlider">
      <button
        v-for="index in 2"
        :key="`t-arr-${index}`"
        :class="[
          'thumnail__arrow',
          index === 1 ? 'thumnail__arrow--left' : 'thumnail__arrow--right',
          index === 1 ? { 'is-hide' : isLeftSide } : { 'is-hide' : isRightSide }
        ]"
        @click.prevent.stop="onClickTriggerBtn({ dir: index === 1 ? 'LEFT' : 'RIGHT' })"
      ></button>
      <div class="el-carousel__layer">
        <el-carousel-item v-for="(groupItem, groupIndex) in listGroup" :key="groupItem.id">
          <ul :class="['el-carousel__groups', { 'el-carousel__groups--wrap-mode': isListGroup }]">
            <li
              v-for="(item, index) in groupItem"
              :key="item.id"
              :class="['el-carousel__unit', { 'is-active': item.isActive }]"
            >
              <slot
                name="item"
                :item="item"
                :index="index"
                :groupIndex="groupIndex"
                :setLazyResize="(idx) => lazyResize(idx)"
                :setResize="() => onResize"
                :currIndex="currIndex"
              ></slot>
            </li>
          </ul>
        </el-carousel-item>
      </div>
    </template>

    <!-- 커스텀 레이아웃 형태 -->
    <template v-else-if="customItem && !isInnerSlider">
      <slot></slot>
    </template>
  </el-carousel>

</template>

<script>
import deepCopy from 'lodash/cloneDeep'

export default {
  props: {
    type: {
      type: String,
      default: ''
    },

    groupId: {
      type: String,
      default: 'unnamed'
    },

    version: {
      type: Number,
      default: 1
    },

    isTriggerStateUpdate: {
      type: Boolean,
      default: false
    },

    isReactive: {
      type: Boolean,
      default: true
    },

    isInnerSlider: {
      type: Boolean,
      default: false
    },

    isThumbnail: {
      type: Boolean,
      default: false
    },

    layout: {
      type: Object,
      default: () => {}
    },

    // deprecated
    maxHeight: {
      type: Object,
      default: () => {}
    },

    thumbnailData: {
      type: Array,
      default: () => []
    },

    currItemIndex: {
      type: Number,
      default: 0
    },

    data: {
      type: Array,
      default: () => []
    },

    height: {
      type: String,
      default: ''
    },

    autoplay: {
      type: Boolean,
      default: false
    },

    interval: {
      type: Number,
      default: 3000
    },

    trigger: {
      type: String,
      default: 'click'
    },

    arrow: {
      type: String,
      default: 'always'
    },

    indicatorPosition: {
      type: String,
      default: 'outside'
    },

    customItem: {
      type: Boolean,
      default: false
    }
  },

  data() {
    return {
      baseLayout: { desktop: { row: 1, col: 1 }, tablet: { row: 1, col: 1 }, mobile: { row: 1, col: 1 } },
      baseMaxHeight: { desktop: 'auto', tablet: 'auto', mobile: 'auto' },
      isBindEvents: false,
      currIndex: 0,
      inSliderMaxLen: 0,
      thumbnail: { width: 0, height: 0 }
    }
  },

  computed: {
    thumnailStyle() {
      const thumbnailHeight = this.thumbnail.height
      const value = (thumbnailHeight && parseInt(thumbnailHeight.split('px')[0])) || 170

      return { transform: `translateY(-${value}px)` }
    },

    thumnailItemStyle() {
      const currIndex = this.currIndex || 0
      const SLIDE_PER_ITEM = 4
      const thumbnailWidth = this.thumbnail.width
      const containerWidth = (thumbnailWidth && parseInt(thumbnailWidth.split('px')[0])) || 720
      const itemWidth = '25%'
      const value = this.isThumbnail
        ? -(Math.floor(currIndex / SLIDE_PER_ITEM) * containerWidth)
        : -(currIndex * containerWidth)

      return { width: itemWidth, transform: `translateX(${value}px)` }
    },

    thumnailBoardStyle() {
      const BOARD_HEIGHT = 106
      const CONTAINER_HEIGHT = 405
      const currIndex = this.currIndex || 0
      const group = this.groups && this.groups[currIndex]
      const groupHeight = group ? group.offsetHeight : CONTAINER_HEIGHT
      const value = groupHeight - BOARD_HEIGHT

      return { top: `${value}px` }
    },

    getIndicatorPosition() {
      return this.isThumbnail ? 'none' : this.indicatorPosition
    },

    computedHeight() {
      const isPixel = (_) => _.indexOf('auto') !== -1 || _.indexOf('px') !== -1
      return this.height ? this.height : ((_) => (isPixel(_) ? _ : ''))(this.baseMaxHeight[this.$mq])
    },

    isListGroup() {
      // return this.baseLayout[this.$mq].row > 1
    },

    listGroup() {
      const { row, col } = this.baseLayout[this.$mq]
      const volume = row * col
      let groups = []
      let data = deepCopy(this.data)
      while (data.length > volume) {
        groups.push(data.splice(0, volume))
      }

      return [...groups, data]
    },

    list() {
      return this.data.map((item) => ({ ...item }))
    },

    isLeftSide() {
      return this.isInSlideRange() && this.currIndex === 0
    },

    isRightSide() {
      return this.isInSlideRange() && this.currIndex + 1 === this.inSliderMaxLen
    }
  },

  watch: {
    isListGroup(bool) {
      return bool ? this.addEvent() : this.removeEvent()
    },

    $mq(curr, prev) {
      if (this.version >= 2) {
        this.$nextTick(() => this.createState())
      }
    }
  },

  created() {
    if (this.version >= 2) {
      this.bindProps()
      this.handleBaseField('maxHeight')
      this.handleBaseField('layout')
    }
  },

  mounted() {
    if (!this.isBindEvents && this.version >= 2) {
      this.$nextTick(() => {
        this.initialize()
        this.lazyResize()
        this.$emit('load')
        setTimeout(() => {
          this.onResize()
        }, 0)
      })
    }
  },

  beforeDestroy() {
    this.removeEvent()
  },

  methods: {
    initialize() {
      this.createState()
      !this.isBindEvents && this.addEvent()
      this.isGroupId() && this.setSubscribe()
    },

    createState() {
      this.setUIState()
      this.bindUIElements()
    },

    setUIState() {
      this.currIndex = this.currItemIndex || 0
      this.inSliderMaxLen = (() => {
        const isCustomItem = this.customItem
        let result = this.listGroup.length
        if (isCustomItem) {
          const carouselGroups = this.$el.getElementsByClassName('el-carousel__groups')
          const carouselItems = this.$el.getElementsByClassName('el-carousel__item')
          result = carouselGroups.length > 0 ? this._slice(carouselGroups).length : carouselItems.length
        }
        return result
      })()
    },

    _slice(_) {
      return [].slice.apply(_)
    },

    bindUIElements() {
      const { _slice, isThumbnail } = this
      this.arrowBtns = _slice(this.$el.getElementsByClassName('el-carousel__arrow'))
      this.indicators = _slice(this.$el.getElementsByClassName('el-carousel__indicator'))
      this.groups = _slice(this.$el.getElementsByClassName('el-carousel__groups'))
      isThumbnail && (this.thumbnailNode = this.$el.getElementsByClassName('thumnail')[0])
    },

    imgStateChecker(itemIndex) {
      const { currIndex, groups, _slice } = this
      if (!groups.length) {
        return
      }

      const targetNode = (() => {
        if (itemIndex !== undefined && itemIndex !== null) {
          const units = _slice(groups[currIndex].getElementsByClassName('el-carousel__unit'))
          return units[itemIndex]
        } else return groups[currIndex]
      })()
      const MAX_DURATION = 300
      const imgGetter = () => targetNode.getElementsByTagName('img')
      const setResize = () => {
        this.onResize()
        clearInterval(fn)
      }

      let nodes = imgGetter()
      let time = 0
      const checker = () => {
        return requestAnimationFrame(() => {
          nodes = imgGetter()
          time++

          for (const node of nodes) {
            node.onload = function() {
              setResize()
            }

            if (node.complete && node.naturalWidth) {
              setResize()
            }
          }

          if (time >= MAX_DURATION) {
            setResize()
          }
        })
      }
      const fn = setInterval(checker, 10)
    },

    bindProps() {
      this.currIndex = [].concat(this.currItemIndex)[0]
    },

    isInSlideRange() {
      return 0 <= this.currIndex && this.currIndex <= this.inSliderMaxLen
    },

    isGroupId() {
      return this.groupId !== 'unnamed'
    },

    setSubscribe() {
      this.$store.subscribe((mutation, state) => {
        const clone = deepCopy(state.sharedHeight[this.groupId])
        const isCloneDone = clone && clone !== '0px'
        const prev = this.baseMaxHeight[this.$mq]
        const isDiff = prev !== clone

        if (mutation.type === 'SET_SHARED_HEIGHT' && isDiff && isCloneDone) {
          this.baseMaxHeight[this.$mq] = clone
        }
      })
    },

    checkPassiveEvent() {
      let passiveEventSupported = false
      const checker = Object.defineProperty({}, 'passive', {
        get: () => (passiveEventSupported = true)
      })

      window.addEventListener('checkEvent', null, checker)
      window.removeEventListener('checkEvent', null, checker)

      return passiveEventSupported ? { capture: false, passive: true } : false
    },

    addEvent() {
      this.isBindEvents = true

      if (this.isThumbnail || this.isReactive) {
        !this.arrowBtns && !this.indicators && this.bindUIElements()
        const { arrowBtns, indicators } = this
        arrowBtns && arrowBtns.forEach((node) => node.addEventListener('click', this.onClick, false))
        indicators && indicators.forEach((node) => node.addEventListener('click', this.onClick, false))
      }

      window.addEventListener('resize', this.onResize, this.checkPassiveEvent)
    },

    removeEvent() {
      this.isGroupId() && this.$store.commit('SET_SHARED_HEIGHT', { name: this.groupId, isRemove: true })
      window.removeEventListener('resize', this.onResize)

      if (this.isThumbnail || this.isReactive) {
        const { arrowBtns, indicators } = this
        arrowBtns && arrowBtns.forEach((node) => node.removeEventListener('click', this.onClick))
        indicators && indicators.forEach((node) => node.removeEventListener('click', this.onClick))
      }

      this.isBindEvents = false
    },

    onClick() {
      this.onResize()
    },

    lazyResize(itemIndex) {
      if (this.version >= 2) {
        this.imgStateChecker(itemIndex)
      }
    },

    onResize() {
      if (!this.groups.length) {
        return
      }

      this.checkContainerHeight()
      if (this.isThumbnail) {
        this.checkThumbnailHeight()
        this.checkThumbnailWidth()
      }
    },

    checkThumbnailHeight() {
      const currHeight = this.thumbnailNode.offsetHeight + 'px'
      const prveHeight = this.thumbnail.height
      const isChange = prveHeight !== currHeight

      return this.setTask(this.handleState([currHeight, 'thumbnail', 'height']), {
        cancel: () => !isChange || currHeight === '0px',
        action: () => isChange
      })()
    },

    checkThumbnailWidth() {
      const currWidth = this.$el.offsetWidth + 'px'
      const prveWidth = this.thumbnail.width
      const isChange = prveWidth !== currWidth

      return this.setTask(this.handleState([currWidth, 'thumbnail', 'width']), {
        cancel: () => !isChange || currWidth === '0px',
        action: () => isChange
      })()
    },

    checkContainerHeight() {
      const breakPoint = this.$mq
      const groupHeight = this.groups[this.currIndex].offsetHeight
      const thumbnailHeight = this.isThumbnail && this.thumbnailNode.offsetHeight
      const currHeight = (this.isThumbnail ? groupHeight + thumbnailHeight : groupHeight) + 'px'
      const prevHeight = this.baseMaxHeight[breakPoint]
      const isChange = prevHeight !== currHeight

      return this.setTask(
        this.handleState(
          (() => {
            this.isGroupId() &&
              this.$store.commit('SET_SHARED_HEIGHT', { name: this.groupId, height: `${currHeight}px` })
            return [currHeight, 'baseMaxHeight', breakPoint]
          })()
        ),
        {
          cancel: () => !isChange || currHeight === '0px',
          action: () => isChange
        }
      )()
    },

    handleState([updateValue, ...props]) {
      return () => (this[props[0]][props[1]] = updateValue)
    },

    setTask(fn, { cancel = () => false, action = () => true }) {
      let tick = false
      return () => {
        if (tick) {
          return
        }

        tick = true
        return requestAnimationFrame(() => {
          if (cancel()) {
            tick = false
            return
          }

          if (action()) {
            tick = false
            return fn()
          }
        })
      }
    },

    handleBaseField(reqStr) {
      const setter = {
        maxHeight(name, value) {
          if (typeof value === 'number') {
            table[name] = `${value}px`
          } else if (typeof value === 'string' && value.indexOf('px') === -1) {
            table[name] = `${value}px`
          } else if (typeof value === 'string' && /^[\d]+px/.test(value)) {
            table[name] = value
          } else {
            throw `Invaild input on carousel's height props. Please, refer to the document.`
          }
        },
        layout(name, value) {
          if (typeof value === 'string' && /\d{1}x\d{1}/.test(value)) {
            const [col, row] = value.split('x').map((x) => parseInt(x))
            table[name] = { col, row }
          } else if (typeof value === 'number') {
            table[name].col = [].concat(requestedField[name])[0]
          } else {
            throw `Invaild input on carousel's layout props. Please, refer to the document.`
          }
        }
      }
      const requestedField = this[reqStr]
      const name = ((str) => str.charAt(0).toUpperCase() + str.slice(1))(reqStr)
      const baseTable = `base${name}`
      let table = this[baseTable]

      for (const propName in requestedField) {
        setter[reqStr](propName, requestedField[propName])
        const allocatedValue = deepCopy(table[propName])
        switch (propName) {
          case 'desktop':
            table['tablet'] = allocatedValue
            table['mobile'] = allocatedValue
            break
          case 'tablet':
            table['mobile'] = allocatedValue
            break
        }
      }

      this[baseTable] = table
    },

    setLevel({ index, dir }) {
      const { carousel } = this.$refs

      if (dir === 'RIGHT') {
        carousel.next()
      } else if (dir === 'LEFT') {
        carousel.prev()
      } else {
        carousel.setActiveItem(index)
      }
    },

    onClickTriggerBtn(param) {
      this.setLevel(param)
      this.$nextTick(() => this.onResize())
    },

    onChange(currentIndex, prevIndex) {
      this.currIndex = currentIndex
      this.$emit('change', currentIndex, prevIndex)
    },

    setActiveItem(idx, refName) {
      refName = refName ? refName : 'carouselRef'
      this.$refs[refName].setActiveItem(idx)
    },

    swipeHandler(refsName) {
      if (this.$mq === 'desktop') return
      return (direction, event) => {
        if (direction == 'left') {
          this.$refs[refsName] && this.$refs[refsName].next()
        } else if (direction == 'right') {
          this.$refs[refsName] && this.$refs[refsName].prev()
        }
      }
    }
  }
}
</script>
