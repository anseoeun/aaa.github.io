<template>
  <div class="page-more">
    <a href="javascript:void(0);" class="more"
      @click="handleClick"
    >
      더보기({{ page }}<span class="total">/{{ total }}</span
      >)
    </a>
  </div>
</template>

<script>
export default {
  name:'VPageMore',
  props: {
    total: {
      type: [Number, String],
      default: 1,
    },
    page: {
      type: [Number, String],
      default: 1,
    },
  },
  methods: {
    handleClick(e) {
      this.$emit('click', e)
    },
  },
}
</script>
