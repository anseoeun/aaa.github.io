<template>
  <el-date-picker
    :value="value"
    :disabled="disabled"
    :format="getFormat.format"
    :value-format="getFormat.value"
    :placeholder="placeholder"
    :clearable="clearable"
    type="date"
    @input="onChange"
    >
  </el-date-picker>
</template>

<script>
export default {
  props: {
    value: {
      type: String,
      default: ''
    },
    type: {
      type: String,
      default: 'date'
    },
    disabled: {
      type: Boolean,
      default: false
    },
    format: {
      type: String,
      default: 'yyyy.MM.dd'
    },
    valueFormat: {
      type: String,
      default: 'yyyy.MM.dd'
    },
    placeholder: {
      type: String,
      default: ''
    },
    clearable: {
      type: Boolean,
      default: false
    }
  },

  computed: {
    getFormat() {
      let format = this.format
      let value = this.valueFormat
      if (this.type === 'month') {
        format = 'yyyy.MM'
        value = 'yyyy.MM'
      } else if (this.type === 'year') {
        format = 'yyyy'
        value = 'yyyy'
      }
      return { format, value }
    }
  },

  methods: {
    onChange(value) {
      this.$emit('input', value)
      this.$emit('change', value)
    }
  }
}
</script>

