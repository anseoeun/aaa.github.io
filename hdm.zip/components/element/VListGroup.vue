<template>
  <div :class="`list-wrap ${listType}`">
    <slot></slot>
  </div>
</template>

<script>
export default {
  props: {
    accordion: {
      type: Boolean,
      default: false
    },
    listType: {
      type: String,
      default: ''
    },
    value: {
      type: Array,
      default: () => []
    },
    data: {
      type: Array,
      default: () => []
    },
    firstSelect: {
      type: Boolean,
      default: true
    },
    isOpen: {
      type: Boolean,
      default: false
    },
    isItemOpen: {
      type: Object,
      default: () => {}
    },
    target: {
      type: String,
      default: ''
    }
  },

  data() {
    return {
      selected: [],
      allSelected: []
    }
  },
  watch: {
    value(newValue, oldValue) {
      const diffList = newValue.filter((val, index) => val !== oldValue[index])
      if (diffList.length) {
        this.selected = [...newValue]
      }
    },
    isOpen(value) {
      if (value === true) {
        this.selected = [...this.allSelected]
      } else if (value === false) {
        this.selected = []
      }
    },
    isItemOpen: {
      deep: true,
      handler(value) {
        if (value.checkTF) {
          if (!this.selected.includes(value.dataId)) this.selected.push(value.dataId)
        } else {
          if (this.selected.includes(value.dataId)) {
            const idx = this.selected.indexOf(value.dataId)
            this.selected.splice(idx, 1)
          }
        }
      }
    }
  },
  created() {
    this.$on('item-click', this.onItemClick)
    this.$nuxt.$on('tab-change', () => {
      this.selected = []
    })
  },

  mounted() {
    if (this.value.length) {
      this.selected = [...this.value]
      return
    }
    if (this.$slots.default && this.firstSelect) {
      this.setSlots()
    }
    this.allSelectInit()
  },

  methods: {
    setSlots() {
      const slotList = this.$slots.default.filter((node) => node.elm && node.elm.dataset)
      this.selected = [slotList[0].elm.dataset.id]
      this.$emit('input', [...this.selected])
    },

    onItemClick(dataId) {
      this.selected = this.accordion
        ? this.selected.includes(dataId)
          ? []
          : [dataId]
        : this.selected.includes(dataId)
        ? this.selected.filter((id) => id !== dataId)
        : this.selected.concat(dataId)
      this.$emit('input', [...this.selected])
      // console.log(this.selected.includes(dataId), this.selected.length, this.allSelected.length, this.isOpen)
      if (this.target) {
        if (this.selected.includes(dataId) && this.selected.length === this.allSelected.length) {
          this.$emit('isOpenToggle', this.target, true)
          // console.log('열어')
        } else {
          this.$emit('isOpenToggle', this.target, null)
          // console.log('null')
        }
      }
      // console.log(this.selected.includes(dataId), this.selected.length, this.allSelected.length, this.isOpen)
    },
    change() {
      if (this.selected.length > 0) {
        this.selected = []
      }
    },
    allSelectInit() {
      this.allSelected = this.$children.map((listItem) => listItem.dataId)
    }
  }
}
</script>
