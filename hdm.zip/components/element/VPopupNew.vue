<template>
  <el-dialog
    v-if="isOpen"
    :visible.sync="isOpen"
    :width="width"
    :modal="isDim"
    :lock-scroll="parentsScroll"
    :show-close="false"
    :close-on-click-modal="dimClick"
    :custom-class="`popup-new-container ${customClass}`"
    :fullscreen="fullPopup"
    @close="onClose"
  >
    <button v-if="isClose" class="popup-close-button" @click="onClose">
      <span class="sr-only">창닫기</span>
    </button>
    <!-- Header -->
    <div v-if="$slots.header && headerVisible" class="popup-header">
      <slot name="header"></slot>
    </div>

    <!-- Body -->
    <div class="popup-body">
      <p v-if="contentsType === 'message'">
        {{ contentsText }}
      </p>
      <slot v-else-if="contentsType === 'contents-slot'" name="body"></slot>
      <slot v-else name="body"></slot>
    </div>

    <div v-if="$slots.footer" class="popup-footer">
      <slot name="footer"></slot>
    </div>
    <div v-else-if="footerButton.length && footerVisible" class="popup-footer-btn-group">
      <v-btn
        v-for="(value, index) in footerButton"
        :key="index"
        :data-id="value"
        :b-color="value === 'cancel' ? 'btn-gray' : ''"
        b-size="btn-md"
        @click="footerBtnClick(value)"
      >
        {{ value }}
      </v-btn>
    </div>
  </el-dialog>
</template>

<script>
import VBtn from '~/components/element/VBtn'
export default {
  components: {
    VBtn
  },
  props: {
    visible: {
      type: Boolean,
      default: false,
      required: true
    },
    fullPopup: {
      type: Boolean,
      default: false,
      required: false
    },
    customClass: {
      type: String,
      default: '',
      required: false
    },
    dimClick: {
      type: Boolean,
      default: true,
      required: false
    },
    width: {
      type: String,
      default: 'auto',
      required: false
    },
    parentsScroll: {
      type: Boolean,
      default: true,
      required: false
    },
    isClose: {
      type: Boolean,
      default: true,
      required: false
    },
    closeSize: {
      type: String,
      default: '30px',
      required: false
    },
    isDim: {
      type: Boolean,
      default: true,
      required: false
    },
    headerVisible: {
      type: Boolean,
      default: true,
      required: false
    },
    contentsType: {
      type: String,
      default: 'message',
      required: false
    },
    contentsText: {
      type: String,
      default: '',
      required: false
    },
    footerVisible: {
      type: Boolean,
      default: true,
      required: false
    },
    footerButton: {
      type: Array,
      default: () => [],
      required: false
    }
  },
  data() {
    return {
      isOpen: false,
      message: false
    }
  },
  watch: {
    visible(newVisible, oldVisible) {
      this.isOpen = newVisible
    },
    isOpen(newValue) {
      if (!newValue) {
        this.onClose()
      }
    }
  },
  methods: {
    onClose() {
      this.$emit('close')
    },
    footerBtnClick(value) {
      //footer 버튼 값 전달
      this.$emit('footBtnClick', value)
    }
  }
}
</script>

