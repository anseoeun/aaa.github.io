<template>
  <div>
      <hooper
        :items-to-show="itemsToShow"
        :pagination="pagination"
        :navigation="navigation"
        :auto-play="autoPlay"
        :infinite-scroll="infiniteScroll"
        :items-to-slide="itemsToSlide"
        :touch-drag="false"
        :mouse-drag="false"
        :wheel-control="false"
        :keys-control="false"
        :short-drag="false"
        :trim-white-space="true"
      >
        <!-- list -->
        <template v-if="customItem === null">
            <slide v-for="(item, index) in data" :key="index">
                <slot :item="item"></slot>
            </slide>
        </template>

        <!-- custon -->
        <template>
            <slide v-for="(item, index) in customItem" :key="index">
                <slot :name="'slide'+(index+1)"></slot>
            </slide>
        </template>

        <hooper-navigation v-if="navigation && (data.length > 1 || customItem > 1)" ref="arrow" slot="hooper-addons"></hooper-navigation>
        <hooper-pagination v-if="pagination && (data.length > 1 || customItem > 1)" slot="hooper-addons"></hooper-pagination>
      </hooper>
  </div>
</template>

<script>
import {
  Hooper,
  Slide,
  Pagination as HooperPagination,
  Navigation as HooperNavigation
} from 'hooper'
import 'hooper/dist/hooper.css'
 export default {
  components: {
    Hooper,
    Slide,
    HooperPagination,
    HooperNavigation
  },
    props: {
        data: {
          type:Array,
          default:() => []
        },
        itemsToShow:{
          type:[String, Number],
          default:1,
        },
        itemsToSlide:{
          type:[String, Number],
          default:1,
        },
        autoPlay:{
          type:Boolean,
          default:false,
        },
        infiniteScroll:{
          type:Boolean,
          default:false,
        },
        navigation:{
          type:Boolean,
          default:false,
        },
        pagination:{
          type:Boolean,
          default:false,
        },
        customItem:{
          type:Number,
          default:null
        },
    },
    data() {
      return {
        dotSize:14
      }
    },
    computed:{
      pagingSize(){
        return this.dotSize * this.data.length
      },
      list(){
        return this.data.map((item) => ({...item}))
      }
    },
    mounted(){
      this.$refs.arrow.$el.firstChild.style.left = - this.pagingSize/ 2 + 'px'
      this.$refs.arrow.$el.lastChild.style.right = - this.pagingSize/ 2 + 'px'
    }

  }
</script>

<style>

</style>