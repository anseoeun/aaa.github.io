<template>
  <v-popup
    :width="'776px'"
    :visible="popVisible.postCode"
    @close="popVisible.postCode = false"
  >
    <template slot="header">
      <div class="title">주소 검색</div>
      <p class="header-description">주소명(도로명, 건물번호)을 입력해주세요.</p>
    </template>
    <template slot="body">
      <div class="post-code-search">
        <v-input
          v-model="postCode"
          class="post-code-input"
          placeholder="예) 헌릉로 12, 양재동 231"
        ></v-input>
        <v-btn class="btn btn md white r">검색</v-btn>
      </div>
      <p class="contents-head">* 검색결과 {{ total }} 건</p>
      <div v-if="addrList.length > 0">
        <div class="table-area">
          <table class="noline-in">
            <colgroup>
              <col width="200px" />
              <col width="auto" />
            </colgroup>
            <thead>
              <tr>
                <th>우편번호</th>
                <th>주소</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="(addr, index) in addrList" :key="index">
                <td>{{ addr.code }}</td>
                <td class="left">{{ addr.address }}</td>
              </tr>
            </tbody>
          </table>
        </div>
        <v-pagination />
      </div>
      <!-- 결과없음 -->
      <div v-else class="addr-no-result">
        검색결과가 없습니다.
      </div>
    </template>
  </v-popup>
</template>
<script>
import { VBtn, VInput, VPopup, VPagination } from '~/components/element'
export default {
  components: {
    VPopup,
    VBtn,
    VInput,
    VPagination
  },
  props: {
    popVisible: {
      type: Object,
      defualt: {},
      required: true
    }
  },
  data() {
    return {
      postCode: '',
      addrList:[
        {code:'06711', address:'서울특별시 서초구 남부순환로317길 (서초동, 서초동 코아아파트)'},
        {code:'06717', address:'서울특별시 서초구 남부순환로317길 (서초동, 서초동 코아아파트)'},
        {code:'06720', address:'서울특별시 서초구 남부순환로317길 (서초동, 서초동 코아아파트)'},
        {code:'06711', address:'서울특별시 서초구 남부순환로317길 (서초동, 서초동 코아아파트)'},
        {code:'06717', address:'서울특별시 서초구 남부순환로317길 (서초동, 서초동 코아아파트)'},
        {code:'06720', address:'서울특별시 서초구 남부순환로317길 (서초동, 서초동 코아아파트)'},
      ]
    }
  },
  computed:{
    total() {
     return this.addrList.length
    }
  },
  updated() {
    this.setLabel((idg) => {
      // console.dir(idg) // 자동 생성된 ID 배열
    })
  },
}
</script>
