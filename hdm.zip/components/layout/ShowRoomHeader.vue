<template>
  <!-- 최초진입시 entry -->
  <div class="showroom-header-wrap entry">
    <strong class="logo">
      <nuxt-link to="/"><span class="offscreen">AX</span></nuxt-link>
    </strong>
    <div class="showroom-menu">
      <ul>
        <li>
          <nuxt-link to="/">하이라이트</nuxt-link>
        </li>
        <li>
          <nuxt-link to="/">디자인</nuxt-link>
        </li>
        <li>
          <nuxt-link to="/">편의사항</nuxt-link>
        </li>
        <li>
          <nuxt-link to="/">성능</nuxt-link>
        </li>
        <li>
          <nuxt-link to="/">안전</nuxt-link>
        </li>
        <li>
          <nuxt-link to="/">액세서리</nuxt-link>
        </li>
      </ul>
    </div>
    <div class="my-car">
      <v-btn class="btn md white r" type="nlink">내 차 만들기</v-btn>
    </div>
  </div>
</template>

<script>
import VBtn from '~/components/element/VBtn'
export default {
  components: {
    VBtn
  },
}
</script>
