<template>
   <v-popup
      type="alram-popup"
      class="alram-popup"
      :visible="alrampopVisible"
      width="400px"
      @close="onClose"
    >
      <template slot="header">알림</template>
      <template slot="body">
        <div v-if="isLogin" class="alarm-list-wrap">
          <ul v-if="isAlarm" class="alarm-list">
            <li v-for="(list, index) in data" :key="index">
              <a href="javascript:void(0);" role="button">
                <div class="top">
                  <span class="tag">{{ list.tag }}</span>
                  <span class="date">{{ list.date }}</span>
                </div>
                <p class="text">{{ list.text }}</p>
              </a>
            </li>
          </ul>
          <div v-else class="no-alarm">
            <i></i>
            <p>새로운 알림이 없습니다.</p>
          </div>
          <div class="btn-alarm-total">
            <v-btn class="btn-more" type="nlink">전체보기</v-btn>
          </div>
        </div>
        <div v-else class="alarm-login">
          <div class="txt">로그인 후 확인하실 수 있습니다.</div>
          <div class="btn-wrap">
            <v-btn class="btn md white r" type="button">로그인하기</v-btn>
          </div>
        </div>
      </template>
    </v-popup>
</template>

<script>
import {VBtn, VPopup} from '~/components/element/'
export default {
  components: {
    VBtn,
    VPopup
  },
  props:{
    isLogin:{
      type:Boolean,
      default: false,
    },
    isAlarm:{
      type:Boolean,
      default: false,
    },
    alrampopVisible:{
      type:Boolean,
      default: false,
    },
    data:{
      type:Array,
      default: ()=> []
    }
  },
  data() {
    return {}
  },
  methods: {
    onClose() {
      this.$emit('close')
    },
  }
}
</script>
