<template>
  <div class="content payment">
    <v-pageheader
      :top-breadcrumb="topBreadcrumb"
      page-title="결제하기"
    >
      <div class="term">결제 기한이 {{ deadline }} 남았습니다</div>
      <div class="require-check">
        <strong class="title">꼭 확인해주세요</strong>
        <p>
          {{ deadlineTime }}까지<br />
          결제를 완료해 주세요.<br />
          기한 내 결제를 완료하지 않는 경우 차량 배정이 취소됩니다.
        </p>
      </div>
    </v-pageheader>
    <div class="purchase-wrap">
      <div class="purchase-info">
        <amount />
        <take-over
          @tintingPop="popupVisible.tinting = true"
          @bluehandsPop="popupVisible.bluehands = true"
          @postCodePopup="popupVisible.postCode = true"
          />
        <sale />
        <point-use />
        <installment-select
          @installmentProducts="popupVisible.installmentProducts = true"
          @installmentSearch="popupVisible.installmentSearch = true"
          @repaymentPlan="popupVisible.repaymentPlan = true"
         />
        <payment-method type="payment"
          @popSaveAutoGuide="popupVisible.saveAutoGuide = true"
         />
        <total-price />
      </div>
      <payment-tool
        @popRegistrationFee="popupVisible.feePop = true"
       />
    </div>
    <popup :visible.sync="popupVisible" @visibleSync="popupSync" />
  </div>
</template>

<script>
import Amount from '~/components/page/payment/main/Amount'
import TakeOver from '~/components/page/payment/main/TakeOver'
import Sale from '~/components/page/payment/main/Sale'
import PointUse from '~/components/page/payment/main/PointUse'
import InstallmentSelect from '~/components/page/payment/main/InstallmentSelect'
import PaymentMethod from '~/components/page/payment/main/PaymentMethod'
import TotalPrice from '~/components/page/payment/main/TotalPrice'
import PaymentTool from '~/components/page/payment/main/PaymentTool'
import Popup from '~/components/page/payment/popup'
export default {
  head() {
    return {
      title: '결제 > 결제하기',
    }
  },
  name:'Payment',
  components: {
    Amount,
    TakeOver,
    Sale,
    PointUse,
    InstallmentSelect,
    PaymentMethod,
    TotalPrice,
    PaymentTool,
    Popup
  },
  data() {
    return{
      topBreadcrumb: [
        { linkName: '결제', link: '/' },
        { linkName: '결제하기', link: '/' },
      ],
      deadline: '1일 20시간 12분',
      deadlineTime:'2021. 01. 21 15:47',
      popupVisible: {
        amountChange:false,
        tinting: false,
        tintingCoupon: false,
        bluehands: false,
        installmentSearch: false,
        repaymentPlan: false,
        privacy:false,
        postCode: false,
        installmentProducts: false,
        paymentwait: false,
        feePop: false,
        infoAcquirement: false,
        InfoFund: false,
        installmentIncrease: false,
        installmentIncreaseGuide: false,
        saveAuto: false,
        saveAutoGuide: false,
        CreditSaveAuto: false
      }
    }
  },
  methods: {
    popupSync(e) {
      this.popupVisible = e
    }
  }
}
</script>

