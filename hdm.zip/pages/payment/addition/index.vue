<template>
  <div class="content payment">
    <v-pageheader
      :top-breadcrumb="topBreadcrumb"
      page-title="추가 결제하기"
    >
      <div class="term">결제 기한이 {{ deadline }} 남았습니다</div>
      <div class="require-check">
        <strong class="title">꼭 확인해주세요</strong>
        <p>
          {{ deadlineTime }}까지<br />
          결제를 완료해 주세요.<br />
          기한 내 결제를 완료하지 않는 경우 차량 배정이 취소됩니다.
        </p>
      </div>
    </v-pageheader>
    <div class="purchase-wrap">
      <div class="purchase-info addition">
        <payment-method type="addition"
          @popSaveAutoGuide="popupVisible.saveAutoGuide = true"
        />
        <div class="addition-check">
          <v-checkbox :one-check="true" :checked.sync="additionCheck">구매내용 및 조건을 확인하였으며, 결제 조건에 동의합니다.</v-checkbox>
          <v-btn class="btn lg blue r">결제하기</v-btn>
        </div>
      </div>
    </div>
    <popup :visible.sync="popupVisible" @visibleSync="popupSync" />
  </div>
</template>

<script>
import PaymentMethod from '~/components/page/payment/main/PaymentMethod'
import Popup from '~/components/page/payment/popup'
export default {
  head() {
    return {
      title: '결제 > 추가결제하기',
    }
  },
  name:'Payment',
  components: {
    PaymentMethod,
    Popup
  },
  data() {
    return{
      topBreadcrumb: [
        { linkName: '결제', link: '/' },
        { linkName: '추가 결제하기', link: '/' },
      ],
      deadline: '1일 20시간 12분',
      deadlineTime:'2021. 01. 21 15:47',
      popupVisible: {
        saveAuto: false,
        saveAutoGuide: false,
      },
      additionCheck: false,
    }
  },
  methods: {
    popupSync(e) {
      this.popupVisible = e
    }
  }
}
</script>

