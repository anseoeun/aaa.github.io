<template>
  <div>
    <!-- <h1>TEST</h1>
    <div>
      <label> 입력폼 테스트 </label>
    </div> -->

  </div>
</template>

<script>
export default {
  data() {
    return {
    }
  },
}
</script>
