<template>
  <div>
    <h1>Table Caption</h1>
    <div class="table-area" style="padding: 20px;">
      <table style="border: 1px solid #aaa;">
        <colgroup>
          <col style="width: 20%;" />
          <col style="width: auto;" />
        </colgroup>
        <thead>
          <tr>
            <th>개발자</th>
            <th>담당영역</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>kwlee</td>
            <td>interaction</td>
          </tr>
          <tr>
            <td>sean</td>
            <td>vue components, vue directives</td>
          </tr>
          <tr>
            <td>hmmoon</td>
            <td>vue components, vue directives</td>
          </tr>
          <tr>
            <td>yskim</td>
            <td>vue components, vue directives</td>
          </tr>
        </tbody>
      </table>
    </div>
    <div class="table-area" style="padding: 20px;">
      <table style="border: 1px solid #aaa;">
        <colgroup>
          <col style="width: 20%;" />
          <col style="width: auto;" />
        </colgroup>
        <thead>
          <tr>
            <th>modules</th>
            <th>version</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>node</td>
            <td>14.15.4</td>
          </tr>
          <tr>
            <td>npm</td>
            <td>6.14.10</td>
          </tr>
          <tr>
            <td>yarn</td>
            <td>1.22.5</td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</template>

<script>
export default {
  name: 'TableCaption',
  components: {
  },
  mounted() {
    this.setCaption()
  },
}
</script>
