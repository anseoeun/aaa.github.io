<template>
  <div>
    <h1>Auto ID</h1>
    <div class="label-input">
      <label>아이디</label>
      <v-input />
    </div>
    <div class="label-input">
      <label>패스워드</label>
      <v-input />
    </div>
    <div class="label-input">
      <label>입력폼 테스트</label>
      <v-input />
    </div>
  </div>
</template>

<script>
import VInput from '~/components/element/VInput'
export default {
  name: 'AutoId',
  components: {
    VInput
  },
  mounted() {
    this.setLabel((idg) => {
      // console.dir(idg) // 자동 생성된 ID 배열
    })
  },
}
</script>
