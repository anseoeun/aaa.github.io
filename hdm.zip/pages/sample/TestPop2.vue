<template>

  <v-popup
    :visible="visible"
    @close="
      $emit('close')
      popVisible = false
    "
  >
    <template slot="header">
      <div class="title">타이틀2</div>
      <p class="header-description">타이틀설명222222222222222222</p>
    </template>
    <template slot="body">팝업내용2222222222222</template>
  </v-popup>
</template>

<script>
import { VPopup } from '~/components/element'
export default {
  components: {
    VPopup
  },
  props: {
    visible: {
      type: Boolean,
      default: false
    },
    data: {
      type: Object,
      default: () => {}
    }
  },

}
</script>

