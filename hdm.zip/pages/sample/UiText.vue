<template>
  <div style="width: 1000px; margin: 0 auto; padding: 30px 0">
    <v-pageheader
      :top-breadcrumb="topBreadcrumb"
      page-title="AX 사전계약"
      page-infotext="온라인에서 진행하는 ooooooo의 사전 계약을 시작합니다."
    >
      <div class="term">사전계약기간 : 2021.01.31 ~ 2021. 03.30</div>
    </v-pageheader>

    <h2>텍스트</h2>
    <br />
    <p class="bullet">면세구분 선택에 따라 개별소비세 과세/면세가 계산되어 차량 총 견적 금액에 적용됩니다.</p>
    <br />
    <ul class="bullet-list">
      <li>등록비는 견적금액에 포함되지 않습니다.</li>
      <li>공채 할인금액은 지자체별 할인율이 매일 변동됨에 따라 실제와 다소 차이가 있을 수 있습니다.</li>
      <li>차량번호판과 등록대행수수료는 지역별로 차이가 있으므로 단순 참고만 하시기 바랍니다.</li>
    </ul>
    <br />
    <ul class="bullet-star-list">
      <li>모델, 색상, 옵션 등 차량 정보를 변경할 수 있습니다. [차량정보 변경] 버튼을 클릭하고 나만의 캐스퍼 만들기로 이동하여 다른 사양으로 변경해 보세요</li>
      <li>차량정보 변경은 결제 전까지 언제든 가능합니다. 단, 변경하시는 품목에 따라 차량 가격이 달라질 수 있습니다.</li>
    </ul>
    <br />
    <p class="bullet-star">아래 사항을 반드시 확인해 주세요.</p>
    <br />
    <div class="content-box">
      <strong class="title">유의사항</strong>
      <ul class="bullet-list">
        <li>본 견적서는 고객님의 차량 구입(청약) 의사결정에 도움을 드리고자 작성된것으로, 계약을 원하실 경우 계약하기를 선택 후 계약을 완료하셔야 합니다.</li>
        <li>실제 계약 내용은 고객께서 청약하실 시점의 판매조건이나 캐피탈사의 대출 조건에 따라 본 견적 내용과 달라질 수 있습니다.</li>
        <li>세이브오토는 당사와 제휴사와의 별도 약정에 따라 차량대금의 일부를 선 지급해드리는 상품으로 향후 고객께서 포인트를 적립하여 상환하여야 하며, 별도 신청서 상의 소정 요건을 충족 시키지 못할 경우 미상환액을 현금으로 상환하셔야 합니다.</li>
        <li>표시된 예상출고일은 견적 시점에서 계산된 것이므로 계약시점에 따라 달라질 수 있으며, 당사 사정에 따라 변경될 수 있습니다.</li>
        <li>탁송료 및 공제할인율은 출고지, 등록일에 따라서 변경될 수 있습니다. 등록대행 수수료는 당사에 등록을 의뢰하실 경우 발생되는 항목이며 의뢰지역, 의뢰방법에 따라 달라질 수 있습니다.</li>
      </ul>
    </div>
    <div class="list-null">
      <i class="icon-doc-none"></i>
      <p>구매 내역이 없습니다.</p>
    </div>

  </div>
</template>
<script>
export default {
  data(){
    return{
      topBreadcrumb: [
        { linkName: '계약하기', link: '/' },
        { linkName: '결제하기', link: '/' },
      ],
    }
  }
}
</script>


<style lang="scss">
@import '~/assets/style/shop.scss';
h2{font-size:20px;font-weight: 500;margin-top:20px;}
</style>
