<template>
  <div class="making-container">
    <div class="car-visual">
      <div class="visual">
        <!-- 2021-04-02 (ver1.1) 코딩변경 -->
        <transition name="vimg"><div v-if="visualStatus == 'init'" class="visual-img" :style="`background-image:url('${visualBg.init}')`"></div></transition>
        <transition name="vimg"><div v-if="visualStatus == 'outcolor'" class="visual-img" :style="`background-image:url('${visualBg.out}')`"></div></transition>
        <transition name="vimg"><div v-if="visualStatus == 'incolor'" class="visual-img" :style="`background-image:url('${visualBg.in}')`"></div></transition>
        <transition name="vimg"><div v-if="configurationShow" class="configuration"></div></transition>
      </div>

      <div class="visual-menu">
        <v-btn
          type="button"
          class="btn-out"
          :class="{ on: visualStatus === 'outcolor' }"
          @click="changeBg('outcolor')"
        ></v-btn>
        <v-btn
          type="button"
          class="btn-in"
          :class="{ on: visualStatus === 'incolor' }"
          @click="changeBg('incolor')"
        ></v-btn>
        <span class="btn-spred">
          <v-btn
            type="button"
            :class="[`${spredBtn}`, { on: spredBtnIs }, { active: configurationShow }]"
            @click="spredBtnIs = !spredBtnIs"
          ></v-btn>
          <span v-show="spredBtnIs" class="spred">
            <v-btn
              v-if="spredBtn !== 'btn-day'"
              type="button"
              class="btn-day"
              @click="changeConfiguration('btn-day')"
            ></v-btn>
            <v-btn
              v-if="spredBtn !== 'btn-night'"
              type="button"
              class="btn-night"
              @click="changeConfiguration('btn-night')"
            ></v-btn>
            <v-btn
              v-if="spredBtn !== 'btn-outdoor'"
              type="button"
              class="btn-outdoor"
              @click="changeConfiguration('btn-outdoor')"
            ></v-btn>
            <v-btn
              v-if="spredBtn !== 'btn-city'"
              type="button"
              class="btn-city"
              @click="changeConfiguration('btn-city')"
            ></v-btn>
          </span>
        </span>
      </div>
    </div>
    <div class="opt-btn" :style="`right:${optWidth}px`">
      <v-btn v-if="optionShow" class="btn-opt-close" @click="hideOption"><span class="offscreen">닫기</span></v-btn>
      <v-btn v-else class="btn-opt-open" @click="showOption"><span class="offscreen">열기</span></v-btn>
    </div>
    <div v-show="optionShow" ref="caropt" class="car-option" :class="[{ expend: isExpend }, {summary: summaryShow}, {end: scrollBottom}]" @scroll="scroll">
      <div ref="caroptin" class="inner">
        <v-btn class="recommend" @click="popupVisible.recommendCombination = true">
          <p class="txt">
            잠깐! 선택이 어려우신가요? <br />
            나만의 캐스퍼를 추천해 드립니다.
          </p>
          <span class="img"></span>
          <!-- <v-img :src="carImg.src" :alt="carImg.alt"></v-img> -->
        </v-btn>
        <!-- 바디타입
          2021-04-02 (ver1.1) 삭제
        <div class="option-box">
          <div class="box-header">
            <b class="tit">바디타입 <v-btn type="icon" icon-class="icon-info"></v-btn></b>
          </div>
          <div class="box-body">
            <v-radio v-model="bodyTypeVal" class="radio-blue-round-button btn-num2" type="button" :data="bodyType" />
          </div>
        </div>
         -->
        <!-- 트림 -->
        <trim
          @trimComparePop="popupVisible.compareSelect = true"
          @detailPop="popupVisible.detail = true"
         />
        <!-- 외장색상 -->
        <exterior-detail :pos.sync="position.outColorTop"
          @trimChangeInfoPop="popupVisible.trimChangeInfo = true"
          @optionChangeInfoPop="popupVisible.optionChangeInfo = true"
          @recommendColorPop="popupVisible.recommendColor = true"
         />
        <!-- 내장색상 -->
        <interior-detail :pos.sync="position.inColorTop" />
         <!-- 옵션 -->
        <option-detail :pos.sync="position.optionTop"
          @expend="optExpend"
          @contract="optContract"
          @bagicPop="popupVisible.specGuide = true"
          @packagePop="popupVisible.packageGuide = true"
          @recommendOptionPop="popupVisible.recommendOption = true"
          @partsAddInfoPop="popupVisible.partsAddInfo = true"
          @partsDellInfoPop="popupVisible.partsDellInfo = true"
         />
        <!-- 요약 -->
        <opt-summary v-if="summaryShow" />
        <!-- 2021-04-02 (ver1.1) fixed-price-wrap 코딩수정 -->
        <div class="fixed-price-wrap">
          <v-btn type="link" href="javascript:void(0);" class="fixed-price" :style="fixSubStyle" @click="summaryToggle">
            <div class="f-row total">
              <div class="left"><b>총 차량 가격</b></div>
              <div class="right">
                <span class="account"> <b>13,890,000</b>원 </span>
              </div>
            </div>
            <div class="f-row installment">
              <div class="left"><b>초장기 할부(60개월) 시</b></div>
              <div class="right">
                <span class="account">월 <b>208,000</b>원 </span>
              </div>
            </div>
          </v-btn>
        </div>
        <div class="next-step-wrap">
          <v-btn type="nlink" to="/" class="next-step" :style="fixBtnStyle">
              <span>2단계. 견적내기</span>
          </v-btn>
        </div>
      </div>
    </div>
    <!-- 팝업 -->
    <!-- <popup :visible.sync="popupVisible" /> -->
  </div>
</template>

<script>
import Trim from './Trim'
import ExteriorDetail from './ExteriorDetail'
import { VRadio, VBtn} from '~/components/element'
import InteriorDetail from './InteriorDetail'
import OptionDetail from './OptionDetail'
import OptSummary from '~/components/page/vehicles/making/popup/Summary'
// import Popup from '~/components/page/vehicles/making/popup'
export default {
  head() {
    return {
      title: '탐색 > 내 차 만들기',
      bodyAttrs: {
        style: 'overflow-y:hidden'
      }
    }
  },
  layout: 'casper',
  components: {
    Trim,
    ExteriorDetail,
    VRadio,
    VBtn,
    InteriorDetail,
    OptionDetail,
    OptSummary,
    // Popup
  },
  data() {
    return {
      headerH: 60,
      isExpend: false,
      optionShow: true,
      optWidth: 0,
      configurationShow: false,
      summaryShow: false,
      visualStatus: '',
      visualBg: {
        init:'https://cdn.pixabay.com/photo/2021/01/11/08/53/sky-5907605_960_720.jpg',
        out:'https://cdn.pixabay.com/photo/2015/03/26/09/47/sky-690293_960_720.jpg',
        in: 'https://cdn.pixabay.com/photo/2021/03/04/15/29/river-6068374_960_720.jpg',
      },
      carImg: {
        src: require('~/assets/images/temp/temp-payment-car-model.png'),
        alt: 'AX 스마트스트림 가솔린 1.1 터보 프리미엄 밀레니얼 A/T'
      },
      bodyTypeVal: '',
      bodyType: [
        { value: 'suv', label: 'SUV' },
        { value: 'suvban', label: 'SUV 밴' }
      ],
      scrollSize: '',
      scrollIs: false,
      scrollBottom: false,
      fixSubStyle: '',
      fixBtnStyle:'',
      //spredBtn
      spredBtnIs: false,
      spredBtn: 'btn-day',
      position: {
        outColorTop: 0,
        inColorTop: 0,
        optionTop: {
          option1Top: 0,
          option2Top: 0,
          option3Top: 0,
        }
      },
      //popup
      popupVisible: {
        friendRecommend: false,
        packageGuide: false,
        detail: false,
        specGuide: false,
        compareSelect: false,
        trimChangeInfo: false,
        optionChangeInfo: false,
        partsAddInfo: false,
        partsDellInfo: false,
        recommendColor: false,
        recommendOption: false,
        recommendCombination: false,
      }
    }
  },
  computed: {

  },
  mounted() {
    this.popupVisible.friendRecommend = true //지인추천할인안내
    this.scrollSize = this.$refs.caropt.offsetWidth - this.$refs.caropt.clientWidth
    this.scrollCheck()
    this.setStyle()
    this.$nextTick(() => {
      this.getOptW()
    })
  },
methods: {
    setStyle() {
      let w = this.$refs.caropt.clientWidth
      let summaryShow = () => {
        this.fixSubStyle = 'position:fixed;bottom:60px;width:'+w+'px;'
        this.fixBtnStyle = 'position:fixed;bottom:0;width:'+w+'px;'
      }
      if (this.scrollIs && this.scrollBottom) { //bottom
        if(this.summaryShow){
         summaryShow()
        }else{
          this.fixSubStyle = ''
          this.fixBtnStyle = ''
        }
      } else if (this.scrollIs && this.scrollBottom == false) {
        if(this.summaryShow){
         summaryShow()
        }else{
          this.fixSubStyle = 'position:fixed;bottom:0;right:' + this.scrollSize + ';width:' + (this.$refs.caropt.clientWidth - this.scrollSize) + 'px;'
          this.fixBtnStyle = ''
        }
      } else {
         if(this.summaryShow){
          summaryShow()
        }else{
          this.fixSubStyle = 'position:fixed;bottom:0;right:0;width:' + this.$refs.caropt.offsetWidth + 'px;'
          this.fixBtnStyle = ''
        }
      }
    },
    scrollCheck() {
      if (this.$refs.caropt.offsetWidth == this.$refs.caropt.clientWidth) this.scrollIs = false
      else this.scrollIs = true
    },
    scroll() {
      let scrollTop = Math.ceil(this.$refs.caropt.scrollTop)
      let outColorTop = this.position.outColorTop
      let inColorTop = this.position.inColorTop
      if (scrollTop + this.$refs.caropt.clientHeight >= this.$refs.caroptin.clientHeight - this.headerH) {
        this.scrollBottom = true
        this.setStyle()
      } else {
        this.scrollBottom = false
        this.setStyle()
      }

      if(this.isExpend) return
      if (scrollTop < outColorTop) {
        this.visualStatus = 'init'
      } else if (scrollTop >= outColorTop && this.$refs.caropt.scrollTop < inColorTop) {
        this.visualStatus = 'outcolor'
      } else if (scrollTop >= inColorTop) {
        this.visualStatus = 'incolor'
      }
    },
    changeBg(scroll) {
      this.configurationShow = false

      if (scroll === 'outcolor') {
        this.$refs.caropt.scrollTop = this.position.outColorTop
        this.visualStatus = 'outcolor'
      } else if (scroll === 'incolor') {
        this.$refs.caropt.scrollTop = this.position.inColorTop
        this.visualStatus = 'incolor'
      }
    },
    changeConfiguration(btn) {
      this.configurationShow = true
      this.visualShow = false
      this.spredBtnIs = false
      this.spredBtn = btn
      this.visualStatus = false
    },
    optExpend(pxpended, type, fnc) {
      this.isExpend = true
      setTimeout(()=> {
        fnc()
        if(type === 'option1') this.$refs.caropt.scrollTop = this.position.optionTop.option1Top
        else if(type === 'option2') this.$refs.caropt.scrollTop = this.position.optionTop.option2Top
        else if(type === 'option3') this.$refs.caropt.scrollTop = this.position.optionTop.option3Top
              this.getOptW()
      }, 100)
    },
    optContract(pxpended, type, fnc) {
      this.isExpend = false
      setTimeout(()=> {
        fnc()
        if(type === 'option1') this.$refs.caropt.scrollTop = this.position.optionTop.option1Top
        else if(type === 'option2') this.$refs.caropt.scrollTop = this.position.optionTop.option2Top
        else if(type === 'option3') this.$refs.caropt.scrollTop = this.position.optionTop.option3Top
        this.getOptW()
      }, 100)
    },
    getOptW(){
      this.optWidth = this.$refs.caropt.clientWidth + 80
    },
    showOption() {
      this.optionShow = true
      setTimeout(()=> {
        this.getOptW()
      }, 100)
    },
    hideOption() {
      this.optionShow = false
      setTimeout(()=> {
        this.getOptW()
        //init
        this.$refs.caropt.scrollTop = 0
        this.isExpend = false
      }, 100)
    },
    summaryToggle() {
      this.summaryShow = !this.summaryShow
      if(this.summaryShow == false) {
        // this.scrollBottom = false
      }
      this.setStyle()
    }
  }
}
</script>