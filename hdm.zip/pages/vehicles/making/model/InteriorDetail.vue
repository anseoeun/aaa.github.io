<template>
<!-- 내장색상 -->
<div ref="incolor" class="option-box">
    <div class="box-header">
        <b class="tit">내장색상</b>
        <div class="right">
        </div>
    </div>
    <div class="box-body">
        <div class="optprice">
          <div class="left">
              <span class="name">블랙(NNB) + 칼라 포인트</span>
          </div>
          <div class="right"><span class="price"><b>+ 300,000</b> 원</span></div>
        </div>
        <v-radio v-model="inColorVal" :custom-label="true" :data="inColorList" class="in-color-List">
        <template slot-scope="props">
            <v-popover trigger="hover" :placement="props.item.index % 2 == 0 ? 'top-end' : 'top-start'" style-type="popover-round">
            <p>
                {{ props.item.exp }}
            </p>
            <i slot="reference" class="in-color" :style="`background-image:url(${props.item.img})`"></i>
            </v-popover>
        </template>
        </v-radio>
    </div>
</div>
</template>

<script>
export default {
  components: {

  },
  props:{
    pos: {
      type: Number,
      default: 0,
    },
    headerHeight: {
      type: Number,
      default: 0,
    },
  },
  data() {
    return {
      inColorVal: '',
      inColorList: [
        {index:1, value: 'color1', exp:'회색회색회색회색', price: '0', img: require('~/assets/images/temp/temp-review-car.png')},
        {index:2, value: 'color2', exp: '블랙 모노', price: '50,000', img: require('~/assets/images/temp/temp-review-car.png')},
        {index:3, value: 'color3', exp: '톰보이 카키 매트', price: '10,000', img: require('~/assets/images/temp/temp-review-car.png')},
      ],
    }
  },
  computed: {

  },
  mounted(){
    this.$nextTick(() => {
        let rectCollection = this.$refs.incolor.offsetTop
        this.$emit('update:pos', rectCollection )
    })
  },
  methods: {

  }

}
</script>
