<template>
  <div class="content estimate">
    <v-pageheader page-title="견적서" />
    <estimate-share />
  </div>
</template>

<script>
import VPageheader from '~/components/element/VPageheader'
import EstimateShare from '~/components/page/estimation/EstimateShare'
export default {
  head() {
    return {
      title: '견적 > 견적서',
    }
  },
  name: 'Estimation',
  components: {
    VPageheader,
    EstimateShare,
  },
  data() {
    return {
    }
  },
}
</script>