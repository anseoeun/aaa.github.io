<template>
  <div class="content estimate estimate-expiration">
    <i class="icon-expiration"></i>
    <p class="text">이 견적 링크는 유효기간이 만료되었습니다.<br />내 차 만들기를 통해 다시 견적을 확인해주세요.</p>
    <div class="btn-wrap">
      <v-btn class="btn lg blue line r" type="nlink" to="/">홈으로</v-btn>
      <v-btn class="btn lg blue r" type="nlink" to="/">내 차 만들기</v-btn>
    </div>
  </div>
</template>

<script>
export default {
  head() {
    return {
      title: '견적 > 견적내기',
    }
  },
  name:'Estimation',
}
</script>