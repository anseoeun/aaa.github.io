<template>
  <!-- 공유견적보기와 동일 (헤더,풋터제거) -->
  <share />
</template>

<script>
import share from '~/pages/estimation/share/index'
export default {
  layout: 'download',
  head() {
    return {
      title: '견적 > 견적서 다운로드',
    }
  },
  name: 'Estimation',
  components: {
    share,
  },
  data() {
    return {
    }
  }
}
</script>