<template>
  <div class="content support support-qna">
    <v-pageheader
      :top-breadcrumb="topBreadcrumb"
      page-title="1:1 문의"
      page-infotext="문의사항에 빠르고 친절하게 답변해 드리겠습니다."
    />

    <div class="content-inner">
      <div class="top-noti-info">
        <div class="right">
          <v-btn class="note-btn btn-more" type="nlink">1:1 문의내역</v-btn>
        </div>
      </div>

      <div class="qna-complete">
        <i class="icon-doc-check"></i>
        <div class="title">1:1 문의 접수 완료</div>
        <div class="matching-list">
          <ul>
            <li>
              <div class="tit"><span class="dot">문의제목</span></div>
              <div class="txt auto">직원DC를 받고 지점에서 차량을 구입했습니다. 해당 차량에 대해 문의할 사항이 있는데 임직원 차량<br />구매 지원센터로 전화 드려도 되나요?</div>
            </li>
            <li>
              <div class="tit"><span class="dot">답변 이메일</span></div>
              <div class="txt auto"><a href="mailto:asdmasd@Hyundai.com" class="c-blue">asdmasd@Hyundai.com</a></div>
            </li>
          </ul>
        </div>
      </div>

      <div class="btn-box">
        <v-btn type="button" class="btn lg blue r">홈으로</v-btn>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      topBreadcrumb: [{ linkName: ' 고객지원', link: '/' }, { linkName: '1:1 문의', link: '/' }],
    }
  },
}
</script>