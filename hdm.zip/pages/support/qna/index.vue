<template>
  <div class="content support support-qna">
    <v-pageheader
      :top-breadcrumb="topBreadcrumb"
      page-title="1:1 문의"
      page-infotext="문의사항에 빠르고 친절하게 답변해 드리겠습니다."
    />

    <div class="content-inner">
      <div class="top-noti-info">
        <div class="left"><div class="noti-txt">문의 사항을 상세히 작성해 주세요. *는 필수항목입니다.</div></div>
        <div class="right">
          <v-btn class="note-btn btn-more" type="nlink">1:1 문의내역 ( 답변2건 / 문의2건 )</v-btn>
        </div>
      </div>
      <el-form ref="askForm" :model="askForm" :rules="rules" label-position="top">
        <div class="form-grid-list">
          <ul>
            <li>
              <div class="form-label">카테고리 선택 *</div>
              <div class="form-group inbl-wrap">
                <el-form-item prop="bigOPtionValue">
                  <v-select
                    v-model="askForm.bigOPtionValue"
                    :data="askForm.bigOPtion"
                    placeholder="Select"
                  />
                </el-form-item>
                <el-form-item prop="smallOPtionValue">
                  <v-select
                    v-model="askForm.smallOPtionValue"
                    :data="askForm.smallOPtion"
                    placeholder="Select"
                  />
                </el-form-item>
                &nbsp;&nbsp;
                <v-btn class="note-btn btn-more" type="nlink">내비게이션/빌트인 캠 업데이트 문의</v-btn>
              </div>
            </li>
            <li class="label-input">
              <div class="form-label"><label>제목</label> *</div>
              <div class="form-group">
                <el-form-item label="" required prop="titleName">
                  <v-input v-model="askForm.titleName" />
                </el-form-item>
              </div>
            </li>
            <li class="label-input">
              <div class="form-label"><label>상담내용</label> *
                <div class="txt-count">
                  ( <span class="txt-blue">{{ askForm.textCount }}</span>
                  자/2000자)
                </div>
              </div>
              <div class="form-group">
                <el-form-item label="" prop="counsel" required>
                  <v-input v-model="askForm.counsel" type="textarea" :rows="13" placeholder="상담내용을 입력하여 주세요(최대 2,000자)" maxlength="2000" @input="checkText" />
                </el-form-item>
              </div>
            </li>
            <li class="label-input">
              <div class="form-label"><label>파일첨부</label></div>
              <div class="form-group">
                 <div class="file-upload-wrap">
                   <div class="file-upload">
                      <div class="file-input">
                        <input ref="fileInput" type="file" class="offscreen" @change="changeFile" />
                        <v-input v-model="fileVal" class="file-value" />
                        <v-btn class="btn-file-delete" type="button" @click="fileDelete"><span>파일삭제</span></v-btn>
                      </div>
                      <v-btn class="file-btn btn-more" type="button" @click="fileOpen">파일찾기</v-btn>
                    </div>
                    <ul class="bullet-list">
                      <li>이미지 형식의 jpg(jpeg), png 나 문서 형식의 doc(docx), ppt(pptx), hwp, pdf만 첨부 가능합니다.</li>
                      <li>첨부파일은 각각 7MB를 초과할 수 없으며, 최대 1개까지 가능합니다.</li>
                    </ul>
                 </div>
              </div>
            </li>
            <li class="label-input">
              <div class="form-label"><label>답변 이메일</label> * </div>
              <div class="form-group">
                <el-form-item label="" required prop="answerEmail">
                    <v-input v-model="askForm.answerEmail" style="width:410px;" />
                </el-form-item>
              </div>
            </li>
            <li class="label-input">
              <div class="form-label"><label>답변 알림</label> *</div>
              <div class="form-group">
                <el-form-item label="" required prop="answerNumber" class="inbl-wrap">
                    <v-input v-model="askForm.answerNumber" style="width:200px;" />
                    &nbsp;&nbsp;
                    <v-checkbox v-model="askForm.checked" :data="askForm.optsList" />
                </el-form-item>
                <ul class="bullet-list">
                  <li>고객님의 문의 관련 정보는 접수일 기준 1년간 보관되며, 기간 만료 후 자동 폐기됩니다.</li>
                  <li>1:1 문의를 통한 전화상담 요청은 불가하오니 이점 양해하여 주시기 바랍니다.</li>
                  <li>1:1 문의 답변은 이메일 또는 <v-btn type="nlink" class="c-blue">마이페이지 > 나의 1:1 문의내역</v-btn>에서 확인하실 수 있습니다.</li>
                </ul>
              </div>
            </li>
          </ul>
        </div>
      </el-form>
      <div class="btn-box">
        <v-btn type="button" class="btn lg gray r">취소</v-btn>
        <v-btn type="button" class="btn lg blue r">등록</v-btn>
      </div>
    </div>

  </div>
</template>

<script>
import { VInput, VBtn, VCheckbox, VPageheader } from '~/components/element'
export default {
  head() {
    return {
      title: '고객지원 > 1:1 문의',
    }
  },
  name:'Qna',
  components: {
    VInput,
    VBtn,
    VCheckbox,
    VPageheader,
  },

  data() {
    return {
      topBreadcrumb: [{ linkName: ' 고객지원', link: '/' }, { linkName: '1:1 문의', link: '/' }],
      askForm: {
        textCount: 0,
        bigOPtionValue: '',
        bigOPtion: [
          {
            value: '',
            label: '대분류를 선택해 주세요'
          },
          {
            value: 'Option1',
            label: '차량구매'
          },
          {
            value: 'Option2',
            label: '블루멤버스'
          },
          {
            value: 'Option3',
            label: '임직원 구매 제도'
          }
        ],
        smallOPtionValue: '',
        smallOPtion: [
          {
            value: '',
            label: '소분류를 선택해 주세요'
          },
          {
            value: 'Option1',
            label: '소분류1'
          },
          {
            value: 'Option2',
            label: '소분류2'
          },
          {
            value: 'Option3',
            label: '소분류3'
          },
          {
            value: 'Option4',
            label: '소분류4'
          }
        ],
        titleName: '',
        checked: ['check1'],
        answerNumber:'',
        answerEmail:'',
        optsList: [{ value: 'check1', label: 'SMS 알림 받기' }]
      },
      fileVal:'',
    }
  },
  computed: {
    rules() {
      return {
        bigOPtionValue: [{ required: true, message: '대분류를 선택해 주세요.', trigger: 'change' }],
        smallOPtionValue: [{ required: true, message: '중분류를 선택해 주세요.', trigger: 'change' }],
        titleName: [
          {
            required: true,
            message: '제목을 입력해 주세요.',
            trigger: ['blur', 'change']
          }
        ],
        counsel: [
          {
            required: true,
            message: '내용을 입력해 주세요.',
            trigger: ['blur', 'change']
          }
        ],
        answerEmail: [
          {
            required: true,
            message: '이메일을 입력해주세요.',
            trigger: ['blur', 'change']
          }
        ],
        answerNumber: [
          {
            required: true,
            message: '휴대폰번호을 입력해주세요.',
            trigger: ['blur', 'change']
          }
        ],
      }
    }
  },
  mounted() {
    this.setLabel((idg) => {
      //console.dir(idg) // 자동 생성된 ID 배열
    })
  },
  methods: {
    changeFile(e) {
      var files = e.target.files || e.dataTransfer.files
      this.fileVal = files[0].name
    },
    fileDelete(){
      this.$refs.fileInput.value = ''
      this.fileVal = ''
    },
    fileOpen(){
      this.$refs.fileInput.click()
    },
    checkText(){
      this.askForm.textCount = this.askForm.counsel.length
    }
  }
}
</script>
