<template>
  <div class="faq-search-result">
      <div class="matching-box content-inner">
        <div class="box-wrap">
          <div class="box-tit">
              검색결과
          </div>
          <div class="box-desc">
            <div class="result-txt">“<span class="key">면세</span>” 에 대해 총 <span class="total c-blue">5</span>건이 검색되었습니다.</div>
            <faq-list :faq-list="resultList" class="toggle-list" />
          </div>
        </div>
      </div>
  </div>
</template>

<script>
import FaqList from '~/components/page/support/faq/FaqList'
export default {
  components: {
    FaqList,
  },
  data() {
    return {
      resultList:[
        {
          seq: 1,
          category: `[차량구매 > 전체]`,
          title: `장애인 <span class="key">면세</span> 공동명의로 구입하려고 하는데 꼭 세대합가를 해야 하나요?`,
          content: `<div class="faq-cont">▶장애인 차량 구입시에는 ①개별 소비세, ②지방세, ③공채 항목시에 <span class="key">면세</span>  혜택이 있습니다.  서울시 기준으로는 심한장애인, 국가유공상이자(1~7급), 고엽제 후유증(경도~고도), 광주민주화운동 부상자(1급~14급)은 장애인 조건으로 차량 구입시 심한 장애인, 국가유공상이자(1~7급), 고엽제 후유증(경도~고도), 광주</p>
          </div>`,
        },
        {
          seq: 2,
          category: `[차량구매 > 계약]`,
          title: `장애인 <span class="key">면세</span> 공동명의로 구입하려고 하는데 꼭 세대합가를 해야 하나요?`,
          content: `<div class="faq-cont">▶장애인 차량 구입시에는 ①개별 소비세, ②지방세, ③공채 항목시에 <span class="key">면세</span>  혜택이 있습니다.  서울시 기준으로는 심한장애인, 국가유공상이자(1~7급), 고엽제 후유증(경도~고도), 광주민주화운동 부상자(1급~14급)은 장애인 조건으로 차량 구입시 심한 장애인, 국가유공상이자(1~7급), 고엽제 후유증(경도~고도), 광주</p>
          </div>`,
        },
      ]
    }
  },
}
</script>
