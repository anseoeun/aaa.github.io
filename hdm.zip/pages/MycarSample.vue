<template>
  <div>내 차 만들기 샘플</div>
</template>

<script>
export default {
  layout: 'mycar',
}
</script>
