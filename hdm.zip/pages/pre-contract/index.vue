<template>
  <div class="content precontract precontract-wrap">
    <div v-if="mainIndex" class="precontract-visual">
      <contract-visual @click="changeIndex"></contract-visual>
    </div>
    <div v-else class="precontract-contents">
      <v-pageheader
        page-title="AX 사전계약"
        page-infotext="온라인에서 진행하는 ooooooo의 사전 계약을 시작합니다."
      >
        <div class="term">사전계약기간 : {{ precontractTerm }}</div>
      </v-pageheader>
      <!-- <contranctVisual :is-index="true" /> -->
      <div class="precontract-option">
        <div class="car-visual">
            <v-img :src="carImg" alt="자동차 이미지"></v-img>
            <p class="caption">* 홈페이지 상에 사용된 이미지는 실제 적용 사양과 상이할 수 있습니다.</p>
        </div>
        <apply-form></apply-form>
      </div>
    </div>
    <popup :visible.sync="popupVisible" @visibleSync="popupSync" />
  </div>
</template>

<script>
import ApplyForm from '~/components/page/pre-contract/ApplyForm'
import ContractVisual from '~/components/page/pre-contract/ContractVisual'
import Popup from '~/pages/mypage/purchase/contract-detail/'

export default {
  head() {
    return {
      title: '사전계약 > 소개',
    }
  },
  name:'PreContract',
  components: {
    ContractVisual,
    ApplyForm,
    Popup
  },
  data(){
    return{
      precontractTerm:'2021.01.31 ~ 2021. 03.30',
      mainIndex:true,
      carImg: require('~/assets/images/temp/temp-precontact-car-visual.png'),
      popupVisible: {
        precontrctPop: false,
      }
    }
  },
  mounted() {
    this.popupVisible.precontrctPop = true
  },
  methods:{
    changeIndex(value){
      this.mainIndex = value
    },
    popupSync(e) {
      this.popupVisible = e
    }
  }
}
</script>
