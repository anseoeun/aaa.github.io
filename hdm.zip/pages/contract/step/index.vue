<template>
  <section class="container">
    <nuxt-child :key="$route.params.step" :step="$route.params.step" />
  </section>
</template>
<script>
export default {
  data() {
    return {}
  }
}
</script>