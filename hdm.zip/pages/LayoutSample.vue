<template>
  <div style="text-align: center; padding-top: 50px;">
    <!-- pagination type1 -->
    <v-pagination />

    <br />

    <!-- pagination type2 -->
    <v-page-more />
  </div>
</template>

<script>
import VPageMore from '~/components/element/VPageMore'
import VPagination from '~/components/element/VPagination'
export default {
  components: {
    VPageMore,
    VPagination,
  }
}
</script>
