<template>
  <div class="content mypage mypage-review">
    <v-pageheader
      :top-breadcrumb="topBreadcrumb"
      page-title="구매 후기 작성"
      :page-infotext="`${name} 님, 현대 자동차 AX를 구매해 주셔서 감사합니다.<br>고객님이 작성해주신 구매후기는 다른 분들이 차량을 구매하는 데 큰도움이 됩니다.`"
    />

    <mypage-lnb />

    <div class="mypage-wrap">

    </div>
  </div>
</template>

<script>
import MypageLnb from '~/components/page/mypage/index/MypageLnb'
// import { VBtn } from '~/components/element'
export default {
  components: {
    MypageLnb,
    // VBtn,
  },
  data() {
    return {
      topBreadcrumb: [
        { linkName: '마이페이지', link: '/' },
        { linkName: '나의 활동내역', link: '/' },
        { linkName: '구매 후기 내역', link: '/' },
      ],
      name: '김현대',

    }
  },
  methods:{

  }
}
</script>
