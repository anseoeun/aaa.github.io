<template>
  <v-popup
    :visible="visible"
    @close="$emit('close')"
  >
    <template slot="body">
      <div class="content mypage comparision">
        <section class="comparision-model">
          <div class="model-wrap">
            <div class="title">
              <h1>모델</h1>
              <p>드래그&#38;드롭으로<br />차량 순서를 바꿔보세요!</p>
            </div>
            <div class="model-list">
              <draggable tag="ul" v-bind="dragOptions" @start="dragStart" @end="dragEnd">
                <li v-for="(item, index) in selectedData" :key="index" :data-id="index">
                  <div class="desc">
                    <div class="car-desc small-hide">
                      <div class="car-img">
                        <v-img :src="item.carImg" :alt="item.name"></v-img>
                      </div>
                      <ul class="flag-list">
                        <li v-for="(flag, flagIdx) in item.flagData" :key="flagIdx">{{ flag.flagName }}</li>
                      </ul>
                    </div>
                    <strong class="name">{{ item.name }}</strong>
                    <div class="total-price">
                      <div v-if="parseInt(selectedData[0].price) !== parseInt(item.price)" class="margin">
                        <span v-if="parseInt(selectedData[0].price) > parseInt(item.price)" class="down">{{ selectedData[0].price - item.price | comma }} 원</span>
                        <span v-if="parseInt(selectedData[0].price) < parseInt(item.price)" class="up">{{ item.price - selectedData[0].price | comma }} 원</span>
                      </div>
                      <div class="account">
                        <div class="tit">총 견적금액 </div>
                        <div class="price"><b>{{ item.price }}</b> <span class="unit">원</span></div>
                      </div>
                    </div>
                    <ul class="matching-list">
                      <li class="small-hide">
                        <div class="tit">차량가격</div>
                        <div class="txt auto">{{ item.carPrice }} 원</div>
                      </li>
                      <li class="small-hide">
                        <div class="tit">탁송료</div>
                        <div class="txt auto">{{ item.consignmentFee }} 원</div>
                      </li>
                      <li class="small-hide">
                        <div class="tit">할인/포인트</div>
                        <div class="txt auto">(-) {{ item.salePoint }} 원</div>
                      </li>
                    </ul>
                    <ul class="matching-list">
                      <li class="normal-hide">
                        <div class="tit">배기량</div>
                        <div class="txt auto">{{ item.displacement }} cc</div>
                      </li>
                      <li class="normal-hide">
                        <div class="tit">평균연비</div>
                        <div class="txt auto">{{ item.averageFuel }} km/ℓ</div>
                      </li>
                    </ul>
                    <v-btn class="btn-more normal-hide">변경하기</v-btn>
                    <v-btn class="btn white r md small-hide">계약하기</v-btn>
                  </div>
                </li>
              </draggable>
            </div>
          </div>
        </section>

        <vehicle-options />
        <take-over />
        <sale-point />
        <bluemembers-point />
        <payment />
        <tax-registration
          @popInfoAcquirement="popupVisible.infoAcquirement = true"
          @popInfoFund="popupVisible.infoFund = true"
        />
        <popup :visible.sync="popupVisible" @visibleSync="popupSync" />
      </div>
    </template>
  </v-popup>
</template>

<script>
import Draggable from 'vuedraggable'
import { mapGetters, mapMutations } from 'vuex'
import VehicleOptions from '~/components/page/mypage/comparison/VehicleOptions'
import TakeOver from '~/components/page/mypage/comparison/TakeOver'
import SalePoint from '~/components/page/mypage/comparison/SalePoint'
import BluemembersPoint from '~/components/page/mypage/comparison/BluemembersPoint'
import Payment from '~/components/page/mypage/comparison/Payment'
import TaxRegistration from '~/components/page/mypage/comparison/TaxRegistration'
import Popup from '~/components/page/payment/popup'

export default {
  head() {
    return {
      title: '마이페이지 > 나의 활동 > 견적 내역',
    }
  },
  name: 'Mypage',
  components: {
    Draggable,
    VehicleOptions,
    TakeOver,
    SalePoint,
    BluemembersPoint,
    Payment,
    TaxRegistration,
    Popup,
  },
  filters:{
    comma(val){
      return String(val).replace(/\B(?=(\d{3})+(?!\d))/g, ',')
    }
  },
  props: {
    visible: {
      type: Boolean,
      default: false
    },
  },
  data() {
    return {
      popupVisible: {
        infoAcquirement: false,
        infoFund: false,
      },
      isDragging: false,
      editable: true,
    }
  },
  computed: {
    ...mapGetters({
      selectedData: 'mypageModules/selectedData',
      // fixedSelectedData: 'mypageModules/fixedSelectedData',
    }),
    dragOptions() {
      return {
        animation: 100,
        disabled: !this.editable,
        ghostClass: 'ghost'
      }
    },
  },
  updated() {
    if (this.visible) {
      this.comparisionModelEvent()
    }
  },
  methods: {
    ...mapMutations({
      setOrderSelectedData: 'mypageModules/setOrderSelectedData',
    }),
    popupSync(e) {
      this.popupVisible = e
    },
    dragStart() {
      return this.isDragging = true
    },
    dragEnd(value) {
      // let dataIndex = this.selectedData[value.oldIndex]
      // this.selectedData.splice(value.oldIndex, 1)
      // this.selectedData.splice(value.newIndex, 0, dataIndex)
      console.dir(VehicleOptions)
      //this.setDataChange(value, vehicleData, dataIndex)
      return this.isDragging = false
    },
    setDataChange(value, myBoxData, dataIndex) {
      myBoxData.splice(value.oldIndex, 1)
      myBoxData.splice(value.newIndex, 0, dataIndex)
    },
  }
}
</script>
