<template>
  <div class="content mypage">
    <v-pageheader
      :top-breadcrumb="topBreadcrumb"
      page-title="견적 내역"
      page-infotext="저장된 견적내역을 확인하고 비교할 수 있습니다."
    />
    <mypage-lnb />
    <div class="mypage-wrap estimate-detail">
      <strong class="title">견적서</strong>
      <estimate-share />
    </div>
  </div>
</template>

<script>
import MypageLnb from '~/components/page/mypage/index/MypageLnb'
import EstimateShare from '~/components/page/estimation/EstimateShare'
export default {
  head() {
    return {
      title: '마이페이지 > 나의 활동 > 견적 내역',
    }
  },
  name: 'Mypage',
  components: {
    MypageLnb,
    EstimateShare,
  },
  data(){
    return{
      topBreadcrumb: [
        { linkName: '마이페이지', link: '/' },
        { linkName: '나의 활동', link: '/' },
        { linkName: '견적 내역', link: '/' },
      ],
    }
  }
}
</script>
