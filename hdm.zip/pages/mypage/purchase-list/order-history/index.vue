<template>
  <div class="content mypage">
    <v-pageheader
      :top-breadcrumb="topBreadcrumb"
      page-title="구매 내역"
      page-infotext=""
    />
    <mypage-lnb />
    <div class="mypage-wrap order-list">
      <div class="top-noti-info">
        <div class="inbl-wrap">
          <div class="date-wrap">
            <div class="label-input">
              <span class="offscreen">시작일</span>
              <v-date-picker v-model="startDate" class="datepicker" />
            </div>
            <span class="dash"></span>
            <div class="label-input">
              <span class="offscreen">종료일</span>
              <v-date-picker v-model="endDate" class="datepicker" />
            </div>
          </div>
            <v-select
              v-model="selectCalVal"
              :data="selectCalList"
              class="no-st"
              @change="calChange"
            />
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import MypageLnb from '~/components/page/mypage/index/MypageLnb'

export default {
  components: {
    MypageLnb,
  },
  data(){
    return{
      topBreadcrumb: [
        { linkName: '', link: '/' },
      ],
      startDate:'',
      endDate:'',
      selectCalVal:'',
      selectCalList:[
        { value: '', label: '선택' },
        { value: 'week', label: '1주일' },
        { value: 'month', label: '1개월' },
      ],
    }
  },
  methods: {
    //달력
    getDateStr(myDate){
      let year = myDate.getFullYear()
      let month = (myDate.getMonth() + 1)
      let day = myDate.getDate()

      month = (month < 10) ? '0' + String(month) : month
      day = (day < 10) ? '0' + String(day) : day

      return  year + '.' + month + '.' + day
    },
    today() {
      let d = new Date()
      return this.getDateStr(d)
    },
    lastWeek() {
      let d = new Date()
      let dayOfMonth = d.getDate()
      d.setDate(dayOfMonth - 7)
      return this.getDateStr(d)
    },
    lastMonth() {
      let d = new Date()
      let monthOfYear = d.getMonth()
      d.setMonth(monthOfYear - 1)
      return this.getDateStr(d)
    },
    calChange(value){
      if(value == 'week'){
        this.startDate = this.today()
        this.endDate = this.lastWeek()
      }else if(value == 'month'){
        this.startDate = this.today()
        this.endDate = this.lastMonth()
      }
    }
  },
}
</script>
