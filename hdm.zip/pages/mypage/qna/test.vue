<template>
  <div class="content mypage mypage-qna">

          <ul>
              <li
                v-for="({ menuId, menuName}, index) in menus"
                :key="index"
              >
                <button type="button" :data-id="menuId">
                  {{ menuName }}
                </button>

                <div class="sub_wrap">
                  <div class="sub_contents">
                    <button type="button" class="btn_close">
                      <span class="sr-only">검색창 닫기</span>
                    </button>
                  </div>
                </div>
              </li>
            </ul>
<br />
<br />
<br />
<br />
            <div>
              {{ selectedMenu }}
            </div>
  </div>
</template>

<script>
import { mapGetters, mapMutations} from 'vuex'
export default {
  components: {
  },
  data() {
    return {
      // menu: this.menus
      // currentIndex: 1,
      menu : () => {}
    }
  },
  computed: {
    ...mapGetters({
      menus: 'mypageModules/menus',
      selectedMenu: 'mypageModules/selectedMenu',
    }),
    // menu() {
    //   return this.menus[this.currentIndex]
    // }
  },
  mounted() {
    this.setSelectedMenu(1)
  },
  methods:{
    ...mapMutations({
      setSelectedMenu: 'mypageModules/setSelectedMenu',
    }),
  }
}
</script>
