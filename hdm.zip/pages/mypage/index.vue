<template>
  <div class="content mypage">
    <v-pageheader
      :top-breadcrumb="topBreadcrumb"
      page-title="마이페이지"
      page-infotext=""
    />
    <mypage-lnb />
    <div class="mypage-wrap">

    </div>
  </div>
</template>

<script>
import MypageLnb from '~/components/page/mypage/index/MypageLnb'

export default {
  components: {
    MypageLnb,
  },
   data(){
    return{
      topBreadcrumb: [
        { linkName: '', link: '/' },
      ],
    }
  }
}
</script>
