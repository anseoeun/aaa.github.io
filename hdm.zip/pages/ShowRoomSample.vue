<template>
  <div style="padding-top: 90px">쇼룸 레이아웃 샘플</div>
</template>

<script>
export default {
  layout: 'showroom',
}
</script>

<!-- 화면 확인용 -->
<style>
.container { background: skyblue; height: 80vh;}
</style>