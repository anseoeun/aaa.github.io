
$(document).ready(function(){
    $('#header .gnb-wrap .profile-top > a').click(function(){
        console.log('dldlddldl');
        if($('.profile-pop').is(':hidden')){
            $(this).addClass('active');
            $('.profile-pop').addClass('active');
            $('.profile-pop').show();
        }else{
            $(this).removeClass('active');
            $('.profile-pop').removeClass('active');
            $('.profile-pop').hide();
        }

        setTimeout(function(){
            var $target = $('.profile-pop')
            var cls = 'profile-top'
            $('body').on('click.temp', function(e){
                if($(e.target).hasClass(cls) || $(e.target).parents().hasClass(cls)) return;
                if(!$target.has(e.target).length){
                    $target.hide();
                    $('body').off('click.temp');
                }
            });

            $(window).on('resize', function(e){
                $target.hide();
                $('body').off('click.temp');
            });
        }, 300);

    });


    $('.mobile-menu a').click(function(){
        $('#header .gnb-wrap .gnb').addClass('active');
        $('body').addClass('fix');
        $('.dimmed').show();
    });
    $('.menu-close').click(function(){
        $('#header .gnb-wrap .gnb').removeClass('active');
        $('body').removeClass('fix');
        $('.dimmed').hide();
    });
    $('.mobile-search a').click(function(){
        $('#header .top-area').addClass('active');
    });
    $('.mo-search-close').click(function(){
        $('#header .top-area').removeClass('active');
    });

    $(window).resize(function(){
        var windowWidth = window.innerWidth;
        if( windowWidth >= 820 ){
            $('#header .gnb-wrap .gnb').removeClass('active');
            $('#header .top-area').removeClass('active');
            $('body').removeClass('fix');
            $('.dimmed').hide();
        }
    });
    var windowWidth = window.innerWidth;
    if( windowWidth >= 820 ){
        $('#header .gnb-wrap .gnb').removeClass('active');
        $('#header .top-area').removeClass('active');
        $('body').removeClass('fix');
        $('.dimmed').hide();
    }
});


